// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: unitTests.cs
// Responsibility: Michael Paul Johnson
// Last reviewed: 
// 
// <remarks>
// NUnit tests for Conch
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.IO;
using System.Collections.Specialized;
using SIL.FieldWorks.Common.Framework;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.FDO.Scripture;
using SIL.WordWorks.Conch;
using NUnit.Framework;


namespace SIL.WordWorks.ConchTests
{
	/// <summary>
	/// Test methods in this class must be tagged with the [Test] attribute,
	/// be public, take no parameters, and return void. If the test method
	/// throws an exception, failure is assumed, unless the method is tagged
	/// with the expected exception. Please see the NUnit documentation for
	/// details.
	/// </summary>
	[TestFixture]
	public class TestFixture
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="TestFixture"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public TestFixture()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[Test] public void SimpleTest()
		{
			Assertion.Assert("Oyster.exe must exist.", File.Exists("Oyster.exe"));
			Assertion.Assert("TestPlugin1.dll must exist.", File.Exists("TestPlugin1.dll"));
			Assertion.Assert("TestPlugin2.dll must exist.", File.Exists("TestPlugin2.dll"));
			Assertion.Assert("TestPlugin3.dll must exist.", File.Exists("TestPlugin3.dll"));

			StreamWriter sw = new StreamWriter("ConchDebugLog.txt");
			sw.WriteLine(DateTime.Now.ToString());
			sw.Close();

			Assertion.Assert("Please set CONCHPROG to program directory of Conch.",
				Environment.GetEnvironmentVariable("CONCHPROG") != null);
		}
	}
}
