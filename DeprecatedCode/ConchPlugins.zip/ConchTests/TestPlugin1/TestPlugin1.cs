// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: TestPlugin1.cs
// Responsibility: Michael Paul Johnson
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace SIL.WordWorks.Conch
{
	/// <summary>
	/// Summary description for TestPlugin2.
	/// </summary>
	public class TestPlugin1 : TPlugin
	{
		private System.Windows.Forms.TextBox textBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="TestPlugin2"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public TestPlugin1()//(SIL.FieldWorks.FDO.FdoCache cache) :base(cache)
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			FwAvailableTooList.AddContextHandler(new FwAvailableTooList.ContextHandler(HandleContext));
		}

		public new void HandleContext(ContextMessage context)
		{
			if (!m_echoExpected)
			{
				textBox1.Text = context.Text;
			}
			base.HandleContext(context);
			return;
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged 
		/// resources; <c>false</c> to release only unmanaged resources. 
		/// </param>
		/// -----------------------------------------------------------------------------------
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(8, 40);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(128, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "Apinun!";
			this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			// 
			// TestPlugin1
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.textBox1});
			this.Name = "TestPlugin1";
			this.ResumeLayout(false);

		}
		#endregion

		private void textBox1_TextChanged(object sender, System.EventArgs e)
		{
			SetNewContext(new ContextMessage(0, textBox1.Text));
		}

//		//this is a hack related to getting parameters into the initialize method
//		private void TestPlugin1_Load(object sender, System.EventArgs e)
//		{
//			this.Initialize();
//		}
	}
}
