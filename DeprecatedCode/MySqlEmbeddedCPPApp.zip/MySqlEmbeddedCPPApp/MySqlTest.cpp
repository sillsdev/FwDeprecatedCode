// Code is based on http://lstigile.wordpress.com/2009/05/19/using-libmysqld-with-microsoft-visual-c-2008-express/#comment-63

#include <stdafx.h>
#include <stdlib.h>
#include <iostream>
#include <stdio.h>
#include <stdarg.h>
#include <windows.h>
#include <mysql.h>

MYSQL *mysql;
MYSQL_RES *results;
MYSQL_ROW record;


static char *server_options[] = { "mysql_test",
	"--datadir=C:/Documents and Settings/All Users/Application Data/MySQL/MySQL Server 5.1/data",
	"--language=C:/Program Files/MySQL/MySQL Server 5.1/share/english",  NULL };
int num_elements = sizeof(server_options)/ sizeof(char *) - 1;
static char *server_groups[] = { "libmysqld_server", NULL };

int main(int argc, char* argv[])
{
int retval;

	try
	{
		retval = mysql_library_init(num_elements, server_options, (char **) server_groups);
	}
	catch(long)
	{
	   printf("mysql_library_init failed completely");
	}
	if (retval != 0) {
	   printf("mysql_library_init returned error");
	   return 0;
	}

	try
	{
		mysql = mysql_init(NULL);
	}
	catch(long)
	{
	   printf("mysql_init failed completely");
	   mysql_library_end();
	}
	if (mysql == NULL) {
	   printf("mysql_init returned null");
	   mysql_library_end();
	   return 0;
	}

	mysql_options(mysql, MYSQL_OPT_USE_EMBEDDED_CONNECTION, NULL);

	//mysql_real_connect(mysql, NULL,"root", NULL, "mysql", 0, NULL, 0);
	mysql_real_connect(mysql, NULL, "root", "inscrutable", "mysql", 0, NULL, 0);

	mysql_query(mysql, "SELECT user, host FROM user");
	results = mysql_store_result(mysql);

	while((record = mysql_fetch_row(results))) {
	  printf("%s � %s \n", record[0], record[1]);
	}

	mysql_free_result(results);
	mysql_close(mysql);
	mysql_library_end();

	return 0;
	}