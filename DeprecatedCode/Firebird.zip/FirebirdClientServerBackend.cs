// --------------------------------------------------------------------------------------------
// Copyright (C) 2009 SIL International. All rights reserved.
// 
// Distributable under the terms of either the Common Public License or the
// GNU Lesser General Public License, as specified in the LICENSING.txt file.
// 
// File: FirebirdClientServerBackend.cs
// Responsibility: John Thomson, Steve Miller
// Last reviewed: never
// --------------------------------------------------------------------------------------------
using SIL.FieldWorks.FDO.DomainServices.DataMigration;

namespace SIL.FieldWorks.FDO.Infrastructure.Impl
{
	/// <summary>
	/// A subclass of the ClientServerBackend which handles a client/server Firebird database.
	/// </summary>
	internal sealed class FirebirdClientServerBackend : ClientServerBackend
	{
		/// <summary>
		/// Constructor.
		/// </summary>
		internal FirebirdClientServerBackend(FdoCache cache, IdentityMap identityMap, ICmObjectSurrogateFactory surrogateFactory, IFwMetaDataCacheManagedInternal mdc, IDataMigrationManager dataMigrationManager)
			: base(cache, identityMap, surrogateFactory, mdc, dataMigrationManager)
		{
			m_strategy = new FirebirdClientServerStrategy(this, cache, mdc, surrogateFactory);
		}

		protected override bool RenameMyFiles(string sNewBasename)
		{
			return m_strategy.RenameFiles(sNewBasename, ModelVersion);
		}
	}
}