// --------------------------------------------------------------------------------------------
// Copyright (C) 2009 SIL International. All rights reserved.
// 
// Distributable under the terms of either the Common Public License or the
// GNU Lesser General Public License, as specified in the LICENSING.txt file.
// 
// File: FirebirdBackendStrategy.cs
// Responsibility: John Thomson, Steve Miller
// Last reviewed: never
// --------------------------------------------------------------------------------------------
using FirebirdSql.Data.FirebirdClient;
using System.IO;
using System;
using System.Diagnostics;

namespace SIL.FieldWorks.FDO.Infrastructure.Impl
{
	class FirebirdClientServerStrategy : FirebirdStrategy
	{
		/// <summary>
		/// Directory where the (default) Firebird server was installed.  Cached in a member
		/// variable as a convenience.
		/// </summary>
		string m_defaultInstanceDir;

		internal FirebirdClientServerStrategy(FDOBackendProvider backend, FdoCache cache, IFwMetaDataCacheManagedInternal mdc, ICmObjectSurrogateFactory surrogateFactory) :
			base(backend, cache, mdc, surrogateFactory)
		{
			m_defaultInstanceDir = null;
		}

		protected override string DataSource()
		{
			return "localhost";
		}

		protected override string Password()
		{
			return "inscrutable";
		}

		protected override FbServerType ServerType()
		{
			// I never did figure out what FbServerType.Context is, but the doc says
			// that Default is client server.
			return FbServerType.Default;
		}

		protected override bool Pooling()
		{
			// No. This keeps the connection open,
			// even when told to close,
			// 'just in case' somebody wants to reopen it, I (RandyR) guess.
			// The migration/port tests (MigrationToAnotherBEPTests) fail with it set to 'true',
			// but pass on 'false'.
			//return true; 
			return false;
		}

		/// <summary>
		/// Rename the files (or directories) used for storing the data.
		/// </summary>
		/// <param name="sNewBasename"></param>
		/// <param name="currentModelVersion"></param>
		/// <returns>true if successful, false if rename failed</returns>
		internal override bool RenameFiles(string sNewBasename, int currentModelVersion)
		{
			if (DataSource() != "localhost")
				return false;
			// Check that the new name doesn't exist.
			string sNewPath = Path.ChangeExtension(
				Path.Combine(Path.GetDirectoryName(m_pathname), sNewBasename),
				Path.GetExtension(m_pathname)).ToUpperInvariant();
			if (File.Exists(sNewPath))
				return false;
			// Close the connection to the file.
			DestroyConnection();
			if (!DetachDatabase(m_pathname))
				return false;
			// Rename the file.
			bool retval;
			try
			{
				File.Move(m_pathname, sNewPath);
				// TODO: (SteveMiller): The above line ought to be replaced with a proper RemoveBackend()
				//File.Copy(m_pathname, sNewPath);
				//RemoveBackEnd();
				m_pathname = sNewPath;
				retval = true;
			}
			catch
			{
				retval = false;
			}
			// Reopen the connection.
			m_fRestarting = true;
			AttachDatabase(m_pathname);
			StartupInternal(currentModelVersion, new object[] { m_pathname });
			return retval;
		}

		/// <summary>
		/// Directory where the (default) Firebird server was installed.  On MicroSoft Windows
		/// systems, this is found in the registry following installation.  On other systems,
		/// who knows where it can be found?
		/// </summary>
		private string DefaultInstanceDir
		{
			get
			{
				if (String.IsNullOrEmpty(m_defaultInstanceDir))
				{
					Microsoft.Win32.RegistryKey rk = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
						"SOFTWARE\\Firebird Project\\Firebird Server\\Instances");
					m_defaultInstanceDir = rk.GetValue("DefaultInstance") as string;
				}
				return m_defaultInstanceDir;
			}
		}

		private bool DetachDatabase(string pathname)
		{
			var prc = new Process();
			prc.StartInfo.FileName = Path.Combine(DefaultInstanceDir, "bin\\gfix");
			prc.StartInfo.Arguments = String.Format("-user SYSDBA -password {0} {1}:{2} -shut full -force 0",
				Password(), DataSource(), pathname);
			prc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			prc.Start();
			prc.WaitForExit();
			int ret = prc.ExitCode;
			return ret == 0;
		}

		private bool AttachDatabase(string pathname)
		{
			Process prc;
			prc = new Process();
			prc.StartInfo.FileName = Path.Combine(DefaultInstanceDir, "bin\\gfix");
			prc.StartInfo.Arguments = String.Format("-user SYSDBA -password {0} {1}:{2} -online normal",
				Password(), DataSource(), pathname);
			prc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			prc.Start();
			prc.WaitForExit();
			int ret = prc.ExitCode;
			return ret == 0;
		}
	}
}