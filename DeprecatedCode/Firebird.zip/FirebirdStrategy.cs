// --------------------------------------------------------------------------------------------
// Copyright (C) 2009 SIL International. All rights reserved.
// 
// Distributable under the terms of either the Common Public License or the
// GNU Lesser General Public License, as specified in the LICENSING.txt file.
// 
// File: FirebirdBackendStrategy.cs
// Responsibility: John Thomson, Steve Miller
// Last reviewed: never
// --------------------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.IO; // Path & File
using System.Data; // CommandType
using FirebirdSql.Data.FirebirdClient;

namespace SIL.FieldWorks.FDO.Infrastructure.Impl
{
	/// <summary>
	/// A subclass of the BackendStrategy
	/// which handles an in-process Firebird database.
	/// </summary>
	internal class FirebirdStrategy : PersistenceStrategy
	{
		protected FbConnection m_con;
		private int m_dbid = 1;
		private readonly Dictionary<Guid, int> m_guid2dbid = new Dictionary<Guid, int>();
		private int m_custFieldDbid = 1;
		private readonly Dictionary<string, int> m_guid2custFieldDBid = new Dictionary<string, int>();
		protected readonly FdoCache m_cache;
		protected readonly IFwMetaDataCacheManagedInternal m_mdcInternal;
		protected readonly FDOBackendProvider m_backend;
		protected readonly ICmObjectSurrogateFactory m_surrogateFactory;

		protected string m_pathname;
		protected bool m_fRestarting;

		/// <summary>
		/// Constructor.
		/// </summary>
		internal FirebirdStrategy(FDOBackendProvider backend, FdoCache cache, IFwMetaDataCacheManagedInternal mdc, ICmObjectSurrogateFactory surrogateFactory)
		{
			m_fRestarting = false;
			m_backend = backend;
			m_cache = cache;
			m_mdcInternal = mdc;
			m_surrogateFactory = surrogateFactory;
		}

		#region IFWDisposable implementation

		/// <summary>
		/// Executes in two distinct scenarios.
		/// 
		/// 1. If disposing is true, the method has been called directly
		/// or indirectly by a user's code via the Dispose method.
		/// Both managed and unmanaged resources can be disposed.
		/// 
		/// 2. If disposing is false, the method has been called by the 
		/// runtime from inside the finalizer and you should not reference (access) 
		/// other managed objects, as they already have been garbage collected.
		/// Only unmanaged resources can be disposed.
		/// </summary>
		/// <param name="disposing"></param>
		/// <remarks>
		/// If any exceptions are thrown, that is fine.
		/// If the method is being done in a finalizer, it will be ignored.
		/// If it is thrown by client code calling Dispose,
		/// it needs to be handled by fixing the bug.
		/// 
		/// If subclasses override this method, they should call the base implementation.
		/// </remarks>
		protected override void Dispose(bool disposing)
		{
			// Can be called more than once,
			// but only do things the first time.
			if (IsDisposed)
				return;

			if (disposing)
			{
				if (m_con != null)
					m_con.Close();
			}

			// Dispose unmanaged resources here, whether disposing is true or false.

			// Set all member variables to null.
			m_con = null;

			base.Dispose(disposing);
		}

		#endregion IFWDisposable implementation

		/// <summary>
		/// Start the BEP.
		/// </summary>
		/// <param name="currentModelVersion"></param>
		/// <param name="backendProviderOptions"></param>
		/// <returns></returns>
		public override int StartupInternal(int currentModelVersion, object[] backendProviderOptions)
		{
			int currentDataStoreVersion;

			ConnectBackEnd(backendProviderOptions);
			
			// Get data from MAIN.
			using (var cmd = m_con.CreateCommand())
			{
				cmd.CommandType = CommandType.Text;

				// Check model version number.
				cmd.CommandText = "SELECT ID FROM MODELVERSION";
				currentDataStoreVersion = (int) cmd.ExecuteScalar();
				var needConversion = (currentDataStoreVersion != currentModelVersion);
				if (m_fRestarting)
				{
					System.Diagnostics.Debug.Assert(currentDataStoreVersion == currentModelVersion);
					m_fRestarting = false;
				}
				else
				{

					// Get custom fields
					cmd.CommandText = "SELECT * FROM CUSTOMFIELD";
					using (var dataReader = cmd.ExecuteReader())
					{
						var customFields = new List<CustomFieldInfo>();
						while (dataReader.Read())
						{
							var custFieldDbid = dataReader.GetInt32(0);
							if (m_custFieldDbid < custFieldDbid)
								m_custFieldDbid = custFieldDbid;
							m_custFieldDbid++;

							var cfi = new CustomFieldInfo
							          	{
							          		m_classname = dataReader.GetString(1),
							          		m_fieldname = dataReader.GetString(2),
							          		m_destinationClass = dataReader.GetInt32(3),
							          		m_fieldType = FDOBackendProvider.GetFlidTypeFromString(dataReader.GetString(4))
							          	};
							customFields.Add(cfi);
							// Add to map.
							m_guid2custFieldDBid[cfi.Key] = custFieldDbid;
						}
						m_backend.RegisterOriginalCustomProperties(customFields);
					}

					cmd.CommandText = "SELECT * FROM MAIN";
					using (var dataReader = cmd.ExecuteReader())
					{
						while (dataReader.Read())
						{
							var dbid = dataReader.GetInt32(0);
							if (m_dbid < dbid)
								m_dbid = dbid;
							m_dbid++;

							var surrogate = m_surrogateFactory.Create(dataReader.GetString(1));
							if (needConversion)
								m_backend.RegisterSurrogateForConversion(surrogate);
							else
								m_backend.RegisterInactiveSurrogate(surrogate);

							// Add to map (this class only).
							m_guid2dbid[surrogate.Guid] = dbid;
						}
					}
				}
			}
			return currentDataStoreVersion;
		}

		private FbConnectionStringBuilder GetConnectionStringBuilder (object[] backendProviderOptions)
		{
			var conStrBuilder = new FbConnectionStringBuilder
          	{
          		DataSource = DataSource(),
          		Database = (string)backendProviderOptions[0],
          		UserID = "SYSDBA",
          		Password = Password(),
          		Pooling = Pooling(),
          		ServerType = ServerType(),
          		Charset = "UTF8"
          	};
			m_backend.DatabaseName = backendProviderOptions[0].ToString().ToUpper();
			m_pathname = conStrBuilder.Database;

			return conStrBuilder;
		}

		protected virtual string DataSource()
		{
			// The default is an empty string. It is set to localhost for the local
			// computer. I (Steve Miller) imagine it could be set to something else
			// for connecting to another server. 
			return "";
		}

		protected virtual string Password()
		{
			// "masterkey" is the default for new Firebird installations.
			return "masterkey";
		}

		protected virtual FbServerType ServerType()
		{
			return FbServerType.Embedded;
		}

		protected virtual bool Pooling()
		{
			// The default is true; it is set false for embedded
			return false;
		}

		/// <summary>
		/// Create a LangProject with the BEP.
		/// </summary>
		/// <param name="backendProviderOptions"></param>
		/// <param name="currentModelVersion"></param>
		public override void CreateInternal(object[] backendProviderOptions, int currentModelVersion)
		{
			var conStrBuilder = GetConnectionStringBuilder(backendProviderOptions);

			if (File.Exists(conStrBuilder.Database))
			{
				throw new InvalidOperationException("File already exists.");
			}

			try
			{
				// 1. Create a brand new DB.
				const int pageSize = 16384;
				const bool forceWrites = true;
				const bool overwriteDb = true;
				FbConnection.CreateDatabase(conStrBuilder.ToString(), pageSize, forceWrites, overwriteDb);
				m_con = new FbConnection(conStrBuilder.ToString());
				m_con.Open();

				// 2. Create the tables.
				using (var trans = m_con.BeginTransaction())
				{
					using (var cmd = m_con.CreateCommand())
					{
						cmd.Transaction = trans;
						try
						{
							cmd.CommandType = CommandType.Text;
							cmd.CommandText = "CREATE TABLE MODELVERSION (" + 
								"ID INTEGER NOT NULL, " + 
								"CONSTRAINT PK_MODELVERSION PRIMARY KEY(ID))";
							cmd.ExecuteNonQuery();
							cmd.CommandText = "CREATE TABLE MAIN (" + 
								"ID INTEGER NOT NULL, " +
								"XMLDATA BLOB SUB_TYPE TEXT, " +
								"CONSTRAINT PK_MAIN PRIMARY KEY(ID))";
							cmd.ExecuteNonQuery();
							cmd.CommandText = "CREATE TABLE CUSTOMFIELD (" + 
								"ID INTEGER NOT NULL," +
							    "CLASSNAME VARCHAR(50) CHARACTER SET UNICODE_FSS, " +
							    "FIELDNAME VARCHAR(50) CHARACTER SET UNICODE_FSS, " +
							    "DESTINATIONCLASS INTEGER NOT NULL ," +
							    "FIELDTYPE VARCHAR(50) CHARACTER SET UNICODE_FSS, " +
								"CONSTRAINT PK_CUSTOMFIELD PRIMARY KEY(ID))";
							cmd.ExecuteNonQuery();

							trans.Commit();
						}
						catch (Exception err)
						{
							trans.Rollback();
							throw err;
						}
					}
				}
				// 3. Set the version number.
				// (This can't be done in the other transaction,
				// since the table is also being created in the same transaction.)
				InsertVersionNumber(currentModelVersion);

				m_con.Close();
			}
			catch (Exception err)
			{
				if (m_con != null)
					m_con.Close();
				var msg = err.Message;
				throw err;
			}
		}

		private void InsertVersionNumber(int currentModelVersion)
		{
			using (var insTrans = m_con.BeginTransaction())
			{
				using (var insCmd = m_con.CreateCommand())
				{
					insCmd.Transaction = insTrans;
					insCmd.CommandType = CommandType.Text;
					// Add model version number.
					insCmd.CommandText = "INSERT INTO MODELVERSION (ID) VALUES (?)";
					var pId = insCmd.Parameters.Add("@ID", FbDbType.Integer);
					pId.Value = currentModelVersion;
					insCmd.ExecuteNonQuery();
				}
				insTrans.Commit();
			}
		}

		public override void UpdateVersionNumber(int currentModelVersion)
		{
			if (m_con.State == ConnectionState.Closed)
				m_con.Open();

			// Wipe out contents of table
			using (var insTrans = m_con.BeginTransaction())
			{
				using (var insCmd = m_con.CreateCommand())
				{
					insCmd.Transaction = insTrans;
					insCmd.CommandType = CommandType.Text;
					insCmd.CommandText = "DELETE FROM MODELVERSION";
					insCmd.ExecuteNonQuery();
				}
				insTrans.Commit();
			}
			// Now, put back the new number.
			InsertVersionNumber(currentModelVersion);
		}

		#region IDataStorer implementation

		/// <summary>
		/// Update the backend store.
		/// </summary>
		/// <param name="newbies">The newly created objects</param>
		/// <param name="dirtballs">The recently modified objects</param>
		/// <param name="goners">The recently deleted objects</param>
		public override void Commit(HashSet<ICmObjectOrSurrogate> newbies, HashSet<ICmObjectOrSurrogate> dirtballs, HashSet<ICmObjectId> goners)
		{
			IEnumerable<CustomFieldInfo> cfiList;
			if (!m_backend.HaveAnythingToCommit(newbies, dirtballs, goners, out cfiList)) return;
			
			FbTransaction trans = null;
			try
			{
				if (m_con.State == ConnectionState.Closed)
					m_con.Open();

				trans = m_con.BeginTransaction();
				using (var cmd = m_con.CreateCommand())
				{
					cmd.Transaction = trans;
					cmd.CommandType = CommandType.Text;

					// Add new custom fields
					cmd.CommandText = "INSERT INTO CUSTOMFIELD (ID, CLASSNAME, FIELDNAME, DESTINATIONCLASS, FIELDTYPE) VALUES (?, ?, ?, ?, ?)";
					var pId = cmd.Parameters.Add("@ID", FbDbType.Integer);
					var pClassName = cmd.Parameters.Add("@CLASSNAME", FbDbType.VarChar);
					var pFieldName = cmd.Parameters.Add("@FIELDNAME", FbDbType.VarChar);
					var pDestClass = cmd.Parameters.Add("@DESTINATIONCLASS", FbDbType.Integer);
					var pFieldType = cmd.Parameters.Add("@FIELDTYPE", FbDbType.VarChar);
					foreach (var cfi in cfiList)
					{
						var cfiKey = cfi.Key;
						if (!m_guid2custFieldDBid.ContainsKey(cfiKey))
						{
							pId.Value = m_custFieldDbid;
							pClassName.Value = cfi.m_classname;
							pFieldName.Value = cfi.m_fieldname;
							pDestClass.Value = cfi.m_destinationClass;
							pFieldType.Value = FDOBackendProvider.GetFlidTypeAsString(cfi.m_fieldType);
							cmd.ExecuteNonQuery();

							// Add to map.
							m_guid2custFieldDBid[cfiKey] = m_custFieldDbid++;
						}
					}

					// Handle insertions.
					cmd.Parameters.Clear();
					pId = cmd.Parameters.Add("@ID", FbDbType.Integer);
					var pXml = cmd.Parameters.Add("@XMLDATA", FbDbType.Text);
					cmd.CommandText = "INSERT INTO MAIN (ID, XMLDATA) VALUES (?, ?)";
					foreach (var newby in newbies)
					{
						pId.Value = m_dbid;
						pXml.Value = newby.XML;
						cmd.ExecuteNonQuery();
			
						// Add to map (for this class only).
						m_guid2dbid[newby.Id.Guid] = m_dbid++;
					}
					if (newbies.Count > 100) // Improve performance by "recalculating selectivity."
					{
						cmd.CommandText = "SET STATISTICS INDEX PK_MAIN;";
						cmd.ExecuteNonQuery();
					}

					// Handle update.
					cmd.Parameters.Clear();
					pXml = cmd.Parameters.Add("@XMLDATA", FbDbType.Text);
					pId = cmd.Parameters.Add("@ID", FbDbType.Integer);
					cmd.CommandText = "UPDATE MAIN SET XMLDATA = ? WHERE ID = ?";
					foreach (var dirtball in dirtballs)
					{
						pId.Value = m_guid2dbid[dirtball.Id.Guid];
						pXml.Value = dirtball.XML;
						cmd.ExecuteNonQuery();
					}

					// Handle deletions.
					cmd.Parameters.Clear();
					pId = cmd.Parameters.Add("@ID", FbDbType.Integer);
					cmd.CommandText = "DELETE FROM MAIN WHERE ID = ?";
					foreach (var goner in goners)
					{
						var dbid = m_guid2dbid[goner.Guid];
						pId.Value = dbid;
						cmd.ExecuteNonQuery();

						// Remove from map (this class only).
						m_guid2dbid.Remove(goner.Guid);
					}

					trans.Commit();
					trans.Dispose();
				}
				m_con.Close();
			}
			catch  (Exception err)
			{
				if (trans != null)
				{
					trans.Rollback();
					trans.Dispose();
				}
				m_con.Close();
				throw err;
			}
		}

		#endregion IDataStorer implementation

		/// <summary>
		/// Rename the files (or directories) used for storing the data.
		/// </summary>
		/// <param name="sNewBasename"></param>
		/// <param name="currentModelVersion"></param>
		/// <returns>true if successful, false if rename failed</returns>
		internal override bool RenameFiles(string sNewBasename, int currentModelVersion)
		{
			// Check that the new name doesn't exist.
			string sNewPath = Path.ChangeExtension(
				Path.Combine(Path.GetDirectoryName(m_pathname), sNewBasename),
				Path.GetExtension(m_pathname)).ToUpperInvariant();
			if (File.Exists(sNewPath))
				return false;
			// Close the connection to the file.
			DestroyConnection();
			// Rename the file.
			bool retval = true;
			try
			{
				File.Move(m_pathname, sNewPath);
				m_pathname = sNewPath;
			}
			catch
			{
				retval = false;
			}
			// Reopen the connection.
			m_fRestarting = true;
			StartupInternal(currentModelVersion, new object[] { m_pathname });
			return retval;
		}

		protected void DestroyConnection()
		{
			if (m_con != null)
			{
				m_con.Close();
				m_con.Dispose();
			}
			m_con = null;
		}
		/// <summary>
		/// Connect to the database/backend.
		/// </summary>
		public override void ConnectBackEnd(object[] backendProviderOptions)
		{
			var conStrBuilder = GetConnectionStringBuilder(backendProviderOptions);
			conStrBuilder.Database = m_backend.DatabaseName;
			m_con = new FbConnection(conStrBuilder.ToString());
			m_con.Open();
		}

		/// <summary>
		/// Remove or drop the database/backend and its files(s).
		/// </summary>
		public override void RemoveBackEnd()
		{
			var trans = m_con.BeginTransaction();
			var cmd = m_con.CreateCommand();
			cmd.CommandType = CommandType.Text;
			try
			{
				cmd.CommandText = String.Format("DROP DATABASE {0}; ", m_backend.DatabaseName);
				cmd.ExecuteNonQuery();
			}
			catch
			{
				trans.Rollback();
				throw;
			}
			trans.Commit();
		}
	}
}