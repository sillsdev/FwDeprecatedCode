// --------------------------------------------------------------------------------------------
// Copyright (C) 2009 SIL International. All rights reserved.
// 
// Distributable under the terms of either the Common Public License or the
// GNU Lesser General Public License, as specified in the LICENSING.txt file.
// 
// File: FirebirdEmbeddedBackend.cs
// Responsibility: John Thomson, Steve Miller
// Last reviewed: never
// --------------------------------------------------------------------------------------------
using SIL.FieldWorks.FDO.DomainServices;
using SIL.FieldWorks.FDO.DomainServices.DataMigration;

namespace SIL.FieldWorks.FDO.Infrastructure.Impl
{
	/// <summary>
	/// A subclass of the EmbeddedBackend
	/// which handles an in-process Firebird database.
	/// </summary>
	internal sealed class FirebirdEmbeddedBackend : EmbeddedBackend
	{
		/// <summary>
		/// Constructor.
		/// </summary>
		internal FirebirdEmbeddedBackend(FdoCache cache, IdentityMap identityMap, ICmObjectSurrogateFactory surrogateFactory, IFwMetaDataCacheManagedInternal mdc, IDataMigrationManager dataMigrationManager)
			: base(cache, identityMap, surrogateFactory, mdc, dataMigrationManager)
		{
			// The FirebirdStrategy is embedded by default, so we don't have an embedded subclass.
			m_strategy = new FirebirdStrategy(this, cache, mdc, surrogateFactory);
		}

		protected override bool RenameMyFiles(string sNewBasename)
		{
			return m_strategy.RenameFiles(sNewBasename, ModelVersion);
		}
	}
}