// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FwSqlXmlRetriever_Test.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using NUnit.Framework;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Utils;
using System.Diagnostics;
using SIL.FieldWorks.FDO.Ling;
using System.Xml;
using System.Xml.Xsl;
using System.IO;

namespace SIL.FieldWorks.Common.Utils
{
#if USEZPU
	/// <summary>
	/// Summary description for FwSqlXmlRetriever_Test.
	/// </summary>
	[TestFixture]
	public class FwSqlXmlRetriever_Test : TestWWUtilsBase
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="FwSqlXmlRetriever_Test"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public FwSqlXmlRetriever_Test()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		protected int[] FirstTwoWordformHvos
		{
			get 
			{
				return GetHvosForFirstNObjectsOfClass(m_cache.LanguageProject.WordformInventoryOA.WordformsOC,WfiWordform.kClassId,2);
            }
		}

		protected FwSqlXmlRetriever GetRetriever()
		{
			return new FwSqlXmlRetriever(".\\SILFW", "ZPU", FwSqlXmlRetriever.PathToWordworksSchemas() + "sqlxdrWFIDump.xdr");
		}

		[Test]
		public void Peers()
		{
			int[] hvos = FirstTwoWordformHvos;
			FwSqlXmlRetriever retriever = GetRetriever();
			retriever.BeginElement("TwoWords");
			retriever.InsertXPathQueryResults("WfiWordform[@Id='" + hvos[0].ToString() + "' or @Id='" + hvos[1].ToString() + "']");
			retriever.EndElement();
		}


		[Test]
		public void MakeDOM_SimpleSQL ()
		{
			int[] hvos =FirstTwoWordformHvos;
			FwSqlXmlRetriever retriever =GetRetriever ();
			retriever.BeginElement("someWords");

			//without the XML auto statement
			retriever.InsertSQLQueryResults("select * from WfiWordform(readuncommitted) where Id='" + hvos[0].ToString()+"'");

			//with the XML auto statement
			retriever.InsertSQLQueryResults("select * from WfiWordform(readuncommitted) where Id='" + hvos[0].ToString()+"' for xml auto");

			retriever.EndElement();
			Assertion.Assert(retriever.DOMDocument.ChildNodes.Count == 1);
			Assertion.Assert(retriever.DOMDocument.ChildNodes[0].ChildNodes.Count == 2);
		}

		[Test]
		public void MakeDOM_SimpleXPATH ()
		{
			int[] hvos =FirstTwoWordformHvos;
			FwSqlXmlRetriever retriever =GetRetriever ();
			retriever.InsertXPathQueryResults("WfiWordform[@Id='" + hvos[0].ToString()+ "' or @Id='" + hvos[1].ToString()+ "']", "firstTwoWords");
			Assertion.Assert(retriever.DOMDocument.ChildNodes.Count == 1);
			Assertion.Assert(retriever.DOMDocument.ChildNodes[0].Name=="firstTwoWords");
			Assertion.Assert(retriever.DOMDocument.ChildNodes[0].ChildNodes.Count == 2);
		}


		[Test]
		public void MakeDOM_NullResult ()
		{
			FwSqlXmlRetriever retriever =GetRetriever ();
			retriever.InsertXPathQueryResults("WfiWordform[@Id='0']", "firstTwoWords");
			retriever.InsertXPathQueryResults("WfiWordform[@Id='0']");
			retriever.InsertXPathQueryResultsOneRoot("WfiWordform[@Id='0']");
		}
		
		protected XmlDocument MakeDOM()
		{
			int[] hvos =FirstTwoWordformHvos;
			FwSqlXmlRetriever retriever =GetRetriever ();
			retriever.BeginElement("someWords");
			retriever.InsertXPathQueryResults("WfiWordform[@Id='" + hvos[0].ToString()+ "' or @Id='" + hvos[1].ToString()+ "']", "firstTwoWords");
			retriever.BeginElement("anotherWord");
			retriever.InsertXPathQueryResults("WfiWordform[@Id='" + hvos[0].ToString()+ "']");
			retriever.EndElement();
			retriever.EndElement();

			//Debug.WriteLine (retriever.GetAsString());
			XmlNode node = retriever.DOMDocument.SelectSingleNode("someWords/anotherWord/WfiWordform[@Id='" + hvos[0].ToString()+ "']");
			Assertion.Assert( node !=null);
			return retriever.DOMDocument;
		}

		[Test]
		public void MakeDOM_Intermediate ()
		{
			XmlDocument document= MakeDOM();
			Assertion.Assert(document.ChildNodes.Count == 1);
			Assertion.Assert(document.ChildNodes[0].Name=="someWords");
			Assertion.Assert(document.ChildNodes[0].ChildNodes.Count == 2);
		}

		[Test]
		//This is not really a test of the component, but provides an example of 
		//how to use it.
		public void WriteToXmlTempFile ()
		{
			XmlDocument document= MakeDOM();
			FwTempFile temp = new FwTempFile(".xml");
			XmlTextWriter writer = new XmlTextWriter(temp.Writer);
			document.Save(writer);	
			StreamReader reader = File.OpenText(temp.CloseAndGetPath());
			Debug.WriteLine ( "xml file contains:");
			Debug.WriteLine (reader.ReadToEnd());
		}

		[Test]
		//This is not really a test of the component, but provides an example of 
		//how to use it.
		public void ConvertToHtmlTempFile ()
		{
			XmlDocument document= MakeDOM();
			XslTransform transform= new XslTransform();
			
			transform.Load(FwSqlXmlRetriever.PathToWordworksTransforms()+"\\WWUtils\\GenericforTesting.xslt");
			FwTempFile temp = new FwTempFile(".htm");
			transform.Transform(document,new XsltArgumentList(), temp.Writer);
			StreamReader reader = File.OpenText(temp.CloseAndGetPath());
			Debug.WriteLine ( "HTML file contains:");
			Debug.WriteLine (reader.ReadToEnd());
		}
	}
#endif // USEZPU
}
