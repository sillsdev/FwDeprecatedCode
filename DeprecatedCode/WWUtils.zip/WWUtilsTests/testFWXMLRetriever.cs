// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: testFWXMLRetreiver.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using NUnit.Framework;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace SIL.FieldWorks.WordWorks.ParseBench_UnitTests
{
	/// <summary>
	/// note this is testing the xdr and xslt (somewhat, not the display) , as well
	/// </summary>
	[TestFixture]
	public class TestFWXMLRetriever:TestParseBenchBase
	{
		FwSqlXmlRetriever m_r;
		int[] m_wfHvos;

		public TestFWXMLRetriever()
		{
		}

		[SetUp]
		public override void SetUp()
		{
			base.SetUp();

			m_r = new FwSqlXmlRetriever(m_cache,
				FwSqlXmlRetriever.PathToWordworksSchemas()+"sqlxdrWFIDump.xdr",
				FwSqlXmlRetriever.PathToWordworksTransforms()+"Wordform.xsl");

			m_wfHvos = m_cache.LanguageProject.WordformInventoryOA.WordformsOC.hvoArray;
		}

		[Test]
		[ExpectedException(typeof(ArgumentException))]
		public void BadTransformPath ()
		{
			m_r.ExecuteXPathQuery("WfiWordform[@Id='" + m_wfHvos[0].ToString() + "']", "abadpath");
		}	
		
		[Test]
		[ExpectedException(typeof(ArgumentException))]
		public void BadSchemaPath ()
		{
			FwSqlXmlRetriever r = new FwSqlXmlRetriever(m_cache,
				"aBadPath.xdr",
				FwSqlXmlRetriever.PathToWordworksTransforms()+"Wordform.xsl");
		}	
		
		[Test]
		public void GetXmlOfWordformAnalyses ()
		{
			//one without a transform
			string s = m_r.ExecuteXPathQuery("WfiWordform[@Id='" + m_wfHvos[0].ToString() + "']", "");
			Debug.Assert(System.IO.File.Exists(s));
			Debug.Assert(System.IO.Path.GetExtension (s) == ".xml");
		}



		[Test]
		public void MakeHTMLOfWordformAnalyses ()
		{
			const int kHowMany = 1;

			for(int i=0;i<kHowMany;i++)
			{
				int hvo = m_wfHvos[i];
				string s = m_r.ExecuteXPathQuery("WfiWordform[@Id='" + hvo.ToString() + "']");
				Debug.Assert(System.IO.File.Exists(s));
				Debug.Assert(System.IO.Path.GetExtension (s) == ".htm");
			}
		}

//		[Test]
//		public void TestThread ()
//		{
//				FwSqlXmlRetriever.RetrieverThread r = new FwSqlXmlRetriever.RetrieverThread(m_r,  "WfiWordform[@Id='" + m_wfHvos[0].ToString() + "']");
//                
//				Thread t = new Thread(new ThreadStart(r.Go));
//
//				// Start the thread.
//				t.Start();
//			t.Join(1000);
//			Assertion.Assert("Didn't finish before timeout", !t.IsAlive);
//			Console.WriteLine("path =" + r.m_sOutputPath);
//		}


	}
}
