//	 --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Class1.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using NUnit.Framework;
using SIL.FieldWorks.FDO;
using System.  Collections;

namespace SIL.FieldWorks.Common.Utils
{
#if USEZPU
	/// <summary>
	/// 
	/// </summary>
	public class TestWWUtilsBase
	{
		protected FdoCache m_cache;

		public TestWWUtilsBase()
		{
		}

		/// <summary>
		/// 
		/// </summary>
		/// <remarks>This method is called before each test</remarks>
		[SetUp]
		public virtual void SetUp()
		{
			m_cache = FdoCache.Create("ZPU");
		}

		/// <summary>
		/// 
		/// </summary>
		/// <remarks>This method is called after each test </remarks>
		[TearDown]
		public virtual void TearDown()
		{
			m_cache.Undo();
			m_cache.Dispose();
			m_cache = null;
		}

		/// <summary>
		/// Get an array of hvos of a given class out of a vector
		/// </summary>
		/// <param name="vec">The vector holding a heterogeneous collection of objects</param>
		/// <param name="classId">the class of objects you want</param>
		/// <param name="howMany">how many you want</param>
		/// <returns></returns>
		/// <example>Get the first LexMajorEntry in the lexicon
		/// <code>
		///  GetHvosForFirstNObjectsOfClass(m_fdoCache.LanguageProject.LexicalDatabaseOA.EntriesOC,
		///				LexMajorEntry.kclsidLexMajorEntry, 1)[0];
		/// </code></example>
		protected int[] GetHvosForFirstNObjectsOfClass(FdoVector vec, int classId, int howMany)
		{
			Assertion.Assert(howMany>0);

			ArrayList hvos = new ArrayList(howMany);
			
			foreach(int hvo in vec.HvoArray)
			{
				CmObject o = CmObject.CreateFromDBObject(m_cache, hvo);
				if(o.ClassID == classId)
					hvos.Add(hvo);
				if(hvos.Count == howMany)
					break;
			}
			Assertion.Assert("Caller asked for "
				+ howMany.ToString()
				+ " objects, but only "
				+ hvos.Count.ToString()
				+ " were available.", hvos.Count == howMany);

			return (int[])hvos.ToArray(System.Type.GetType("System.Int32"));
		}


	}
#endif // USEZPU
}