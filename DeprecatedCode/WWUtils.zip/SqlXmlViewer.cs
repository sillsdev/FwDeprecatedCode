// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: SqlXmlViewer.cs
// Responsibility: AndyBlack
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Xml;
using System.Xml.Xsl;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Resources;
using Microsoft.Win32;
using MSXML2;

using XCore;
using SIL.FieldWorks;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Utils;
using SIL.Utils;

namespace SIL.FieldWorks.XWorks
{
	/// <summary>
	/// Summary description for SqlXmlViewer.
	/// </summary>
	public class SqlXmlViewer : System.Windows.Forms.UserControl, IxCoreColleague, IxCoreContentControl
	{
		#region Data Members
		/// <summary>
		/// The control that shows the HTML data.
		/// </summary>
		protected HtmlControl m_htmlControl;
		/// <summary>
		/// Collection of parameters from the configuration file.
		/// </summary>
		protected XmlNode m_configurationParameters;
		/// <summary>
		/// Mediator that passes off messages.
		/// </summary>
		protected XCore.Mediator m_mediator;

		/// <summary>
		/// special nodes in config file
		/// </summary>
		XmlNode m_retrieverNode;
		XmlNode m_transformsNode;
		/// <summary>
		/// counts for progress bar
		/// </summary>
		int m_cPrompts;
		int m_cTransforms;
		ResourceManager m_stringResMan;

		/// <summary>
		/// Element name for retrievals which embed other retrievals in config file
		/// </summary>
		private const string m_kWrapItems = "wrapItems";
		private string m_sHtmlFileName = null;
		/// <summary>
		/// SqlXdr retriever
		/// </summary>
		private FwSqlXmlRetriever m_Retriever;
		/// <summary>
		/// Cleaned xml document
		/// </summary>
		private string m_sCleanedFile;

		// These data members are set from the parameters.
		/// <summary>
		/// title for dialog box
		/// </summary>
		private string m_sDialogTitle;
		/// <summary>
		/// Registry key name (from config file)
		/// </summary>
		private string m_sRegKeyName;

		private System.Windows.Forms.Button m_GenerateBtn;
		private System.Windows.Forms.Panel m_panelTop;
		private System.Windows.Forms.Panel m_panelBottom;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		#endregion // Data Members

		#region Properties

		private string TransformPath
		{
			get { return DirectoryFinder.GetFWInstallSubDirectory(@"WW\transforms"); }
		}

		/// <summary>
		/// Name of Sketch Dump xdr annotated schema
		/// </summary>
		private string SketchXDR
		{
			get { return "sqlxdrSketchDump.xdr"; }
		}

		/// <summary>
		/// Name of M3 Dump Cleaner transform
		/// </summary>
		private string CleanerXSLT
		{
			get { return "CleanFWDump.xsl"; }
		}

		/// <summary>
		/// Name of M3 Dump to XLingPap transform
		/// </summary>
		private string DumpToXLingPap
		{
			get { return "M3SketchSvrXMLM3MorphologySketch.xsl"; }
		}
		
		/// <summary>
		/// Name of XLingPap DTD
		/// </summary>
		private string XLingPapDTD
		{
			get { return "XLingPap.dtd"; }
		}

		/// <summary>
		/// Name of XLingPap transform
		/// </summary>
		private string XLingPapXSLT
		{
			get { return "XLingPap1.xsl"; }
		}

		/// <summary>
		/// Name of XLingPap Cascading Style Sheet
		/// </summary>
		private string XLingPapCSS
		{
			get { return "MorphSketch.css"; }
		}

		/// <summary>
		/// Name of htm file to display if in the process of generating
		/// </summary>
		private string GeneratingDocument
		{
			get { return @"WW\SQLXMLViewer\GeneratingDocumentPleaseWait.htm"; }
		}

		/// <summary>
		/// Name of htm file to display the first time
		/// </summary>
		private string InitialDocument
		{
			get { return @"WW\SQLXMLViewer\InitialDocument.htm"; }
		}

		private string RegistryKey
		{
			get
			{
				Debug.Assert(Cache != null);
				Debug.Assert(m_sRegKeyName != null);
				return Path.Combine(@"Software\SIL\Fieldworks\SqlXmlViewer",
					Path.Combine(Cache.DatabaseName, m_sRegKeyName));
			}
		}
		
		private string HtmlFilePath
		{
			get { return "HtmlFilePath"; }
		}

		/// <summary>
		/// FDO cache.
		/// </summary>
		protected FdoCache Cache
		{
			get
			{
				return (FdoCache)m_mediator.PropertyTable.GetValue("cache");
			}
		}

		#endregion // Properties

		#region Construction, Initialization, and disposal

		public SqlXmlViewer()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			m_htmlControl = new HtmlControl();
			m_htmlControl.Dock = System.Windows.Forms.DockStyle.Fill;
			m_panelBottom.Controls.Add(m_htmlControl);
			m_stringResMan = new ResourceManager("SIL.FieldWorks.XWorks.xWorksStrings", Assembly.GetExecutingAssembly());
		}

		private void ReadParameters()
		{
			m_sRegKeyName = XmlUtils.GetManditoryAttributeValue(m_configurationParameters, "regKeyName");
			m_sDialogTitle = XmlUtils.GetManditoryAttributeValue(m_configurationParameters, "dialogTitle");
			foreach (XmlNode rNode in m_configurationParameters.ChildNodes)
			{
				if (rNode.Name == "sqlxmlRetriever")
					m_retrieverNode = rNode;
				else if (rNode.Name == "transforms")
					m_transformsNode = rNode;
			}
		}

		private void DetermineNumberOfPrompts()
		{
			m_cPrompts = 0;
			CountPrompts(m_retrieverNode);
		}

		private void CountPrompts(XmlNode parentNode)
		{
			foreach (XmlNode rNode in parentNode.ChildNodes)
			{
				if (rNode.NodeType == XmlNodeType.Element)
				{
					string sPrompt = XmlUtils.GetOptionalAttributeValue(rNode, "progressPrompt");
					if (sPrompt != null)
						m_cPrompts++;
					if (rNode.Name == m_kWrapItems)
					{
						CountPrompts(rNode);
					}
				}
			}
		}
		private void DetermineNumberOfTransforms()
		{
			m_cTransforms = m_transformsNode.ChildNodes.Count;
		}

		private void ReadRegistry()
		{
			m_sHtmlFileName = null;
			RegistryKey regkey = Registry.CurrentUser.OpenSubKey(RegistryKey);
			if (regkey != null)
			{
				m_sHtmlFileName = (string)regkey.GetValue(HtmlFilePath, Path.Combine(DirectoryFinder.FWInstallDirectory, InitialDocument));
				regkey.Close();
			}
			if (!File.Exists(m_sHtmlFileName))
				m_sHtmlFileName = Path.Combine(DirectoryFinder.FWInstallDirectory, InitialDocument);
		}

		private void ShowSketch()
		{
			m_htmlControl.URL = m_sHtmlFileName;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
					components.Dispose();
			}
			base.Dispose(disposing);
		}

		#endregion // Construction, Initialization, and disposal

		#region Message Handlers

		void OnGenerateButtonClick(object obj, EventArgs ea)
		{
			ProduceSketch();
			ShowSketch();
			WriteRegistry();
		}

		#endregion // Message Handlers

		#region Other Methods

		private void WriteRegistry()
		{
			RegistryKey regkey = Registry.CurrentUser.OpenSubKey(RegistryKey, true);
			if (regkey == null)
				regkey = Registry.CurrentUser.CreateSubKey(RegistryKey);
			regkey.SetValue(HtmlFilePath, m_sHtmlFileName);
			regkey.Close();
		}

		private void ProduceSketch()
		{
			XProgressDialog dlg = InitProgressDialog();
			ShowGeneratingPage();
			PerformRetrieval(dlg);
			CleanRetrievedXml(dlg);
			PerformTransformations(dlg);
			UpdateProgress(m_stringResMan.GetString("stidCompleted"), dlg);
			dlg.Close();
		}

		private XProgressDialog InitProgressDialog()
		{
			XProgressDialog dlg = new XProgressDialog();
			dlg.Owner = this.FindForm();
			dlg.m_ProgressBar.Minimum = 0;
			dlg.m_ProgressBar.Maximum = m_cPrompts + m_cTransforms + 1; // additional one is the clean XSLT
			dlg.Text = m_sDialogTitle;
			dlg.Show();
			return dlg;
		}
		private void ShowGeneratingPage()
		{
			// this doesn't work for some reason...
			m_sHtmlFileName = Path.Combine(DirectoryFinder.FWInstallDirectory, GeneratingDocument);
			ShowSketch();
		}

		public FwSqlXmlRetriever GetRetriever()
		{
			FdoCache cache = Cache;
			return new FwSqlXmlRetriever(cache.ServerName, cache.DatabaseName, FwSqlXmlRetriever.PathToWordworksSchemas() + SketchXDR);
		}

		public void RetrieveItems(XmlNode parentNode, XProgressDialog dlg)
		{
			foreach (XmlNode rNode in parentNode.ChildNodes)
			{
				if (rNode.NodeType == XmlNodeType.Element)
				{
					string sPrompt = XmlUtils.GetOptionalAttributeValue(rNode, "progressPrompt");
					if (sPrompt != null)
						UpdateProgress(sPrompt, dlg);
					switch (rNode.Name)
					{
						case m_kWrapItems:
							string sWrapsItemElement = XmlUtils.GetManditoryAttributeValue(rNode, "wrappingElement");
							m_Retriever.BeginElement(sWrapsItemElement);
							RetrieveItems(rNode, dlg);
							m_Retriever.EndElement();
							break;

						case "wrappedItem":
							string sWrappedItemElement = XmlUtils.GetManditoryAttributeValue(rNode, "wrappingElement");
							string sWrappedItemXPath = XmlUtils.GetManditoryAttributeValue(rNode, "xpath");
							m_Retriever.InsertXPathQueryResults(sWrappedItemXPath, sWrappedItemElement);
							break;

						case "item":
							string sItemXPath = XmlUtils.GetManditoryAttributeValue(rNode, "xpath");
							m_Retriever.InsertXPathQueryResults(sItemXPath);
							break;
					}
				}
			}
		}

		public void PerformRetrieval(XProgressDialog dlg)
		{
			m_Retriever = GetRetriever();
			string sTopMostElement = XmlUtils.GetManditoryAttributeValue(m_retrieverNode, "beginElement");
			m_Retriever.BeginElement(sTopMostElement);
			RetrieveItems(m_retrieverNode, dlg);
			m_Retriever.EndElement();
		}

		/// <summary>
		/// <remarks>Used by unit testing</remarks>
		/// </summary>
		public void CreateRetriever()
		{
			m_Retriever = GetRetriever();
		}

		public void CleanRetrievedXml(XProgressDialog dlg)
		{
			UpdateProgress(m_mediator.StringTbl.GetString("Cleaning", "DocumentGeneration"), dlg); //m_stringResMan.GetString("stidCleaningRetrieval"), dlg);
			XmlDocument document= m_Retriever.DOMDocument;
			XslTransform transform= new XslTransform();
			transform.Load(Path.Combine(TransformPath, CleanerXSLT));
			FwTempFile tempClean = new FwTempFile(".xml");
			// REVIEW Randy: .NET 2003 requires an XmlResolver as a fourth argument.
			// I don't know what that is, but at least a null makes the compiler happy.
			transform.Transform(document, new XsltArgumentList(), tempClean.Writer, null);
			m_sCleanedFile = tempClean.CloseAndGetPath();
		}

		private void PerformTransformations(XProgressDialog dlg)
		{
			string sLastFile = m_sCleanedFile;
			foreach (XmlNode rNode in m_transformsNode.ChildNodes)
				sLastFile = ApplyTransform(sLastFile, rNode, dlg);
			m_sHtmlFileName = sLastFile;
		}

		private string ApplyTransform(string sInputFile, XmlNode node, XProgressDialog dlg)
		{
			string sProgressPrompt = XmlUtils.GetManditoryAttributeValue(node, "progressPrompt");
			UpdateProgress(sProgressPrompt, dlg);
			string sOutputFile = CreateOutputFile(node);
			string sXslt = XmlUtils.GetManditoryAttributeValue(node, "file");

			XSLParameter[] parameterList = CreateParameterList(node);

			TransformFileToFile(Path.Combine(TransformPath, sXslt), parameterList, sInputFile, sOutputFile); 
			return sOutputFile;
		}

		private XSLParameter[] CreateParameterList(XmlNode node)
		{
			XSLParameter[] parameterList = null;
			foreach (XmlNode rNode in node.ChildNodes)
			{
				if (rNode.Name == "xsltParameters")
				{
					int cParams = CountParams(rNode);
					if (cParams > 0)
					{
						parameterList = GetParameters(cParams, rNode);
					}
				}
			}
			return parameterList;
		}

		private XSLParameter[] GetParameters(int cParams, XmlNode rNode)
		{
			XSLParameter[] parameterList = new XSLParameter[cParams];
			int i = 0;
			foreach (XmlNode rParamNode in rNode.ChildNodes)
			{
				if (rParamNode.Name == "param")
				{
					string sName = XmlUtils.GetManditoryAttributeValue(rParamNode, "name");
					string sValue = XmlUtils.GetManditoryAttributeValue(rParamNode, "value");
					if (sValue == "TransformDirectory")
					{
						sValue = TransformPath;
					}
					parameterList[i] = new XSLParameter(sName, sValue);
					i++;
				}
			}
			return parameterList;
		}

		private int CountParams(XmlNode node)
		{
			int cParams = 0;
			foreach (XmlNode rNode in node.ChildNodes)
			{
				if (rNode.Name == "param")
					cParams++;
			}
			return cParams;
		}

		private string CreateOutputFile(XmlNode node)
		{
			string sExtension = XmlUtils.GetManditoryAttributeValue(node, "ext");
			FwTempFile tmpFile = new FwTempFile(sExtension);
			string sOutputFile = tmpFile.CloseAndGetPath();
			return sOutputFile;
		}

		private void UpdateProgress(string sMessage, XProgressDialog dlg)
		{
			dlg.m_LabelWorkingOn.Text = sMessage;
			dlg.m_ProgressBar.PerformStep();
			dlg.Refresh();
		}

		/// <summary>
		/// <remarks>Should be part of some class we can inherit from</remarks>
		/// </summary>
		private void TransformFileToFile(string sTransformName, XSLParameter[] parameterList, string sInputPath, string sOutputName)
		{
			DateTime start = DateTime.Now;
			Debug.WriteLine("\tStarting at: " + start.TimeOfDay.ToString());
#if false
			TextWriter writer = null;
			try
			{
				XslTransform transformer = new XslTransform();
				transformer.Load(Path.Combine(TransformPath, sTransformName));
				XsltArgumentList args = new XsltArgumentList();
				if (parameterList != null)
				{
					foreach(XSLParameter rParam in parameterList)
						args.AddParam(rParam.Name, "", rParam.Value);
				}
				writer = File.CreateText(sOutputName);
				XmlDocument inputDOM = new XmlDocument();
				inputDOM.Load(sInputPath);
				transformer.Transform(inputDOM, args, writer, null);
			}
			finally
			{
				if (writer != null)
					writer.Close();
			}
#else
			MSXML2.XSLTemplate40Class xslt = new MSXML2.XSLTemplate40Class();
			MSXML2.FreeThreadedDOMDocument40Class xslDoc = new
				MSXML2.FreeThreadedDOMDocument40Class();
			MSXML2.DOMDocument40Class xmlDoc = new MSXML2.DOMDocument40Class();
			MSXML2.IXSLProcessor xslProc;
 
			xslDoc.async = false;
			xslDoc.load(Path.Combine(TransformPath, sTransformName));
			xslt.stylesheet = xslDoc;
			xmlDoc.async = false;
			xmlDoc.load(sInputPath);
			xslProc = xslt.createProcessor();
			xslProc.input = xmlDoc;
			AddParameters(parameterList, xslProc);
			xslProc.transform();
			StreamWriter sr = File.CreateText(sOutputName);
			sr.Write(xslProc.output);
			sr.Close();
#endif
			DateTime end = DateTime.Now;
			Debug.WriteLine("\tEnding at: " + end.TimeOfDay.ToString());
			System.TimeSpan diff = end.Subtract(start);
			Debug.WriteLine("\t" + diff.ToString() + " " + sOutputName);
		}

		private void AddParameters(XSLParameter[] parameterList, MSXML2.IXSLProcessor xslProc)
		{
			if (parameterList != null)
			{
				foreach(XSLParameter rParam in parameterList)
				{
					xslProc.addParameter(rParam.Name, rParam.Value, "");
				}
			}
		}

		#endregion // Other Methods

		#region IxCoreColleague implementation

		/// <summary>
		/// Initialize.
		/// </summary>
		/// <param name="mediator"></param>
		/// <param name="configurationParameters"></param>
		public void Init(Mediator mediator, XmlNode configurationParameters)
		{
			m_mediator = mediator;
			m_configurationParameters = configurationParameters;
			mediator.AddColleague(this);
			ReadParameters();
			DetermineNumberOfPrompts();
			DetermineNumberOfTransforms();
			ReadRegistry();
			ShowSketch();
		}

		/// <summary>
		/// Return an array of all of the objects which should
		/// 1) be queried when looking for someone to deliver a message to
		/// 2) be potential recipients of a broadcast
		/// </summary>
		/// <returns>An array of IxCoreColleague objects. Here it is just 'this'.</returns>
		public IxCoreColleague[] GetMessageTargets()
		{
			return new IxCoreColleague[]{this};
		}

		#endregion // IxCoreColleague implementation

		#region IxCoreContentControl implementation

		/// <summary>
		/// From IxCoreContentControl
		/// </summary>
		/// <returns>true if ok to go away</returns>
		public bool PrepareToGoAway()
		{
			return true;
		}

		#endregion // IxCoreContentControl implementation

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(SqlXmlViewer));
			this.m_GenerateBtn = new System.Windows.Forms.Button();
			this.m_panelTop = new System.Windows.Forms.Panel();
			this.m_panelBottom = new System.Windows.Forms.Panel();
			this.m_panelTop.SuspendLayout();
			this.SuspendLayout();
			// 
			// m_GenerateBtn
			// 
			this.m_GenerateBtn.AccessibleDescription = ((string)(resources.GetObject("m_GenerateBtn.AccessibleDescription")));
			this.m_GenerateBtn.AccessibleName = ((string)(resources.GetObject("m_GenerateBtn.AccessibleName")));
			this.m_GenerateBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_GenerateBtn.Anchor")));
			this.m_GenerateBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_GenerateBtn.BackgroundImage")));
			this.m_GenerateBtn.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_GenerateBtn.Dock")));
			this.m_GenerateBtn.Enabled = ((bool)(resources.GetObject("m_GenerateBtn.Enabled")));
			this.m_GenerateBtn.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("m_GenerateBtn.FlatStyle")));
			this.m_GenerateBtn.Font = ((System.Drawing.Font)(resources.GetObject("m_GenerateBtn.Font")));
			this.m_GenerateBtn.Image = ((System.Drawing.Image)(resources.GetObject("m_GenerateBtn.Image")));
			this.m_GenerateBtn.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_GenerateBtn.ImageAlign")));
			this.m_GenerateBtn.ImageIndex = ((int)(resources.GetObject("m_GenerateBtn.ImageIndex")));
			this.m_GenerateBtn.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_GenerateBtn.ImeMode")));
			this.m_GenerateBtn.Location = ((System.Drawing.Point)(resources.GetObject("m_GenerateBtn.Location")));
			this.m_GenerateBtn.Name = "m_GenerateBtn";
			this.m_GenerateBtn.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("m_GenerateBtn.RightToLeft")));
			this.m_GenerateBtn.Size = ((System.Drawing.Size)(resources.GetObject("m_GenerateBtn.Size")));
			this.m_GenerateBtn.TabIndex = ((int)(resources.GetObject("m_GenerateBtn.TabIndex")));
			this.m_GenerateBtn.Text = resources.GetString("m_GenerateBtn.Text");
			this.m_GenerateBtn.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_GenerateBtn.TextAlign")));
			this.m_GenerateBtn.Visible = ((bool)(resources.GetObject("m_GenerateBtn.Visible")));
			this.m_GenerateBtn.Click += new System.EventHandler(this.OnGenerateButtonClick);
			// 
			// m_panelTop
			// 
			this.m_panelTop.AccessibleDescription = ((string)(resources.GetObject("m_panelTop.AccessibleDescription")));
			this.m_panelTop.AccessibleName = ((string)(resources.GetObject("m_panelTop.AccessibleName")));
			this.m_panelTop.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_panelTop.Anchor")));
			this.m_panelTop.AutoScroll = ((bool)(resources.GetObject("m_panelTop.AutoScroll")));
			this.m_panelTop.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("m_panelTop.AutoScrollMargin")));
			this.m_panelTop.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("m_panelTop.AutoScrollMinSize")));
			this.m_panelTop.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_panelTop.BackgroundImage")));
			this.m_panelTop.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.m_GenerateBtn});
			this.m_panelTop.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_panelTop.Dock")));
			this.m_panelTop.Enabled = ((bool)(resources.GetObject("m_panelTop.Enabled")));
			this.m_panelTop.Font = ((System.Drawing.Font)(resources.GetObject("m_panelTop.Font")));
			this.m_panelTop.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_panelTop.ImeMode")));
			this.m_panelTop.Location = ((System.Drawing.Point)(resources.GetObject("m_panelTop.Location")));
			this.m_panelTop.Name = "m_panelTop";
			this.m_panelTop.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("m_panelTop.RightToLeft")));
			this.m_panelTop.Size = ((System.Drawing.Size)(resources.GetObject("m_panelTop.Size")));
			this.m_panelTop.TabIndex = ((int)(resources.GetObject("m_panelTop.TabIndex")));
			this.m_panelTop.Text = resources.GetString("m_panelTop.Text");
			this.m_panelTop.Visible = ((bool)(resources.GetObject("m_panelTop.Visible")));
			// 
			// m_panelBottom
			// 
			this.m_panelBottom.AccessibleDescription = ((string)(resources.GetObject("m_panelBottom.AccessibleDescription")));
			this.m_panelBottom.AccessibleName = ((string)(resources.GetObject("m_panelBottom.AccessibleName")));
			this.m_panelBottom.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_panelBottom.Anchor")));
			this.m_panelBottom.AutoScroll = ((bool)(resources.GetObject("m_panelBottom.AutoScroll")));
			this.m_panelBottom.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("m_panelBottom.AutoScrollMargin")));
			this.m_panelBottom.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("m_panelBottom.AutoScrollMinSize")));
			this.m_panelBottom.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_panelBottom.BackgroundImage")));
			this.m_panelBottom.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_panelBottom.Dock")));
			this.m_panelBottom.Enabled = ((bool)(resources.GetObject("m_panelBottom.Enabled")));
			this.m_panelBottom.Font = ((System.Drawing.Font)(resources.GetObject("m_panelBottom.Font")));
			this.m_panelBottom.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_panelBottom.ImeMode")));
			this.m_panelBottom.Location = ((System.Drawing.Point)(resources.GetObject("m_panelBottom.Location")));
			this.m_panelBottom.Name = "m_panelBottom";
			this.m_panelBottom.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("m_panelBottom.RightToLeft")));
			this.m_panelBottom.Size = ((System.Drawing.Size)(resources.GetObject("m_panelBottom.Size")));
			this.m_panelBottom.TabIndex = ((int)(resources.GetObject("m_panelBottom.TabIndex")));
			this.m_panelBottom.Text = resources.GetString("m_panelBottom.Text");
			this.m_panelBottom.Visible = ((bool)(resources.GetObject("m_panelBottom.Visible")));
			// 
			// SqlXmlViewer
			// 
			this.AccessibleDescription = ((string)(resources.GetObject("$this.AccessibleDescription")));
			this.AccessibleName = ((string)(resources.GetObject("$this.AccessibleName")));
			this.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("$this.Anchor")));
			this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
			this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
			this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.m_panelBottom,
																		  this.m_panelTop});
			this.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("$this.Dock")));
			this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
			this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
			this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
			this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
			this.Name = "SqlXmlViewer";
			this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
			this.Size = ((System.Drawing.Size)(resources.GetObject("$this.Size")));
			this.TabIndex = ((int)(resources.GetObject("$this.TabIndex")));
			this.Visible = ((bool)(resources.GetObject("$this.Visible")));
			this.m_panelTop.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}

	/// <summary>
	/// A class that represents a parameter of an XSL stylesheet.
	/// </summary>
	internal class XSLParameter
	{
		/// <summary>
		/// Parameter name.
		/// </summary>
		private string m_name;
    
		/// <summary>
		/// Parameter value.
		/// </summary>
		private string m_value;

		public XSLParameter(string sName, string sValue)
		{
			m_name = sName;
			m_value = sValue;
		}

		public string Name
		{
			get { return m_name; }
			set { m_name = value; }
		}

		public string Value
		{
			get { return m_value; }
			set { m_value = value; }
		}
	}
}
