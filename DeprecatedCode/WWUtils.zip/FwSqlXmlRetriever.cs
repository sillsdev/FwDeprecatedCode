// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FwSqlXmlRetriever.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// this makes use of SQLXML to get XML out of the database.
//	if you are simply making a single query, this doesn't do that much for you.
//	Instead, it is good for combining multiple queries (both XPATH and SQL) into a single document.
//	Currently, you can only retrieve using a single annotated schema.
// </remarks>
// --------------------------------------------------------------------------------------------

using System;
using Microsoft.Data.SqlXml;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Xml;

namespace SIL.FieldWorks.Common.Utils
{
	/// <summary>
	/// Handles retrieving XML out of the sequel server database, 
	/// optionally transforming the XML into HTML.
	/// </summary>
	public class FwSqlXmlRetriever : System.Object
	{
		protected SqlXmlCommand m_command;
		protected String m_sOutputTransformPath;
		protected XmlDocument m_dom;
		protected System.Collections.Stack m_elementStack;

		#region construction
		/// <summary>
		/// construct a retriever
		/// </summary>
		/// <param name="server">e.g. "hatton1\SILFW"</param>
		/// <param name="database">e.g. "ZPU" </param>
		/// <param name="pathToXdrSchema">the path to the XDR schema describing the shape of the XML output 
		/// and its relationship to the sequel server database tables.</param>
		/// <param name="pathToTransform">the path to the XSLT transform which will be applied to the XML output.  
		/// This can be empty if no transform needed, just want raw xml</param>
		public FwSqlXmlRetriever(string server, string database, string pathToXdrSchema)//, string pathToTransform)
		{
			if(!File.Exists(pathToXdrSchema))
				throw new ArgumentException("A file wasn't where it was expected to be, at "+pathToXdrSchema+" .", "pathToXdrSchema");
		
//			if(pathToTransform!= null && pathToTransform.Length > 0) // ok if it's empty, else must exist
//				if(!File.Exists(pathToTransform))
//					throw new ArgumentException("A file wasn't where it was expected to be, at "+pathToTransform+" .", "pathToTransform");

			//m_sOutputTransformPath =pathToTransform;
			
			//ENHANCE: consider whether it is harmful to the leaving a connection open from this time until the time we are garbage collected.
			string sConnection = "Provider=SQLOLEDB;Server="+server+";database="+database+";user id=fwdeveloper;password=careful";

			//this is said to be faster (by ms performance article on web), but it wasn't conclusive
			//string sConnection = "provider=SQLXMLOLEDB.3.0;data provider=SQLOLEDB"
			//+";Server="+server+";database="+database+";user id=fwdeveloper;password=careful"
			
			
			//Use this someday:
			//+";Connection Timeout=5";

			m_command = new SqlXmlCommand(sConnection);
			m_command.SchemaPath = pathToXdrSchema;
	
			m_dom = new XmlDocument();
			m_elementStack = new System.Collections.Stack();
			m_elementStack.Push((XmlNode)m_dom);

		}

		#endregion

		#region properties

		/// <summary>
		/// the file system path to the annotated schemas used by WordWorks.
		/// </summary>
		/// <returns></returns>
		static public string PathToWordworksSchemas()
		{
			return DirectoryFinder.FWInstallDirectory + @"\WW\annotatedSchemas\";
		}

		/// <summary>
		/// the file system path to the XSLT transforms used by WordWorks.
		/// </summary>
		/// <returns></returns>
		static public string PathToWordworksTransforms()
		{
			return DirectoryFinder.FWInstallDirectory + @"\WW\transforms\";
		}


		/// <summary>
		/// the Dom that was built.
		/// </summary>
		public XmlDocument DOMDocument
		{
			get 
			{
				Debug.Assert(m_elementStack.Count== 1, "Looks like there is an open elements still");
				return m_dom;
			}
		}
		#endregion

		#region public methods
		public void BeginElement(string label)
		{
			XmlNode node = m_dom.CreateElement(label);
			/* if you get the message "This document already has a DocumentElement node." here,
			 * this may be because an XML document can only half a single root note.
			*/
			CurrentNode.AppendChild(node);
			m_elementStack.Push(node);
		}

		/// <summary>
		/// Close off the current XML element.
		/// </summary>
		public void EndElement()
		{
			//the top element on the stack is the actual DOM, so you can't pop that.
			Debug.Assert(m_elementStack.Count>1,"the call to EndElement was not matched by a BeginElement");
			m_elementStack.Pop();
		}

		/// <summary>
		/// Perform an XPATH query and put the results within the current element.
		/// </summary>
		/// <param name="query">e.g. WfiWordform[@Id='9735' | @Id='9736']]</param>
		public void InsertXPathQueryResults(string query, string wrappingElementLabel)
		{
			ExecuteXPathQuery(query, wrappingElementLabel);
		}

		/// <summary>
		/// Perform an XPATH query and put the results within the current element.
		/// </summary>
		/// <param name="query">e.g. WfiWordform[@Id='9735' or @Id='9736']</param>
		public void InsertXPathQueryResultsOneRoot(string query)
		{
			ExecuteXPathQueryOneRoot(query, null);
		}
		
		/// <summary>
		/// Perform an XPATH query and put the results within the current element which is guaranteed to return only one root element!
		/// </summary>
		/// <remarks> the constraint to have only one root element allows us to optimize.</remarks>
		/// <param name="query">e.g. WfiWordform[@Id='9735']</param>
		public void InsertXPathQueryResults(string query)
		{
			ExecuteXPathQuery(query, null);
		}		
		/// <summary>
		/// Perform a SQL query which will format the results as XML input them into the current element.
		/// </summary>
		/// <remarks>This is useful when calling a store procedure which produces XML.</remarks>
		/// <param name="query"></param>
		public void InsertSQLQueryResults(string query)
		{
			Debug.Assert(query.ToLower().IndexOf("readuncommitted") > -1
						|| query.ToLower().IndexOf("exec") > -1,
						"Looks like this query needs a (readuncommitted) flag");
			ExecuteSQLQuery(query,null);
		}
		/// <summary>
		/// Perform a SQL query which will format the results as XML input them into the current element.
		/// </summary>
		/// <remarks>This is useful when calling a store procedure which produces XML.</remarks>
		/// <param name="query"></param>
		public void InsertSQLQueryResults(string query, string wrappingElementLabel)
		{
			Debug.Assert(query.ToLower().IndexOf("readuncommitted") > -1
				|| query.ToLower().IndexOf("exec") > -1,
				"Looks like this query needs a (readuncommitted) flag");
			ExecuteSQLQuery(query, wrappingElementLabel);
		}
		
		/// <summary>
		/// Get the contents of the document as a string.
		/// </summary>
		/// <returns></returns>
		public string GetAsString()
		{
			Debug.Assert(m_elementStack.Count == 1, "Looks like some BeginElement() was not matched by a EndElement().");
			return m_dom.OuterXml;
		}


		#endregion

		#region protected methods
		protected XmlNode CurrentNode
		{
			get {return (XmlNode)m_elementStack.Peek();}
		}

		/// <summary>
		/// Insert an XML element at this point. 
		/// </summary>
		/// <remarks> the constraint to have only one root element allows us to optimize.</remarks>
		/// <param name="label">e.g. "FeatureStructures"</param>
		protected void ExecuteXPathQueryOneRoot(String xpathToObject, string wrappingElementLabel)
		{
			try
			{
				m_command.CommandType = SqlXmlCommandType.XPath;
				m_command.RootTag = wrappingElementLabel;//may be null

				//			m_command.RootTag = "ROOT";
				m_command.CommandText = xpathToObject;
				
				//TODO JohnH:find out how to do the equivalent of (readuncommitted) in these kinds of queries
				//TODO JohnH:find out how to set a timeout and handle it
			
				//m_command.XslPath = pathToTransform; // can be empty if no transform needed
				XmlReader reader = m_command.ExecuteXmlReader();
				if(!reader.HasValue)
				{
					reader.Close();
					return;  //query returned an empty result, which is fine.
				}

				reader.MoveToContent();//skip the declaration
				Debug.Assert(reader.NodeType == XmlNodeType.Element);

				/* reader.ReadNode() will choke if it finds
				 * that the contents were not wrapped in a single element, but that is pretty easy to get
				 * using SQLXML if the XPATH returns more than one object but you did not want to specify a root element.  
				 * Therefore, if your query might return more than one element, you need to specify a wrapping elements label.
				 */
				XmlNode node = m_dom.ReadNode(reader);

				/* if you get the message "This document already has a DocumentElement node."here,
				 * this may be because you have tried to do a second query without nesting both queries under an element.
				 * this is required because in XML document can only half a single root note.
				 * to overcome this, call BeganElement() before calling any queries.
				 */
				CurrentNode.AppendChild(node);
				reader.Close();
			}
			catch(Microsoft.Data.SqlXml.SqlXmlException error)
			{
				string message =GetSQLErrorString(error);
				Debug.Assert(false, "SqlXml had a problem with the query: " +message);
			}
			catch (Exception error)
			{
				//if you get a "multiple roots" error here, you need to start providing a wrapping element in InsertXPathQueryResults()
				Debug.Assert(false, error.Message);
			}
		}

		/// <summary>
		/// Insert 0 or more XML elements at this point.
		/// </summary>
		/// <remarks> the constraint to have only one root element allows us to optimize.</remarks>
		/// <param name="label">e.g. "FeatureStructures"</param>
		protected void ExecuteXPathQuery(String xpathToObject, string wrappingElementLabel)
		{
			try
			{
				m_command.CommandType = SqlXmlCommandType.XPath;
				m_command.RootTag= wrappingElementLabel;//may be null

				//			m_command.RootTag = "ROOT";
				m_command.CommandText = xpathToObject;
				
				//TODO JohnH:find out how to do the equivalent of (readuncommitted) in these kinds of queries
			
				//m_command.XslPath = pathToTransform; // can be empty if no transform needed
				Stream strm = m_command.ExecuteStream();

				XmlDocumentFragment fragment = m_dom.CreateDocumentFragment();
				StreamReader reader = new StreamReader(strm);
				fragment.InnerXml = reader.ReadToEnd();
				if(fragment.ChildNodes.Count > 0 && fragment.FirstChild.Name=="xml")
					fragment.RemoveChild(fragment.FirstChild);

				/* if you get the message "This document already has a DocumentElement node."here,
				 * this may be because you have tried to do a second query without nesting both queries under an element.
				 * this is required because in XML document can only half a single root note.
				 * to overcome this, call BeganElement() before calling any queries.
				 */
				CurrentNode.AppendChild(fragment);
			}
			catch(Microsoft.Data.SqlXml.SqlXmlException error)
			{
				string message =GetSQLErrorString(error);
				Debug.Assert(false, "SqlXml had a problem with the query: " +message);
			}
			catch (Exception error)
			{
				//if you get a "multiple roots" error here, you need to start providing a wrapping element in InsertXPathQueryResults()
				Debug.Assert(false, error.Message);
			}
		}

	
		protected void ExecuteSQLQuery(String query, string wrappingElementLabel)
		{
			try
			{
				if(query.ToLower().IndexOf("select")>=0 && (query.ToLower().IndexOf("for xml")<1))
					query+=" for xml auto";

				m_command.CommandType = SqlXmlCommandType.Sql;
				m_command.RootTag= wrappingElementLabel;//may be null

				m_command.CommandText = query;

				//TODO JohnH:find out how to do the equivalent of (readuncommitted) in these kinds of queries
			
				//m_command.XslPath = pathToTransform; // can be empty if no transform needed
				Stream strm = m_command.ExecuteStream();

				XmlDocumentFragment fragment = m_dom.CreateDocumentFragment();
				StreamReader reader = new StreamReader(strm);
				fragment.InnerXml = reader.ReadToEnd();
				if(fragment.ChildNodes.Count > 0 && fragment.FirstChild.Name=="xml")
					fragment.RemoveChild(fragment.FirstChild);

				/* if you get the message "This document already has a DocumentElement node."here,
				 * this may be because you have tried to do a second query without nesting both queries under an element.
				 * this is required because in XML document can only half a single root note.
				 * to overcome this, call BeganElement() before calling any queries.
				 */
				CurrentNode.AppendChild(fragment);
			}
			catch(Microsoft.Data.SqlXml.SqlXmlException error)
			{
				string message =GetSQLErrorString(error);
				Debug.Assert(false, "SqlXml had a problem with the query: " +message);
			}
			catch (Exception error)
			{
				//if you get a "multiple roots" error here, you need to start providing a wrapping element in InsertXPathQueryResults()
				Debug.Assert(false, error.Message);
			}
		}
		protected string GetSQLErrorString (Microsoft.Data.SqlXml.SqlXmlException error)
		{
			System.Text.StringBuilder builder = new System.  Text.StringBuilder();
			error.ErrorStream.Position=0;
			byte[] b = new Byte[error.ErrorStream.Length + 1];
			error.ErrorStream.Read(b, 0, (int)error.ErrorStream.Length );
			foreach(char c in b)
				builder.Append(c);

			return builder.ToString();
		}
		#endregion
	}
}


