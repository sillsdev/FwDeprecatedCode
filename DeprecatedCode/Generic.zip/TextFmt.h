/*--------------------------------------------------------------------*//*:Ignore this sentence.
Copyright (C) 1999, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TextFmt.h
Responsibility: Shon Katzenberger
Last reviewed:

	For formatting lines of text.

	Note: The line formatting code uses two coordinate systems: source coordinates and
	destination coordinates. All layout is done in source coordinates. Drawing and hit
	testing is done in destination coordinates. Source coordinates are indicated by the
	hungarian xs, ys, zs. Destination coordinates are indicated by the hungarian xd, yd, zd.
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef TextFmt_H
#define TextFmt_H 1

// Runs are at most this long.
const long kcchMaxRunFli = 128;


/*----------------------------------------------------------------------------------------------
	For formatting a line of text.
----------------------------------------------------------------------------------------------*/
class FmtLineBase
{
protected:
	enum { kcchMaxRunFli = 128 };

	enum RunType
	{
		krtNormal = 0,		// Normal characters - no break opportunities.
		krtBop,				// Ends with a break opportunity.
		krtBreak,			// Break at the end of this run.
		krtHardBreak,		// Carriage return at the end of this run.
		krtTab,				// One or more tabs (always a bop).
		krtObject,			// Always a bop.
	};

	struct Run
	{
		byte rt;			// Type of run.
		bool fTestBreak;	// If the last ch of this run is a fchTestBreak.
		int cch;			// Number of characters in the run.
		int cchDraw;		// Number of drawable characters in the run
		int cchTrim;		// Cch to trim off if this is the last run.
		int dysAscent;		// Descent for the run.
		int dysDescent;		// Ascent for the run.
		int dxs;			// Width of the run.
		int dxsTrim;		// Width to trim if this is the last run.
	};

	struct RunPos
	{
		int crun;		// Number of runs.
		int ichLim;		// Lim of chars on the line.
		int ichLimSel;	// Last selectable position.
		int dxsCur;		// Width through ichLim.
		int dxsLine;	// Width through ichLimSel.
		int dysAscent;	// Ascent.
		int dysDescent;	// Descent.
	};

	HDC m_hdc;			// The HDC to use for metrics.
	int m_dxsInch;		// Number of device pixels per inch.
	int m_dysInch;		// Number of device pixels per inch.

	bool m_fFormatted;	// Whether we're done formatting.
	int m_ichMin;		// The base ich for the line.
	int m_ichLim;		// Lim of characters to consider.
	int m_dxsLine;		// Target line width passed to Init.
	int m_dxsBreak;		// Where to break the line.

	int m_dxsIndent;	// Left indent of the line.
	int m_dxsJustify;	// Extra indent because of justification.

	LgParaRenderProps m_parp;	// Paragraph properties.
	LgCharRenderProps m_chrp;	// Current character properties.
	int m_ichMinChrp;		// Min of range of m_chrp.
	int m_ichLimChrp;		// Lim of range of m_chrp (bounded by m_ichLim).
	int m_dysAscentChrp;	// Ascent for m_chrp.
	int m_dysDescentChrp;	// Descent for m_chrp.

	RunPos m_rposCur;		// Current run position.
	RunPos m_rposBop;		// Run position of last break opportunity.

	Vector<Run> m_vrun;

	HFONT m_hfont;
	HFONT m_hfontOld;
	HDC m_hdcFont;
	LOGFONT m_lf;

	bool FInit(HDC hdc, int dxsInch, int dysInch, int ichMin, int ichLim, int dxsLine,
		bool fAll);
	void SaveRun(Run * prun);
	void GetSavedRun(int irun, Run * prun);
	void EnsureChrp(int ich);
	void GetRun(int ichBase, int dxmpBase, bool fTestBreak, Run * prun);
	void SkipIgnores(int ichBase, Run * prun);
//	void FullJustify(void);
	void UncacheFont(void);

	// REVIEW ShonK: Should we normalize round off errors?
	int DxsFromDxmp(int dxmp)
	{
		return MulDiv(dxmp, m_dxsInch, kdzmpInch);
	}

	int DysFromDymp(int dymp)
	{
		return MulDiv(dymp, m_dysInch, kdzmpInch);
	}

	int DxmpFromDxs(int dxs)
	{
		return MulDiv(dxs, kdzmpInch, m_dxsInch);
	}

	int DympFromDys(int dys)
	{
		return MulDiv(dys, kdzmpInch, m_dxsInch);
	}

	virtual int DympOffset(const LgCharRenderProps & chrp)
	{
		switch (chrp.ssv)
		{
		case kssvSuper:
			return chrp.dympOffset + chrp.dympHeight / 3;
		case kssvSub:
			return chrp.dympOffset - chrp.dympHeight / 3;
		}
		return chrp.dympOffset;
	}

protected:
	virtual void FetchChrp(int ich, LgCharRenderProps & chrp, int * pichMin = NULL,
		int * pichLim = NULL) = 0;
	virtual void FetchParp(int ich, LgParaRenderProps & parp, int * pichMin = NULL,
		int * pichLim = NULL) = 0;
	virtual int IchMac(void) = 0;
	virtual void FetchRgch(int ichMin, int ichLim, achar * prgch) = 0;
	virtual achar ChFetch(int ich) = 0;
	virtual bool FMinPara(int ich) = 0;
	virtual int IchPrev(int ich) = 0;
	virtual int IchNext(int ich) = 0;

	virtual void GetRectFromRgch(HDC hdc, Rect & rc, const achar * prgch, int cch);
	virtual void SetFont(HDC hdc, int dypInch, const LgCharRenderProps & chrp);

public:
	FmtLineBase(void);
	~FmtLineBase(void);

	void Clear(void);
	void FormatLine(HDC hdc, int dxsInch, int dysInch, int ichMin, int ichLim, int dxsLine,
		bool fUseAll = false);
	void DrawLine(HDC hdc, const Rect & rcdClip, const Rect & rcs, const Rect & rcd);
	int IchFromXd(HDC hdc, int xd, const Rect & rcs, const Rect & rcd, bool fClosest);
	int XdFromIch(HDC hdc, int ich, const Rect & rcs, const Rect & rcd);

	int IchMin(void)
		{ return m_ichMin; }
	int IchLim(void)
		{ return m_rposCur.ichLim; }
	int IchLimSel(void)
		{ return m_rposCur.ichLimSel; }
	int DysAscent(void)
		{ return m_rposCur.dysAscent; }
	int DysDescent(void)
		{ return m_rposCur.dysDescent; }
};

#endif // !TextFmt_H

