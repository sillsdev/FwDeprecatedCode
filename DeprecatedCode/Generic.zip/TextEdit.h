/*--------------------------------------------------------------------*//*:Ignore this sentence.
Copyright (C) 1999, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TextEdit.h
Responsibility: Shon Katzenberger
Last reviewed:

	Implements text editing.
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef TextEdit_H
#define TextEdit_H 1


class RichTextDoc;
class ByteString;


enum
{
	kfdocNil    = 0x0000,
	kfdocUpdate = 0x0001, // Update associated views.
	kfdocInval  = 0x0002, // Invalidate associated views.
};


typedef achar rchar;

const rchar kchBackSpace = 0x08;
const rchar kchLineFeed = 0x0A;
const rchar kchReturn = 0x0D;
const rchar kchSpace = 0x20;

const int kvkLeft = VK_LEFT;
const int kvkRight = VK_RIGHT;
const int kvkUp = VK_UP;
const int kvkDown = VK_DOWN;
const int kvkHome = VK_HOME;
const int kvkEnd = VK_END;
const int kvkPageUp = VK_PRIOR;
const int kvkPageDown = VK_NEXT;
const int kvkBackSpace = VK_BACK;
const int kvkDelete = VK_DELETE;
const int kvkReturn = VK_RETURN;

// No Input, No CHange.
//const int knNinch = 0x80000000;
// A range has two or more different values for a particular setting.
//const int knConflicting = knNinch + 1;


/*----------------------------------------------------------------------------------------------
	Character type flags.
	TODO ShonK: Reconcile with writing system stuff.
----------------------------------------------------------------------------------------------*/
enum CharType
{
	kfchNil =			0x0000,

	// Can overhang the end of a line and doesn't need to be draw.
	kfchWhiteOverhang =	0x0001,

	// Should break a line.
	kfchBreak =			0x0002,

	// May break a line.
	kfchMayBreak =		0x0004,

	// Should be totally ignored (and not draw).
	kfchIgnore = 		0x0008,

	// Some sort of control character.
	kfchControl =		0x0010,

	// A tab character.
	kfchTab = 			0x0020,

	// Characters that can break if not followed by certain punctuation.
	kfchTestBreak = 	0x0040,

	// The punctuation characters that we can't break before.
	kfchNoBreakBefore = 0x0080,

	// These are for delimiting "words" when text is double-clicked on or the
	// control-arrow keys are used. There are four categories:
	//
	// A - Non Japanese breaking characters and ignore characters.
	// B - Remaining non-Japanese characters.
	// C - Japanese period, comma, etc
	// D - Other Japanese characters
	//
	// To find the next "word", skip BA or DC (left to right).
	// To find the previouse "word", skip AB or CD (right to left).
	kfchWordEnd =		0x0100,
	kfchWordBody = 		0x0200,
	kfchWordEndJ =		0x0400,
	kfchWordBodyJ =		0x0800,
};

uint GrfchFromCh(achar ch);

void ApplyChrpTextPropGroup(LgCharRenderProps & chrp, const byte * prgb, int cb);
void MergeNinchChrp(const LgCharRenderProps & chrpSrc, LgCharRenderProps & chrpDst);
void ApplyParpTextPropGroup(LgParaRenderProps & parp, const byte * prgb, int cb);

/*----------------------------------------------------------------------------------------------
	Get the variation from the given value.
----------------------------------------------------------------------------------------------*/
inline int GetTextPropVar(int nVal)
{
	return nVal & ((1 << kcbitTextPropVar) - 1);
}


/*----------------------------------------------------------------------------------------------
	Get the value portion.
----------------------------------------------------------------------------------------------*/
inline int GetTextPropVal(int nVal)
{
	return nVal >> kcbitTextPropVar;
}


/*----------------------------------------------------------------------------------------------
	Used to hold a byte string.
----------------------------------------------------------------------------------------------*/
class ByteString
{
protected:
	uint m_uHash;
	ByteString * m_pbstNext;
	int m_cb;

	friend class ByteStrHolder;

	ByteString(void)
	{
	}
	~ByteString(void)
	{
	}

public:
	const byte * Prgb(void)
	{
		return (byte *)(this + 1);
	}
	int Size(void)
	{
		// High bit is used for marking and freeing.
		return m_cb & 0x7FFFFFFF;
	}
	void Mark(void)
	{
		m_cb |= 0x80000000;
	}
};


/*----------------------------------------------------------------------------------------------
	Used to hold common byte strings such as style names. Each RichTextDoc has one of these.
	Hungarian: bsh.
----------------------------------------------------------------------------------------------*/
class ByteStrHolder
{
public:
	ByteStrHolder(void);
	~ByteStrHolder(void);

	ByteString * GetByteStr(const void * pv, int cb);

	// Used to free unused byte strings. First call ClearMarks(), then call Mark() on
	// each byte string still in use, then call FreeUnmarked().
	void ClearMarks(void);
	void FreeUnmarked(void);

protected:
	friend class ByteString;

	// The hash buckets.
	ByteString ** m_prgpbstHash;

	// m_cpbstHash is the number of buckets.
	int m_cpbstHash;

	// Total number of entries.
	int m_cpbst;

	bool Find(const void * pv, int cb, uint uHash, ByteString ** ppbst);
	void Add(ByteString * pbst);
	void Rehash(void);
};


/*----------------------------------------------------------------------------------------------
	A TxtPropMap tracks locations within a DataStream and associates data with each location.
	Hungarian: tpm.
----------------------------------------------------------------------------------------------*/
class TxtPropMap : public GenRefObj
{
public:
	TxtPropMap(bool fTrackPos = false)
	{
		m_fTrackPos = fTrackPos;
	}

	ByteString * FetchStr(int ich, int * pichMin, int * pichLim);
	void SetStr(int ichMin, int ichLim, ByteString * pbst);

	void MarkAll(void);
	bool Edit(int ichMin, int ichLim, int cchIns);

protected:
	struct Entry
	{
		int m_ich;
		ByteString * m_pbst;
	};
	Vector<Entry> m_vent;

	// For deferred updates. Set m_dich to 0 to signal up to date status.
	int m_ientInval;
	int m_dich;

	// Whether this tracks character positions or character ranges.
	bool m_fTrackPos;

	int FindEntry(int ich);
	void Validate(void);
	int GetIch(int ient)
	{
		Assert((uint)ient < (uint)m_vent.Size());
		return ient >= m_ientInval ? m_vent[ient].m_ich + m_dich : m_vent[ient].m_ich;
	}
	ByteString * GetBst(int ient)
	{
		Assert(-1 <= ient && ient < m_vent.Size());
		return ient < 0 ? NULL : m_vent[ient].m_pbst;
	}
};

typedef GenSmartPtr<TxtPropMap> TxtPropMapPtr;


/*----------------------------------------------------------------------------------------------
	For receiving edit notifications.
	Hungarian: tes
----------------------------------------------------------------------------------------------*/
class TextEditSink : public LLBase<TextEditSink>
{
public:
	TextEditSink(void) : LLBase<TextEditSink>(NULL)
	{
		m_fNotified = false;
	}

	virtual void Edit(RichTextDoc * prtd, int ichMin, int ichLim, int cchIns, uint grfdoc) = 0;
	virtual void Attach(void)
	{
	}
	virtual void Close(void)
	{
		Link(NULL);
	}

protected:
	bool m_fNotified;

	friend class RichTextDoc;
};


/*----------------------------------------------------------------------------------------------
	A RichTextDoc contains formatted text.
	Hungarian: rtd.
----------------------------------------------------------------------------------------------*/
class RichTextDoc : public GenRefObj
{
public:
	static void Create(RichTextDoc ** pprtd);

	// Get the total number of characters.
	int IchMac(void);

	// Return the indicated character.
	rchar ChFetch(int ich)
	{
		AssertObj(this);
		Assert((uint)ich < (uint)IchMac());

		if (ich < m_ichMinCache || ich >= m_ichLimCache)
			CacheRange(ich, ich + 1);

		return m_rgchCache[ich - m_ichMinCache];
	}

	// Get a range of characters.
	void FetchRgch(int ichMin, int ichLim, rchar * prgch);

	// Find bounds of paragraphs, etc.
	void GetParaBounds(int * pichMin, int * pichLim, bool fExpand);
	bool FMinPara(int ich);
	int IchMinPara(int ich);
	int IchLimPara(int ich);
	int IchPrev(int ich);
	int IchNext(int ich);

	// Replace characters.
	void Replace(int ichMin, int ichLim, const rchar * prgch, int cchIns,
		uint grfdoc = kfdocUpdate);

	// Fetch properties.
	ByteString * FetchCharProps(int ich, int * pichMin = NULL, int * pichLim = NULL);
	ByteString * FetchParaProps(int ich, int * pichMin = NULL, int * pichLim = NULL);
	ByteString * FetchStrProp(int spt, int ich,
		int * pichMin = NULL, int * pichLim = NULL);

	// Set properties.
	void SetCharProps(int ichMin, int ichLim, const void * pv, int cb,
		uint grfdoc = kfdocUpdate);
	void SetCharStrProp(int spt, int ichMin, int ichLim, const void * pv, int cb,
		uint grfdoc = kfdocUpdate);
	void SetParaProps(int ichMin, int ichLim, const void * pv, int cb,
		int * pichMin = NULL, int * pichLim = NULL, bool fExpand = true,
		uint grfdoc = kfdocUpdate);
	void SetParaStrProp(int spt, int ichMin, int ichLim, const void * pv, int cb,
		int * pichMin = NULL, int * pichLim = NULL, bool fExpand = true,
		uint grfdoc = kfdocUpdate);

	// Setting an individual property across a range.
	void ApplyCharProp(int ichMin, int ichLim, int scp, int nVal1, int nVal2 = knNinch,
		bool fDel = false, uint grfdoc = kfdocUpdate);
	void ApplyParaProp(int ichMin, int ichLim, int scp, int nVal1, int nVal2 = knNinch,
		bool fDel = false, uint grfdoc = kfdocUpdate);
	void ApplyCharProps(int ichMin, int ichLim, const ScalarPropDelta * prgspd, int cspd,
		uint grfdoc = kfdocUpdate);
	void ApplyParaProps(int ichMin, int ichLim, const ScalarPropDelta * prgspd, int cspd,
		uint grfdoc = kfdocUpdate);

	// Undo management.
	void SuspendUndo(void);
	void ResumeUndo(void);
	void SetUndo(int ich1, int ich2, int ccpIns);
	void CancelUndo(void);
	void CommitUndo(void);
	void BumpCombineUndo(void);

	// Notification registration.
	void RegisterSink(TextEditSink * ptes);
	void BroadCastInval(uint grfdoc);

#if 0
	bool FReplaceFlo(PFLO pflo, bool fCopy, long cp, long ccpDel,
		short osk = koskCur, ulong grfdoc = fdocUpdate);
	bool FReplaceBsf(PBSF pbsfSrc, long cpSrc, long ccpSrc,
		long cpDst, long ccpDel, ulong grfdoc = fdocUpdate);
	bool FReplaceTxtb(PTXTB ptxtbSrc, long cpSrc, long ccpSrc,
		long cpDst, long ccpDel, ulong grfdoc = fdocUpdate);
	bool FReplaceRgch(void *prgch, long ccpIns, long cp, long ccpDel,
		PCHP pchp, PPAP ppap = pvNil, ulong grfdoc = fdocUpdate);
	bool FReplaceFlo(PFLO pflo, bool fCopy, long cp, long ccpDel,
		PCHP pchp, PPAP ppap = pvNil, short osk = koskCur,
		ulong grfdoc = fdocUpdate);
	bool FReplaceBsf(PBSF pbsfSrc, long cpSrc, long ccpSrc,
		long cpDst, long ccpDel,
		PCHP pchp, PPAP ppap = pvNil, ulong grfdoc = fdocUpdate);
	bool FReplaceTxtb(PTXTB ptxtbSrc, long cpSrc, long ccpSrc,
		long cpDst, long ccpDel,
		PCHP pchp, PPAP ppap = pvNil, ulong grfdoc = fdocUpdate);
	bool FReplaceTxrd(PTXRD ptxrd, long cpSrc, long ccpSrc,
		long cpDst, long ccpDel, ulong grfdoc = fdocUpdate);

	bool FFetchObject(long cpMin, long *pcp, void **ppv = pvNil,
		long *pcb = pvNil);
	bool FInsertObject(void *pv, long cb, long cp, long ccpDel,
		PCHP pchp = pvNil, ulong grfdoc = fdocUpdate);
	bool FApplyObjectProps(void *pv, long cb, long cp,
		ulong grfdoc = fdocUpdate);

	bool FGetObjectRc(long cp, PGNV pgnv, PCHP pchp, RC *prc,
		bool fVertical);
	bool FDrawObject(long cp, PGNV pgnv, long xp, long yp,
		PCHP pchp, RC *prcClip, bool fVertical);

	bool FGetFni(FNI *pfni);
	bool FGetFniSave(FNI *pfni);
	bool FSaveToFni(FNI *pfni, bool fSetFni);
	bool FSaveToChunk(PCFL pcfl, CKI *pcki,
		bool fRedirectText = fFalse);
#endif

protected:
	enum { kcchMaxCache = 512 };
	rchar m_rgchCache[kcchMaxCache];
	int m_ichMinCache;
	int m_ichLimCache;

	// These track the amount changed during an edit operation.
	// m_ichLimEdit is the lim before the edit happened.
	int m_ichMinEdit;
	int m_ichLimEdit;
	int m_dichEdit;

	ByteStrHolder m_bsh;
	DataStreamPtr m_qdast;
	TxtPropMapPtr m_qtpmChar;
	TxtPropMapPtr m_qtpmPara;

	struct TxtPropMapInfo
	{
		int m_spt;
		bool m_fPara;
		TxtPropMapPtr m_qtpm;
	};

	// These are sorted by spt.
	Vector<TxtPropMapInfo> m_vtpmi;

	// The linked list of edit sinks.
	TextEditSink * m_ptesFirst;

	void Init(void);
	void AddEdit(int ichMin, int ichLim, int cchIns);
	void CacheRange(int ichMin, int ichLim);
	void InvalCache(int ichMin, int ichLim, int cchIns);
	void AdjustMaps(int ichMin, int ichLim, int cchIns);
	ByteString * FetchStr(TxtPropMap * ptpm, int ich, int * pichMin, int * pichLim);
	TxtPropMap * GetTxtPropMap(int spt, bool fCreate = false);
	void ApplyScalarPropCore(TxtPropMap * ptpm, int ichMin, int ichLim, int scp,
		int nVal1, int nVal2, bool fDel, uint grfdoc);
	void ApplyScalarPropsCore(TxtPropMap * ptpm, int ichMin, int ichLim,
		const ScalarPropDelta * prgspd, int cspd, uint grfdoc);
};

typedef GenSmartPtr<RichTextDoc> RichTextDocPtr;

#endif // !TextEdit_H

