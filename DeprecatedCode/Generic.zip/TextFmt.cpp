/*--------------------------------------------------------------------*//*:Ignore this sentence.
Copyright (C) 1999, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TextFmt.cpp
Responsibility: Shon Katzenberger
Last reviewed:

-------------------------------------------------------------------------------*//*:End Ignore*/
#include "Main.h"
#pragma hdrstop

#include "Vector_i.cpp"

#undef THIS_FILE
DEFINE_THIS_FILE


/*----------------------------------------------------------------------------------------------
	Constructor for the FmtLineBase.
----------------------------------------------------------------------------------------------*/
FmtLineBase::FmtLineBase(void)
{
	m_hdc = NULL;
	m_fFormatted = false;
	m_ichMinChrp = 0;
	m_ichLimChrp = 0;
	m_hfont = NULL;
	m_hfontOld = NULL;
	m_hdcFont = NULL;
}


/*----------------------------------------------------------------------------------------------
	Destructor for the FmtLineBase.
----------------------------------------------------------------------------------------------*/
FmtLineBase::~FmtLineBase(void)
{
	Clear();
}


/*----------------------------------------------------------------------------------------------
	The formatting info is invalid.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::Clear(void)
{
	m_hdc = NULL;
	m_fFormatted = false;
	m_vrun.Clear();
	m_ichMinChrp = 0;
	m_ichLimChrp = 0;
	UncacheFont();
}


/*----------------------------------------------------------------------------------------------
	Initialize the FmtLineBase for formatting a line. Returns true if the FmtLineBase already
	contains the formatted line. Returns false if the line needs to be formatted.
----------------------------------------------------------------------------------------------*/
bool FmtLineBase::FInit(HDC hdc, int dxsInch, int dysInch, int ichMin, int ichLim, int dxsLine,
	bool fUseAll)
{
	Assert(hdc);
	Assert(dxsInch > 0);
	Assert(dysInch > 0);

	LgParaRenderProps parp;
	int ichLimParp;

	FetchParp(ichMin, parp, NULL, &ichLimParp);

	ichMin = Bound<int>(ichMin, 0, IchMac() - 1);
	ichLim = Bound<int>(ichLim, ichMin, ichLimParp);
	dxsLine = Bound<int>(dxsLine, 0, 0x01000000L);

	if (m_fFormatted && m_ichMin == ichMin && m_dxsLine == dxsLine &&
		m_hdc == hdc && m_dxsInch == dxsInch && m_dysInch == dysInch &&
		m_rposCur.ichLim <= ichLim && ichLim <= m_ichLim &&
		(!fUseAll || ichLim == m_rposCur.ichLim))
	{
		// Line is already formatted.
		return true;
	}

	m_fFormatted = false;
	m_hdc = hdc;
	m_dxsInch = dxsInch;
	m_dysInch = dysInch;

	m_parp = parp;
	m_ichMin = ichMin;
	m_ichLim = ichLim;
	m_dxsLine = dxsLine;
	m_dxsBreak = dxsLine - DxsFromDxmp(m_parp.dxmpRightIndent);

	// Apply any indenting.
	m_dxsIndent = 0;
	m_dxsJustify = 0;

	if (m_parp.dxmpFirstIndent > 0 && FMinPara(m_ichMin))
		m_dxsIndent = DxsFromDxmp(m_parp.dxmpLeadingIndent + m_parp.dxmpFirstIndent);
	else if (m_parp.dxmpFirstIndent < 0 && !FMinPara(m_ichMin))
		m_dxsIndent = DxsFromDxmp(m_parp.dxmpLeadingIndent - m_parp.dxmpFirstIndent);
	else
		m_dxsIndent = DxsFromDxmp(m_parp.dxmpLeadingIndent);

	if (m_dxsBreak < m_dxsIndent)
		m_dxsBreak = m_dxsIndent;

	ClearItems(&m_rposCur, 1);
	m_rposCur.ichLim = m_ichMin;
	m_rposCur.ichLimSel = m_ichMin;
	m_rposCur.dxsCur = m_dxsIndent;
	m_rposCur.dxsLine = m_dxsIndent;

	m_rposBop = m_rposCur;

	m_vrun.Clear();

	return false;
}


/*----------------------------------------------------------------------------------------------
	Format a line.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::FormatLine(HDC hdc, int dxsInch, int dysInch, int ichMin, int ichLim,
	int dxsLine, bool fUseAll)
{
	Run run;
	int dysTot;
	bool fTestBreak = false;

	if (FInit(hdc, dxsInch, dysInch, ichMin, ichLim, dxsLine, fUseAll))
	{
		// This line is already formatted.
		UncacheFont();
		return;
	}

	for (;;)
	{
		if (m_rposCur.ichLim >= m_ichLim)
		{
			// We're out of characters.
			goto LJustify;
		}

		GetRun(m_rposCur.ichLim, m_rposCur.dxsCur, fTestBreak, &run);
		fTestBreak = run.fTestBreak;
		if (!fUseAll && run.dxs + m_rposCur.dxsCur > m_dxsBreak)
		{
			// We're past the end of the line.
			break;
		}

		SkipIgnores(m_rposCur.ichLim, &run);
		SaveRun(&run);

		if (krtBreak == run.rt || krtHardBreak == run.rt)
		{
			// This forces a line break.
			goto LJustify;
		}
	}

	// This run takes us past the edge of the line.
	if (fUseAll || m_rposCur.ichLim <= m_ichMin)
	{
		// We have to use this run.
		SkipIgnores(m_rposCur.ichLim, &run);
		SaveRun(&run);
	}
	else
	{
		switch (run.rt)
		{
		case krtObject:
		case krtTab:
			// In these cases, we allow a break immediately before this run.
			break;

		default:
			if (m_rposBop.ichLim > m_ichMin)
			{
				// Revert to the previous Bop.
				if (m_vrun.Size() > m_rposBop.crun)
					m_vrun.Resize(m_rposBop.crun);
				m_rposCur = m_rposBop;
			}
			break;
		}
	}

LJustify:
	switch (m_parp.tal)
	{
	case ktalTrailing:	// TODO ShonK: switch for right-to-left?
	case ktalRight:
		m_dxsJustify = m_dxsBreak - m_rposCur.dxsLine;
		break;
	case ktalCenter:
		m_dxsJustify = (m_dxsBreak - m_rposCur.dxsLine) / 2;
		break;
	case ktalJustify:
		// TODO ShonK: implement: FullJustify();
		break;
	}

	// Apply line height adjustments.
	dysTot = MulDiv(m_rposCur.dysAscent + m_rposCur.dysDescent, m_parp.relLine,
		kdenTextPropRel);
	dysTot += DysFromDymp(m_parp.dympExtraLine);

	int dysBefore = 0;
	int dysAfter = 0;

	if (FMinPara(m_ichMin))
	{
		// Start of a paragraph.
		dysBefore = MulDiv(dysTot, m_parp.relBefore, kdenTextPropRel);
		dysBefore += DysFromDymp(m_parp.dympExtraBefore);
	}

	if (FMinPara(m_rposCur.ichLim) || m_rposCur.ichLim == IchMac())
	{
		// End of a paragraph.
		dysAfter = MulDiv(dysTot, m_parp.relAfter, kdenTextPropRel);
		dysAfter += DysFromDymp(m_parp.dympExtraAfter);
	}

	dysTot += dysBefore + dysAfter;
	m_rposCur.dysAscent += dysBefore;

	if (dysTot <= 0)
		dysTot = 1;

	if (m_rposCur.dysAscent < 0)
		m_rposCur.dysAscent = 0;
	m_rposCur.dysDescent = dysTot - m_rposCur.dysAscent;

	// We've formatted the line!
	m_fFormatted = true;

	UncacheFont();
}


/*----------------------------------------------------------------------------------------------
	Draw the line to the given HDC. Assumes the HDC has already been erased or prepped in
	whatever way is appropriate - just draws the stuff on top of whatever is currently there.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::DrawLine(HDC hdc, const Rect & rcClip, const Rect & rcs, const Rect & rcd)
{
	achar rgch[kcchMaxRunFli];
	int cch;
	int ich;
	int irun;
	Run run;
	LgCharRenderProps chrp;
	int xd, yd;
	int xs;
	int dydInch;
	SIZE dpt;

	if (!m_fFormatted)
	{
		AssertMsg(m_fFormatted, "FmtLineBase not formatted!");
		return;
	}

	xs = rcs.left + m_dxsIndent + m_dxsJustify;
	xd = rcs.MapXTo(xs, rcd);
	ich = m_ichMin;
	dydInch = MulDiv(m_dysInch, rcd.Height(), rcs.Height());

	if (m_parp.clrBack != kclrTransparent)
	{
		Rect rcdBack(0, 0, m_dxsLine, m_rposCur.dysAscent + m_rposCur.dysDescent);
		rcdBack.Map(rcs, rcd);

		::SetBkColor(hdc, m_parp.clrBack);
		::ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rcdBack, NULL, 0, NULL);
	}

	for (irun = 0; irun < m_rposCur.crun; irun++)
	{
		GetSavedRun(irun, &run);
		switch (run.rt)
		{
		case krtObject:
			// TODO ShonK: implement.
		case krtTab:
			// Don't draw anything.
			xs += run.dxs;
			xd = rcs.MapXTo(xs, rcd);
			break;

		default:
			// Normal characters to draw.
			FetchChrp(ich, chrp);

			cch = NMin(kcchMaxRunFli, run.cchDraw);
			FetchRgch(ich, ich + cch, rgch);

			SetFont(hdc, dydInch, chrp);

			if (chrp.clrBack == kclrTransparent)
				::SetBkMode(hdc, TRANSPARENT);
			else
			{
				::SetBkMode(hdc, OPAQUE);
				::SetBkColor(hdc, chrp.clrBack);
			}

			yd = rcs.MapYTo(m_rposCur.dysAscent - DysFromDymp(DympOffset(chrp)), rcd);
			::SetTextColor(hdc, chrp.clrFore);
			::TextOut(hdc, xd, yd, rgch, cch);
			if (rcd.Width() != rcs.Width())
			{
				::GetTextExtentPoint32(hdc, rgch, cch, &dpt);
				xd += dpt.cx;
			}
			else
				xd += run.dxs;
			xs += run.dxs;
			break;
		}

		ich += run.cch;
	}

	UncacheFont();
}


/*----------------------------------------------------------------------------------------------
	Get the ich on the current formatted line that is closest to dxd. If fClosest is false,
	this gets the character that dxd is over (or the first or last visible character if dxd is
	not in the bounds of the line). If fClosest is true, this finds the closest character
	boundary.
----------------------------------------------------------------------------------------------*/
int FmtLineBase::IchFromXd(HDC hdc, int xd, const Rect & rcs, const Rect & rcd, bool fClosest)
{
	int ichMin;
	Run run;
	int irun;
	int iv, ivMin, ivLim;
	int cch;
	achar rgch[kcchMaxRunFli];
	int xsCur;
	int xdCur;
	int xsNew;
	int xdNew;
	int dydInch;
	SIZE dpt, dpt2;
	LgCharRenderProps chrp;

	if (!m_fFormatted)
	{
		AssertMsg(false, "FmtLineBase not formatted!");
		return 0;
	}

	xsCur = m_dxsIndent + m_dxsJustify;
	xdCur = rcs.MapXTo(xsCur, rcd);
	if (xd <= xdCur)
		return m_ichMin;

	dydInch = MulDiv(m_dysInch, rcd.Height(), rcs.Height());

	ichMin = m_ichMin;
	for (irun = 0; ; irun++)
	{
		if (irun >= m_rposCur.crun)
		{
			UncacheFont();
			if (fClosest)
				return m_rposCur.ichLimSel;
			return Max(m_ichMin, IchPrev(m_rposCur.ichLimSel));
		}

		GetSavedRun(irun, &run);
		switch (run.rt)
		{
		case krtObject:
			// TODO ShonK: implement.
		case krtTab:
			// Set the position according to source coordinates.
			xsNew = xsCur + run.dxs;
			xdNew = rcs.MapXTo(xsNew, rcd);
			break;

		default:
			// Normal characters to draw.
			if (rcd.Width() == rcs.Width())
			{
				xsNew = xsCur + run.dxs;
				xdNew = xdCur + run.dxs;
			}
			else
			{
				FetchChrp(ichMin, chrp);
				cch = NMin(kcchMaxRunFli, run.cchDraw);
				FetchRgch(ichMin, ichMin + cch, rgch);
				SetFont(hdc, dydInch, chrp);
				::GetTextExtentPoint32(hdc, rgch, cch, &dpt);
				xdNew = xdCur + dpt.cx;
				xsNew = xsCur + run.dxs;
			}
			break;
		}

		if (xd < xdNew)
			break;
		xsCur = xsNew;
		xdCur = xdNew;
		ichMin += run.cch;
	}

	// It's in this run.
	cch = NMin(run.cchDraw, run.cch - run.cchTrim);
	if (cch <= 1)
	{
		UncacheFont();

		// At most one visible character in the run - this is more than an optimization - it
		// also handles tab and object runs, while the binary search code below doesn't.
		if (!fClosest || xd <= (xdCur + xdNew) / 2)
			return ichMin;
		return ichMin + run.cch - run.cchTrim;
	}

	AssertMsg(run.rt != krtObject && run.rt != krtTab, "bad tab or object run");

	// Find the last character that fits. Binary search.
	FetchChrp(ichMin, chrp);
	SetFont(hdc, dydInch, chrp);

	cch = NMin(kcchMaxRunFli, cch);
	FetchRgch(ichMin, ichMin + cch, rgch);

	xd -= xdCur;
	for (ivMin = 1, ivLim = cch; ivMin < ivLim; )
	{
		iv = (ivMin + ivLim) / 2;
		::GetTextExtentPoint32(hdc, rgch, iv, &dpt);
		if (dpt.cx <= xd)
			ivMin = iv + 1;
		else
			ivLim = iv;
	}

	ichMin += ivMin - 1;
	if (!fClosest)
	{
		UncacheFont();
		return ichMin;
	}

	::GetTextExtentPoint32(hdc, rgch, ivMin - 1, &dpt);
	::GetTextExtentPoint32(hdc, rgch, ivMin, &dpt2);

	UncacheFont();

	if (Abs(xd - dpt.cx) <= Abs(xd - dpt2.cx))
		return ichMin;

	return IchNext(ichMin);
}


/*----------------------------------------------------------------------------------------------
	Gets the position of the character within the formatted line.
----------------------------------------------------------------------------------------------*/
int FmtLineBase::XdFromIch(HDC hdc, int ich, const Rect & rcs, const Rect & rcd)
{
	int ichMin;
	Run run;
	int irun;
	int cch;
	achar rgch[kcchMaxRunFli];
	int xsCur;
	int xdCur;
	int dydInch;
	SIZE dpt;
	LgCharRenderProps chrp;

	if (!m_fFormatted)
	{
		AssertMsg(false, "FmtLineBase not formatted!");
		return 0;
	}

	xsCur = m_dxsIndent + m_dxsJustify;
	xdCur = rcs.MapXTo(xsCur, rcd);
	if (ich <= m_ichMin)
		return xdCur;

	dydInch = MulDiv(m_dysInch, rcd.Height(), rcs.Height());

	ichMin = m_ichMin;
	for (irun = 0; ; irun++)
	{
		if (irun >= m_rposCur.crun || ich <= ichMin)
		{
			UncacheFont();
			return xdCur;
		}

		GetSavedRun(irun, &run);
		switch (run.rt)
		{
		case krtObject:
			// TODO ShonK: implement.
		case krtTab:
			// Set the position according to source coordinates.
			xsCur += run.dxs;
			xdCur = rcs.MapXTo(xsCur, rcd);
			break;

		default:
			// Normal characters to draw.
			if (ichMin + run.cch <= ich && rcd.Width() == rcs.Width())
			{
				xsCur += run.dxs;
				xdCur += run.dxs;
			}
			else
			{
				FetchChrp(ichMin, chrp);
				cch = NMin(ich - ichMin, NMin(kcchMaxRunFli, run.cchDraw));
				FetchRgch(ichMin, ichMin + cch, rgch);
				SetFont(hdc, dydInch, chrp);
				::GetTextExtentPoint32(hdc, rgch, cch, &dpt);
				xdCur += dpt.cx;
				xsCur += run.dxs;
			}
			break;
		}

		ichMin += run.cch;
	}
}


/*----------------------------------------------------------------------------------------------
	Save the run.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::SaveRun(Run * prun)
{
	AssertPtr(prun);

	m_rposCur.crun++;
	m_rposCur.ichLim += prun->cch;
	m_rposCur.ichLimSel = m_rposCur.ichLim - prun->cchTrim;
	m_rposCur.dxsCur += prun->dxs;
	m_rposCur.dxsLine = m_rposCur.dxsCur - prun->dxsTrim;
	m_rposCur.dysAscent = Max(m_rposCur.dysAscent, prun->dysAscent);
	m_rposCur.dysDescent = Max(m_rposCur.dysDescent, prun->dysDescent);

	switch (prun->rt)
	{
	case krtBop:
	case krtObject:
	case krtTab:
		m_rposBop = m_rposCur;
		break;
	}

	m_vrun.Push(*prun);
}


/*----------------------------------------------------------------------------------------------
	Retrieve a run previously saved by a call to SaveRun.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::GetSavedRun(int irun, Run * prun)
{
	Assert((uint)irun < (uint)m_rposCur.crun);
	AssertPtr(prun);
	Assert(m_vrun.Size() == m_rposCur.crun);

	*prun = m_vrun[irun];

	if (irun < m_rposCur.crun - 1)
	{
		// Trim only applies to the last run.
		prun->cchTrim = 0;
		prun->dxsTrim = 0;
	}
	else
	{
		prun->cchDraw = NMin(prun->cchDraw, prun->cch - prun->cchTrim);
		prun->dxs -= prun->dxsTrim;
	}
}


/*----------------------------------------------------------------------------------------------
	Skip any trailing ignore characters. Just changes prun->cch and prun->cchTrim.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::SkipIgnores(int ichBase, Run * prun)
{
	AssertPtr(prun);

	int cch;
	int ich = ichBase + prun->cch;
	int ichLim = Min(m_ichLim, ichBase + 0xFF);

	Assert(ichBase <= ich && ich <= ichLim);
	while (ich < ichLim && (kfchIgnore & GrfchFromCh(ChFetch(ich))))
		ich++;

	if (prun->cch < (cch = ich - ichBase))
	{
		if (prun->cchTrim > 0)
			prun->cchTrim += cch - prun->cch;
		prun->cch = cch;
		prun->fTestBreak = false;
	}
}


/*----------------------------------------------------------------------------------------------
	Make sure m_chrp is the character properties for ich. Also, set the font in m_hdc and get
	the ascent and descent.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::EnsureChrp(int ich)
{
	Rect rc;
	bool fValid = m_ichMinChrp <= ich && ich < m_ichLimChrp;

	if (!fValid)
	{
		// Get the chrp.
		FetchChrp(ich, m_chrp, &m_ichMinChrp, &m_ichLimChrp);
	}

	// Set the font and get the vertical dimensions.
	SetFont(m_hdc, m_dysInch, m_chrp);

#ifdef TO_DO_IF_NEEDED // shonk: Win95 bug workaround
	// If we don't draw to the _pgnv before getting the metrics, the metrics
	// can be different than after we draw!
	achar ch = kchSpace;
	_pgnv->DrawRgch(&ch, 1, 0, 0);
#endif /*TO_DO_IF_NEEDED*/

	if (!fValid)
	{
		int dysOffset = DysFromDymp(DympOffset(m_chrp));
		GetRectFromRgch(m_hdc, rc, NULL, 0);
		m_dysAscentChrp = Max(0, -rc.top + dysOffset);
		m_dysDescentChrp = Max(0, rc.bottom - dysOffset);
	}
}


/*----------------------------------------------------------------------------------------------
	Get the next run of characters.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::GetRun(int ichBase, int dxsBase, bool fTestBreak, Run * prun)
{
	AssertPtr(prun);

	achar rgch[kcchMaxRunFli];
	ushort rggrfch[kcchMaxRunFli];
	achar ch;
	int cchLim;
	int cchBop;
	int dxsT;
	Rect rc;
	int iv, ivMin, ivLim;
	uint grfch, grfchPrev;

	EnsureChrp(ichBase);

	ClearItems(prun, 1);
	prun->dysAscent = m_dysAscentChrp;
	prun->dysDescent = m_dysDescentChrp;

	cchBop = 0;
	cchLim = NMin(NMin(m_ichLim, m_ichLimChrp) - ichBase, kcchMaxRunFli);

	grfch = fTestBreak ? kfchTestBreak : kfchNil;
	while (prun->cch < cchLim)
	{
		grfchPrev = grfch;
		ch = ChFetch(ichBase + prun->cch);
		grfch = GrfchFromCh(ch);

		if (/* kchObject == ch || */ grfch & (kfchIgnore | kfchTab | kfchBreak))
		{
			if (prun->cch > 0 || (grfch & kfchIgnore))
			{
				// End the run
				break;
			}

			AssertMsg(prun->cch == 0, "run should be empty");

#ifdef TO_DO_IF_NEEDED // TODO ShonK: implement objects.
			if (kchObject == ch)
			{
				// Return just the object (if it really is an object).
				if (!_FGetObjectRc(cpBase + prun->ccp, _pgnv,
						&_chp, &rc))
					{
					// treat as a normal character
					rgch[0] = ch;
					prun->ccp = 1;
					continue;
					}

				rc.Offset(0, _chp.dypOffset);
				Assert(!rc.FEmpty() && rc.xpRight >= 0,
					"bad rectangle for the object");

				prun->dxp = rc.xpRight;
				prun->ccp = prun->ccpDraw = 1;
				prun->dypAscent = LwMax(_dypAscentChp, -rc.ypTop);
				prun->dypDescent = LwMax(_dypDescentChp, rc.ypBottom);
				prun->rt = krtObject;
			}
			else
#endif /*TO_DO_IF_NEEDED*/
			if (grfch & kfchTab)
			{
				int dxmpBase = DxmpFromDxs(dxsBase);
				// TODO ShonK: implement a tab list.
				prun->dxs = DxsFromDxmp(
					(dxmpBase / m_parp.dxmpTabDef + 1) * m_parp.dxmpTabDef - dxmpBase);
				prun->cch = prun->cchDraw = 1;
				prun->rt = krtTab;
			}
			else
			{
				// This line must break after this character.
				Assert(grfch & kfchBreak);
				prun->cch = 1;
				prun->cchTrim = 1;
				prun->rt = krtHardBreak;
			}
			return;
		}

		if (grfch & kfchMayBreak)
			cchBop = prun->cch + 1;
		else if (grfchPrev & kfchTestBreak)
		{
			if (!(grfch & kfchNoBreakBefore))
			{
				// Can break after the previous character.
				cchBop = prun->cch;
			}
			else
			{
				// Propogate kfchTestBreak through this character.
				grfch |= kfchTestBreak;
			}
		}
		rggrfch[prun->cch] = (ushort)grfch;
		rgch[prun->cch++] = ch;
	}

	// We're out of characters or the cache is full - see if everything fits on the line.
	if (prun->cch == 0)
	{
		// Rare case but can happen (theoretically) if a run starts with an ignore character.
		prun->rt = krtNormal;
		return;
	}

	// See if the last character is a BOP.
	if (cchBop < prun->cch && (kfchTestBreak & rggrfch[prun->cch - 1]) &&
		(prun->cch + ichBase >= m_ichLim ||
			!(kfchNoBreakBefore & GrfchFromCh(ChFetch(prun->cch + ichBase)))))
	{
		cchBop = prun->cch;
	}

	if (cchBop > 0)
	{
		// Retreat to the last bop.
		prun->rt = krtBop;
		prun->cch = cchBop;
		if (kfchWhiteOverhang & rggrfch[cchBop - 1])
			prun->cchTrim = 1;
	}
	else
		prun->rt = krtNormal;

	// Get the width of the text and see if it all fits.
	prun->cchDraw = prun->cch;
	GetRectFromRgch(m_hdc, rc, rgch, prun->cchDraw);
	prun->dxs = rc.Width();
	if (prun->dxs <= (dxsT = m_dxsBreak - dxsBase))
	{
		// This run fits.
		goto LGetTrim;
	}

	// This run takes us over the edge.
	prun->rt = krtNormal;
	prun->cchTrim = 0;

	// Find the character that takes us over the edge. binary search.
	for (ivMin = 1, ivLim = prun->cchDraw; ivMin < ivLim; )
	{
		iv = (ivMin + ivLim) / 2;
		GetRectFromRgch(m_hdc, rc, rgch, iv);
		if (rc.Width() <= dxsT)
			ivMin = iv + 1;
		else
			ivLim = iv;
	}

	// This character hangs over.
	prun->cch = prun->cchDraw = ivMin;

	if (cchBop == 0)
		goto LNoBop;

	// There used to be a bop, see if we still have one.
	grfch = rggrfch[prun->cch - 1];

	// Check for a whitespace overhang situation.
	if (!(~grfch & (kfchMayBreak | kfchWhiteOverhang)))
	{
		prun->rt = krtBreak;
		prun->cchDraw--;
		prun->cchTrim = 1;
	}
	else
	{
		// Find the last break opportunity strictly before prun->cch.
		int cch;

		for (cch = prun->cch - 1; --cch >= 0; )
		{
			grfchPrev = grfch;
			grfch = rggrfch[cch];
			if (kfchMayBreak & grfch ||
				kfchTestBreak & grfch && !(kfchNoBreakBefore & grfchPrev))
			{
				prun->rt = krtBreak;
				prun->cch = prun->cchDraw = cch + 1;
				prun->cchTrim = (grfch & kfchWhiteOverhang) != 0;
				break;
			}
		}
	}

LNoBop:
	// Get rid of the overflow character.
	if (krtNormal == prun->rt && prun->cch > 1)
		prun->cchDraw = --(prun->cch);

	// Get the width of the text.
	GetRectFromRgch(m_hdc, rc, rgch, prun->cchDraw);
	prun->dxs = rc.Width();

LGetTrim:
	if (prun->cchTrim > prun->cch - prun->cchDraw)
	{
		GetRectFromRgch(m_hdc, rc, rgch, prun->cch - prun->cchTrim);
		prun->dxsTrim = prun->dxs - rc.Width();
	}

	if (prun->cch > 0 && rggrfch[prun->cch - 1] & kfchTestBreak)
		prun->fTestBreak = true;
}


/*----------------------------------------------------------------------------------------------
	Get the bounding rectangle of the text.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::GetRectFromRgch(HDC hdc, Rect & rc, const achar * prgch, int cch)
{
	AssertArray(prgch, cch);

	SIZE dpt;
	TEXTMETRICA txm;

	GetTextMetricsA(m_hdc, &txm);
	rc.Set(0, -txm.tmAscent, 0, txm.tmHeight + txm.tmExternalLeading - txm.tmAscent);

	if (cch)
	{
		::GetTextExtentPoint32(hdc, prgch, cch, &dpt);
		rc.right = dpt.cx;
	}
}


/*----------------------------------------------------------------------------------------------
	Set the font for the hdc.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::SetFont(HDC hdc, int dypInch, const LgCharRenderProps & chrp)
{
	LOGFONT lf;

	ClearItems(&lf, 1);

	// REVIEW ShonK: Determine correct font height for superscript. Word seems to do 2 / 3.
	if (chrp.ssv == kssvSuper || chrp.ssv == kssvSub)
		lf.lfHeight = MulDiv(chrp.dympHeight, dypInch, kdzmpInch * 3 / 2);
	else
		lf.lfHeight = MulDiv(chrp.dympHeight, dypInch, kdzmpInch);

	lf.lfWeight = chrp.ttvBold != kttvOff ? FW_BOLD : FW_NORMAL;
	lf.lfItalic = chrp.ttvItalic != kttvOff;
	lf.lfUnderline = chrp.unt != kuntNone;
	lf.lfCharSet = DEFAULT_CHARSET;
	lf.lfOutPrecision = OUT_TT_ONLY_PRECIS;
	lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
	lf.lfQuality = DEFAULT_QUALITY;
	lf.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
	strcpy(lf.lfFaceName, "Arial");

	if (m_hdcFont != hdc || m_hfont == NULL || memcmp(&m_lf, &lf, isizeof(lf)) != 0)
	{
		UncacheFont();

		Assert(m_hfont == NULL);
		m_hfont = AfGdi::CreateFontIndirect(&lf);
		if (m_hfontOld)
			AfGdi::DeleteObjectFont(m_hfontOld);
		m_hfontOld = AfGdi::SelectObjectFont(hdc, m_hfont);
		m_hdcFont = hdc;
	}

	::SetTextAlign(hdc, TA_BASELINE | TA_LEFT);
}


/*----------------------------------------------------------------------------------------------
	Unselect the font from the hdc, delete the font and clear all the variables.
----------------------------------------------------------------------------------------------*/
void FmtLineBase::UncacheFont(void)
{
	if (m_hdcFont && m_hfontOld)
	{
		AfGdi::SelectObjectFont(m_hdcFont, m_hfontOld, AfGdi::OLD);
	}
	m_hfontOld = NULL;
	m_hdcFont = NULL;

	if (m_hfont)
	{
		AfGdi::DeleteObjectFont(m_hfont);
		m_hfont = NULL;
	}
}


#ifdef TO_DO_IF_NEEDED // TODO ShonK: implement.
/***************************************************************************
	Apply full justification to the runs in _pglrun.
***************************************************************************/
void FmtLineBase::_FullJustify(void)
{
	RUN run, runT;
	int dxpFill, dxpT;
	int irunT, irunMin;
	int cbop;
	int cp;
	int ichLim, ich;
	ulong grfch, grfchPrev;
	RC rc;
	achar rgch[kcchMaxRunFli];
	byte rgichBreak[kcchMaxRunFli];
	int iichBreak;

	if (NULL == _pglrun || _pglrun->IvMac() < _rposCur.crun ||
			_rposCur.crun <= 0)
		{
		// we've had an OOM error, just use left justification
		return;
		}

	if (0 >= (dxpFill = _dxpBreak - _rposCur.dxpLine))
		{
		// we already fill the line
		return;
		}

	_pglrun->Get(_rposCur.crun - 1, &run);
	if (krtHardBreak == run.rt || krtTab == run.rt)
		{
		// don't apply full justification to lines that end with a hard break
		// or a tab
		return;
		}

	// break the runs at all break opportunities back to the last tab
	cbop = 0;
	cp = _rposCur.ichLim;
	for (irunMin = _rposCur.crun; irunMin-- > 0 && cbop < dxpFill; )
		{
		_pglrun->Get(irunMin, &run);
		cp -= run.ccp;
		switch (run.rt)
			{
		case krtTab:
			goto LAdjustSpace;
		case krtNormal:
			continue;
		case krtObject:
		case krtBop:
			if (cp + run.ccp < _rposCur.ichLim)
				cbop++;
			break;
			}

		if (run.ccpDraw <= 1)
			continue;

		AssertIn(run.ccpDraw, 0, kcchMaxRunFli + 1);
		_FetchRgch(cp, run.ccpDraw, rgch);
		_EnsureChp(cp);

		// find all the break opportunities within the run
		ichLim = run.ccpDraw;
		iichBreak = 0;
		grfch = fchNil;
		if (irunMin > 0 && ((RUN *)_pglrun->QvGet(irunMin - 1))->fTestBreak)
			grfch = fchTestBreak;

		for (ich = 0; ich < ichLim; ich++)
			{
			grfchPrev = grfch;
			grfch = GrfchFromCh(rgch[ich]);

			if (grfch & fchMayBreak)
				{
				if (ich + 1 < ichLim)
					rgichBreak[iichBreak++] = ich + 1;
				}
			else if (grfchPrev & fchTestBreak)
				{
				if (!(grfch & fchNoBreakBefore))
					{
					// can break after the previous character
					if (ich > 0)
						rgichBreak[iichBreak++] = (byte)ich;
					}
				else
					{
					// propogate fchTestBreak through this character
					grfch |= fchTestBreak;
					}
				}
			}

		if (0 == iichBreak)
			continue;

		if (!_pglrun->FEnsureSpace(iichBreak))
			{
			// out of memory
			break;
			}

		while (iichBreak-- > 0)
			{
			ich = rgichBreak[iichBreak];

			_pgnv->GetRcFromRgch(&rc, rgch, ich);

			runT = run;
			runT.ccp -= (byte)ich;
			runT.ccpDraw -= (byte)ich;
			runT.dxp -= rc.Dxp();

			run.rt = krtBop;
			run.ccp = (byte)ich;
			run.ccpDraw = (byte)ich;
			run.ccpTrim = 0;
			run.dxp = rc.Dxp();
			run.dxpTrim = 0;

			AssertDo(_pglrun->FInsert(irunMin + 1, &runT), "shouldn't fail");
			_rposCur.crun++;
			cbop++;
			}
		_pglrun->Put(irunMin, &run);
		}

LAdjustSpace:
	if (cbop == 0)
		{
		// can't full justify
		return;
		}

	irunMin++;
	AssertIn(irunMin, 0, _rposCur.crun);

	// apply full justification to the runs from irunMin to _rposCur.crun
	for (irunT = _rposCur.crun - 1; irunT-- > irunMin; )
		{
		_pglrun->Get(irunT, &run);
		if (krtBop != run.rt && krtObject != run.rt)
			continue;

		dxpT = dxpFill / cbop;
		run.dxp += dxpT;
		_pglrun->Put(irunT, &run);
		dxpFill -= dxpT;
		if (--cbop <= 0)
			break;
		}

	_rposCur.dxpLine = _dxpBreak - dxpFill;
}
#endif // TO_DO_IF_NEEDED
