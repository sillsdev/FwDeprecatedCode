/*--------------------------------------------------------------------*//*:Ignore this sentence.
Copyright (C) 1999, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TextEdit.cpp
Responsibility: Shon Katzenberger
Last reviewed:

	Implements text property byte strings.
-------------------------------------------------------------------------------*//*:End Ignore*/
#include "Main.h"
#pragma hdrstop

#include "Vector_i.cpp"

#undef THIS_FILE
DEFINE_THIS_FILE


// Explicit instantiations.
template Vector<RichTextDoc::TxtPropMapInfo>;


/*----------------------------------------------------------------------------------------------
	Return the type of the character. This must follow these implications:
		kfchBreak -> kfchMayBreak
		kfchBreak -> kfchControl
		kfchIgnore -> kfchControl
	REVIEW ShonK: Reconcile with the unicode spec.
----------------------------------------------------------------------------------------------*/
uint GrfchFromCh(achar ch)
{
	switch ((uchar)ch)
	{
	default:
		if (ch < kchSpace && 0 <= ch)
			return kfchControl | kfchWordEnd;

#ifdef UNICODE
		if (FIn((uchar)ch, 0x3000, 0x3100) || FIn((uchar)ch, 0x3190, 0x31A0) ||
			FIn((uchar)ch, 0x3300, 0x3400) || FIn((uchar)ch, 0x4E00, 0xA000) ||
			FIn((uchar)ch, 0xFE30, 0xFE50) || FIn((uchar)ch, 0xFF00, 0xFFF0))
			{
			// These, according to MSKK, are Japanese characters.
			return fchTestBreak | fchWordBodyJ;
			}
#endif //UNICODE

		return kfchWordBody;

	case kchReturn:
		return kfchBreak | kfchMayBreak | kfchControl | kfchWordEnd;

	case kchLineFeed:
		return kfchIgnore | kfchControl | kfchWordEnd;

	case '\t':
		return kfchTab | kfchMayBreak | kfchControl | kfchWordEnd;

	case kchSpace:
		return kfchWhiteOverhang | kfchMayBreak | kfchWordEnd;

	case 0x7F:
		return kfchControl | kfchWordEnd;

#ifdef UNICODE
	case 0xFF46:
		return kfchTestBreak | kfchWordEndJ;

	// Can't break a line right after these characters

	case '(':
	case '[':
	case '{':
		return kfchWordBody;

	case 0x2018:
	case 0x201C:
	case 0x3008:
	case 0x300A:
	case 0x300C:
	case 0x300E:
	case 0x3010:
	case 0x3014:
	case 0xFF08:
	case 0xFF1C:
	case 0xFF3B:
	case 0xFF5B:
	case 0xFF62:
		return kfchWordBodyJ;

	// If these follow an fchTestBreak character, we cannot break
	// in between.

	case '!': // 0x0021
	case ')': // 0x0029
	case ',': // 0x002C
	case '.': // 0x002E
	case ':': // 0x003A
	case ';': // 0x003B
	case '?': // 0x003F
	case ']': // 0x005D
	case '}': // 0x007D
		return kfchNoBreakBefore | kfchWordBody;

	case 0x3001:
	case 0xFF61:
		return kfchNoBreakBefore | kfchWordEndJ;

	case 0x2019:
	case 0x201D:

	case 0x3002:
	case 0x3005:
	case 0x3009:
	case 0x300D:
	case 0x300F:
	case 0x3011:
	case 0x3015:
	case 0x3041:
	case 0x3043:
	case 0x3045:
	case 0x3047:
	case 0x3049:
	case 0x3063:
	case 0x3083:
	case 0x3085:
	case 0x3087:
	case 0x308E:
	case 0x3091:
	case 0x3093:
	case 0x3095:
	case 0x3097:
	case 0x3099:
	case 0x309B:
	case 0x309E:
	case 0x30C3:
	case 0x30E3:
	case 0x30E5:
	case 0x30E7:
	case 0x30EE:
	case 0x30FB:
	case 0x30FC:
	case 0x30FD:
	case 0x30FE:

	case 0xFF01:
	case 0xFF09:
	case 0xFF0C:
	case 0xFF0E:
	case 0xFF1A:
	case 0xFF1B:
	case 0xFF1E:
	case 0xFF1F:
	case 0xFF3D:
	case 0xFF5D:
	case 0xFF63:
	case 0xFF64:
	case 0xFF65:
	case 0xFF67:
	case 0xFF68:
	case 0xFF69:
	case 0xFF6A:
	case 0xFF6B:
	case 0xFF6C:
	case 0xFF6D:
	case 0xFF6E:
	case 0xFF70:

	case 0xFF9E:
	case 0xFF9F:
		return kfchNoBreakBefore | kfchWordBodyJ;
#endif //UNICODE
	}
}


/*----------------------------------------------------------------------------------------------
	Apply the given group of text properties to the given chrp. Assumes the chrp is
	already filled with base values.
----------------------------------------------------------------------------------------------*/
void ApplyChrpTextPropGroup(LgCharRenderProps & chrp, const byte * prgb, int cb)
{
	AssertArray(prgb, cb);

	int nVal1, nVal2;
	const byte * pb = prgb;
	const byte * pbLim = pb + cb;

	while (pb < pbLim)
	{
		switch (::GetFirstTextProp(&pb, pbLim, &nVal1, &nVal2))
		{
		case kscpWs:
		case kscpWsAndOws:
			chrp.ws = nVal1;
			break;
		case kscpItalic:
			if (nVal1 == kttvInvert)
				chrp.ttvItalic = chrp.ttvItalic == kttvOff ? kttvOn : kttvOff;
			else
				chrp.ttvItalic = nVal1;
			break;
		case kscpBold:
			if (nVal1 == kttvInvert)
				chrp.ttvBold = chrp.ttvBold == kttvOff ? kttvOn : kttvOff;
			else
				chrp.ttvBold = nVal1;
			break;
		case kscpSuperscript:
			chrp.ssv = nVal1;
			break;
		case kscpUnderline:
			chrp.unt = nVal1;
			break;
		case kscpFontSize:
			if (GetTextPropVar(nVal1) == ktpvMilliPoint)
				chrp.dympHeight = GetTextPropVal(nVal1);
			break;
		case kscpOffset:
			if (GetTextPropVar(nVal1) == ktpvMilliPoint)
				chrp.dympOffset = GetTextPropVal(nVal1);
			break;
		case kscpForeColor:
			chrp.clrFore = nVal1;
			break;
		case kscpBackColor:
			chrp.clrBack = nVal1;
			break;
		case kscpUnderColor:
			chrp.clrBack = nVal1;
			break;
		}
	}
}


/*----------------------------------------------------------------------------------------------
	Apply the given group of text properties to the given parp. Assumes the parp is
	already filled with base values.
----------------------------------------------------------------------------------------------*/
void ApplyParpTextPropGroup(LgParaRenderProps & parp, const byte * prgb, int cb)
{
	AssertArray(prgb, cb);

	int nVal1, nVal2;
	const byte * pb = prgb;
	const byte * pbLim = pb + cb;

	while (pb < pbLim)
	{
		switch (::GetFirstTextProp(&pb, pbLim, &nVal1, &nVal2))
		{
		case kscpAlign:
			parp.tal = nVal1;
			break;
		case kscpFirstIndent:
			if (GetTextPropVar(nVal1) == ktpvMilliPoint)
				parp.dxmpFirstIndent = GetTextPropVal(nVal1);
			break;
		case kscpLeadingIndent:
			if (GetTextPropVar(nVal1) == ktpvMilliPoint)
				parp.dxmpLeadingIndent = GetTextPropVal(nVal1);
			break;
		case kscpTrailingIndent:
			if (GetTextPropVar(nVal1) == ktpvMilliPoint)
				parp.dxmpTrailingIndent = GetTextPropVal(nVal1);
			break;
		case kscpLineHeight:
			switch (GetTextPropVar(nVal1))
			{
			case ktpvMilliPoint:
				parp.relLine = 0;
				parp.dympExtraLine = GetTextPropVal(nVal1);
				break;
			case ktpvRelative:
				parp.relLine = GetTextPropVal(nVal1);
				parp.dympExtraLine = 0;
				break;
			}
			break;
		case kscpSpaceBefore:
			if (GetTextPropVar(nVal1) == ktpvMilliPoint)
			{
				parp.relBefore = 0;
				parp.dympExtraBefore = GetTextPropVal(nVal1);
			}
			break;
		case kscpSpaceAfter:
			if (GetTextPropVar(nVal1) == ktpvMilliPoint)
			{
				parp.relAfter = 0;
				parp.dympExtraAfter = GetTextPropVal(nVal1);
			}
			break;
		case kscpTabDef:
			if (GetTextPropVar(nVal1) == ktpvMilliPoint)
				parp.dxmpTabDef = GetTextPropVal(nVal1);
			break;
		case kscpParaColor:
			parp.clrBack = nVal1;
			break;
		}
	}
}


/*----------------------------------------------------------------------------------------------
	For fields that differ, set chrpDst to knNinch.
	WARNING: This assumes that each field is an int.
----------------------------------------------------------------------------------------------*/
void MergeNinchChrp(const LgCharRenderProps & chrpSrc, LgCharRenderProps & chrpDst)
{
	const int * pnSrc = (int *)&chrpSrc;
	int * pnDst = (int *)&chrpDst;
	const int * pnSrcLim = (int *)(&chrpSrc + 1);

	for ( ; pnSrc < pnSrcLim; pnSrc++, pnDst++)
	{
		if (*pnSrc != *pnDst)
			*pnDst = knNinch;
	}
}


/*----------------------------------------------------------------------------------------------
	Constructor. This should be allocated with NewObj which should have cleared everything.
----------------------------------------------------------------------------------------------*/
ByteStrHolder::ByteStrHolder(void)
{
	Assert(!m_prgpbstHash);
	Assert(!m_cpbstHash);
	Assert(!m_cpbst);
}


/*----------------------------------------------------------------------------------------------
	Free any remaining byte strings.
----------------------------------------------------------------------------------------------*/
ByteStrHolder::~ByteStrHolder(void)
{
	int ipbst;
	ByteString * pbst;

	for (ipbst = 0; ipbst < m_cpbstHash; ipbst++)
	{
		for (pbst = m_prgpbstHash[ipbst]; pbst; )
		{
			ByteString * pbstT = pbst;
			pbst = pbst->m_pbstNext;
			delete pbstT;
		}
	}

	if (m_prgpbstHash)
	{
		free(m_prgpbstHash);
		m_prgpbstHash = NULL;
	}
	m_cpbstHash = 0;
	m_cpbst = 0;
}


/*----------------------------------------------------------------------------------------------
	Make sure there is a byte string containing the given data and return it.
----------------------------------------------------------------------------------------------*/
ByteString * ByteStrHolder::GetByteStr(const void * pv, int cb)
{
	AssertPtrSize(pv, cb);

	ByteString * pbst;
	uint uHash = ComputeHashRgb((byte *)pv, cb);

	if (Find(pv, cb, uHash, &pbst))
		return pbst;

	pbst = NewObjExtra(cb) ByteString;

	CopyBytes(pv, pbst + 1, cb);
	pbst->m_uHash = uHash;
	pbst->m_cb = cb;
	pbst->m_pbstNext = NULL;

	Add(pbst);

	return pbst;
}


/*----------------------------------------------------------------------------------------------
	Clear the marks on the byte strings. The high bit of m_cb is used as the mark.
----------------------------------------------------------------------------------------------*/
void ByteStrHolder::ClearMarks(void)
{
	int ipbst;
	ByteString * pbst;

	for (ipbst = 0; ipbst < m_cpbstHash; ipbst++)
	{
		for (pbst = m_prgpbstHash[ipbst]; pbst; pbst = pbst->m_pbstNext)
			pbst->m_cb &= 0x7FFFFFFF;
	}
}


/*----------------------------------------------------------------------------------------------
	Free any byte strings that are unmarked.
----------------------------------------------------------------------------------------------*/
void ByteStrHolder::FreeUnmarked(void)
{
	int ipbst;
	ByteString ** ppbst;

	for (ipbst = 0; ipbst < m_cpbstHash; ipbst++)
	{
		for (ppbst = &m_prgpbstHash[ipbst]; *ppbst; )
		{
			ByteString * pbstT = *ppbst;
			if (!(pbstT->m_cb & 0x80000000))
			{
				*ppbst = pbstT->m_pbstNext;
				delete pbstT;
			}
			else
				ppbst = &pbstT->m_pbstNext;
		}
	}
}


/*----------------------------------------------------------------------------------------------
	Look for a byte string containing the given data.
----------------------------------------------------------------------------------------------*/
bool ByteStrHolder::Find(const void * pv, int cb, uint uHash, ByteString ** ppbstRet)
{
	AssertPtrSize(pv, cb);
	AssertPtr(ppbstRet);

	if (!m_cpbstHash)
		return false;

	ByteString * pbst;
	ByteString ** ppbstHead = &m_prgpbstHash[uHash % m_cpbstHash];
	ByteString ** ppbst;

	for (ppbst = ppbstHead; (pbst = *ppbst) != NULL; ppbst = &pbst->m_pbstNext)
	{
		if (uHash == pbst->m_uHash && (pbst->m_cb & 0x7FFFFFFF) == cb &&
			0 == memcmp(pbst + 1, pv, cb))
		{
			*ppbstRet = pbst;
			if (ppbst != ppbstHead)
			{
				// Move to the head of the chain.
				*ppbst = pbst->m_pbstNext;
				pbst->m_pbstNext = *ppbstHead;
				*ppbstHead = pbst;
			}
			return true;
		}
	}

	return false;
}


/*----------------------------------------------------------------------------------------------
	Add the byte string to the hash table.
----------------------------------------------------------------------------------------------*/
void ByteStrHolder::Add(ByteString * pbst)
{
	AssertPtr(pbst);
	Assert(!pbst->m_pbstNext);

	if (m_cpbst >= 4 * m_cpbstHash)
		Rehash();

	int ipbst = pbst->m_uHash % m_cpbstHash;
	pbst->m_pbstNext = m_prgpbstHash[ipbst];
	m_prgpbstHash[ipbst] = pbst;
	m_cpbst++;
	Assert(m_cpbst > 0);
}


/*----------------------------------------------------------------------------------------------
	Grow the number of hash buckets.
----------------------------------------------------------------------------------------------*/
void ByteStrHolder::Rehash(void)
{
	// Need to grow the number of hash buckets.
	int cpbstNew = GetPrimeNear(Max(2 * (m_cpbst + 1), 10));
	if (cpbstNew <= m_cpbstHash)
		return;

	ByteString ** prgpbstNew = (ByteString **)calloc(cpbstNew, isizeof(ByteString *));
	if (!prgpbstNew)
		ThrowHr(WarnHr(E_OUTOFMEMORY));

	ByteString * pbst;
	ByteString * pbstNext;
	int ipbst;

	for (ipbst = 0; ipbst < m_cpbstHash; ipbst++)
	{
		for (pbst = m_prgpbstHash[ipbst]; pbst; pbst = pbstNext)
		{
			pbstNext = pbst->m_pbstNext;

			int ipbstNew = pbst->m_uHash % cpbstNew;
			pbst->m_pbstNext = prgpbstNew[ipbstNew];
			prgpbstNew[ipbstNew] = pbst;
		}
	}

	if (m_prgpbstHash)
		free(m_prgpbstHash);

	m_prgpbstHash = prgpbstNew;
	m_cpbstHash = cpbstNew;
}


/***********************************************************************************************
	TxtPropMap methods.
***********************************************************************************************/


/*----------------------------------------------------------------------------------------------
	Return the index of the Entry containing ich. If ich is before the first Entry, this
	returns -1.
----------------------------------------------------------------------------------------------*/
int TxtPropMap::FindEntry(int ich)
{
	AssertObj(this);
	Assert(ich >= 0);

	int ivMin, ivLim;

	for (ivMin = 0, ivLim = m_vent.Size(); ivMin < ivLim; )
	{
		int ivMid = (ivMin + ivLim) / 2;
		if (GetIch(ivMid) <= ich)
			ivMin = ivMid + 1;
		else
			ivLim = ivMid;
	}
	Assert(ivMin == m_vent.Size() || ich < GetIch(ivMin));
	Assert(ivMin == 0 || GetIch(ivMin - 1) <= ich);

	return ivMin - 1;
}


/*----------------------------------------------------------------------------------------------
	Make sure the m_ich values are all up to date.
----------------------------------------------------------------------------------------------*/
void TxtPropMap::Validate(void)
{
	AssertObj(this);

	if (m_dich)
	{
		int ient;

		for (ient = m_ientInval; ient < m_vent.Size(); ient++)
		{
			m_vent[ient].m_ich += m_dich;
			Assert(0 == ient && 0 <= m_vent[ient].m_ich ||
				0 < ient && m_vent[ient - 1].m_ich < m_vent[ient].m_ich);
		}

		m_dich = 0;
	}
	m_ientInval = 0; // This really isn't necessary.
}


/*----------------------------------------------------------------------------------------------
	Get the string for the given character position. The caller should fill in *pichMin and
	*pichLim with defaults before calling this.
----------------------------------------------------------------------------------------------*/
ByteString * TxtPropMap::FetchStr(int ich, int * pichMin, int * pichLim)
{
	AssertObj(this);
	AssertPtrN(pichMin);
	AssertPtrN(pichLim);

	int ient = FindEntry(ich);

	if (pichLim && ient + 1 < m_vent.Size())
		*pichLim = GetIch(ient + 1);
	if (ient >= 0)
	{
		if (pichMin)
			*pichMin = GetIch(ient);
		return m_vent[ient].m_pbst;
	}

	return NULL;
}


/*----------------------------------------------------------------------------------------------
	Set the string on the given range.
----------------------------------------------------------------------------------------------*/
void TxtPropMap::SetStr(int ichMin, int ichLim, ByteString * pbst)
{
	AssertObj(this);
	Assert(0 <= ichMin && ichMin <= ichLim);
	AssertPtrN(pbst);

	if (!pbst->Size())
		pbst = NULL;

	if (ichMin >= ichLim)
		return;

	// Find the entries.
	int ientMin = FindEntry(ichMin);
	int ientLim = FindEntry(ichLim);

	Assert(-1 <= ientMin && ientMin <= ientLim && ientLim < m_vent.Size());

	ByteString * pbstMin = GetBst(ientMin);
	ByteString * pbstLim = GetBst(ientLim);

	// The new entries.
	Entry rgent[2];
	int cent = 0;

	if (ientMin <= 0 || GetIch(ientMin) < ichMin || pbst != GetBst(ientMin - 1))
	{
		if (pbst != pbstMin)
		{
			rgent[cent].m_ich = ichMin;
			rgent[cent].m_pbst = pbst;
			cent++;
		}
		if (ientMin < 0 || GetIch(ientMin) < ichMin)
			ientMin++;
	}

	if (pbst == pbstLim)
		ientLim++;
	else if (ientLim < ientMin || GetIch(ientLim) < ichLim)
	{
		rgent[cent].m_ich = ichLim;
		rgent[cent].m_pbst = pbstLim;
		cent++;
		ientLim++;
	}

	Assert(0 <= ientMin && ientMin <= ientLim && ientLim <= m_vent.Size());

	if (ientMin < ientLim || cent > 0)
	{
		if (m_dich)
			Validate();
		m_vent.Replace(ientMin, ientLim, rgent, cent);
	}
}


/*----------------------------------------------------------------------------------------------
	An edit occured on the text stream. Update this appropriately.
	Returns true iff some elements were in the affected range.

	Concerning cchIns and ichLim:
		For character range tracking these should indicate the actual character positions that
			were edited.
		For paragraph range tracking, ichMin + cchIns should be on a paragraph boundary and
			ichLim should be adjusted accordingly.
----------------------------------------------------------------------------------------------*/
bool TxtPropMap::Edit(int ichMin, int ichLim, int cchIns)
{
	AssertObj(this);
	Assert(0 <= ichMin && ichMin <= ichLim);
	Assert(0 <= cchIns);

	int dich = cchIns - ichLim + ichMin;
	int ientMin = FindEntry(ichMin);
	int ientLim = FindEntry(ichLim);
	bool fRet = false;

	Assert(-1 <= ientMin && ientMin <= ientLim && ientLim < m_vent.Size());
	Assert(ientMin == m_vent.Size() - 1 || ichMin < GetIch(ientMin + 1));
	Assert(ientMin < 0 || GetIch(ientMin) <= ichMin);
	Assert(ientLim == m_vent.Size() - 1 || ichLim < GetIch(ientLim + 1));
	Assert(ientLim < 0 || GetIch(ientLim) <= ichLim);

	if (ientMin < 0 || GetIch(ientMin) < ichMin)
		ientMin++;
	if (m_fTrackPos)
	{
		if (ientLim < 0 || GetIch(ientLim) < ichLim)
			ientLim++;
	}
	else
	{
		if (ientLim < ientMin)
			ientLim++;
		Assert(0 <= ientLim && (ientLim + 1 >= m_vent.Size() || ichLim < GetIch(ientLim + 1)));
		if (ientLim < m_vent.Size())
		{
			// See if the byte strings of the soon to be adjacent entries match. If so, delete
			// an extra entry. Otherwise, if ichLim is in ientLim, update the m_ich of ientLim
			// so it starts at ichLim.
			if (m_vent[ientLim].m_pbst == GetBst(ientMin - 1))
				ientLim++;
			else if (GetIch(ientLim) < ichLim)
			{
				m_vent[ientLim].m_ich += ichLim - GetIch(ientLim);
				Assert(ichLim == GetIch(ientLim));
				fRet = true;
			}
		}
	}

	// If the current deferred update doesn't start within the range that we're deleting,
	// validate the entries before performing the edit.
	if (m_dich && (m_ientInval < ientMin || ientLim < m_ientInval))
		Validate();

	// Delete the old entries.
	Assert(!m_dich || ientMin <= m_ientInval && m_ientInval <= ientLim);
	if (ientMin < ientLim)
	{
		fRet = true;
		m_vent.Delete(ientMin, ientLim);
	}

	// Adjust the invalidation.
	if (ientMin >= m_vent.Size())
	{
		m_dich = 0;
		m_ientInval = 0;
	}
	else if (0 == (m_dich += dich))
		m_ientInval = 0;
	else
		m_ientInval = ientMin;

	return fRet;
}


/***********************************************************************************************
	RichTextDoc methods.
***********************************************************************************************/


/*----------------------------------------------------------------------------------------------
	Create a new empty rich text document.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::Create(RichTextDoc ** pprtd)
{
	AssertPtr(pprtd);
	Assert(!*pprtd);

	RichTextDocPtr qrtd;

	qrtd.Attach(NewObj RichTextDoc);
	qrtd->Init();
	*pprtd = qrtd.Detach();
}


/*----------------------------------------------------------------------------------------------
	Initialize a new rich text document.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::Init(void)
{
	AssertPtr(this);

	rchar ch;

	m_qtpmChar.Create();
	m_qtpmPara.Create();
	m_qdast.Attach(NewObj DataStream(isizeof(rchar)));

	// Append a return character.
	ch = kchReturn;
	m_qdast->Replace(m_qdast->Size(), m_qdast->Size(), &ch, 1);

	AssertObj(this);
}


/*----------------------------------------------------------------------------------------------
	Return the number of characters in the document.
----------------------------------------------------------------------------------------------*/
int RichTextDoc::IchMac(void)
{
	AssertObj(this);
	return m_qdast->Size();
}


/*----------------------------------------------------------------------------------------------
	Make sure the range of characters is in the cache.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::CacheRange(int ichMin, int ichLim)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	Assert(ichLim - ichMin <= kcchMaxCache);

	if (ichMin >= m_ichMinCache && ichLim <= m_ichLimCache)
		return;

	int ichMac = IchMac();

	// Since we have to adjust the cache, center the new cache on the requested range.
	int ichMinCache = Max(0, Min(ichMac - kcchMaxCache,
		(ichMin + ichLim - kcchMaxCache) / 2));
	int ichLimCache = Min(ichMac, ichMinCache + kcchMaxCache);

	Assert((uint)ichMinCache <= (uint)ichMin && (uint)ichMin <= (uint)ichLim &&
		(uint)ichLim <= (uint)ichLimCache && (uint)ichLimCache <= (uint)ichMac);

	// If the current cache is small or the new cache range doesn't overlap the
	// current cache or the cache is growing in both directions, just ignore the current cache.
	const int kcchSlop = kcchMaxCache / 5;

	if (m_ichLimCache - m_ichMinCache <= kcchSlop ||
		m_ichLimCache <= ichMinCache || ichLimCache <= m_ichMinCache ||
		ichMinCache < m_ichMinCache && m_ichLimCache < ichLimCache)
	{
		// Can't use existing cache.
		m_qdast->Fetch(ichMinCache, ichLimCache, m_rgchCache);
	}
	else if (ichMinCache < m_ichMinCache)
	{
		// Keep front end of old stuff.
		Assert(ichLimCache <= m_ichLimCache);
		MoveItems(m_rgchCache, m_rgchCache + m_ichMinCache - ichMinCache,
			ichLimCache - m_ichMinCache);
		m_qdast->Fetch(ichMinCache, m_ichMinCache, m_rgchCache);
	}
	else
	{
		// Keep back end old stuff.
		Assert(ichLimCache > m_ichLimCache);
		Assert(ichMinCache >= m_ichMinCache);

		if (ichMinCache > m_ichMinCache)
		{
			MoveItems(m_rgchCache + ichMinCache - m_ichMinCache, m_rgchCache,
				m_ichLimCache - ichMinCache);
		}
		m_qdast->Fetch(m_ichLimCache, ichLimCache, m_rgchCache + m_ichLimCache - ichMinCache);
	}

	m_ichMinCache = ichMinCache;
	m_ichLimCache = ichLimCache;
}


/*----------------------------------------------------------------------------------------------
	Characters have changed, so fix the cache.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::InvalCache(int ichMin, int ichLim, int cchIns)
{
	Assert(0 <= ichMin && ichMin <= ichLim);
	Assert(cchIns >= 0);
	Assert(ichMin + cchIns <= m_qdast->Size());

	int dichFront, dichBack;

	if (m_ichLimCache <= ichMin || m_ichLimCache <= m_ichMinCache ||
			cchIns == 0 && ichMin == ichLim)
	{
		// Cache is before the edit or cache is already empty.
		return;
	}

	if (m_ichMinCache >= ichLim)
	{
		// Cache is after the edit.
		m_ichMinCache += cchIns - ichLim + ichMin;
		m_ichLimCache += cchIns - ichLim + ichMin;
		return;
	}

	dichFront = ichMin - m_ichMinCache;
	dichBack = m_ichLimCache - ichLim;
	if (dichFront <= 0 && dichBack <= 0)
		m_ichMinCache = m_ichLimCache = 0;
	else if (dichFront >= dichBack)
	{
		// Keep the front end of the cache.
		m_ichLimCache = ichMin;
	}
	else
	{
		// Keep the tail end of the cache.
		MoveItems(m_rgchCache + ichLim - m_ichMinCache, m_rgchCache, dichBack);
		m_ichMinCache = ichMin + cchIns;
		m_ichLimCache = m_ichMinCache + dichBack;
	}
}


/*----------------------------------------------------------------------------------------------
	Adjust all the TxtPropMaps after an edit.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::AdjustMaps(int ichMin, int ichLim, int cchIns)
{
	if (ichMin == ichLim && !cchIns)
		return;

	int cchInsPara;
	int ichLimPara;
	bool fParaPropsChanged = false;

	if (FMinPara(ichMin + cchIns))
		cchInsPara = cchIns;
	else
		cchInsPara = IchLimPara(ichMin + cchIns) - ichMin;
	ichLimPara = ichLim + cchInsPara - cchIns;

	m_qtpmChar->Edit(ichMin, ichLim, cchIns);
	if (m_qtpmPara->Edit(ichMin, ichLimPara, cchInsPara))
		fParaPropsChanged = true;

	int itpmi;

	// TODO ShonK: Keep track of which are para tracking.
	for (itpmi = 0; itpmi < m_vtpmi.Size(); itpmi++)
	{
		if (!m_vtpmi[itpmi].m_fPara)
			m_vtpmi[itpmi].m_qtpm->Edit(ichMin, ichLim, cchIns);
		else if (m_vtpmi[itpmi].m_qtpm->Edit(ichMin, ichLimPara, cchInsPara))
			fParaPropsChanged = true;
	}

	if (fParaPropsChanged)
		AddEdit(ichMin, ichLimPara, cchInsPara);
	else
		AddEdit(ichMin, ichLim, cchIns);
}


/*----------------------------------------------------------------------------------------------
	Fetch some characters from the text document.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::FetchRgch(int ichMin, int ichLim, rchar * prgch)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	AssertArray(prgch, ichLim - ichMin);

	while (ichMin < ichLim)
	{
		int cchT = NMin(ichLim - ichMin, kcchMaxCache);
		CacheRange(ichMin, ichMin + cchT);
		CopyItems(m_rgchCache + ichMin - m_ichMinCache, prgch, cchT);
		prgch += cchT;
		ichMin += cchT;
	}
}


/*----------------------------------------------------------------------------------------------
	If fExpand is true, get the bounds of all paragraphs that intersect [ichMin, ichLim).
	If fExpand is false, get the bounds of all paragraphs completely contained in
		[ichMin, ichLim).
----------------------------------------------------------------------------------------------*/
void RichTextDoc::GetParaBounds(int * pichMin, int * pichLim, bool fExpand)
{
	AssertPtr(pichMin);
	AssertPtr(pichLim);
	Assert(0 <= *pichMin && *pichMin < IchMac());
	Assert(*pichMin <= *pichLim && *pichLim <= IchMac());

	if (fExpand)
	{
		*pichLim = IchLimPara(*pichLim - (*pichLim > 0 && *pichLim > *pichMin));
		*pichMin = IchMinPara(*pichMin);
	}
	else
	{
		if (!FMinPara(*pichMin))
			*pichMin = IchLimPara(*pichMin);
		if (!FMinPara(*pichLim))
		{
			*pichLim = IchNext(*pichLim);
			if (*pichLim < IchMac())
				*pichLim = IchMinPara(*pichLim);
		}
	}
}


/*----------------------------------------------------------------------------------------------
	Returns non-zero iff ich is the beginning of a paragraph.
----------------------------------------------------------------------------------------------*/
bool RichTextDoc::FMinPara(int ich)
{
	AssertObj(this);

	if (ich <= 0)
		return ich == 0;
	if (ich >= IchMac())
		return false;

	rchar ch;

	ch = ChFetch(ich);
	if (GrfchFromCh(ch) & kfchIgnore)
		return false;

	// Return true iff the first non-line feed character we see is a carriage return character.
	while (--ich >= 0)
	{
		ch = ChFetch(ich);
		if (GrfchFromCh(ch) & kfchBreak)
			return true;
		if (!(GrfchFromCh(ch) & kfchIgnore))
			return false;
	}

	// Just line feeds!
	Warn("isolated line feeds");
	return false;
}


/*----------------------------------------------------------------------------------------------
	Find the beginning of the paragraph that ich is in. If ich <= 0, returns 0.
	If ich >= IchMac(), returns the beginning of the last paragraph.
----------------------------------------------------------------------------------------------*/
int RichTextDoc::IchMinPara(int ich)
{
	AssertObj(this);

	int ichOrig;
	int dichLine = 1;

	if (ich <= 0)
		return 0;

	if (ich >= IchMac())
		ich = IchMac() - 1;
	else if (ChFetch(ich) == kchLineFeed)
		dichLine++;
	ichOrig = ich;

	while (--ich >= 0)
	{
		rchar ch = ChFetch(ich);
		if (GrfchFromCh(ch) & kfchBreak)
		{
			if (ich + dichLine <= ichOrig)
				return ich + dichLine;
			dichLine = 1;
		}
		else if (GrfchFromCh(ch) & kfchIgnore)
			dichLine++;
		else
			dichLine = 1;
	}
	return 0;
}


/*----------------------------------------------------------------------------------------------
	Find the end of the paragraph that ich is in. If ich < 0, returns 0. If ich >= IchMac(),
	returns IchMac().
----------------------------------------------------------------------------------------------*/
int RichTextDoc::IchLimPara(int ich)
{
	AssertObj(this);

	bool fCr = false;
	int ichLim = IchMac();

	if (ich < 0)
		return 0;
	if (ich >= ichLim)
		return ichLim;

	// Ich should now be a legal index into the character stream.
	Assert((uint)ich < (uint)ichLim);

	while (ich > 0 && GrfchFromCh(ChFetch(ich)) & kfchIgnore)
		ich--;

	for ( ; ich < ichLim; ich++)
	{
		rchar ch = ChFetch(ich);
		if (GrfchFromCh(ch) & kfchBreak)
		{
			if (fCr)
				return ich;
			fCr = true;
		}
		else if (!(GrfchFromCh(ch) & kfchIgnore) && fCr)
			return ich;
	}

	AssertMsg(fCr, "last character is not a return character");
	return ichLim;
}


/*----------------------------------------------------------------------------------------------
	Return ich of the previous character, skipping line feed characters.
	ENHANCE: Implement a word version of this.
----------------------------------------------------------------------------------------------*/
int RichTextDoc::IchPrev(int ich)
{
	AssertObj(this);
	Assert((uint)ich <= (uint)IchMac());

	if (ich <= 0)
		return 0;

	while (--ich > 0 && ChFetch(ich) == kchLineFeed)
		;

	return ich;
}


/*----------------------------------------------------------------------------------------------
	Return ich of the next character, skipping line feed characters.
----------------------------------------------------------------------------------------------*/
int RichTextDoc::IchNext(int ich)
{
	AssertObj(this);
	Assert((uint)ich <= (uint)IchMac());

	int ichLim = IchMac();

	if (ich >= ichLim)
		return ichLim;

	while (++ich < ichLim && ChFetch(ich) == kchLineFeed)
		;

	return ich;
}


/*----------------------------------------------------------------------------------------------
	Record an edit on the given range. The edits are accumulated until BroadCastInval
	is called (with non NULL grfdoc).
----------------------------------------------------------------------------------------------*/
void RichTextDoc::AddEdit(int ichMin, int ichLim, int cchIns)
{
	Assert((uint)ichMin < (uint)IchMac());
	Assert(ichMin <= ichLim);
	Assert((uint)cchIns <= (uint)(IchMac() - ichMin));

	if (ichMin == ichLim && !cchIns)
		return;

	if (!m_dichEdit && m_ichMinEdit == m_ichLimEdit)
	{
		m_ichMinEdit = ichMin;
		m_ichLimEdit = ichLim;
		m_dichEdit = cchIns - ichLim + ichMin;
	}
	else
	{
		/***************************************************************************************
			To understand how this works, consider two functions defined as follows:

				f(i) = i      for i <  a
				f(i) = i + x  for i >= b
				f(i) = undefined otherwise

				g(i) = i      for i <  c
				g(i) = i + y  for i >= d
				g(i) = undefined otherwise

			Then

				g(f(i)) = i          for i <  min(a, c)
				g(f(i)) = i + x + y  for i >= max(b, d - x)
				g(f(i)) = undefined otherwise

			Thus we should set

				m_ichMinEdit = Min(m_ichMinEdit, ichMin);
				m_ichLimEdit = Max(m_ichLimEdit, ichLim - m_dich);
				m_dich = m_dich + cchIns - ichLim + ichMin;
		***************************************************************************************/
		if (ichMin < m_ichMinEdit)
			m_ichMinEdit = ichMin;
		if (m_ichLimEdit < ichLim - m_dichEdit)
			m_ichLimEdit = ichLim - m_dichEdit;
		m_dichEdit += cchIns - ichLim + ichMin;
	}
}


/*----------------------------------------------------------------------------------------------
	Replace [ichMin, ichLim) with the given characters.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::Replace(int ichMin, int ichLim, const rchar * prgch, int cchIns, uint grfdoc)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	AssertArray(prgch, cchIns);

	SetUndo(ichMin, ichLim, cchIns);

	m_qdast->Replace(ichMin, ichLim, prgch, cchIns);
	InvalCache(ichMin, ichLim, cchIns);
	// AdjustMaps calls AddEdit.
	AdjustMaps(ichMin, ichLim, cchIns);

	CommitUndo();

	AssertObj(this);
	BroadCastInval(grfdoc);
}


/*----------------------------------------------------------------------------------------------
	Get the TxtPropMap for the given string property type. If the map doesn't exist and fCreate
	is true, this creates the map (empty).
----------------------------------------------------------------------------------------------*/
TxtPropMap * RichTextDoc::GetTxtPropMap(int spt, bool fCreate)
{
	AssertPtr(this);

	int ivMin, ivLim;

	for (ivMin = 0, ivLim = m_vtpmi.Size(); ivMin < ivLim; )
	{
		int ivMid = (ivMin + ivLim) / 2;
		if (m_vtpmi[ivMid].m_spt < spt)
			ivMin = ivMid + 1;
		else
			ivLim = ivMid;
	}

	Assert(ivMin == m_vtpmi.Size() || m_vtpmi[ivMin].m_spt >= spt);
	Assert(ivMin == 0 || m_vtpmi[ivMin - 1].m_spt < spt);

	if (ivMin >= m_vtpmi.Size() || m_vtpmi[ivMin].m_spt != spt)
	{
		if (!fCreate)
			return NULL;

		// Create the TxtPropMap.
		TxtPropMapInfo tpmi;
		tpmi.m_spt = spt;
		tpmi.m_qtpm.Create();
		m_vtpmi.Insert(ivMin, tpmi);
	}

	Assert(ivMin < m_vtpmi.Size() && m_vtpmi[ivMin].m_spt == spt);
	return m_vtpmi[ivMin].m_qtpm;
}


/*----------------------------------------------------------------------------------------------
	Get the byte string and valid range for the given range of characters.
----------------------------------------------------------------------------------------------*/
ByteString * RichTextDoc::FetchStr(TxtPropMap * ptpm, int ich, int * pichMin, int * pichLim)
{
	AssertObj(this);
	AssertObjN(ptpm);
	AssertPtrN(pichMin);
	AssertPtrN(pichLim);

	if (pichMin)
		*pichMin = 0;
	if (pichLim)
		*pichLim = IchMac();

	ByteString * pbst;

	if (ptpm && NULL != (pbst = ptpm->FetchStr(ich, pichMin, pichLim)))
		return pbst;
	return m_bsh.GetByteStr(NULL, 0);
}


/*----------------------------------------------------------------------------------------------
	Get the character properties byte string.
----------------------------------------------------------------------------------------------*/
ByteString * RichTextDoc::FetchCharProps(int ich, int * pichMin, int * pichLim)
{
	return FetchStr(m_qtpmChar, ich, pichMin, pichLim);
}


/*----------------------------------------------------------------------------------------------
	Get the paragraph properties byte string.
----------------------------------------------------------------------------------------------*/
ByteString * RichTextDoc::FetchParaProps(int ich, int * pichMin, int * pichLim)
{
	return FetchStr(m_qtpmPara, ich, pichMin, pichLim);
}


/*----------------------------------------------------------------------------------------------
	Get the byte string for the given string property type and character position.
----------------------------------------------------------------------------------------------*/
ByteString * RichTextDoc::FetchStrProp(int spt, int ich, int * pichMin, int * pichLim)
{
	return FetchStr(GetTxtPropMap(spt), ich, pichMin, pichLim);
}


/*----------------------------------------------------------------------------------------------
	This forces the properties over the entire range to be exactly (pv, cb).
----------------------------------------------------------------------------------------------*/
void RichTextDoc::SetCharProps(int ichMin, int ichLim, const void * pv, int cb, uint grfdoc)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	AssertPtrSize(pv, cb);

	if (ichMin >= ichLim)
		return;

	m_qtpmChar->SetStr(ichMin, ichLim, m_bsh.GetByteStr(pv, cb));
	AddEdit(ichMin, ichLim, ichLim - ichMin);
	BroadCastInval(grfdoc);
}


/*----------------------------------------------------------------------------------------------
	Set the string property value to (pv, cb) on [ichMin, ichLim).
----------------------------------------------------------------------------------------------*/
void RichTextDoc::SetCharStrProp(int spt, int ichMin, int ichLim, const void * pv, int cb,
	uint grfdoc)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	AssertPtrSize(pv, cb);

	if (ichMin >= ichLim)
		return;

	GetTxtPropMap(spt, true)->SetStr(ichMin, ichLim, m_bsh.GetByteStr(pv, cb));
	AddEdit(ichMin, ichLim, ichLim - ichMin);
	BroadCastInval(grfdoc);
}


/*----------------------------------------------------------------------------------------------
	This forces the properties over the entire range to be exactly (pv, cb).
	If fExpand is false, this sets the properties on paragraphs totally enclosed by
	[ichMin, ichLim). If fExpand is true, this sets the properties on all paragraphs that
	intersect [ichMin, ichLim).
----------------------------------------------------------------------------------------------*/
void RichTextDoc::SetParaProps(int ichMin, int ichLim, const void * pv, int cb,
	int * pichMin, int * pichLim, bool fExpand, uint grfdoc)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	AssertPtrSize(pv, cb);

	if (fExpand)
	{
		ichMin = IchMinPara(ichMin);
		if (!FMinPara(ichLim))
			ichLim = IchLimPara(ichLim);
	}

	if (!m_qtpmPara)
		m_qtpmPara.Create();

	m_qtpmPara->SetStr(ichMin, ichLim, m_bsh.GetByteStr(pv, cb));
	AddEdit(ichMin, ichLim, ichLim - ichMin);
	BroadCastInval(grfdoc);
}


void RichTextDoc::SetParaStrProp(int spt, int ichMin, int ichLim, const void * pv, int cb,
	int * pichMin, int * pichLim, bool fExpand, uint grfdoc)
{
}


/*----------------------------------------------------------------------------------------------
	Apply an individual character property to a range.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::ApplyCharProp(int ichMin, int ichLim, int scp, int nVal1, int nVal2,
	bool fDel, uint grfdoc)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());

	ApplyScalarPropCore(m_qtpmChar, ichMin, ichLim, scp, nVal1, nVal2, fDel, grfdoc);
}


/*----------------------------------------------------------------------------------------------
	Apply an individual character property to a range.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::ApplyParaProp(int ichMin, int ichLim, int scp, int nVal1, int nVal2,
	bool fDel, uint grfdoc)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());

	GetParaBounds(&ichMin, &ichLim, true);
	ApplyScalarPropCore(m_qtpmPara, ichMin, ichLim, scp, nVal1, nVal2, fDel, grfdoc);
}


/*----------------------------------------------------------------------------------------------
	Apply an individual character property to a range.
	REVIEW ShonK: Should we just call ApplyScalarPropsCore?
----------------------------------------------------------------------------------------------*/
void RichTextDoc::ApplyScalarPropCore(TxtPropMap * ptpm, int ichMin, int ichLim, int scp,
	int nVal1, int nVal2, bool fDel, uint grfdoc)
{
	AssertObj(this);
	AssertPtr(ptpm);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());

	int cbData = CbScpData(scp);
	int ichMinCur, ichLimCur, ich;
	int nVal1Cur, nVal2Cur;

	if (!fDel)
	{
		// Normalize the data.
		if (cbData <= isizeof(int))
			nVal2 = 0;
		if (cbData == 1)
			nVal1 &= 0x000000FF;
		else if (cbData == 2)
			nVal1 &= 0x0000FFFF;
	}

	TextPropGroup tpg;
	int ichMinInval, ichLimInval;

	ichMinInval = ichLim;
	ichLimInval = ichLim;

	for (ich = ichMin; ich < ichLim; )
	{
		ByteString * pbst = FetchStr(ptpm, ich, &ichMinCur, &ichLimCur);
		if (!FGetTextPropValue(scp, pbst->Prgb(), pbst->Size(), &nVal1Cur, &nVal2Cur) ==
				!fDel ||
			!fDel && (nVal1Cur != nVal1 || nVal2Cur != nVal2))
		{
			tpg.Set(pbst->Prgb(), pbst->Size());
			if (fDel)
				tpg.Del(scp);
			else
				tpg.Add(scp, nVal1, nVal2);

			if (ich < ichMinInval)
				ichMinInval = ich;
			ichLimInval = Min(ichLim, ichLimCur);
			ptpm->SetStr(ich, ichLimInval, m_bsh.GetByteStr(tpg.Prgb(), tpg.Size()));
		}

		ich = ichLimCur;
	}

	if (ichMinInval < ichLimInval)
		AddEdit(ichMinInval, ichLimInval, ichLimInval - ichMinInval);
	BroadCastInval(grfdoc);
}


/*----------------------------------------------------------------------------------------------
	Apply the scalar property changes to the character formatting on the given range.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::ApplyCharProps(int ichMin, int ichLim, const ScalarPropDelta * prgspd,
	int cspd, uint grfdoc)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	AssertArray(prgspd, cspd);

	ApplyScalarPropsCore(m_qtpmChar, ichMin, ichLim, prgspd, cspd, grfdoc);
}


/*----------------------------------------------------------------------------------------------
	Apply the scalar property changes to the character formatting on the given range.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::ApplyParaProps(int ichMin, int ichLim, const ScalarPropDelta * prgspd,
	int cspd, uint grfdoc)
{
	AssertObj(this);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	AssertArray(prgspd, cspd);

	GetParaBounds(&ichMin, &ichLim, true);
	ApplyScalarPropsCore(m_qtpmPara, ichMin, ichLim, prgspd, cspd, grfdoc);
}


/*----------------------------------------------------------------------------------------------
	Apply the scalar property changes to the character formatting on the given range.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::ApplyScalarPropsCore(TxtPropMap * ptpm, int ichMin, int ichLim,
	const ScalarPropDelta * prgspd, int cspd, uint grfdoc)
{
	AssertObj(this);
	AssertPtr(ptpm);
	Assert((uint)ichMin <= (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	AssertArray(prgspd, cspd);

	if (cspd <= 0)
		return;

	int ichMinCur, ichLimCur, ich;

	TextPropGroup tpg;
	int ichMinInval, ichLimInval;

	ichMinInval = ichLim;
	ichLimInval = ichLim;

	for (ich = ichMin; ich < ichLim; )
	{
		ByteString * pbst = FetchStr(ptpm, ich, &ichMinCur, &ichLimCur);

		tpg.Set(pbst->Prgb(), pbst->Size());
		tpg.Apply(prgspd, cspd);

		if (tpg.Size() != pbst->Size() || 0 != memcmp(tpg.Prgb(), pbst->Prgb(), tpg.Size()))
		{
			ByteString * pbstNew = m_bsh.GetByteStr(tpg.Prgb(), tpg.Size());
			if (ich < ichMinInval)
				ichMinInval = ich;
			ichLimInval = Min(ichLim, ichLimCur);
			ptpm->SetStr(ich, ichLimInval, pbstNew);
		}

		ich = ichLimCur;
	}

	if (ichMinInval < ichLimInval)
		AddEdit(ichMinInval, ichLimInval, ichLimInval - ichMinInval);
	BroadCastInval(grfdoc);
}


// TODO ShonK: implement undo.
void RichTextDoc::SuspendUndo(void)
{
}


void RichTextDoc::ResumeUndo(void)
{
}


void RichTextDoc::SetUndo(int ich1, int ich2, int ccpIns)
{
}


void RichTextDoc::CancelUndo(void)
{
}


void RichTextDoc::CommitUndo(void)
{
}


void RichTextDoc::BumpCombineUndo(void)
{
}


/*----------------------------------------------------------------------------------------------
	Register an edit sink. Just attach it to the linked list of sinks.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::RegisterSink(TextEditSink * ptes)
{
	AssertObj(this);
	AssertPtr(ptes);

	ptes->Link(&m_ptesFirst);

	// Mark the TextEditSink as already having been notified, in case we're currently
	// sending notifications.
	ptes->m_fNotified = true;

	// Tell the sink it's been attached.
	ptes->Attach();
}


/*----------------------------------------------------------------------------------------------
	Send edit notifications to all the sinks. If grfdoc is kfdocNil (0), no notifications are
	sent.
----------------------------------------------------------------------------------------------*/
void RichTextDoc::BroadCastInval(uint grfdoc)
{
	AssertObj(this);
	Assert(0 <= m_ichMinEdit && m_ichMinEdit <= m_ichLimEdit &&
		m_ichMinEdit <= m_dichEdit + m_ichLimEdit && m_dichEdit + m_ichLimEdit <= IchMac());

	// TODO ShonK: Mark the document dirty
	// SetDirty();

	if (kfdocNil == grfdoc)
		return;

	TextEditSink * ptes;
	int ichMin = m_ichMinEdit;
	int ichLim = m_ichLimEdit;
	int cchIns = m_ichLimEdit - m_ichMinEdit + m_dichEdit;

	m_ichMinEdit = 0;
	m_ichLimEdit = 0;
	m_dichEdit = 0;

	for (ptes = m_ptesFirst; ptes; ptes = ptes->m_pobjNext)
		ptes->m_fNotified = false;

	for (ptes = m_ptesFirst; ptes; )
	{
		if (!ptes->m_fNotified)
		{
			ptes->m_fNotified = true;
			ptes->Edit(this, ichMin, ichLim, cchIns, grfdoc);

			// Start over in case the linked list was modified.
			ptes = m_ptesFirst;
		}
		else
			ptes = ptes->m_pobjNext;
	}
}

