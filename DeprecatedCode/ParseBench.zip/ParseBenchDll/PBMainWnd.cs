// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: PBMainWnd.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------

using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using SIL.FieldWorks.Common.Utils;

//for open project dlg
//using SIL.FieldWorks.Linguistics.Common;
//using CmnFWDlgs;
//using FwKernelLib;

using SIL.FieldWorks.Common.Framework;
using SIL.FieldWorks;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.LangProj.Generated;
using SIL.FieldWorks.Common.Controls;
using SIL.FieldWorks.Common.RootSites;

namespace SIL.FieldWorks.WordWorks.ParseBench
{

	/// <summary>
	/// Summary description for PBMainWnd.
	/// </summary>
	public class PBMainWnd : System.Windows.Forms.Form, IFwMainWnd
	{
		#region Data members

		/// <summary></summary>
		protected FdoCache m_cache;
		protected ParserHandler m_parserHandler;
		protected LogWindow m_log;
		protected WordListController m_wordListController;
		protected AnalysisViewController m_analysisViewController;
		protected WordSourceTreeController m_wordSourceTreeController;
		protected WordSourceSideBarController m_wordSourceSidebarController;
		protected SIL.FieldWorks.Common.Controls.SideBarTab m_sidebarTabWordSets;
		

		private System.ComponentModel.IContainer components;

		private System.Windows.Forms.Panel panelGroupsNRight;
		private System.Windows.Forms.Panel panelWordsNRight;
		private System.Windows.Forms.TreeView tvGroups;
		private System.Windows.Forms.MenuItem mnuImportWords;
		private System.Windows.Forms.MainMenu mainMenu1;
		private SIL.FieldWorks.Common.Controls.SideBar sideBar1;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem mnuChooseProject;
		private System.Windows.Forms.Timer m_timerParserStatus;
		private System.Windows.Forms.StatusBarPanel m_panelMisc;
		private System.Windows.Forms.MenuItem mnuExit;
		private System.Windows.Forms.ListView lvWords;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private AxSHDocVw.AxWebBrowser browser;
		private System.Windows.Forms.StatusBarPanel m_panelParserActivity;
		private System.Windows.Forms.StatusBarPanel m_panelParserQueue;
		private System.Windows.Forms.MenuItem menuFile;
		private System.Windows.Forms.MenuItem menuParser;
		private System.Windows.Forms.MenuItem mnuReloadParser;
		private System.Windows.Forms.ImageList m_sideBarImages;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem mnuParseGroup;
		private System.Windows.Forms.MenuItem mnuParseWord;
		private System.Windows.Forms.MenuItem menuEdit;
		private System.Windows.Forms.MenuItem mnuDeleteWord;
		private System.Windows.Forms.MenuItem menuView;
		private System.Windows.Forms.MenuItem mnuRefresh;
		private System.Windows.Forms.MenuItem mnuUndo;
		private System.Windows.Forms.MenuItem mnuRedo;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem mnuNewWord;
		private System.Windows.Forms.Timer m_timerStartupParser;
		private System.Windows.Forms.MenuItem mnuPauseParser;
		private System.Windows.Forms.MenuItem mnuStopParser;
		private System.Windows.Forms.MenuItem mnuStartParser;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem mnuTraceWord;
		#endregion

		#region IFwMainWnd implementation
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Gets the currently active view (client window).
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public virtual IRootSite ActiveView
		{
			get
			{
				// TODO WW team: implement this if needed (see FwMainWnd.ActiveView for example)
				return null;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called when a window is finished being created and completely initialized.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public void OnFinishedInit()
		{
		}
		
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// The window rectangle (DesktopBounds) that is persisted in the registry.
		/// Use this property when trying to set the DesktopBounds for a new window.
		/// (Simply setting DesktopBounds will not give the desired result in the Show method.)
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public Rectangle PersistentDesktopBounds
		{
			set
			{
				DesktopBounds = value;
				//	m_persistence.SaveWindowPosition(SettingsKey);
			}
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Returns the NormalStateDesktopBounds property from the persistence object.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public Rectangle NormalStateDesktopBounds
		{
			get
			{
				return new Rectangle(Location, Size);
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public string ApplicationName
		{
			get {return string.Empty;}
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Gets or sets the data objects cache.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public virtual FdoCache Cache
		{
			get
			{
				return m_cache;
			}
			set
			{
				if (m_cache != null)
				{
					// TODO TomB: Probably all kinds of stuff needs to be done if the connection is
					// being changed.
					Debug.Assert(false);
				}
				m_cache = value;
				this.Text = "ParseBench "+value.LanguageProject.Name.AnalysisDefaultWritingSystem;
			}
		}
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Enable or disable this window.
		/// </summary>
		/// 
		/// <param name="fEnable">Enable (true) or disable (false).</param>
		/// -----------------------------------------------------------------------------------
		public void EnableWindow (bool fEnable)
		{
			// TODO TomB: Implement this.
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Save all data in this window, ending the current transaction.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public void SaveData()
		{
			// REVIEW TeTeam:
			// If this class someday implements record-based stuff, we may need to updated the
			// DateModified in the records. Ref RecMainWnd::SaveData().

			this.Cache.Save();
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Create the client windows and add corresponding stuff to the sidebar, View menu,
		/// etc.
		/// </summary>
		/// <remarks>Required by IFwMainWnd.</remarks>
		/// -----------------------------------------------------------------------------------
		public void InitAndShowClient()
		{
			m_parserHandler = new ParserHandler(m_cache, m_log);

			//create the controllers which handle the various panes in the main window
			m_wordSourceSidebarController= new WordSourceSideBarController(m_cache, m_sidebarTabWordSets, m_parserHandler);
			m_wordSourceTreeController = new WordSourceTreeController(m_cache, tvGroups);	
			m_wordListController = new WordListController(lvWords, m_parserHandler, m_cache);
			m_analysisViewController = new AnalysisViewController(m_cache, browser);

			//wire up menu items to these controllers
			mnuImportWords.Click += new System.EventHandler(m_wordSourceSidebarController.mnuImportWords_Click);

			//parser menu
			menuParser.Popup += new System.EventHandler(m_parserHandler.menuParser_Popup);
			//mnuParseInBgnd.Click += new System.EventHandler(m_parserHandler.mnuParseInBgnd_Click);
			//mnRestartParser.Click += new System.EventHandler(m_parserHandler.mnuRestartParser_Click);
			mnuReloadParser.Click += new System.EventHandler(m_parserHandler.mnuReloadParser_Click);

			mnuStartParser.Click += new System.EventHandler(m_parserHandler.mnuStartParser_Click);
			mnuStopParser.Click += new System.EventHandler(m_parserHandler.mnuStopParser_Click);
			mnuPauseParser.Click += new System.EventHandler(m_parserHandler.mnuPauseParser_Click);
			
			//wire up the AnalysisViewController to the WordListController,
			//	so that the view of the analysis will change when the user selects a different word
			m_wordListController.SelectionChanged += new FwSelectionChangedEventHandler(m_analysisViewController.OnWordSelectionChanged);
			m_wordListController.StatusChanged += new FwSimpleMessageEventHandler(this.OnWordListControllerStatusChanged);
			mnuDeleteWord.Click += new System.EventHandler(m_wordListController.OnDeleteSelectedWord);

			m_wordSourceSidebarController.SelectionChanged +=
				new ParseBench.WordSourceSelectionChangedEventHandler(m_wordSourceTreeController.OnWordSourceSelectionChanged);

			//the tree of queries is not refill every time a different WordSource is chosen in the sidebar.
			//therefore, we just tell it that now is to fine time to fill up the tree, and then it will never be refilled.
			m_wordSourceTreeController.FillGroupTree();

			//must follow the fill, 'cause the sidebar isn't setup yet to provide the base input source
			m_wordSourceTreeController.SelectionChanged +=
				new ParseBench.WordSourceSelectionChangedEventHandler(m_wordListController.OnWordSourceSelectionChanged);

			//finally, we fill in the sidebar tab which shows the WordformInventory and list of WfiWordSets in the language project
			//this will get the ball rolling, starting off the chain of events which will fill each of the panels
			m_wordSourceSidebarController.FillWordSetList();
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Occurs when the user changed the definition of a style.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">An <see cref="EventArgs"/> that contains the event data.</param>
		/// ------------------------------------------------------------------------------------
		public void  OnStyleSheetChanged(object sender, EventArgs e)
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// This begins the syncroization process for an application so other applications and
		/// their views will reflect changes made to the DB from the current application.
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public virtual void BeginSyncronization(SyncInfo sync)
		{
			// TODO: Implement it. This is copied from TE.
			//Cache.StoreSync(TeApp.AppGuid, sync);
			//FwApp.App.Synchronize(sync, Cache);
		}
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called just before a window syncronizes it's views with DB changes (e.g. when an
		/// undo or redo command is issued).
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public virtual bool PreSynchronize(SyncInfo sync)
		{
			// TODO: Implement it. This is copied from TE.
			return true;
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called when a window syncronizes it's views with DB changes (e.g. when an undo or
		/// redo command is issued).
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public virtual bool Synchronize(SyncInfo sync)
		{
			// TODO: Implement it. This is copied from TE.
			//Updating views in all windows.
			//FwApp.App.RefreshAllViews();
			return true;
		}

		#endregion // IFwMainWnd implementation

		#region Construction and disposal

		public PBMainWnd(FdoCache cache, Form wndCopyFrom):base() //:  base(cache, wndCopyFrom)
		{

			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			JoinWithSplitter(sideBar1, panelGroupsNRight);
			JoinWithSplitter(tvGroups, panelWordsNRight);


			//todo: this isn't working
			// and including it makes it come up next to the previous
			// one, making that one appear twice as wide but only 
			// left side works.
			//JoinWithSplitter(lvWords, browser);
			lvWords.Dock = System.Windows.Forms.DockStyle.Left;
			browser.Dock = System.Windows.Forms.DockStyle.Fill;

			//leave this after InitializeComponent()
			Cache = cache;

			//combat forms designer elephantitous
			tvGroups.Width = 100;
			lvWords.Width = 150;
			//splitterFw.Width = 10;
			statusBar1.Height = 16;
			sideBar1.Width = 200;

			//hide menus
	
			//panelGroupsNRight.Dock = System.Windows.Forms.DockStyle.Fill;

	
			// Customize SideBar
			// 
			m_sidebarTabWordSets = new SIL.FieldWorks.Common.Controls.SideBarTab();
			m_sidebarTabWordSets.Enabled = true;
			m_sidebarTabWordSets.InitialLargeIcons = false;
			m_sidebarTabWordSets.Name = "TabWordSets";
			m_sidebarTabWordSets.Title = "Word Sets";
			sideBar1.Tabs.Insert(0, m_sidebarTabWordSets);
			// REVIEW JohnH(RandyR): Shouldn't this be added to the main set of controls?
			// When it is added, the list shows nothing.
			//Controls.Add(m_sidebarTabWordSets);

			statusBar1.ShowPanels = true;

			m_log = new LogWindow();
			m_log.WriteLine("This window contains errors produced by the parser.");
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				CleanUp();
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#endregion // Construction and disposal

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(PBMainWnd));
			System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																								new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "lvwords", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.ScrollBar, new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, -1);
			this.panelGroupsNRight = new System.Windows.Forms.Panel();
			this.panelWordsNRight = new System.Windows.Forms.Panel();
			this.browser = new AxSHDocVw.AxWebBrowser();
			this.lvWords = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.tvGroups = new System.Windows.Forms.TreeView();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuFile = new System.Windows.Forms.MenuItem();
			this.mnuChooseProject = new System.Windows.Forms.MenuItem();
			this.mnuImportWords = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.mnuExit = new System.Windows.Forms.MenuItem();
			this.menuEdit = new System.Windows.Forms.MenuItem();
			this.mnuUndo = new System.Windows.Forms.MenuItem();
			this.mnuRedo = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.mnuNewWord = new System.Windows.Forms.MenuItem();
			this.mnuDeleteWord = new System.Windows.Forms.MenuItem();
			this.menuView = new System.Windows.Forms.MenuItem();
			this.mnuRefresh = new System.Windows.Forms.MenuItem();
			this.menuParser = new System.Windows.Forms.MenuItem();
			this.mnuParseGroup = new System.Windows.Forms.MenuItem();
			this.mnuParseWord = new System.Windows.Forms.MenuItem();
			this.mnuTraceWord = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.mnuReloadParser = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.mnuStartParser = new System.Windows.Forms.MenuItem();
			this.mnuStopParser = new System.Windows.Forms.MenuItem();
			this.mnuPauseParser = new System.Windows.Forms.MenuItem();
			this.sideBar1 = new SIL.FieldWorks.Common.Controls.SideBar();
			this.m_sideBarImages = new System.Windows.Forms.ImageList(this.components);
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.m_panelMisc = new System.Windows.Forms.StatusBarPanel();
			this.m_panelParserActivity = new System.Windows.Forms.StatusBarPanel();
			this.m_panelParserQueue = new System.Windows.Forms.StatusBarPanel();
			this.m_timerParserStatus = new System.Windows.Forms.Timer(this.components);
			this.m_timerStartupParser = new System.Windows.Forms.Timer(this.components);
			this.panelGroupsNRight.SuspendLayout();
			this.panelWordsNRight.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.browser)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.m_panelMisc)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.m_panelParserActivity)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.m_panelParserQueue)).BeginInit();
			this.SuspendLayout();
			// 
			// panelGroupsNRight
			// 
			this.panelGroupsNRight.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.panelGroupsNRight.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.panelGroupsNRight.Controls.AddRange(new System.Windows.Forms.Control[] {
																							this.panelWordsNRight,
																							this.tvGroups});
			this.panelGroupsNRight.Location = new System.Drawing.Point(183, -176);
			this.panelGroupsNRight.Name = "panelGroupsNRight";
			this.panelGroupsNRight.Size = new System.Drawing.Size(913, 672);
			this.panelGroupsNRight.TabIndex = 12;
			// 
			// panelWordsNRight
			// 
			this.panelWordsNRight.BackColor = System.Drawing.SystemColors.Desktop;
			this.panelWordsNRight.Controls.AddRange(new System.Windows.Forms.Control[] {
																						   this.browser,
																						   this.lvWords});
			this.panelWordsNRight.Location = new System.Drawing.Point(184, 192);
			this.panelWordsNRight.Name = "panelWordsNRight";
			this.panelWordsNRight.Size = new System.Drawing.Size(560, 364);
			this.panelWordsNRight.TabIndex = 12;
			// 
			// browser
			// 
			this.browser.ContainingControl = this;
			this.browser.Enabled = true;
			this.browser.Location = new System.Drawing.Point(168, 122);
			this.browser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("browser.OcxState")));
			this.browser.Size = new System.Drawing.Size(240, 120);
			this.browser.TabIndex = 3;
			// 
			// lvWords
			// 
			this.lvWords.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.lvWords.BackColor = System.Drawing.SystemColors.Window;
			this.lvWords.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																					  this.columnHeader1});
			this.lvWords.HideSelection = false;
			this.lvWords.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
																					listViewItem1});
			this.lvWords.Location = new System.Drawing.Point(24, 80);
			this.lvWords.MultiSelect = false;
			this.lvWords.Name = "lvWords";
			this.lvWords.Size = new System.Drawing.Size(109, 240);
			this.lvWords.TabIndex = 0;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Form";
			this.columnHeader1.Width = 117;
			// 
			// tvGroups
			// 
			this.tvGroups.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.tvGroups.HideSelection = false;
			this.tvGroups.ImageIndex = -1;
			this.tvGroups.Location = new System.Drawing.Point(32, 240);
			this.tvGroups.Name = "tvGroups";
			this.tvGroups.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
																				 new System.Windows.Forms.TreeNode("tvgroups")});
			this.tvGroups.SelectedImageIndex = -1;
			this.tvGroups.Size = new System.Drawing.Size(144, 244);
			this.tvGroups.TabIndex = 14;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuFile,
																					  this.menuEdit,
																					  this.menuView,
																					  this.menuParser});
			// 
			// menuFile
			// 
			this.menuFile.Index = 0;
			this.menuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mnuChooseProject,
																					 this.mnuImportWords,
																					 this.menuItem4,
																					 this.mnuExit});
			this.menuFile.Text = "File";
			// 
			// mnuChooseProject
			// 
			this.mnuChooseProject.Index = 0;
			this.mnuChooseProject.Text = "Choose Project...";
			this.mnuChooseProject.Click += new System.EventHandler(this.mnuChooseProject_Click);
			// 
			// mnuImportWords
			// 
			this.mnuImportWords.Index = 1;
			this.mnuImportWords.Text = "Import Words...";
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 2;
			this.menuItem4.Text = "-";
			// 
			// mnuExit
			// 
			this.mnuExit.Index = 3;
			this.mnuExit.Text = "E&xit";
			this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
			// 
			// menuEdit
			// 
			this.menuEdit.Index = 1;
			this.menuEdit.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mnuUndo,
																					 this.mnuRedo,
																					 this.menuItem3,
																					 this.mnuNewWord,
																					 this.mnuDeleteWord});
			this.menuEdit.Text = "&Edit";
			this.menuEdit.Popup += new System.EventHandler(this.menuEditPopup);
			// 
			// mnuUndo
			// 
			this.mnuUndo.Index = 0;
			this.mnuUndo.Shortcut = System.Windows.Forms.Shortcut.CtrlZ;
			this.mnuUndo.Text = "&Undo";
			this.mnuUndo.Click += new System.EventHandler(this.menuUndo_Click);
			// 
			// mnuRedo
			// 
			this.mnuRedo.Index = 1;
			this.mnuRedo.Shortcut = System.Windows.Forms.Shortcut.CtrlY;
			this.mnuRedo.Text = "&Redo";
			this.mnuRedo.Click += new System.EventHandler(this.menuRedo_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "-";
			// 
			// mnuNewWord
			// 
			this.mnuNewWord.Index = 3;
			this.mnuNewWord.Text = "&Add New Word...";
			this.mnuNewWord.Click += new System.EventHandler(this.mnuNewWord_Click);
			// 
			// mnuDeleteWord
			// 
			this.mnuDeleteWord.Index = 4;
			this.mnuDeleteWord.Text = "&Delete Word";
			// 
			// menuView
			// 
			this.menuView.Index = 2;
			this.menuView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mnuRefresh});
			this.menuView.Text = "&View";
			// 
			// mnuRefresh
			// 
			this.mnuRefresh.Index = 0;
			this.mnuRefresh.Shortcut = System.Windows.Forms.Shortcut.F5;
			this.mnuRefresh.Text = "&Refresh";
			this.mnuRefresh.Click += new System.EventHandler(this.mnuRefresh_Click);
			// 
			// menuParser
			// 
			this.menuParser.Index = 3;
			this.menuParser.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.mnuParseGroup,
																					   this.mnuParseWord,
																					   this.mnuTraceWord,
																					   this.menuItem2,
																					   this.mnuReloadParser,
																					   this.menuItem6,
																					   this.mnuStartParser,
																					   this.mnuStopParser,
																					   this.mnuPauseParser});
			this.menuParser.Text = "&Parser";
			// 
			// mnuParseGroup
			// 
			this.mnuParseGroup.Index = 0;
			this.mnuParseGroup.Text = "Parse Current &Group";
			this.mnuParseGroup.Click += new System.EventHandler(this.mnuParseGroup_Click);
			// 
			// mnuParseWord
			// 
			this.mnuParseWord.Index = 1;
			this.mnuParseWord.Text = "Parse Current &Word";
			this.mnuParseWord.Click += new System.EventHandler(this.mnuParseWord_Click);
			// 
			// mnuTraceWord
			// 
			this.mnuTraceWord.Index = 2;
			this.mnuTraceWord.Text = "&Trace Current Word";
			this.mnuTraceWord.Click += new System.EventHandler(this.mnuTraceWord_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 3;
			this.menuItem2.Text = "-";
			// 
			// mnuReloadParser
			// 
			this.mnuReloadParser.Index = 4;
			this.mnuReloadParser.Text = "&Reload Grammar  Lexicon";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 5;
			this.menuItem6.Text = "-";
			// 
			// mnuStartParser
			// 
			this.mnuStartParser.Index = 6;
			this.mnuStartParser.Text = "&Start Parser";
			// 
			// mnuStopParser
			// 
			this.mnuStopParser.Index = 7;
			this.mnuStopParser.Text = "&Stop Parser";
			// 
			// mnuPauseParser
			// 
			this.mnuPauseParser.Index = 8;
			this.mnuPauseParser.Text = "&Pause Parser";
			// 
			// sideBar1
			// 
			this.sideBar1.DockPadding.All = 1;
			this.sideBar1.ImageListLarge = this.m_sideBarImages;
			this.sideBar1.ImageListSmall = this.m_sideBarImages;
			this.sideBar1.Name = "sideBar1";
			this.sideBar1.Size = new System.Drawing.Size(110, 545);
			this.sideBar1.TabIndex = 13;
			// 
			// m_sideBarImages
			// 
			this.m_sideBarImages.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.m_sideBarImages.ImageSize = new System.Drawing.Size(16, 16);
			this.m_sideBarImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("m_sideBarImages.ImageStream")));
			this.m_sideBarImages.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(110, 529);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.m_panelMisc,
																						  this.m_panelParserActivity,
																						  this.m_panelParserQueue});
			this.statusBar1.Size = new System.Drawing.Size(666, 16);
			this.statusBar1.TabIndex = 14;
			this.statusBar1.Text = "m_statusBar";
			// 
			// m_panelMisc
			// 
			this.m_panelMisc.MinWidth = 120;
			this.m_panelMisc.Text = "statusBarPanel1";
			this.m_panelMisc.Width = 120;
			// 
			// m_panelParserActivity
			// 
			this.m_panelParserActivity.MinWidth = 200;
			this.m_panelParserActivity.Width = 300;
			// 
			// m_panelParserQueue
			// 
			this.m_panelParserQueue.MinWidth = 100;
			// 
			// m_timerParserStatus
			// 
			this.m_timerParserStatus.Enabled = true;
			this.m_timerParserStatus.Interval = 1000;
			this.m_timerParserStatus.Tick += new System.EventHandler(this.m_timerParserStatus_Tick);
			// 
			// m_timerStartupParser
			// 
			this.m_timerStartupParser.Enabled = true;
			this.m_timerStartupParser.Interval = 10000;
			this.m_timerStartupParser.Tick += new System.EventHandler(this.m_timerStartupParser_Tick);
			// 
			// PBMainWnd
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(776, 545);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.statusBar1,
																		  this.sideBar1,
																		  this.panelGroupsNRight});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "PBMainWnd";
			this.Text = "ParseBench";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.PBMainWnd_Closing);
			this.panelGroupsNRight.ResumeLayout(false);
			this.panelWordsNRight.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.browser)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.m_panelMisc)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.m_panelParserActivity)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.m_panelParserQueue)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region menu event handlers

		private void mnuTraceWord_Click(object sender, System.EventArgs e)
		{
			try
			{
				int hvo = m_wordListController.SelectedWordformHvo;
				if(hvo >0)
				{
					m_parserHandler.TraceWordform(hvo);
				}
				else
					MessageBox.Show("Select a word first.");
			}
			catch(Exception err)
			{
				MessageBox.Show("The word could not be Parsed: " + err.Message);
			}
		}

		private void mnuParseWord_Click(object sender, System.EventArgs e)
		{
			try
			{
				int hvo = m_wordListController.SelectedWordformHvo;
				if(hvo >0)
				{
					m_parserHandler.UpdateWordformAsap (hvo);
				}
				else
					MessageBox.Show("Select a word first.");
			}
			catch(Exception err)
			{
				MessageBox.Show("The word could not be Parsed: " + err.Message);
			}
			//todo: need refresh the analysis display of the word, but only after it has been updated
			//RefreshDataDisplay();
		}
		private void mnuRefresh_Click(object sender, System.EventArgs e)
		{
//			RefreshDataDisplay();
			m_analysisViewController.Refresh();
		}

		private void mnuNewWord_Click(object sender, System.EventArgs e)
		{
			NewWordDialog dlg = new NewWordDialog();
			if(DialogResult.OK ==  dlg.ShowDialog())
			{	
				string form = dlg.sWord.Text.Trim();
				// TODO: what else can we do to make sure this is a good form?
				if (form.Length == 0)
					return;

				LanguageProject lp = m_cache.LanguageProject;
				WfiWordform word = lp.WordformInventoryOA.FindOrCreateWordform(dlg.sWord.Text, lp.DefaultVernacularWritingSystem);
				m_wordSourceSidebarController.AddWordToCurrentList(word.Hvo);
				m_wordListController.RefillAndSelectWord(form);
			}
		}


		private void menuEditPopup(object sender, System.EventArgs e)
		{
			mnuUndo.Enabled =m_cache.CanUndo;
			mnuRedo.Enabled = m_cache.CanRedo;
			if (m_cache.CanUndo)
			{
				mnuUndo.Text = m_cache.UndoText;
			}
			if (m_cache.CanRedo)
			{
				mnuRedo.Text = m_cache.RedoText;
			}
		
		}

		private void menuUndo_Click(object sender, System.EventArgs e)
		{
			m_cache.Undo();
			RefreshDataDisplay();
		}

		private void menuRedo_Click(object sender, System.EventArgs e)
		{
			m_cache.Redo ();
			RefreshDataDisplay();
		}


		private void mnuParseGroup_Click(object sender, System.EventArgs e)
		{
			WordSource source =m_wordSourceTreeController.GetSelectedWordSource();
			if (source != null)
				m_parserHandler.UpdateWordforms(source.GetReader());
		}

		private void mnuAbout_Click(object sender, System.EventArgs e)
		{
			SIL.FieldWorks.FwCoreDlgs.FwHelpAbout x = new SIL.FieldWorks.FwCoreDlgs.FwHelpAbout();
			x.ShowDialog();
		}

		private void mnuSave_Click(object sender, System.EventArgs e)
		{
			if (m_cache != null)
				m_cache.Save();
		}

		
		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			m_log.Show();
		}


		private void mnuParserReload_Click(object sender, System.EventArgs e)
		{
			m_parserHandler.Reload();
		}
	

		#endregion

		#region Miscellaneous methods

		private void JoinWithSplitter(Control left, Control right)
		{
			Debug.Assert(left.Parent == right.Parent);
			Control p = left.Parent;
			p.SuspendLayout();
			p.Controls.Remove(left);
			p.Controls.Remove(right);
			Splitter s = new System.Windows.Forms.Splitter();
			s.Dock = System.Windows.Forms.DockStyle.Left;
			s.Visible = true;
			s.BackColor = System.Drawing.SystemColors.Control;
			left.Dock = System.Windows.Forms.DockStyle.Left;
			right.Dock = System.Windows.Forms.DockStyle.Fill;
			p.Controls.AddRange(new System.Windows.Forms.Control[] { right, s, left });
			p.ResumeLayout(true);
		}

		protected void CleanUp()
		{
			if(m_parserHandler != null)
			{
				menuParser.Popup -= new System.EventHandler(m_parserHandler.menuParser_Popup);
				mnuReloadParser.Click -= new System.EventHandler(m_parserHandler.mnuReloadParser_Click);
				mnuStartParser.Click -= new System.EventHandler(m_parserHandler.mnuStartParser_Click);
				mnuStopParser.Click -= new System.EventHandler(m_parserHandler.mnuStopParser_Click);
				mnuPauseParser.Click -= new System.EventHandler(m_parserHandler.mnuPauseParser_Click);
				m_parserHandler.Dispose();
				m_parserHandler = null;
			}
			if (m_wordListController != null)
			{
				m_wordListController.StatusChanged -=
					new FwSimpleMessageEventHandler(OnWordListControllerStatusChanged);
				mnuDeleteWord.Click -= new System.EventHandler(m_wordListController.OnDeleteSelectedWord);
				if (m_wordSourceTreeController != null)
				{
					m_wordSourceTreeController.SelectionChanged -=
						new ParseBench.WordSourceSelectionChangedEventHandler(m_wordListController.OnWordSourceSelectionChanged);
				}
				if (m_analysisViewController != null)
				{
					m_wordListController.SelectionChanged -=
						new FwSelectionChangedEventHandler(m_analysisViewController.OnWordSelectionChanged);
				}
				m_wordListController.Dispose();
				m_wordListController = null;
			}
			if (m_analysisViewController != null)
			{
				m_analysisViewController.Dispose();
				m_analysisViewController = null;
			}
			if (m_wordSourceTreeController != null)
			{
				if (m_wordSourceSidebarController != null)
				{
					m_wordSourceSidebarController.SelectionChanged -=
						new ParseBench.WordSourceSelectionChangedEventHandler(m_wordSourceTreeController.OnWordSourceSelectionChanged);
				}
				m_wordSourceTreeController.Dispose();
				m_wordSourceTreeController = null;
			}
			if (m_wordSourceSidebarController != null)
			{
				mnuImportWords.Click -= new System.EventHandler(m_wordSourceSidebarController.mnuImportWords_Click);
				m_wordSourceSidebarController.Dispose();
				m_wordSourceSidebarController = null;
			}
			if (m_sidebarTabWordSets != null)
			{
				m_sidebarTabWordSets.Dispose();
				m_sidebarTabWordSets = null;
			}
			if (m_log != null)
			{
				m_log.Dispose();
				m_log = null;
			}
			if (m_cache != null)
			{
				if (FwApp.App != null)
					FwApp.App.RemoveWindow(this);
				m_cache = null;
			}
		}

		//hack
		private void mnuChooseProject_Click(object sender, System.EventArgs e)
		{
			if (((ParseBenchApp)FwApp.App).ChooseProject())
				this.Close();
		}
		
		public void OnWordListControllerStatusChanged(Object sender,FwSimpleStatusEventArgs e)
		{
			m_panelMisc.Text = e.Message;
		}


		private void toolBar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			switch(e.Button.Text)
			{
				case "New Word": MessageBox.Show("New");
					break;
			}
		}

		private void RefreshDataDisplay()
		{
			//m_wordSourceTreeController.FillGroupTree();//might not be necessary
			m_wordSourceSidebarController.FillWordSetList();

			//WordformGroup.FillGroupTree (tvGroups, GetConnectionString (), m_cache);

			try
			{
				//m_wordListController.Refresh(); 
			}
			catch (Exception error)
			{
				MessageBox.Show ("Could not Refresh " +error.Message);
				return;
			}
		}

		private void mnuExit_Click(object sender, System.EventArgs e)
		{
			//		CleanUp();
			FwApp.App.OnFileExit(sender);
		}


		private void m_timerParserStatus_Tick(object sender, System.EventArgs e)
		{
			if (m_parserHandler!= null)
			{
				m_panelParserActivity.Text = "Parser: "+m_parserHandler.GetParserActivityString();
				m_panelParserQueue.Text = m_parserHandler.GetParserQueueString();
			}
		}
	

		//		private void wordSetButton_Click(object sender, System.EventArgs e)
		//		{
		//			FwButton btn = (FwButton)sender;
		//			if (btn == null)
		//				m_currentWordSet = null;
		//			else
		//				m_currentWordSet = (WfiWordSet)  btn.Tag;
		//
		//			RefreshDataDisplay ();
		//		}

		//when the application is closed by clicking on the close button of the window,
		//for some reason the FwApp.OnCloseWindow does not always lead to
		//this window being disposed of properly (Dispose is not called).
		//therefore, I have wired up this method to the closing event, which is called first.
		//otherwise, the Parser thread will not be interrupted and the application cannot quit.
		private void PBMainWnd_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			CleanUp();
		}

		//we delay starting up the Parser because it is so processor intensive
		//by delaying it, we give a better "first impression"
		private void m_timerStartupParser_Tick(object sender, System.EventArgs e)
		{
			m_timerStartupParser.Enabled= false;
			//m_parserHandler.ConnectToParser();
		}

		#endregion // Miscellaneous methods

	}
}
