// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: WordListController.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>Implements word list controller
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Drawing;//for access to Font
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using SIL.Common.Utils;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	//public delegate void FwSelectionChangedEventHandler (object sender, FwObjectSelectionEventArgs e);

	/// <summary>
	/// Wraps the control which shows the list of words, controlling 
	///	filling of this list as well as events that occur on it.
	/// </summary>
	public class WordListController : FwController, IDisposable
	{
		public event  SIL.FieldWorks.Common.Utils.FwSelectionChangedEventHandler SelectionChanged;

		protected ListView m_listview;
		protected ListViewItem m_selectedItem = null;
		protected System.Windows.Forms.Timer m_updateTimer;
		protected bool m_waitingToNotify;
		protected ParserHandler m_parserHandler;
		protected WordSource m_source;

		//note that these are just the words in the current ListView, not all the words in the WFI
		protected System.Collections.Hashtable m_hashWordStringToListViewItem;

	#region construction/initialization

		public WordListController(ListView listview, ParserHandler parserHandler, FDO.FdoCache cache)
		{
			

			
			m_parserHandler = parserHandler;
			m_listview = listview;
			SetUpFonts(cache);

			m_hashWordStringToListViewItem = new System.Collections.Hashtable(3000);
			m_listview.SelectedIndexChanged += new EventHandler(OnSelectedIndexChanged);
			m_updateTimer = new System.Windows.Forms.Timer();
			m_updateTimer.Tick += new EventHandler(this.OnUpdateTimerTick);
			m_updateTimer.Interval = 200;
			m_updateTimer.Enabled = true;
		}

		private void SetUpFonts(FDO.FdoCache cache)
		{
			string fontName="unknown";
			try
			{
				fontName = cache.LanguageProject.DefaultVernacularWritingSystemFont;
				m_listview.Font = new Font(fontName, 8); 
				if(m_listview.Font.Name != fontName)
					throw new Exception();
			}
			catch (Exception)
			{
				MessageBox.Show("Could not load a font '"+fontName+"'.");
			}
		}

		public void Dispose()
		{
			if (m_listview != null)
			{
				m_listview.SelectedIndexChanged -= new EventHandler(OnSelectedIndexChanged);
				m_listview = null;
			}
			if (m_updateTimer != null)
			{
				m_updateTimer.Tick -= new EventHandler(this.OnUpdateTimerTick);
				m_updateTimer.Dispose();
			}
			m_selectedItem = null;
			m_parserHandler = null;
		}

		#endregion

		#region public methods
		public bool SelectWordInList(string word)
		{
			ListViewItem lvi = (ListViewItem)m_hashWordStringToListViewItem[word];
			if (lvi != null)
			{
				lvi.Selected = true;; 
				return true;
			} 
			return false;
		}


		/// <summary>
		/// populated the list with the results from the database
		/// </summary>
		/// <param name="readerHolder"></param>
		public void FillWordList(SqlDataReaderHolder readerHolder)
		{
			int khvoColumn = 0;
			NotifyOfStatusChanged("Loading word list...");
			m_listview.BeginUpdate();
			m_listview.Items.Clear();
			m_listview.View = System.Windows.Forms.View.Details;
			m_listview.Scrollable = true;
			m_hashWordStringToListViewItem.Clear();

			try
			{
				const int kStringColumn = 1;
				while (readerHolder.Reader.Read())
				{
					string s = readerHolder.Reader[kStringColumn].ToString();
					ListViewItem lvi;// = new ListViewItem(reader[kStringColumn].ToString());
					if(!m_hashWordStringToListViewItem.ContainsKey(s)) //cannot add the same word twice
					{
						lvi = new ListViewItem(new string[] {s});
						m_listview.Items.Add(lvi);
						m_hashWordStringToListViewItem.Add(s, lvi);
						lvi.Tag = readerHolder.Reader[khvoColumn];
					}
#if DEBUG
					else
					{
						Console.WriteLine("Duplicate wordform: {0}", s);
					}
#endif
				}
			}
			catch(Exception error) 
			{
				throw error;
			}	
			finally
			{
				m_listview.EndUpdate();
				//since we did not create the subject, related to our caller to dispose of it: readerHolder.Dispose();
			}
			//select the first word in the list
			if (m_listview.Items.Count > 0)
				m_listview.Items[0].Selected = true;
			else
			{
				RememberCurrentSelection();
				NotifyOfSelectionChanged(); //not having anything to select also counts as a change of selection
			}
			NotifyOfStatusChanged("Loaded " + m_listview.Items.Count.ToString() + " wordforms");
		}
		#endregion

		#region misc selection stuff
		/// <summary>
		/// In some cases, like when the user is holding down an arrow key,
		/// we want to delay broadcasting the event so that we don't send out spurious selection changed events.
		/// After all, changing the selection can lead to a lot of processing, including querying the database,
		/// transforming XML and displaying it in the browser.
		/// also, the ListView control sends us 2 selection changed events for only one change, if the changes 
		/// from one item to another. By delaying, we manage to only send a single selection changed event on in this case.
		/// </summary>
		private void RememberCurrentSelection()
		{
			Debug.Assert(m_listview != null);
			if (m_listview.SelectedItems.Count > 0)	//if there is something selected
			{
				m_selectedItem = m_listview.SelectedItems[0];
			}
			else
			{
				m_selectedItem = null;
			}
		}
		/// <summary>
		/// constructor for when the selected item is a ListView item
		/// </summary>
		protected FwObjectSelectionEventArgs GetArgsFromListViewItem(ListViewItem item)
		{
			int hvo=0;
			if (item != null)
			{
				if(item.Tag == null)
					throw new Exception("A ListViewItem had a null tag");
				hvo = (int)item.Tag;
			}
			return new FwObjectSelectionEventArgs(hvo);
		}
		
		protected void NotifyOfSelectionChanged()
		{
			NotifyOfSelectionChanged(GetArgsFromListViewItem(m_selectedItem)); 
		}

		protected void NotifyOfSelectionChanged(FwObjectSelectionEventArgs args)
		{
			if (SelectionChanged != null) 
			{
				//notify any delegates that the selection changed
				SelectionChanged(this, args); 
			}
		}
		public int SelectedWordformHvo
		{
			get
			{
				if(m_listview.SelectedItems.Count == 0)
					return 0;
				else
					return (int)m_listview.SelectedItems[0].Tag;
			}
		}
		#endregion

		#region event handling

		public void OnWordSourceSelectionChanged(object sender,WordSourceSelectionChangedEventArgs e)
		{
			FillList(e.Source);		
		}

		/// <summary>
		/// call this when a new word has been added to the list
		/// </summary>
		/// <param name="hvoWord"></param>
		public void RefillAndSelectWord(string form)
		{
			Debug.Assert(m_source != null, "This should not be called before something which sets the source initially.");
			FillList(m_source); //use the same source
			SelectWordInList(form);
		}

		private void FillList(WordSource source)
		{
			m_source = source;

			// ENHANCE: Does this really required two readers?
			// (Never tried with one, but I assume these are forward only readers,
			// so cannot be reused.)
			SqlDataReaderHolder readerHolder = null;
			//			SqlDataReaderHolder readerHolder2 = null;
			try
			{ 
				readerHolder = source.GetReader();
				//				readerHolder2 = source.GetReader();
				FillWordList(readerHolder);
				//decided that this is too expensive; let the user explicitly update 
				//these if he wants.
				//				m_parserHandler.UpdateWordforms(readerHolder2);
			}
			catch(Exception error) 
			{
				throw error;
			}	
			finally
			{
				if(readerHolder != null)
					readerHolder.Dispose();
				//				readerHolder2.Dispose();
			}
		}
		
		private void OnSelectedIndexChanged(object sender, System.EventArgs e)
		{
			//avoid going slow if just arrowing-through the words
			//also removes the problem that the underlying list sends two of these events when you switch from one word to another
			m_updateTimer.Start();//reset the timer
			m_waitingToNotify = true;
			RememberCurrentSelection();
		}

		private void OnUpdateTimerTick(object sender, System.EventArgs e)
		{
			if(m_waitingToNotify)
			{
				m_updateTimer.Stop();
				m_waitingToNotify = false;
				NotifyOfSelectionChanged();		
			}
		}

		/// <summary>
		/// receive the menu, toolbar, or (keyboard?) event to delete the selected word
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void OnDeleteSelectedWord(object sender, System.EventArgs e)
		{
			MessageBox.Show("Sorry, this has not been implemented yet.");
			/*			try
						{
							TreeNode tn = lvWords.SelectedNode;
							if(tn != null)
								m_wfiUtil.DeleteWordform((int)tn.Tag);	//(int) unboxes the integer id
							else
								MessageBox.Show("Select a word first.");
						}
						catch(Exception err)
						{
							MessageBox.Show("The word could not be deleated: WfiUtil said " + err.Message);
						}
						RefreshDataDisplay();
			*/
		}
		#endregion
	}


}
