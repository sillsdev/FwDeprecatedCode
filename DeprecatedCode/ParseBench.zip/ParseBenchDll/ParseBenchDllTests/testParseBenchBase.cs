// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Class1.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;

using NUnit.Framework;

using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.FDO;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	/// <summary>
	/// 
	/// </summary>
	public class TestParseBenchBase
	{
		protected FdoCache m_cache;

		public TestParseBenchBase()
		{
		}

		/// <summary>
		/// This method is called before each test.
		/// </summary>
		[SetUp]
		public virtual void SetUp()
		{
			m_cache = FdoCache.Create("TestlangProj");
			m_cache.DatabaseAccessor.BeginTrans();
		}

		/// <summary>
		/// This method is called after each test.
		/// </summary>
		[TearDown]
		public virtual void TearDown()
		{
			if (m_cache != null)
			{
				if (m_cache.DatabaseAccessor.IsTransactionOpen())
					m_cache.DatabaseAccessor.RollbackTrans();
				m_cache.Dispose();
				m_cache = null;
			}
		}
	}
}
