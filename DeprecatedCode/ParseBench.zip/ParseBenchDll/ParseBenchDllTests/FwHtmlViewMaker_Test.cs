// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: _FwHtmlView_Test.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using NUnit.Framework;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using System.Diagnostics;
using System.IO;
using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.Common.Utils.UnitTests
{

	[TestFixture]
	public class FwHtmlView_Test
	{
		protected FdoCache m_cache;
		protected WordformView m_wordform;
//		protected FwHtmlView m_analysis;
		protected FdoOwningCollection m_wordforms ;

		public FwHtmlView_Test()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	
		[SetUp]
		public  void SetUp()
		{
			m_cache = FdoCache.Create("ZPU"); 

			//test

			m_wordform = new   WordformView(m_cache);
//			m_analysis = new   FwHtmlView(m_cache);
		}

				
		[Test]
		public void simple ()
		{
			foreach(CmPossibility p in m_cache.LanguageProject.LexicalDatabaseOA.MorphTypesOA.PossibilitiesOS)
			{
				MoMorphType t = (MoMorphType)p;
				if(t.Name.AnalysisDefaultWritingSystem == "prefix")
				{
					t.Postfix.Text="-";
					t.Prefix.Text="";
				}
				if(t.Name.AnalysisDefaultWritingSystem == "suffix")
				{
					t.Prefix.Text = "-";
					t.Postfix.Text="";
				}
			}

			int hvo = 9749; //"ak"   m_wordforms.hvoArray[0];
			FwTempFile output = m_wordform.MakeDocument(hvo);
			using (output)
			{
				output.DumpToConsole ();
				output.Detach();
				System.Diagnostics.ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo(output.CloseAndGetPath());
				System.Diagnostics.Process.Start(info);//launch with Internet Explorer
			}
		}

	}
}
