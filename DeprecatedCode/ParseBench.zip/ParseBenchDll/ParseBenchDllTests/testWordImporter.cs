// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: TestWordImporter.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.IO;

using NUnit.Framework;

using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	[TestFixture]
	public class TestWordImporter : TestParseBenchBase
	{
		protected WordImporter m_importer;

		public TestWordImporter()
		{
			m_importer = null;
		}

		[SetUp]
		public override void SetUp()
		{
			base.SetUp();
			m_importer = new WordImporter(m_cache);
		}

		[TearDown]
		public override void TearDown()
		{
			m_importer.Dispose();
			base.TearDown();
		}

		protected void CheckGetWordformsInFile(string input, int expectedCount)
		{
			FwTempFile temp = null;
			try
			{
				temp = new FwTempFile();
				temp.Writer.Write(input);
				int[] hvos = m_importer.GetWordformsInFile(temp.CloseAndGetPath());
				Assert.AreEqual(expectedCount, hvos.GetLength(0), "Wrong number of hvos.");
			}
			finally
			{
				if (temp != null)
					temp.Dispose();
			}
		}
		
		protected void CheckGetNonUniqueWords(string input, int expectedCount)
		{
			System.Collections.Specialized.StringCollection words = m_importer.GetNonUniqueWords(input);
			Assert.AreEqual(expectedCount, words.Count, "Wrong number of non-unique words.");
		}

		#region buffer parsing tests

		//note: this is currently bogus, because it 
		//depends on what the wordforming characters are for the database that this is being run on/
		//Thus, the words here are divided with characters that are unlikely to be wordforming characters.
		//however, any of these English characters could also be considered non wordforming.
		[Test]
		public void Wordforming()
		{
			CheckGetNonUniqueWords(@"blue+green.e=mcSquared\nArizona", 5);
		}

		[Test]
		public void Numbers()
		{
			// The number in each should be skipped.
			CheckGetNonUniqueWords("Our family has 3 people.", 4);
			CheckGetNonUniqueWords("Our family has 13 people.", 4);
		}

		[Test]
		public void Misc()
		{
			CheckGetNonUniqueWords(@" There are two issues I see:
										1) In the few nanoseconds between checking for a wordform (and not finding
										it) and adding it, another process could add it.", 
				27);
		}
		
		#endregion

		#region file parsing tests

		[Test]
		public void ParseFile()
		{
			CheckGetWordformsInFile(@" There are two issues I see:
										1) In the few nanoseconds between checking for a wordform (and not finding
										it) and adding it, another process could add it.", 
									27);
		}

		#endregion
	}
}
