// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: testParseBenchGUI.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;

using NUnit.Framework;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	/// <summary>
	/// Summary description for testParseBenchGUI.
	/// </summary>
	//[TestFixture]
	public class testParseBenchGUI
	{
		public testParseBenchGUI()
		{
			//
			// TODO: Add constructor logic here
			//
		}

//		[Test]
//		public void CreateAndImportWordset()
//		{
//			Application.Run(new ParseBenchForm());
//
//		}
	}
}
