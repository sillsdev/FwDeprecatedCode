// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: WordSourceSideBarController.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>Implements WordSourceSidebarController a subclass of WordSource
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.Common.Controls;

namespace SIL.FieldWorks.WordWorks.ParseBench
{

	/// <summary>
	/// Wraps a sidebar tab, filling it with appropriate members as well as handling user commands related to the tab.
	/// </summary>
	public class WordSourceSideBarController : WordSourceController, IDisposable
	{
		protected SideBarTab m_sidebarTab;
		protected ParserHandler m_parserHandler;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="cache"></param>
		/// <param name="sidebarTab"></param>
		/// <param name="parserHandler">This is something of a pack, to allow us to blow away the Parser to get a round a bug with the open file dialog.</param>
		public WordSourceSideBarController(FdoCache cache, SideBarTab sidebarTab, ParserHandler parserHandler)
			:base(cache)
		{
			m_parserHandler = parserHandler;
			m_sidebarTab = sidebarTab;
		}

		public new void Dispose()
		{
			base.Dispose();
			foreach(SideBarButton btn in m_sidebarTab.Buttons)
				btn.Click -= new System.EventHandler(OnWordSourceButton_Click);
			m_sidebarTab.Buttons.Dispose();
			m_sidebarTab = null;
			m_parserHandler = null;
		}

		/// <summary>
		/// Handle the selection of a button.
		/// </summary>
		/// <remarks>notice that we get mouse clicks on the individual buttons.
		/// Also note that the FieldWorks sidebar currently uses this event for all selection, not just four clicks.</remarks>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void OnWordSourceButton_Click(object sender, System.EventArgs e)
		{
			FwButton btn = (FwButton)sender;
			if (btn == null)//review: does the sidebar control ever give us a null button?
				m_selectedSource  = null;
			else
				m_selectedSource = (WordSource)  btn.Tag;

			//notify any delegates that the selection changed
			NotifySelectionChanged ();
		}

		/// <summary>
		/// at the word to this list if it is not already in it
		/// </summary>
		/// <param name="hvoWord"></param>
		public void AddWordToCurrentList(int hvoWord) 
		{
			//if the source is the entire WordformInventory, then it makes no sense to try to add it again.
			//it only makes sense if the current source is a word list
			if (m_selectedSource is WordSetWordSource)
				((WordSetWordSource)m_selectedSource).AddWordToList(hvoWord);
		}

		/// <summary>
		/// Populate the list with a button for the WordformInventory, as well as 
		/// each WfiWordSet in the TestSets attribute of the morphological data object of the LanguageProject
		/// </summary>
		public void FillWordSetList()
		{
			try
			{
				m_sidebarTab.Buttons.Clear();
				m_sidebarTab.InitialLargeIcons= false;

				//add a button to represent the entire WordformInventory
				AddButton(new WholeInventoryWordSource(m_cache));


				//add a button for each wordSet in the system
				FdoOwningCollection sets=
					m_cache.LanguageProject.MorphologicalDataOA.TestSetsOC;	
				foreach(WfiWordSet wordSet in sets)
				{
					AddButton(new WordSetWordSource(m_cache, wordSet));
				}
				//select the first one
			//	m_sidebarTab.Buttons[0].Select();
				m_sidebarTab.IntSelection = new int[]{0};
			//	m_sidebarTab.Buttons[0].Focus ();//TODO JohnH:remove this when the sidebar select event arrives

			}
			catch (Exception error)
			{
				MessageBox.Show ("Could not fill the list of wordset sidebar. The error was: " + error.Message);
			}
		}

		/// <returns>
		///    <para>The index at which the new element was inserted.</para>
		/// </returns>
		protected int AddButton(WordSource source)
		{
			SideBarButton btn = new SideBarButton();
			btn.Tag = source;//can be null
			btn.Text = source.Label;

			btn.ImageIndex = 0;
			btn.Click += new System.EventHandler(OnWordSourceButton_Click);
			return m_sidebarTab.Buttons.Add(btn);
		}

		/// <summary>
		/// Allow the user to select one or more filesfor importing into a new wordset.
		/// </summary>
		/// <remarks>this causes a hang iff the Parser is running and updating words.
		/// Therefore, we currently kill the Parser before showing the dialog, then restart it.
		///</remarks>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void mnuImportWords_Click(object sender, System.EventArgs e)
		{
			m_parserHandler.DisconnectFromParser();

			System.Windows.Forms.OpenFileDialog dlg = new System.Windows.Forms.OpenFileDialog();
			dlg.Multiselect = true;


			 //TODO: **** this causes a hang iff the Parser is running and updating words.
			System.Windows.Forms.DialogResult result = dlg.ShowDialog();
		
			m_parserHandler.ConnectToParser();
			
			if(result != System.Windows.Forms.DialogResult.OK)
				return;
			WfiWordSet ows = CreateWordsetFromFiles(dlg.FileNames);
			int index = AddButton(new WordSetWordSource(m_cache,ows));
			m_sidebarTab.IntSelection = new int[]{index}; // m_sidebarTab.Buttons.Count-1};
			
		}

		/// <summary>
		/// Parse the given lists of files and create a wordset from them.
		/// </summary>
		/// <param name="paths"></param>
		/// <remarks>This is marked internal so that unit tests can call it</remarks>
		/// <returns></returns>
		internal WfiWordSet CreateWordsetFromFiles(string[] paths)
		{
			WordImporter importer = new WordImporter(m_cache);
			FdoOwningCollection sets = m_cache.LanguageProject.MorphologicalDataOA.TestSetsOC;
			WfiWordSet wordSet = (WfiWordSet)sets.Add(new WfiWordSet());
			wordSet.Name.AnalysisDefaultWritingSystem = System.IO.Path.GetFileName(paths[0]);
			//TODO: deal with duplicate wordSet names
			//TODO: add the names of the other files, not just the first one.
			wordSet.Description.AnalysisDefaultWritingSystem.Text = "Created by importing the words from fileart of a: " + paths[0];
			importer.PopulateWordset(paths, wordSet);
			return wordSet;
		}
	}
}
