// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: WordImporter.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// Implements WordImporter
// </remarks>
// --------------------------------------------------------------------------------------------

using System;
using System.IO;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Runtime.InteropServices;

using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.Common.COMInterfaces;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	/// <summary>
	/// a class for parsing text files and populating WfiWordSets with them.
	/// </summary>
	public class WordImporter : IDisposable
	{
		protected ILgCharacterPropertyEngine m_lgCharPropEngineVern; 
		protected FdoCache m_cache;

		public WordImporter(FdoCache cache)
		{
			m_cache = cache;

			//the following comment is from the FDO Scripture class, so the answer may appear there.

			// Get a default character property engine.
			// REVIEW SteveMc(TomB): We need the cpe for the primary vernacular writing system. What
			// should we be passing as the second param (i.e., the old writing system)? For now,
			// 0 seems to work.
			m_lgCharPropEngineVern = (ILgCharacterPropertyEngine)
				m_cache.LanguageWritingSystemFactoryAccessor.get_CharPropEngine(
				m_cache.LanguageProject.DefaultVernacularWritingSystem);
		}

		public void Dispose()
		{
			m_cache = null;
			System.Runtime.InteropServices.Marshal.ReleaseComObject(m_lgCharPropEngineVern);
		}

		public void PopulateWordset(string[] paths, WfiWordSet wordSet)
		{
			foreach (string path in paths)
			{
//				Debug.WriteLine ("--------------------------");
//				Debug.WriteLine ( "Words in " + path);
				int[] hvos = GetWordformsInFile(path);

				foreach(int hvo in hvos)
				{
					//Enhance: if it were possible to add an element to an array just using its hvo, 
					//	then we would never have to create this FDO-Wordform
					//create the FDO object and stick the word in this word set
					wordSet.CasesRC.Add(WfiWordform.CreateFromDBObject(m_cache, hvo));
				}
			}
		}
		
		// NB: This will currently return redundant hvos
		// if speed became a concern, we could experiment with reducing duplication of words
		// StringCollection, the data structure we are using, 1) does not prevent duplicate words being added
		// and 2) only does a dumb linear search for words if you ask if it already contains a word.
		public int[] GetWordformsInFile(string path)
		{
			System.Collections.ArrayList hvos = new System.Collections.ArrayList();
			System.IO.TextReader reader = File.OpenText(path);
 			while (true)
			{
				//REVIEW: can this be broken by a very long line?
				string line = reader.ReadLine();
				if (line == null)
					break;
				StringCollection words = GetNonUniqueWords(line);
				LanguageProject lp = m_cache.LanguageProject;
				WordformInventory wfi = lp.WordformInventoryOA;

				foreach(string word in words)
					hvos.Add(wfi.FindOrCreateWordform(word, lp.DefaultVernacularWritingSystem).Hvo);
			}
			reader.Close();
			return (int[])hvos.ToArray(Type.GetType("System.Int32"));
		}

		// ENHANCE: If speed becomes a concern,
		// this method could also do the FindOrCreateWordform and forgo creating a list of strings.
		public StringCollection GetNonUniqueWords(string buffer)
		{
			/*	
							if (m_lgCharPropEngineVern.get_IsNumber(sVerseNum[i]))			
			*/		

			StringCollection words = new StringCollection();
			int start = -1; //negative one needs we're still looking for a word to start
			int length = 0;
			int totalLengh = buffer.Length;
			for(int i = 0; i < totalLengh; i++)
			{
				bool isWordforming = m_lgCharPropEngineVern.get_IsWordForming(buffer[i]);
				if (isWordforming)
				{
					length++;
					if (start < 0) //first character in this word?
						start = i;
				}
				
				if ((start > -1) // had a word and found yet?
					 && (!isWordforming || i == totalLengh - 1 /*last char of the input*/)) 
				{
					//Enhance: with the proper data structure, we would not have to check before adding
					string word = buffer.Substring(start, length);
					words.Add(word);
					length = 0;
					start = -1;
				}
			}
			return words;
		}

		public StringCollection DumbEnglishGetUniqueWords(string line)
		{
			//TODO:	Tap into the real punctuation character list
			char[] separators = {' ', ',', '.', ';', ':', '\t', '!', '?', '(', ')', '\''};

			string[] rawWords = line.Split (separators);
			StringCollection words = new StringCollection();
			foreach(string rawWord in rawWords) 
			{
				string word = rawWord.Trim();
				if (word.Length == 0)
					continue;
				Debug.WriteLine(word);
				if (!words.Contains(word))//don't add the same word twice
					words.Add(word);
			}
			return words;
		}
	}
}
