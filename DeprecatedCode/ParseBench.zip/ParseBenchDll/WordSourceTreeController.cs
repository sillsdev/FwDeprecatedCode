// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: WordSourceTreeController.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks> Implements WordSourceController and one of its two subclass, WordSourceTreeController
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	#region event classes and delegate definition
	/// <summary>
	/// It the responsibility of the owner of this object to wire something up to this event handler
	/// </summary>
	public delegate void WordSourceSelectionChangedEventHandler(object sender, WordSourceSelectionChangedEventArgs e);

	/// <summary>
	/// This class is used as a parameter for the event "WordSourceSelectionChanged"
	/// </summary>
	public class WordSourceSelectionChangedEventArgs : EventArgs 
	{   
		protected WordSource m_source;

		/// <summary>
		/// constructor for when the selected item is a ListView item
		/// </summary>
		internal WordSourceSelectionChangedEventArgs(WordSource source)
		{
			m_source = source;
		}

		public WordSource Source
		{
			get
			{
				return m_source;
			}
		}
	}
	#endregion

	/// <summary>
	/// An abstract class which represents a list of word sources.
	/// </summary>
	/// <remarks>There are at least two subclasses of this one for a sidebar tab and another for a TreeView.
	/// </remarks>
	public abstract class WordSourceController : FwController, IDisposable
	{
		public event WordSourceSelectionChangedEventHandler SelectionChanged;
		
		protected FdoCache m_cache;
		protected WordSource m_selectedSource;
		protected int m_hvoParserAgent;
		protected int m_hvoUserAgent;

		public WordSourceController(FdoCache cache)
		{
			m_selectedSource = null;
			m_cache = cache;
			m_hvoParserAgent = m_cache.LanguageProject.DefaultParserAgent.Hvo;
			m_hvoUserAgent = m_cache.LanguageProject.DefaultUserAgent.Hvo;
		}

		public void Dispose()
		{
			m_cache = null;
			m_selectedSource = null;
		}

		protected virtual void NotifySelectionChanged()
		{
			if (SelectionChanged != null && m_selectedSource != null) 
			{
				//notify any delegates that the selection changed
				SelectionChanged(this, new WordSourceSelectionChangedEventArgs(m_selectedSource)); 
			}				
		}
	}

	
	/// <summary>
	/// Controls filling a TreeView with a set of WordSource choices, and handling user events on that TreeView.
	/// </summary>
	public class WordSourceTreeController : WordSourceController, IDisposable
	{		
		protected TreeView m_treeview;
		protected WordSource  m_sidebarWordSource;

		public WordSourceTreeController(FdoCache cache, TreeView treeview)
			: base(cache)
		{
			m_treeview = treeview;
			m_treeview.AfterSelect += new TreeViewEventHandler(OnAfterSelect);
			m_sidebarWordSource = null;
		}

		public new void Dispose()
		{
			base.Dispose();
			m_cache = null;
			if (m_treeview != null)
			{
				m_treeview.AfterSelect -= new TreeViewEventHandler(OnAfterSelect);
				m_treeview = null;
			}
			m_sidebarWordSource = null;
		}

		public WordSource GetSelectedWordSource()
		{
			if (m_treeview.SelectedNode == null)
				return null;

			return (WordSource)m_treeview.SelectedNode.Tag;
		}

		/// <summary>
		/// this receives the event when a button in the sidebar tab representing a WordSource is changed 
		/// (remember we have a hierarchy of sources, where the sidebar source is at the top and then the sources in the tree feed of that)
		/// </summary>
		/// <param name="e"></param>
		public void OnWordSourceSelectionChanged(object sender, WordSourceSelectionChangedEventArgs e)
		{			
			m_sidebarWordSource = e.Source;//set our current word set to what has just been selected in this sidebar
			//no need to refill it, which would cause us to lose the current selection.
			//FillGroupTree();//might not be the best eventual solution

			//even though the selection did not actually change, the selected item will now produce
			//a different set of words, because the WordSource that it relies on has changed.
			//therefore, we need to tell anyone depending on us that we changed.
			NotifySelectionChanged();
		}

		/// <summary>
		/// this event is fired when the tree we are managing has a change of selection.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void OnAfterSelect(object sender, TreeViewEventArgs e)
		{
			if(e.Node == null)
				return;	//TODO JohnH:maybe reselect the last item?

			if(e.Node.Tag == null)
				return; //this is a group node which does not have been associated query

			//Debug.Assert( m_sidebarWordSource!= null);
			//	m_tempgroup =(WordformGroup)e.Node.Tag;
			m_selectedSource = (WordSource)e.Node.Tag;
			NotifySelectionChanged();
		}

		protected override void NotifySelectionChanged()
		{
			if (m_selectedSource != null)
			{
				// REVIEW: This is ugly.  Remember, the word set comes from the sidebar.
				// m_tempgroup.CurrentWordSource = m_sidebarWordSource;
				((QueryWordSource)m_selectedSource).CurrentWordSource = m_sidebarWordSource;
				base.NotifySelectionChanged();
			}
		}

		
		protected  TreeNode CreateQueryWordSourceAndTreeNode(string label, string subquery)
		{
			TreeNode node = new TreeNode(label);
			node.Tag = new QueryWordSource(m_cache, label, subquery);
			return node;
		}

		// TODO (SteveMiller): Still a bunch of queries to do in here.
		public void FillGroupTree()
		{
			// REVIEW (SteveMiller): Other parts of the program can and do attach 
			// more SQL to the end of these queries. See GetQueryEnd() methods in 
			// WordSource.cs. It'd be really nice to get the SQL in one spot, but if 
			// that's not possible, it'd be nice to include as much of the SQL here,
			// and not in GetQueryEnd().

			m_treeview.Nodes.Clear();
			int root = m_treeview.Nodes.Add(CreateQueryWordSourceAndTreeNode("All",
				@"SELECT DISTINCT fn.[Id], fn.Txt
				FROM dbo.fnGetWordformParses(NULL, NULL, 'All')	fn "));
			
//			m_treeview .Nodes .Add(CreateQueryWordSourceAndTreeNode("No Parses",
//				@" and obj Not In
//								(select distinct obj from WfiWordform_Analyses wa (readuncommitted), WfiWordform_Form wf (readuncommitted)
//								where wa.src = wf.obj)"));

			m_treeview.Nodes.Add(CreateQueryWordSourceAndTreeNode("Some User Analyses",
				@"SELECT DISTINCT fn.[Id], fn.Txt
				FROM dbo.fnGetWordformParses(NULL, NULL, 'Some') fn "));
			
			TreeNode node = new TreeNode("Problems");
			m_treeview.Nodes.Add(node);
				
			node.Nodes.Add(CreateQueryWordSourceAndTreeNode("Problem",
				@"SELECT DISTINCT fn.[Id], fn.Txt
				FROM dbo.fnGetWordformParses2(" +
				m_hvoParserAgent.ToString() + @", " +
				m_hvoUserAgent.ToString() + @", " +
				m_cache.DefaultVernWs.ToString() + @", 
					'Problem') fn "));

			node.Nodes.Add(CreateQueryWordSourceAndTreeNode("Missing Parses",
				@"SELECT DISTINCT fn.[Id], fn.Txt
				FROM dbo.fnGetWordformParses2(" +
				m_hvoParserAgent.ToString() + @", " +
				m_hvoUserAgent.ToString() + @", " +
				m_cache.DefaultVernWs.ToString() + @", 
					'Missing') fn "));

			node.Nodes.Add(CreateQueryWordSourceAndTreeNode("Extra Parses",
				@"SELECT DISTINCT fn.[Id], fn.Txt
				FROM dbo.fnGetWordformParses2(" +
				m_hvoParserAgent.ToString() + @", " +
				m_hvoUserAgent.ToString() + @", " +
				m_cache.DefaultVernWs.ToString() + @", 
					'Extra') fn "));

			m_treeview.Nodes.Add(CreateQueryWordSourceAndTreeNode("Needs Evaluation",
				@"SELECT DISTINCT fn.[Id], fn.Txt
				FROM dbo.fnGetWordformParses(" +
				m_hvoUserAgent.ToString() + @", " +
				m_cache.DefaultVernWs.ToString() + @", 
					'NeedsEval') fn "));

			m_treeview.Nodes.Add(CreateQueryWordSourceAndTreeNode("Perfect",
				@"SELECT DISTINCT fn.[Id], fn.Txt
				FROM dbo.fnGetWordformParses2(" +
				m_hvoParserAgent.ToString() + @", " +
				m_hvoUserAgent.ToString() + @", " +
				m_cache.DefaultVernWs.ToString() + @", 
					'Perfect') fn "));

			node = new TreeNode("Misc");
			m_treeview.Nodes.Add(node);
			
			node.Nodes.Add(CreateQueryWordSourceAndTreeNode("Never Parsed",
				@"SELECT DISTINCT fn.[Id], fn.Txt
				FROM dbo.fnGetWordformParses(" +
					m_hvoParserAgent.ToString() + @", " +
					m_cache.DefaultVernWs.ToString() + @", 
					'Never') fn "));

			AddParseCountRange(node, 0, 0);
			AddParseCountRange(node, 1, 1);
			AddParseCountRange(node, 2, 2);
			AddParseCountRange(node, 3, 3);
			AddParseCountRange(node, 4, 4);
			AddParseCountRange(node, 5, 9);
			AddParseCountRange(node, 10, 19);
			AddParseCountRange(node, 20, 39);
			AddParseCountRange(node, 39, 9999999);

			m_treeview.Nodes[root].ExpandAll();

			//select the first node
			m_treeview.SelectedNode = m_treeview.Nodes[root];
			Debug.Assert(m_treeview.SelectedNode != null);
		}

		/// <summary>
		/// construct a particular kind of query which just selects words based
		/// on the number of parses
		/// </summary>
		protected void AddParseCountRange(TreeNode parentNode, int lowerBound, int upperBound)
		{
			//TODO JohnH: make multilingual, coming from a resource
			string label;
			if (lowerBound == upperBound)
			{
				if (lowerBound == 1)
					label = lowerBound.ToString() + " parse";
				else
					label = lowerBound.ToString() + " parses";
			}
			else
			{
				if (upperBound == 9999999)
					label = lowerBound.ToString() + "> parses";
				else
					label = lowerBound.ToString() + " - " + upperBound.ToString() + " parses";
			}
			
			parentNode.Nodes.Add(CreateQueryWordSourceAndTreeNode(
				label,
				@"SELECT DISTINCT fn.[Id], fn.Txt 
				FROM dbo.fnGetParseCountRange("
					+ m_hvoParserAgent.ToString() + @", " +
					m_cache.DefaultVernWs.ToString() +
					@", NULL, " + 
					lowerBound.ToString() + @", " +
					upperBound.ToString() + @")	fn "));
		}

		private void mnuWordSetDelete_Click(object sender, System.EventArgs e)
		{
			try
			{
				//doesn't work yet, leads to hang
				//System.Windows.Forms.MenuItem  item = (System.Windows.Forms.MenuItem)sender;
		
				WordSetWordSource source = (WordSetWordSource)this.GetSelectedWordSource();
				if (source != null)
				{
					FdoOwningCollection sets =
						m_cache.LanguageProject.MorphologicalDataOA.TestSetsOC;	

					try
					{
						m_cache.BeginUndoTask("Undo delete '" + source.Label + "'", "Redo add '" + source.Label + "'");
						sets.Remove(source.WordSet);
					}
					finally
					{
						m_cache.EndUndoTask();
					}
					//	FillWordSetList();

				//	MessageBox.Show ("Due to a bug in the sidebar code which displays the word sets, you should 'Save', then Quit this program and restart it.");
				}
			}
			catch(Exception error)
			{
				MessageBox.Show("Could not delete the word set. The error was: " + error.Message);
			}
		}
	}

}
