// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: AnalysisViewController.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using SIL.FieldWorks;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.WordWorks;
using SIL.FieldWorks.Common.Utils;
using SIL.Common.Utils;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	/// <summary>
	/// this class is responsible for  displaying the analyses of a Wordform in an HTML browser pane, 
	/// and allowing the user to accept or reject analyses.
	/// The inputs to this class are 
	/// 1) an FdoCache and 
	/// 2) the Internet Explorer browser component of the form.
	/// After construction, this class does its work when an event is raised.  
	/// Normally, the event delegate of this object will be wired to the selection event of a list 
	/// of words.  Thus, whenever a new word is selected, this class will show the analyses for that 
	/// word.
	/// </summary>
	public class AnalysisViewController : IDisposable
	{
		protected AxSHDocVw.AxWebBrowser m_browser;
		protected WordformView m_wordformView;
		protected FwTempFile m_inUseTempFile;
		protected int m_currentWordformHvo = 0;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="cache"></param>
		/// <param name="browser"></param>
		public AnalysisViewController(FdoCache cache, AxSHDocVw.AxWebBrowser browser)
		{
			m_browser = browser;

			//link up to be before navigate the event of the browser so that we know when the user clicked on something
			//note: this old version of before navigate is being used because of a bug in the.net framework.
			//win this bug is fixed, we should look at switching to using BeforeNavigate2

			//need to get hold of the ActiveX object and then grab this old interface:
			SHDocVw.WebBrowser_V1 axDocumentV1 = browser.GetOcx() as SHDocVw.WebBrowser_V1;
			axDocumentV1.BeforeNavigate += new SHDocVw.DWebBrowserEvents_BeforeNavigateEventHandler(this.OnBeforeNavigate); 
			m_wordformView = new WordformView(cache);
		}

		public void Dispose()
		{
			if (m_browser != null)
			{
				SHDocVw.WebBrowser_V1 axDocumentV1 = m_browser.GetOcx() as SHDocVw.WebBrowser_V1;
				axDocumentV1.BeforeNavigate -= new SHDocVw.DWebBrowserEvents_BeforeNavigateEventHandler(OnBeforeNavigate); 
				m_browser = null;
			}
		}

		//note: this old version of before navigate is being used because of a bug in the.net framework.
		//win this bug is fixed, we should look at switching to using BeforeNavigate2
		protected void OnBeforeNavigate(string URL, int Flags, string TargetFrameName,
				ref object PostData, string Headers, ref bool Processed)  
		{ 
			try
			{
				Processed = m_wordformView.HandleNavigationEvent(URL); 
				if(Processed)
					ShowWordform(m_currentWordformHvo); // Refresh
			}
			catch (Exception error) 
			{
				System.Windows.Forms.MessageBox.Show("There was an error handling the click. " + error.Message, "Program Error");
				ShowPage("about:blank");//blank page
			}
 		}  

		//this may become useful when Microsoft fixes the bug that prevents its current use
//		protected void OnBeforeNavigate2(object sender, AxSHDocVw.DWebBrowserEvents2_BeforeNavigate2Event orange)
//		{
//			char c= orange.uRL.ToString()[0];
//			if (c== 'm')
//				System.Windows.Forms.MessageBox.Show(orange.uRL.ToString());
//		}


		/// <summary>
		/// Raise this event to when a different word should be displayed (or the first word).
		/// </summary>
		/// <param name="sender">unused</param>
		/// <param name="e">the event arguments</param>
		public void OnWordSelectionChanged(object sender, FwObjectSelectionEventArgs e)
		{
			ShowWordform(e.Hvo);
		}

		private void ShowPage(String sPagePath)
		{
			System.Object nullObject = 0;
			System.Object nullObjStr = "";
			m_browser.Visible = true;
			m_browser.BringToFront();
			
			m_browser.Offline = true;
			m_browser.Navigate(sPagePath, ref nullObject, ref nullObjStr,
				ref nullObjStr, ref nullObjStr);
		}

		private void ShowWordform(int hvoWordform)
		{			
			System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;
			try
			{
				if(hvoWordform >0)
				{
					FwTempFile tf = m_wordformView.MakeDocument(hvoWordform);
					ShowPage(tf.CloseAndGetPath());
					if(m_inUseTempFile != null)
						m_inUseTempFile.Dispose();
					m_inUseTempFile = tf;
					m_currentWordformHvo = hvoWordform;
				}
				else
				{
					ShowPage("about:blank");//blank page
				}
			}
			catch
			{
				ShowPage("about:blank");//blank page
			}
			finally
			{
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Arrow;
			}
		}

		/// <summary>
		/// Redraw the analysis frame
		/// </summary>
		public void Refresh()
		{
			if(m_currentWordformHvo != 0)
				ShowWordform(m_currentWordformHvo);
		}
		
	}

}