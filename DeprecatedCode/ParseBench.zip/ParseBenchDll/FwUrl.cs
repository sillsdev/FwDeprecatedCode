// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FwUrl.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Collections;
//using System.Runtime.InteropServices;

//using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;

namespace SIL.FieldWorks.Common.Utils
{
	/// <summary>
	/// Summary description for FwUrl.
	/// </summary>
	public class FwUrl
	{
		protected string m_appName;
		protected string m_view;
		protected string m_server;
		protected string m_database;
		protected int m_targetHvo;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// constructor to use when you want to create a href
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public FwUrl(int targetHvo, string applicationName)
		{
			SetDefaults();

			m_targetHvo = targetHvo;
			m_appName = applicationName;
		}
		/// <summary>
		/// constructor to use when you have a href and want to follow it
		/// </summary>
		/// <remarks> Normally, you should use the static method Handle instead of 
		/// this constructor.</remarks>
		/// <param name="url"></param>
		public FwUrl(FdoCache cache, string url)
		{
			try
			{

				SetDefaults();
			
				if(GetProtocolPart(url) != "silfw")
					throw new ArgumentException("Could not handle that kind of url", url);

				//for some reason, we get a trailing '/' which we want to remove
				url = url.TrimEnd(new Char[]{'/', ' '});
				string content =GetParametersPart(url);  

				//TODO: this is all a complete hack which will need to be rewritten from scratch
				string[] parameters = content.Split(new Char[]{','});
				if(parameters[0] != "broker")
					throw new ArgumentException("Could not handle that kind of url", url);
				m_appName = parameters[1].Substring(4); // skip the "app="
				string targetHvoName = parameters[2].Substring(10); // skip the "targetHvo="
				m_targetHvo = int.Parse(targetHvoName);

				//don't handle changing the server or db for now
				m_database = cache.DatabaseName;
				m_server = cache.ServerName;
			}
			catch(Exception error)
			{
				throw new ApplicationException("there was an problem making sense of this url: "+url+"   "+error.Message, error);
			}
		}

		public void Navigate(FdoCache cache)
		{
#if CANUSENEWAPPS
			Debug.Assert(m_targetHvo > 0);

			int[] hvos = null;
			int[] flids = {0};
			int hvoMainObjectOfTheApp = 0;

			// TODO: I made lots of dangerous asssumptions here about who owns whom!
			try
			{
				int cls = cache.GetClassOfObject(m_targetHvo);
				switch (cls)
				{
					case SIL.FieldWorks.FDO.Ling.MoStemMsa.kclsidMoStemMsa:
						MoStemMsa msa = (MoStemMsa)CmObject.CreateFromDBObject(cache, m_targetHvo);
						hvos = new int[] {msa.PartOfSpeechRAHvo};
						break;
					case MoInflectionalAffixMsa.kclsidMoInflectionalAffixMsa:
						MoInflectionalAffixMsa miam = (MoInflectionalAffixMsa)CmObject.CreateFromDBObject(cache, m_targetHvo);
						MoInflAffixSlot slot = (MoInflAffixSlot)miam.Slots.FirstItem; // go to the first one
						//hvos = new int[] {slot.ownerHVO};
						hvos = new int[] {slot.OwnerHVO, slot.Hvo};
						flids = new int[] {(int)SIL.FieldWorks.FDO.Ling.Generated.BasePartOfSpeech.PartOfSpeechTags.kflidAffixSlots};
						break;
					case MoDerivationalAffixMsa.kclsidMoDerivationalAffixMsa:
						MoDerivationalAffixMsa md = (MoDerivationalAffixMsa)CmObject.CreateFromDBObject(cache, m_targetHvo);
						//what to go to? From, or to? From for now.
						hvos = new int[] {md.FromPartOfSpeechRAHvo};
						break;
					case SIL.FieldWorks.FDO.Ling.LexEntry.kclsidLexEntry:
						hvos = new int[]{m_targetHvo};
						break;
					case SIL.FieldWorks.FDO.Ling.LexMajorEntry.kclsidLexMajorEntry:
						hvos = new int[]{m_targetHvo};
						break;
					case SIL.FieldWorks.FDO.Ling.LexSense.kclsidLexSense:
						//takes two steps
						//the path is the entry, then the sense.
						hvos = new int[] {cache.GetOwnerOfObject(m_targetHvo), m_targetHvo};
						//the flid is the "senses" field of the entry.
						flids = new int[] {(int)SIL.FieldWorks.FDO.Ling.Generated.BaseLexEntry.LexEntryTags.kflidSenses,
											 (int)SIL.FieldWorks.FDO.Ling.Generated.BaseLexSense.LexSenseTags.kflidGloss};
						//lexdb is the owner of the lexentry
						break;
					default:
						Debug.Fail("FwUrl Can't handle linking to that kind of object.");
						break;
				}
			}
			catch(Exception er)
			{
				throw new ApplicationException("Could not figure out where to go.", er);
			}

			IFwTool app = null;
			try
			{
				switch (m_appName.ToLower())
				{
					case "lexed":
						hvoMainObjectOfTheApp = cache.LanguageProject.LexicalDatabaseOAHvo;
						app =(IFwTool)new LexEdLib.LexicalDatabaseEditorClass();
						break;
					case "pos":
						hvoMainObjectOfTheApp = cache.LanguageProject.PartsOfSpeechOAHvo;
						app = (IFwTool)new CleLib.ChoicesListEditorClass();
						break;
					default:
						Debug.Fail("FwUrl Can't handle linking to that app (" + m_appName + ")");
						break;
				}
			}
			catch(Exception er)
			{
				if (app != null)
					System.Runtime.InteropServices.Marshal.ReleaseComObject(app);
				throw new ApplicationException("Could not launch the application", er);
			}

			try
			{
				// Open a main window on a particular object in a particular database.
				// Will fail if the specified tool cannot handle the specified top-level object.
				// This attempts to open using a particular view and opens with the selection on a specified
				// object or field. The selection is specified by providing a path from a normal record to
				// the sub-record and field. For example, if subentry 1582 is to be displayed, the following
				// input might be used:
				// prghvo: 1579, 1581, 1582,  chvo: 3
				// prgflid: 4004009, 4004009,  cflid: 2
				// 1579 is the main record. 1581 is a subentry in the 4004009 flid of 1579. 1582 is a
				// subentry in the 4004009 flid of 1581. When the window opens, we try to display the
				// cursor in the 1582 record. If a third flid is supplied, we try to position the cursor
				// in that field. It should also be possible to specify a view without specifying a path,
				// in which case the tool should open on the first record using the specified view.
				int ppidNew = 0; // Not used here.
				int notUsed; // phtool Handle to the newly created window.
				notUsed = app.NewMainWndWithSel(Server, // bstrServerName Name of the MSDE/SQLServer computer.
					Database, // bstrDbName Name of the database.
					cache.LanguageProject.Hvo, // hvoLangProj Which languate project within the database.
					hvoMainObjectOfTheApp, // hvoMainObj The top-level object on which to open the window.
					cache.LanguageProject.DefaultAnalysisWritingSystem, // encUi The user-interface writing system.
					0, // nTool A tool-dependent identifier of which tool to use.
					0, // nParam Another tool-dependent parameter.
					hvos, // prghvo Pointer to an array of object ids.
					hvos.Length, // chvo Number of object ids in prghvo.
					flids, // prgflid Pointer to an array of flids.
					flids.Length, // cflid Number of flids in prgflid.
					0, // ichCur Cursor offset from beginning of field.
					-1, // nView The view to display when showing the first object. Use -1 to use the first data entry view.
					out ppidNew); // ppidNew Process id of the new main window's process.
			}
			finally
			{
				if (app != null)
					System.Runtime.InteropServices.Marshal.ReleaseComObject(app);
			}
#else
			System.Windows.Forms.MessageBox.Show("Navigation temporarily suspended.");
#endif
		}

		protected void SetDefaults()
		{
			m_view = "edit";
			m_appName = "lexed";
			m_server = ".//SILFW";
			m_database = "";
			m_targetHvo = 0;
		}

		public string URL
		{
			get
			{
				return "SILFW://broker" + ",app=" + Application + ",targetHvo=" + m_targetHvo.ToString();
			}
		}

		/// <summary>
		/// Handle the url if we can
		/// </summary>
		/// <param name="url"></param>
		/// <returns>true if it was handled, else false</returns>
		public static bool Handle(FdoCache cache,string url)
		{
			if(GetProtocolPart(url) != "silfw")
				return false;

			FwUrl x = new FwUrl(cache, url);
			x.Navigate(cache);

			return true;
		}

		protected static string GetProtocolPart(string url)
		{
			int afterProtocol = url.IndexOf("://") + 3;

			if(afterProtocol < 4)
				return null;
				
			return url.Substring(0, afterProtocol - 3);
		}

		protected static string GetParametersPart(string url)
		{
			int parametersStart = url.IndexOf("://") + 3;

			if(parametersStart < 4)
				return null;
				
			return  url.Substring(parametersStart);
		}


		#region boring properties
		public string Application
		{
			get
			{
				return m_appName;
			}
			set
			{
				m_appName = value;
			}
		}

		public string View
		{
			get
			{
				return m_view;
			}
			set
			{
				m_view = value;
			}
		}

		public string Server
		{
			get
			{
				return m_server;
			}
			set
			{
				m_server = value;
			}
		}

		public string Database
		{
			get
			{
				return m_database;
			}
			set
			{
				m_database = value;
			}
		}
		#endregion
	}
}
