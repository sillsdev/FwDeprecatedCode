// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ParserHandler.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
//	Implements ParserHandler
// </remarks>
// --------------------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Windows.Forms;
using System.Diagnostics;
using System.Configuration;
using SIL.FieldWorks.WordWorks.Parser;
using SIL.Common.Utils;
using SIL.FieldWorks.Common.Utils;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.LangProj.Generated;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	/// <summary>
	/// this class just gets all the parser calling and event and receiving
	/// out of the form code. It is scheduled for refactoring
	/// </summary>
	public class ParserHandler
	{
		protected ParserConnection m_parserConnection;
		protected FdoCache m_cache;										//a pointer to the one owned by from the form
		protected LogWindow m_log;

		/// <summary>
		/// constructor
		/// </summary>
		/// <remarks> this must be followed by a call to ConnectToParser ()</remarks>
		/// <param name="cache"></param>
		/// <param name="log"></param>
		public ParserHandler(FdoCache cache, LogWindow log)
		{
			m_cache = cache;
			m_log = log;

/*			//read in any special configuration settings
			System.Collections.Specialized.NameValueCollection settings = (System.Collections.Specialized.NameValueCollection)
				ConfigurationSettings.GetConfig("appSettings");

			//		1 means skip loading xample

			if (settings != null)
			{
				/*				m_flags= ConfigurationUtils.GetIntegerConfigSetting(settings,"M3ParserFlags", 0);

								if (ConfigurationUtils.GetBooleanConfigSetting(settings,"LoadOnStartup", false))
									GetParserConnection();
				* /			}
*/
			//ConnectToParser();
		}

		public void ConnectToParser()
		{
			//Debug.Assert(m_parserConnection == null, "already connected to Parser");
			if(m_parserConnection == null)
				m_parserConnection = new ParserConnection(m_cache.ServerName, m_cache.DatabaseName,
					m_cache.LanguageProject.Name.AnalysisDefaultWritingSystem);
		}

		public void DisconnectFromParser()
		{
			//Debug.Assert(m_parserConnection != null, "already connected to Parser");
			if(m_parserConnection != null)
			{
				m_parserConnection.Dispose();
				m_parserConnection = null;
			}
		}		
		
		/// <summary>
		/// put the wordform in the highest priority queue of the Parser
		/// </summary>
		/// <param name="hvo"></param>
		public void UpdateWordformAsap(int hvo)
		{
			m_parserConnection.Parser.ScheduleOneWordformForUpdate(hvo, WordWorks.Parser.ParserScheduler.Priority.ASAP);
		}

		/// <summary>
		///
		/// </summary>
		/// <param name="hvo"></param>
		public void TraceWordform(int hvo)
		{
			string result = m_parserConnection.TraceWord(hvo);
			FwTempFile temp = new FwTempFile(".xml");
			temp.Writer.Write(result);
			Process.Start(temp.CloseAndGetPath());
		}		

		/// <summary>
		/// put the wordform in the medium priority queue of the Parser
		/// </summary>
		/// <param name="hvo"></param>
		public void UpdateWordformSoon(int hvo)
		{
			m_parserConnection.Parser.ScheduleOneWordformForUpdate(hvo, WordWorks.Parser.ParserScheduler.Priority.soon);
		}

		private string FormOfWord (int hvo)
		{
			try
			{
				WfiWordform word = new WfiWordform (m_cache, hvo);
				return word.Form.VernacularDefaultWritingSystem;
			}
			catch (Exception) 
			{
				Debug.Assert(false, "The word returned in msg from parser apparently doesn't exist in db");
				return "Unknown";
			}
		}

		protected void LogError(string s)
		{
			m_log.WriteLine(s);
			m_log.WriteLine();
		}

		public void Reload()
		{
			Debug.Fail("Not implemented. Hit 'ignore' now.");
			//GetParserConnection().Prepare(m_iParserClientNum, 0, 2/*reload flag */);
		}

				
		public void UpdateWordforms(SqlDataReaderHolder readerHolder)
		{
			try
			{ 
				//tests, using the debug version of the M3 parser and WFI DLL:
				//fifty-one words
				//1: 28secs
				//5: 27
				//10: 26
				//60: 48

				//				int kHowManyAtATime=50;
				//				int[] hvos=new int[kHowManyAtATime];
				//				int i = 0;
				//				const int kHvoColumn=0;
				//
				//				while (readerHolder.Reader.Read())
				//				{
				//					int hvo= (int)readerHolder.Reader[kHvoColumn];
				//					hvos [i] = hvo;
				//					if (i == kHowManyAtATime-1)
				//					{
				//						UpdateWordforms(hvos);
				//						i = 0;
				//						hvos=new int[kHowManyAtATime];//quick way to clear it out
				//					}
				//					else
				//						i++;
				//				}
				//				if (i > 0)//the last one does not necessarily fill up
				//					UpdateWordforms(hvos);

				const int kHvoColumn = 0;

				while (readerHolder.Reader.Read())
				{
					UpdateWordformSoon((int)readerHolder.Reader[kHvoColumn]);
				}
			}
			catch(Exception error) 
			{
				throw error;
			}	
			finally
			{
				readerHolder.Dispose();
			}
		}

		//note that the Parser also supports an event oriented system
		//so that we are notified for every single event that happens.  
		//Here, we have instead chosen to use the polling ability.  
		//We will thus missed some events but not get slowed down with too many.
		public string GetParserActivityString()
		{
			if(m_parserConnection ==null)
				return "No Parser Loaded";
			else
				return m_parserConnection.Activity;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public string GetParserQueueString()
		{
			if(m_parserConnection == null)
				return "(-/-/-)";
			int lowQueueSize = m_parserConnection.Parser.GetQueueSize(ParserScheduler.Priority.eventually);
			int medQueueSize = m_parserConnection.Parser.GetQueueSize(ParserScheduler.Priority.soon);
			int highQueueSize = m_parserConnection.Parser.GetQueueSize(ParserScheduler.Priority.ASAP);

			return "Queue:" + lowQueueSize.ToString() + "/"+medQueueSize.ToString() + "/"+highQueueSize.ToString();
		}


		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public void Dispose()
		{
			DisconnectFromParser();
		}

		/// <summary>
		/// enable/disable and check items in the Parser menu
		/// </summary>
		internal void menuParser_Popup(object sender, System.EventArgs e)
		{
			const int kIndexOfStartItem = 6;		//the only one that is enabled if we are disconnected
			const int kIndexOfPauseItem = 8;	//need a check
			bool connected = (null != m_parserConnection);

			//first, set them all to match whether we are enabled or not
			foreach(MenuItem item in ((MenuItem)sender).MenuItems)
			{
				item.Enabled = connected;
			}
			//next, switch the "start" item to be the opposite
			((MenuItem)sender).MenuItems[kIndexOfStartItem].Enabled = !connected;

			//finally, set the check mark on the pause item.
			if(m_parserConnection != null)
				((MenuItem)sender).MenuItems[kIndexOfPauseItem].Checked = m_parserConnection.IsPaused;
		}

		
		internal void mnuStartParser_Click(object sender, System.EventArgs e)
		{
			if(m_parserConnection == null)
				ConnectToParser();		
		}

		internal void mnuStopParser_Click(object sender, System.EventArgs e)
		{
			if(m_parserConnection != null)
				DisconnectFromParser();		
		}

		internal void mnuPauseParser_Click(object sender, System.EventArgs e)
		{
			if(m_parserConnection != null)
			{
				if (m_parserConnection.IsPaused)
				{
					m_parserConnection.Resume();
				}
				else
				{
					if(!m_parserConnection.AttemptToPause())
						MessageBox.Show("Alas, the pause didn't take.");
				} 
			}
		}

//		internal void mnuRestartParser_Click(object sender, System.EventArgs e)
//		{
//			DisconnectFromParser();
//			ConnectToParser();
//		}

		internal void mnuReloadParser_Click(object sender, System.EventArgs e)
		{
			m_parserConnection.Parser.ReloadGrammarAndLexicon();
		}
	}
}