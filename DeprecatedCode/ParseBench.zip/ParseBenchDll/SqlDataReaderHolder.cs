// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: SqlDataReaderHolder.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
//		The class reduces duplicate code by encapsulating in both the reader and (optionally)connection, 
//		and making sure that both get closed when this reader is garbage collected.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;

namespace SIL.Common.Utils
{
	/// <summary>
	/// Use this class to reduce the code needed to close the reader and (optionally) handle the opening and closing of the connection.
	/// </summary>
	///	this class can be used in two scenarios:
	///	1) you have an open connection which you are using for other things, and you need
	///			this class just to make sure that the reader is closed (you still need to call Dispose()in a timely manner
	///			if this is going to do you any good).
	///	2) you are opening that connection just for the purpose of doing this single query.  In this case,
	///	use the constructor which takes a connection string.  When you call Dispose()on this class,
	///	the connection will be closed and m_disposed of.
	public class SqlDataReaderHolder : IDisposable
	{
		protected SqlConnection m_connection;
		protected SqlDataReader m_reader;
		// Track whether Dispose has been called.
		private bool m_disposed = false;
		protected bool m_doOwnConnection;

		/// <summary>
		/// Use this constructor when you only have a single query to execute for the lifetime of the connection.
		/// </summary>
		/// <param name="connectionString"></param>
		/// <param name="query"></param>
		public SqlDataReaderHolder(string connectionString, string query)
		{
			m_doOwnConnection= true;
			m_connection = new SqlConnection(connectionString);
			m_connection.Open ();
			Init(query);
		}

		/// <summary>
		/// Use this constructor when the connection is already opened and will be used for other things.
		/// </summary>
		/// <param name="connection">an already open database connection</param>
		/// <param name="query">the query that will be executed</param>
		public SqlDataReaderHolder(SqlConnection connection, string query)
		{
			m_doOwnConnection= false;
			m_connection = connection;
			Init(query);
		}

		protected void Init(string query)
		{
			SqlCommand command = m_connection.CreateCommand();
			command.CommandText = query;

			//Debug.WriteLine ( command.CommandText);
			m_reader = command.ExecuteReader();

		}

		public SqlDataReader Reader
		{
			get
			{
				if(this.m_disposed)
				{
					throw new ObjectDisposedException("SqlDataReaderHolder");
				}
				return m_reader;
			}
		}

		/// <summary>close the reader and the connection</summary>
		/// <remarks>
		/// This method is the reason this class exists; to make sure that the reader and a connection get closed.
		/// Ideally, the method using this reader should call this at the end of the method, preferably in a
		/// finally{} clause.  However, if this is not called explicitly, at least it will be called when the
		/// class is garbage collected.
		/// </remarks>
		/// <remarks>A derived class should not be able to override this method.</remarks>
		public void Dispose()
		{
			Dispose(true);
			// Take this off of the Finalization queue 
			// to prevent finalization code for this object
			// from executing a second time.
			GC.SuppressFinalize(this);
		}

		// Dispose(bool disposing) executes in two distinct scenarios.
		// If disposing equals true, the method has been called directly
		// or indirectly by a user's code. Managed and unmanaged resources
		// can be m_disposed.
		// If disposing equals false, the method has been called by the 
		// runtime from inside the finalizer and you should not reference 
		// other objects. Only unmanaged resources can be m_disposed.
		protected virtual void Dispose(bool disposing)
		{
			// Check to see if Dispose has already been called.
			if(!this.m_disposed)
			{
				//explicitly close the reader
				if (m_reader != null)
				{
					m_reader.Close();
				}

				// If disposing equals true, dispose all managed and unmanaged resources.
				// If false, we would only dispose unmanaged resources (which we don't have any of in this class)
				if(disposing)
				{
					if (m_doOwnConnection && m_connection != null)
					{
						m_connection.Close ();
						m_connection.Dispose();
					}				
				}
			}
			m_disposed = true;         
		}

		// Use C# destructor syntax for finalization code.
		// This destructor will run only if the Dispose method 
		// does not get called.
		~SqlDataReaderHolder()      
		{
			Dispose(false);
		}

	}
}
