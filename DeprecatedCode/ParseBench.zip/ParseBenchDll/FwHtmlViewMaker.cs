// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FwHtmlView.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// These classes have two functions:
//  1) create HTML views of selected FieldWorks objects (i.e. this is not a generic mechanism)
//	2) handle user clicks on those views which modify the database.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using SIL.FieldWorks.Common.Utils;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.LangProj.Generated;
using System.IO;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	/// <summary>
	/// An abstract class for producing HTML documents representing FieldWorks objects 
	/// and handling user clicks on those HTML pages.
	/// </summary>
	public abstract class FwHtmlView : IDisposable
	{
		protected const string ksOurBogusProtocol = "pb"; // Must be lower-case.
		protected FdoCache m_cache;
		protected CmAgent m_userAgent;
		protected CmAgent m_parserAgent;

		public FwHtmlView(FdoCache cache, CmAgent userAgent, CmAgent parserAgent)
		{
			m_cache = cache;
			m_userAgent= userAgent;
			m_parserAgent = parserAgent;
		}

		public FwHtmlView(FdoCache cache)
		{
			m_cache = cache;
			m_userAgent=cache.LanguageProject.DefaultUserAgent;
			m_parserAgent = m_cache.LanguageProject.DefaultParserAgent;
		}

		public void Dispose()
		{
			m_cache = null;
			m_userAgent = null;
			m_parserAgent = null;
		}
		
		/// <summary>
		/// Handle an event prompted by the user clicking on something which makes Internet Explorer want to navigate to this URL.
		/// These URLs are bogus, they are a way for us to receive input from the user, not real addresses.
		/// </summary>
		/// <param name="eventURL"></param>
		/// <returns>true if the URL was handled.  For example, if the URL was an actual http address, it would not be handled.</returns>
		public bool HandleNavigationEvent (String eventURL)
		{
			try
			{
				if (FwUrl.Handle(m_cache, eventURL))
					return true;
				int afterProtocol = eventURL.IndexOf("://") +3;
				if(afterProtocol <4)
					return false;
				
				//for some reason, we get a trailing '/' which we want to remove
				eventURL = eventURL.TrimEnd(new Char[]{'/', ' '});

				string protocol = eventURL.Substring(0, afterProtocol-3);
				if(protocol != ksOurBogusProtocol)
					return false;

				string content = eventURL.Substring(afterProtocol);
				string[] parameters = content.Split(new Char[]{','});
				Debug.Assert(parameters.Length >= 2);//at least a class name and a code
				string className = parameters[0];
				
				//enhance: consider using reflection to look up the classes
				if(className == "AnalysisView")
					AnalysisView.HandleClickEvent(m_cache,parameters);

				return true;
			}
			catch (Exception error) 
			{
				// REVIEW JohnH(RandyR): WHy catch it, if the caller is to deal with it?
				// Isn't it better to skip the try and catch?
				throw error; // Probably better to let the caller interact with the user over this.
			}
		}

		protected string MakeInternalURL(string code, string parameters)
		{
			string className = this.GetType().Name;
			return ksOurBogusProtocol + "://" + className +"," + code+","+ parameters;
		}



		/// <summary>
		/// Get a temporary file containing HTML.  Warning: call Detach() or hold onto this until anything using the file (e.g. IE) is done with it.
		/// </summary>
		/// <param name="objectId"></param>
		/// <returns></returns>
		public virtual FwTempFile MakeDocument (int objectId)
		{

				FwTempFile output= new FwTempFile(".htm");
				output.Writer.WriteLine(@"
<html  XMLNS:tooltip xmlns='http://www.w3.org/1999/xhtml'>
<head>
	 <meta content='text/html; charset=utf-8' http-equiv='Content-Type'/>
</head>
	  <body><font face='Arial Unicode MS' size='2'>");

/*Don't remove!
<style>
@media all{
   tooltip\:tip{behavior: url('C:\fw\DistFiles\WW\behaviors\ToolTips\tooltip_js.htc')
}
</style>*/

			try
			{
				WriteHTML(output.Writer,objectId);
			}
			catch(Exception error)//locking errors should show up here
			{
				output.Writer.WriteLine("There was an exception<p>"+error.Message+"<p><h3>Stack Trace</h3><p>"+error.StackTrace);
			}

				output.Writer.WriteLine();
				output.Writer.WriteLine(@"</body>");
				output.Writer.WriteLine(@"</html>");
				output.Writer.Close();
				return output;
		}

		public virtual void WriteHTML (TextWriter writer, int objectId)
		{
			writer.WriteLine("hello world");
		}
	}

	/// <summary>
	/// 
	/// </summary>
	public  class WordformView : FwHtmlView
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="cache"></param>
		public WordformView(FdoCache cache) : base(cache)
		{
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="objectId"></param>
		public override void WriteHTML (TextWriter writer, int objectId)
		{
			writer.Write (@"<DIV ID = 'oWord'>");

			WfiWordform word = (WfiWordform)CmObject.CreateFromDBObject(m_cache,objectId);
//			WriteTooltipHTML(writer, word);
			writer.Write(@"	<font face='Arial Unicode MS'>
				<span style='font-weight:bold; font-size:18'>");
			writer.Write(word.Form .VernacularDefaultWritingSystem);
			writer.Write(@"</span></font>");
			writer.WriteLine("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + word.AnalysesOC.Count.ToString() + " analyses");
			writer.Write("<font size='1' color='#808080'>hvo=" + word.Hvo.ToString() + "&nbsp;</font>");
			writer.Write("<font size='1' color='#808080'>Parsed " + word.GetLastEvaluationDate(m_parserAgent.Hvo) + "</font>");
			writer.WriteLine( "<p/>");
			writer.Write (@"</DIV>");
			AnalysisView orange = new AnalysisView(m_cache, m_userAgent, m_parserAgent);
			foreach(WfiAnalysis analysis in word.AnalysesOC)
			{
				orange.WriteHTML(writer,analysis);
			}
		}

		protected void WriteTooltipHTML (TextWriter writer, WfiWordform word)
		{
			writer.Write (@"<tooltip:tip element = 'oWord'>");
			writer.Write ("Last Evaluated on " + word.GetLastEvaluationDate(m_parserAgent.Hvo));
			writer.Write (@"</tooltip:tip>");
		}


	}
	/// <summary>
	/// 
	/// </summary>
	public class AnalysisView : FwHtmlView 
	{
		protected string m_evaluationFontElement = "<font size='2' color='#808080'>";
		protected string m_morphFontElement = "<font size='2'>";
		protected string m_entryFontElement = "<font size='2' color='#000080'>";

		/// <summary>
		/// 
		/// </summary>
		/// <param name="cache"></param>
		public AnalysisView(FdoCache cache, CmAgent userAgent, CmAgent parserAgent)
			: base(cache, userAgent, parserAgent)
		{
		}
		
		/// <summary>
		/// 
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="analysis"></param>
		public void WriteHTML(TextWriter writer, WfiAnalysis analysis)
		{
			//	writer.WriteLine(@"<span style='background-color:powderblue'>Analysis</span>");
			writer.WriteLine(@"<p/><hr/>");

			WriteAnalysisEvaluationControls(writer, analysis);
			//<xsl:apply-templates select='WfiAnalysis_ValidatingSources'/>

			// Forms ----------------------
			writer.WriteLine(@"<span style='font-weight:bold; font-size:2'>");
			writer.WriteLine(@"<table cellspacing='2' cellpadding='1'><tr><td>" + m_morphFontElement + "Morph:</font></td>");

			foreach(WfiMorphBundle bundle in analysis.MorphBundlesOS)
			{
				WriteMorphsCells(writer, (MoForm)bundle.MorphRA);
			}
			writer.WriteLine(@"</tr>");

			// Entries ----------------------
			writer.WriteLine( "<tr><td>" + m_entryFontElement + "LexEntry:</font></td>");

			foreach(WfiMorphBundle bundle in analysis.MorphBundlesOS)
			//foreach(MoForm morph in analysis.MorphsRS) //analysis.MorphsRS)
			{
				WriteEntryCells(writer, GetOwningLexEntry((MoForm)bundle.MorphRA));
			}
			writer.WriteLine(@"</tr>");

			// LexGloss ----------------------
			writer.WriteLine( "<tr><td>" + m_entryFontElement + "LexGloss:</font></td>");

			foreach(WfiMorphBundle bundle in analysis.MorphBundlesOS)
			{
				WriteEntryGlossCells(writer, GetOwningLexEntry((MoForm)bundle.MorphRA));
			}
			writer.WriteLine(@"</tr>");

			// MSAs ----------------------
			writer.WriteLine("<tr><td>" + m_entryFontElement + "LexPOS:</font></td>");

			//foreach(MoMorphoSyntaxAnalysis msa in analysis.MsasRS) //analysis.MorphsRS)
			foreach(WfiMorphBundle bundle in analysis.MorphBundlesOS)
			{
				WriteMSACells(writer, (MoMorphoSyntaxAnalysis)bundle.MsaRA);
			}
			writer.WriteLine(@"</tr>");
			writer.WriteLine(@"</table>");
			writer.WriteLine(@"</span>");
		}

		protected void WriteAnalysisEvaluationControls(TextWriter writer, WfiAnalysis analysis)
		{
			writer.Write(@"<p style='margin-top: 0; margin-bottom: 8'><font size='2' color='#808080'>");
			string sHvoAnalysis = analysis.Hvo.ToString();
			WfiAnalysis.Opinions current = analysis.GetAgentOpinion(m_userAgent);
			if(current == WfiAnalysis.Opinions.noopinion)
			{
				writer.Write("You can mark this analysis as ");
				writer.Write( "<a href=" + MakeInternalURL("approve", sHvoAnalysis) + ">"
					+ m_evaluationFontElement + "correct</font></a>");
				writer.Write(" or ");
				writer.Write( "<a href=" + MakeInternalURL("disapprove", sHvoAnalysis)
					+ ">" + m_evaluationFontElement + "incorrect</font></a>");
				writer.Write(".");
			}
			else
			{
				string opinion="";
				switch(current)
				{
					case WfiAnalysis.Opinions.approves:
						opinion = "correct";
						break;
					case WfiAnalysis.Opinions.disapproves:
						opinion = "incorrect";
						break;
				}
				writer.Write( "You have marked this analysis as <b>"+opinion+"</b>.");
				writer.Write( "<a href=" + MakeInternalURL("noopinion",sHvoAnalysis)
					+ ">"+m_evaluationFontElement + " Change that opinion.</font></a>");
			}	
			writer.Write("</p>");
		}


		/// <summary>
		/// handle an event when the user clicks on a URL that was generated by this class.
		/// </summary>
		/// <param name="parameters">{className, code, (other parameters)...}</param>
		internal static void HandleClickEvent (FdoCache cache, string[] parameters)
		{
			cache.BeginUndoTask("Undo change Opinion", "Redo change opinion");
			try
			{
				Debug.Assert( parameters.Length == 3);
				int hvo = Int32.Parse(parameters[2]);
				WfiAnalysis analysis = WfiAnalysis.CreateFromDBObject(cache,hvo);

				if(parameters[1]=="approve")
				{
					analysis.SetAgentOpinion(cache.LanguageProject.DefaultUserAgent, WfiAnalysis.Opinions.approves);
				}
				else if(parameters[1]=="disapprove")
				{
					analysis.SetAgentOpinion(cache.LanguageProject.DefaultUserAgent, WfiAnalysis.Opinions.disapproves);
				}
				else if(parameters[1]=="noopinion")
				{
					analysis.SetAgentOpinion(cache.LanguageProject.DefaultUserAgent, WfiAnalysis.Opinions.noopinion);
				}
			}
			finally
			{
				cache.EndUndoTask();
			}
		}

		protected LexEntry GetOwningLexEntry (CmObject o)
		{
			//Enhance: could possibly speak this up by turning off validity checking

			//Enhance: could speed this up by storing the C# type of LexEntry and using that as a parameter.
			return LexEntry.CreateFromDBObject(m_cache, o.OwnerHVO);
		}

		protected void WriteMorphsCells(TextWriter writer, MoForm morph)
		{
			writer.Write(@"<td>" + m_morphFontElement);
			writer.Write(morph.ShortName );
			writer.WriteLine("</font></td>");
		}
		protected void WriteMSACells(TextWriter writer, MoMorphoSyntaxAnalysis msa)
		{
			FwUrl url = new FwUrl(msa.Hvo, "POS");
			writer.Write(@"<td>" + m_entryFontElement + "<a href='" + url.URL + "'>");
			writer.Write(msa.InterlinearName);
			writer.WriteLine("</a></font></td>");
		}
		protected void WriteEntryCells(TextWriter writer, LexEntry entry)
		{
			FwUrl url = new FwUrl(entry.Hvo, "lexed");
			writer.Write(@"<td>" + m_entryFontElement + "<a href='" + url.URL + "'>");
			writer.Write(entry.ShortName);
			writer.WriteLine("</a></font></td>");
		}
		protected void WriteEntryGlossCells(TextWriter writer, LexEntry entry)
		{
			//for now, we're just using the same link as the entry...
			//the next step would be to go to the actual first sense.
		//	FwUrl url = new FwUrl(entry.hvo,"lexed");
			FwUrl url;
			if(entry.SensesOS.Count > 0)
				url = new FwUrl(entry.SensesOS[0].Hvo, "lexed");
			else
				url = new FwUrl(entry.Hvo, "lexed");

			writer.Write(@"<td>" + m_entryFontElement + "<a href='" + url.URL + "'>");
			writer.Write(entry.PrimaryGloss);
			writer.WriteLine("</a></font></td>");
		}	
	}
}
