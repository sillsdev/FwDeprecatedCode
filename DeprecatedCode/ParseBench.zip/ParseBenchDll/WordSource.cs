// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: WordSource.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// Implements WordSource and its subclasses: 
//		WholeInventoryWordSource, WordSetWordSource, and QueryWordSource
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;
using SIL.Common.Utils;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
namespace SIL.FieldWorks.WordWorks.ParseBench
{
	/// <summary>
	/// A word source is an object which provides a list of wordforms. 
	/// There are subclasses for getting words from the WFI, WordSets (TestSets), and arbitrary queries.
	/// </summary>
	public abstract class WordSource : IDisposable
	{
		protected FdoCache m_cache;
		public WordSource(FdoCache cache)
		{
			Debug.Assert(cache != null);
			m_cache = cache;
		}

		public void Dispose()
		{
			m_cache = null;
		}
	
		public abstract string GetQueryEnd(); 

		protected string GetFullQuery()
		{
			// REVIEW (SteveMiller): It'd be really nice to get the SQL in one spot, but if 
			// that's not possible, it'd be nice to include as much of the SQL in FillGroupTree().
			// See WordSourceTreeController.cs.

			return GetQueryEnd();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="connection">an already open connection</param>
		/// <returns></returns>
		public SqlDataReaderHolder GetReader()
		{
			try
			{ 
				return new SqlDataReaderHolder(GetCoreConnectionString(), GetFullQuery());
			}
			catch(Exception error) 
			{
				throw error;//TODO JohnH:wrap this in an explanatory exception
			}	
		}	

		/// <summary>
		/// get a connection string which does not mentioned the provider or protocol.
		/// </summary>
		/// <returns></returns>		
		protected string GetCoreConnectionString ()
		{
			return "Server="+m_cache.ServerName+";database="+m_cache.DatabaseName+";user id=fwdeveloper;password=careful";
		}

		public abstract string Label
		{
			get;
		}
	}
	


	/// <summary>
	/// A WordSource which is just the entire WordformInventory of the language project.
	/// </summary>
	/// <remarks>note that this is not named WFIWordSource on purpose, since that would sound like an FDO object.</remarks>
	
	/// <summary>
	/// A WordSource which always delivers the entire WordformInventory
	/// </summary>
	public class WholeInventoryWordSource : WordSource
	{
		public WholeInventoryWordSource(FdoCache cache)
			: base(cache)
		{
		}

		/// <summary>
		/// the string that is displayed next to the icon for this item.
		/// </summary>
		public override string Label
		{
			get {return "All words";}//TODO JohnH: make multilingual, coming from a resource
		}

		public override string GetQueryEnd()
		{
			return @" ORDER BY Txt ";
		}

	}


	/// <summary>
	/// A WordSource which delivers the contents of a WfiWordSet
	/// </summary>
	public class WordSetWordSource : WordSource, IDisposable
	{
		protected WfiWordSet m_wordset;

		public WordSetWordSource(FdoCache cache, WfiWordSet wordset)
			: base(cache)
		{
			m_wordset = wordset;
		}

		public new void Dispose()
		{
			base.Dispose();
			m_wordset = null;
		}

		/// <summary>
		/// the wordSet which this word source is wrapping
		/// </summary>
		public WfiWordSet WordSet
		{
			get
			{
				return m_wordset;
			}
			set
			{
				m_wordset = value;
			}
		}

		/// <summary>
		/// the string that is displayed next to the icon for this item.
		/// </summary>
		public override string Label
		{
			get {return WordSet.Name.AnalysisDefaultWritingSystem;}
		}
		
		public override string GetQueryEnd()
		{
			return @" JOIN WfiWordSet_Cases wsc ON wsc.Src = " + WordSet.Hvo + @"
				AND wsc.Dst = fn.[Id] 
				ORDER BY Txt";
		}		

		/// <summary>
		/// at the word to this list if it is not already in it
		/// </summary>
		/// <param name="hvoWord"></param>
		public void AddWordToList(int hvoWord) 
		{
			this.m_wordset.CasesRC.Add(hvoWord);
		}
	}


	/// <summary>
	/// A WordSource which delivers words based on and Input WordSource as well as a sql query.
	/// In other words, it filters a WordSource.
	/// </summary>
	public class QueryWordSource : WordSource, IDisposable
	{
		protected WordSource m_inputWordSource;
		protected string m_label;//TODO JohnH: make multilingual, coming from a resource 
		protected string m_subquery;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="cache">the FDO cache</param>
		/// <param name="label">The label to use if this is shown to the user.</param>
		/// <param name="subquery">This is the second half of the query so it should start with "and".
		/// Example:"and txt like('b%')"
		/// </param>
		public QueryWordSource(FdoCache cache, string label, string subquery)
			: base(cache)
		{
			m_inputWordSource = null;
			m_label = label;
			m_subquery = subquery;
		}

		public new void Dispose()
		{
			base.Dispose();
			m_inputWordSource = null;
		}

		/// <summary>
		/// the string that is displayed next to the icon for this item.
		/// </summary>
		public override string Label
		{
			get {return m_label;}
		}
		

		public WordSource CurrentWordSource
		{
			set
			{
				//Debug.Assert( value != null);
				m_inputWordSource = value;
			}
		}

		public override string GetQueryEnd()
		{
			return m_subquery + " " + m_inputWordSource.GetQueryEnd();
		}
		 
		/// <summary>
		/// add the words to medium priority queue of the Parser so that they get parsed soon
		/// </summary>
		public void AddWordsToParserQueue()
		{
		}
	}
}
