// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FwController.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
//	Implements FwController
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	public delegate void FwSimpleMessageEventHandler (object sender, FwSimpleStatusEventArgs e);

	/// <summary>
	/// Abstract class for specific controllers.
	/// I am using the term "controller" to refer to an object which is responsible for a mediating 
	/// between a component of the user interface and the database layers.  Such an object must read 
	/// the database and populate the user interface component.  Also, it must act on user actions on 
	/// the user interface object, either passing them on as events or modifying the database.
	/// 
	/// This is a very thin abstract base class. It includes some event handling which is 
	/// common to controllers.
	/// </summary>
	public abstract class FwController
	{
		/// <summary>
		/// This is used to broadcast simple text messages related to status.
		/// </summary>
		public event FwSimpleMessageEventHandler StatusChanged;

		public FwController()
		{
		}


		/// <summary>
		/// Broadcast this message to any delegates that have been wired to this "StatusChanged".
		/// </summary>
		/// <param name="message"></param>
		protected void NotifyOfStatusChanged (string message)
		{
			if (StatusChanged != null) 
			{
				//notify any delegates
				StatusChanged(this, new FwSimpleStatusEventArgs(message)); 
			}
		}
	}
	

	/// <summary>
	/// a simple class to transmit a string message.
	/// </summary>
	/// <remarks>For some reason, the.net documentation says that event arguments are supposed 
	/// to be a subclass of EventArgs, and this whole class rather than just passing a string.  
	/// Perhaps, in the future, we will want to add other properties to this class, like the 
	/// nature of the status.</remarks>
	public class FwSimpleStatusEventArgs : EventArgs 
	{   
		protected string m_message;

		internal FwSimpleStatusEventArgs(string message)
		{
			m_message = message;
		}

		/// <summary>
		/// The status message that is the core of this event.
		/// </summary>
		public string Message
		{
			get
			{
				return m_message;
			}
		}
	}
}
