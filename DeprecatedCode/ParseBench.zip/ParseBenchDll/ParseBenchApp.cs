// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ParseBenchApp.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Windows.Forms;
using SIL.FieldWorks.Common.Framework;
using Microsoft.Win32;
using SIL.FieldWorks.FDO;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	/// <summary>
	/// This is a primarily tool for measuring the effectiveness of a grammar 
	/// at parsing the words in a language.
	/// </summary>
	public class ParseBenchApp : FwApp
	{
		#region Properties
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// The HTML help file (.chm) for the app.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public override string HelpFile
		{
			get { return string.Empty; }
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Guid for the application (used for uniquely identifying DB items that "belong" to
		///		this app.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public static Guid AppGuid
		{
			get
			{
				return new Guid("D161CDE8-99B7-49a2-B874-C1BA113D862F");
			}
		}

		#endregion // Properties

		#region Construction and initialization

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="rgArgs">Command line arguments.</param>
		/// -----------------------------------------------------------------------------------
		public ParseBenchApp(string[] rgArgs)
			: base(rgArgs)
		{
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Application entry point. 
		/// </summary>
		/// <param name="rgArgs">Command-line arguments</param>
		/// <returns>0</returns>
		/// -----------------------------------------------------------------------------------
		[STAThread]
		public static int Main(string[] rgArgs) 
		{
			try
			{
				using(ParseBenchApp app = new ParseBenchApp(rgArgs))
				{
					app.Run();
				}
			}
			catch(Exception e)
			{
				Debug.Write(e.Message);
			}
			return 0;
		}

		#endregion // Construction and initialization

		#region ISettings implementation

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// The RegistryKey for this application.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		override public RegistryKey SettingsKey
		{
			get 
			{
				return base.SettingsKey.CreateSubKey("ParseBench");
			}
		}

		#endregion // ISettings implementation

		#region Required by FwApp

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Creates a new instance of the main Translation Editor window
		/// </summary>
		/// <param name="cache">Instance of the FW Data Objects cache that the new main window
		/// will use for accessing the database.</param>
		/// <param name="fNewCache">Flag indicating whether one-time, application-specific
		/// initialization should be done for this cache.</param>
		/// <param name="fOpeningNewProject"><c>true</c> if opening a brand spankin' new
		/// project</param>
		/// <returns>New instance of PBMainWnd, or null if data not loaded.</returns>
		/// -----------------------------------------------------------------------------------
		override protected Form NewMainAppWnd(FdoCache cache, bool fNewCache, Form wndCopyFrom,
			bool fOpeningNewProject)
		{
			Debug.Assert(wndCopyFrom == null, "wndCopyFrom hanlding not implemented");
			if (!LoadData(cache))
				return null;

			if (fNewCache)
			{
			}
			return new PBMainWnd(cache, wndCopyFrom);
		}

		#endregion // Required by FwApp

		#region Miscellaneous Methods

		//hack until FwApp handles choosing/changing the project
		internal bool ChooseProject()
		{
			// results parms for the dlg.
			bool fHaveProject;
			int hvoProj;
			string sProject;
			Guid  guid;
			bool fHaveSubItem;
			int hvoSubItem;
			string sSubItemName;
			string sServer= Environment.MachineName +"\\SILFW";
			string sDatabase;
 
			string sWsUser = "en";	// should really be loaded from resource
			FwViews.OpenFWProjectDlgClass dlg = new FwViews.OpenFWProjectDlgClass();
			dlg.Show(null, null, sServer, sWsUser, (uint)0/*this.Handle*/, true, 0, "xxxxxxxxxx.htm");
			dlg.GetResults(out fHaveProject, out hvoProj, out sProject,
				out sDatabase, 
				out sServer,
				out guid,
				out fHaveSubItem, out hvoSubItem,
				out sSubItemName);
			if (!fHaveProject)
				return false;
            
			FdoCache cache = FdoCache.Create(sServer, sDatabase, sProject, sSubItemName);

			//hack
			//!!! the application will want to exit when the last window is closed
//			foreach(Form w in this.MainWindows)
//			{
//				w.Close();
//				break; //we only have one, and closing that window actually invalidated the Enumerator.
//			}

//
			RegistryKey key = this.SettingsKey; //Registry.CurrentUser.CreateSubKey("Software\\SIL\\FieldWorks\\ParseBench");
			
			// Save Database Settings
			key.SetValue("LatestDatabaseName", cache.DatabaseName);
			key.SetValue("LatestDatabaseServer", cache.ServerName);
			key.SetValue("LatestProjectName", cache.LanguageProject.Name.AnalysisDefaultWritingSystem);

			MessageBox.Show("HACK: ParseBench will now exit. When you run it again, it will use the new language project.");

//			System.Diagnostics.ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo(Application.ExecutablePath);
//			System.Diagnostics.Process.Start(info); //relaunch me

			return true;
		}

	
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// make sure that this LanguageProject is ready for WordWorks
		/// </summary>
		/// <param name="cache">FDO cache for accessing DB</param>
		/// <returns>true</returns>
		/// -----------------------------------------------------------------------------------
		protected bool LoadData(FdoCache cache)
		{
			return true;
		}


		#endregion
	}
}
