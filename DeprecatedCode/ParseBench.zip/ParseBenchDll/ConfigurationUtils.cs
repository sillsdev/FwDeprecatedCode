// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ConfigurationUtils.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// Holds utilities for working with the.net configuration files.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;

namespace SIL.Common.Utils
{
	/// <summary>
	/// 
	/// </summary>
	public class ConfigurationUtils
	{
		public ConfigurationUtils()
		{
			// 
			// TODO: Add constructor logic here
			//
		}

		public static bool GetBooleanConfigSetting (System.Collections.Specialized.NameValueCollection settings,  
			string name,
			bool defaultValue)
		{
			if(settings[name]==null)
				return defaultValue;
			return (settings[name].ToLower()=="yes" ||  settings[name].ToLower()=="true");
			//noticed that this will return false if it does not understand what the user put there
		}

		public static int GetIntegerConfigSetting (System.Collections.Specialized.NameValueCollection settings,  
			string name,
			int defaultValue)
		{
			if(settings[name]==null)
				return defaultValue;

			try
			{
				return Convert.ToInt32(settings[name]);
			}
			catch (Exception) 
			{
				return defaultValue;
			}
		}

	}
}
