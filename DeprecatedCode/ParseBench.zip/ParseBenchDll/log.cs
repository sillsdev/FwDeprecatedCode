using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace SIL.FieldWorks.WordWorks.ParseBench
{
	/// <summary>
	/// Summary description for LogWindow.
	/// </summary>
	public class LogWindow : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RichTextBox rtLogWindow;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public LogWindow()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			this.Visible = false;
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.rtLogWindow = new System.Windows.Forms.RichTextBox();
			this.SuspendLayout();
			// 
			// rtLogWindow
			// 
			this.rtLogWindow.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rtLogWindow.Name = "rtLogWindow";
			this.rtLogWindow.ReadOnly = true;
			this.rtLogWindow.Size = new System.Drawing.Size(501, 540);
			this.rtLogWindow.TabIndex = 0;
			this.rtLogWindow.Text = "";
			// 
			// LogWindow
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
			this.ClientSize = new System.Drawing.Size(501, 540);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.rtLogWindow});
			this.Name = "LogWindow";
			this.ShowInTaskbar = false;
			this.Text = "Parsing LogWindow";
			this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
			this.Closing += new System.ComponentModel.CancelEventHandler(this.LogWindow_Closing);
			this.ResumeLayout(false);

		}
		#endregion

		public void WriteLine (string s)
		{
			rtLogWindow.AppendText(s+"\r\n");
			//if(!m_log.Visible)
		//	Hide();
			Show ();
			this.BringToFront();

		}
		public void WriteLine ()
		{
			rtLogWindow.AppendText("\r\n");
		}
		public void Write (string s)
		{
			rtLogWindow.AppendText(s);
		}

		private void LogWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			this.Hide();
			e.Cancel = true;
		}
	}
}
