/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: AfNewProj.cpp
Responsibility: Steve McConnel
Last reviewed: never.

Description:
	Implementation of the File / New wizard dialog classes for the Data Notebook.
-------------------------------------------------------------------------------*//*:End Ignore*/
#include "Main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

#include <direct.h>
/*
BEGIN_CMD_MAP(AfNewProjVernacular)
	ON_CID_CHILD(kcidWizProjLanguagePopupMenu, &AfNewProjVernacular::CmdLangPopup, NULL)
END_CMD_MAP_NIL()
BEGIN_CMD_MAP(AfNewProjAnalysis)
	ON_CID_CHILD(kcidWizProjAnalPopupMenu, &AfNewProjAnalysis::CmdLangPopup, NULL)
END_CMD_MAP_NIL()
*/
//:>********************************************************************************************
//:>	AfNewLanguageProjectWizard Implementation
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Initialize the dialog in response to the WM_INITDIALOG message.
	All one-time initialization should be done here (that is, all controls have been created
	and have valid hwnd's, but they need initial values.)

	@param hwndCtrl Not used by this method.
	@param lp Not used by this method.

	@return True.
----------------------------------------------------------------------------------------------*/
bool AfNewLanguageProjectWizard::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	AddPage(NewObj AfNewProjIdentify());
	AddPage(NewObj AfNewProjVernacular());
	AddPage(NewObj AfNewProjAnalysis());

	GetAvailableFonts();

	StrApp strTitle(kstidWizProjCaption);
	::SetWindowText(m_hwnd, strTitle.Chars());

	m_lcidAnal = ::GetUserDefaultLCID();
	m_lgidAnal = (WORD)PRIMARYLANGID(LANGIDFROMLCID(m_lcidAnal));
	// Required for later test.  This has to be 0 to avoid overwriting the name of the analysis
	// writing system from the NewLangProj.xml file in the case where the user chooses one of
	// the "standard" languages for the analysis writing system.
	m_lcidAnal = 0;

	m_strXmlFile.Assign(_T("NewLangProj.xml"));

	// Get the FieldWorks root directory, first trying to find it in the registry, then using a
	// dumb default value.
	StrAppBufPath strbpFwRoot;
	HKEY hk;
	if (::RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("Software\\SIL\\FieldWorks"), 0, KEY_QUERY_VALUE,
		&hk) == ERROR_SUCCESS)
	{
		achar rgch[MAX_PATH];
		DWORD cb = isizeof(rgch);
		DWORD dwT;
		LONG nRet = ::RegQueryValueEx(hk, _T("RootDir"), NULL, &dwT, (BYTE *)rgch, &cb);
		if (nRet == ERROR_SUCCESS)
		{
			Assert(dwT == REG_SZ);
			strbpFwRoot.Assign(rgch);
		}
		RegCloseKey(hk);
	}
	if (!strbpFwRoot.Length())
		strbpFwRoot.Assign("C:\\FieldWorks");

	// Set the template directory path.
	StrAnsi sta(strbpFwRoot.Chars(), strbpFwRoot.Length());
	_mkdir(sta.Chars());
	sta.Append("\\Templates");
	_mkdir(sta.Chars());
	m_strTemplateDir.Assign(sta.Chars(), sta.Length());

	// Set the data directory path.
	sta.Assign(strbpFwRoot.Chars(), strbpFwRoot.Length());
	sta.Append("\\Data");
	_mkdir(sta.Chars());
	m_strDataDir.Assign(sta.Chars(), sta.Length());

	// Subclass the Help button.
	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidHelp, kbtHelp, NULL, 0);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Get the list of all available fonts.
----------------------------------------------------------------------------------------------*/
void AfNewLanguageProjectWizard::GetAvailableFonts()
{
	if (!m_vstrFonts.Size())
	{
		// Get the currently available fonts via the LgFontManager.

		ILgFontManagerPtr qfm;
		SmartBstr bstrNames;

		qfm.CreateInstance(CLSID_LgFontManager);
		CheckHr(qfm->AvailableFonts(&bstrNames));
		static long ipszList = 0; // Returned value from SendMessage.

		StrApp strNameList;
		strNameList.Assign(bstrNames.Bstr(), BstrLen(bstrNames.Bstr()));
		int cchLength = strNameList.Length();
		StrApp strName;		// Individual font name.
		int ichMin;			// Index of the beginning of a font name.
		int ichLim;			// Index that is one past the end of a font name.

		// Add each font name to the list.
		for (ichMin = 0, ichLim = 0; ichLim < cchLength; ichMin = ichLim + 1)
		{
			ichLim = strNameList.FindCh(L',', ichMin);
			if (ichLim == -1) // i.e., if not found.
			{
				ichLim = cchLength;
			}
			strName.Assign(strNameList.Chars() + ichMin, ichLim - ichMin);
			m_vstrFonts.Push(strName);
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Find the language name in m_vlangid, and set m_lgidAnal and m_lcidAnal accordingly.

	@param rgchName Name of the analysis language (and locale).
	@param cchName Number of characters in rgchName.
----------------------------------------------------------------------------------------------*/
void AfNewLanguageProjectWizard::SetAnalLang(achar * rgchName, int cchName)
{
	AssertArray(rgchName, cchName);

	Vector<SysLangInfo> & vsli = AfSystemLanguageList::GetLanguages();
	StrApp strName(rgchName, cchName);
	int iv;
	int ivMid;
	int ivLim;
	for (iv = 0, ivLim = vsli.Size(); iv < ivLim; )
	{
		ivMid = (iv + ivLim) / 2;
		if (_tcscoll(vsli[ivMid].m_strName.Chars(), strName.Chars()) < 0)
			iv = ivMid + 1;
		else
			ivLim = ivMid;
	}
	if (vsli[iv].m_strName == strName)
	{
		m_lcidAnal = vsli[iv].m_lcid;
		m_lgidAnal = (WORD)PRIMARYLANGID(LANGIDFROMLCID(m_lcidAnal));
	}
}


/*----------------------------------------------------------------------------------------------
	Create a new language project database.
----------------------------------------------------------------------------------------------*/
void AfNewLanguageProjectWizard::CreateNewLangProj()
{
	WaitCursor wc;

	StrApp strDbName = AfDbApp::FilterForFileName(m_strLanguageName);
	StrUni stuLang(m_strLanguageName);
	StrUni stuDbName(strDbName);
	StrUni stuServer(dynamic_cast<AfDbApp *>(AfApp::Papp())->GetLocalServer());
	m_stuServer = stuServer;	// Save for later retrieval.
	StrUni stuDatabase(L"master");
	StrApp strTitle(kstidWizProjMsgCaption);

	AfProgressDlgPtr qprog;
	qprog.Create();
	qprog->DoModeless(m_hwnd);
	StrApp strMsg(kstidWizProjProgStep1);
	qprog->SetMessage(strMsg.Chars());
	StrApp strFmt(kstidWizProjInitializingFmt);
	strMsg.Format(strFmt.Chars(), m_strLanguageName.Chars());
	qprog->SetTitle(strMsg.Chars());
	qprog->SetRange(0, 3);

	try
	{
		HVO hvoLP;
		IOleDbEncapPtr qode; // Declare before qodc.
		IOleDbCommandPtr qodc;
		HRESULT hr;
		IStreamPtr qfist;

		// Get the IStream pointer for logging. NULL returned if no log file.
		hr = AfApp::Papp()->GetLogPointer(&qfist);
		// Copy the template database files, renaming them in the process, and then "attach"
		// the new database.
		StrApp strTemplate(m_strTemplateDir);
		strTemplate.Append(_T("\\BlankLangProj.mdf"));
		StrApp strNewFile;
		StrApp str;
		StrApp strFileFmt(_T("%s\\%s"));
		strNewFile.Format(strFileFmt.Chars(), m_strDataDir.Chars(),
			strDbName.Chars());
		StrApp strOrgFileName(strNewFile.Chars());
		str.Format(_T("%s.mdf"), strNewFile.Chars());
		StrApp strCnt("");
		int ncnt = 0;
		BOOL fOk = ::CopyFile(strTemplate.Chars(), str.Chars(), TRUE);
		if (!fOk)
		{
			DWORD dwError = ::GetLastError();
			if (dwError == ERROR_FILE_NOT_FOUND)
			{
				strFmt.Load(kstidWizProjNoBlankFmt);
				str.Format(strFmt.Chars(), strTemplate.Chars());
				::MessageBox(m_pafw->Hwnd(), str.Chars(), strTitle.Chars(),
					MB_OK | MB_ICONWARNING);
				ThrowHr(S_OK);		// Error already reported to the user.
			}
			if (dwError == ERROR_FILE_EXISTS)
			{
				do
				{
					// The database name already exists so make a name with a number appended.
					ncnt ++;
					strNewFile.Assign(strOrgFileName.Chars(), strOrgFileName.Length());
					strCnt.Format(_T("%d"), ncnt);
					strNewFile.Append(strCnt.Chars(),strCnt.Length());
					str.Format(_T("%s.mdf"), strNewFile.Chars());
					fOk = ::CopyFile(strTemplate.Chars(), str.Chars(), TRUE);
					if (!fOk)
					{
						dwError = ::GetLastError();
						if (dwError != ERROR_FILE_EXISTS)
						{
#ifdef DEBUG
							StrApp strDebug;
							strDebug.Load(kstidWizProjUnknownError);
							str.Format(_T("%s; error=%d."), strDebug.Chars(), dwError);
#else
							str.Load(kstidWizProjUnknownError);
#endif
							::MessageBox(m_pafw->Hwnd(), str.Chars(), strTitle.Chars(),
								MB_OK | MB_ICONERROR);
							ThrowHr(S_OK);		// Error already reported to the user.
						}
					}
				} while (!fOk);
			}
		}
		if (fOk)
		{
			qprog->StepIt();
			strFileFmt.Assign(_T("%s\\BlankLangProj_Log.ldf"));
			strTemplate.Format(strFileFmt.Chars(), m_strTemplateDir.Chars());
			str.Format(_T("%s_Log.ldf"),strNewFile.Chars());
			fOk = ::CopyFile(strTemplate.Chars(), str.Chars(), TRUE);
		}
		if (!fOk)
		{
			str.Load(kstidWizProjCannotCopyLPDB);
			::MessageBox(m_pafw->Hwnd(), str.Chars(), strTitle.Chars(), MB_OK | MB_ICONWARNING);
			ThrowHr(S_OK);		// Error already reported to the user.
		}
		qprog->StepIt();
		qode.CreateInstance(CLSID_OleDbEncap);
		CheckHr(qode->Init(stuServer.Bstr(), stuDatabase.Bstr(), qfist, koltMsgBox, 0));
		CheckHr(qode->CreateCommand(&qodc));
		StrUni stuDataDir(m_strDataDir);
		StrUni stuCmd;
		StrUni stuCnt(strCnt);
		StrUni stuNewFile(strNewFile);
		stuDbName.Append(stuCnt.Chars(), stuCnt.Length());
		m_stuDbName = stuDbName;	// Save for later retrieval.
		stuCmd.Format(L"EXEC sp_attach_db '%s', '%s.mdf', '%s_Log.ldf'",
			stuDbName.Chars(), stuNewFile.Chars(), stuNewFile.Chars());

		hr = qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults);
		if (FAILED(hr))
		{
			str.Load(kstidWizProjCannotAttach);
			::MessageBox(m_pafw->Hwnd(), str.Chars(), strTitle.Chars(), MB_OK | MB_ICONSTOP);
			ThrowHr(S_OK);		// Error already reported to the user.
		}
		qodc.Clear();
		qode.Clear();
		qprog->StepIt();
		strMsg.Load(kstidWizProjProgStep2);
		qprog->SetMessage(strMsg.Chars());
		qprog->SetRange(0, 100);

		// Load the minimal NewLangProj.xml into the new database.
		IFwXmlDataPtr qfwxd;
		qfwxd.CreateInstance(CLSID_FwXmlData, CLSCTX_INPROC_SERVER);
		CheckHr(qfwxd->Open(stuServer.Bstr(), stuDbName.Bstr()));
		StrUni stuXml(m_strTemplateDir);
		stuXml.Append(L"\\");
		Assert(m_strXmlFile.Length());
		stuXml.Append(m_strXmlFile);

		IAdvIndPtr qadvi;
		qprog->QueryInterface(IID_IAdvInd, (void **)&qadvi);
		CheckHr(qfwxd->LoadXml(stuXml.Bstr(), qadvi));
		qfwxd->Close();
		qfwxd.Clear();

		// Set the language and language encodings for the new database.
		qode.CreateInstance(CLSID_OleDbEncap);
		CheckHr(qode->Init(stuServer.Bstr(), stuDbName.Bstr(), qfist, koltMsgBox, 0));
		CheckHr(qode->CreateCommand(&qodc));

		ComBool fMoreRows;
		ComBool fIsNull = TRUE;
		ULONG cbSpaceTaken;

		stuCmd.Assign("SELECT [Id] FROM LanguageProject (readuncommitted)");
		CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));
		if (fMoreRows)
		{
			CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&hvoLP), isizeof(hvoLP),
				&cbSpaceTaken, &fIsNull, 0));
		}
		if (fIsNull)
		{
			str.Load(kstidWizProjCannotInit);
			::MessageBox(m_pafw->Hwnd(), str.Chars(), strTitle.Chars(), MB_OK | MB_ICONWARNING);
			ThrowHr(S_OK);		// Error already reported to the user.
		}
		m_hvoLP = hvoLP;	// Save for future retrieval.

		int wsUser = AfDbApp::UserWs(qode);

		// Change the name of the notebook from the default in the XML file.
		stuCmd.Format(L"SELECT Dst FROM LanguageProject_ResearchNotebook WHERE Src = %d",
			m_hvoLP);
		CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));
		if (fMoreRows)
		{
			HVO hvoRn;
			CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&hvoRn), isizeof(hvoRn),
				&cbSpaceTaken, &fIsNull, 0));
			if (!fIsNull)
			{
				StrUni stuFmt;
				stuFmt.Load(kstidWizProjNameFmt);
				StrUni stuRnName;
				stuRnName.Format(stuFmt.Chars(), stuLang.Chars());
				StrUtil::NormalizeStrUni(stuRnName, UNORM_NFD);
				stuCmd.Format(L"DELETE FROM MultiTxt$ where Obj=%d AND Flid=%d;"
					L"INSERT INTO MultiTxt$ (Flid,Obj,Ws,Txt) VALUES (%d,%d,%d,?)",
					hvoRn, kflidCmMajorObject_Name, kflidCmMajorObject_Name, hvoRn, wsUser);
				CheckHr(qodc->SetParameter(1, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_WSTR,
					(ULONG *)stuRnName.Chars(), stuRnName.Length() * sizeof(OLECHAR)));
				CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
				CheckHr(qode->CreateCommand(&qodc));
			}
		}

		StrUni stuEthCode(m_strEthCode);
		StrUtil::NormalizeStrUni(stuEthCode, UNORM_NFD);
		// Convert from Ethnologue code to ISO equivalent.
		StrUni stuIsoCode(SilUtil::ConvertEthnologueToISO(stuEthCode.Chars()));
		stuEthCode.Assign(stuIsoCode);
		stuCmd.Format(L"UPDATE LanguageProject SET EthnologueCode='%s' WHERE [ID]=%d",
			stuEthCode.Chars(), hvoLP);
		CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		qprog->StepIt();
		StrUtil::NormalizeStrUni(stuLang, UNORM_NFD);
		CheckHr(qodc->SetParameter(1, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_WSTR,
			(ULONG *)stuLang.Chars(), stuLang.Length() * sizeof(OLECHAR)));
		stuCmd.Format(L"INSERT INTO MultiTxt$ (Flid,Obj,Ws,Txt) VALUES (%d,%d,%d,?)",
			kflidCmProject_Name, hvoLP, wsUser);
		CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		qodc.Clear();
		qprog->StepIt();

		// Create the vernacular writing system.
		int wsVern;
		ILgWritingSystemFactoryBuilderPtr qwsfb;
		ILgWritingSystemFactoryPtr qwsf;
		ILgWritingSystemPtr qws;
		qwsfb.CreateInstance(CLSID_LgWritingSystemFactoryBuilder);
		CheckHr(qwsfb->GetWritingSystemFactory(qode, qfist, &qwsf));
		AssertPtr(qwsf);
		CheckHr(qwsf->GetWsFromStr(stuEthCode.Bstr(), &wsVern));
		if (wsVern)
			CheckHr(qwsf->RemoveEngine(wsVern));
		CheckHr(qwsf->get_Engine(stuEthCode.Bstr(), &qws));
		if (!wsVern)
			CheckHr(qwsf->GetWsFromStr(stuEthCode.Bstr(), &wsVern));
		Assert(wsVern);
		if (m_lcid)
			CheckHr(qws->put_Locale(m_lcid));
		CheckHr(qws->put_Name(wsUser, stuLang.Bstr()));
		// Set the default fonts.
		CheckHr(qws->put_DefaultSerif(m_strNormalFont.Bstr()));
		CheckHr(qws->put_DefaultSansSerif(m_strHeadingFont.Bstr()));
		CheckHr(qwsf->SaveWritingSystems());
		qprog->StepIt();

		// Create the analysis writing system if needed.
		int wsAnal = 0;
		StrUni stuAnalCode;
		ILgWritingSystemPtr qwsAnal;
		switch (m_lgidAnal)
		{
		case LANG_AFRIKAANS:
			stuAnalCode = "AFK";
			break;
		case LANG_ALBANIAN:
			stuAnalCode = "ALS";		// or ?
			break;
		case LANG_ARABIC:
			stuAnalCode = "ABV";		// or ?
			break;
		case LANG_ARMENIAN:
			stuAnalCode = "ARM";
			break;
		case LANG_ASSAMESE:
			stuAnalCode = "ASM";
			break;
		case LANG_AZERI:
			stuAnalCode = "AZE";
			break;
		case LANG_BASQUE:
			stuAnalCode = "BSQ";
			break;
		case LANG_BELARUSIAN:
			stuAnalCode = "RUW";
			break;
		case LANG_BENGALI:
			stuAnalCode = "BNG";
			break;
		case LANG_BULGARIAN:
			stuAnalCode = "BLG";
			break;
		case LANG_CATALAN:
			stuAnalCode = "CLN";
			break;
		case LANG_CHINESE:
			stuAnalCode = "CHN";		// ?
			break;
		case LANG_CROATIAN:
			stuAnalCode = "SRC";
			break;
		case LANG_CZECH:
			stuAnalCode = "CZC";
			break;
		case LANG_DANISH:
			stuAnalCode = "DNS";
			break;
		case LANG_DUTCH:
			stuAnalCode = "DUT";
			break;
		case LANG_ENGLISH:
			stuAnalCode = "en";
			break;
		case LANG_ESTONIAN:
			stuAnalCode = "EST";
			break;
		case LANG_FAEROESE:
			stuAnalCode = "FAE";
			break;
		case LANG_FARSI:
			stuAnalCode = "PRS";		// or ?
			break;
		case LANG_FINNISH:
			stuAnalCode = "FIN";
			break;
		case LANG_FRENCH:
			stuAnalCode = "fr";
			break;
		case LANG_GEORGIAN:
			stuAnalCode = "GEO";
			break;
		case LANG_GERMAN:
			stuAnalCode = "de";
			break;
		case LANG_GREEK:
			stuAnalCode = "GRK";
			break;
		case LANG_GUJARATI:
			stuAnalCode = "GJR";
			break;
		case LANG_HEBREW:
			stuAnalCode = "HBR";
			break;
		case LANG_HINDI:
			stuAnalCode = "HND";
			break;
		case LANG_HUNGARIAN:
			stuAnalCode = "HNG";
			break;
		case LANG_ICELANDIC:
			stuAnalCode = "ICE";
			break;
		case LANG_INDONESIAN:
			stuAnalCode = "INZ";
			break;
		case LANG_ITALIAN:
			stuAnalCode = "ITN";
			break;
		case LANG_JAPANESE:
			stuAnalCode = "JPN";
			break;
		case LANG_KANNADA:
			stuAnalCode = "KJV";
			break;
		case LANG_KASHMIRI:
			stuAnalCode = "KSH";
			break;
		case LANG_KAZAK:
			stuAnalCode = "KAZ";
			break;
		case LANG_KONKANI:
			stuAnalCode = "KNK";
			break;
		case LANG_KOREAN:
			stuAnalCode = "KKN";
			break;
		case LANG_LATVIAN:
			stuAnalCode = "LAT";
			break;
		case LANG_LITHUANIAN:
			stuAnalCode = "LIT";
			break;
		case LANG_MACEDONIAN:
			stuAnalCode = "MKJ";
			break;
		case LANG_MALAY:
			stuAnalCode = "MLI";		// or ?
			break;
		case LANG_MALAYALAM:
			stuAnalCode = "MJS";
			break;
		case LANG_MANIPURI:
			stuAnalCode = "MNR";
			break;
		case LANG_MARATHI:
			stuAnalCode = "MRT";
			break;
		case LANG_NEPALI:
			stuAnalCode = "NEP";
			break;
		case LANG_NORWEGIAN:
			stuAnalCode = "NRR";
			break;
		case LANG_ORIYA:
			stuAnalCode = "ORY";		// or ?
			break;
		case LANG_POLISH:
			stuAnalCode = "PQL";
			break;
		case LANG_PORTUGUESE:
			stuAnalCode = "POR";
			break;
		case LANG_PUNJABI:
			stuAnalCode = "PNJ";
			break;
		case LANG_ROMANIAN:
			stuAnalCode = "RUM";
			break;
		case LANG_RUSSIAN:
			stuAnalCode = "RUS";
			break;
		case LANG_SANSKRIT:
			stuAnalCode = "SKT";
			break;
		case LANG_SINDHI:
			stuAnalCode = "SND";
			break;
		case LANG_SLOVAK:
			stuAnalCode = "SLO";
			break;
		case LANG_SLOVENIAN:
			stuAnalCode = "SLV";
			break;
		case LANG_SPANISH:
			stuAnalCode = "es";
			break;
		case LANG_SWAHILI:
			stuAnalCode = "SWA";
			break;
		case LANG_SWEDISH:
			stuAnalCode = "SWD";
			break;
		case LANG_TAMIL:
			stuAnalCode = "TCV";
			break;
		case LANG_TATAR:
			stuAnalCode = "TTR";
			break;
		case LANG_TELUGU:
			stuAnalCode = "TCW";
			break;
		case LANG_THAI:
			stuAnalCode = "THJ";
			break;
		case LANG_TURKISH:
			stuAnalCode = "TRK";
			break;
		case LANG_UKRAINIAN:
			stuAnalCode = "UKR";
			break;
		case LANG_URDU:
			stuAnalCode = "URD";
			break;
		case LANG_UZBEK:
			stuAnalCode = "UZB";		// or ?
			break;
		case LANG_VIETNAMESE:
			stuAnalCode = "VIE";
			break;
		default:
			stuAnalCode = "en";
			break;
		}
		Assert(stuAnalCode.Length());
		CheckHr(qwsf->GetWsFromStr(stuAnalCode.Bstr(), &wsAnal));
		if (wsAnal)
		{
			CheckHr(qwsf->get_EngineOrNull(wsAnal, &qwsAnal));
			AssertPtr(qwsAnal.Ptr());
		}
		else
		{
			CheckHr(qwsf->get_Engine(stuAnalCode.Bstr(), &qwsAnal));
			Assert(qwsAnal);
			CheckHr(qwsf->GetWsFromStr(stuAnalCode.Bstr(), &wsAnal));
			Assert(wsAnal);
			StrUni stuSerifFontName(L"Times New Roman");
			CheckHr(qwsAnal->put_DefaultSerif(stuSerifFontName.Bstr()));
			StrUni stuSSFontName(L"Arial");
			CheckHr(qwsAnal->put_DefaultSansSerif(stuSSFontName.Bstr()));
		}
		if (m_lcidAnal)
			CheckHr(qwsAnal->put_Locale(m_lcidAnal));
		StrUni stuAnalFull = AfSystemLanguageList::GetLanguageName(m_lcidAnal);
		if (stuAnalFull.Length())
		{
			StrUni stuAnal = stuAnalFull;
			int ich = stuAnal.FindStr(L" (");
			if (ich >= 0)
				stuAnal.Replace(ich, stuAnal.Length(), L"");
			qwsAnal->put_Name(wsUser, stuAnal.Bstr());
			if (stuAnalFull != stuAnal)
			{
				ITsStrFactoryPtr qtsf;
				qtsf.CreateInstance(CLSID_TsStrFactory);
				AssertPtr(qtsf);
				ITsStringPtr qtss;
				CheckHr(qtsf->MakeString(stuAnalFull.Bstr(), wsUser, &qtss));
				CheckHr(qwsAnal->put_Description(wsUser, qtss));
			}
		}
		CheckHr(qwsf->SaveWritingSystems());
		qwsf.Clear();
		qprog->StepIt();

		// Set the vernacular, analysis, and project encodings in the database.
		CheckHr(qode->CreateCommand(&qodc));
		HVO hvoVern = wsVern;
		HVO hvoAnal = wsAnal;
		Assert(hvoVern);
		if (hvoVern)
		{
			stuCmd.Format(
				L"INSERT INTO LanguageProject_CurrentVernacularWritingSystems (Src,Dst,Ord) "
				L"VALUES (%d, %d, 0)", hvoLP, hvoVern);
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
			stuCmd.Format(L"INSERT INTO LanguageProject_VernacularWritingSystems (Src,Dst) "
				L"VALUES (%d, %d)", hvoLP, hvoVern);
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		}
		Assert(hvoAnal);
		if (hvoAnal)
		{
			stuCmd.Format(
				L"INSERT INTO LanguageProject_CurrentAnalysisWritingSystems (Src,Dst,Ord) "
				L"VALUES (%d, %d, 0)", hvoLP, hvoAnal);
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
			stuCmd.Format(L"INSERT INTO LanguageProject_AnalysisWritingSystems (Src,Dst) "
				L"VALUES (%d, %d)", hvoLP, hvoAnal);
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		}

		qodc.Clear();
		qode.Clear();
		strMsg.Load(kstidWizProjProgStep3);
		qprog->SetMessage(strMsg.Chars());
		qprog->SetRange(0, 3);
		qprog->SetPos(0);
		qprog->DestroyHwnd();
		qprog.Clear();
	}
	catch (Throwable & thr)
	{
		if (thr.Error() != S_OK)
		{
			ComSmartPtr<IErrorInfo> qei;
			HRESULT hr = ::GetErrorInfo(0, &qei);
			if (hr == S_OK && qei)
			{
				strMsg.Load(kstidWizProjError);
				::MessageBox(m_pafw->Hwnd(), strMsg.Chars(), strTitle.Chars(),
					MB_OK | MB_ICONERROR);
			}
			else
			{
				strMsg.Load(kstidWizProjUnknownError);
				::MessageBox(m_pafw->Hwnd(), strMsg.Chars(), strTitle.Chars(),
					MB_OK | MB_ICONERROR);
			}
		}
	}
	catch (...)
	{
		strMsg.Load(kstidWizProjUnknownError);
		::MessageBox(m_pafw->Hwnd(), strMsg.Chars(), strTitle.Chars(), MB_OK | MB_ICONERROR);
	}
	if (qprog)
	{
		qprog->DestroyHwnd();
		qprog.Clear();
	}
}


//:>********************************************************************************************
//:>	AfNewProjIdentify Implementation
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Initialize the dialog in response to the WM_INITDIALOG message.
	All one-time initialization should be done here (that is, all controls have been created
	and have valid hwnd's, but they need initial values.)

	@param hwndCtrl Not used by this method.
	@param lp Not used by this method.

	@return True.
----------------------------------------------------------------------------------------------*/
bool AfNewProjIdentify::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	// Set the font for the page title.
	m_hfontLarge = AfGdi::CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET,
		OUT_CHARACTER_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH | FF_SWISS,
		_T("MS Sans Serif"));
	if (m_hfontLarge)
	{
		::SendMessage(::GetDlgItem(m_hwnd, kridWizProjIdentifyTitle), WM_SETFONT,
			(WPARAM)m_hfontLarge, false);
	}
	StrApp str(kstidWizProjIdentifyTitle);
	::SetWindowText(::GetDlgItem(m_hwnd, kridWizProjIdentifyTitle), str.Chars());

	str.Load(kstidWizProjDefaultLanguage);
	::SetWindowText(::GetDlgItem(m_hwnd, kctidWizProjIdentifyLanguage), str.Chars());

	::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjIdentifyEthCode), EM_LIMITTEXT, 5, 0);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}


/*----------------------------------------------------------------------------------------------
	Handle a WM_NOTIFY message, first letting the superclass method handle it if possible.

	@param ctidFrom Identifies the control sending the message.
	@param pnmh Pointer to the notification message data.
	@param lnRet Reference to a long integer return value used by some messages.

	@return True if the message is handled successfully; otherwise, false.
----------------------------------------------------------------------------------------------*/
bool AfNewProjIdentify::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (SuperClass::OnNotifyChild(ctidFrom, pnmh, lnRet))
		return true;

	switch (pnmh->code)
	{
	case EN_CHANGE:
		switch (ctidFrom)
		{
			case kctidWizProjIdentifyEthCode:
			{
				StrAppBuf strb;
				int cch;
				cch = ::SendMessage (pnmh->hwndFrom, WM_GETTEXT, strb.kcchMaxStr,
					(LPARAM)strb.Chars());
				if (cch >= strb.kcchMaxStr)
					cch = strb.kcchMaxStr;
				strb.SetLength(cch);

				achar rgch[100];
				_tcscpy(rgch, strb.Chars());
				StrApp strEth(_T(""));
				bool fInvalid = false;
				for (int i = 0; i < 5; ++i)
				{
					if (i == cch)
						break;
					if (i < 3)
					{
						if ((rgch[i] >='A' && rgch[i] <='Z'))
								strEth.Append(rgch + i, 1);
						else
						{
								fInvalid = true;
								::MessageBeep(MB_ICONEXCLAMATION);
								break;
						}
					}
					else if (i < 5)
					{
						if ((rgch[i] >='0' && rgch[i] <='9'))
							strEth.Append(rgch + i, 1);
						else
						{
							fInvalid = true;
							::MessageBeep(MB_ICONEXCLAMATION);
							break;
						}
					}
					else if (i == 5)
					{
						fInvalid = true;
						::MessageBeep(MB_ICONEXCLAMATION);
						break;
					}

				}
				if (fInvalid)
				{
					::SendMessage(pnmh->hwndFrom, WM_SETTEXT, 0, (LPARAM)strEth.Chars());
					::SendMessage(pnmh->hwndFrom, EM_SETSEL, (WPARAM)strEth.Length(),
						(LPARAM)-1);
				}
				SetNextEnbl();
				break;
			}
			case kctidWizProjIdentifyLanguage:
			{
				SetNextEnbl();
				break;
			}
		}
		break;
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Either enables the Next button or disables it depending on if there is valid data.
----------------------------------------------------------------------------------------------*/
void AfNewProjIdentify::SetNextEnbl()
{
			achar rgch[100];
			bool fOk = true;
			int cchLang = ::GetDlgItemText(m_hwnd, kctidWizProjIdentifyLanguage, rgch, 100);
			if (cchLang == 0)
			{
				fOk = false;
			}
			else
			{
				StrApp strDefault(kstidWizProjDefaultLanguage);
				StrApp str(rgch, cchLang);
				if (str == strDefault)
					fOk = false;
			}
			if (fOk)
			{
				int cch = ::GetDlgItemText(m_hwnd, kctidWizProjIdentifyEthCode, rgch, 100);
				if (cch < 3 || cch > 5)
					fOk = false;

				for (int i = 0; i < 5; ++i)
				{
					if (i == cch)
						break;
					if (i < 3 && (rgch[i] < 'A' || rgch[i] > 'Z'))
					{
						fOk = false;
						break;
					}
					if (i > 2 && (rgch[i] < '0' || rgch[i] > '9'))
					{
						fOk = false;
						break;
					}
				}
			}
			m_pwiz->EnableNextButton(fOk);
}


/*----------------------------------------------------------------------------------------------
	Either enables or disables the Next button when this page becomes active.
	@return True.
----------------------------------------------------------------------------------------------*/
bool AfNewProjIdentify::OnSetActive()
{
	SetNextEnbl();
	return SuperClass::OnSetActive();
}


/*----------------------------------------------------------------------------------------------
	Return information about predefined languages and encodings in relation to the passed
	parameters.
	@param pszLang Name of language to be compared with predefined languages.
	@param cchLang Length of pszName (excludes terminating zero).
	@param pszWs Name of writing system to be compared with predefined encodings.
	@param cchWs Length of pszWs (excludes terminating zero).
	@param bNameOrWs Control flag:
		true:	compare pszLang with predefined language names. If there is no match, return
				true. If there is a match, return true if pszWs matches the corresponding
				predefined writing system, else false.
		false:	compare pszWs with predefined writing system names. If there is no match, return
				true. If there is a match, return true if pszLang matches the corresponding
				predefined language name, else false.
				In this case, also return (in pszLang) the language name which does match pszWs.
----------------------------------------------------------------------------------------------*/
bool PredefinedNameOrEnc(achar * pszLang, int cchLang, achar * pszWs, int cchWs,
	bool bNameOrWs)
{
	static const int kcPredefined = 4;
	// NOTE: these names must match those in Newlangproj.xml.
	static achar * pszPredefLangs[kcPredefined] = { _T("English"), _T("French"), _T("Spanish"),
		_T("Portuguese") };
	static achar * pszPredefEncs[kcPredefined] = { _T("en"), _T("fr"), _T("es"), _T("pt") };

	int i;
	if (bNameOrWs)
	{
		for (i = 0; i < kcPredefined; ++i)
		{
			if (_tcscmp(pszLang, pszPredefLangs[i]) == 0)
			{
				if (_tcscmp(pszWs, pszPredefEncs[i]) == 0)
					return true;
				else
				{
					_tcscpy(pszWs, pszPredefEncs[i]);
					return false;
				}
			}
		}
		return true;
	}
	else
	{
		for (i = 0; i < kcPredefined; ++i)
		{
			if (_tcscmp(pszWs, pszPredefEncs[i]) == 0)
			{
				if (_tcscmp(pszLang, pszPredefLangs[i]) == 0)
					return true;
				else
					_tcscpy(pszLang, pszPredefLangs[i]);
				return false;
			}
		}
		return true;
	}
}

/*----------------------------------------------------------------------------------------------
	Retrieve the name of the language and its Ethnologue code.

	@return handle of the next page to advance to.
----------------------------------------------------------------------------------------------*/
HWND AfNewProjIdentify::OnWizardNext()
{
	AfNewLanguageProjectWizard * prnlp = dynamic_cast<AfNewLanguageProjectWizard *>(m_pwiz);
	Assert(prnlp);

	achar rgchName[128];
	achar rgchEnc[10];
	int cchWs = ::GetDlgItemText(m_hwnd, kctidWizProjIdentifyEthCode, rgchEnc, 128);
	int cchName = ::GetDlgItemText(m_hwnd, kctidWizProjIdentifyLanguage, rgchName, 128);

	const achar * pszHelpUrl = m_pszHelpUrl;
	if (!PredefinedNameOrEnc(rgchName, cchName, rgchEnc, cchWs, true))
	{
		// The entered name is a pre-defined name and the writing system does not match it.
		StrApp strMsg;
		StrApp strTemp(kstidWizProjPredefLang);
		StrApp strTitle(kstidWizProjPredefLangTlt);
		strMsg.Format(strTemp.Chars(), rgchName, rgchEnc, rgchName, rgchEnc);
		m_pszHelpUrl = _T("WhatIsALanguageCode.htm");
		::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(),
			MB_OK | MB_ICONINFORMATION | MB_HELP);
		::SetFocus(::GetDlgItem(m_hwnd, kctidWizProjIdentifyLanguage));
		m_pszHelpUrl = pszHelpUrl;
		return (HWND)-1;		// Stay on same page.
	}

	// Save the language name and the writing system.
	StrApp strName(rgchName, cchName);
	StrAppBufSmall strbsWs(rgchEnc, cchWs);
	achar rgchNameUsed[128];
	int cchNameUsed = ::GetDlgItemText(m_hwnd, kctidWizProjIdentifyLanguage, rgchNameUsed, 128);
	if (!PredefinedNameOrEnc(rgchNameUsed, cchNameUsed, rgchEnc, cchWs, false))
	{
		// The entered writing system is a pre-defined one and the name does not match.
		StrAppBufSmall strbsEncSuggested(rgchEnc, cchWs);
		strbsEncSuggested.Append(_T("1"), 1);
		StrApp strMsg;
		StrApp strTemp(kstidWizProjPredefEnc);
		StrApp strTitle(kstidWizProjPredefEncTlt);
		strMsg.Format(strTemp.Chars(), rgchEnc, rgchNameUsed, rgchName,
			strbsEncSuggested.Chars());
		m_pszHelpUrl = _T("DialogDuplicateEthnologueCode.htm");
		if (::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(),
			MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2 | MB_HELP) == IDNO)
		{
			::SetFocus(::GetDlgItem(m_hwnd, kctidWizProjIdentifyEthCode));
			m_pszHelpUrl = pszHelpUrl;
			return (HWND)-1;			// Stay on same page.
		}
		strbsWs = strbsEncSuggested;	// Yes, take the incremented code.
	}
	m_pszHelpUrl = pszHelpUrl;
	prnlp->SetLanguageName(strName.Chars(), strName.Length());
	prnlp->SetEthCode(strbsWs.Chars(), strbsWs.Length());

	return NULL;
}

//:>********************************************************************************************
//:>	AfNewProjVernacular Implementation
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Initialize the dialog in response to the WM_INITDIALOG message.
	All one-time initialization should be done here (that is, all controls have been created
	and have valid hwnd's, but they need initial values.)

	@param hwndCtrl Not used by this method.
	@param lp Not used by this method.

	@return True.
----------------------------------------------------------------------------------------------*/
bool AfNewProjVernacular::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	// Set the font for the page title.
	m_hfontLarge = AfGdi::CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET,
		OUT_CHARACTER_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH | FF_SWISS,
		_T("MS Sans Serif"));
	if (m_hfontLarge)
		::SendMessage(::GetDlgItem(m_hwnd, kridWizProjVernacularTitle), WM_SETFONT,
			(WPARAM)m_hfontLarge, false);
	StrApp str(kstidWizProjVernacularTitle);
	::SetWindowText(::GetDlgItem(m_hwnd, kridWizProjVernacularTitle), str.Chars());

	m_strChooseMsgFmt.Load(kstidWizProjChooseLangTextFmt);
	StrApp strUnkLang(kstidLangUnknown);
	str.Format(m_strChooseMsgFmt.Chars(), strUnkLang.Chars());
	::SetWindowText(::GetDlgItem(m_hwnd, kctidWizProjChooseLangText), str.Chars());

	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidWizProjChooseLang, kbtPopMenu, NULL, 0);

	// Fill in the font combo boxes.
	// TODO (version 1 or 2?): display font names in their actual fonts.  This requires
	// owner draw at a minimum as far as i can tell.

	AfNewLanguageProjectWizard * prnlp = dynamic_cast<AfNewLanguageProjectWizard *>(m_pwiz);
	Assert(prnlp);
	Vector<StrApp> & vstrFonts = prnlp->FontList();

	HWND hwnd;
	int i;
	int iDef = -1;
	hwnd = ::GetDlgItem(m_hwnd, kctidWizProjNormalFont);
	StrApp strDefault("Times New Roman");
	for (i = 0; i < vstrFonts.Size(); ++i)
	{
		::SendMessage(hwnd, CB_ADDSTRING, 0, (LPARAM)vstrFonts[i].Chars());
		if (vstrFonts[i] == strDefault)
			iDef = i;
	}
	if (iDef == -1)
		iDef = 0;
	::SendMessage(hwnd, CB_SETCURSEL, iDef, 0);

	hwnd = ::GetDlgItem(m_hwnd, kctidWizProjHeadingFont);
	strDefault.Assign("Arial");
	iDef = -1;
	for (i = 0; i < vstrFonts.Size(); ++i)
	{
		::SendMessage(hwnd, CB_ADDSTRING, 0, (LPARAM)vstrFonts[i].Chars());
		if (vstrFonts[i] == strDefault)
			iDef = i;
	}
	if (iDef == -1)
		iDef = 0;
	::SendMessage(hwnd, CB_SETCURSEL, iDef, 0);

	// TODO (Version 2?): Add explicit handling for KeyMan setup.
	::ShowWindow(::GetDlgItem(m_hwnd, kctidWizProjKeymanText), SW_HIDE);
	::ShowWindow(::GetDlgItem(m_hwnd, kctidWizProjKeymanSetup), SW_HIDE);

	m_pwiz->EnableNextButton(false);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Handle a WM_NOTIFY message, first letting the superclass method handle it if possible.

	@param ctidFrom Identifies the control sending the message.
	@param pnmh Pointer to the notification message data.
	@param lnRet Reference to a long integer return value used by some messages.

	@return True if the message is handled successfully; otherwise, false.
----------------------------------------------------------------------------------------------*/
bool AfNewProjVernacular::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (SuperClass::OnNotifyChild(ctidFrom, pnmh, lnRet))
		return true;

	switch (pnmh->code)
	{
	case BN_CLICKED:
		if (ctidFrom == kctidWizProjChooseLang)
		{
			// Show the popup menu that allows a user to choose the language.
			AfNewLanguageProjectWizard * prnlp =
				dynamic_cast<AfNewLanguageProjectWizard *>(m_pwiz);
			Assert(prnlp);
			Rect rc;
			::GetWindowRect(::GetDlgItem(m_hwnd, kctidWizProjChooseLang), &rc);

			// Because of difficulties with message handling when there is no frame window,
			// try using ::TrackPopupMenu in its mode which does not send messages but
			// simply returns the user selection (or 0 if none). However, the user selection
			// is returned as the id of the selection and we need the index.
			int idLang = ::TrackPopupMenu(prnlp->LanguageMenu(),
				TPM_LEFTALIGN | TPM_RIGHTBUTTON | TPM_RETURNCMD | TPM_NONOTIFY,
				rc.left, rc.bottom, 0, m_hwnd, NULL);
			if (idLang)
			{
				// The id is simply related to the index. See AfSysLangList::GetLanguageMenu().
				SysLangInfo & langid = prnlp->InstalledLanguage(idLang - kcidMenuItemDynMin);
				::SetWindowText(::GetDlgItem(m_hwnd, kctidWizProjChooseLang),
					langid.m_strName.Chars());
				prnlp->SetLocaleId(langid.m_lcid);
				m_pwiz->EnableNextButton(true);
			}
			else
			{
				achar rgch[MAX_PATH];
				int cch = ::GetWindowText(::GetDlgItem(m_hwnd, kctidWizProjChooseLang),
					rgch, MAX_PATH);
				if ((cch > 0) &&
					(!_tcscmp(rgch, _T("Choose..."))))
					m_pwiz->EnableNextButton(false);
				else
					m_pwiz->EnableNextButton(true);
			}
			return true;
		}
		else if (ctidFrom == kctidWizProjKeymanSetup)
		{
#if 8
			::MessageBoxA(m_hwnd, "NOT YET IMPLEMENTED", "DEBUG", MB_OK | MB_ICONWARNING);
#endif
			return true;
		}
		break;
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Fix the "choose language" text to reflect the chosen language name.

	@return True if the page was successfully set active; otherwise false.
----------------------------------------------------------------------------------------------*/
bool AfNewProjVernacular::OnSetActive()
{
	AfNewLanguageProjectWizard * prnlp = dynamic_cast<AfNewLanguageProjectWizard *>(m_pwiz);
	Assert(prnlp);

	StrApp str;
	str.Format(m_strChooseMsgFmt.Chars(), prnlp->LanguageName());
	::SetWindowText(::GetDlgItem(m_hwnd, kctidWizProjChooseLangText), str.Chars());

	if (prnlp->LocaleId() == 0)
		m_pwiz->EnableNextButton(false);
	else
		m_pwiz->EnableNextButton(true);

	const StrApp strNormal = prnlp->NormalFont();
	if (strNormal.Length())
	{
	}
	const StrApp strHeading = prnlp->HeadingFont();
	if (strHeading.Length())
	{
	}

	return SuperClass::OnSetActive();
}

/*----------------------------------------------------------------------------------------------
	Retrieve the names of the selected fonts.

	@return handle of the next page to advance to.
----------------------------------------------------------------------------------------------*/
HWND AfNewProjVernacular::OnWizardNext()
{
	AfNewLanguageProjectWizard * prnlp = dynamic_cast<AfNewLanguageProjectWizard *>(m_pwiz);
	Assert(prnlp);
	prnlp->SetNormalFont(::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjNormalFont),
		CB_GETCURSEL, 0, 0));
	prnlp->SetHeadingFont(::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjHeadingFont),
		CB_GETCURSEL, 0, 0));
	return NULL;
}

/*----------------------------------------------------------------------------------------------
	Handle a popup menu command for choosing the desired language.

	@param pcmd Pointer to the command information.

	@return True.
----------------------------------------------------------------------------------------------
bool AfNewProjVernacular::CmdLangPopup(Cmd * pcmd)
{
	AssertPtr(pcmd);
	Assert(pcmd->m_rgn[0] == AfMenuMgr::kmaDoCommand);

	// The user selected an expanded menu item, so perform the command now.
	//    m_rgn[1] holds the menu handle.
	//    m_rgn[2] holds the index of the selected item.

	AfNewLanguageProjectWizard * prnlp = dynamic_cast<AfNewLanguageProjectWizard *>(m_pwiz);
	Assert(prnlp);
	int ilang = pcmd->m_rgn[2];
	SysLangInfo & langid = prnlp->InstalledLanguage(ilang);
	::SetWindowText(::GetDlgItem(m_hwnd, kctidWizProjChooseLang), langid.m_strName.Chars());
	prnlp->SetLocaleId(langid.m_lcid);
	m_pwiz->EnableNextButton(true);

	return true;
}
*/

//:>********************************************************************************************
//:>	AfNewProjAnalysis Implementation
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Initialize the dialog in response to the WM_INITDIALOG message.
	All one-time initialization should be done here (that is, all controls have been created
	and have valid hwnd's, but they need initial values.)

	@param hwndCtrl Not used by this method.
	@param lp Not used by this method.

	@return True.
----------------------------------------------------------------------------------------------*/
bool AfNewProjAnalysis::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	// Set the font for the page title.
	m_hfontLarge = AfGdi::CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET,
		OUT_CHARACTER_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH | FF_SWISS,
		_T("MS Sans Serif"));
	if (m_hfontLarge)
		::SendMessage(::GetDlgItem(m_hwnd, kridWizProjAnalysisTitle), WM_SETFONT,
			(WPARAM)m_hfontLarge, false);
	StrApp str(kstidWizProjAnalysisTitle);
	::SetWindowText(::GetDlgItem(m_hwnd, kridWizProjAnalysisTitle), str.Chars());

	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidWizProjAnalChoose, kbtPopMenu, NULL, 0);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Initialize the pushbuttons and dropdown menu for choosing the analysis language.

	@return True if the page was successfully set active; otherwise false.
----------------------------------------------------------------------------------------------*/
bool AfNewProjAnalysis::OnSetActive()
{
	AfNewLanguageProjectWizard * prnlp = dynamic_cast<AfNewLanguageProjectWizard *>(m_pwiz);
	Assert(prnlp);

	::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalEnglish), BM_SETCHECK, BST_UNCHECKED, 0);
	::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalFrench), BM_SETCHECK, BST_UNCHECKED, 0);
	::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalSpanish), BM_SETCHECK, BST_UNCHECKED, 0);
	::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalPortuguese), BM_SETCHECK, BST_UNCHECKED,
		0);
	::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalOther), BM_SETCHECK, BST_UNCHECKED, 0);
	::EnableWindow(::GetDlgItem(m_hwnd, kctidWizProjAnalChoose), TRUE);

	switch (prnlp->AnalLang())
	{
	case LANG_ENGLISH:
		::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalEnglish),
			BM_SETCHECK, BST_CHECKED, 0);
		break;
	case LANG_FRENCH:
		::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalFrench),
			BM_SETCHECK, BST_CHECKED, 0);
		break;
	case LANG_SPANISH:
		::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalSpanish),
			BM_SETCHECK, BST_CHECKED, 0);
		break;
	case LANG_PORTUGUESE:
		::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalPortuguese),
			BM_SETCHECK, BST_CHECKED, 0);
		break;
	default:
		::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalOther),
			BM_SETCHECK, BST_CHECKED, 0);
		break;
	}

	return SuperClass::OnSetActive();
}

/*----------------------------------------------------------------------------------------------
	Handle a WM_NOTIFY message, first letting the superclass method handle it if possible.

	@param ctidFrom Identifies the control sending the message.
	@param pnmh Pointer to the notification message data.
	@param lnRet Reference to a long integer return value used by some messages.

	@return True if the message is handled successfully; otherwise, false.
----------------------------------------------------------------------------------------------*/
bool AfNewProjAnalysis::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (SuperClass::OnNotifyChild(ctidFrom, pnmh, lnRet))
		return true;

	::EnableWindow(::GetDlgItem(m_hwnd, kctidWizProjAnalChoose), TRUE);

	switch (pnmh->code)
	{
	case BN_CLICKED:
		switch (ctidFrom)
		{
		case kctidWizProjAnalEnglish:
		case kctidWizProjAnalFrench:
		case kctidWizProjAnalSpanish:
		case kctidWizProjAnalPortuguese:
			m_pwiz->EnableNextButton(true);
			break;

		case kctidWizProjAnalOther:
			{
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalEnglish),
					BM_SETCHECK, BST_UNCHECKED, 0);
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalFrench),
					BM_SETCHECK, BST_UNCHECKED, 0);
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalSpanish),
					BM_SETCHECK, BST_UNCHECKED, 0);
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalPortuguese),
					BM_SETCHECK, BST_UNCHECKED, 0);
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalOther),
					BM_SETCHECK, BST_CHECKED, 0);
				::EnableWindow(::GetDlgItem(m_hwnd, kctidWizProjAnalChoose), TRUE);

				achar rgch[MAX_PATH];
				int cch = ::GetWindowText(::GetDlgItem(m_hwnd, kctidWizProjAnalChoose),
					rgch, MAX_PATH);
				if ((cch > 0) && (!_tcscmp(rgch, _T("Choose..."))))
					m_pwiz->EnableNextButton(false);
			}
			break;

		case kctidWizProjAnalChoose:
			{
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalEnglish),
					BM_SETCHECK, BST_UNCHECKED, 0);
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalFrench),
					BM_SETCHECK, BST_UNCHECKED, 0);
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalSpanish),
					BM_SETCHECK, BST_UNCHECKED, 0);
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalPortuguese),
					BM_SETCHECK, BST_UNCHECKED, 0);
				::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalOther),
					BM_SETCHECK, BST_CHECKED, 0);

				// Show the popup menu that allows a user to choose the language.
				AfNewLanguageProjectWizard * prnlp =
					dynamic_cast<AfNewLanguageProjectWizard *>(m_pwiz);
				Assert(prnlp);
				Rect rc;
				::GetWindowRect(::GetDlgItem(m_hwnd, kctidWizProjAnalChoose), &rc);

				// Because of difficulties with message handling when there is no frame window,
				// try using ::TrackPopupMenu in its mode which does not send messages but
				// simply returns the user selection (or 0 if none). However, the user selection
				// is returned as the id of the selection and we need the index.
				int idLang = ::TrackPopupMenu(prnlp->LanguageMenu(),
					TPM_LEFTALIGN | TPM_RIGHTBUTTON | TPM_RETURNCMD | TPM_NONOTIFY,
					rc.left, rc.bottom, 0, m_hwnd, NULL);
				if (idLang)
				{
					// The id is simply related to the index.
					// See AfSysLangList::GetLanguageMenu().
					SysLangInfo & langid = prnlp->InstalledLanguage(
						idLang - kcidMenuItemDynMin);
					::SetWindowText(::GetDlgItem(m_hwnd, kctidWizProjAnalChoose),
						langid.m_strName.Chars());
					prnlp->SetLocaleId(langid.m_lcid);
					m_pwiz->EnableNextButton(true);
				}
				else
				{
					achar rgch[MAX_PATH];
					int cch = ::GetWindowText(::GetDlgItem(m_hwnd, kctidWizProjAnalChoose),
						rgch, MAX_PATH);
					if ((cch > 0) && (!_tcscmp(rgch, _T("Choose..."))))
						m_pwiz->EnableNextButton(false);
				}
				return true;
			}
			break;
		}
		break;
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Save the dialog values.

	Returns: True.
----------------------------------------------------------------------------------------------*/
bool AfNewProjAnalysis::OnKillActive()
{
	AfNewLanguageProjectWizard * prnlp = dynamic_cast<AfNewLanguageProjectWizard *>(m_pwiz);
	Assert(prnlp);

	if (::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalEnglish),
		BM_GETCHECK, 0, 0) == BST_CHECKED)
	{
		prnlp->SetAnalLang(LANG_ENGLISH);
	}
	else if (::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalFrench),
		BM_GETCHECK, 0, 0) == BST_CHECKED)
	{
		prnlp->SetAnalLang(LANG_FRENCH);
	}
	else if (::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalSpanish),
		BM_GETCHECK, 0, 0) == BST_CHECKED)
	{
		prnlp->SetAnalLang(LANG_SPANISH);
	}
	else if (::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalPortuguese),
		BM_GETCHECK, 0, 0) == BST_CHECKED)
	{
		prnlp->SetAnalLang(LANG_PORTUGUESE);
	}
	else if (::SendMessage(::GetDlgItem(m_hwnd, kctidWizProjAnalOther),
		BM_GETCHECK, 0, 0) == BST_CHECKED)
	{
		achar rgch[MAX_PATH];
		int cch = ::GetWindowText(::GetDlgItem(m_hwnd, kctidWizProjAnalChoose), rgch, MAX_PATH);
		if (cch)
			prnlp->SetAnalLang(rgch, cch);
	}
	else
	{
		Assert(false);
	}

	return true;
}


#include "Vector_i.cpp"
#include "HashMap_i.cpp"

// Local Variables:
// mode:C++
// compile-command:"cmd.exe /e:4096 /c c:\\FW\\Bin\\MkCustomNb.bat"
// End: (These 4 lines are useful to Steve McConnel.)
