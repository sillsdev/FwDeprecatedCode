/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: LangProjPropDlg.cpp
Responsibility: Steve McConnel
Last reviewed: Not yet.

Description:
	Implementation of the File / Properties / Language Project dialog classes.
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop

#include "HashMap_i.cpp" // Need for release build

#undef THIS_FILE
DEFINE_THIS_FILE
//:End Ignore

#import "FwCoreDlgs.tlb" raw_interfaces_only rename_namespace("FwCoreDlgs")

BEGIN_CMD_MAP(LangProjPropWrtSys)
	ON_CID_CHILD(kcidLngPrjNewVernWS, &LangProjPropWrtSys::CmdNewVernWS, NULL)
	ON_CID_CHILD(kcidLngPrjNewAnalWS, &LangProjPropWrtSys::CmdNewAnalWS, NULL)
END_CMD_MAP_NIL()

//:>********************************************************************************************
//:>	LangProjPropDlg Implementation
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
LangProjPropDlg::LangProjPropDlg()
{
	m_rid = kridLangProjPropDlg;
	SetHelpUrl(0);
}

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
LangProjPropDlg::~LangProjPropDlg()
{
}

/*----------------------------------------------------------------------------------------------
	Called by the framework to initialize the dialog. All one-time initialization should be
	done here (that is, all controls have been created and have valid hwnd's, but they
	need initial values.)

	See ${AfDialog#FWndProc}
	@param hwndCtrl (not used)
	@param lp (not used)

	@return true if Successful
----------------------------------------------------------------------------------------------*/
bool LangProjPropDlg::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	GeneralPropDlgTabPtr qgenp;
	qgenp.Attach(NewObj GeneralPropDlgTab(this, m_ctidName));
	qgenp->EnableLocation(true);
	qgenp->EnableSize(false);
	qgenp->EnableModified(true);
	qgenp->EnableDescription(true);
	AfDialogViewPtr qdlgv;
	qdlgv = qgenp;
	m_vqdlgv.Push(qdlgv);
	qdlgv.Attach(NewObj LangProjPropWrtSys(this));
	m_vqdlgv.Push(qdlgv);
	qdlgv.Attach(NewObj LangProjPropExtLnkTab(this));
	m_vqdlgv.Push(qdlgv);

	m_hwndTab = ::GetDlgItem(m_hwnd, kcidLangProjPropDlgTab);

	// WARNING: If this ever gets changed to anything but a fixed length buffer, make sure
	// ti.pszText is set after loading each string, since the memory pointed to by strb
	// could be different each time.
	StrAppBuf strb;
	TCITEM ti;
	ti.mask = TCIF_TEXT;
	ti.pszText = const_cast<achar *>(strb.Chars());

	// Add a tab to the tab control for each dialog view.
	strb.Load(kstidGeneralPropTab);
	TabCtrl_InsertItem(m_hwndTab, kidlgGeneral, &ti);
	strb.Load(kstidLngPrjWrtSys);
	TabCtrl_InsertItem(m_hwndTab, kidlgWrtSys, &ti);
	strb.Load(kstidLngPrjExtLnk);
	TabCtrl_InsertItem(m_hwndTab, kidlgExtLnk, &ti);

	// This section must be after at least one tab gets added to the tab control.
	RECT rcTab;
	::GetWindowRect(m_hwndTab, &rcTab);
	TabCtrl_AdjustRect(m_hwndTab, false, &rcTab);
	POINT pt = { rcTab.left, rcTab.top };
	::ScreenToClient(m_hwnd, &pt);
	m_dxsClient = pt.x;
	m_dysClient = pt.y;

	// Subclass the Help button.
	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidHelp, kbtHelp, NULL, 0);

	ShowChildDlg(m_itabInitial);

	AfApp::Papp()->EnableMainWindows(false);

	::SetFocus(m_hwndTab);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	This method is called by the framework when the user chooses the OK or the Apply Now button.
	When the framework calls this method, changes made in the dialog are accepted.
	The default OnApply closes the dialog.

	@param fClose not used here

	@return True if successful.
----------------------------------------------------------------------------------------------*/
bool LangProjPropDlg::OnApply(bool fClose)
{
	int iq;
	LangProjPropWrtSys * plppw = NULL;
	for (iq = 0; iq < m_vqdlgv.Size(); ++iq)
	{
		// We don't want to apply each page here because it is done in SuperClass::OnApply.
		if (!plppw)
			plppw = dynamic_cast<LangProjPropWrtSys *>(m_vqdlgv[iq].Ptr());
	}
	bool fT = SuperClass::OnApply(fClose);
	if (plppw)
	{
		// THIS CODE HAS TO BE AFTER THE DIALOG IS ACTUALLY CLOSED. This is because all windows
		// must be closed down while the encodings are changed.
		plppw->ChangeEncs();
	}
	return fT;
}


/*----------------------------------------------------------------------------------------------
	@return true if the language encodings changed requiring redraws.
----------------------------------------------------------------------------------------------*/
bool LangProjPropDlg::GetWsChange()
{
	LangProjPropWrtSys * plppw = dynamic_cast<LangProjPropWrtSys *>
		(m_vqdlgv[kidlgWrtSys].Ptr());
	Assert(plppw);
	return plppw->GetWsChange();
}


/*----------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------*/
bool LangProjPropDlg::OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (pnmh->code == TCN_SELCHANGE)
	{
		int itab = TabCtrl_GetCurSel(m_hwndTab);
		SetHelpUrl(itab);
	}

	return SuperClass::OnNotifyChild(ctid, pnmh, lnRet);
}

/*----------------------------------------------------------------------------------------------
	Set the help link based on which tab is selected.
----------------------------------------------------------------------------------------------*/
void LangProjPropDlg::SetHelpUrl(int itab)
{
	switch (itab)
	{
	case 0:
		m_pszHelpUrl = _T("DialogProjectPropertiesGeneral.htm");
		break;
	case 1:
		m_pszHelpUrl = _T("DialogProjectPropertiesWriting.htm");
		break;
	case 2:
		m_pszHelpUrl = _T("DialogProjectPropertiesExterna.htm");
		break;
	default:
		Assert(false);
		break;
	}
}


//:>********************************************************************************************
//:>	LangProjPropWrtSys Implementation
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
LangProjPropWrtSys::LangProjPropWrtSys(PropertiesDlg * ppropd)
{
	m_rid = kridLngPrjWrtSysDlg;
	m_ppropd = ppropd;
	m_fInitialized = false;
	m_pszHelpUrl = _T("DialogProjectPropertiesWriting.htm");
	m_hDown = NULL;
	m_hUp = NULL;
}

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
LangProjPropWrtSys::~LangProjPropWrtSys()
{
	if (m_hDown)
	{
		AfGdi::DeleteObjectBitmap(m_hDown);
		m_hDown = NULL;
	}
	if (m_hUp)
	{
		AfGdi::DeleteObjectBitmap(m_hUp);
		m_hUp = NULL;
	}
}


/*----------------------------------------------------------------------------------------------
	Called by the framework to initialize the dialog. All one-time initialization should be
	done here (that is, all controls have been created and have valid hwnd's, but they
	need initial values.)

	See ${AfDialog#FWndProc}
	@param hwndCtrl (not used)
	@param lp (not used)

	@return true if Successful
----------------------------------------------------------------------------------------------*/
bool LangProjPropWrtSys::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	AfLpInfo * plpi = m_ppropd->GetLangProjInfo();
	AssertPtr(plpi);
	AfDbInfo * pdbi = plpi->GetDbInfo();
	AssertPtr(pdbi);
	pdbi->GetLgWritingSystemFactory(&m_qwsf);
	AssertPtr(m_qwsf);
	ILgWritingSystemPtr qws;
	HMODULE hModule = ::GetModuleHandle(NULL);
	m_wsUser = pdbi->UserWs();
	SmartBstr sbstr;
	Rect rc;
	int iws;
	int iwsd;
	int iv;
	StrApp str;
	WrtSysData wsd;
	SmartBstr sbstrRendInit;

	// Build the list of all available language encodings / old writing systems.
	int cws;
	CheckHr(m_qwsf->get_NumberOfWs(&cws));
	Vector<int> vws;
	HashMap<int,int> hmenciwsd;
	vws.Resize(cws);
	CheckHr(m_qwsf->GetWritingSystems(vws.Begin(), vws.Size()));
	for (iws = 0; iws < cws; ++iws)
	{
		if (vws[iws] == 0)
			continue;

		CheckHr(m_qwsf->get_EngineOrNull(vws[iws], &qws));
		Assert(qws);
		CheckHr(qws->get_UiName(m_wsUser, &sbstr));
		wsd.m_ws = vws[iws];
		wsd.m_stuName.Assign(sbstr.Chars());
		CheckHr(qws->get_Locale(&wsd.m_lcid));
		StrUni stuBogusMono;
		AfApp::DefaultFontsForWs(qws, wsd.m_stuNormalFont, wsd.m_stuHeadingFont, stuBogusMono);
		iwsd = m_vwsd.Size();
		hmenciwsd.Insert(wsd.m_ws, iwsd);
		m_vwsd.Push(wsd);
		m_vwsdOrig.Push(wsd);
	}

	// Build and display the list of vernacular language encodings / old writing systems.
	HWND hwndVern = ::GetDlgItem(m_hwnd, kcidLngPrjVernWrtSysList);
	m_hwndVernWrtSys = hwndVern;	// Save for windows bug fix in FWndProc.
	::GetClientRect(hwndVern, &rc);
	LVCOLUMN lvcol;
	::ZeroMemory(&lvcol, isizeof(lvcol));
	lvcol.mask = LVCF_WIDTH;
	lvcol.cx = rc.Width();
	ListView_InsertColumn(hwndVern, 0, &lvcol);
	ListView_SetExtendedListViewStyle(hwndVern, LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT);

	LVITEM lvi;
	::ZeroMemory(&lvi, isizeof(lvi));
	lvi.mask = LVIF_TEXT;

	// vwsVern is ordered. vwsVernAll is unordered. We need to put vwsVern (checked)
	// items first followed by any other encodings in vwsVernAll.
	Vector<int> & vwsVernAll = plpi->AllVernWss();
	Vector<int> & vwsVern = plpi->VernWss();
	Set<int> setwsVern;
	iv = 0;
	for (iws = 0; iws < vwsVern.Size(); ++iws)
	{
		setwsVern.Insert(vwsVern[iws]);
		if (!hmenciwsd.Retrieve(vwsVern[iws], &iwsd))
		{
			// REVIEW SteveMc: do we need an error or warning here?
			continue;
		}
		lvi.iItem = iv++;
		str.Assign(m_vwsd[iwsd].m_stuName.Chars());
		lvi.pszText = const_cast<achar *>(str.Chars());
		lvi.cchTextMax = str.Length();
		ListView_InsertItem(hwndVern, &lvi);
		ListView_SetCheckState(hwndVern, lvi.iItem, TRUE);
		m_viwsdVern.Push(iwsd);
	}
	for (iws = 0; iws < vwsVernAll.Size(); ++iws)
	{
		if (setwsVern.IsMember(vwsVernAll[iws]))
			continue; // Already in list.
		if (!hmenciwsd.Retrieve(vwsVernAll[iws], &iwsd))
		{
			// REVIEW SteveMc: do we need an error or warning here?
			continue;
		}
		lvi.iItem = iv++;
		str.Assign(m_vwsd[iwsd].m_stuName.Chars());
		lvi.pszText = const_cast<achar *>(str.Chars());
		lvi.cchTextMax = str.Length();
		ListView_InsertItem(hwndVern, &lvi);
		ListView_SetCheckState(hwndVern, lvi.iItem, FALSE);
		m_viwsdVern.Push(iwsd);
	}
	ListView_SetItemState(hwndVern, 0, LVIS_SELECTED, LVIS_SELECTED);

	if (m_hDown)
		AfGdi::DeleteObjectBitmap(m_hDown);
	m_hDown = AfGdi::LoadImageBitmap(hModule, (LPCTSTR)kridLngPrjDownArrowPic, IMAGE_BITMAP, 0, 0,
		LR_LOADMAP3DCOLORS);
	if (m_hUp)
		AfGdi::DeleteObjectBitmap(m_hUp);
	m_hUp = AfGdi::LoadImageBitmap(hModule, (LPCTSTR)kridLngPrjUpArrowPic, IMAGE_BITMAP, 0, 0,
		LR_LOADMAP3DCOLORS);
	::SendMessage(::GetDlgItem(m_hwnd, kctidLngPrjMoveDownVernWS), BM_SETIMAGE,
		(WPARAM)IMAGE_BITMAP, (LPARAM)m_hDown);
	::SendMessage(::GetDlgItem(m_hwnd, kctidLngPrjMoveUpVernWS), BM_SETIMAGE,
		(WPARAM)IMAGE_BITMAP, (LPARAM)m_hUp);
	::EnableWindow(::GetDlgItem(m_hwnd, kctidLngPrjMoveDownVernWS), m_viwsdVern.Size() > 1);
	::EnableWindow(::GetDlgItem(m_hwnd, kctidLngPrjMoveUpVernWS), m_viwsdVern.Size() > 1);
	::EnableWindow(::GetDlgItem(m_hwnd, kctidLngPrjDeleteVernWS), m_viwsdVern.Size() > 1);

	// Build and display the list of analysis language encodings / old writing systems.
	HWND hwndAnal = ::GetDlgItem(m_hwnd, kcidLngPrjAnalWrtSysList);
	m_hwndAnalWrtSys = hwndAnal;	// Save for windows bug fix in FWndProc.
	ListView_SetExtendedListViewStyle(hwndAnal, LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT);
	::GetClientRect(hwndAnal, &rc);
	::ZeroMemory(&lvcol, isizeof(lvcol));
	lvcol.mask = LVCF_WIDTH;
	lvcol.cx = rc.Width();
	ListView_InsertColumn(hwndAnal, 0, &lvcol);

	// vwsAnal is ordered. vwsAnalAll is unordered. We need to put vwsAnal (checked)
	// items first followed by any other encodings in vwsAnalAll.
	Vector<int> & vwsAnalAll = plpi->AllAnalWss();
	Vector<int> & vwsAnal = plpi->AnalWss();
	Set<int> setwsAnal;
	iv = 0;
	for (iws = 0; iws < vwsAnal.Size(); ++iws)
	{
		setwsAnal.Insert(vwsAnal[iws]);
		if (!hmenciwsd.Retrieve(vwsAnal[iws], &iwsd))
		{
			// REVIEW SteveMc: do we need an error or warning here?
			continue;
		}
		lvi.iItem = iv++;
		str.Assign(m_vwsd[iwsd].m_stuName.Chars());
		lvi.pszText = const_cast<achar *>(str.Chars());
		lvi.cchTextMax = str.Length();
		ListView_InsertItem(hwndAnal, &lvi);
		ListView_SetCheckState(hwndAnal, lvi.iItem, TRUE);
		m_viwsdAnal.Push(iwsd);
	}
	for (iws = 0; iws < vwsAnalAll.Size(); ++iws)
	{
		if (setwsAnal.IsMember(vwsAnalAll[iws]))
			continue; // Already in list.
		if (!hmenciwsd.Retrieve(vwsAnalAll[iws], &iwsd))
		{
			// REVIEW SteveMc: do we need an error or warning here?
			continue;
		}
		lvi.iItem = iv++;
		str.Assign(m_vwsd[iwsd].m_stuName.Chars());
		lvi.pszText = const_cast<achar *>(str.Chars());
		lvi.cchTextMax = str.Length();
		ListView_InsertItem(hwndAnal, &lvi);
		ListView_SetCheckState(hwndAnal, lvi.iItem, FALSE);
		m_viwsdAnal.Push(iwsd);
	}
	ListView_SetItemState(hwndAnal, 0, LVIS_SELECTED, LVIS_SELECTED);

	::SendMessage(::GetDlgItem(m_hwnd, kctidLngPrjMoveDownAnalWS), BM_SETIMAGE,
		(WPARAM)IMAGE_BITMAP, (LPARAM)m_hDown);
	::SendMessage(::GetDlgItem(m_hwnd, kctidLngPrjMoveUpAnalWS), BM_SETIMAGE,
		(WPARAM)IMAGE_BITMAP, (LPARAM)m_hUp);
	::EnableWindow(::GetDlgItem(m_hwnd, kctidLngPrjMoveDownAnalWS), m_viwsdAnal.Size() > 1);
	::EnableWindow(::GetDlgItem(m_hwnd, kctidLngPrjMoveUpAnalWS), m_viwsdAnal.Size() > 1);
	::EnableWindow(::GetDlgItem(m_hwnd, kctidLngPrjDeleteAnalWS), m_viwsdAnal.Size() > 1);

	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidLngPrjAddVernWS, kbtPopMenu, NULL, 0);

	AfButtonPtr qbtn2;
	qbtn2.Create();
	qbtn2->SubclassButton(m_hwnd, kctidLngPrjAddAnalWS, kbtPopMenu, NULL, 0);

	m_fInitialized = true;

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Handle a WM_NOTIFY message, first letting the superclass method handle it if possible.

	@param ctidFrom Identifies the control sending the message.
	@param pnmh Pointer to the notification message data.
	@param lnRet Reference to a long integer return value used by some messages.

	@return True if the message is handled successfully; otherwise, false.
----------------------------------------------------------------------------------------------*/
bool LangProjPropWrtSys::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (SuperClass::OnNotifyChild(ctidFrom, pnmh, lnRet))
		return true;

	switch (pnmh->code)
	{
	case BN_CLICKED:
		switch (ctidFrom)
		{
		case kctidLngPrjAddVernWS:
			AddWrtSys(kctidLngPrjAddVernWS, kcidLngPrjNewVernWS, kcidLngPrjVernWrtSysList,
				m_viwsdVern, kctidLngPrjMoveDownVernWS, kctidLngPrjMoveUpVernWS,
				kctidLngPrjDeleteVernWS);
			return true;

		case kctidLngPrjModifyVernWS:
			ModifyWrtSys(kcidLngPrjVernWrtSysList, m_viwsdVern, kcidLngPrjAnalWrtSysList,
				m_viwsdAnal);
			return true;

		case kctidLngPrjDeleteVernWS:
			RemoveWrtSys(kcidLngPrjVernWrtSysList, m_viwsdVern, kctidLngPrjMoveDownVernWS,
				kctidLngPrjMoveUpVernWS, kctidLngPrjDeleteVernWS);
			return true;

		case kctidLngPrjMoveUpVernWS:
			MoveWrtSysUp(kcidLngPrjVernWrtSysList, m_viwsdVern);
			return true;

		case kctidLngPrjMoveDownVernWS:
			MoveWrtSysDown(kcidLngPrjVernWrtSysList, m_viwsdVern);
			return true;

		case kctidLngPrjAddAnalWS:
			AddWrtSys(kctidLngPrjAddAnalWS, kcidLngPrjNewAnalWS, kcidLngPrjAnalWrtSysList,
				m_viwsdAnal, kctidLngPrjMoveDownAnalWS, kctidLngPrjMoveUpAnalWS,
				kctidLngPrjDeleteAnalWS);
			return true;

		case kctidLngPrjModifyAnalWS:
			ModifyWrtSys(kcidLngPrjAnalWrtSysList, m_viwsdAnal, kcidLngPrjVernWrtSysList,
				m_viwsdVern);
			return true;

		case kctidLngPrjDeleteAnalWS:
			RemoveWrtSys(kcidLngPrjAnalWrtSysList, m_viwsdAnal, kctidLngPrjMoveDownAnalWS,
				kctidLngPrjMoveUpAnalWS, kctidLngPrjDeleteAnalWS);
			return true;

		case kctidLngPrjMoveUpAnalWS:
			MoveWrtSysUp(kcidLngPrjAnalWrtSysList, m_viwsdAnal);
			return true;

		case kctidLngPrjMoveDownAnalWS:
			MoveWrtSysDown(kcidLngPrjAnalWrtSysList, m_viwsdAnal);
			return true;
		}
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	This method is called when the user selects OK or Apply from the parent dialog, or the
	parent dialog wants to persist the changes in this dialog.

	@return true if Successful
----------------------------------------------------------------------------------------------*/
bool LangProjPropWrtSys::Apply()
{
	if (!m_fInitialized)
		return true;
	AssertPtr(m_qwsf);

	StrUni stu;
	int ihvo;
	AfLpInfo * plpi = m_ppropd->GetLangProjInfo();
	ILgWritingSystemPtr qws;
	SmartBstr sbstrRendInit;
	int iwsd;
	int ws;
	StrUni stuWs;
	HVO hvo;
	bool fChanged = false;
	for (iwsd = 0; iwsd < m_vwsd.Size(); ++iwsd)
	{
		// Check whether we've changed the language/old writing system setup.
		if (iwsd < m_vwsdOrig.Size() && m_vwsd[iwsd] == m_vwsdOrig[iwsd])
			continue;
		if (!m_vwsd[iwsd].m_ws && !m_vwsd[iwsd].m_stuName.Length() && !m_vwsd[iwsd].m_lcid &&
			!m_vwsd[iwsd].m_stuNormalFont.Length() && !m_vwsd[iwsd].m_stuHeadingFont.Length())
		{
			// This writing system/old writing system has been deleted!
			continue;
		}
		fChanged = true;
		// If the writing system value has changed, we have to deal with it in a later pass.
		WrtSysData & wsd = (iwsd < m_vwsdOrig.Size()) ? m_vwsdOrig[iwsd] : m_vwsd[iwsd];
		
		// Get the engine, or create one if it is a new one.
		CheckHr(m_qwsf->get_EngineOrNull(wsd.m_ws, &qws));
		if (!qws)
		{
			Assert(!wsd.m_ws);
			CheckHr(m_qwsf->get_Engine(wsd.m_stuIcuLocale.Bstr(), &qws));
			Assert(qws);
			CheckHr(qws->get_WritingSystem(&wsd.m_ws));
		}
		if (iwsd >= m_vwsdOrig.Size() || m_vwsd[iwsd].m_stuName != m_vwsdOrig[iwsd].m_stuName)
		{
			CheckHr(qws->put_Name(m_wsUser, m_vwsd[iwsd].m_stuName.Bstr()));
		}
		if (iwsd >= m_vwsdOrig.Size() || m_vwsd[iwsd].m_lcid != m_vwsdOrig[iwsd].m_lcid)
		{
			CheckHr(qws->put_Locale(m_vwsd[iwsd].m_lcid));
		}
		if (iwsd >= m_vwsdOrig.Size() ||
			m_vwsd[iwsd].m_stuNormalFont != m_vwsdOrig[iwsd].m_stuNormalFont)
		{
			CheckHr(qws->put_DefaultSerif(m_vwsd[iwsd].m_stuNormalFont.Bstr()));
		}
		if (iwsd >= m_vwsdOrig.Size() ||
			m_vwsd[iwsd].m_stuHeadingFont != m_vwsdOrig[iwsd].m_stuHeadingFont)
		{
			CheckHr(qws->put_DefaultSansSerif(m_vwsd[iwsd].m_stuHeadingFont.Bstr()));
		}
	}

	// If we've changed something, we need to save it to the database and then
	// make sure the hvos are all present for the next step.
	if (fChanged)
	{
		CustViewDaPtr qcvd;
		plpi->GetDataAccess(&qcvd);
		// Must save prior to saving encodings because it does a BeginTrans.
		CheckHr(qcvd->Save());
		CheckHr(m_qwsf->SaveWritingSystems());
		for (iwsd = 0; iwsd < m_vwsd.Size(); ++iwsd)
		{
			// If the writing system value has changed, we have to deal with it in a later pass.
			if (iwsd < m_vwsdOrig.Size())
				ws = m_vwsdOrig[iwsd].m_ws;
			else
				ws = m_vwsd[iwsd].m_ws;
			// Get the engine, or create one if it is a new one.
			CheckHr(m_qwsf->get_EngineOrNull(ws, &qws));
			Assert(qws);
			if (!qws)
				ThrowHr(WarnHr(E_FAIL));
		}
	}

	HWND hwnd = ::GetDlgItem(m_hwnd, kcidLngPrjVernWrtSysList);
	int iselLim = ListView_GetItemCount(hwnd);
	int isel;
	Vector<int> vwsNewVern;
	Vector<int> vwsNewVernAll;
	Vector<HVO> vhvoNewVern;
	Vector<HVO> vhvoNewVernAll;
	for (isel = 0; isel < iselLim; ++isel)
	{
		iwsd = m_viwsdVern[isel];
		if (iwsd < m_vwsdOrig.Size())
		{
			ws = m_vwsdOrig[iwsd].m_ws;
			hvo = m_vwsdOrig[iwsd].m_ws;
		}
		else
		{
			ws = m_vwsd[iwsd].m_ws;
			hvo = m_vwsd[iwsd].m_ws;
		}
		if (ListView_GetCheckState(hwnd, isel))
		{
			vwsNewVern.Push(ws);
			vhvoNewVern.Push(hvo);
		}
		vwsNewVernAll.Push(ws);
		vhvoNewVernAll.Push(hvo);
	}

	hwnd = ::GetDlgItem(m_hwnd, kcidLngPrjAnalWrtSysList);
	iselLim = ListView_GetItemCount(hwnd);
	Vector<int> vwsNewAnal;
	Vector<int> vwsNewAnalAll;
	Vector<HVO> vhvoNewAnal;
	Vector<HVO> vhvoNewAnalAll;
	for (isel = 0; isel < iselLim; ++isel)
	{
		iwsd = m_viwsdAnal[isel];
		if (iwsd < m_vwsdOrig.Size())
		{
			ws = m_vwsdOrig[iwsd].m_ws;
			hvo = m_vwsdOrig[iwsd].m_ws;
		}
		else
		{
			ws = m_vwsd[iwsd].m_ws;
			hvo = m_vwsd[iwsd].m_ws;
		}
		if (ListView_GetCheckState(hwnd, isel))
		{
			vwsNewAnal.Push(ws);
			vhvoNewAnal.Push(hvo);
		}
		vwsNewAnalAll.Push(ws);
		vhvoNewAnalAll.Push(hvo);
	}

	StrApp strMsg;
	if (!vwsNewVernAll.Size())
		strMsg.Load(kstidLngPrjNeedVernWs);
	else if (!vwsNewVern.Size())
		strMsg.Load(kstidLngPrjNeedActiveVernWs);
	else if (!vwsNewAnalAll.Size())
		strMsg.Load(kstidLngPrjNeedAnalWs);
	else if (!vwsNewAnal.Size())
		strMsg.Load(kstidLngPrjNeedActiveAnalWs);
	if (strMsg.Length())
	{
		StrApp strTitle(kstidLangProjPropMsgCaption);
		::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(), MB_OK | MB_ICONWARNING);
		return false;
	}

	IOleDbEncapPtr qode;
	IOleDbCommandPtr qodc;
	plpi->GetDbInfo()->GetDbAccess(&qode);
	AssertPtr(qode);
	HVO hvoLp = plpi->GetLpId();

	// Process any changes to LanguageProject_CurrentVernacularWritingSystems.
	bool fVernChanged = false;
	Vector<int> & vwsVern = plpi->VernWss();
	if (vwsVern.Size() != vwsNewVern.Size())
	{
		fVernChanged = true;
	}
	else
	{
		for (int i = 0; i < vwsVern.Size(); ++i)
		{
			if (vwsVern[i] != vwsNewVern[i])
			{
				fVernChanged = true;
				break;
			}
		}
	}
	if (fVernChanged)
	{
		vwsVern.Clear();
		vwsVern = vwsNewVern;
		// Save changes to database. Simplest way is to clear old values and add new.
		stu.Format(L"DELETE FROM LanguageProject_CurrentVernacularWritingSystems WHERE Src = %d",
			hvoLp);
		CheckHr(qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtNoResults));
		for (ihvo = 0; ihvo < vhvoNewVern.Size(); ++ihvo)
		{
			stu.Format(L"INSERT INTO LanguageProject_CurrentVernacularWritingSystems (Src, Dst, Ord)"
				L" VALUES (%d,%d,%d)",
				hvoLp, vhvoNewVern[ihvo], ihvo);
			CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtNoResults));
		}
	}

	// Process any changes to LanguageProject_VernacularWritingSystems.
	bool fAllVernChanged = false;
	Vector<int> & vwsVernAll = plpi->AllVernWss();
	if (vwsVernAll.Size() != vwsNewVernAll.Size())
	{
		fAllVernChanged = true;
	}
	else
	{
		for (int i = 0; i < vwsVernAll.Size(); ++i)
		{
			if (vwsVernAll[i] != vwsNewVernAll[i])
			{
				fAllVernChanged = true;
				break;
			}
		}
	}
	if (fAllVernChanged)
	{
		vwsVernAll.Clear();
		vwsVernAll = vwsNewVernAll;
		// Save changes to database. Simplest way is to clear old values and add new.
		stu.Format(L"DELETE FROM LanguageProject_VernacularWritingSystems WHERE Src = %d",
			hvoLp);
		CheckHr(qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtNoResults));
		for (ihvo = 0; ihvo < vhvoNewVernAll.Size(); ++ihvo)
		{
			stu.Format(L"INSERT INTO LanguageProject_VernacularWritingSystems (Src,Dst)"
				L" VALUES (%d,%d)",
				hvoLp, vhvoNewVernAll[ihvo]);
			CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtNoResults));
		}
	}

	// Process any changes to LanguageProject_CurrentAnalysisWritingSystems.
	bool fAnalChanged = false;
	Vector<int> & vwsAnal = plpi->AnalWss();
	if (vwsAnal.Size() != vwsNewAnal.Size())
	{
		fAnalChanged = true;
	}
	else
	{
		for (int i = 0; i <vwsAnal.Size(); ++i)
		{
			if (vwsAnal[i] != vwsNewAnal[i])
			{
				fAnalChanged = true;
				break;
			}
		}
	}
	if (fAnalChanged)
	{
		vwsAnal.Clear();
		vwsAnal = vwsNewAnal;
		// Save changes to database. Simplest way is to clear old values and add new.
		stu.Format(L"DELETE FROM LanguageProject_CurrentAnalysisWritingSystems WHERE Src = %d",
			hvoLp);
		CheckHr(qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtNoResults));
		for (ihvo = 0; ihvo < vhvoNewAnal.Size(); ++ihvo)
		{
			stu.Format(L"INSERT INTO LanguageProject_CurrentAnalysisWritingSystems (Src, Dst, Ord)"
				L" VALUES (%d,%d,%d)",
				hvoLp, vhvoNewAnal[ihvo], ihvo);
			CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtNoResults));
		}
	}

	// Process any changes to LanguageProject_AnalysisWritingSystems.
	bool fAllAnalChanged = false;
	Vector<int> & vwsAnalAll = plpi->AllAnalWss();
	if (vwsAnalAll.Size() != vwsNewAnalAll.Size())
	{
		fAllAnalChanged = true;
	}
	else
	{
		for (int i = 0; i <vwsAnalAll.Size(); ++i)
		{
			if (vwsAnalAll[i] != vwsNewAnalAll[i])
			{
				fAllAnalChanged = true;
				break;
			}
		}
	}
	if (fAllAnalChanged)
	{
		vwsAnalAll.Clear();
		vwsAnalAll = vwsNewAnalAll;
		// Save changes to database. Simplest way is to clear old values and add new.
		stu.Format(L"DELETE FROM LanguageProject_AnalysisWritingSystems WHERE Src = %d",
			hvoLp);
		CheckHr(qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtNoResults));
		for (ihvo = 0; ihvo < vhvoNewAnalAll.Size(); ++ihvo)
		{
			stu.Format(L"INSERT INTO LanguageProject_AnalysisWritingSystems (Src,Dst)"
				L" VALUES (%d,%d)",
				hvoLp, vhvoNewAnalAll[ihvo]);
			CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtNoResults));
		}
	}

	// If we've changed the order of encodings, we need to force possibility lists to reload.
	if (fAnalChanged || fVernChanged)
		m_fEncChange = true; // Flag that we need to redraw most things.

	RecMainWnd * prmw = dynamic_cast<RecMainWnd *>(MainWindow());
	if (prmw)
	{
		if (fAnalChanged || fVernChanged || fAllAnalChanged || fAllVernChanged || fChanged)
		{
			// Force the Sort Method Menu to be updated if anything at all changes.
			prmw->ClearSortMenuNodes();
		}
		if (fAllAnalChanged || fAllVernChanged || fChanged)
		{	// fChanged added in case only the name was changed rather than writing system
			// itself.
			// Update the writing system combobox list on the formatting toolbar.
			prmw->UpdateToolBarWrtSysControl();
		}
	}

	return true;
}


/*----------------------------------------------------------------------------------------------
	Check whether any of the encodings have changed, do a sanity check on any changes, and
	then (if sane) make the changes.
	This must be done after the master properties dialog window has been closed.
----------------------------------------------------------------------------------------------*/
void LangProjPropWrtSys::ChangeEncs()
{
	int iwsd;
	Vector<int> viwsdChg;
	for (iwsd = 0; iwsd < m_vwsdOrig.Size(); ++iwsd)
	{
		if (m_vwsd[iwsd].m_ws && m_vwsd[iwsd].m_ws != m_vwsdOrig[iwsd].m_ws)
			viwsdChg.Push(iwsd);
	}
	if (!viwsdChg.Size())
		return;
	// Check whether the set of new encodings overlaps with the set of old encodings.
	StrApp strTitle(kstidLangProjPropMsgCaption);
	int i;
	int iwsdX;
	for (i = 0; i < viwsdChg.Size(); ++i)
	{
		iwsdX = viwsdChg[i];
		for (iwsd = 0; iwsd < m_vwsd.Size(); ++iwsd)
		{
			if (iwsd == iwsdX)
				continue;
			if (m_vwsd[iwsd].m_ws == m_vwsd[iwsdX].m_ws)
			{
		// "Cannot change writing system %<0>s to %<1>s because %<1>s is already used for %<2>s"
				StrApp strFmt(kstidLngPrjEncNotUnique);
				StrApp strWsOld(m_vwsdOrig[iwsdX].m_stuIcuLocale.Chars());
				StrApp strWsNew(m_vwsd[iwsd].m_stuIcuLocale.Chars());
				StrApp strName(m_vwsd[iwsd].m_stuName.Chars());
				StrApp strMsg;
				strMsg.Format(strFmt.Chars(), strWsOld.Chars(), strWsNew.Chars(),
					strName.Chars());
				::MessageBox(NULL, strMsg.Chars(), strTitle.Chars(), MB_OK|MB_ICONINFORMATION);
				return;
			}
		}
	}
	for (i = 0; i < viwsdChg.Size(); ++i)
	{
		iwsdX = viwsdChg[i];
		for (iwsd = 0; iwsd < m_vwsdOrig.Size(); ++iwsd)
		{
			if (iwsd == iwsdX)
				continue;
			if (m_vwsdOrig[iwsd].m_ws == m_vwsd[iwsdX].m_ws)
			{
		// "Cannot change writing system %<0>s to %<1>s because %<1>s was being used for %<2>s"
				StrApp strFmt(kstidLngPrjEncWasUsed);
				StrApp strWsNew(m_vwsdOrig[iwsdX].m_stuIcuLocale.Chars());
				StrApp strWsOld(m_vwsd[iwsdX].m_ws);

				StrApp strName(m_vwsdOrig[iwsd].m_stuName.Chars());
				StrApp strMsg;
				strMsg.Format(strFmt.Chars(), strWsNew.Chars(), strWsOld.Chars(),
					strName.Chars());
				::MessageBox(NULL, strMsg.Chars(), strTitle.Chars(), MB_OK|MB_ICONINFORMATION);
				return;
			}
		}
	}
	// Check whether we're trying to change the User Interface writing system, which is embedded
	// in the resources.
	for (i = 0; i < viwsdChg.Size(); ++i)
	{
		iwsd = viwsdChg[i];
		if (m_wsUser == m_vwsdOrig[iwsd].m_ws)
		{
	// "Cannot change writing system %<0>s to %<1>s because %<0>s is the User Interface writing system."
			StrApp strFmt(kstidLngPrjEncForUI);
			StrApp strWsOld(m_vwsdOrig[iwsd].m_stuIcuLocale.Chars());
			StrApp strWsNew(m_vwsd[iwsd].m_stuIcuLocale.Chars());
			StrApp strMsg;
			strMsg.Format(strFmt.Chars(), strWsOld.Chars(), strWsNew.Chars());
			::MessageBox(NULL, strMsg.Chars(), strTitle.Chars(), MB_OK | MB_ICONINFORMATION);
			return;
		}
	}

	// Okay, we are now ready to make the changes.
	bool fStrCrawlInit = false;
	RecMainWnd * prmw = dynamic_cast<RecMainWnd *>(MainWindow());
	AssertPtr(prmw);
	AfLpInfo * plpi = prmw->GetLpInfo();
	AssertPtr(plpi);
	AfDbInfo * pdbi = plpi->GetDbInfo();
	AssertPtr(pdbi);
	StrUni stuDbName(pdbi->DbName());
	StrUni stuServerName(pdbi->ServerName());
	HVO hvoRootObj = prmw->GetRootObj(); // The root object being shown (list, or notebook).

	ChangeEncStringCrawler cesc(false, true, true, false);
	ULONG cbLog;
	StrAnsi staLog;

	AfProgressDlgPtr qprog;
	qprog.Create();

	// ENHANCE: Instead of a separate loop for each writing system, they could all be combined into
	// a single pass. This is low priority because it is probably rare to change more than one
	// writing system ID at a time.

	for (i = 0; i <viwsdChg.Size(); ++i)
	{
		iwsd = viwsdChg[i];
		int wsOld = m_vwsdOrig[iwsd].m_ws;
		int wsNew = m_vwsd[iwsd].m_ws;

		cesc.m_wsOld = wsOld;
		cesc.m_wsNew = wsNew;
		StrUni stuFmt;
		StrUni stuMsg;

		if (!fStrCrawlInit)
		{
			fStrCrawlInit = true; // regardless of whether DB connection succeeds below.

			IAdvInd3Ptr qadvi3;
			qprog->QueryInterface(IID_IAdvInd3, (void **)&qadvi3);

			IStreamPtr qfist;
			CheckHr(AfApp::Papp()->GetLogPointer(&qfist));
			if (!cesc.Init(stuServerName.Chars(), stuDbName.Chars(), qfist, qadvi3))
			{
				cesc.Terminate(hvoRootObj);
				return;
			}
			qprog->DoModeless(NULL);
			qprog->SetRange(0, 100);
		}

		// "Change Language Code From %<0>s To %<1>s"
		stuFmt.Load(kstidLngPrjChangeEnc);
		stuMsg.Format(stuFmt.Chars(),
			m_vwsdOrig[iwsd].m_stuIcuLocale.Chars(),	// old ws
			m_vwsd[iwsd].m_stuIcuLocale.Chars());		// new ws
		qprog->put_Title(stuMsg.Bstr());
		stuMsg.Clear();
		qprog->put_Message(stuMsg.Bstr());

		////////////////////////////////////////////////////////////////////////////////////
		// Munge the database as needed to change language encodings.

		cesc.ResetConnection();
		if (cesc.LogFile())
		{
			staLog.Format("Changing Language Writing system for %S from %S to %S in %S (%S)%n",
				m_vwsd[iwsd].m_stuName.Chars(),		// name
				m_vwsdOrig[iwsd].m_stuIcuLocale,	// old ws
				m_vwsd[iwsd].m_stuIcuLocale,		// new ws
				cesc.DbName().Chars(), cesc.ServerName().Chars());
			cesc.LogFile()->Write(staLog.Chars(), staLog.Length(), &cbLog);
		}
		cesc.BeginTrans();
		cesc.CreateCommand();
		StrUni stuCmd;
		ComBool fMoreRows;
		ComBool fIsNull;
		unsigned long cbSpaceTaken;
		// Update the encodings for all forms of multilingual text.
		// Note that this command assumes there is only one language project per database:
		// If there are more than one, this command updates the indicated multilingual
		// strings in all of the language projects.
		stuMsg.Load(kstidLngPrjChgEncPhaseOne);
		qprog->put_Message(stuMsg.Bstr());

		stuCmd.Format(L"UPDATE MultiTxt$ SET Ws=%d WHERE Ws=%d ; "
			L"UPDATE MultiBigTxt$ SET Ws=%d WHERE Ws=%d ; "
			L"UPDATE MultiStr$ SET Ws=%d WHERE Ws=%d ; "
			L"UPDATE MultiBigStr$ SET Ws=%d WHERE Ws=%d",
			wsNew, wsOld, wsNew, wsOld, wsNew, wsOld, wsNew, wsOld);
		CheckHr(cesc.GetOleDbCommand()->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		cesc.SetPercentComplete(5);

		// Do the standard stuff for monolingual and multilingual strings.
		cesc.DoAll(kstidLngPrjChgEncPhaseOne, kstidLngPrjChgEncPhaseTwo,
			false);	// don't create a new transaction--this method handles it

		// Update the structured text style rules for StPara and StStyle.
		// First StPara.
		stuMsg.Load(kstidLngPrgChgEncPhaseThree);
		qprog->put_Message(stuMsg.Bstr());
		int nPercent = 0;
		cesc.SetPercentComplete(nPercent);

		int hobj = 0;
		//int flid = 0;
		//int encStr;
		Vector<byte> vbFmt;
		int cbFmt;

		int ceFix;
		int ieFix;
		Vector<int> vflidFix;
		Vector<int> vhobjFix;
		Vector<int> vwsFix;
		Vector<Vector<byte> > vvbFmtFix;

		// Get the count of rows for the sake of the progress indicator dialog.
		// Review (SharonC): Does this slow things down too much?
		int cRows;
		StrUni stuCmdCnt(
			L"SELECT count (*) FROM StPara (readuncommitted) WHERE StyleRules IS NOT NULL");
		CheckHr(cesc.GetOleDbCommand()->ExecCommand(stuCmdCnt.Bstr(),
			knSqlStmtSelectWithOneRowset));
		CheckHr(cesc.GetOleDbCommand()->GetRowset(0));
		CheckHr(cesc.GetOleDbCommand()->NextRow(&fMoreRows));
		CheckHr(cesc.GetOleDbCommand()->GetColValue(1, reinterpret_cast <ULONG *>(&cRows),
			isizeof(hobj), &cbSpaceTaken, &fIsNull, 0));

		// Get the items.
		stuCmd.Format(L"SELECT [Id], StyleRules FROM StPara (readuncommitted) "
			L"WHERE StyleRules IS NOT NULL");
		CheckHr(cesc.GetOleDbCommand()->ExecCommand(stuCmd.Bstr(),
			knSqlStmtSelectWithOneRowset));
		CheckHr(cesc.GetOleDbCommand()->GetRowset(0));
		CheckHr(cesc.GetOleDbCommand()->NextRow(&fMoreRows));
		vbFmt.Resize(1024);
		int iRow = 0;
		while (fMoreRows)
		{
			CheckHr(cesc.GetOleDbCommand()->GetColValue(1, reinterpret_cast<ULONG *>(&hobj),
				isizeof(hobj), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(cesc.GetOleDbCommand()->GetColValue(2,
				reinterpret_cast<ULONG *>(vbFmt.Begin()), vbFmt.Size(),
				&cbSpaceTaken, &fIsNull, 0));
			cbFmt = cbSpaceTaken;
			if (cbFmt >= vbFmt.Size())
			{
				vbFmt.Resize(cbFmt + 1);
				CheckHr(cesc.GetOleDbCommand()->GetColValue(2,
					reinterpret_cast<ULONG *>(vbFmt.Begin()), vbFmt.Size(),
					&cbSpaceTaken, &fIsNull, 0));
				cbFmt = cbSpaceTaken;
			}
			vbFmt.Resize(cbFmt);
			if (ChangeStyleEnc(vbFmt, wsOld, wsNew))
			{
				// Mark the string for updating.
				vhobjFix.Push(hobj);
				vvbFmtFix.Push(vbFmt);
			}
			CheckHr(cesc.GetOleDbCommand()->NextRow(&fMoreRows));
			iRow++;
			cesc.SetPercentComplete((iRow * 30) / cRows);
		}
		cesc.SetPercentComplete(30);

		ceFix = vhobjFix.Size();
		for (ieFix = 0; ieFix < ceFix; ++ieFix)
		{
			stuCmd.Format(L"UPDATE StPara SET StyleRules=? WHERE [Id] = %d",
				vhobjFix[ieFix]);
			// Set the parameter and execute the command.
			CheckHr(cesc.GetOleDbCommand()->SetParameter(1, DBPARAMFLAGS_ISINPUT,
				NULL, DBTYPE_BYTES,
				reinterpret_cast<ULONG *>(vvbFmtFix[ieFix].Begin()),
				vvbFmtFix[ieFix].Size()));
			CheckHr(cesc.GetOleDbCommand()->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
			cesc.SetPercentComplete(30 + ((ieFix * 20) / ceFix));
		}
		vhobjFix.Clear();
		vvbFmtFix.Clear();
		cesc.SetPercentComplete(50);

		// Now do the same for StStyle.

		// Get the count.
		stuCmdCnt.Format(
			L"SELECT count (*) FROM StStyle (readuncommitted) WHERE Rules IS NOT NULL");
		CheckHr(cesc.GetOleDbCommand()->ExecCommand(stuCmdCnt.Bstr(),
			knSqlStmtSelectWithOneRowset));
		CheckHr(cesc.GetOleDbCommand()->GetRowset(0));
		CheckHr(cesc.GetOleDbCommand()->NextRow(&fMoreRows));
		CheckHr(cesc.GetOleDbCommand()->GetColValue(1, reinterpret_cast <ULONG *>(&cRows),
			isizeof(hobj), &cbSpaceTaken, &fIsNull, 0));

		// Get the items.
		stuCmd.Format(L"SELECT [Id], Rules FROM StStyle (readuncommitted) "
			L"WHERE Rules IS NOT NULL");
		CheckHr(cesc.GetOleDbCommand()->ExecCommand(stuCmd.Bstr(),
			knSqlStmtSelectWithOneRowset));
		CheckHr(cesc.GetOleDbCommand()->GetRowset(0));
		CheckHr(cesc.GetOleDbCommand()->NextRow(&fMoreRows));
		vbFmt.Resize(1024);
		iRow = 0;
		while (fMoreRows)
		{
			CheckHr(cesc.GetOleDbCommand()->GetColValue(1, reinterpret_cast <ULONG *>(&hobj),
				isizeof(hobj), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(cesc.GetOleDbCommand()->GetColValue(2,
				reinterpret_cast<ULONG *>(vbFmt.Begin()), vbFmt.Size(),
				&cbSpaceTaken, &fIsNull, 0));
			cbFmt = cbSpaceTaken;
			if (cbFmt >= vbFmt.Size())
			{
				vbFmt.Resize(cbFmt + 1);
				CheckHr(cesc.GetOleDbCommand()->GetColValue(2,
					reinterpret_cast<ULONG *>(vbFmt.Begin()), vbFmt.Size(),
					&cbSpaceTaken, &fIsNull, 0));
				cbFmt = cbSpaceTaken;
			}
			vbFmt.Resize(cbFmt);
			if (ChangeStyleEnc(vbFmt, wsOld, wsNew))
			{
				// Mark the string for updating.
				vhobjFix.Push(hobj);
				vvbFmtFix.Push(vbFmt);
			}
			CheckHr(cesc.GetOleDbCommand()->NextRow(&fMoreRows));
			iRow++;
			cesc.SetPercentComplete(50 + ((iRow * 30) / cRows));
		}

		cesc.SetPercentComplete(80);

		ceFix = vhobjFix.Size();
		for (ieFix = 0; ieFix < ceFix; ++ieFix)
		{
			stuCmd.Format(L"UPDATE StStyle SET Rules=? WHERE [Id] = %d",
				vhobjFix[ieFix]);
			// Set the parameter and execute the command.
			CheckHr(cesc.GetOleDbCommand()->SetParameter(1, DBPARAMFLAGS_ISINPUT,
				NULL, DBTYPE_BYTES,
				reinterpret_cast<ULONG *>(vvbFmtFix[ieFix].Begin()),
				vvbFmtFix[ieFix].Size()));
			CheckHr(cesc.GetOleDbCommand()->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
			cesc.SetPercentComplete(80 + ((ieFix * 18) / ceFix));
		}
		vhobjFix.Clear();
		vvbFmtFix.Clear();

		cesc.SetPercentComplete(98);

		// Change the Language Writing system itself in the database.
//-		stuCmd.Format(L"UPDATE [LgWritingSystem] SET [Code]=%d WHERE [Code]=%d",
//-			wsNew, wsOld);
//-		CheckHr(cesc.GetOleDbCommand()->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		Assert(false);		// We gotta change everything.

		cesc.SetPercentComplete(100);
		cesc.CommitTrans();
	}

	// Notify the database that we've made a change.
	SyncInfo sync(ksyncWs, 0, 0);
	cesc.Terminate(hvoRootObj);

	// This is needed because the old AfDbInfo object is destroyed by the processing above.
	AfDbApp * pdapp = dynamic_cast<AfDbApp *>(AfApp::Papp());
	Assert(pdapp);
	pdbi = pdapp->GetDbInfo(stuDbName.Chars(), stuServerName.Chars());

	// We need to store a synch message on startup.
	Vector<AfLpInfoPtr> & vlpi = pdbi->GetLpiVec();

	// There should only be a single LpInfo at this point.
	Assert(vlpi.Size() == 1);
	vlpi[0]->StoreSync(sync);
	if (qprog)
		qprog->DestroyHwnd();
}

/*----------------------------------------------------------------------------------------------
	Handle a popup menu command for choosing the desired language writing system.

	@param pcmd Pointer to the command information.

	@return True.
----------------------------------------------------------------------------------------------*/
bool LangProjPropWrtSys::CmdNewVernWS(Cmd * pcmd)
{
	// We don't need to do anything here, since ::TrackPopupMenu() is set to return the code.
	return true;
}

/*----------------------------------------------------------------------------------------------
	Handle a popup menu command for choosing the desired language writing system.

	@param pcmd Pointer to the command information.

	@return True.
----------------------------------------------------------------------------------------------*/
bool LangProjPropWrtSys::CmdNewAnalWS(Cmd * pcmd)
{
	// We don't need to do anything here, since ::TrackPopupMenu() is set to return the code.
	return true;
}

/*----------------------------------------------------------------------------------------------
	Handle adding a language writing system to a list (either vernacular list or analysis list).

	@param ctidNewWS Control id of pushbutton for adding a new language writing system to a list.
	@param cidNewWS Control id of related popup menu.
	@param cidWrtSysList Control id of the related list of language encodings.
	@param viwsd Vector of indexes into m_vwsd for elements in the list of language encodings.
	@param ctidMoveDown Control id of related pushbutton for moving selection down in the list.
	@param ctidMoveUp Control id of related pushbutton for moving selection up in the list.
	@param ctidDelete Control id of related pushbutton for deleting the selection from the list.
----------------------------------------------------------------------------------------------*/
void LangProjPropWrtSys::AddWrtSys(int ctidNewWS, int cidNewWS, int cidWrtSysList,
	Vector<int> & viwsd, int ctidMoveDown, int ctidMoveUp, int ctidDelete)
{
	AssertPtr(m_qwsf);
	StrApp strTitle(kstidLangProjPropMsgCaption);
	StrApp strMsg;
	HWND hwnd = ::GetDlgItem(m_hwnd, cidWrtSysList);

	// create a menu consisting of the names of the defined language encodings (from m_vwsd)
	// that are not already on the list of encodings (viwsd), plus the command "New..." at the
	// end, following a separator.
	HMENU hmenu = ::CreatePopupMenu();
	StrApp str;
	if (!hmenu)
		ThrowHr(WarnHr(E_FAIL));
	int iwsd;
	int ii;
	bool fIgnore;
	for (iwsd = 0; iwsd < m_vwsd.Size(); ++iwsd)
	{
		fIgnore = !m_vwsd[iwsd].m_ws;
		if (fIgnore)
			continue;		// <unknown> writing system.  (?)
		if (!m_vwsd[iwsd].m_stuName.Length() && !m_vwsd[iwsd].m_lcid)
			continue;		// Marked for deletion.
		for (ii = 0; ii < viwsd.Size(); ++ii)
		{
			if (viwsd[ii] == iwsd)
			{
				fIgnore = true;
				break;
			}
		}
		if (fIgnore)
			continue;
		str.Assign(m_vwsd[iwsd].m_stuName);
		::AppendMenu(hmenu, MF_STRING, kcidMenuItemDynMin + iwsd, str.Chars());
	}
	::AppendMenu(hmenu, MF_SEPARATOR, 0, 0);
	str.Load(kstidLngPrjNewWrtSys);
	::AppendMenu(hmenu, MF_STRING, kcidMenuItemDynMin + m_vwsd.Size(), str.Chars());

	// Show the popup menu that allows a user to choose the language.
	Rect rc;
	::GetWindowRect(::GetDlgItem(m_hwnd, ctidNewWS), &rc);
	AfApp::GetMenuMgr()->SetMenuHandler(cidNewWS);
	int icmd = ::TrackPopupMenu(hmenu, TPM_LEFTALIGN | TPM_RIGHTBUTTON | TPM_RETURNCMD,
		rc.left, rc.bottom, 0, m_hwnd, NULL);
	::DestroyMenu(hmenu);
	if (icmd)
	{
		iwsd = icmd - kcidMenuItemDynMin;
		if (iwsd == m_vwsd.Size())
		{
			// Start of using C# New Writing System wizard
			FwCoreDlgs::IWritingSystemWizardPtr qwsw;
			qwsw.CreateInstance("FwCoreDlgs.WritingSystemWizard");
			CheckHr(qwsw->Init(m_qwsf));
			long nRet;
			CheckHr(qwsw->DisplayDialog(&nRet));
			if (nRet == kctidOk)
			{
				ILgWritingSystemPtr qws;
				IUnknownPtr qunk;
				CheckHr(qwsw->WritingSystem(&qunk));
				CheckHr(qunk->QueryInterface(IID_ILgWritingSystem, (void **)&qws));
				WrtSysData wsd;
				SmartBstr sbstr;
				CheckHr(qws->get_IcuLocale(&sbstr));
				wsd.m_stuIcuLocale.Assign(sbstr.Chars());
				CheckHr(m_qwsf->GetWsFromStr(wsd.m_stuIcuLocale.Bstr(), &wsd.m_ws));
				CheckHr(qws->get_Name(m_wsUser, &sbstr));
				wsd.m_stuName = sbstr.Chars();
				CheckHr(qws->get_Locale(&wsd.m_lcid));
				CheckHr(qws->get_DefaultSerif(&sbstr));
				wsd.m_stuNormalFont = sbstr.Chars();
				CheckHr(qws->get_DefaultSansSerif(&sbstr));
				wsd.m_stuHeadingFont = sbstr.Chars();
				viwsd.Push(m_vwsd.Size());
				m_vwsd.Push(wsd);
				StrApp strName(wsd.m_stuName);
				LVITEM lvi;
				::ZeroMemory(&lvi, isizeof(lvi));
				lvi.mask = LVIF_TEXT;
				lvi.iItem = ListView_GetItemCount(hwnd);
				lvi.pszText = const_cast<achar *>(strName.Chars());
				lvi.cchTextMax = _tcslen(lvi.pszText);
				ListView_InsertItem(hwnd, &lvi);
				ListView_SetCheckState(hwnd, lvi.iItem, TRUE);
			}
//			else if (n == -1)
//			{
//				DWORD dwError = ::GetLastError();
//				achar rgchMsg[MAX_PATH+1];
//				DWORD cch = ::FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwError, 0,
//					rgchMsg, MAX_PATH, NULL);
//				rgchMsg[cch] = 0;
//				::MessageBox(m_hwnd, rgchMsg, strTitle.Chars(), MB_OK | MB_ICONWARNING);
//				return;
//			}
			// End of using C# New Writing System wizard
		}
		else
		{
			// Insert an existing language into the vernacular list.
			viwsd.Push(iwsd);
			LVITEM lvi;
			::ZeroMemory(&lvi, isizeof(lvi));
			lvi.mask = LVIF_TEXT;
			lvi.iItem = ListView_GetItemCount(hwnd);
			str.Assign(m_vwsd[iwsd].m_stuName);
			lvi.pszText = const_cast<achar *>(str.Chars());
			lvi.cchTextMax = _tcslen(lvi.pszText);
			ListView_InsertItem(hwnd, &lvi);
			ListView_SetCheckState(hwnd, lvi.iItem, TRUE);
		}
	}
	else
	{
		// error message?
	}
	::EnableWindow(::GetDlgItem(m_hwnd, ctidMoveDown), viwsd.Size() > 1);
	::EnableWindow(::GetDlgItem(m_hwnd, ctidMoveUp), viwsd.Size() > 1);
	::EnableWindow(::GetDlgItem(m_hwnd, ctidDelete), viwsd.Size() > 1);

	Assert(viwsd.Size() == ListView_GetItemCount(hwnd));
}

/*----------------------------------------------------------------------------------------------
	Handle modifying a language writing system in a list (either vernacular list or analysis list),
	with changes reflected in the other list as well.

	@param cidList Control id of the list of language encodings.
	@param viwsd Vector of indexes into m_vwsd for elements in the list of language encodings.
	@param cidListOther Control id of the other list.
	@param viwsdOther Vector of indexes into m_vwsd for the other list.
----------------------------------------------------------------------------------------------*/
void LangProjPropWrtSys::ModifyWrtSys(int cidList, Vector<int> & viwsd, int cidListOther,
	Vector<int> & viwsdOther)
{
	AssertPtr(m_qwsf);
	StrApp strTitle(kstidLangProjPropMsgCaption);
	StrApp strMsg;
	HWND hwnd = ::GetDlgItem(m_hwnd, cidList);
	if (ListView_GetSelectedCount(hwnd) > 0)
	{
		// Locate the selected item.
		int iselLim = ListView_GetItemCount(hwnd);
		int isel;
		for (isel = 0; isel < iselLim; ++isel)
		{
			if (ListView_GetItemState(hwnd, isel, LVIS_SELECTED))
				break;
		}
		Assert(isel < iselLim);
		int iwsd = viwsd[isel];

		// Start of using C# WritingSystemProperties dialog
		ILgWritingSystemPtr qws;

		SmartBstr sbstr;
		m_qwsf->GetStrFromWs(m_vwsd[iwsd].m_ws, &sbstr);
		m_qwsf->get_Engine(sbstr, &qws);

		FwCoreDlgs::IWritingSystemPropertiesDialogPtr qwspd;
		qwspd.CreateInstance("FwCoreDlgs.WritingSystemPropertiesDialog");
		IFwToolPtr qfwt;
		const CLSID * pclsid = AfApp::Papp()->GetAppClsid();
		AssertPtr(pclsid);
		// Check to see if the application is already running.
		IRunningObjectTablePtr qrot;
		CheckHr(::GetRunningObjectTable(0, &qrot));
		IMonikerPtr qmnk;
		CheckHr(::CreateClassMoniker(*pclsid, &qmnk));
		IUnknownPtr qunk;
		if (SUCCEEDED(qrot->GetObject(qmnk, &qunk)))
			qunk->QueryInterface(IID_IFwTool, (void **)&qfwt);

		AfLpInfo * plpi = m_ppropd->GetLangProjInfo();
		AfDbInfo * pdbi = plpi->GetDbInfo();
		StrUni stuServer(pdbi->ServerName());
		StrUni stuDatabase(pdbi->DbName());
		IStreamPtr qstrmLog;
		AfApp::Papp()->GetLogPointer(&qstrmLog);
		int hvoProj = plpi->GetLpId();
		int hvoRootObj = plpi->ObjId();
		CheckHr(qwspd->Initialize(qfwt, stuServer.Bstr(), stuDatabase.Bstr(), qstrmLog,
			hvoProj, hvoRootObj, m_wsUser));
		long pRet;
		qwspd->ShowDialog(qws, &pRet);

		// End of using C# WritingSystemProperties dialog

		//LangDefPropDlgPtr qldpd;
		//qldpd.Create();
		//qldpd->Initialize(m_qwsf,
		//	m_vwsd[iwsd].m_ws, m_vwsd[iwsd].m_stuName,
		//	m_vwsd[iwsd].m_lcid, m_vwsd[iwsd].m_stuNormalFont,
		//	m_vwsd[iwsd].m_stuHeadingFont, m_vwsd[iwsd].m_stuEncodingConverter,
		//	m_vwsd[iwsd].m_stuEncodingConvDesc, &m_vwsd);	// Last param for sanity checks.
		//int n = qldpd->DoModal(m_hwnd);
		//if (n == kctidOk)
		//{
		//	m_vwsd[iwsd].m_ws = qldpd->EthCode();
		//	StrUni stu = qldpd->LanguageName();
		//	if (stu != m_vwsd[iwsd].m_stuName)
		//	{
		//		m_vwsd[iwsd].m_stuName = stu;
		//		ListView_SetItemText(hwnd, isel, 0,
		//			const_cast<achar *>(qldpd->LanguageName()));
		//		int ii;
		//		for (ii = 0; ii < viwsdOther.Size(); ++ii)
		//		{
		//			if (viwsdOther[ii] == iwsd)
		//			{
		//				ListView_SetItemText(::GetDlgItem(m_hwnd, cidListOther),
		//					ii, 0, const_cast<achar *>(qldpd->LanguageName()));
		//				break;
		//			}
		//		}
		//	}
		//	m_vwsd[iwsd].m_lcid = qldpd->LocaleId();
		//	m_vwsd[iwsd].m_stuNormalFont = qldpd->NormalFont();
		//	m_vwsd[iwsd].m_stuHeadingFont = qldpd->HeadingFont();
		//}
		//else if (n == -1)
		//{
		//	DWORD dwError = ::GetLastError();
		//	achar rgchMsg[MAX_PATH+1];
		//	DWORD cch = ::FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwError,
		//		0, rgchMsg, MAX_PATH, NULL);
		//	rgchMsg[cch] = 0;
		//	::MessageBox(m_hwnd, rgchMsg, strTitle.Chars(), MB_OK | MB_ICONWARNING);
		//	return;
		//}
	}
	Assert(viwsd.Size() == ListView_GetItemCount(hwnd));
}

/*----------------------------------------------------------------------------------------------
	Handle moving a language writing system down in the list (either vernacular list or analysis
	list).

	@param cidList Control id of the list of language encodings.
	@param viwsd Vector of indexes into m_vwsd for elements in the list of language encodings.
----------------------------------------------------------------------------------------------*/
void LangProjPropWrtSys::MoveWrtSysDown(int cidList, Vector<int> & viwsd)
{
	HWND hwnd = ::GetDlgItem(m_hwnd, cidList);
	if (ListView_GetSelectedCount(hwnd) > 0)
	{
		// Locate the selected item.
		int iselLim = ListView_GetItemCount(hwnd);
		int isel;
		for (isel = 0; isel < iselLim; ++isel)
		{
			if (ListView_GetItemState(hwnd, isel, LVIS_SELECTED))
				break;
		}
		Assert(isel < iselLim);
		if (isel + 1 < iselLim)
		{
			int iwsd;
			StrApp str;
			viwsd.Delete(isel, &iwsd);
			viwsd.Insert(isel + 1, iwsd);
			BOOL fCheck1 = ListView_GetCheckState(hwnd, isel);
			BOOL fCheck2 = ListView_GetCheckState(hwnd, isel + 1);
			str = m_vwsd[viwsd[isel]].m_stuName;
			ListView_SetItemText(hwnd, isel, 0, const_cast<achar *>(str.Chars()));
			ListView_SetCheckState(hwnd, isel, fCheck2);
			str = m_vwsd[viwsd[isel + 1]].m_stuName;
			ListView_SetItemText(hwnd, isel + 1, 0, const_cast<achar *>(str.Chars()));
			ListView_SetCheckState(hwnd, isel + 1, fCheck1);
			ListView_SetItemState(hwnd, isel + 1, LVIS_SELECTED, LVIS_SELECTED);
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Handle moving a language writing system up in the list (either vernacular list or analysis list).

	@param cidList Control id of the list of language encodings.
	@param viwsd Vector of indexes into m_vwsd for elements in the list of language encodings.
----------------------------------------------------------------------------------------------*/
void LangProjPropWrtSys::MoveWrtSysUp(int cidList, Vector<int> & viwsd)
{
	HWND hwnd = ::GetDlgItem(m_hwnd, cidList);
	if (ListView_GetSelectedCount(hwnd) > 0)
	{
		// Locate the selected item.
		int iselLim = ListView_GetItemCount(hwnd);
		int isel;
		for (isel = 0; isel < iselLim; ++isel)
		{
			if (ListView_GetItemState(hwnd, isel, LVIS_SELECTED))
				break;
		}
		Assert(isel < iselLim);
		if (isel > 0)
		{
			int iwsd;
			StrApp str;
			viwsd.Delete(isel, &iwsd);
			viwsd.Insert(isel - 1, iwsd);
			BOOL fCheck1 = ListView_GetCheckState(hwnd, isel);
			BOOL fCheck2 = ListView_GetCheckState(hwnd, isel - 1);
			str = m_vwsd[viwsd[isel]].m_stuName;
			ListView_SetItemText(hwnd, isel, 0, const_cast<achar *>(str.Chars()));
			ListView_SetCheckState(hwnd, isel, fCheck2);
			str = m_vwsd[viwsd[isel - 1]].m_stuName;
			ListView_SetItemText(hwnd, isel - 1, 0, const_cast<achar *>(str.Chars()));
			ListView_SetCheckState(hwnd, isel - 1, fCheck1);
			ListView_SetItemState(hwnd, isel - 1, LVIS_SELECTED, LVIS_SELECTED);
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Handle removing a language writing system from an active list, either vernacular or analysis.

	@param cidList Control id of the list of language encodings.
	@param viwsd Vector of indexes into m_vwsd for elements in the list of language encodings.
	@param ctidMoveDown Control id of related pushbutton for moving selection down in the list.
	@param ctidMoveUp Control id of related pushbutton for moving selection up in the list.
	@param ctidDelete Control id of related pushbutton for deleting the selection from the list.
----------------------------------------------------------------------------------------------*/
void LangProjPropWrtSys::RemoveWrtSys(int cidList, Vector<int> & viwsd, int ctidMoveDown,
	int ctidMoveUp, int ctidDelete)
{
	HWND hwnd = ::GetDlgItem(m_hwnd, cidList);
	if (ListView_GetSelectedCount(hwnd) > 0)
	{
		StrApp strTitle(kstidLangProjPropMsgCaption);
		StrApp strMsg;
		// Locate the selected item.
		int iselLim = ListView_GetItemCount(hwnd);
		int isel;
		for (isel = 0; isel < iselLim; ++isel)
		{
			if (ListView_GetItemState(hwnd, isel, LVIS_SELECTED))
				break;
		}
		Assert(isel < iselLim);
		Assert(iselLim >= 2);

		// Go ahead and delete it from the desired list on the display.
		viwsd.Delete(isel);
		ListView_DeleteItem(hwnd, isel);
		::EnableWindow(::GetDlgItem(m_hwnd, ctidMoveDown), viwsd.Size() > 1);
		::EnableWindow(::GetDlgItem(m_hwnd, ctidMoveUp), viwsd.Size() > 1);
		::EnableWindow(::GetDlgItem(m_hwnd, ctidDelete), viwsd.Size() > 1);
	}
}

#if 0
// ALTHOUGH THIS CODE HAS BEEN COMMENTED OUT, IT MAY BE USEFUL AS A BASIS FOR IMPLEMENTING ITS
// FUNCTIONALITY AT A DIFFERENT PLACE IN THE USER INTERFACE.
/*----------------------------------------------------------------------------------------------
	Handle deleting a language writing system.

	@param cidList Control id of the list of language encodings.
	@param viwsd Vector of indexes into m_vwsd for elements in the list of language encodings.
	@param ctidMoveDown Control id of related pushbutton for moving selection down in the list.
	@param ctidMoveUp Control id of related pushbutton for moving selection up in the list.
	@param ctidDelete Control id of related pushbutton for deleting the selection from the list.

	@param cidListOther Control id of the other list of language encodings.
	@param viwsdOther Vector of indexes into m_vwsd for elements in the other list of language
					encodings.
	@param ctidMoveDownOther Control id of related pushbutton for moving selection down in the
					other list.
	@param ctidMoveUpOther Control id of related pushbutton for moving selection up in the
					other list.
	@param ctidDeleteOther Control id of related pushbutton for deleting the selection from the
					other list.
----------------------------------------------------------------------------------------------*/
void LangProjPropWrtSys::DeleteWrtSys(int cidList, Vector<int> & viwsd, int ctidMoveDown,
	int ctidMoveUp, int ctidDelete, int cidListOther, Vector<int> & viwsdOther,
	int ctidMoveDownOther, int ctidMoveUpOther, int ctidDeleteOther)
{
	AssertPtr(m_qwsf);
	HWND hwnd = ::GetDlgItem(m_hwnd, cidList);
	if (ListView_GetSelectedCount(hwnd) > 0)
	{
		StrApp strTitle(kstidLangProjPropMsgCaption);
		StrApp strMsg;
		// Locate the selected item.
		int iselLim = ListView_GetItemCount(hwnd);
		int isel;
		for (isel = 0; isel < iselLim; ++isel)
		{
			if (ListView_GetItemState(hwnd, isel, LVIS_SELECTED))
				break;
		}
		Assert(isel < iselLim);
		int iwsd = viwsd[isel];

		WaitCursor wc;

		HWND hwnd2 = ::GetDlgItem(m_hwnd, cidListOther);
		int iselLim2 = ListView_GetItemCount(hwnd2);
		int isel2;
		for (isel2 = 0; isel2 < iselLim2; ++isel2)
		{
			if (viwsdOther[isel2] == iwsd)
				break;
		}
		if (isel2 < iselLim2 && viwsdOther.Size() < 2)
		{
			strMsg.Load(cidList == kcidLngPrjVernWrtSysList ?
				kstidLngPrjCannotDeleteLastAnal : kstidLngPrjCannotDeleteLastVern);
			::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(), MB_OK);
			return;
		}

		// Verify that the user really, really wants to do this.
		strMsg.Load(kstidLngPrjContinueDelete);
		int nRet = ::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(),
			MB_YESNO | MB_ICONEXCLAMATION | MB_DEFBUTTON2);
		if (nRet != IDYES)
			return;
		StrApp strFmt(kstidLngPrjContinueDeleteFmt2);
		StrApp str(m_vwsd[iwsd].m_stuName);
		strMsg.Format(strFmt.Chars(), str.Chars());
		nRet = ::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(),
			MB_YESNO | MB_ICONEXCLAMATION | MB_DEFBUTTON2);
		if (nRet != IDYES)
			return;

		// THEY ASKED FOR IT!
		viwsd.Delete(isel);
		ListView_DeleteItem(hwnd, isel);
		::EnableWindow(::GetDlgItem(m_hwnd, ctidMoveDown), viwsd.Size() > 1);
		::EnableWindow(::GetDlgItem(m_hwnd, ctidMoveUp), viwsd.Size() > 1);
		::EnableWindow(::GetDlgItem(m_hwnd, ctidDelete), viwsd.Size() > 1);
		if (isel2 < iselLim2)
		{
			viwsdOther.Delete(isel2);
			ListView_DeleteItem(hwnd2, isel2);
			::EnableWindow(::GetDlgItem(m_hwnd, ctidMoveDownOther), viwsdOther.Size() > 1);
			::EnableWindow(::GetDlgItem(m_hwnd, ctidMoveUpOther), viwsdOther.Size() > 1);
			::EnableWindow(::GetDlgItem(m_hwnd, ctidDeleteOther), viwsd.Size() > 1);
		}

		// 1. Flush the data cache to the database.
		// 2. BEGIN TRANSACTION
		// 3. Munge the database.
		// 4. END TRANSACTION
		// 5. Delete all the windows open on the database, and reopen them to recreate the
		//    data cache.  (?)

		RecMainWnd * prmw = dynamic_cast<RecMainWnd *>(MainWindow());
		AssertPtr(prmw);
		prmw->SaveData(); // NO MORE UNDO OF PAST ACTIONS!
		AfLpInfoPtr qlpi = prmw->GetLpInfo();
		AssertPtr(qlpi.Ptr());

		IOleDbEncapPtr qode;
		AfDbInfoPtr qdbi = qlpi->GetDbInfo();
		AssertPtr(qdbi.Ptr());
		qdbi->GetDbAccess(&qode);
		AssertPtr(qode.Ptr());
		CheckHr(qode->BeginTrans());		// TODO: LOCK ACCESS TO DATABASE TO JUST ME?

		IOleDbCommandPtr qodc;
		CheckHr(qode->CreateCommand(&qodc));

		// Delete all multilingual strings in the specified writing system.
		StrUni stuCmd;
		ComBool fMoreRows;
		ComBool fIsNull;
		unsigned long cbSpaceTaken;
		// Note that this command assumes there is only one language project per database:  if
		// there are more than one, this command deletes the indicated multilingual strings from
		// all of the language projects.
		stuCmd.Format(
			L"DELETE FROM MultiTxt$ WHERE Ws = %d ; DELETE FROM MultiBigTxt$ WHERE Ws = %d ; "
			L"DELETE FROM MultiStr$ WHERE Ws = %d ; DELETE FROM MultiBigStr$ WHERE Ws = %d",
			m_vwsd[iwsd].m_ws, m_vwsd[iwsd].m_ws, m_vwsd[iwsd].m_ws, m_vwsd[iwsd].m_ws);
		CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));

		int hobj = 0;
		int flid = 0;
		int encStr;
		Vector<wchar> vchTxt;
		int cchTxt;
		Vector<byte> vbFmt;
		int cbFmt;

		int ieFix;
		Vector<int> vflidFix;
		Vector<int> vhobjFix;
		Vector<int> vwsFix;
		Vector<Vector<wchar> > vvchTxtFix;
		Vector<Vector<byte> > vvbFmtFix;
		int crun;
		int ieDel;
		Vector<int> vhobjDel;
		Vector<int> vflidDel;
		Vector<int> vwsDel;

		// Scan all remaining multilingual formatted strings for embedded runs in the
		// specified writing system.
		stuCmd.Format(L"SELECT Flid, Obj, Ws, Txt, Fmt FROM MultiStr$ (readuncommitted)");
		CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));
		vchTxt.Resize(1024);
		vbFmt.Resize(1024);
		while (fMoreRows)
		{
			CheckHr(qodc->GetColValue(1, reinterpret_cast <ULONG *>(&flid),
				isizeof(flid), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(2, reinterpret_cast <ULONG *>(&hobj),
				isizeof(hobj), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(3, reinterpret_cast <ULONG *>(&encStr),
				isizeof(encStr), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(4, reinterpret_cast <ULONG *>(vchTxt.Begin()),
				vchTxt.Size() * isizeof(wchar), &cbSpaceTaken, &fIsNull, 0));
			cchTxt = cbSpaceTaken / isizeof(wchar);
			Assert(cbSpaceTaken == cchTxt * sizeof(wchar));
			if (cchTxt >= vchTxt.Size())
			{
				vchTxt.Resize(cchTxt + 1);
				CheckHr(qodc->GetColValue(4, reinterpret_cast <ULONG *>(vchTxt.Begin()),
					vchTxt.Size() * isizeof(wchar), &cbSpaceTaken, &fIsNull, 0));
				cchTxt = cbSpaceTaken / isizeof(wchar);
				Assert(cchTxt < vchTxt.Size());
			}
			CheckHr(qodc->GetColValue(5, reinterpret_cast <ULONG *>(vbFmt.Begin()),
				vbFmt.Size(), &cbSpaceTaken, &fIsNull, 0));
			cbFmt = cbSpaceTaken;
			if (cbFmt >= vbFmt.Size())
			{
				vbFmt.Resize(cbFmt + 1);
				CheckHr(qodc->GetColValue(5, reinterpret_cast <ULONG *>(vbFmt.Begin()),
					vbFmt.Size(), &cbSpaceTaken, &fIsNull, 0));
				cbFmt = cbSpaceTaken;
			}
			vchTxt.Resize(cchTxt);
			vbFmt.Resize(cbFmt);
			if (PurgeEmbeddedEncRun(vchTxt, vbFmt, m_vwsd[iwsd].m_ws, &crun))
			{
				if (!crun)
				{
					// Nothing left in the string: mark it for deletion.
					vhobjDel.Push(hobj);
					vflidDel.Push(flid);
					vwsDel.Push(encStr);
				}
				else
				{
					// Mark the string for updating.
					vhobjFix.Push(hobj);
					vflidFix.Push(flid);
					vwsFix.Push(encStr);
					vvchTxtFix.Push(vchTxt);
					vvbFmtFix.Push(vbFmt);
				}
			}
			CheckHr(qodc->NextRow(&fMoreRows));
		}
		for (ieFix = 0; ieFix < vhobjFix.Size(); ++ieFix)
		{
			stuCmd.Format(L"UPDATE MultiStr$ SET Txt=?, Fmt=?"
				L" WHERE Obj = %d AND Flid = %d AND Ws = %d",
				vhobjFix[ieFix], vflidFix[ieFix], vwsFix[ieFix]);
			// Set the 2 parameters and execute the command.
			CheckHr(qodc->SetParameter(1, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_WSTR,
				reinterpret_cast<ULONG *>(vvchTxtFix[ieFix].Begin()),
				vvchTxtFix[ieFix].Size() * isizeof(wchar)));
			CheckHr(qodc->SetParameter(2, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_BYTES,
				reinterpret_cast<ULONG *>(vvbFmtFix[ieFix].Begin()),
				vvbFmtFix[ieFix].Size()));
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		}
		CheckHr(qode->CreateCommand(&qodc));
		for (ieDel = 0; ieDel < vhobjDel.Size(); ++ieDel)
		{
			stuCmd.Format(L"DELETE FROM MultiStr$ WHERE Obj = %d AND Flid = %d AND Ws = %d",
				vhobjDel[ieDel], vflidDel[ieDel], vwsDel[ieDel]);
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		}
		vhobjFix.Clear();
		vflidFix.Clear();
		vwsFix.Clear();
		vvchTxtFix.Clear();
		vvbFmtFix.Clear();
		vhobjDel.Clear();
		vflidDel.Clear();
		vwsDel.Clear();

		stuCmd.Format(L"SELECT Flid, Obj, Ws, Txt, Fmt FROM MultiBigStr$ (readuncommitted)");
		CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));
		vchTxt.Resize(4096);
		vbFmt.Resize(4096);
		while (fMoreRows)
		{
			CheckHr(qodc->GetColValue(1, reinterpret_cast <ULONG *>(&hobj),
				isizeof(hobj), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(2, reinterpret_cast <ULONG *>(&flid),
				isizeof(flid), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(3, reinterpret_cast <ULONG *>(&encStr),
				isizeof(encStr), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(4, reinterpret_cast <ULONG *>(vchTxt.Begin()),
				vchTxt.Size() * isizeof(wchar), &cbSpaceTaken, &fIsNull, 0));
			cchTxt = cbSpaceTaken / isizeof(wchar);
			Assert(cbSpaceTaken == cchTxt * sizeof(wchar));
			if (cchTxt >= vchTxt.Size())
			{
				vchTxt.Resize(cchTxt + 1);
				CheckHr(qodc->GetColValue(4, reinterpret_cast <ULONG *>(vchTxt.Begin()),
					vchTxt.Size() * isizeof(wchar), &cbSpaceTaken, &fIsNull, 0));
				cchTxt = cbSpaceTaken / isizeof(wchar);
				Assert(cchTxt < vchTxt.Size());
			}
			CheckHr(qodc->GetColValue(5, reinterpret_cast <ULONG *>(vbFmt.Begin()),
				vbFmt.Size(), &cbSpaceTaken, &fIsNull, 0));
			cbFmt = cbSpaceTaken;
			if (cbFmt >= vbFmt.Size())
			{
				vbFmt.Resize(cbFmt + 1);
				CheckHr(qodc->GetColValue(5, reinterpret_cast <ULONG *>(vbFmt.Begin()),
					vbFmt.Size(), &cbSpaceTaken, &fIsNull, 0));
				cbFmt = cbSpaceTaken;
			}
			vchTxt.Resize(cchTxt);
			vbFmt.Resize(cbFmt);
			if (PurgeEmbeddedEncRun(vchTxt, vbFmt, m_vwsd[iwsd].m_ws, &crun))
			{
				if (!crun)
				{
					// Nothing left in the string: mark it for deletion.
					vhobjDel.Push(hobj);
					vflidDel.Push(flid);
					vwsDel.Push(encStr);
				}
				else
				{
					// Mark the string for updating.
					vhobjFix.Push(hobj);
					vflidFix.Push(flid);
					vwsFix.Push(encStr);
					vvchTxtFix.Push(vchTxt);
					vvbFmtFix.Push(vbFmt);
				}
			}
			CheckHr(qodc->NextRow(&fMoreRows));
		}

		for (ieFix = 0; ieFix < vhobjFix.Size(); ++ieFix)
		{
			stuCmd.Format(L"UPDATE MultiBigStr$ SET Txt=?, Fmt=?"
				L" WHERE Obj = %d AND Flid = %d AND Ws = %d",
				vhobjFix[ieFix], vflidFix[ieFix], vwsFix[ieFix]);
			// Set the 2 parameters and execute the command.
			CheckHr(qodc->SetParameter(1, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_WSTR,
				reinterpret_cast<ULONG *>(vvchTxtFix[ieFix].Begin()),
				vvchTxtFix[ieFix].Size() * isizeof(wchar)));
			CheckHr(qodc->SetParameter(2, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_BYTES,
				reinterpret_cast<ULONG *>(vvbFmtFix[ieFix].Begin()),
				vvbFmtFix[ieFix].Size()));
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		}
		CheckHr(qode->CreateCommand(&qodc));
		for (ieDel = 0; ieDel < vhobjDel.Size(); ++ieDel)
		{
			stuCmd.Format(L"DELETE FROM MultiBigStr$ WHERE Obj = %d AND Flid = %d AND Ws = %d",
				vhobjDel[ieDel], vflidDel[ieDel], vwsDel[ieDel]);
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		}
		vhobjFix.Clear();
		vflidFix.Clear();
		vwsFix.Clear();
		vvchTxtFix.Clear();
		vvbFmtFix.Clear();
		vhobjDel.Clear();
		vflidDel.Clear();
		vwsDel.Clear();

		// Get all the formatted string fields in the database, scan all formatted strings for
		// embedded runs in the deleted writing system.
		// Note that the standard metadata cache does not provide the information we need.
		Vector<StrUni> vstuField;
		Vector<StrUni> vstuClass;
		const int * rgnTypes = { kcptString, kcptBigString };
		const int cTypes = isizeof(rgnTypes) / isizeof(int);
		DbStringCrawler::GetFieldsForTypes(qodc, rgnTypes, cTypes, vstuClass, vstuField)
		int istu;
		for (istu = 0; istu < vstuField.Size(); ++istu)
		{
			stuCmd.Format(L"SELECT [Id], %s, %s_fmt FROM %s (readuncommitted) "
				L"WHERE %s IS NOT NULL",
				vstuField[istu].Chars(), vstuField[istu].Chars(), vstuClass[istu].Chars(),
				vstuField[istu].Chars());
			CheckHr(qode->CreateCommand(&qodc));
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtSelectWithOneRowset));
			CheckHr(qodc->GetRowset(0));
			CheckHr(qodc->NextRow(&fMoreRows));
			vchTxt.Resize(1024);
			vbFmt.Resize(1024);
			while (fMoreRows)
			{
				CheckHr(qodc->GetColValue(1, reinterpret_cast <ULONG *>(&hobj),
					isizeof(hobj), &cbSpaceTaken, &fIsNull, 0));
				CheckHr(qodc->GetColValue(2, reinterpret_cast <ULONG *>(vchTxt.Begin()),
					vchTxt.Size() * isizeof(wchar), &cbSpaceTaken, &fIsNull, 0));
				cchTxt = cbSpaceTaken / isizeof(wchar);
				Assert(cbSpaceTaken == cchTxt * sizeof(wchar));
				if (cchTxt >= vchTxt.Size())
				{
					vchTxt.Resize(cchTxt + 1);
					CheckHr(qodc->GetColValue(2, reinterpret_cast <ULONG *>(vchTxt.Begin()),
						vchTxt.Size() * isizeof(wchar), &cbSpaceTaken, &fIsNull, 0));
					cchTxt = cbSpaceTaken / isizeof(wchar);
					Assert(cchTxt < vchTxt.Size());
				}
				CheckHr(qodc->GetColValue(3, reinterpret_cast <ULONG *>(vbFmt.Begin()),
					vbFmt.Size(), &cbSpaceTaken, &fIsNull, 0));
				cbFmt = cbSpaceTaken;
				if (cbFmt >= vbFmt.Size())
				{
					vbFmt.Resize(cbFmt + 1);
					CheckHr(qodc->GetColValue(3, reinterpret_cast <ULONG *>(vbFmt.Begin()),
						vbFmt.Size(), &cbSpaceTaken, &fIsNull, 0));
					cbFmt = cbSpaceTaken;
				}
				vchTxt.Resize(cchTxt);
				vbFmt.Resize(cbFmt);
				if (PurgeEmbeddedEncRun(vchTxt, vbFmt, m_vwsd[iwsd].m_ws, &crun))
				{
					// Mark the string for updating.
					vhobjFix.Push(hobj);
					vvchTxtFix.Push(vchTxt);
					vvbFmtFix.Push(vbFmt);
				}
				CheckHr(qodc->NextRow(&fMoreRows));
			}
			for (ieFix = 0; ieFix < vhobjFix.Size(); ++ieFix)
			{
				stuCmd.Format(L"UPDATE %s SET %s=?, %s_fmt=? WHERE [Id] = %d",
					vstuClass[istu].Chars(), vstuField[istu].Chars(), vstuField[istu].Chars(),
					vhobjFix[ieFix]);
				// Set the 2 parameters and execute the command.
				CheckHr(qodc->SetParameter(1, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_WSTR,
					reinterpret_cast<ULONG *>(vvchTxtFix[ieFix].Begin()),
					vvchTxtFix[ieFix].Size() * isizeof(wchar)));
				CheckHr(qodc->SetParameter(2, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_BYTES,
					reinterpret_cast<ULONG *>(vvbFmtFix[ieFix].Begin()),
					vvbFmtFix[ieFix].Size()));
				CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
			}
			vhobjFix.Clear();
			vvchTxtFix.Clear();
			vvbFmtFix.Clear();
		}

		// Delete the Language Writing system itself from the database.
		HVO hvoWs = m_vwsd[iwsd].m_ws;
		if (hvoWs)
		{
			stuCmd.Format(
			L"DELETE FROM [LanguageProject_AnalysisWritingSystems] where [Dst] = %d; "
			L"DELETE FROM [LanguageProject_VernacularWritingSystems] where [Dst] = %d; "
			L"DELETE FROM [LanguageProject_CurrentAnalysisWritingSystems] where [Dst] = %d; "
			L"DELETE FROM [LanguageProject_CurrentVernacularWritingSystems] where [Dst] = %d",
				hvoWs, hvoWs, hvoWs, hvoWs);
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));

			stuCmd.Format(L"DELETE FROM MultiTxt$ where [Obj] = %d; "
				L"DELETE FROM MultiStr$ where [Obj] = %d; "
				L"DELETE FROM [CmObject] WHERE [Id] = %d",
				hvoWs, hvoWs, hvoWs);
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));

			// TODO (KenZ): find other places in the conceptual model where ws has snuck in, and
			// fix them.

			stuCmd.Format(L"DELETE FROM [LgWritingSystem] WHERE [Id] = %d", hvoWs);
			CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
		}

		CheckHr(qode->CommitTrans());		// TODO: UNLOCK ACCESS TO DATABASE TO JUST ME?

		// Now for the hard part: HOW DO WE RESYNC EVERYTHING??!?!
		// FIXME: THIS CODE DOES NOT REALLY WORK!
		LangProjPropDlg * plppd = dynamic_cast<LangProjPropDlg *>(m_ppropd);
		AssertPtr(plppd);
		int ilist = plppd->GetListIndex();
		Set<int> siselOld;
		int iview = plppd->GetViewIndex();
		siselOld.Insert(iview);
		Set<int> siselNew;
		siselNew.Insert(iview);
		prmw->OnViewBarChange(ilist, siselOld, siselNew);

//		qrootbox->Reconstruct();

		// Delete the Language Writing system Engine from the factory.
		m_qwsf->RemoveEngine(m_vwsd[iwsd].m_ws);

		// Mark the selected language writing system / old writing system as deleted.
		m_vwsd[iwsd].m_ws = 0;
		m_vwsd[iwsd].m_stuName.Clear();
		m_vwsd[iwsd].m_lcid = 0;
		m_vwsd[iwsd].m_stuNormalFont.Clear();
		m_vwsd[iwsd].m_stuHeadingFont.Clear();
	}
}

/*----------------------------------------------------------------------------------------------
	Scan the serialized string vchTxt/vbFmt for runs in the given writing system.  If any are found,
	delete them from vchTxt and vbFmt, and return true.  Otherwise, return false.

	@param vchTxt Reference to a character vector containing the text of the string.
	@param vbFmt Reference to a byte vector containing the formatting information for the
					string.
	@param encDel Language writing system code for runs that need to be removed from the string.
	@param pcrun Pointer to an integer for returning the number of runs remaining in the string
					after any desired runs are removed.

	@return True if run with the given writing system was deleted, otherwise false.
----------------------------------------------------------------------------------------------*/
bool LangProjPropWrtSys::PurgeEmbeddedEncRun(Vector<wchar> & vchTxt, Vector<byte> & vbFmt,
	int encDel, int * pcrun)
{
	Assert(sizeof(int) == 4);
	AssertPtr(pcrun);
	int * pn = reinterpret_cast<int *>(vbFmt.Begin());
	int crun = *pn++;
	if (pcrun)
		*pcrun = crun;
	int crunDel = 0;
	int cbOffsets = isizeof(int) + 2 * crun * isizeof(int);
	int itip;
	int ctip;
	int itsp;
	int ctsp;
	int cbTsp;
	int irun;
	int ws;
	int scp;
	int cch;
	int cb;
	const byte * pbProp;
	const byte * pb;
	const byte * pbNext;
	Vector<int> vichMin;
	Vector<int> vibProp;
	Vector<bool> vfDel;
	vichMin.Resize(crun);
	vibProp.Resize(crun);
	vfDel.Resize(crun);

	Vector<Vector<wchar> > vvchTxtRun;
	Vector<Vector<byte> > vvbFmtRun;
	Vector<wchar> vch;
	Vector<byte> vb;

	for (irun = 0; irun < crun; ++irun)
	{
		vfDel[irun] = false;
		vichMin[irun] = pn[2 * irun];
		vibProp[irun] = pn[2 * irun + 1];
	}
	for (irun = 0; irun < crun; ++irun)
	{
		if (irun == crun - 1)
			cch = vchTxt.Size() - vichMin[irun];
		else
			cch = vichMin[irun + 1] - vichMin[irun];
		vch.Replace(0, vch.Size(), vchTxt.Begin() + vichMin[irun], cch);
		vvchTxtRun.Push(vch);
		pbProp = vbFmt.Begin() + cbOffsets + vibProp[irun];
		pb = pbProp;
		ctip = *pb++;
		ctsp = *pb++;
		for (itip = 0; itip < ctip; ++itip)
		{
			scp = TextProps::DecodeScp(pb, vbFmt.End() - pb, &pbNext);
			if (scp == kscpWs || scp == kscpWsAndOws)
			{
				ws = *(reinterpret_cast<const int *>(pbNext));
				if (ws == encDel)
				{
					vfDel[irun] = true;
					++crunDel;
				}
			}
			switch (scp & 0x3)
			{
			case 0:
				pb = pbNext + 1;
				break;
			case 1:
				pb = pbNext + 2;
				break;
			case 2:
				pb = pbNext + 4;
				break;
			case 3:
				pb = pbNext + 8;
				break;
			}
		}
		for (itsp = 0; itsp < ctsp; ++itsp)
		{
			scp = TextProps::DecodeScp(pb, vbFmt.End() - pb, &pbNext);
			cbTsp = TextProps::DecodeCch(pbNext, vbFmt.End()-pbNext, &pbNext) * isizeof(wchar);	
			pb = pbNext + cbTsp;
		}
		vb.Replace(0, vb.Size(), pbProp, pb - pbProp);
		vvbFmtRun.Push(vb);
	}
	if (!crunDel)
		return false;

	vichMin.Clear();

	// Delete the indicated runs.
	for (irun = 0; irun < crun; ++irun)
	{
		if (vfDel[irun])
		{
			vvchTxtRun.Delete(irun);
			vvbFmtRun.Delete(irun);
			vfDel.Delete(irun);
			vibProp.Delete(irun);
			--irun;
			--crun;
		}
	}
	vfDel.Clear();

	// Merge adjacent runs with the formatting information.
	for (irun = 1; irun < crun; ++irun)
	{
		if (vibProp[irun-1] == vibProp[irun])
		{
			vvchTxtRun[irun-1].InsertMulti(vvchTxtRun[irun-1].Size(), vvchTxtRun[irun].Size(),
				vvchTxtRun[irun].Begin());
			vvchTxtRun.Delete(irun);
			vvbFmtRun.Delete(irun);
			vibProp.Delete(irun);
			--irun;
			--crun;
		}
	}

	int irun2;
	for (irun = 0; irun < crun; ++irun)
	{
		for (irun2 = irun + 1; irun2 < crun; ++irun2)
		{
			if (vibProp[irun2] == vibProp[irun])
				vvbFmtRun[irun2].Clear();
		}
	}
	cb = 0;
	HashMap<int, int> hmibOldibNew;
	for (irun = 0; irun < crun; ++irun)
	{
		if (vvbFmtRun[irun].Size())
		{
			hmibOldibNew.Insert(vibProp[irun], cb);
			cb += vvbFmtRun[irun].Size();
		}
	}

	// Rebuild the output string.
	int ib;
	vchTxt.Clear();
	vbFmt.Clear();
	vbFmt.Resize(isizeof(int) + 2 * crun * isizeof(int) + cb);
	pn = reinterpret_cast<int *>(vbFmt.Begin());
	pn[0] = crun;
	++pn;
	for (irun = 0; irun < crun; ++irun)
	{
		pn[2 * irun] = vchTxt.Size();
		hmibOldibNew.Retrieve(vibProp[irun], &ib);
		pn[2 * irun + 1] = ib;
		vchTxt.InsertMulti(vchTxt.Size(), vvchTxtRun[irun].Size(), vvchTxtRun[irun].Begin());
	}
	pb = vbFmt.Begin() + isizeof(int) + 2 * crun * isizeof(int);
	for (irun = 0; irun < crun; ++irun)
	{
		if (vvbFmtRun[irun].Size())
		{
			memcpy(const_cast<byte *>(pb), vvbFmtRun[irun].Begin(), vvbFmtRun[irun].Size());
			pb += vvbFmtRun[irun].Size();
		}
	}
	Assert(pb == vbFmt.Begin() + vbFmt.Size());

	if (pcrun)
		*pcrun = irun2;

	return true;
}
#endif

/*----------------------------------------------------------------------------------------------
	Read a persistent text property code for either an integer-valued property or a string-
	valued property.

	@param pb Reference to a pointer to the binary text property information.
----------------------------------------------------------------------------------------------*/
static int GetTextPropCode(const byte *& pb)
{
	byte bT = *pb++;
	int cbScp = TextProps::CbScpCode(bT);
	if (cbScp == 1)
		return bT;

	int scp;
	if (cbScp == 2)
	{
		scp = *pb++;
	}
	else if (cbScp == 5)
	{
		CopyBytes(pb, &scp, 4);
		pb += 4;
	}
	else
	{
		Assert(false);		// THIS SHOULD NEVER HAPPEN!
		ThrowHr(WarnHr(E_UNEXPECTED));
	}
	scp <<= 6;
	scp |= bT & 0x3F;
	return scp;
}

/*----------------------------------------------------------------------------------------------
	Read the length of the character string stored for a string-valued text property.

	@param pb Reference to a pointer to the binary text property information.
----------------------------------------------------------------------------------------------*/
static int GetStrPropLength(const byte *& pb)
{
	int cch = 0;
	byte bT = *pb++;
	int cbCch = !(bT & 0x80) ? 1 : (bT & 0x40) ? 4 : 2;
	if (cbCch == 1)
	{
		cch = bT;
	}
	else
	{
		if (cbCch == 2)
		{
			cch = *pb++;
		}
		else if (cbCch == 4)
		{
			CopyBytes(pb, &cch, 3);
			pb += 3;
		}
		else
		{
			Assert(false);		// THIS SHOULD NEVER HAPPEN!
			ThrowHr(WarnHr(E_UNEXPECTED));
		}
		cch <<= 6;
		cch |= bT & 0x3F;
	}
	return cch;
}

/*----------------------------------------------------------------------------------------------
	Scan the serialized style rule (vbRule) for the writing system wsOld.  If found, change the
	writing system to wsNew instead, and return true.  Otherwise, return false.

	NOTE: This method must be kept in sync with the FwStyledText functions.

	@param vbRule Reference to a byte vector containing the style rule.
	@param wsOld Language writing system code for runs that need to be changed in the style rule.
	@param wsNew New writing system value to use.
	@param pstrm IStream pointer for optional logging.

	@return True if the style rule has its writing system changed, otherwise false.
----------------------------------------------------------------------------------------------*/
bool LangProjPropWrtSys::ChangeStyleEnc(Vector<byte> & vbRule, int wsOld, int wsNew)
{
	Assert(sizeof(int) == 4);
	const byte * pb = vbRule.Begin();
	AssertPtr(pb);
	Assert(vbRule.Size() >= 2);

	int ctip = *pb++;
	int ctsp = *pb++;
	Assert((int)(byte)ctip == ctip);
	Assert((int)(byte)ctsp == ctsp);
	bool fEncChanged = false;
	int ws;
	if (ctip)
	{
		int scp;
		for (int itip = 0; itip < ctip; itip++)
		{
			scp = GetTextPropCode(pb);
			switch (TextProps::CbScpData(scp))
			{
			case 1:
				++pb;
				break;
			case 2:
				pb += 2;
				break;
			case 4:
				if (scp == kscpWs)
				{
					CopyBytes(pb, &ws, 4);
					if (ws == wsOld)
					{
						CopyBytes(&wsNew, const_cast<byte *>(pb), 4);
						fEncChanged = true;
					}
				}
				pb += 4;
				break;
			case 8:
				if (scp == kscpWsAndOws)
				{
					int ws;
					CopyBytes(pb, &ws, 4);
					if (ws == wsOld)
					{
						CopyBytes(&wsNew, const_cast<byte *>(pb), 4);
						fEncChanged = true;
					}
				}
				pb += 8;
				break;
			default:
				Assert(false);		// THIS SHOULD NEVER HAPPEN!
				break;
			}
		}
	}

	if (ctsp)
	{
		int tpt;
		int cch;
		for (int itsp = 0; itsp < ctsp; ++itsp)
		{
			tpt = GetTextPropCode(pb);
			cch = GetStrPropLength(pb);
			if (tpt == ktptWsStyle)
			{
				Vector<unsigned int> vws;
				Vector<int> vibOffsets;
				byte * pbMin = const_cast<byte *>(pb);

				const byte * pbLim = pb + cch * isizeof(wchar);
				while (pb < pbLim)
				{
					vibOffsets.Push(pb - pbMin);

					if (pbLim - pb < 12)
					{
						Assert(false);
						ThrowHr(WarnHr(E_UNEXPECTED));
					}
					// The writing system comes first for this type property.
					CopyBytes(pb, &ws, 4);
					if (ws == wsOld)
					{
						CopyBytes(&wsNew, const_cast<byte *>(pb), 4);
						fEncChanged = true;
						vws.Push(wsNew);
					}
					else
						vws.Push(ws);

					// Move past ws and ows.
					pb += 8;
					// Move past the font family.
					int cchFF = 0;
					CopyBytes(pb, &cchFF, 2);
					pb += 2 + cchFF * isizeof(wchar);
					if (pb >= pbLim)
						ThrowHr(WarnHr(E_FAIL));
					int cprop = 0;
					CopyBytes(pb, &cprop, 2);
					pb += 2;
					if (pbLim - pb < 8 * cprop)
					{
						Assert(false);
						ThrowHr(WarnHr(E_FAIL));
					}
					pb += cprop * 8;
				}

				// Now sort the writing system chunks based on the writing system ID.
				vibOffsets.Push(pb - pbMin);
				Vector<byte> vbEnc1;
				Vector<byte> vbEnc2;

				for (int iws1 = 0; iws1 < vws.Size() - 1; iws1++)
				{
					for (int iws2 = iws1 + 1; iws2 < vws.Size(); iws2++)
					{
						if (vws[iws1] > vws[iws2])
						{
							int cbEnc1 = vibOffsets[iws1 + 1] - vibOffsets[iws1];
							vbEnc1.Resize(cbEnc1);
							memcpy(vbEnc1.Begin(), pbMin + vibOffsets[iws1], cbEnc1);

							int cbEnc2 = vibOffsets[iws2 + 1] - vibOffsets[iws2];
							vbEnc2.Resize(cbEnc2);
							memcpy(vbEnc2.Begin(), pbMin + vibOffsets[iws2], cbEnc2);

							// how much to shift the intervening stuff by:
							int dbShift = cbEnc2 - cbEnc1;
							// how much intervening stuff there is:
							int cbShift = vibOffsets[iws2] - vibOffsets[iws1 + 1];
							byte * pbShiftFrom = pbMin + vibOffsets[iws1 + 1];
							byte * pbShiftTo = pbShiftFrom + dbShift;
							// shift intervening stuff
							memmove(pbShiftTo, pbShiftFrom, cbShift);
							// slide the swapped chunks into the their new slots
							memcpy(pbMin + vibOffsets[iws2] + dbShift, vbEnc1.Begin(), cbEnc1);
							memcpy(pbMin + vibOffsets[iws1], vbEnc2.Begin(), cbEnc2);

							unsigned int encSwap = vws[iws1];
							vws[iws1] = vws[iws2];
							vws[iws2] = encSwap;

							for (int iwsTmp = iws1 + 1; iwsTmp <= iws2; iwsTmp++)
								vibOffsets[iwsTmp] += dbShift;
						}
					}
				}
			}
			else
			{
				pb += cch * isizeof(wchar);
			}
		}
	}
	Assert(pb == vbRule.Begin() + vbRule.Size());

	return fEncChanged;
}


/*----------------------------------------------------------------------------------------------
	Handle window messages.

	@param wm windows message
	@param wp WPARAM
	@param lp LPARAM
	@param lnRet Value to be returned to the windows.
	@return true
----------------------------------------------------------------------------------------------*/
bool LangProjPropWrtSys::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
	if (wm == WM_ERASEBKGND)
	{
		// this is required to prevent the listview from not painting when selected then covered
		// by another window, then uncovered.  without this the listview will not repaint.
		RedrawWindow(m_hwndVernWrtSys, NULL , NULL, RDW_ERASE | RDW_FRAME | RDW_INTERNALPAINT |
			RDW_INVALIDATE);
		RedrawWindow(m_hwndAnalWrtSys, NULL , NULL, RDW_ERASE | RDW_FRAME | RDW_INTERNALPAINT |
			RDW_INVALIDATE);
	}
	return SuperClass::FWndProc(wm, wp, lp, lnRet);
}



//:>********************************************************************************************
//:> LangProjPropExtLnkTab methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
LangProjPropExtLnkTab::LangProjPropExtLnkTab(PropertiesDlg * ppropd)
{
	m_rid = kridLngPrjExtLnkDlg;
	m_ppropd = ppropd;
	m_fInitialized = false;
	m_pszHelpUrl = _T("DialogProjectPropertiesExterna.htm");
}


/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
bool LangProjPropExtLnkTab::Apply()
{
	AfLpInfo * plpi = m_ppropd->GetLangProjInfo();
	AssertPtr(plpi);

	IOleDbEncapPtr qode;
	IOleDbCommandPtr qodc;
	plpi->GetDbInfo()->GetDbAccess(&qode);
	AssertPtr(qode);
	CheckHr(qode->CreateCommand(&qodc));

	StrAppBuf strb;
	int cch = ::SendDlgItemMessage(m_hwnd, kridLngPrjExtLnkEdit, WM_GETTEXT, strb.kcchMaxStr,
		(LPARAM)strb.Chars());
	strb.SetLength(cch);
	StrUni stu(strb.Chars());

	StrUni stuFmt(L"update LanguageProject set ExtLinkRootDir = '%s'");
	StrUni stuSql;
	stuSql.Format(stuFmt.Chars(), stu.Chars());
	CheckHr(qodc->ExecCommand(stuSql.Bstr(), knSqlStmtNoResults));

	plpi->GetExtLinkRoot(true);

	return true;
}


/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
bool LangProjPropExtLnkTab::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	AfLpInfo * plpi = m_ppropd->GetLangProjInfo();
	AssertPtr(plpi);
	StrUni stuFolder = plpi->GetExtLinkRoot();
	StrAppBuf strb(stuFolder.Chars());
	::SendDlgItemMessage(m_hwnd, kridLngPrjExtLnkEdit, WM_SETTEXT, 0, (LPARAM)strb.Chars());

	m_fInitialized = true;

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}


/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
bool LangProjPropExtLnkTab::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (SuperClass::OnNotifyChild(ctidFrom, pnmh, lnRet))
		return true;

	switch (pnmh->code)
	{
	case BN_CLICKED:
		switch (ctidFrom)
		{
		case kridLngPrjExtLnkBrowse:
			{ // Block
				StrAppBuf strb;
				int cch = ::SendDlgItemMessage(m_hwnd, kridLngPrjExtLnkEdit, WM_GETTEXT,
					strb.kcchMaxStr, (LPARAM)strb.Chars());
				strb.SetLength(cch);
				if (FolderSelectDlg::ChooseFolder(m_hwnd, strb, kstidChooseExtLnk, _T("")))
				{
					::SendDlgItemMessage(m_hwnd, kridLngPrjExtLnkEdit, WM_SETTEXT, 0,
						(LPARAM)strb.Chars());
				}
			} // End block
			return true;
		}
	}

	return false;
}



//:>********************************************************************************************
//:> ChangeEncStringCrawler methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Scan the serialized string format (vbFmt) for runs in the writing system wsOld.  If any are
	found, change the run to use wsNew instead, and return true.  Otherwise, return false.

	@param vbFmt Reference to a byte vector containing the formatting information for the
					string.
	@param wsOld Language writing system code for runs that need to be changed in the string.
	@param wsNew New writing system value to use.
	@param pstrm IStream pointer for optional logging.

	@return True if one or more runs had their writing system changed, otherwise false.
----------------------------------------------------------------------------------------------*/
bool ChangeEncStringCrawler::ProcessBytes(Vector<byte> & vbFmt)
{
	Assert(sizeof(int) == 4);
	int * pn = reinterpret_cast<int *>(vbFmt.Begin());
	int crun = *pn++;
	int crunChg = 0;
	// 2 for char-min followed by prop offset
	int cbOffsets = isizeof(int) + (2 * crun * isizeof(int));
	int itip;
	int ctip;
	int ctsp;
	int irun;
	int ws;
	int scp;

	const byte * pbProp;
	const byte * pb;
	const byte * pbNext;
	Vector<int> vibProp;
	vibProp.Resize(crun);

	for (irun = 0; irun < crun; ++irun)
		vibProp[irun] = pn[2 * irun + 1];
	for (irun = 0; irun < crun; ++irun)
	{
		pbProp = vbFmt.Begin() + cbOffsets + vibProp[irun];
		pb = pbProp;
		ctip = *pb++;
		ctsp = *pb++;
		for (itip = 0; itip < ctip; ++itip)
		{
			scp = TextProps::DecodeScp(pb, vbFmt.End() - pb, &pbNext);
			if (scp == kscpWs || scp == kscpWsAndOws)
			{
				ws = *(reinterpret_cast<const int *>(pbNext));
				if (ws == m_wsOld)
				{
					byte * pbEnc = const_cast<byte *>(pbNext);
					*(reinterpret_cast<int *>(pbEnc)) = m_wsNew;
					++crunChg;
				}
			}
			switch (scp & 0x3)
			{
			case 0:
				pb = pbNext + 1;
				break;
			case 1:
				pb = pbNext + 2;
				break;
			case 2:
				pb = pbNext + 4;
				break;
			case 3:
				pb = pbNext + 8;
				break;
			}
		}
	}
	return (crunChg > 0);
}


#include "Vector_i.cpp"
#include "Set_i.cpp"


// Local Variables:
// mode:C++
// compile-command:"cmd.exe /e:4096 /c c:\\FW\\Bin\\MkCustomNb.bat"
// End: (These 4 lines are useful to Steve McConnel.)
