/*----------------------------------------------------------------------------------------------
Copyright 2001, SIL International. All rights reserved.

File: AfNewProj.h
Responsibility: Steve McConnel (based originally on ExNewLP.h by John Wimbish)
Last reviewed: never

Description:
	New Language Project Wizard Classes

		AfNewLanguageProjectWizard : AfWizardDlg
		AfNewProjIdentify : AfWizardPage
		AfNewProjVernacular : AfWizardPage
		AfNewProjAnalysis : AfWizardPage
		AfNewProjAnthroCodes : AfWizardPage

		AfEmptyNotebookDlg : AfDialog
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef AFNEWPROJ_H_INCLUDED
#define AFNEWPROJ_H_INCLUDED

/*----------------------------------------------------------------------------------------------
	This class provides the functionality of the wizard invoked for the File / New command,
	which creates a new language project.

	Hungarian: rnlp.
----------------------------------------------------------------------------------------------*/
class AfNewLanguageProjectWizard : public AfWizardDlg
{
typedef AfWizardDlg SuperClass;

public:
	AfNewLanguageProjectWizard() : AfWizardDlg()
	{
		m_lcid = 0;
		m_lgidAnal = LANG_ENGLISH;
		m_pszHelpUrl = _T("WizardCreateANewLanguageProjec.htm");
	}

	~AfNewLanguageProjectWizard()
	{
	}

	// Set the language name from the character array rgchName[cchName].
	void SetLanguageName(const achar * rgchName, int cchName)
	{
		m_strLanguageName.Assign(rgchName, cchName);
	}

	// Return a pointer to the language name character string.
	const achar * LanguageName()
	{
		return m_strLanguageName.Chars();
	}

	// Return a pointer to the database name character string.
	const wchar * DatabaseName()
	{
		return m_stuDbName.Chars();
	}

	// Return a pointer to the server name character string.
	const wchar * ServerName()
	{
		return m_stuServer.Chars();
	}

	// Return the Project hvo.
	HVO ProjLP()
	{
		return m_hvoLP;
	}

	// Set the language Ethnologue code from the character array rgchCode[cchCode].
	void SetEthCode(const achar * rgchCode, int cchCode)
	{
		m_strEthCode.Assign(rgchCode, cchCode);
	}

	// Return a pointer to the language Ethnologue code character string.
	const achar * EthCode()
	{
		return m_strEthCode.Chars();
	}

	// Set the locale id for the vernacular language writing system.
	void SetLocaleId(int lcid)
	{
		m_lcid = lcid;
	}

	// Return the locale id for the vernacular language writing system.
	int LocaleId()
	{
		return m_lcid;
	}

	// Set the "normal" font for displaying vernacular language text.
	void SetNormalFont(int isel)
	{
		m_strNormalFont = m_vstrFonts[isel];
	}

	// Return the name of the "normal" font for displaying vernacular language text.
	const StrApp & NormalFont()
	{
		return m_strNormalFont;
	}

	// Set the "heading" font for displaying vernacular language text.
	void SetHeadingFont(int isel)
	{
		m_strHeadingFont = m_vstrFonts[isel];
	}

	// Return the name of "heading" font for displaying vernacular language text.
	const StrApp & HeadingFont()
	{
		return m_strHeadingFont;
	}

	// Return a reference to a list of the fonts currently installed on the local system.
	Vector<StrApp> & FontList()
	{
		return m_vstrFonts;
	}

	// Return a handle to the menu used to select from among the currently installed language
	// locales.
	HMENU LanguageMenu()
	{
		return m_sll.GetLanguageMenu();
	}

	// Return a reference to a list of the language locales currently installed.
	SysLangInfo & InstalledLanguage(int iv)
	{
		Vector<SysLangInfo> & vsli = AfSystemLanguageList::GetLanguages();
		Assert((unsigned)iv < (unsigned)vsli.Size());
		return vsli[iv];
	}

	// Return the language id code for the analysis language.
	WORD AnalLang()
	{
		return m_lgidAnal;
	}

	// Set the language id code for the analysis language.
	void SetAnalLang(WORD lgid)
	{
		m_lgidAnal = lgid;
	}
	// Set the analysis language from the name given by the character array rgchName[cchName].
	void SetAnalLang(achar * rgchName, int cchName);

	// Return the language id code for the analysis language.
	int AnalLocale()
	{
		return m_lcidAnal;
	}

	// Set the locale id code for the analysis language.
	void SetAnalLocale(int lcid)
	{
		m_lcidAnal = lcid;
	}

	void SetInitializationXmlFile(const achar * pszBasename)
	{
		m_strXmlFile = pszBasename;
		if (pszBasename && *pszBasename)
			m_strXmlFile.Append(".xml");
	}

	// Store a pointer to the current frame window object.  This will be used for accessing
	// things like the status bar.
	void Initialize(AfMainWnd * pafw)
	{
		m_pafw = pafw;
	}

	// Return a pointer to the FieldWorks "template" directory character string.
	const achar * TemplateDir()
	{
		return m_strTemplateDir.Chars();
	}

	// Return a pointer to the FieldWorks "data" directory character string.
	const achar * DataDir()
	{
		return m_strDataDir.Chars();
	}

	void CreateNewLangProj();

protected:
//	virtual bool OnWizardNext();			// The user clicked on the Next button
//	virtual bool OnWizardBack();			// The user clicked on the Back button
//	virtual bool OnWizardFinish();			// The user clicked on the Finish btn
//	virtual bool OnCancel();				// Cancel btn was pressed

	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
//	virtual bool OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet);

	void GetAvailableFonts();

	StrApp m_strLanguageName;
	StrApp m_strEthCode;
	StrUni m_stuDbName;			// Name of new database.
	StrUni m_stuServer;			// Name of (local) server.
	HVO m_hvoLP;				// hvo of the Project.
	int m_lcid;					// Locale ID that best matches the Vernacular writing system.
	StrApp m_strNormalFont;		// Default font for vernacular writing system.
	StrApp m_strHeadingFont;	// Default heading font for vernacular writing system.
	WORD m_lgidAnal;
	int m_lcidAnal;				// When m_lgidAnal != one of the four standard choices.

	AfMainWnd * m_pafw;			// Points to application's frame window.
	Vector<StrApp> m_vstrFonts;
	AfSystemLanguageList m_sll;

	StrApp m_strTemplateDir;
	StrApp m_strDataDir;
	StrApp m_strXmlFile;
};

typedef GenSmartPtr<AfNewLanguageProjectWizard> AfNewLanguageProjectWizardPtr;

/*----------------------------------------------------------------------------------------------
	This class provides the page wherein the user identifies the language for which the new
	new project will be used.  The language name is shown in FieldWorks in one of the
	UI Writing Systems, and thus we can use a normal edit box for it.

	Hungarian: rnpi.
----------------------------------------------------------------------------------------------*/
class AfNewProjIdentify : public AfWizardPage
{
typedef AfWizardPage SuperClass;
public:
	AfNewProjIdentify() : AfWizardPage(kridWizProjPageIdentify)
	{
		m_hfontLarge = NULL;
	}
	~AfNewProjIdentify()
	{
		if (m_hfontLarge)
		{
			AfGdi::DeleteObjectFont(m_hfontLarge);
			m_hfontLarge = NULL;
		}
	}

protected:
//	virtual bool OnQueryCancel();			// Wanna cancel the Cancel btn action?
//	virtual bool OnCancel();				// Cancel btn was pressed
	virtual bool OnSetActive();				// This page is becoming active
//	virtual bool OnKillActive();			// Another page is becoming active
	virtual HWND OnWizardNext();			// The user has clicked on the Next btn
	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	virtual bool OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet);
	void SetNextEnbl();		// Enables or Disables the Next button.

	// Handle to a large font (16pt Sans Serif) used in the dialog display to get the user's
	// attention.
	HFONT m_hfontLarge;
};

typedef GenSmartPtr<AfNewProjIdentify> AfNewProjIdentifyPtr;

/*----------------------------------------------------------------------------------------------
	This class provides the page wherein the user chooses the basic vernacular writing system
	for the new language project.

	Hungarian: rnpv.
----------------------------------------------------------------------------------------------*/
class AfNewProjVernacular : public AfWizardPage
{
typedef AfWizardPage SuperClass;
public:
	AfNewProjVernacular() : AfWizardPage(kridWizProjPageVernacular)
	{
		m_hfontLarge = NULL;
	}
	~AfNewProjVernacular()
	{
		if (m_hfontLarge)
		{
			AfGdi::DeleteObjectFont(m_hfontLarge);
			m_hfontLarge = NULL;
		}
	}
protected:
//	virtual bool OnQueryCancel();			// Wanna cancel the Cancel btn action?
//	virtual bool OnCancel();				// Cancel btn was pressed
	virtual bool OnSetActive();				// This page is becoming active
//	virtual bool OnKillActive();			// Another page is becoming active
//	virtual HWND OnWizardBack();			// The user has clicked on the Back btn
	virtual HWND OnWizardNext();			// The user has clicked on the Next btn

	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	virtual bool OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet);

//	virtual bool CmdLangPopup(Cmd * pcmd);

	// Handle to a large font (16pt Sans Serif) used in the dialog display to get the user's
	// attention.
	HFONT m_hfontLarge;
	StrApp m_strChooseMsgFmt;	// Format string for "choose language" text.

//	CMD_MAP_DEC(AfNewProjVernacular);
};

typedef GenSmartPtr<AfNewProjVernacular> AfNewProjVernacularPtr;

/*----------------------------------------------------------------------------------------------
	This class provides the page wherein the user chooses the basic analysis writing system
	for the new language project.

	Hungarian: rnpa.
----------------------------------------------------------------------------------------------*/
class AfNewProjAnalysis : public AfWizardPage
{
typedef AfWizardPage SuperClass;
public:
	AfNewProjAnalysis() : AfWizardPage(kridWizProjPageAnalysis)
	{
		m_hfontLarge = NULL;
	}
	~AfNewProjAnalysis()
	{
		if (m_hfontLarge)
		{
			AfGdi::DeleteObjectFont(m_hfontLarge);
			m_hfontLarge = NULL;
		}
	}
protected:
//	virtual bool OnQueryCancel();			// Wanna cancel the Cancel btn action?
//	virtual bool OnCancel();				// Cancel btn was pressed
	virtual bool OnSetActive();				// This page is becoming active
	virtual bool OnKillActive();			// Another page is becoming active
//	virtual HWND OnWizardBack();			// The user has clicked on the Back btn
//	virtual bool OnWizardFinish();			// The user clicked on the Finish btn
	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	virtual bool OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet);

//	virtual bool CmdLangPopup(Cmd * pcmd);

	// Handle to a large font (16pt Sans Serif) used in the dialog display to get the user's
	// attention.
	HFONT m_hfontLarge;

//	CMD_MAP_DEC(AfNewProjAnalysis);
};

typedef GenSmartPtr<AfNewProjAnalysis> AfNewProjAnalysisPtr;


/*----------------------------------------------------------------------------------------------
//-	This class provides a dialog wherein the user chooses how to initialize the new language
//-	project.
//-
//-	Hungarian: rnpc.
----------------------------------------------------------------------------------------------*/
//-class AfNewProjAnthroCodes : public AfWizardPage
//-{
//-typedef AfWizardPage SuperClass;
//-public:
//-	AfNewProjAnthroCodes() : AfWizardPage(kridWizProjPageAnthroCodes)
//-	{
//-		m_hfontLarge = NULL;
//-	}
//-	~AfNewProjAnthroCodes()
//-	{
//-		if (m_hfontLarge)
//-		{
//-			AfGdi::DeleteObjectFont(m_hfontLarge);
//-			m_hfontLarge = NULL;
//-		}
//-	}
//-
//-protected:
//-//	virtual bool OnQueryCancel();			// Wanna cancel the Cancel btn action?
//-//	virtual bool OnCancel();				// Cancel btn was pressed
//-//	virtual bool OnSetActive();				// This page is becoming active
//-//	virtual bool OnKillActive();			// Another page is becoming active
//-//	virtual HWND OnWizardBack();			// The user has clicked on the Back btn
//-//	virtual bool OnWizardFinish();			// The user clicked on the Finish btn
//-	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
//-	virtual bool OnNotifyChild(int id, NMHDR * pnmh, long & lnRet);
//-
//-	// Handle to a large font (16pt Sans Serif) used in the dialog display to get the user's
//-	// attention.
//-	HFONT m_hfontLarge;
//-	Vector<StrApp> m_vstrXmlFiles;
//-};
//-
//-typedef GenSmartPtr<AfNewProjAnthroCodes> AfNewProjAnthroCodesPtr;

// Local Variables:
// mode:C++
// compile-command:"cmd.exe /e:4096 /c c:\\FW\\Bin\\MkCustomNb.bat"
// End: (These 4 lines are useful to Steve McConnel.)

#endif /*AFNEWPROJ_H_INCLUDED*/
