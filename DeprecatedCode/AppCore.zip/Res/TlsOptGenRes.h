/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TlsOptGenRes.h
Responsibility:
Last reviewed: never

Description:

-------------------------------------------------------------------------------*//*:End Ignore*/
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TlsOptGen.rc
//
#define kcidTlsOptGenModMnu             28300
#define kridTlsOptDlgGen                28301
#define kcidTlsOptDlgGenMsr             28302
#define kstidTlsOptGen                  28303
#define kstidTlsOptData                 28304
#define kcidTlsOptGenModNReq            28306
#define kcidTlsOptGenModEnc             28307
#define kcidTlsOptGenModReq             28308
#define kridModReqDlg                   28309
#define kcidTlsOptDlgGenFlds            28310
#define kstidTlosOptNotRequired         28311
#define kcidTlsOptDlgGenFIn             28312
#define kstidTlosOptEncouraged          28313
#define kstidTlosOptRequired            28314
#define kcidTlsOptDlgIcon				28315
#define kcidTlsOptDlgGenMod             28317

#define kridModFldNtcDlg                28319
#define kcidTlsOptDlgModReq             28320
#define kcidTlsOptDlgModEn              28321
#define kcidTlsOptDlgModNReq            28322
#define kcidTlsOptDlgGenFInL            28323
#define kstidTlosOptSubentries			28324

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2052
#define _APS_NEXT_COMMAND_VALUE         2100
#define _APS_NEXT_CONTROL_VALUE         2118
#define _APS_NEXT_SYMED_VALUE           401
#endif
#endif
