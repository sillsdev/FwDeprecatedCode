//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FmtParaDlg.rc
//
#define kridFmtParaDlg                  23300
#define kctidFpCbAlign                  23301
#define kctidFpCbBkgrnd                 23302
#define kctidFpEdIndLft                 23303
#define kctidFpSpIndLft                 23304
#define kctidFpEdIndRt                  23305
#define kctidFpSpIndRt                  23306
#define kctidFpCbSpec                   23307
#define kctidFpEdSpIndBy                23308
#define kctidFpSpSpIndBy                23309
#define kctidFpEdSpacBef                23310
#define kctidFpSpSpacBef                23311
#define kctidFpEdSpacAft                23312
#define kctidFpSpSpacAft                23313
#define kctidFpCbLineSpace              23314
#define kctidFpEdLineSpaceAt            23315
#define kctidFpSpLineSpaceAt            23316
#define kctidFpPreview                  23317
#define kctidFpCbDirection              23318
#define kstidFpAlignLeft                23340
#define kstidFpAlignCenter              23341
#define kstidFpAlignRight               23342
#define kstidFpSpecNone                 23343
#define kstidFpSpecHang                 23344
#define kstidFpSpecFirstLine            23345
#define kstidFpLsSingle                 23346
#define kstidFpLs15Lines                23347
#define kstidFpLsDouble                 23348
#define kstidFpLsAtLeast                23349
#define kstidFpLsExact                  23350
#define kstidFbPointsAbbr               23351
#define kstidFpInchAbbr                 23352
#define kstidFpUnspecified              23353
#define kridFmtParaDlgRtl               23354
#define kctidFpLtr                      23355
#define kctidFpRtl                      23356
#define kstidFpAlignLead                23357
#define kstidFpAlignTrail               23358
#define kctidFpLabelIndLft              23359
#define kctidFpLabelIndRt               23360
#define kstidFpLabelIndLeft             23361
#define kstidFpLabelIndRight            23362
#define kstidFpLabelIndLeading          23363
#define kstidFpLabelIndTrailing         23364
#define kstidFpEdLsAt                   23365
#define kstidFpEdSpIndBy                23366
#define kstidFpLsExactFmt               23367
#define kstidFpLsAtLeastFmt             23368
#define kstidLineSpacingFmt             23369
#define kstidLeadingFmt                 23370
#define kstidHangingFmt                 23371
#define kstidFirstLineFmt               23372
#define kstidTrailingFmt                23373
#define kstidBeforeFmt                  23374
#define kstidAfterFmt                   23375
#define kstidLeftToRight                23376
#define kstidRightToLeft                23377
#define kstidIndentColon                23378
#define kstidSpace                      23379
#define kstidFpAlignJustify             23380
#define kstidLtrInherited				23381
#define kstidLtrLeftToRight				23382
#define kstidLtrRightToLeft				23383

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         23365
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
