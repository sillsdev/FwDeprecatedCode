/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: FmtGenDlgRes.h
Responsibility:
Last reviewed: never

Description:

-------------------------------------------------------------------------------*//*:End Ignore*/
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FmtGenDlg.rc
//
#define kridFmtGenDlg                   23650
#define kctidFgEdName                   23651
#define kctidFgStyleType                23652
#define kctidFgCbBasedOn                23653
#define kctidFgCbParaNextStyle          23654
#define kctidFgEdShortcut               23655
#define kctidFgDescription              23656
#define kctidFgUnknown                  23657
//WARNING kridFmtGenDlgLim              23700


// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         23658
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
