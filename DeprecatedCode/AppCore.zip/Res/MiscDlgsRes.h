//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MiscDlgs.rc
//
#define kridChsrMergDlg                 23701
#define kctidChsrMergLabel              23702
#define kctidMergeTree                  23703
#define kstidChsrMergText               23704
#define kridMssngDtDlg                  23705
#define kctidMssngDtYes                 23706
#define kctidMssngDtNo                  23707
#define kctidMssngDtNoToAll             23708
#define kridDeleteDlg                   23709
#define kridDeleteObjDlg                23710
#define kctidDelDlgSelTxt               23711
#define kctidDelDlgObj                  23712
#define kctidDelObjBox                  23713
#define kctidDelObjTxt                  23714
#define kstidDelObjTxt                  23715
#define kstidDelObjDel                  23716
#define kridConfirmDeleteDlg            23717
#define kstidConfirmDeleteDlg           23718
#define kridConfirmDeleteIcon           23719
#define kcidConfirmDeleteMsg            23720
#define kstidConfirmDeleteMsg           23721

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        23790
#define _APS_NEXT_COMMAND_VALUE         23790
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
