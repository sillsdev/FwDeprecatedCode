//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TlsStatsDlg.rc
//
#define kdlgidTlsStats                  22700
#define kridTlsStatsDlg                 22700
#define kcidTlsStatsAdd                 22701
#define kcidTlsStatCopy                 22702
#define kcidTlsStatListCb               22703
#define kcidTlsStatList                 22704
#define kcidTlsStatOrderBy              22705
#define kcidTlsStatAsc                  22706
#define kcidTlsStatDesc                 22707
#define kcidTlsStatSub                  22708
#define kcidTlsStatAbbr                 22709
#define kcidTlsStatZero                 22710
#define kcidTlsStatShow                 22711
#define kcidTlsStatPrint                22712
#define kcidTlsStatClose                22713
#define kstidTlsStatCaption             22714
#define kstidTlsStatHeaderAbbr          22715
#define kstidTlsStatHeaderName          22716
#define kstidTlsStatHeaderCount         22717
#define kcidTlsStatGB                   22718
#define kstidTlsStatDefault				22719

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         22718
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
