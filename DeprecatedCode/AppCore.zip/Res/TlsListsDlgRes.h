/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TlsListsDlgRes.h
Responsibility:
Last reviewed: never

Description:

-------------------------------------------------------------------------------*//*:End Ignore*/
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TlsListsDlg.rc
//
#define kdlgidTlsLists                  25500
#define kridTlsListsDlg                 25500
#define kcidTlsListsAdd                 25501
#define kstidTlsListsGender             25502
#define kcidTlsListsCopy                25502
#define kcidTlsListsMod                 25503
#define kcidTlsListsDel                 25504
#define kcidTlsListsProp                25505
#define kcidTlsListsLst                 25507
#define kstidTlsListsCpyLst             25508
#define kstidTlsListsAddLst             25509
#define kstidTlsLstsDetails             25514
#define kstidTlsLstsList                25515
#define kstidTlsLstsItems               25516
#define kstidListsPropMsgCaption        25517
#define kstidTlsLstsNameExist           25518
#define kstidTlsLstsNameExistC          25519
#define kstidTlsListsDel				25520
#define kstidTlsListsDMsg				25521
#define kstidTlsListsNotDel				25522
#define kstidTlsListsNotDelMsg			25523

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         25510
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
