/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: LangDefPropDlgRes.h
Responsibility: Steve McConnel
Last reviewed: Not yet.

Description:
	Resource constant definitions for LangDefPropDlg.  Note that these must be in the range
	given by kridLangDefDlgMin and kridLangDefDlgLim in AfCoreRes.h (27000-27100), and must not
	conflict with those defined for AfNewLangDefWizard.
-------------------------------------------------------------------------------*//*:End Ignore*/
#ifndef LangDefPropDlgRes_H
#define LangDefPropDlgRes_H 1

#define kridLangDefPropDlg              27000
#define kctidLangDefName                27001
#define kctidLangDefCode                27002
#define kctidLangDefNormalFont          27003
#define kctidLangDefHeadingFont         27004
#define kctidLangDefLocale              27005
#define kctidLangDefKeymanSetup         27006
#define kcidLangDefLocaleMenu           27007
#define kstidLangDefMsgTitle            27010
#define kstidLangDefMissingName         27011
#define kstidLangDefBadEnc              27012

#endif /*LangDefPropDlgRes_H*/
