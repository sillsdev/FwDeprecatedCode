//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TlsOptCust.rc
//
#define kridTlsOptDlgCst                28100
#define kcidTlsOptDlgCstDfn             28101
#define kcidTlsOptDlgCstFld             28102
#define kcidTlsOptDlgCstAdd             28103
#define kcidTlsOptDlgCstDel             28104
#define kcidTlsOptDlgCstDes             28105
#define kcidTlsOptDlgCstTyp             28106
#define kcidTlsOptDlgCstLstcbo          28107
#define kcidTlsOptDlgCstLst             28108
#define kcidTlsOptDlgCstLimit           28109
#define kcidTlsOptDlgCstWS              28110
#define kstidTlsOptCust                 28111
#define kstidTlsOptCuMul                28112
#define kstidTlsOptCuOne                28113
#define kstidTlsOptCuAsc                28114
#define kstidTlsOptCuDes                28115
#define kstidTlsOptCuNSrt               28116
#define kcidTlsOptDlgCstCopy            28117

#define kstidTlsOptCTSingle             28120
#define kstidTlsOptCTInt                28122
#define kstidTlsOptCTDate               28123
#define kstidTlsOptCTLst                28124
#define kstidTlsOptCTTxt                28126
#define kstidTlsOptNewFld               28127
#define kcidTlsOptDlgCstHlp             28128

#define kstidTlsOptDlgCstDes            28130
#define kstidTlsOptDlgCstTyp            28131
#define kstidTlsOptDlgCstCap            28132
#define kstidTlsOptDlgCstWS             28133

#define kstidTlsOptDlgCstLstCap         28135
#define kstidTlsOptCpyFld               28136
#define kstidTlsOptCuDelDataA           28137
#define kstidTlsOptCuDelDataB           28138
#define kstidTlsOptCuDel                28139
#define kstidTlsOptCuDMsg               28140
#define kstidTlsOptCuDifLab             28141
#define kstidTlsOptCuDifLabCap          28142
#define kcidTlsOptDlgCstDfnCap          28143
#define kcidTlsOptDlgCstFldCap          28144


// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2052
#define _APS_NEXT_COMMAND_VALUE         2100
#define _APS_NEXT_CONTROL_VALUE         2119
#define _APS_NEXT_SYMED_VALUE           401
#endif
#endif
