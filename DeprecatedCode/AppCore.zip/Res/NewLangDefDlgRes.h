/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: NewLangDefDlgRes.h
Responsibility: Steve McConnel
Last reviewed: Not yet.

Description:
	Resource definitions for NewLangDefDlg.  These must be in the range given by
	kridLangDefDlgMin and kridLangDefDlgMin in AfCoreRes.h (27000-27100).
-------------------------------------------------------------------------------*//*:End Ignore*/
#ifndef NEWLANGDEFDLGRES_H
#define NEWLANGDEFDLGRES_H

#define kridNewLangPageIdentify                 27050
#define kridNewLangIdentifyPic                  27051
#define kridNewLangIdentifyTitle                27052
#define kctidNewLangIdentifyLanguage            27053
#define kctidNewLangIdentifyEthCode             27054
#define kstidNewLangIdentifyTitle               27055
#define kstidNewLangDefaultLanguage             27056
#define kstidNewLangDefaultEthCode              27057

#define kridNewLangPageSetup                    27058
#define kridNewLangSetupPic                     27059
#define kridNewLangSetupTitle                   27060
#define kcidNewLangLanguagePopupMenu            27061
#define kctidNewLangChooseLangText              27062
#define kctidNewLangChooseLang                  27063
#define kctidNewLangNormalFont                  27064
#define kctidNewLangHeadingFont                 27065
#define kctidNewLangKeymanText                  27066
#define kctidNewLangKeymanSetup                 27067
#define kstidNewLangSetupTitle                  27068
#define kstidNewLangChooseLangTextFmt           27069
#define kstidNewLangWizTitle                    27070
#define kstidEncAlreadyInListFmt                27071
#define kstidEncNoAlternativeFmt                27072
#define kstidLangAlreadyInListFmt               27073
#define kstidEncAlreadyInListTlt                27074
#define kstidLangAlreadyInListTlt               27075
#define kstidEncNoAlternativeTlt                27076
#endif /*NEWLANGDEFDLGRES_H*/
