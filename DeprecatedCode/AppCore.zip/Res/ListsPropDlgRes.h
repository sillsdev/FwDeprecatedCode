/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: ListsPropDlgRes.h
Responsibility:
Last reviewed: never

Description:

-------------------------------------------------------------------------------*//*:End Ignore*/
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ListsPropDlg.rc
//
#define kridDetailsPropDlg              25601
#define kstidListsDetails               25602
#define kctidDetailsPropTabSort         25603
#define kstidListsDetailsName           25604
#define kctidDetailsPropTabDup          25605
#define kstidListsDetailsAbbr           25606
#define kctidDetailsPropTabHeir         25607
#define kstidListsDetailsAN             25608
#define kctidDetailsPropTabAdv          25609
#define kctidDetailsPropTabDisp         25611
#define kridDetailsPropTabObjIcon       25612
#define kridDetailsPropTabBigName       25613
#define kctidDetailsPropTabAbbr         25614
#define kctidDetailsPropTabHelpF        25615
#define kctidDetailsPropTabBrws         25616
#define kstidOpenHelp                   25617
#define kctidDetailsPropTabWS           25618

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         25616
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
