/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: AfFindDlgRes.h
Responsibility:
Last reviewed: never

Description:

-------------------------------------------------------------------------------*//*:End Ignore*/
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AfFindDlg.rc
//
#define kridAfFindDlg                   27400
#define kridAfReplaceDlg                27401
#define kctidFindFindNow                27402
#define kctidFindClose                  27403
#define kctidFindMoreLess               27404
#define kctidFindWhat                   27405
#define kctidListResults                27406
#define kstidFindFmtWs                  27407
#define kstidFindFmtStyle				27408
#define kctidSetCurrentFilter           27409
#define kctidReplaceLabel               27410
#define kctidFindWhichEntries           27411
#define kctidFindFieldCheck             27412
#define kctidFindFieldCombo             27413
#define kctidFindMatchWholeWord         27414
#define kctidFindMatchCase              27415
#define kctidFindMatchDiacritics        27416
#define kctidFindSpecial                27417
#define kctidFindFormat                 27418
#define kctidSeparator                  27419
#define kctidFindAnimation              27420
#define kctidFindInBorder               27421
#define kctidWhichEntriesLabel          27422
#define kctidFindMatchWrtSys            27423
#define kctidFindReplace                27430
#define kctidFindReplaceAll             27431
#define kctidFindReplaceWith            27432
#define kctidFindTab                    27433
#define IDC_BUTTON1                     27434
#define kctidSearchOptionsLabel         27435
#define kcidFindFmtWs                   27450
#define kcidFindFmtStyle				27451
#define kstidMorePlain                  27480
#define kstidLessPlain                  27481
#define kstidFind                       27482
#define kstidReplace                    27483
#define kstidCloseButton                27484
#define kstidReplaceAll                 27485
#define kstidNoMatchesDoc               27486
#define kstidNoMatchesField             27487
#define kstidNoMoreMatches              27488
#define kstidReplaceNDoc                27489
#define kstidReplaceNField              27490
#define kstidNoFindMatch                27491
#define kridFindAnimation               27492
#define kridFindFmtMenu                 27493
#define kctidFindStop					27494
#define kridEmptyReplaceDlg             27495
#define kcidConfirmEmptyReplaceText     27496
#define kridConfirmReplaceIcon          27497
#define kstidReplaceErr					27498

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        27499
#define _APS_NEXT_COMMAND_VALUE         27451
#define _APS_NEXT_CONTROL_VALUE         27436
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
