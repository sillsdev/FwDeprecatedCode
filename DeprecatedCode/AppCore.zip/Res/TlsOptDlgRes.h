/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TlsOptDlgRes.h
Responsibility:
Last reviewed: never

Description:

-------------------------------------------------------------------------------*//*:End Ignore*/
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TlsOptDlg.rc
//
#define kridTlsOptDlg                   28200
#define kcidTlsOptDlgTab                28201
#define kstidTlsOptSubentries           28202
#define kstidCopy1                      28203
#define kstidCopyN                      28204
#define kcidPrevTab                     28205
#define kcidNextTab                     28206

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2052
#define _APS_NEXT_COMMAND_VALUE         2100
#define _APS_NEXT_CONTROL_VALUE         2118
#define _APS_NEXT_SYMED_VALUE           401
#endif
#endif
