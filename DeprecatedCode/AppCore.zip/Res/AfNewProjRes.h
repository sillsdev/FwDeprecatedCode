/*----------------------------------------------------------------------------------------------
Copyright 2001, SIL International. All rights reserved.

File: AfNewProjRes.h
Responsibility: Steve McConnel
Last reviewed: Not yet.

Description:
	Resource definitions for the New Language Project wizard.
----------------------------------------------------------------------------------------------*/

// Create New Language Project Wizard Pages

#define kridWizProjPageIdentify           22900
#define kridWizProjIdentifyPic            22901
#define kridWizProjIdentifyTitle          22902
#define kstidWizProjIdentifyTitle         22903
#define kctidWizProjIdentifyLanguage      22904
#define kctidWizProjIdentifyEthCode       22905
#define kstidWizProjDefaultLanguage       22906
#define kstidWizProjPredefLang            22907
#define kstidWizProjPredefEnc             22908

#define kridWizProjPageVernacular         22910
#define kridWizProjVernacularPic          22911
#define kridWizProjVernacularTitle        22912
#define kstidWizProjVernacularTitle       22913
#define kctidWizProjChooseLangText        22914
#define kstidWizProjChooseLangTextFmt     22915
#define kctidWizProjChooseLang            22916
#define kcidWizProjLanguagePopupMenu      22917
#define kctidWizProjNormalFont            22918
#define kctidWizProjHeadingFont           22919
#define kctidWizProjKeymanText            22920
#define kctidWizProjKeymanSetup           22921

#define kridWizProjPageAnalysis           22930
#define kridWizProjAnalysisPic            22931
#define kridWizProjAnalysisTitle          22932
#define kstidWizProjAnalysisTitle         22933
#define kctidWizProjAnalEnglish           22934
#define kctidWizProjAnalFrench            22935
#define kctidWizProjAnalSpanish           22936
#define kctidWizProjAnalPortuguese        22937
#define kctidWizProjAnalOther             22938
#define kctidWizProjAnalChoose            22939
#define kcidWizProjAnalPopupMenu          22940

//-#define kridWizProjPageAnthroCodes        22950
//-#define kridWizProjAnthroCodesPic         22951
//-#define kridWizProjAnthroCodesTitle       22952
//-#define kstidWizProjAnthroCodesTitle      22953
//-#define kctidWizProjAnthroOCMFrame        22954
//-#define kctidWizProjAnthroOCM             22955
//-#define kctidWizProjAnthroBlank           22956
//-#define kctidWizProjAnthroUseOther        22957
//-#define kctidWizProjAnthroOther           22958

#define kstidWizProjCaption               22970
#define kstidWizProjMsgCaption            22971
#define kstidWizProjCannotCopyLPDB        22973
#define kstidWizProjCopyStatusMsg         22974
#define kstidWizProjCannotAttach          22975
#define kstidWizProjCannotInit            22976
#define kstidWizProjInitializingFmt       22977
#define kstidWizProjProgStep1             22978
#define kstidWizProjProgStep2             22979
#define kstidWizProjProgStep3             22980
#define kstidWizProjNoInitFilesFmt        22981
#define kstidWizProjNoBlankFmt            22982
#define kstidWizProjError                 22983
#define kstidWizProjUnknownError          22984
#define kstidWizProjPredefEncTlt          22985
#define kstidWizProjPredefLangTlt         22986
#define kstidWizProjNameFmt               22987
//WARNING kridAfNewProjDlgLim             23000
