/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: FmtFntDlgRes.h
Responsibility:
Last reviewed: never

Description:

-------------------------------------------------------------------------------*//*:End Ignore*/
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FmtFntDlg.rc
//
#define kctidRfdFont                    23150
#define kctidRfdSize                    23151
#define kctidRfdForeClr                 23152
#define kctidRfdBackClr                 23153
#define kctidRfdUnder                   23154
#define kctidRfdUnderClr                23155
#define kctidRfdBold                    23156
#define kctidRfdItalic                  23157
#define kctidRfdSuper                   23158
#define kctidRfdSub                     23159
#define kctidRfdOffset                  23160
//WARNING kridRemFmtDlgLim				23200


#define kridFmtFntDlg                   23200
#define kctidFfdFont                    23201
#define kctidFfdBold                    23202
#define kctidFfdItalic                  23203
#define kctidFfdSuper                   23204
#define kctidFfdSize                    23205
#define kctidFfdForeClr                 23206
#define kctidFfdBackClr                 23207
#define kctidFfdUnderClr                23208
#define kctidFfdUnder                   23209
#define kctidFfdOffset                  23210
#define kctidFfdOffsetSpin              23211
#define kctidFfdOffsetNum               23212
#define kctidFfdSub                     23213
#define kctidFfdPreview                 23214
#define kctidFfdRemove                  23215
#define kstidFfdInherit                 23216
#define kstidFfdNone                    23217
#define kstidFfdEmpty                   23218
#define kstidFfdSuperscript             23219
#define kstidFfdSubscript               23220
#define kstidFfdRaise                   23221
#define kstidFfdLower                   23222
#define kstidFfdUnspecified             23223
#define kstidFfdDotted                  23224
#define kstidFfdDashed                  23225
#define kstidFfdSingle                  23226
#define kstidFfdDouble                  23227
#define kstidFfdNormal                  23228
#define kstidFfdRange                   23229
#define kstidLanguage                   23230
#define kstidDescription                23231
#define kstidBold                       23232
#define kstidItalic                     23233
#define kridRemFmtDlg                   23234
#define kstidTextOnFmt                  23235
#define kridAfStyleFntDlg               23236
#define kstidTextIsFmt                  23237
#define kctidAsfdFontList               23238
#define kctidAsfdLangList               23239
#define kstidSingleUnderFmt             23240
#define kstidDottedUnderFmt             23241
#define kstidDashedUnderFmt             23242
#define kstidDoubleUnderFmt             23243
#define kstidRaisedFmt                  23244
#define kstidLoweredFmt                 23245
#define kstidFeatureLabel				23246
#define kstidFeatureValueLabel			23247
#define kctidFfdFeatures				23248
#define kctidFfdFeatPopup				23249
#define kctidFfdPosLabel				23250
#define kctidFfdByLabel					23251
#define kstidFfdStrikethrough			23252
#define kstidStrikethroughUnderFmt		23253
#define kstidDefaultSettings			23254
//WARNING kridFmtFntDlgLim				23300

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         23255
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
