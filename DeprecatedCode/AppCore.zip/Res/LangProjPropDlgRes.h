/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: LangProjPropDlgRes.h
Responsibility: Steve McConnel
Last reviewed: Not yet.

Description:
	Resource constant definitions for LangProjPropDlg.  Note that these must be in the range
	given by kridProjPropsDlgMin and kridProjPropsDlgLim in AfCoreRes.h (27100-27200).
-------------------------------------------------------------------------------*//*:End Ignore*/
#ifndef LangProjPropDlgRes_H
#define LangProjPropDlgRes_H 1

#define kridLangProjPropDlg             27100
#define kcidLangProjPropDlgTab          27101
#define kstidLangProjPropDlgTab         27102
#define kstidLanguageProject            27104
#define kridLngPrjWrtSysDlg             27105
#define kstidLngPrjWrtSys               27106
#define kcidLngPrjVernWrtSysList        27107
#define kctidLngPrjAddVernWS            27108
#define kctidLngPrjModifyVernWS         27109
#define kctidLngPrjDeleteVernWS         27110
#define kctidLngPrjMoveUpVernWS         27111
#define kctidLngPrjMoveDownVernWS       27112
#define kcidLngPrjAnalWrtSysList        27113
#define kctidLngPrjAddAnalWS            27114
#define kctidLngPrjModifyAnalWS         27115
#define kctidLngPrjDeleteAnalWS         27116
#define kctidLngPrjMoveUpAnalWS         27117
#define kctidLngPrjMoveDownAnalWS       27118
#define kridLngPrjUpArrowPic            27119
#define kridLngPrjDownArrowPic          27120
#define kstidLangProjPropMsgCaption     27121
#define kcidLngPrjNewVernWS             27123
#define kcidLngPrjNewAnalWS             27124
#define kstidLngPrjContinueDelete       27125
#define kstidLngPrjContinueDeleteFmt2   27126
#define kstidLngPrjCannotDeleteLastAnal 27127
#define kstidLngPrjCannotDeleteLastVern 27128
#define kstidLngPrjNewWrtSys            27129
#define kstidLngPrjEncNotUnique         27130
#define kstidLngPrjEncWasUsed           27131
#define kstidLngPrjChangeEncQuestion    27132
#define kstidLngPrjNeedVernWs           27133
#define kstidLngPrjNeedActiveVernWs     27134
#define kstidLngPrjNeedAnalWs           27135
#define kstidLngPrjNeedActiveAnalWs     27136
#define kridGeneralPropertiesObjIcon	27137	// Enable's Cle application icon.
#define kridGeneralPropertiesNwIcon		27138

// NOT USED								27140
// NOT USED								27141
// NOT USED								27142
// NOT USED								27143
#define kstidLngPrjChangeEnc            27144
#define kstidLngPrjChgEncPhaseOne       27145
#define kstidLngPrjChgEncPhaseTwo       27146
#define kstidLngPrgChgEncPhaseThree		27147

#define kridLngPrjExtLnkDlg				27150
#define kridLngPrjExtLnkEdit			27151
#define kridLngPrjExtLnkBrowse			27152
#define kstidLngPrjExtLnk               27153
#define kstidChooseExtLnk				27154

#define kstidLngPrjEncForUI             27155

#endif /*LangProjPropDlgRes_H*/
