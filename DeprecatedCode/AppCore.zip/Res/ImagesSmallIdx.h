/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2002 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: ImagesSmallIdx.h
Responsibility:
Last reviewed: never

Description: Indices into the ImagesSmall.bmp

-------------------------------------------------------------------------------*//*:End Ignore*/

#define kridOpenProjFileDrawerClosed                2
#define kridOpenProjSearch                         44
#define kridOpenProjSubitem                        50

