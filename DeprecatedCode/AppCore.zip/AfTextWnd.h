/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 1999, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: AfTextWnd.h
Responsibility: Shon Katzenberger
Last reviewed:

	Implements a text editor window class.
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef AfTextWnd_H
#define AfTextWnd_H 1

// Forward declarations.
class AfTextWnd;
class FmtLineWnd;

/*----------------------------------------------------------------------------------------------
	For displaying and editing a rich text document.
	Hungarian: txtw.
----------------------------------------------------------------------------------------------*/
class AfTextWnd : public AfWnd
{
public:
	typedef AfWnd SuperClass;

	static void Create(AfTextWnd ** pptxtw);

	// The document.
	void SetDoc(RichTextDoc * prtd, uint grfdoc = kfdocInval);

	// Selection management.
	void TurnOffSel(void); // Makes the current selection invisible.
	void ShowSel(void); // Scrolls so the selection is in view.

	void GetSel(int * pichAnchor, int * pichOther);
	void SetSel(int ich1, int ich2);

	void Replace(int ich1, int ich2, const achar * prgch, int cch,
		uint grfdoc = kfdocInval);

	// Apply the indicated scalar character property to the current selection. If the selection
	// is empty, this affects the insertion properties.
	void ApplyCharPropSel(int scp, int nVal1, int nVal2 = knNinch, bool fDel = false);

	// Apply the indicated scalar paragraph property to the current selection.
	void ApplyParaPropSel(int scp, int nVal1, int nVal2 = knNinch, bool fDel = false);

	// Apply the indicated scalar property to the given range.
	void ApplyCharProp(int ichMin, int ichLim, int scp, int nVal1, int nVal2 = knNinch,
		bool fDel = false);
	void ApplyParaProp(int ichMin, int ichLim, int scp, int nVal1, int nVal2 = knNinch,
		bool fDel = false);

	// Apply the indicated scalar property list to the current selection.
	void ApplyCharPropsSel(const ScalarPropDelta * prgspd, int cspd);

	// Get the value of the indicated scalar character property for the current selection.
	// If the selection is empty, this gets the value from the insertion properties.
	bool FetchCharPropSel(int scp, int * pnVal1, int * pnVal2 = NULL, bool * pfConflict = NULL,
		int crunMax = 100);

	// Get the value of the indicated scalar paragraph property for the current selection.
	bool FetchParaPropSel(int scp, int * pnVal1, int * pnVal2 = NULL, bool * pfConflict = NULL,
		int crunMax = 100);

	// Get the value of the indicated scalar property for the given range.
	bool FetchCharProp(int ichMin, int ichLim, int scp, int * pnVal1, int * pnVal2 = NULL,
		bool * pfConflict = NULL, int crunMax = 100);
	bool FetchParaProp(int ichMin, int ichLim, int scp, int * pnVal1, int * pnVal2 = NULL,
		bool * pfConflict = NULL, int crunMax = 100);

	// Get the LgCharRenderProps of the current selection. Values that vary over the selection
	// are filled with ninch. This also fills in the base character properties over the same
	// range. The base properties are those derived from the view defaults with the paragraph
	// and character styles applied. This is used for the format/font dialog.
	void FetchChrpSel(LgCharRenderProps & chrp, LgCharRenderProps & chrpBase);

	int IchMac(void);
	void FetchChrp(int ich, LgCharRenderProps & chrp, int * pichMin, int * pichLim);
	void FetchParp(int ich, LgParaRenderProps & parp, int * pichMin, int * pichLim);
	void FetchRgch(int ichMin, int ichLim, achar * prgch);
	achar ChFetch(int ich);

	bool FMinPara(int ich);
	int IchMinPara(int ich);
	int IchLimPara(int ich);
	int IchPrev(int ich, bool fWord = false);
	int IchNext(int ich, bool fWord = false);
	int IchPropIns(int ich1, int ich2);

protected:
	// Minimum document width is 1 inch.
	enum { kdxmpDocMin = 72000 };

	class EditSink : public TextEditSink
	{
	public:
		AfTextWnd * m_ptxtw; // No ref count.

		EditSink(void)
		{
			m_ptxtw = NULL;
		}

		virtual void Edit(RichTextDoc * prtd, int ichMin, int ichLim, int cchIns, uint grfdoc)
		{
			if (m_ptxtw)
				m_ptxtw->OnEdit(prtd, ichMin, ichLim, cchIns, grfdoc);
		}
	};
	friend class EditSink;
	EditSink m_esk;

	// For formatting lines of text.
	friend class FmtLineWnd;
	FmtLineWnd * m_pfli;

	// Line information.
	struct DispLine
	{
		int ichMin; // The ich of the first character in this line.
		int dysTot; // The total height of lines up to this line.
		int cch; // Number of characters on this line.
		int dys; // Height of this line.
		int dysAscent; // Ascent of this line.
	};
	Vector<DispLine> m_vlin;

	// The dc for this window. This dc defines the destination coordinates (xd, yd, zd), except
	// when printing.
	HDC m_hdcWnd;
	// Pixel (window) coordinates. The width and height of this are the number of pixels
	// per inch. The top - left is (0, 0).
	Rect m_rcp;

	// The dc to use for formatting. This may be a printer dc or a screen dc. Nothing
	// should be drawn to this dc. This dc defines the source coordinate system (xs, ys, zs).
	HDC m_hdcFmt;
	// Source coordinates. The width and height of this are the number of pixels per inch.
	// The top-left is correlated with the current scroll values.
	Rect m_rcs;

	// The first line and character that are displayed. These are correlated with m_rcs.top,
	// which should in generally be equal to -m_vlin[m_ilinDisp].dysTot.
	int m_ilinDisp;
	int m_ichDisp;

	// DispLines from here on have wrong ichMin and dympTot values.
	int m_ilinInval;

	RichTextDocPtr m_qrtd;
	int m_dxmpDoc; // Document width (for line breaking, etc).

	bool m_fSelOn; // Whether the selection has been drawn.
	bool m_fXdSelValid; // Whether m_xdSel is valid.
	int m_ichAnchor; // The anchor point of the selection.
	int m_ichOther; // The other end (floating end) of the selection.
	ulong m_tsSel;
	int m_xdSel;

	COLORREF m_clrFore;
	COLORREF m_clrBack;

	// The insertion properties.
	bool m_fValidProps;
	bool m_fLockProps;
	// REVIEW ShonK: Should we use a TextPropGroupGrow?
	TextPropGroup m_tpgIns;

	AfTextWnd(void);
	~AfTextWnd(void);

	void Init(void);
	virtual void CreateFmtLine(void);
	virtual void PostAttach(void);
	virtual void DetachHwnd(HWND hwnd);

	// Invalidate the given rectangle.
	void InvalRect(Rect * prc, uint grfdoc = kfdocInval)
	{
		// TODO ShonK: fix this.
		if (m_hwnd)
			::InvalidateRect(m_hwnd, prc, false);
	}
	void SwitchSel(bool fOn);
	void InvertSel(HDC hdc);
	void FetchCharPropsIns(int ich1, int ich2);
	void EnsureCharPropsIns(void)
	{
		if (!m_fValidProps)
			FetchCharPropsIns(m_ichAnchor, m_ichOther);
	}
	void GetBoundsFromIch(int ich, Rect & rcp, int * pypBase = NULL);
	int XpFromIch(int ich, DispLine & lin);
	int IchFromXp(int xp, DispLine & lin, bool fClosest);
	int IchFromPt(int xp, int yp, bool fClosest);
	void InvertRange(HDC hdc, int ich1, int ich2);
	void FetchBaseChrp(int ich, LgCharRenderProps & chrp, int * pichMin, int * pichLim);
	void FetchBaseParp(int ich, LgParaRenderProps & parp, int * pichMin, int * pichLim);

	void DrawLines(HDC hdc, int dxpInch, int dypInch, int xp, int yp,
		const Rect & rcpClip, int ilinMin, int ilinLim);
	void Draw(HDC hdc, const Rect & rcpClip);
	void ReformatAndDraw(int ichMin, int ichLimDel, int cchIns);
	void Reformat(int ichMin, int ichLimDel, int cchIns, int * pyr, int * pdyrDel,
		int * pdyrIns);
	void FetchLine(int ilin, DispLine * plin, int * pilinActual = NULL);
	void CalcLine(int ichMin, int dysBase, DispLine * plin);
	int IchFromLine(int ilin);
	int IlinFromIch(int ich);
	void FindIch(int ichFind, DispLine * plin, int * pilin = NULL,
		bool fCalcLines = true);
	void FindYp(int ypFind, DispLine * plin, int * pilin = NULL, bool fCalcLines = true);
	void FormatLine(int ichMin, int ichLim, bool fUseAll = false);

	void OnEdit(RichTextDoc * prtd, int ichMin, int ichLim, int cchIns, uint grfdoc);

	/*------------------------------------------------------------------------------------------
		Message handling.
	------------------------------------------------------------------------------------------*/
	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);

	virtual bool OnPaint(HDC hdcDef);
	virtual bool OnChar(achar ch, WPARAM wp, LPARAM lp);
	virtual bool OnKey(int vk, uint grfmst, LPARAM lp);
	virtual bool OnMouseDown(uint grfmk, int xp, int yp);
	virtual bool OnMouseMove(uint grfmk, int xp, int yp);
	virtual bool OnMouseUp(uint grfmk, int xp, int yp);

	/*------------------------------------------------------------------------------------------
		Command handling.
	------------------------------------------------------------------------------------------*/
	virtual bool CmdSelIdle(Cmd * pcmd);

	CMD_MAP_DEC(AfTextWnd);
};

typedef GenSmartPtr<AfTextWnd> AfTextWndPtr;


/*----------------------------------------------------------------------------------------------
	Format line class specific to AfTextWnd.
----------------------------------------------------------------------------------------------*/
class FmtLineWnd : public FmtLineBase
{
protected:
	AfTextWnd * m_ptxtw; // No reference count.

	virtual void FetchChrp(int ich, LgCharRenderProps & chrp, int * pichMin = NULL,
		int * pichLim = NULL)
	{
		AssertPtr(m_ptxtw);
		m_ptxtw->FetchChrp(ich, chrp, pichMin, pichLim);
	}

	virtual void FetchParp(int ich, LgParaRenderProps & parp, int * pichMin = NULL,
		int * pichLim = NULL)
	{
		AssertPtr(m_ptxtw);
		m_ptxtw->FetchParp(ich, parp, pichMin, pichLim);
	}

	virtual int IchMac(void)
	{
		AssertPtr(m_ptxtw);
		return m_ptxtw->IchMac();
	}

	virtual void FetchRgch(int ichMin, int ichLim, achar * prgch)
	{
		AssertPtr(m_ptxtw);
		m_ptxtw->FetchRgch(ichMin, ichLim, prgch);
	}

	virtual achar ChFetch(int ich)
	{
		AssertPtr(m_ptxtw);
		return m_ptxtw->ChFetch(ich);
	}

	virtual bool FMinPara(int ich)
	{
		AssertPtr(m_ptxtw);
		return m_ptxtw->FMinPara(ich);
	}

	virtual int IchPrev(int ich)
	{
		AssertPtr(m_ptxtw);
		return m_ptxtw->IchPrev(ich);
	}

	virtual int IchNext(int ich)
	{
		AssertPtr(m_ptxtw);
		return m_ptxtw->IchNext(ich);
	}

public:
	virtual void SetWnd(AfTextWnd * ptxtw)
	{
		m_ptxtw = ptxtw;
		Clear();
	}
};

#endif // !AfTextWnd_H

