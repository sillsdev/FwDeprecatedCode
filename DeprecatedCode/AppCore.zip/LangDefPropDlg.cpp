/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: LangDefPropDlg.cpp
Responsibility: Steve McConnel (Sharon Correll?)
Last reviewed: Not yet.

Description:
	Implementation of the Language Definition Properties Dialog class.

	TODO: Handle encoding converters (and their descriptions?).
----------------------------------------------------------------------------------------------*/
//****************************************************************************************
// ALL OF THE LOGIC HERE MUST CHANGE RADICALLY!!!
//****************************************************************************************

#include "Main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE
//:End Ignore

BEGIN_CMD_MAP(LangDefPropDlg)
	ON_CID_CHILD(kcidLangDefLocaleMenu, &LangDefPropDlg::CmdLocalePopup, NULL)
END_CMD_MAP_NIL()

//:>********************************************************************************************
//:>	Language Definition Properties dialog class methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
LangDefPropDlg::LangDefPropDlg()
{
	m_rid = kridLangDefPropDlg;
	m_pszHelpUrl = _T("DialogLanguageDefinitionProper.htm");
}

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
LangDefPropDlg::~LangDefPropDlg()
{
}

/*----------------------------------------------------------------------------------------------
	Initialize the dialog in response to the WM_INITDIALOG message.
	All one-time initialization should be done here (that is, all controls have been created
	and have valid hwnd's, but they need initial values.)

	@param hwndCtrl Not used by this method.
	@param lp Not used by this method.

	@return True.
----------------------------------------------------------------------------------------------*/
bool LangDefPropDlg::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	HWND hwnd;
	StrApp str;
	int ie;

	// Language name.
	hwnd = ::GetDlgItem(m_hwnd, kctidLangDefName);
	::SetWindowText(hwnd, m_strName.Chars());
	// Ethnologue code.
	// THIS WILL ALL CHANGE MASSIVELY -- PERHAPS THE ICU Locale WILL BE SHOWN HERE?
	hwnd = ::GetDlgItem(m_hwnd, kctidLangDefCode);
	if (m_ws)
	{
		SmartBstr sbstrWs;
		CheckHr(m_qwsf->GetStrFromWs(m_ws, &sbstrWs));
		if (sbstrWs)
			str.Assign(sbstrWs.Chars(), sbstrWs.Length());
	}
	::SetWindowText(hwnd, str.Chars());
	::SendMessage(hwnd, EM_LIMITTEXT, 5, 0);
	// Normal Font (combobox list).
	hwnd = ::GetDlgItem(m_hwnd, kctidLangDefNormalFont);
	for (ie = 0; ie < m_vstrFonts.Size(); ++ie)
		::SendMessage(hwnd, CB_ADDSTRING, 0, (LPARAM)m_vstrFonts[ie].Chars());
	::SendMessage(hwnd, CB_SETCURSEL, m_istrNormalFont, 0);
	// Heading Font (combobox list).
	hwnd = ::GetDlgItem(m_hwnd, kctidLangDefHeadingFont);
	for (ie = 0; ie < m_vstrFonts.Size(); ++ie)
		::SendMessage(hwnd, CB_ADDSTRING, 0, (LPARAM)m_vstrFonts[ie].Chars());
	::SendMessage(hwnd, CB_SETCURSEL, m_istrHeadingFont, 0);

	// Subclass the "Choose..." button.
	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidLangDefLocale, kbtPopMenu, NULL, 0);
	hwnd = ::GetDlgItem(m_hwnd, kctidLangDefLocale);
	if (m_lcid)
	{
		StrApp str(AfSystemLanguageList::GetLanguageName(m_lcid));
		if (str.Length())
			::SetWindowText(hwnd, str.Chars());
	}

	// Subclass the Help button.
	AfButtonPtr qbtn2;
	qbtn2.Create();
	qbtn2->SubclassButton(m_hwnd, kctidHelp, kbtHelp, NULL, 0);

	// TODO (Version 2?): Add explicit handling for KeyMan setup.
	::ShowWindow(::GetDlgItem(m_hwnd, kctidLangDefKeymanSetup), SW_HIDE);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	This method is called by the framework when the user chooses the OK or the Apply Now button.
	When the framework calls this method, changes made in the dialog are accepted.
	The default OnApply closes the dialog.

	@param fClose not used here

	@return True if successful.
----------------------------------------------------------------------------------------------*/
bool LangDefPropDlg::OnApply(bool fClose)
{
	HWND hwnd;
	StrApp strTitle(kstidLangDefMsgTitle);
	StrApp strMsg;
	// Get the language name as edited by the user.
	hwnd = ::GetDlgItem(m_hwnd, kctidLangDefName);
	achar rgch[MAX_PATH];
	int cch = ::GetWindowText(hwnd, rgch, isizeof(rgch) / isizeof(achar));
	int ichFirst;
	int ichLim;
	for (ichFirst = 0; ichFirst < cch; ++ichFirst)
	{
		if (rgch[ichFirst] != ' ')
			break;
	}
	for (ichLim = cch; ichLim > ichFirst; --ichLim)
	{
		if (rgch[ichLim - 1] != ' ')
			break;
	}
	cch = ichLim - ichFirst;
	if (cch == 0)
	{
		// Empty name (or all spaces).
		strMsg.Load(kstidLangDefMissingName);
		::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(),
			MB_OK | MB_ICONWARNING | MB_APPLMODAL);
		return false;
	}
	m_strName.Assign(rgch + ichFirst, cch);

	// This should be an ICU locale identifier string.
	hwnd = ::GetDlgItem(m_hwnd, kctidLangDefCode);
	cch = ::GetWindowText(hwnd, rgch, isizeof(rgch) / isizeof(achar));
	StrUni stuNewWs(rgch, cch);
	SmartBstr sbstrOrigWs;
	CheckHr(m_qwsf->GetStrFromWs(m_ws, &sbstrOrigWs));

	// Don't allow change to an existing value used for another language.
	if (stuNewWs != sbstrOrigWs.Chars())
	{
		int wsNew = 0;
		HRESULT hr;
		CheckHr(hr = m_qwsf->GetWsFromStr(stuNewWs.Bstr(), &wsNew));
		SmartBstr sbstrName;
		StrApp strWsOld(sbstrOrigWs.Chars(), sbstrOrigWs.Length());
		StrApp strWsNew(stuNewWs);
		StrApp strMsg;
		if (hr == S_OK || wsNew)
		{
		// "Cannot change writing system %<0>s to %<1>s because %<1>s is already used for %<2>s"
			StrApp strFmt(kstidLngPrjEncNotUnique);
			strMsg.Format(strFmt.Chars(), strWsOld.Chars(), strWsNew.Chars(),
				m_strName.Chars());
			::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(), MB_OK | MB_ICONINFORMATION);
			::SetFocus(hwnd);
			return false;
		}
		int wsUser;
		CheckHr(m_qwsf->get_UserWs(&wsUser));
		if (m_ws == wsUser)
		{
			// "Cannot change writing system %<0>s to %<1>s because %<0>s is the User Interface writing system."
			StrApp strFmt(kstidLngPrjEncForUI);
			strMsg.Format(strFmt.Chars(), strWsOld.Chars(), strWsNew.Chars());
			::MessageBox(NULL, strMsg.Chars(), strTitle.Chars(), MB_OK | MB_ICONINFORMATION);
			return false;
		}
	}

	// The locale id selected by the user is kept up to date in CmdLocalePopup().
	// Get the normal font selected by the user.
	hwnd = ::GetDlgItem(m_hwnd, kctidLangDefNormalFont);
	m_istrNormalFont = ::SendMessage(hwnd, CB_GETCURSEL, 0, 0);
	// Get the heading font selected by the user.
	hwnd = ::GetDlgItem(m_hwnd, kctidLangDefHeadingFont);
	m_istrHeadingFont = ::SendMessage(hwnd, CB_GETCURSEL, 0, 0);

	return SuperClass::OnApply(fClose);
}

/*----------------------------------------------------------------------------------------------
	Handle the Cancel button.

	@return True if successful.
----------------------------------------------------------------------------------------------*/
bool LangDefPropDlg::OnCancel()
{
	return SuperClass::OnCancel();
}

/*----------------------------------------------------------------------------------------------
	Handle a WM_NOTIFY message, first letting the superclass method handle it if possible.

	@param ctidFrom Identifies the control sending the message.
	@param pnmh Pointer to the notification message data.
	@param lnRet Reference to a long integer return value used by some messages.

	@return True if the message is handled successfully; otherwise, false.
----------------------------------------------------------------------------------------------*/
bool LangDefPropDlg::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (SuperClass::OnNotifyChild(ctidFrom, pnmh, lnRet))
		return true;

	switch (pnmh->code)
	{
	case BN_CLICKED:
		if (ctidFrom == kctidLangDefLocale)
		{
			// Show the popup menu that allows a user to choose the language.
			Rect rc;
			::GetWindowRect(::GetDlgItem(m_hwnd, kctidLangDefLocale), &rc);
			AfApp::GetMenuMgr()->SetMenuHandler(kcidLangDefLocaleMenu);
			::TrackPopupMenu(m_sll.GetLanguageMenu(), TPM_LEFTALIGN | TPM_RIGHTBUTTON,
				rc.left, rc.bottom, 0, m_hwnd, NULL);
			return true;
		}
		else if (ctidFrom == kctidLangDefKeymanSetup)
		{
			// TODO (Version 2?): Add explicit handling for KeyMan setup.
		}
		break;

	case EN_CHANGE:
		switch(ctidFrom)
		{
			case kctidLangDefCode:
			{
				StrAppBuf strb;
				int cch;
				cch = ::SendMessage (pnmh->hwndFrom, WM_GETTEXT, strb.kcchMaxStr,
					(LPARAM)strb.Chars());
				strb.SetLength(cch);

				achar rgch[100];
				_tcscpy(rgch, strb.Chars());
				StrApp strEth(_T(""));
				bool fInvalid = false;
				for (int i = 0; i < 5; ++i)
				{
					if (i == cch)
						break;
					if (i < 3)
					{
						if ((rgch[i] >='A' && rgch[i] <='Z'))
								strEth.Append(rgch + i, 1);
						else
						{
							fInvalid = true;
							::MessageBeep(MB_ICONEXCLAMATION);
							break;
						}
					}
					else if (i < 5)
					{
						if ((rgch[i] >='0' && rgch[i] <='9'))
							strEth.Append(rgch + i, 1);
						else
						{
							fInvalid = true;
							::MessageBeep(MB_ICONEXCLAMATION);
							break;
						}
					}
					else if (i == 5)
					{
						fInvalid = true;
						::MessageBeep(MB_ICONEXCLAMATION);
						break;
					}

				}
				if (fInvalid)
				{
					::SendMessage(pnmh->hwndFrom, WM_SETTEXT, 0, (LPARAM)strEth.Chars());
					::SendMessage(pnmh->hwndFrom, EM_SETSEL, (WPARAM)strEth.Length(),
						(LPARAM)-1);
				}
			}
		}
		break;
	}
	return false;
}


/*----------------------------------------------------------------------------------------------
	Initialize the values edited by this dialog.

	@param pwsf 
	@param ws Language writing system code.
	@param stuName Name of the language.
	@param lcid MS Windows locale id for this language.
	@param stuNormalFont Name of the font used for normal text.
	@param stuHeadingFont Name of the font used for headings.
	@param stuEncodingConverter 
	@param stuEncodingConvDesc 
	@param pvwsdCurrent 
----------------------------------------------------------------------------------------------*/
void LangDefPropDlg::Initialize(ILgWritingSystemFactory * pwsf, int ws, StrUni & stuName,
	int lcid, StrUni & stuNormalFont, StrUni & stuHeadingFont, StrUni & stuEncodingConverter,
	StrUni & stuEncodingConvDesc, Vector<WrtSysData> * pvwsdCurrent)
{
	AssertPtr(pwsf);

	m_qwsf = pwsf;
	m_ws = ws;
	m_strName = stuName;
	m_lcid = lcid;
	m_pvwsdCurrent = pvwsdCurrent;
	m_strEncodingConverter = stuEncodingConverter;
	m_strEncodingConvDesc = stuEncodingConvDesc;

	// Get the currently available fonts via the LgFontManager.
	ILgFontManagerPtr qfm;
	SmartBstr bstrNames;
	qfm.CreateInstance(CLSID_LgFontManager);
	CheckHr(qfm->AvailableFonts(&bstrNames));
	StrApp strNameList;
	strNameList.Assign(bstrNames.Bstr(), BstrLen(bstrNames.Bstr()));
	int cchLength = strNameList.Length();
	StrApp strName; // Individual font name.
	StrApp strNormalFont(stuNormalFont);
	StrApp strHeadingFont(stuHeadingFont);
	m_istrNormalFont = -1;
	m_istrHeadingFont = -1;
	int ichMin = 0; // Index of the beginning of a font name.
	int ichLim = 0; // Index that is one past the end of a font name.
	// Add each font name to the vector of names.
	while (ichLim < cchLength)
	{
		ichLim = strNameList.FindCh(L',', ichMin);
		if (ichLim == -1) // i.e., if not found.
		{
			ichLim = cchLength;
		}
		strName.Assign(strNameList.Chars() + ichMin, ichLim - ichMin);
		if (strName == strNormalFont)
			m_istrNormalFont = m_vstrFonts.Size();
		if (strName == strHeadingFont)
			m_istrHeadingFont = m_vstrFonts.Size();
		m_vstrFonts.Push(strName);
		ichMin = ichLim + 1;
	}
	if (m_istrNormalFont == -1)
	{
		m_istrNormalFont = m_vstrFonts.Size();
		m_vstrFonts.Push(strNormalFont);
	}
	if (m_istrHeadingFont == -1)
	{
		if (strNormalFont == strHeadingFont)
		{
			m_istrHeadingFont = m_istrNormalFont;
		}
		else
		{
			m_istrHeadingFont = m_vstrFonts.Size();
			m_vstrFonts.Push(strHeadingFont);
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Handle a popup menu command for choosing the desired locale/language.

	@param pcmd Pointer to the command information.

	@return True.
----------------------------------------------------------------------------------------------*/
bool LangDefPropDlg::CmdLocalePopup(Cmd * pcmd)
{
	AssertPtr(pcmd);
	Assert(pcmd->m_rgn[0] == AfMenuMgr::kmaDoCommand);

	// The user selected an expanded menu item, so perform the command now.
	//    m_rgn[1] holds the menu handle.
	//    m_rgn[2] holds the index of the selected item.
	int ilang = pcmd->m_rgn[2];
	Vector<SysLangInfo> & vsli = AfSystemLanguageList::GetLanguages();
	::SetWindowText(::GetDlgItem(m_hwnd, kctidLangDefLocale), vsli[ilang].m_strName.Chars());
	m_lcid = vsli[ilang].m_lcid;
	return true;
}
