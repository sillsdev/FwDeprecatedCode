/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: LangDefPropDlg.h
Responsibility: Steve McConnel
Last reviewed: never

Description:
	Manages a dialog to allow editing a language definition, both writing system and old writing system.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef LANGDEFPROPDLG_H_INCLUDED
#define LANGDEFPROPDLG_H_INCLUDED 1
//:End Ignore

/*----------------------------------------------------------------------------------------------
	Language Definition Properties Dialog class.

	Hungarian: ldpd
----------------------------------------------------------------------------------------------*/
class LangDefPropDlg : public AfDialog
{
	typedef AfDialog SuperClass;

public:
	LangDefPropDlg();
	~LangDefPropDlg();

	// Return a pointer to the language name character string.
	const achar * LanguageName()
	{
		return m_strName.Chars();
	}

	// Return a pointer to the encoded language Ethnologue code.
	int EthCode()
	{
		return m_ws;
	}

	// Return the locale id for the vernacular language writing system.
	int LocaleId()
	{
		return m_lcid;
	}

	// Return the name of the "normal" font for displaying vernacular language text.
	const achar * NormalFont()
	{
		Assert((unsigned)m_istrNormalFont < (unsigned)m_vstrFonts.Size());
		return m_vstrFonts[m_istrNormalFont].Chars();
	}

	// Return the name of "heading" font for displaying vernacular language text.
	const achar * HeadingFont()
	{
		Assert((unsigned)m_istrHeadingFont < (unsigned)m_vstrFonts.Size());
		return m_vstrFonts[m_istrHeadingFont].Chars();
	}

	// Return a pointer to the encoding converter name string.
	const achar * EncodingConverter()
	{
		return m_strEncodingConverter.Chars();
	}

	// Return a pointer to the encoding converter description string.
	const achar * EncodingConvDesc()
	{
		return m_strEncodingConvDesc.Chars();
	}

	void Initialize(ILgWritingSystemFactory * pwsf, int ws, StrUni & stuName, int lcid,
		StrUni & stuNormalFont, StrUni & stuHeadingFont, StrUni & stuEncodingConverter,
		StrUni & stuEncodingConvDesc, Vector<WrtSysData> * pvwsdCurrent);

protected:
	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp); //:> init controls
	virtual bool OnApply(bool fClose);
	virtual bool OnCancel();
	virtual bool OnNotifyChild(int id, NMHDR * pnmh, long & lnRet);

	virtual bool CmdLocalePopup(Cmd * pcmd);

	ILgWritingSystemFactoryPtr m_qwsf;
	int m_ws;			// id
	StrApp m_strName;	// name
	int m_lcid;
	Vector<WrtSysData> * m_pvwsdCurrent;
	int m_istrNormalFont;		// Index of font in m_vstrFonts.
	int m_istrHeadingFont;		// Index of font in m_vstrFonts.
	Vector<StrApp> m_vstrFonts;
	StrApp m_strEncodingConverter;
	StrApp m_strEncodingConvDesc;

	AfSystemLanguageList m_sll;

	CMD_MAP_DEC(LangDefPropDlg);
};
typedef GenSmartPtr<LangDefPropDlg> LangDefPropDlgPtr;


// Local Variables:
// mode:C++
// End: (These 3 lines are useful to Steve McConnel.)

#endif // !LANGDEFPROPDLG_H_INCLUDED
