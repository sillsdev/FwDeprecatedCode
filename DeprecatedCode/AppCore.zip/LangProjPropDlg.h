/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: LangProjPropDlg.h
Responsibility: Steve McConnel
Last reviewed: never

Description:
	Define the dialog classes that support the File / Language Project Properties menu command.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef LANGPROJPROPDLG_H_INCLUDED
#define LANGPROJPROPDLG_H_INCLUDED 1

//:End Ignore

/*----------------------------------------------------------------------------------------------
	Language project properties dialog.

	@h3{Hungarian: lppd}
----------------------------------------------------------------------------------------------*/
class LangProjPropDlg : public PropertiesDlg
{
	typedef PropertiesDlg SuperClass;
public:
	LangProjPropDlg();
	~LangProjPropDlg();

	void SetViewParams(int ilist, int iview)
	{
		m_ilist = ilist;
		m_iview = iview;
	}

	int GetListIndex()
	{
		return m_ilist;
	}

	int GetViewIndex()
	{
		return m_iview;
	}

	bool GetWsChange();

protected:
	enum
	{
		kidlgGeneral = 0,
		kidlgWrtSys = 1,
		kidlgExtLnk = 2,
	};

	int m_ilist;
	int m_iview;

	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
//	virtual bool OnHelpInfo(HELPINFO * phi);
	virtual bool OnApply(bool fClose);
	virtual bool OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet);

	void SetHelpUrl(int itab);

};
typedef GenSmartPtr<LangProjPropDlg> LangProjPropDlgPtr;

/*------------------------------------------------------------------------------------------
	Writing System data.
	Hungarian: wsd
------------------------------------------------------------------------------------------*/
struct WrtSysData
{
	int m_ws;						// subsumes the old m_hvo field.
	StrUni m_stuIcuLocale;			// replaces the Alphabetic representation of the old m_ws
	StrUni m_stuName;
	int m_lcid;
	StrUni m_stuNormalFont;
	StrUni m_stuHeadingFont;
	StrUni m_stuEncodingConverter;	// From LegacyMapping field of LgWritingSystem.
	StrUni m_stuEncodingConvDesc;	// From somewhere or other???

	/*--------------------------------------------------------------------------------------
		Compare two WrtSysData objects for equality.

		@param wsd Reference to the other WrtSysData object.
	--------------------------------------------------------------------------------------*/
	bool operator == (const WrtSysData & wsd)
	{
		return m_ws == wsd.m_ws &&
			m_lcid == wsd.m_lcid &&
			m_stuName == wsd.m_stuName &&
			m_stuNormalFont == wsd.m_stuNormalFont &&
			m_stuHeadingFont == wsd.m_stuHeadingFont &&
			m_stuEncodingConverter == wsd.m_stuEncodingConverter &&
			m_stuEncodingConvDesc == wsd.m_stuEncodingConvDesc;
	}
};


/*----------------------------------------------------------------------------------------------
	This class provides the functionality particular to the Writing System tab for language
	project properties.

	@h3{Hungarian: lppw}
----------------------------------------------------------------------------------------------*/
class LangProjPropWrtSys : public AfDialogView
{
	typedef AfDialogView SuperClass;
public:
	LangProjPropWrtSys(PropertiesDlg * ppropd);
	~LangProjPropWrtSys();

	virtual bool Apply();
//	virtual void Cancel();
//	virtual bool SetActive();
//	virtual bool QueryClose(QueryCloseType qct);
	void ChangeEncs();
	bool GetWsChange()
	{
		return m_fEncChange;
	}

protected:
	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);
//	virtual bool OnHelpInfo(HELPINFO * phi);
//	virtual bool OnCommand(int cid, int nc, HWND hctl);
//	virtual bool OnApply(bool fClose);
//	virtual bool OnCancel();
//	virtual bool OnHelp();
//	virtual bool OnNotifyThis(int id, NMHDR * pnmh, long & lnRet)
	virtual bool OnNotifyChild(int id, NMHDR * pnmh, long & lnRet);

	virtual bool CmdNewVernWS(Cmd * pcmd);
	virtual bool CmdNewAnalWS(Cmd * pcmd);
	void AddWrtSys(int ctidNewWS, int cidNewWS, int cidWrtSysList, Vector<int> & viwsd,
		int ctidMoveDown, int ctidMoveUp, int ctidDelete);
	void ModifyWrtSys(int cidList, Vector<int> & viwsd, int cidListOther,
		Vector<int> & viwsdOther);
	void MoveWrtSysDown(int cidList, Vector<int> & viwsd);
	void MoveWrtSysUp(int cidList, Vector<int> & viwsd);
	void RemoveWrtSys(int cidList, Vector<int> & viwsd, int ctidMoveDown, int ctidMoveUp,
		int ctidDelete);
//	bool ChangeEmbeddedEncRun(Vector<byte> & vbFmt, int encOld, int encNew);
	bool ChangeStyleEnc(Vector<byte> & vbRule, int encOld, int encNew);

	PropertiesDlg * m_ppropd;
	ILgWritingSystemFactoryPtr m_qwsf;
	int m_wsUser;			// user interface writing system id.
	HWND m_hwndVernWrtSys;	// Vernacular Writing Systems list box.
	HWND m_hwndAnalWrtSys;	// Analysis Writing Systems list box.
	Vector<WrtSysData> m_vwsd;
	Vector<WrtSysData> m_vwsdOrig;
	Vector<int> m_viwsdVern;
	Vector<int> m_viwsdAnal;
	bool m_fInitialized;
	bool m_fEncChange; // Flag to indicate that we changed order of encodings.
	HANDLE m_hDown;
	HANDLE m_hUp;

	CMD_MAP_DEC(LangProjPropWrtSys);
};
typedef GenSmartPtr<LangProjPropWrtSys> LangProjPropWrtSysPtr;



/*----------------------------------------------------------------------------------------------
	This class provides the functionality particular to the External Links  tab for language
	project properties.

	@h3{Hungarian: lppe}
----------------------------------------------------------------------------------------------*/
class LangProjPropExtLnkTab : public AfDialogView
{
	typedef AfDialogView SuperClass;
public:
	LangProjPropExtLnkTab(PropertiesDlg * ppropd);
	virtual bool Apply();

protected:
	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	virtual bool OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet);

	PropertiesDlg * m_ppropd;
	bool m_fInitialized;
};
typedef GenSmartPtr<LangProjPropExtLnkTab> LangProjPropExtLnkTabPtr;


/*----------------------------------------------------------------------------------------------
	String crawler for changing encodings.
----------------------------------------------------------------------------------------------*/
class ChangeEncStringCrawler : public DbStringCrawler
{
	typedef DbStringCrawler SuperClass;
	friend LangProjPropWrtSys;
public:
	ChangeEncStringCrawler(bool fPlain, bool fFormatting, bool fProcessBytes, bool fCharacters)
		: DbStringCrawler(fPlain, fFormatting, fProcessBytes, fCharacters)
	{
	}

	virtual bool ProcessFormatting(ComVector<ITsTextProps> & vqttp)
	{
		Assert(false);
		return false;
	}
	virtual bool ProcessBytes(Vector<byte> & vb);

protected:
	int m_wsOld;
	int m_wsNew;
};


// Local Variables:
// mode:C++
// compile-command:"cmd.exe /e:4096 /c c:\\FW\\Bin\\MkCustomNb.bat"
// End: (These 4 lines are useful to Steve McConnel.)

#endif // !LANGPROJPROPDLG_H_INCLUDED
