/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 1999, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: AfTextWnd.cpp
Responsibility: Shon Katzenberger
Last reviewed:


-------------------------------------------------------------------------------*//*:End Ignore*/
#include "Main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

// Explicit instantiations.
template Vector<AfTextWnd::DispLine>;


BEGIN_CMD_MAP(AfTextWnd)
	ON_CID_ME(kcidSelIdle, &AfTextWnd::CmdSelIdle, NULL)
END_CMD_MAP_NIL()


/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
AfTextWnd::AfTextWnd(void)
{
	m_pfli = NULL;
	m_hdcWnd = NULL;
}


/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
AfTextWnd::~AfTextWnd(void)
{
	m_esk.Close();
	m_esk.m_ptxtw = NULL;
	if (m_pfli)
	{
		m_pfli->Clear();
		delete m_pfli;
		m_pfli = NULL;
	}
	if (m_hdcWnd)
	{
		int iSuccess;
		iSuccess = ::ReleaseDC(m_hwnd, m_hdcWnd);
		Assert(iSuccess);
		m_hdcWnd = NULL;
	}
}


/*----------------------------------------------------------------------------------------------
	Static method to create a text window.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::Create(AfTextWnd ** pptxtw)
{
	AssertPtr(pptxtw);
	Assert(!*pptxtw);

	AfTextWndPtr qtxtw;

	qtxtw.Attach(NewObj AfTextWnd);
	qtxtw->Init();
	*pptxtw = qtxtw.Detach();
}


/*----------------------------------------------------------------------------------------------
	Initialize the text window.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::Init(void)
{
	m_clrFore = kclrBlack;
	m_clrBack = kclrWhite;
	m_dxmpDoc = 2 * 72000; // ENHANCE: Fix: 6 inches is the default.

	CreateFmtLine();

	SmartDc sdc((HWND)NULL);
}


/*----------------------------------------------------------------------------------------------
	Create the line formatter.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::CreateFmtLine(void)
{
	Assert(!m_pfli);
	m_pfli = NewObj FmtLineWnd;
	m_pfli->SetWnd(this);
}


/*----------------------------------------------------------------------------------------------
	The hwnd has just been attached so get the hdc.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::PostAttach(void)
{
	SuperClass::PostAttach();
	Assert(m_hwnd);
	Assert(m_hdcWnd == NULL);
	m_hdcWnd = ::GetDC(m_hwnd);
	m_rcp.Set(0, 0,
		::GetDeviceCaps(m_hdcWnd, LOGPIXELSX) * 2,
		::GetDeviceCaps(m_hdcWnd, LOGPIXELSY) * 2);

	m_hdcFmt = m_hdcWnd;
	m_rcs.Set(0, 0,
		::GetDeviceCaps(m_hdcFmt, LOGPIXELSX),
		::GetDeviceCaps(m_hdcFmt, LOGPIXELSY));
}


/*----------------------------------------------------------------------------------------------
	The hwnd has just been detached so release the hdc and clear the line formatter.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::DetachHwnd(HWND hwnd)
{
	Assert(m_hwnd);
	if (m_pfli)
		m_pfli->Clear();
	if (m_hdcWnd)
	{
		// REVIEW ShonK: What do we do with the m_hdcFmt dc?
		int iSuccess;
		iSuccess = ::ReleaseDC(m_hwnd, m_hdcWnd);
		Assert(iSuccess);
		m_hdcWnd = NULL;
		m_hdcFmt = NULL;
	}
}


/*----------------------------------------------------------------------------------------------
	Set the document that this AfTextWnd should be attached to.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::SetDoc(RichTextDoc * prtd, uint grfdoc)
{
	AssertObj(this);
	AssertObjN(prtd);

	if (prtd == m_qrtd)
		return;

	m_qrtd = prtd;
	m_ichAnchor = 0;
	m_ichOther = 0;
	m_fValidProps = false;
	m_fLockProps = false;
	m_ilinDisp = 0;
	m_ichDisp = 0;
	m_ilinInval = 0;
	m_vlin.Resize(0);

	if (prtd)
	{
		prtd->RegisterSink(&m_esk);
		m_esk.m_ptxtw = this;
	}
	else
	{
		m_esk.Close();
		m_esk.m_ptxtw = NULL;
	}

	InvalRect(NULL, grfdoc);
}


#ifdef TOOD // ShonK: Figure out how to set doc width, zoom, etc.
/*----------------------------------------------------------------------------------------------
	Set the width of the document (for line breaking, centering, etc).
----------------------------------------------------------------------------------------------*/
void AfTextWnd::SetDocWidth(int dxmp, uint grfdoc)
{
	AssertObj(this);

	if (dxmp < kdxmpDocMin)
		dxmp = kdxmpDocMin;

	if (m_dxmpDoc == dxmp)
		return;

	m_dxmpDoc = dxmp;

	InvalRect(NULL, grfdoc);
}
#endif // TODO


/***********************************************************************************************
	Selection management.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Turn off the selection.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::TurnOffSel(void)
{
	AssertObj(this);

	if (m_fSelOn)
	{
		SwitchSel(false);
		m_tsSel = 0;
	}
}


/*----------------------------------------------------------------------------------------------
	Protected method to turn the selection on or off.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::SwitchSel(bool fOn)
{
	AssertObj(this);

	if (fOn != m_fSelOn)
	{
		InvertSel(m_hdcWnd);
		m_fSelOn = fOn;
		m_tsSel = ::GetTickCount();
	}
}


/*----------------------------------------------------------------------------------------------
	Make the selection visible by scrolling it into view and making sure it will turn
	on soon.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::ShowSel(void)
{
	AssertObj(this);

	// For now, just make sure the selection is being drawn. Once scrolling is implemented,
	// also scroll so the selection is visible.

	AfApp::Papp()->PushCid(kcidSelIdle, this);
}


/*----------------------------------------------------------------------------------------------
	Get the selection.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::GetSel(int * pichAnchor, int * pichOther)
{
	AssertObj(this);
	AssertPtr(pichAnchor);
	AssertPtr(pichOther);

	*pichAnchor = m_ichAnchor;
	*pichOther = m_ichOther;
}


/*----------------------------------------------------------------------------------------------
	Set the selection.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::SetSel(int ichAnchor, int ichOther)
{
	AssertObj(this);
	int ichMac = IchMac();

	// Invalidate the insertion properties.
	if (!m_fLockProps)
		m_fValidProps = false;

	ichAnchor = Bound(ichAnchor, 0, ichMac - 1);
	ichOther = Bound(ichOther, 0, ichMac - 1);

	if (m_fSelOn)
	{
		if (m_ichAnchor != ichAnchor || m_ichAnchor == m_ichOther ||
			ichAnchor == ichOther)
		{
			InvertSel(m_hdcWnd);
			m_ichAnchor = ichAnchor;
			m_ichOther = ichOther;
			InvertSel(m_hdcWnd);
			m_tsSel = ::GetTickCount();
		}
		else
		{
			// They have the same anchor and neither is an insertion.
			InvertRange(m_hdcWnd, m_ichOther, ichOther);
			m_ichOther = ichOther;
		}
	}
	else
	{
		m_ichAnchor = ichAnchor;
		m_ichOther = ichOther;
		m_tsSel = 0;
	}
}


/*----------------------------------------------------------------------------------------------
	Make sure the insertion scalar character properties are valid.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FetchCharPropsIns(int ich1, int ich2)
{
	AssertObj(this);

	ByteString * pbst = m_qrtd->FetchCharProps(IchPropIns(ich1, ich2));
	m_tpgIns.Set(pbst->Prgb(), pbst->Size());
	m_fValidProps = true;
}


/***********************************************************************************************
	Property and text fetching.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Get the values for the given character from the selection.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::FetchCharPropSel(int scp, int * pnVal1, int * pnVal2, bool * pfConflict,
	int crunMax)
{
	AssertPtrN(pnVal1);
	AssertPtrN(pnVal2);
	AssertPtrN(pfConflict);

	if (m_ichAnchor == m_ichOther)
	{
		EnsureCharPropsIns();
		if (pfConflict)
			*pfConflict = false;
		return m_tpgIns.FGet(scp, pnVal1, pnVal2);
	}

	return FetchCharProp(Min(m_ichAnchor, m_ichOther), Max(m_ichAnchor, m_ichOther), scp,
		pnVal1, pnVal2, pfConflict, crunMax);
}


/*----------------------------------------------------------------------------------------------
	Get the values for the given character from the selection.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::FetchCharProp(int ichMin, int ichLim, int scp, int * pnVal1, int * pnVal2,
	bool * pfConflict, int crunMax)
{
	Assert(0 <= ichMin && ichMin <= ichLim && ichLim <= IchMac());
	AssertPtrN(pnVal1);
	AssertPtrN(pnVal2);
	AssertPtrN(pfConflict);

	ByteString * pbst;

	if (!pfConflict)
	{
		pbst = m_qrtd->FetchCharProps(ichMin, NULL, NULL);
		return FGetTextPropValue(scp, pbst->Prgb(), pbst->Size(), pnVal1, pnVal2);
	}

	bool fRet;
	int nVal1, nVal2;
	int nValT1, nValT2;
	int ich = ichMin;
	int crun = 0;

	pbst = m_qrtd->FetchCharProps(ich, NULL, &ich);
	fRet = FGetTextPropValue(scp, pbst->Prgb(), pbst->Size(), &nVal1, &nVal2);
	if (pnVal1)
		*pnVal1 = nVal1;
	if (pnVal2)
		*pnVal2 = nVal2;
	*pfConflict = false;

	while (ich < ichLim)
	{
		if (++crun >= crunMax)
		{
			*pfConflict = true;
			break;
		}
		pbst = m_qrtd->FetchCharProps(ich, NULL, &ich);
		if (fRet != FGetTextPropValue(scp, pbst->Prgb(), pbst->Size(), &nValT1, &nValT2) ||
			fRet && (nValT1 != nVal1 || nValT2 != nVal2))
		{
			*pfConflict = true;
			break;
		}
	}

	return fRet;
}


/*----------------------------------------------------------------------------------------------
	Get the values for the given character from the selection.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::FetchParaPropSel(int scp, int * pnVal1, int * pnVal2, bool * pfConflict,
	int crunMax)
{
	return FetchParaProp(Min(m_ichAnchor, m_ichOther), Max(m_ichAnchor, m_ichOther), scp,
		pnVal1, pnVal2, pfConflict, crunMax);
}


/*----------------------------------------------------------------------------------------------
	Get the values for the given character from the selection.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::FetchParaProp(int ichMin, int ichLim, int scp, int * pnVal1, int * pnVal2,
	bool * pfConflict, int crunMax)
{
	Assert(0 <= ichMin && ichMin <= ichLim && ichLim <= IchMac());
	AssertPtrN(pnVal1);
	AssertPtrN(pnVal2);
	AssertPtrN(pfConflict);

	ByteString * pbst;

	if (!pfConflict)
	{
		pbst = m_qrtd->FetchParaProps(ichMin, NULL, NULL);
		return FGetTextPropValue(scp, pbst->Prgb(), pbst->Size(), pnVal1, pnVal2);
	}

	bool fRet;
	int nVal1, nVal2;
	int nValT1, nValT2;
	int ich = ichMin;
	int crun = 0;

	pbst = m_qrtd->FetchParaProps(ich, NULL, &ich);
	fRet = FGetTextPropValue(scp, pbst->Prgb(), pbst->Size(), &nVal1, &nVal2);
	if (pnVal1)
		*pnVal1 = nVal1;
	if (pnVal2)
		*pnVal2 = nVal2;
	*pfConflict = false;

	while (ich < ichLim)
	{
		if (++crun >= crunMax)
		{
			*pfConflict = true;
			break;
		}
		pbst = m_qrtd->FetchParaProps(ich, NULL, &ich);
		if (fRet != FGetTextPropValue(scp, pbst->Prgb(), pbst->Size(), &nValT1, &nValT2) ||
			fRet && (nValT1 != nVal1 || nValT2 != nVal2))
		{
			*pfConflict = true;
			break;
		}
	}

	return fRet;
}


/*----------------------------------------------------------------------------------------------
	Get the base character properties for the given character.
	TODO ShonK: implement for real and cache.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FetchBaseChrp(int ich, LgCharRenderProps & chrp, int * pichMin, int * pichLim)
{
	AssertPtrN(pichMin);
	AssertPtrN(pichLim);

	// Fill in the defaults.
	chrp.ws = 0;
	chrp.ttvItalic = kttvOff;
	chrp.ttvBold = kttvOff;
	chrp.ssv = kssvOff;
	chrp.unt = kuntNone;
	chrp.dympHeight = 12000;
	chrp.dympOffset = 0;
	chrp.clrFore = kclrBlack;
	chrp.clrBack = (COLORREF)kclrTransparent;

	if (pichMin)
		*pichMin = 0;
	if (pichLim)
		*pichLim = IchMac();
}


/*----------------------------------------------------------------------------------------------
	Get the base paragraph properties for the given character.
	TODO ShonK: implement for real and cache.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FetchBaseParp(int ich, LgParaRenderProps & parp, int * pichMin, int * pichLim)
{
	AssertPtrN(pichMin);
	AssertPtrN(pichLim);

	// Fill in the defaults.
	parp.tal = ktalLeft;
	parp.dxmpFirstIndent = 0;
	parp.dxmpLeadingIndent = 0;
	parp.dxmpTrailingIndent = 0;
	parp.dxmpTabDef = 36000; // Half inch.
	parp.relLine = kdenTextPropRel;
	parp.dympExtraLine = 0;
	parp.relBefore = 0;
	parp.dympExtraBefore = 0;
	parp.relAfter = 0;
	parp.dympExtraAfter = 6000;
	parp.clrBack = (COLORREF)kclrTransparent;

	if (pichMin)
		*pichMin = 0;
	if (pichLim)
		*pichLim = IchMac();
}


/*----------------------------------------------------------------------------------------------
	Get the chrp and base chrp for the current selection. Sets ambiguous values to ninch.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FetchChrpSel(LgCharRenderProps & chrp, LgCharRenderProps & chrpBase)
{
	AssertObj(this);

	ByteString * pbst;

	if (m_ichAnchor == m_ichOther)
	{
		int ich = IchPropIns(m_ichAnchor, m_ichOther);
		FetchBaseChrp(ich, chrpBase, NULL, NULL);
		chrp = chrpBase;

		if (m_fValidProps)
		{
			// Selection is an insertion and we have the insertion properties cached.
			ApplyChrpTextPropGroup(chrp, m_tpgIns.Prgb(), m_tpgIns.Size());
		}
		else
		{
			pbst = m_qrtd->FetchCharProps(ich);
			ApplyChrpTextPropGroup(chrp, pbst->Prgb(), pbst->Size());
		}
		return;
	}

	LgCharRenderProps chrpT;
	int ichLimBase, ichLimBst;
	int ich = Min(m_ichAnchor, m_ichOther);
	int ichLim = Max(m_ichAnchor, m_ichOther);

	FetchBaseChrp(ich, chrpBase, NULL, &ichLimBase);
	pbst = m_qrtd->FetchCharProps(ich, NULL, &ichLimBst);

	chrp = chrpBase;
	ApplyChrpTextPropGroup(chrp, pbst->Prgb(), pbst->Size());

	// REVIEW ShonK: If the selection is too big should we just put ninch in all the fields?
	while ((ich = Min(ichLimBase, ichLimBst)) < ichLim)
	{
		if (ich < ichLimBase)
			chrpT = chrpBase;
		else
		{
			FetchBaseChrp(ich, chrpT, NULL, &ichLimBase);
			Assert(ich < ichLimBase);
			MergeNinchChrp(chrpT, chrpBase);
		}

		if (ich >= ichLimBst)
			pbst = m_qrtd->FetchCharProps(ich, NULL, &ichLimBst);
		Assert(ich < ichLimBst);
		ApplyChrpTextPropGroup(chrpT, pbst->Prgb(), pbst->Size());

		MergeNinchChrp(chrpT, chrp);
		ich = Min(ichLimBase, ichLimBst);
	}
}


/*----------------------------------------------------------------------------------------------
	Return the character that insertion properties should come from.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IchPropIns(int ich1, int ich2)
{
	AssertObj(this);
	Assert((uint)ich1 < (uint)IchMac());
	Assert((uint)ich2 < (uint)IchMac());

	if (ich1 != ich2)
		return Min(ich1, ich2);

	if (!FMinPara(ich1) || FMinPara(ich2 = IchNext(ich1)) || ich2 >= IchMac())
		ich1 = IchPrev(ich1);

	return ich1;
}


/*----------------------------------------------------------------------------------------------
	Fetch the character properties of the given character.
	ENHANCE (ShonK): implement a cache.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FetchChrp(int ich, LgCharRenderProps & chrp, int * pichMin, int * pichLim)
{
	AssertPtrN(pichMin);
	AssertPtrN(pichLim);
	AssertPtr(m_qrtd);

	FetchBaseChrp(ich, chrp, pichMin, pichLim);

	int ichMin, ichLim;
	ByteString * pbst = m_qrtd->FetchCharProps(ich, &ichMin, &ichLim);

	if (pichMin && *pichMin < ichMin)
		*pichMin = ichMin;
	if (pichLim && *pichLim > ichLim)
		*pichLim = ichLim;

	ApplyChrpTextPropGroup(chrp, pbst->Prgb(), pbst->Size());
}


/*----------------------------------------------------------------------------------------------
	Fetch the paragraph properties of the given character.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FetchParp(int ich, LgParaRenderProps & parp, int * pichMin, int * pichLim)
{
	AssertPtrN(pichMin);
	AssertPtrN(pichLim);
	AssertPtr(m_qrtd);

	FetchBaseParp(ich, parp, pichMin, pichLim);

	int ichMin, ichLim;
	ByteString * pbst = m_qrtd->FetchParaProps(ich, &ichMin, &ichLim);

	if (pichMin && *pichMin < ichMin)
		*pichMin = ichMin;
	if (pichLim && *pichLim > ichLim)
		*pichLim = ichLim;

	ApplyParpTextPropGroup(parp, pbst->Prgb(), pbst->Size());
}


/*----------------------------------------------------------------------------------------------
	Return the number of characters in the document.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IchMac(void)
{
	AssertPtr(m_qrtd);
	return m_qrtd->IchMac();
}


/*----------------------------------------------------------------------------------------------
	Fetch some characters.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FetchRgch(int ichMin, int ichLim, achar * prgch)
{
	AssertPtr(m_qrtd);
	m_qrtd->FetchRgch(ichMin, ichLim, prgch);
}


/*----------------------------------------------------------------------------------------------
	Fetch a character.
----------------------------------------------------------------------------------------------*/
achar AfTextWnd::ChFetch(int ich)
{
	AssertPtr(m_qrtd);
	return m_qrtd->ChFetch(ich);
}


/*----------------------------------------------------------------------------------------------
	Return whether the character is the beginning of a paragraph.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::FMinPara(int ich)
{
	AssertPtr(m_qrtd);
	return m_qrtd->FMinPara(ich);
}


/*----------------------------------------------------------------------------------------------
	Return the beginning of the paragraph containing ich.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IchMinPara(int ich)
{
	AssertPtr(m_qrtd);
	return m_qrtd->IchMinPara(ich);
}


/*----------------------------------------------------------------------------------------------
	Return the end of the paragraph containing ich.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IchLimPara(int ich)
{
	AssertPtr(m_qrtd);
	return m_qrtd->IchLimPara(ich);
}


/*----------------------------------------------------------------------------------------------
	Return ich of the previous character, skipping line feed characters.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IchPrev(int ich, bool fWord)
{
	AssertObj(this);
	Assert((uint)ich <= (uint)IchMac());

	if (ich <= 0)
		return 0;

	if (!fWord)
	{
		while (--ich > 0 && GrfchFromCh(ChFetch(ich)) & kfchIgnore)
			;
	}
	else
	{
		uint grfch1, grfch2;

		if (GrfchFromCh(ChFetch(ich - 1)) & (kfchWordBody | kfchWordEnd))
		{
			grfch1 = kfchWordEnd;
			grfch2 = kfchWordBody;
		}
		else
		{
			grfch1 = kfchWordEndJ;
			grfch2 = kfchWordBodyJ;
		}

		while (ich > 0 && (grfch1 & GrfchFromCh(ChFetch(ich - 1))))
			ich--;
		while (ich > 0 && (grfch2 & GrfchFromCh(ChFetch(ich - 1))))
			ich--;
	}

	return ich;
}


/*----------------------------------------------------------------------------------------------
	Return ich of the next character, skipping line feed characters.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IchNext(int ich, bool fWord)
{
	AssertObj(this);
	Assert((uint)ich <= (uint)IchMac());

	int ichLim = IchMac();

	if (ich >= ichLim)
		return ichLim;

	if (!fWord)
	{
		while (++ich < ichLim && GrfchFromCh(ChFetch(ich)) & kfchIgnore)
			;
	}
	else
	{
		uint grfch1, grfch2;

		if (GrfchFromCh(ChFetch(ich)) & (kfchWordBody | kfchWordEnd))
		{
			grfch1 = kfchWordBody;
			grfch2 = kfchWordEnd;
		}
		else
		{
			grfch1 = kfchWordBodyJ;
			grfch2 = kfchWordEndJ;
		}

		while (ich < ichLim && (grfch1 & GrfchFromCh(ChFetch(ich))))
			ich++;
		while (ich < ichLim && (grfch2 & GrfchFromCh(ChFetch(ich))))
			ich++;
	}

	return ich;
}


/***********************************************************************************************
	Editing.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Replace characters.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::Replace(int ich1, int ich2, const achar * prgch, int cch, uint grfdoc)
{
	AssertObj(this);
	AssertObj(m_qrtd);
	AssertArray(prgch, cch);
	Assert((uint)ich1 < (uint)IchMac());
	Assert((uint)ich2 < (uint)IchMac());

	TurnOffSel();

	if (ich1 > ich2)
		SwapVars(ich1, ich2);

	if (ich1 == NMin(m_ichAnchor, m_ichOther) && ich2 == NMax(m_ichAnchor, m_ichOther))
		EnsureCharPropsIns();
	else
		FetchCharPropsIns(ich1, ich2);

	m_fLockProps = true;
	m_qrtd->Replace(ich1, ich2, prgch, cch, kfdocNil);

	if (cch > 0)
	{
		try
		{
			m_qrtd->SetCharProps(ich1, ich1 + cch, m_tpgIns.Prgb(), m_tpgIns.Size(), kfdocNil);
		}
		catch (Throwable & thr)
		{
			thr;
			Warn("Applying char props threw an exception");
		}
	}

	m_qrtd->BroadCastInval(grfdoc);

	ich1 += cch;

	SetSel(ich1, ich1);
	ShowSel();
	m_fLockProps = false;

	Assert(m_fValidProps);
}


/*----------------------------------------------------------------------------------------------
	Apply a scalar character property.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::ApplyCharPropSel(int scp, int nVal1, int nVal2, bool fDel)
{
	AssertObj(this);

	if (m_ichAnchor == m_ichOther)
	{
		// Selection is empty.
		EnsureCharPropsIns();
		if (fDel)
			m_tpgIns.Del(scp);
		else
			m_tpgIns.Add(scp, nVal1, nVal2);
		return;
	}

	int ichAnchor = m_ichAnchor;
	int ichOther = m_ichOther;
	int ichMin = Min(ichAnchor, ichOther);
	int ichLim = Max(ichAnchor, ichOther);

	TurnOffSel();

	m_fValidProps = false;
	m_fLockProps = false;
	m_qrtd->ApplyCharProp(ichMin, ichLim, scp, nVal1, nVal2, fDel);

	SetSel(ichAnchor, ichOther);
	ShowSel();
}


/*----------------------------------------------------------------------------------------------
	Apply a scalar paragraph property.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::ApplyParaPropSel(int scp, int nVal1, int nVal2, bool fDel)
{
	AssertObj(this);

	int ichMin = Min(m_ichAnchor, m_ichOther);
	int ichLim = Max(m_ichAnchor, m_ichOther);

	int ichAnchor = m_ichAnchor;
	int ichOther = m_ichOther;

	TurnOffSel();

	m_fLockProps = true;
	m_qrtd->ApplyParaProp(ichMin, ichLim, scp, nVal1, nVal2, fDel);

	SetSel(ichAnchor, ichOther);
	ShowSel();

	m_fLockProps = false;
}


/*----------------------------------------------------------------------------------------------
	Apply the scalar properties to the character formatting of the current selection.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::ApplyCharPropsSel(const ScalarPropDelta * prgspd, int cspd)
{
	AssertObj(this);
	AssertArray(prgspd, cspd);

	if (cspd <= 0)
		return;

	if (m_ichAnchor == m_ichOther)
	{
		// Selection is empty.
		EnsureCharPropsIns();
		m_tpgIns.Apply(prgspd, cspd);
		return;
	}

	int ichAnchor = m_ichAnchor;
	int ichOther = m_ichOther;
	int ichMin = Min(ichAnchor, ichOther);
	int ichLim = Max(ichAnchor, ichOther);

	TurnOffSel();

	m_fValidProps = false;
	m_fLockProps = false;
	m_qrtd->ApplyCharProps(ichMin, ichLim, prgspd, cspd);

	SetSel(ichAnchor, ichOther);
	ShowSel();
}


/***********************************************************************************************
	Formatting.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	An edit has occurred. Update the view.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::OnEdit(RichTextDoc * prtd, int ichMin, int ichLim, int cchIns, uint grfdoc)
{
	AssertObj(this);
	AssertObj(prtd);
	Assert(prtd == m_qrtd);
	Assert(0 <= ichMin && ichMin <= ichLim);
	Assert(ichMin <= IchMac());
	Assert(cchIns >= 0);
	Assert(!m_fSelOn);

	int ichAnchor, ichOther;

	// Don't let the FmtLine cache a formatted line.
	AssertPtr(m_pfli);
	m_pfli->Clear();

	// Adjust the sel.
	ichAnchor = m_ichAnchor;
	ichOther = m_ichOther;

	FAdjustIndex(&ichAnchor, ichMin, ichLim, cchIns);
	FAdjustIndex(&ichOther, ichMin, ichLim, cchIns);
	if (ichAnchor != m_ichAnchor || ichOther != m_ichOther)
		SetSel(ichAnchor, ichOther);

	if (m_hwnd)
	{
		Assert(m_hdcWnd);
		Assert(m_hdcFmt);
		ReformatAndDraw(ichMin, ichLim, cchIns);
	}
}


/*----------------------------------------------------------------------------------------------
	Reformat the text window and update the display. If this text window is not the active one,
	the display is invalidated instead of updated.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::ReformatAndDraw(int ichMin, int ichLimDel, int cchIns)
{
	Rect rcp, rcd;
	int ys, dysIns, dysDel;

	m_fXdSelValid = false;

	// Reformat.
	Reformat(ichMin, ichLimDel, cchIns, &ys, &dysIns, &dysDel);

	// Determine the dirty rectangles and if we're active, update them.
	GetClientRect(rcp);

#ifdef NEED_TO_DO_THIS	// ShonK?
	if (!_fActive)
	{
		rc = rcLoc;
		rc.ypTop += yp;
		if (dypIns == dypDel)
			rc.ypBottom = rc.ypTop + dypIns;
		if (fptNil != _grfpt)
			rc.Transform(_grfpt);
		InvalRc(&rc);
		return;
	}
#endif

	int yd = MulDiv(ys, m_rcp.Height(), m_rcs.Height());
	int ydLimIns = MulDiv(ys + dysIns, m_rcp.Height(), m_rcs.Height());
	int ydLimDel = MulDiv(ys + dysDel, m_rcp.Height(), m_rcs.Height());

	rcd = rcp;
	rcd.top = yd;
	rcd.bottom = ydLimIns;
	if (ydLimIns != ydLimDel)
	{
#ifdef NEED_TO_DO_THIS // ShonK: fix this to scroll.
		// Have some bits to blt vertically. If the background isn't clear, but _fMark is set,
		// still do the scroll, since _fMark is intended to avoid flashing (allowing offscreen
		// drawing) and scrolling doesn't flash anyway.
		if (_fClear)
			rc.ypBottom = rcLoc.ypBottom;
		else
		{
			Point ptd(0, ypLimIns - ypLimDel);

			rc = rcLoc;
			rc.ypTop += LwMax(0, yp + LwMin(dypIns, dypDel));
			Scroll(&rc, pt.xp, pt.yp, _fMark ? kginMark : kginDraw);
			if (fptNil != _grfpt)
				rc.Transform(_grfptInv);
			rc.ypBottom = rc.ypTop;
			rc.ypTop = rcLoc.ypTop + yp;
		}
#endif
		rcd.bottom = rcp.bottom;
	}

	if (!rcd.IsEmpty())
		InvalRect(&rcd);
}


/*----------------------------------------------------------------------------------------------
	Recalculate the m_vlin after an edit. Sets *pys, *pdysIns, *pdysDel to indicate the
	vertical display space that was affected.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::Reformat(int ichMin, int ichLimDel, int cchIns, int * pys, int * pdysDel,
	int * pdysIns)
{
	AssertObj(this);
	Assert((uint)ichMin < (uint)IchMac());
	Assert((uint)cchIns <= (uint)(IchMac() - ichMin));
	Assert(ichMin <= ichLimDel);
	AssertPtrN(pys);
	AssertPtrN(pdysDel);
	AssertPtrN(pdysIns);

	int cchDel = ichLimDel - ichMin;
	int ysDel, dysDel, dysIns, dysCur;
	int cch, ichCur, ichNext, ichMac;
	int ilin, ilinOld;
	DispLine linOld, lin, linT;

	// _fClear = _ptxtb->AcrBack() == kacrClear;
	ichMac = IchMac();

	// Find the LIN that contains ich (if there is one) - don't calc any lines though.
	FindIch(ichMin, &linOld, &ilinOld, false);

	if (ichMin >= linOld.ichMin + linOld.cch)
	{
		// The line for this ich was not cached - recalc from the beginning of the last line.
		cchIns += ichMin - linOld.ichMin;
		cchDel += ichMin - linOld.ichMin;
		ichMin = linOld.ichMin;
	}
	Assert(linOld.ichMin <= ichMin);
	Assert(ichMin < linOld.ichMin + linOld.cch + (linOld.cch == 0));

	// Make sure the previous line is formatted correctly.
	if (ilinOld > 0 && !FMinPara(linOld.ichMin))
	{
		FetchLine(ilinOld - 1, &lin);
		CalcLine(lin.ichMin, lin.dysTot, &linT);
		if (linT.cch != lin.cch)
		{
			// Edit affected previous line - so start formatting from there.
			ilinOld--;
			linOld = lin;
		}
	}

	// Remove deleted lines.
	Assert(ilinOld <= m_ilinInval);
	m_ilinInval = ilinOld;

	int ilinT;

	cch = 0;
	dysDel = 0;
	for (ilinT = ilinOld;
		linOld.ichMin + cch <= ichMin + cchDel && ilinT < m_vlin.Size();
		ilinT++)
	{
		lin = m_vlin[ilinT];
		dysDel += lin.dys;
		cch += lin.cch;
	}
	m_vlin.Delete(ilinOld, ilinT);

	// Insert the new lines.
	ichCur = linOld.ichMin;
	dysCur = linOld.dysTot;

	// ichNext is the ich of the next (possibly stale) line in m_vlin.
	if (ilinOld < m_vlin.Size())
	{
		ichNext = linOld.ichMin + cch - cchDel + cchIns;
		Assert(linOld.ichMin <= ichNext && ichNext <= ichMac);
	}
	else
		ichNext = ichMac;

	Assert((uint)ilinOld <= (uint)m_vlin.Size());
	dysIns = 0;
	for (ilin = ilinOld; ; )
	{
		Assert(linOld.ichMin <= ichCur && ichCur <= ichMac);
		Assert(linOld.dysTot <= dysCur);
		while (ichNext < ichCur && ilin < m_vlin.Size())
		{
			lin = m_vlin[ilin];
			m_vlin.Delete(ilin);
			ichNext += lin.cch;
			dysDel += lin.dys;
		}
		Assert(ichCur <= ichNext && ichNext <= ichMac);

		if (ilin >= m_vlin.Size())
		{
			// No more DispLines that might be preservable, so we may as well stop trying.
			ilin = m_vlin.Size();
			if (ichNext < ichMac)
				dysDel = 0x01000000;
			if (ichCur < ichMac)
				dysIns = 0x01000000;
			break;
		}

		Assert((uint)ilin < (uint)m_vlin.Size());
		if (ichCur == ichNext)
		{
			// Everything from here on should be correct - we still need to set _ilinDisp.
			break;
		}

		CalcLine(ichCur, dysCur, &lin);
		m_vlin.Insert(ilin, lin);

		dysIns += lin.dys;
		ichCur += lin.cch;
		dysCur += lin.dys;
		ilin++;
	}
	m_ilinInval = ilin;

	if (m_ichDisp <= linOld.ichMin)
		ysDel = linOld.dysTot + m_rcs.top;
	else
	{
		if (m_ichDisp > ichMin)
		{
			if (m_ichDisp >= ichMin + cchDel)
				m_ichDisp += cchIns - cchDel;
			else if (m_ichDisp >= ichMin + cchIns)
				m_ichDisp = ichMin + cchIns;
		}
		ysDel = 0;
		FindIch(m_ichDisp, &lin, &m_ilinDisp);
		m_ichDisp = lin.ichMin;
		dysDel = NMax(0, linOld.dysTot + dysDel + m_rcs.top);
		m_rcs.Offset(0, -lin.dysTot - m_rcs.top);
		dysIns = NMax(0, linOld.dysTot + dysIns + m_rcs.top);
	}

	if (pys)
		*pys = ysDel;
	if (pdysIns)
		*pdysIns = dysIns;
	if (pdysDel)
		*pdysDel = dysDel;
}


/*----------------------------------------------------------------------------------------------
	Format the line.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FormatLine(int ichMin, int ichLim, bool fUseAll)
{
	AssertObj(this);
	Assert((uint)ichMin < (uint)ichLim && (uint)ichLim <= (uint)IchMac());
	AssertPtr(m_pfli);

	m_pfli->FormatLine(m_hdcFmt, m_rcs.Width(), m_rcs.Height(), ichMin, ichLim,
		MulDiv(m_dxmpDoc, m_rcs.Width(), kdzmpInch), fUseAll);
}


/*----------------------------------------------------------------------------------------------
	Calculate the end of the line, the left position of the line, the height of the line and
	the ascent of the line.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::CalcLine(int ichMin, int dysBase, DispLine * plin)
{
	AssertObj(this);
	Assert((uint)ichMin < (uint)IchMac());
	AssertPtr(plin);
	AssertPtr(m_pfli);

	m_pfli->Clear();
	FormatLine(ichMin, IchMac());

	plin->cch = m_pfli->IchLim() - ichMin;
	plin->dysAscent = m_pfli->DysAscent();
	plin->dys = plin->dysAscent + m_pfli->DysDescent();
	plin->ichMin = ichMin;
	plin->dysTot = dysBase;
}


/*----------------------------------------------------------------------------------------------
	Get the DispLine for the given ilin.  If ilin is past the end of m_vlin, CalcLine is called
	repeatedly and new lines are added to m_vlin. The actual index of the returned line is
	put in *pilinActual (if not NULL).
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FetchLine(int ilin, DispLine * plin, int * pilinActual)
{
	AssertObj(this);
	Assert(ilin >= 0);
	AssertPtr(plin);
	AssertPtrN(pilinActual);

	int ichLim, ichMac;
	int dysTot;
	DispLine * plinT;
	int ilinLim = NMin(m_vlin.Size(), ilin + 1);

	if (pilinActual)
		*pilinActual = ilin;

	if (m_ilinInval < ilinLim)
	{
		plinT = &m_vlin[m_ilinInval];
		if (0 == m_ilinInval)
		{
			ichLim = 0;
			dysTot = 0;
		}
		else
		{
			plinT--;
			ichLim = plinT->ichMin + plinT->cch;
			dysTot = plinT->dysTot + plinT->dys;
			plinT++;
		}

		// Adjust lines up to ilinLim.
		for (; m_ilinInval < ilinLim; m_ilinInval++, plinT++)
		{
			plinT->ichMin = ichLim;
			plinT->dysTot = dysTot;
			ichLim += plinT->cch;
			dysTot += plinT->dys;
		}
	}
	Assert(m_ilinInval >= ilinLim);

	if (ilin < m_ilinInval)
	{
		*plin = m_vlin[ilin];
		return;
	}

	Assert(ilinLim == m_vlin.Size());
	if (ilinLim == 0)
	{
		ichLim = 0;
		dysTot = 0;
		ClearItems(plin, 1);
	}
	else
	{
		// Get the line in case we don't actually calc any lines below.
		*plin = m_vlin[ilinLim - 1];
		ichLim = plin->ichMin + plin->cch;
		dysTot = plin->dysTot + plin->dys;
	}

	ichMac = IchMac();
	for (; ilinLim <= ilin && ichLim < ichMac; ilinLim++)
	{
		CalcLine(ichLim, dysTot, plin);
		m_vlin.Push(*plin);
		ichLim += plin->cch;
		dysTot += plin->dys;
	}
	m_ilinInval = m_vlin.Size();
	if (pilinActual)
		*pilinActual = ilinLim - 1;
}


/*----------------------------------------------------------------------------------------------
	Get the ich for the beginning of the ilin'th line. ilin is zero based.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IchFromLine(int ilin)
{
	AssertObj(this);

	DispLine lin;
	int ilinT;

	FetchLine(ilin, &lin, &ilinT);
	if (ilinT < ilin)
		return IchMac() - 1;

	return lin.ichMin;
}


/*----------------------------------------------------------------------------------------------
	Get the line number (zero based) from the ich.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IlinFromIch(int ich)
{
	AssertObj(this);
	int ilin;

	FindIch(NMin(ich, IchMac() - 1), NULL, &ilin);
	return ilin;
}


/*----------------------------------------------------------------------------------------------
	Find the line that contains the given ichFind. pilin and/or plin can be NULL. If fCalcLines
	is false, we won't calculate any new lines and the returned line may be before ichFind.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FindIch(int ichFind, DispLine * plin, int * pilin, bool fCalcLines)
{
	AssertObj(this);
	Assert((uint)ichFind < (uint)IchMac());
	AssertPtrN(plin);
	AssertPtrN(pilin);

	DispLine * plinT;
	DispLine lin;
	int dysTot;
	int ichLim;
	int ilinMac;

	// Get the starting ich and dysTot values for m_ilinInval.
	if (m_ilinInval == 0)
	{
		ichLim = 0;
		dysTot = 0;
	}
	else
	{
		plinT = &m_vlin[m_ilinInval - 1];
		ichLim = plinT->ichMin + plinT->cch;
		dysTot = plinT->dysTot + plinT->dys;
	}

	if (ichFind < ichLim)
	{
		// Do a binary search to find the DispLine containing ichFind.
		int ivMin, ivLim;

		for (ivMin = 0, ivLim = m_ilinInval; ivMin < ivLim; )
		{
			int ivMid = (ivMin + ivLim) / 2;
			plinT = &m_vlin[ivMid];
			if (ichFind < plinT->ichMin)
				ivLim = ivMid;
			else if (ichFind >= plinT->ichMin + plinT->cch)
				ivMin = ivMid + 1;
			else
			{
				if (pilin)
					*pilin = ivMid;
				if (plin)
					*plin = *plinT;
				return;
			}
		}

		AssertMsg(false, "Invalid DispLins");
		ichLim = 0;
		dysTot = 0;
		m_ilinInval = 0;
	}

	Assert(ichFind >= ichLim);
	if (m_ilinInval < (ilinMac = m_vlin.Size()))
	{
		// Adjust DispLines up to ichFind.
		plinT = &m_vlin[m_ilinInval];
		for (; m_ilinInval < ilinMac && ichFind >= ichLim; m_ilinInval++, plinT++)
		{
			plinT->ichMin = ichLim;
			plinT->dysTot = dysTot;
			ichLim += plinT->cch;
			dysTot += plinT->dys;
		}

		if (ichFind < ichLim)
		{
			Assert(plinT[-1].ichMin <= ichFind);
			if (pilin)
				*pilin = m_ilinInval - 1;
			if (plin)
				*plin = plinT[-1];
			return;
		}
	}
	Assert(m_ilinInval == ilinMac);
	Assert(ichFind >= ichLim);

	if (!fCalcLines)
	{
		if (pilin)
			*pilin = ilinMac - (ilinMac > 0);
		if (plin)
		{
			if (ilinMac > 0)
				*plin = m_vlin[ilinMac - 1];
			else
				ClearItems(plin, 1);
		}
		return;
	}

	// Have to calculate some lines.
	for (; ichFind >= ichLim; ilinMac++)
	{
		CalcLine(ichLim, dysTot, &lin);
		m_vlin.Push(lin);
		ichLim += lin.cch;
		dysTot += lin.dys;
	}
	m_ilinInval = m_vlin.Size();

	if (pilin)
		*pilin = ilinMac - 1;
	if (plin)
		*plin = lin;
}


/*----------------------------------------------------------------------------------------------
	Find the DispLine that contains the given ypFind value (measured from the top of the
	window). pilin and/or plin can be NULL. If fCalcLines is false, we won't calculate any
	new lines and the returned DispLine may be before ypFind.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::FindYp(int ypFind, DispLine * plin, int * pilin, bool fCalcLines)
{
	AssertObj(this);
	AssertPtrN(plin);
	AssertPtrN(pilin);

	DispLine * plinT;
	DispLine lin;
	int dysFind;
	int dysTot;
	int ichLim, ichMac;
	int ilinMac;

	// Get the starting ich and dysTot values for m_ilinInval.
	if (m_ilinInval == 0)
	{
		ichLim = 0;
		dysTot = 0;
	}
	else
	{
		plinT = &m_vlin[m_ilinInval - 1];
		ichLim = plinT->ichMin + plinT->cch;
		dysTot = plinT->dysTot + plinT->dys;
	}

	// Map ypFind to the source coordinates.
	if (ypFind < 0)
		dysFind = 0;
	else
		dysFind = m_rcp.MapYTo(ypFind, m_rcs);

	if (dysFind < dysTot)
	{
		// Do a binary search to find the LIN containing dypFind
		int ivMin, ivLim;

		for (ivMin = 0, ivLim = m_ilinInval; ivMin < ivLim; )
		{
			int ivMid = (ivMin + ivLim) / 2;
			plinT = &m_vlin[ivMid];
			if (dysFind < plinT->dysTot)
				ivLim = ivMid;
			else if (dysFind >= plinT->dysTot + plinT->dys)
				ivMin = ivMid + 1;
			else
			{
				if (pilin)
					*pilin = ivMid;
				if (plin)
					*plin = *plinT;
				return;
			}
		}

		AssertMsg(false, "Invalid DispLins");
		ichLim = 0;
		dysTot = 0;
		m_ilinInval = 0;
	}

	Assert(dysFind >= dysTot);
	if (m_ilinInval < (ilinMac = m_vlin.Size()))
	{
		// Adjust DispLines up to dysFind.
		plinT = &m_vlin[m_ilinInval];
		for (; m_ilinInval < ilinMac && dysFind >= dysTot; m_ilinInval++, plinT++)
		{
			plinT->ichMin = ichLim;
			plinT->dysTot = dysTot;
			ichLim += plinT->cch;
			dysTot += plinT->dys;
		}

		if (dysFind < dysTot)
		{
			Assert(m_ilinInval > 0 && plinT[-1].dysTot <= dysFind);
			if (pilin)
				*pilin = m_ilinInval - 1;
			if (plin)
				*plin = plinT[-1];
			return;
		}
	}
	Assert(m_ilinInval == ilinMac);
	Assert(dysFind >= dysTot);

	if (!fCalcLines)
	{
		if (pilin)
			*pilin = ilinMac - (ilinMac > 0);
		if (plin)
		{
			if (ilinMac > 0)
				*plin = m_vlin[ilinMac - 1];
			else
				ClearItems(plin, 1);
		}
		return;
	}

	ichMac = IchMac();
	if (ichLim >= ichMac)
	{
		if (plin)
		{
			// Get a valid lin.
			if (ilinMac > 0)
				lin = m_vlin[ilinMac - 1];
			else
				ClearItems(&lin, 1);
		}
		m_ilinInval = ilinMac;
	}
	else
	{
		Assert(dysFind >= dysTot && ichLim < ichMac);
		for (; dysFind >= dysTot && ichLim < ichMac; ilinMac++)
		{
			CalcLine(ichLim, dysTot, &lin);
			m_vlin.Push(lin);
			ichLim += lin.cch;
			dysTot += lin.dys;
		}
		m_ilinInval = m_vlin.Size();
	}

	if (pilin)
		*pilin = ilinMac - 1;
	if (plin)
		*plin = lin;
}


/*----------------------------------------------------------------------------------------------
	Get the bounds of the character in destination coordinates.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::GetBoundsFromIch(int ich, Rect & rcp, int * pypBase)
{
	AssertObj(this);
	Assert(0 <= ich && ich < IchMac());
	AssertPtrN(pypBase);
	AssertPtr(m_pfli);

	DispLine lin;

	FindIch(ich, &lin);

	rcp.left = XpFromIch(ich, lin);
	rcp.right = rcp.left;
	rcp.top = m_rcs.MapYTo(lin.dysTot, m_rcp);
	rcp.bottom = m_rcs.MapYTo(lin.dysTot + lin.dys, m_rcp);

	if (pypBase)
		*pypBase = m_rcs.MapYTo(lin.dysTot + lin.dysAscent, m_rcp);
}


/*----------------------------------------------------------------------------------------------
	Get the horizontal location of the character.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::XpFromIch(int ich, DispLine & lin)
{
	AssertObj(this);
	Assert(lin.ichMin <= ich && ich < lin.ichMin + lin.cch && lin.ichMin + lin.cch <= IchMac());
	AssertPtr(m_pfli);

	FormatLine(lin.ichMin, lin.ichMin + lin.cch, true);
	return m_pfli->XdFromIch(m_hdcWnd, ich, m_rcs, m_rcp);
}


/*----------------------------------------------------------------------------------------------
	Get the ich on the line given by lin that the xp is in. If fClosest is true, this finds
	the ich boundary that the point is closest to (for traditional selection). If fClosest
	is false, it finds the character that the xp is over.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IchFromXp(int xp, DispLine & lin, bool fClosest)
{
	AssertObj(this);
	Assert((uint)lin.ichMin < (uint)IchMac());
	Assert(1 <= lin.cch && lin.cch <= IchMac() - lin.ichMin);

	FormatLine(lin.ichMin, lin.ichMin + lin.cch, true);
	return m_pfli->IchFromXd(m_hdcWnd, xp, m_rcs, m_rcp, fClosest);
}


/*----------------------------------------------------------------------------------------------
	Get the ich that the point is in. If fClosest is true, this finds the ich boundary that
	the point is closest to (for traditional selection). If fClosest is false, it finds the
	character that the point is over.
----------------------------------------------------------------------------------------------*/
int AfTextWnd::IchFromPt(int xp, int yp, bool fClosest)
{
	AssertObj(this);

	DispLine lin;

	FindYp(yp, &lin);
	return IchFromXp(xp, lin, fClosest);
}


/***********************************************************************************************
	Drawing.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Draw to the given clip rectangle.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::Draw(HDC hdc, const Rect & rcpClip)
{
	Assert(hdc);

	DrawLines(hdc, m_rcp.Width(), m_rcp.Height(), 0, 0, rcpClip, 0, 0x01000000);

	if (m_fSelOn)
		InvertSel(hdc);
	// _SetScrollValues();
}


/*----------------------------------------------------------------------------------------------
	Draws some lines of the document.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::DrawLines(HDC hdc, int dxpInch, int dypInch, int xp, int yp,
	const Rect & rcpClip, int ilinMin, int ilinLim)
{
	Assert(hdc);

	int ichLine, ichLim;
	DispLine lin;
	int ilin;
	Rect rcs;

	ichLim = IchMac();
	FetchLine(ilinMin, &lin);
	ichLine = lin.ichMin;

	AfGfx::FillSolidRect(hdc, rcpClip, RGB(255, 255, 255));

	rcs = m_rcs;
	rcs.Offset(0, -lin.dysTot - rcs.top);

	for (ilin = ilinMin; ilin < ilinLim; ilin++)
	{
		if (rcs.MapYTo(0, m_rcp) > rcpClip.bottom || ichLine >= ichLim)
			break;

		FetchLine(ilin, &lin);
		Assert(ichLine == lin.ichMin);
		if (rcs.MapYTo(lin.dys, m_rcp) >= rcpClip.top)
		{
			FormatLine(lin.ichMin, lin.ichMin + lin.cch, true);
			m_pfli->DrawLine(m_hdcWnd, rcpClip, rcs, m_rcp);
		}

		rcs.Offset(0, -lin.dys);
		ichLine += lin.cch;
	}
}


/*----------------------------------------------------------------------------------------------
	Invert the selection.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::InvertSel(HDC hdc)
{
	AssertObj(this);

	if (!hdc)
		return;

	if (m_ichAnchor != m_ichOther)
	{
		InvertRange(hdc, m_ichAnchor, m_ichOther);
		return;
	}

	// Insertion bar.
	Rect rcpClip;
	Rect rcp;

	GetClientRect(rcpClip);
	GetBoundsFromIch(m_ichAnchor, rcp);
	rcp.right = --rcp.left + 2;

	if (rcp.Intersect(rcpClip))
		AfGfx::InvertRect(hdc, rcp);
}


/*----------------------------------------------------------------------------------------------
	Invert (for selection) a range of characters.
----------------------------------------------------------------------------------------------*/
void AfTextWnd::InvertRange(HDC hdc, int ich1, int ich2)
{
	AssertObj(this);
	Assert((uint)ich1 <= (uint)IchMac());
	Assert((uint)ich2 <= (uint)IchMac());

	if (!hdc || ich1 == ich2)
		return;

	if (ich1 > ich2)
		SwapVars(ich1, ich2);

	Rect rcp1, rcp2, rcpClip, rcpT;

	GetBoundsFromIch(ich1, rcp1);
	GetBoundsFromIch(ich2, rcp2);

	GetClientRect(rcpClip);

	rcp1.Offset(rcpClip.left, rcpClip.top);
	rcp2.Offset(rcpClip.left, rcpClip.top);

	if (rcp1.top >= rcpClip.bottom || rcp2.bottom <= rcpClip.top)
		return;

	if (rcp1.top == rcp2.top && rcp1.bottom == rcp2.bottom)
	{
		// Only one line involved.
		rcp1.right = rcp2.right;
		if (rcpT.Intersect(rcp1, rcpClip))
			AfGfx::InvertRect(hdc, rcpT);
		return;
	}

	// Invert the sel on the first line.
	rcp1.right = rcpClip.right;
	if (rcpT.Intersect(rcp1, rcpClip))
		AfGfx::InvertRect(hdc, rcpT);

	// Invert the main rectangular block.
	rcp1.left = rcpClip.left;
	rcp1.top = rcp1.bottom;
	rcp1.bottom = rcp2.top;
	if (rcpT.Intersect(rcp1, rcpClip))
		AfGfx::InvertRect(hdc, rcpT);

	// Invert the last line.
	rcp2.left = rcp1.left;
	if (rcpT.Intersect(rcp2, rcpClip))
		AfGfx::InvertRect(hdc, rcpT);
}


/***********************************************************************************************
	Message handling.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Handle window messages.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
	AssertObj(this);
	Assert(!lnRet);

	switch (wm)
	{
	case WM_KEYDOWN:
		return OnKey(wp, AfApp::GrfmstCur(), lp);

	case WM_CHAR:
		return OnChar((achar)wp, wp, lp);

	case WM_LBUTTONDOWN:
		return OnMouseDown(wp, (int)(short)LOWORD(lp), (int)(short)HIWORD(lp));

	case WM_MOUSEMOVE:
		return OnMouseMove(wp, (int)(short)LOWORD(lp), (int)(short)HIWORD(lp));

	case WM_LBUTTONUP:
		return OnMouseUp(wp, (int)(short)LOWORD(lp), (int)(short)HIWORD(lp));
	}

	return SuperClass::FWndProc(wm, wp, lp, lnRet);
}


/*----------------------------------------------------------------------------------------------
	Paint the thing.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::OnPaint(HDC hdcDef)
{
	AssertObj(this);

	HDC hdc;
	PAINTSTRUCT ps;
	Rect rcp;

	GetClientRect(rcp);

	if (hdcDef)
		hdc = hdcDef;
	else
	{
		hdc = BeginPaint(m_hwnd, &ps);
		rcp.Intersect(ps.rcPaint);
	}

	Draw(hdc, rcp);

	if (!hdcDef)
		EndPaint(m_hwnd, &ps);

	return true;
}


/*----------------------------------------------------------------------------------------------
	Handle a WM_CHAR message.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::OnChar(achar ch, WPARAM wp, LPARAM lp)
{
	switch (ch)
	{
	case kchBackSpace:
		// We handle this as a virtual key.
		return true;

	default:
		Replace(m_ichAnchor, m_ichOther, (const rchar *)&wp, 1);
		return true;
	}
}


/*----------------------------------------------------------------------------------------------
	Handle a WM_KEYDOWN message.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::OnKey(int vk, uint grfmst, LPARAM lp)
{
	int ichOther;
	DispLine lin;
	int ilin;

	switch (vk)
	{
	case kvkBackSpace:
		if (m_ichAnchor != m_ichOther)
			ichOther = m_ichOther;
		else
			ichOther = IchPrev(m_ichAnchor);
		if (ichOther != m_ichAnchor)
			Replace(m_ichAnchor, ichOther, NULL, 0);
		return true;

	case kvkDelete:
		if (m_ichAnchor != m_ichOther)
			ichOther = m_ichOther;
		else
			ichOther = Min(IchMac() - 1, IchNext(m_ichAnchor));
		if (ichOther != m_ichAnchor)
			Replace(m_ichAnchor, ichOther, NULL, 0);
		return true;

	case kvkHome:
		if (grfmst & kfmstCtrl)
			ichOther = 0;
		else
		{
			FindIch(Min(m_ichAnchor, m_ichOther), &lin);
			ichOther = lin.ichMin;
		}
		m_fXdSelValid = false;
		break;

	case kvkEnd:
		if (grfmst & kfmstCtrl)
			ichOther = IchMac();
		else
		{
			FindIch(Max(m_ichAnchor, m_ichOther), &lin);
			FormatLine(lin.ichMin, lin.ichMin + lin.cch, true);
			ichOther = m_pfli->IchLimSel();
		}
		m_fXdSelValid = false;
		break;

	case kvkLeft:
		ichOther = Min(m_ichAnchor, m_ichOther);
		if (m_ichOther == m_ichAnchor || (grfmst & (kfmstCtrl | kfmstShift)))
			ichOther = IchPrev(ichOther, (grfmst & kfmstCtrl) != 0);
		m_fXdSelValid = false;
		break;

	case kvkRight:
		ichOther = Max(m_ichAnchor, m_ichOther);
		if (m_ichOther == m_ichAnchor || (grfmst & (kfmstCtrl | kfmstShift)))
			ichOther = IchNext(ichOther, (grfmst & kfmstCtrl) != 0);
		m_fXdSelValid = false;
		break;

	case kvkUp:
		ichOther = grfmst & kfmstShift ? m_ichOther : Min(m_ichAnchor, m_ichOther);
		FindIch(ichOther, &lin, &ilin);
		// REVIEW ShonK: Fix this when we have ilin == 0 with lin.ichMin > 0.
		if (ilin == 0)
		{
			if (grfmst & kfmstShift)
			{
				ichOther = 0;
				m_fXdSelValid = false;
			}
			break;
		}

		if (!m_fXdSelValid)
		{
			m_xdSel = XpFromIch(ichOther, lin) - m_rcp.left;
			m_fXdSelValid = true;
		}
		FetchLine(ilin - 1, &lin);
		ichOther = IchFromXp(m_xdSel + m_rcp.left, lin, true);
		break;

	case kvkDown:
		ichOther = grfmst & kfmstShift ? m_ichOther : Max(m_ichAnchor, m_ichOther);
		FindIch(ichOther, &lin, &ilin);
		if (lin.ichMin + lin.cch >= IchMac())
		{
			if (grfmst & kfmstShift)
			{
				ichOther = IchMac();
				m_fXdSelValid = false;
			}
			break;
		}

		if (!m_fXdSelValid)
		{
			m_xdSel = XpFromIch(ichOther, lin) - m_rcp.left;
			m_fXdSelValid = true;
		}
		FetchLine(ilin + 1, &lin);
		ichOther = IchFromXp(m_xdSel + m_rcp.left, lin, true);
		break;

	default:
		return false;
	}

	// Move the selection.
	SetSel(grfmst & kfmstShift ? m_ichAnchor : ichOther, ichOther);
	ShowSel();

	return true;
}


bool AfTextWnd::OnMouseDown(uint grfmk, int xp, int yp)
{
	AssertObj(this);

	int ich, ichAnchor;

	// Set the selection.
	if (::GetCapture() != NULL || !m_hwnd)
	{
		AssertMsg(false, "Someone else has the mouse captured");
		return false;
	}

	::SetCapture(m_hwnd);

	ich = IchFromPt(xp, yp, true);
	if (grfmk & MK_SHIFT)
		ichAnchor = m_ichAnchor;
	else
		ichAnchor = ich;

	SetSel(ichAnchor, ich);
	SwitchSel(true);

	return true;
}


bool AfTextWnd::OnMouseMove(uint grfmk, int xp, int yp)
{
	AssertObj(this);

	int ich, ichAnchor;

	if (::GetCapture() != m_hwnd || !m_hwnd)
		return false;

	ich = IchFromPt(xp, yp, true);
	ichAnchor = m_ichAnchor;

	SetSel(ichAnchor, ich);
	SwitchSel(true);

	return true;
}


bool AfTextWnd::OnMouseUp(uint grfmk, int xp, int yp)
{
	AssertObj(this);

	int ich, ichAnchor;

	if (::GetCapture() != m_hwnd || !m_hwnd)
		return false;

	::ReleaseCapture();

	ich = IchFromPt(xp, yp, true);
	ichAnchor = m_ichAnchor;

	SetSel(ichAnchor, ich);
	SwitchSel(true);

	return true;
}


/***********************************************************************************************
	Command functions.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Handle the sel idle command.
----------------------------------------------------------------------------------------------*/
bool AfTextWnd::CmdSelIdle(Cmd * pcmd)
{
	AssertObj(this);
	AssertObj(pcmd);

	if (pcmd->m_qcmh != this)
		return false;

	SwitchSel(true);

	return true;
}

