/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: NewLangDefDlg.cpp
Responsibility: Steve McConnel
Last reviewed: never.

Description:
	Implementation of the New Language definition wizard dialog classes.
-------------------------------------------------------------------------------*//*:End Ignore*/
#include "Main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

#include <direct.h>

BEGIN_CMD_MAP(AfNewLangSetup)
	ON_CID_CHILD(kcidNewLangLanguagePopupMenu, &AfNewLangSetup::CmdLangPopup, NULL)
END_CMD_MAP_NIL()

//:>********************************************************************************************
//:>	AfNewLangDefWizard Implementation
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Initialize the dialog in response to the WM_INITDIALOG message.
	All one-time initialization should be done here (that is, all controls have been created
	and have valid hwnd's, but they need initial values.)

	@param hwndCtrl Not used by this method.
	@param lp Not used by this method.

	@return True.
----------------------------------------------------------------------------------------------*/
bool AfNewLangDefWizard::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	AddPage(NewObj AfNewLangIdentify(m_qwsf));
	AddPage(NewObj AfNewLangSetup());

	GetAvailableFonts();

	StrApp str(kstidNewLangWizTitle);
	::SetWindowText(m_hwnd, str.Chars());

	// Subclass the Help button.
	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidHelp, kbtHelp, NULL, 0);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Get the list of all available fonts.
----------------------------------------------------------------------------------------------*/
void AfNewLangDefWizard::GetAvailableFonts()
{
	if (!m_vstrFonts.Size())
	{
		// Get the currently available fonts via the LgFontManager.

		ILgFontManagerPtr qfm;
		SmartBstr bstrNames;

		qfm.CreateInstance(CLSID_LgFontManager);
		CheckHr(qfm->AvailableFonts(&bstrNames));
		static long ipszList = 0; // Returned value from SendMessage.

		StrApp strNameList;
		strNameList.Assign(bstrNames.Bstr(), BstrLen(bstrNames.Bstr()));
		int cchLength = strNameList.Length();
		StrApp strName;		// Individual font name.
		int ichMin;			// Index of the beginning of a font name.
		int ichLim;			// Index that is one past the end of a font name.

		// Add each font name to the list.
		for (ichMin = 0, ichLim = 0; ichLim < cchLength; ichMin = ichLim + 1)
		{
			ichLim = strNameList.FindCh(L',', ichMin);
			if (ichLim == -1) // i.e., if not found.
			{
				ichLim = cchLength;
			}
			strName.Assign(strNameList.Chars() + ichMin, ichLim - ichMin);
			m_vstrFonts.Push(strName);
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Create a new language writing system.
----------------------------------------------------------------------------------------------*/
void AfNewLangDefWizard::CreateNewLangEncoding()
{
	StrUni stuLang(m_strLanguageName);
	StrUni stuEthCode(m_strEthCode);
	try
	{
		AssertPtr(m_qwsf);

		// Create the new language writing system.
		int ws;
		CheckHr(m_qwsf->GetWsFromStr(stuEthCode.Bstr(), &ws));
		if (ws)
			CheckHr(m_qwsf->RemoveEngine(ws));
		ILgWritingSystemPtr qws;
		CheckHr(m_qwsf->get_Engine(stuEthCode.Bstr(), &qws));
		if (m_lcid)
			CheckHr(qws->put_Locale(m_lcid));
		CheckHr(qws->put_Name(m_wsUser, stuLang.Bstr()));
		CheckHr(qws->put_DefaultSerif(m_strNormalFont.Bstr()));
		CheckHr(qws->put_DefaultSansSerif(m_strHeadingFont.Bstr()));
		m_hvo = ws;
	}
	catch (Throwable & thr)
	{
		if (thr.Error() != S_OK)
		{
			// Do something?
		}
	}
	catch (...)
	{
		// Do something?
	}
}


//:>********************************************************************************************
//:>	AfNewLangIdentify Implementation
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
AfNewLangIdentify::~AfNewLangIdentify()
{
	if (m_hfontLarge)
	{
		AfGdi::DeleteObjectFont(m_hfontLarge);
		m_hfontLarge = NULL;
	}
}


/*----------------------------------------------------------------------------------------------
	Initialize the dialog in response to the WM_INITDIALOG message.
	All one-time initialization should be done here (that is, all controls have been created
	and have valid hwnd's, but they need initial values.)

	@param hwndCtrl Not used by this method.
	@param lp Not used by this method.

	@return True.
----------------------------------------------------------------------------------------------*/
bool AfNewLangIdentify::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	// Set the font for the page title.
	m_hfontLarge = AfGdi::CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET,
		OUT_CHARACTER_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH | FF_SWISS,
		_T("MS Sans Serif"));
	if (m_hfontLarge)
	{
		::SendMessage(::GetDlgItem(m_hwnd, kridNewLangIdentifyTitle), WM_SETFONT,
			(WPARAM)m_hfontLarge, false);
	}
	StrApp str(kstidNewLangIdentifyTitle);
	::SetWindowText(::GetDlgItem(m_hwnd, kridNewLangIdentifyTitle), str.Chars());

	str.Load(kstidNewLangDefaultLanguage);
	::SetWindowText(::GetDlgItem(m_hwnd, kctidNewLangIdentifyLanguage), str.Chars());

	::SendMessage(::GetDlgItem(m_hwnd, kctidNewLangIdentifyEthCode), EM_LIMITTEXT, 5, 0);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Handle a WM_NOTIFY message, first letting the superclass method handle it if possible.

	@param ctidFrom Identifies the control sending the message.
	@param pnmh Pointer to the notification message data.
	@param lnRet Reference to a long integer return value used by some messages.

	@return True if the message is handled successfully; otherwise, false.
----------------------------------------------------------------------------------------------*/
bool AfNewLangIdentify::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (SuperClass::OnNotifyChild(ctidFrom, pnmh, lnRet))
		return true;

	switch (pnmh->code)
	{
	case EN_CHANGE:
	case EN_KILLFOCUS:
		{
			switch (ctidFrom)
			{
				case kctidNewLangIdentifyEthCode:
				{
					StrAppBuf strb;
					int cch;
					cch = ::SendMessage (pnmh->hwndFrom, WM_GETTEXT, strb.kcchMaxStr,
						(LPARAM)strb.Chars());
					strb.SetLength(cch);

					achar rgch[100];
					_tcscpy(rgch, strb.Chars());
					StrApp strEth(_T(""));
					bool fInvalid = false;
					for (int i = 0; i < 5; ++i)
					{
						if (i == cch)
							break;
						if (i < 3)
						{
							if ((rgch[i] >='A' && rgch[i] <='Z'))
								strEth.Append(rgch + i, 1);
							else
							{
								fInvalid = true;
								::MessageBeep(MB_ICONEXCLAMATION);
								break;
							}
						}
						else if (i < 5)
						{
							if ((rgch[i] >='0' && rgch[i] <='9'))
								strEth.Append(rgch + i, 1);
							else
							{
								fInvalid = true;
								::MessageBeep(MB_ICONEXCLAMATION);
								break;
							}
						}
					}

					if (fInvalid)
					{
						::SendMessage(pnmh->hwndFrom, WM_SETTEXT, 0, (LPARAM)strEth.Chars());
						::SendMessage(pnmh->hwndFrom, EM_SETSEL, (WPARAM)strEth.Length(), (LPARAM)-1);
					}
				}
				// do not put a break here.  We want to fall through.
				case kctidNewLangIdentifyLanguage:
				{
					achar rgch[100];
					bool fOk = true;
					int cchLang = ::GetDlgItemText(m_hwnd, kctidNewLangIdentifyLanguage,
						rgch, 100);
					if (cchLang == 0)
					{
						fOk = false;
					}
					else
					{
						StrApp strDefault(kstidNewLangDefaultLanguage);
						StrApp str(rgch, cchLang);
						if (str == strDefault)
							fOk = false;
					}
					if (fOk)
					{
						int cchEth = ::GetDlgItemText(m_hwnd, kctidNewLangIdentifyEthCode,
							rgch, 100);

						if (cchEth < 3 || cchEth > 5)
							fOk = false;

						for (int i = 0; i < 5; ++i)
						{
							if (i == cchEth)
								break;
							if (i < 3 && (rgch[i] < 'A' || rgch[i] > 'Z'))
							{
								fOk = false;
								break;
							}
							if (i > 2 && (rgch[i] < '0' || rgch[i] > '9'))
							{
								fOk = false;
								break;
							}
						}
					}
					m_pwiz->EnableNextButton(fOk);
				}
			}
			break;
		}
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Retrieve the name of the language and its Ethnologue code.

	@return handle of the next page to advance to.
----------------------------------------------------------------------------------------------*/
HWND AfNewLangIdentify::OnWizardNext()
{
	AfNewLangDefWizard * prnlp = dynamic_cast<AfNewLangDefWizard *>(m_pwiz);
	Assert(prnlp);
	StrApp strMsg;

	const Vector<WrtSysData> * pvwsd = prnlp->OldWritingSystemDefs();

	StrUni stuLangNameEntered;
	StrAppBufSmall strbsWs;
	const achar * pszHelpUrl = m_pszHelpUrl;
	int wsEntered;
	achar rgch[128];
	::GetDlgItemText(m_hwnd, kctidNewLangIdentifyEthCode, rgch, 128);
	SmartBstr sbstrWs(rgch);
	CheckHr(m_qwsf->GetWsFromStr(sbstrWs, &wsEntered));
	if (wsEntered)
	{
		// "The writing system code ""%<0>s"" is already used by the ""%<1>s"" writing system."
		StrApp strTitle(kstidLangAlreadyInListTlt);
		StrApp strFmt(kstidEncAlreadyInListFmt);
		StrApp strWs(sbstrWs.Chars());
		ILgWritingSystemPtr qws;
		SmartBstr sbstrName;
		CheckHr(m_qwsf->get_EngineOrNull(wsEntered, &qws));
		AssertPtr(qws);
		CheckHr(qws->get_UiName(prnlp->UserWs(), &sbstrName));
		StrApp strName(sbstrName.Chars());
		strMsg.Format(strFmt.Chars(), strWs.Chars(), strName.Chars());
		m_pszHelpUrl = _T("WhatIsAnEthnologueCode.htm");
		::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(),
			MB_OK | MB_ICONINFORMATION | MB_HELP);
		m_pszHelpUrl = pszHelpUrl;
		return (HWND)-1;	// Stay on same page.
	}
	int cchLang = ::GetDlgItemText(m_hwnd, kctidNewLangIdentifyLanguage, rgch, 128);
	stuLangNameEntered.Assign(rgch, cchLang);

	// Check for duplicate language name.
	int iwsdTemp;
	for (iwsdTemp = 0; iwsdTemp < (*pvwsd).Size(); ++iwsdTemp)
	{
		if (stuLangNameEntered == (*pvwsd)[iwsdTemp].m_stuName)
		{
			StrApp strTitle(kstidLangAlreadyInListTlt);
			StrApp strFmt(kstidLangAlreadyInListFmt);
			StrApp strName(stuLangNameEntered.Chars());
			StrApp strWs((*pvwsd)[iwsdTemp].m_stuIcuLocale.Chars());
			strMsg.Format(strFmt.Chars(), strName.Chars(), strWs.Chars());
			m_pszHelpUrl = _T("WhatIsALanguageCode.htm");
			::MessageBox(m_hwnd, strMsg.Chars(), strTitle.Chars(),
				MB_OK | MB_ICONINFORMATION | MB_HELP);
			::SetFocus(::GetDlgItem(m_hwnd, kctidNewLangIdentifyLanguage));
			m_pszHelpUrl = pszHelpUrl;
			return (HWND)-1;	// Stay on same page.
		}
	}

	m_pszHelpUrl = pszHelpUrl;
	prnlp->SetLanguageName(rgch, cchLang);
	prnlp->SetEthCode(sbstrWs.Chars(), sbstrWs.Length());

	return NULL;
}

/*----------------------------------------------------------------------------------------------
	Method to return 0 if the given writing system (encFirst) is not already in (*pvwsd).
	If it is, returns the lowest 4- or 5-character writing system which is not already in the list
	and which begins with the same three letters as ws. Assumes that encFirst (as a string) is
	exactly 3 letters. In this case it also returns the index of the matching entry in (*pvwsd).
	@param encFirst Writing system to look for in (*pvwsd).
	@param piwsd (output) Pointer to index of matching entry in (*pvwsd), if encFirst was found.
	@param pvwsd Pointer to a vector of old writing system definitions.
----------------------------------------------------------------------------------------------*/
int AfNewLangIdentify::SuggestEnc(int encFirst, int * piwsd, const Vector<WrtSysData> * pvwsd)
{
	return -1;					// No alternative is available.
}


//:>********************************************************************************************
//:>	AfNewLangSetup Implementation
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
AfNewLangSetup::~AfNewLangSetup()
{
	if (m_hfontLarge)
	{
		AfGdi::DeleteObjectFont(m_hfontLarge);
		m_hfontLarge = NULL;
	}
}


/*----------------------------------------------------------------------------------------------
	Initialize the dialog in response to the WM_INITDIALOG message.
	All one-time initialization should be done here (that is, all controls have been created
	and have valid hwnd's, but they need initial values.)

	@param hwndCtrl Not used by this method.
	@param lp Not used by this method.

	@return True.
----------------------------------------------------------------------------------------------*/
bool AfNewLangSetup::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	// Set the font for the page title.
	m_hfontLarge = AfGdi::CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET,
		OUT_CHARACTER_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH | FF_SWISS,
		_T("MS Sans Serif"));
	if (m_hfontLarge)
		::SendMessage(::GetDlgItem(m_hwnd, kridNewLangSetupTitle), WM_SETFONT,
			(WPARAM)m_hfontLarge, false);
	StrApp str(kstidNewLangSetupTitle);
	::SetWindowText(::GetDlgItem(m_hwnd, kridNewLangSetupTitle), str.Chars());

	m_strChooseMsgFmt.Load(kstidNewLangChooseLangTextFmt);
	StrApp strUnk(kstidLangUnknown);
	str.Format(m_strChooseMsgFmt.Chars(), strUnk.Chars());
	::SetWindowText(::GetDlgItem(m_hwnd, kctidNewLangChooseLangText), str.Chars());

	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidNewLangChooseLang, kbtPopMenu, NULL, 0);

	// Fill in the font combo boxes.
	// TODO (version 1 or 2?): display font names in their actual fonts.  This requires
	// owner draw at a minimum as far as i can tell.

	AfNewLangDefWizard * prnlp = dynamic_cast<AfNewLangDefWizard *>(m_pwiz);
	Assert(prnlp);
	Vector<StrApp> & vstrFonts = prnlp->FontList();

	HWND hwnd;
	int i;
	int iDef = -1;
	hwnd = ::GetDlgItem(m_hwnd, kctidNewLangNormalFont);
	StrApp strDefault("Times New Roman");
	for (i = 0; i < vstrFonts.Size(); ++i)
	{
		::SendMessage(hwnd, CB_ADDSTRING, 0, (LPARAM)vstrFonts[i].Chars());
		if (vstrFonts[i] == strDefault)
			iDef = i;
	}
	if (iDef == -1)
		iDef = 0;
	::SendMessage(hwnd, CB_SETCURSEL, iDef, 0);

	hwnd = ::GetDlgItem(m_hwnd, kctidNewLangHeadingFont);
	strDefault.Assign("Arial");
	iDef = -1;
	for (i = 0; i < vstrFonts.Size(); ++i)
	{
		::SendMessage(hwnd, CB_ADDSTRING, 0, (LPARAM)vstrFonts[i].Chars());
		if (vstrFonts[i] == strDefault)
			iDef = i;
	}
	if (iDef == -1)
		iDef = 0;
	::SendMessage(hwnd, CB_SETCURSEL, iDef, 0);

	// TODO (Version 2?): Add explicit handling for KeyMan setup.
	::ShowWindow(::GetDlgItem(m_hwnd, kctidNewLangKeymanText), SW_HIDE);
	::ShowWindow(::GetDlgItem(m_hwnd, kctidNewLangKeymanSetup), SW_HIDE);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Handle a WM_NOTIFY message, first letting the superclass method handle it if possible.

	@param ctidFrom Identifies the control sending the message.
	@param pnmh Pointer to the notification message data.
	@param lnRet Reference to a long integer return value used by some messages.

	@return True if the message is handled successfully; otherwise, false.
----------------------------------------------------------------------------------------------*/
bool AfNewLangSetup::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (SuperClass::OnNotifyChild(ctidFrom, pnmh, lnRet))
		return true;

	switch (pnmh->code)
	{
	case BN_CLICKED:
		if (ctidFrom == kctidNewLangChooseLang)
		{
			// Show the popup menu that allows a user to choose the language.
			AfNewLangDefWizard * prnlp =
				dynamic_cast<AfNewLangDefWizard *>(m_pwiz);
			Assert(prnlp);
			Rect rc;
			::GetWindowRect(::GetDlgItem(m_hwnd, kctidNewLangChooseLang), &rc);
			AfApp::GetMenuMgr()->SetMenuHandler(kcidNewLangLanguagePopupMenu);
			::TrackPopupMenu(prnlp->LanguageMenu(), TPM_LEFTALIGN | TPM_RIGHTBUTTON,
				rc.left, rc.bottom, 0, m_hwnd, NULL);
			return true;
		}
		else if (ctidFrom == kctidNewLangKeymanSetup)
		{
#if 8
			::MessageBoxA(m_hwnd, "NOT YET IMPLEMENTED", "DEBUG", MB_OK | MB_ICONWARNING);
#endif
			return true;
		}
		break;
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Fix the "choose language" text to reflect the chosen language name.

	@return True if the page was successfully set active; otherwise false.
----------------------------------------------------------------------------------------------*/
bool AfNewLangSetup::OnSetActive()
{
	AfNewLangDefWizard * prnlp = dynamic_cast<AfNewLangDefWizard *>(m_pwiz);
	Assert(prnlp);

	StrApp str;
	str.Format(m_strChooseMsgFmt.Chars(), prnlp->LanguageName());
	::SetWindowText(::GetDlgItem(m_hwnd, kctidNewLangChooseLangText), str.Chars());

	if (prnlp->LocaleId() == 0)
		m_pwiz->EnableNextButton(false);

	const StrApp strNormal = prnlp->NormalFont();
	if (strNormal.Length())
	{
	}
	const StrApp strHeading = prnlp->HeadingFont();
	if (strHeading.Length())
	{
	}

	return true;
}

/*----------------------------------------------------------------------------------------------
	Retrieve the names of the selected fonts.

	@return true.
----------------------------------------------------------------------------------------------*/
bool AfNewLangSetup::OnWizardFinish()
{
	AfNewLangDefWizard * prnlp = dynamic_cast<AfNewLangDefWizard *>(m_pwiz);
	Assert(prnlp);
	prnlp->SetNormalFont(::SendMessage(::GetDlgItem(m_hwnd, kctidNewLangNormalFont),
		CB_GETCURSEL, 0, 0));
	prnlp->SetHeadingFont(::SendMessage(::GetDlgItem(m_hwnd, kctidNewLangHeadingFont),
		CB_GETCURSEL, 0, 0));
	return true;
}

/*----------------------------------------------------------------------------------------------
	Handle a popup menu command for choosing the desired language.

	@param pcmd Pointer to the command information.

	@return True.
----------------------------------------------------------------------------------------------*/
bool AfNewLangSetup::CmdLangPopup(Cmd * pcmd)
{
	AssertPtr(pcmd);
	Assert(pcmd->m_rgn[0] == AfMenuMgr::kmaDoCommand);

	// The user selected an expanded menu item, so perform the command now.
	//    m_rgn[1] holds the menu handle.
	//    m_rgn[2] holds the index of the selected item.

	AfNewLangDefWizard * prnlp = dynamic_cast<AfNewLangDefWizard *>(m_pwiz);
	Assert(prnlp);
	int ilang = pcmd->m_rgn[2];
	SysLangInfo & lcinf = prnlp->InstalledLanguage(ilang);
	::SetWindowText(::GetDlgItem(m_hwnd, kctidNewLangChooseLang), lcinf.m_strName.Chars());
	prnlp->SetLocaleId(lcinf.m_lcid);
	m_pwiz->EnableNextButton(true);

	return true;
}
