// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Form1.cs
// Responsibility: RandyR
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using SIL.FieldWorks.LexTools;
using SIL.FieldWorks.Common.Framework;
using SIL.FieldWorks.Common.Controls.Design;
using SIL.FieldWorks.Common.Controls;
using SIL.FieldWorks.Common.Drawing;
using SIL.FieldWorks.FDO;

namespace DemoApp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private InterlinearWordform m_wf;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Initializes a new instance of the Form1 class.
		/// </summary>
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			AddWordformView();
		}

		/// <summary>
		/// Initializes a new instance of the Form1 class.
		/// </summary>
		public Form1(FdoCache cache)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			AddWordformView();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		private void AddWordformView()
		{
			// Set up the interlinear view
			m_wf = new SIL.FieldWorks.LexTools.InterlinearWordform();
			SuspendLayout();
			// 
			// myView
			// 
			m_wf.BackColor = System.Drawing.SystemColors.Window;
			m_wf.ForeColor = System.Drawing.SystemColors.WindowText;
			m_wf.Location = new System.Drawing.Point(16, 32); // Review JohnT: compute from container info?
			m_wf.Name = "InterlinearView";
			m_wf.Size = new System.Drawing.Size(232, 192); // Review JohnT: compute from container info?
			m_wf.TabIndex = 0;
			// 
			// Main window (after contained view, following model of HellowView; maybe so
			// we get an appropriate OnSize for the contained view when sizing the main one?
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			// JohnT: Don't really understand this...copied from HelloView.
			this.Controls.AddRange(new System.Windows.Forms.Control[] {m_wf});
			this.Name = "InterlinSample";
			this.Text = "InterlinSample";

			this.ResumeLayout(false);

		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Name = "Form1";
			this.Text = "Form1";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			using (FdoCache cache = FdoCache.Create())
			{
				Application.Run(new Form1(cache));
			}
		}
	}
}
