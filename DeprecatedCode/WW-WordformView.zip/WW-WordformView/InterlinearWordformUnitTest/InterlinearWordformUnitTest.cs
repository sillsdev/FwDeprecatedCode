// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Class1.cs
// Responsibility: RandyR
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;

namespace InterlinearWordformUnitTest
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class InterlinearWordformUnitTest
	{
		public InterlinearWordformUnitTest()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
