// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: InterlinearWordform.cs
// Responsibility: RandyR
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Framework;
using SIL.FieldWorks.Common.Controls.Design;
using SIL.FieldWorks.Common.Controls;
using SIL.FieldWorks.Common.Drawing;

namespace SIL.FieldWorks.LexTools
{
	/// <summary>
	/// Summary description for InterlinearWordform.
	/// </summary>
	public class InterlinearWordform : RootSite// System.Windows.Forms.UserControl	//RootSite
	{
		protected FdoCache m_cache;
		private System.Windows.Forms.Label label1;

		public const int ktagWord_Form = 99;
		public const int ktagWord_Type = 98;
		public const int ktagText_Words = 97;
		public const int khvoText = 1000;
		public const int kfrText = 1;
		public const int kfrWord = 2;

		// Words have hvo's from  1 upwards to the number of words.
		private InterlinearVc m_iVc;
		// Combo box appears when annotation clicked.
		private FwOverrideComboBox typeComboBox;
		private int hvoObjSelected = 0; // object selected for combo box.
		private bool fCacheCreated = false;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public InterlinearWordform()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			Cache = FDO.FdoCache.Create();
			fCacheCreated = true;

		}

		/// <summary>
		/// Initializes a new instance of the Form1 class.
		/// </summary>
		public InterlinearWordform(FdoCache cache)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			Cache = cache;
		}

		protected override void OnLoad(EventArgs e)
		{
			if (DesignMode)
				return;
			// We don't really use a database, but for some reason RootSite
			// requires to have one, so we take the first database that we
			// find. In real code you would create the FdoCache in the calling
			// class (usually the Form).
//				Cache = FDO.FdoCache.Create();
		}

		/// <summary>
		/// Must be called, before using InterlinearWordform.
		/// </summary>
		/// <param name="cache">The FDO cache.</param>
		public void Init(FdoCache cache)
		{
			Debug.Assert(cache != null);
			if (m_cache != null && fCacheCreated)
			{
				m_cache.Dispose();
				fCacheCreated = false;
			}
			m_cache = cache;
			label1.Text = cache.DatabaseName;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			//Debug.WriteLineIf(!disposing, "****************** " + GetType().Name + " 'disposing' is false. ******************");
			// Must not be run more than once.
			if (IsDisposed)
				return;

			if (m_rootb != null)
			{
				CloseRootBox();
				m_rootb = null;
			}
			if( disposing )
			{
				if( components != null )
					components.Dispose();

				if (fCacheCreated)
					m_cache.Dispose();
				if (m_iVc != null)
					m_iVc.Dispose();
				if (typeComboBox != null && !Controls.Contains(typeComboBox))
					typeComboBox.Dispose();
			}
			typeComboBox = null;
			m_cache = null;
			m_iVc = null;

			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 40);
			this.label1.Name = "label1";
			this.label1.TabIndex = 0;
			this.label1.Text = "Hello, John.";
			// 
			// InterlinearWordform
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label1});
			this.Name = "InterlinearWordform";
			this.ResumeLayout(false);

		}
		#endregion
	


	
	#region Windows message handling methods
			protected override void OnSizeChanged(EventArgs e)
			{
				base.OnSizeChanged(e);

				if (DesignMode)
					return;

				// Recompute your layout and redraw completely, unless the width has not actually changed.
				InitGraphics();
				if (DoLayout())
					Invalidate();	
				UninitGraphics();
			}
		#endregion
			public override void MakeSelectionVisible(IVwSelection sel)
			{
			}

			public override bool IsSelectionVisible(IVwSelection sel, bool fTestSecondary)
			{
				return false;
			}

			public override void MakeRoot(IVwGraphics vg, ILgWritingSystemFactory wsfParam, out IVwRootBox rootbParam)
			{
				rootbParam = null;

				// JohnT: this is a convenient though somewhat unconventional place to create and partly
				// initialize the combo box. We can't set its position yet, as that depends on what the user
				// clicks. Nor do we yet add it to our list of windows, nor make it visible.
				typeComboBox = new FwOverrideComboBox();
				typeComboBox.Items.AddRange(new object[] {"sal", "noun", "verb", "det", "adj", "adv"});
				typeComboBox.DropDownWidth = 280; // Todo JohnT: make right for showing all options
				typeComboBox.SelectedValueChanged += new EventHandler(this.HandleComboSelChange);

				base.MakeRoot(vg, wsfParam, out rootbParam);

				if (m_fdoCache == null || DesignMode)
					return;

				IVwRootBox rootb = (IVwRootBox)new FwViews.VwRootBoxClass();
				rootb.SetSite(this);

				int hvoRoot = khvoText;

				// Set up sample data (not in the database for now)
				ITsStrFactory tsf = (ITsStrFactory)new FwKernelLib.TsStrFactoryClass();
				int wsDefAnal = m_fdoCache.LanguageProject.DefaultAnalysisWritingSystem;
				string[] words = {"Hello","world!","This","is","an","interlinear","view"};
				string[] wordtypes = {"sal","noun","det","verb","det","adj","noun"};
				int[] rghvoWords = new int[(words.Length)];
				for (int i = 0; i < words.Length; ++i)
				{
					ITsString tss = tsf.MakeString(words[i], wsDefAnal);
					// Use i+1 as the HVO for the word objects. Avoid using 0 as an HVO
					m_fdoCache.VwCacheDaAccessor.CacheStringProp(i + 1, ktagWord_Form, tss);
					tss = tsf.MakeString(wordtypes[i], wsDefAnal);
					// Use i+1 as the HVO for the word objects. Avoid using 0 as an HVO
					m_fdoCache.VwCacheDaAccessor.CacheStringProp(i + 1, ktagWord_Type, tss);
					rghvoWords[i] = i + 1;
				}
				m_fdoCache.VwCacheDaAccessor.CacheVecProp(khvoText, ktagText_Words, rghvoWords, rghvoWords.Length);

				int frag = kfrText;
				m_iVc = new InterlinearVc();

				if (wsfParam != null)
					m_fdoCache.MainCacheAccessor.set_WritingSystemFactory(wsfParam);

				rootb.set_DataAccess(m_fdoCache.MainCacheAccessor);

				rootb.SetRootObject(hvoRoot, m_iVc, frag, null);
				rootbParam = rootb;
			}
			// Handles a change in the item selected in the combo box
			void HandleComboSelChange(object sender, EventArgs ea)
			{
				ITsString tss = m_fdoCache.GetTsStringProperty(hvoObjSelected, ktagWord_Type);
				string str = tss.get_Text();
				if (str != typeComboBox.SelectedItem.ToString())
				{
					ITsStrFactory tsf = (ITsStrFactory)new FwKernelLib.TsStrFactoryClass();
					string strEng = "en";
					int wsEng =
						m_fdoCache.LanguageWritingSystemFactoryAccessor.GetWsFromStr(strEng);
					tss = tsf.MakeString(typeComboBox.SelectedItem.ToString(), wsEng);
					// Enhance JohnT: for a real property, we would use another method that really sets
					// it in the database.
					m_fdoCache.VwCacheDaAccessor.CacheStringProp(hvoObjSelected, ktagWord_Type, tss);
					m_fdoCache.PropChanged(null, FwViews.PropChangeType.kpctNotifyAll, hvoObjSelected, ktagWord_Type, 0, 0, 0);
				}
			}

			// Handles a change in the view selection.
			public override void SelectionChanged(IVwRootBox rootb, IVwSelection vwselNew)
			{
				base.SelectionChanged(rootb, vwselNew);
				// Figure what property is selected and display combo only if relevant.
				SIL.FieldWorks.Common.COMInterfaces.ITsString tss;
				int ich, tag, ws;
				bool fAssocPrev;
				vwselNew.TextSelInfo(true, out tss, out ich, out fAssocPrev, out hvoObjSelected, out tag, out ws);
				string str = tss.get_Text();
				if (tag == ktagWord_Type)
				{
					// Display combo at selection
					SIL.FieldWorks.Common.COMInterfaces.Rect loc;
					vwselNew.GetParaLocation(out loc);
					typeComboBox.Location = new System.Drawing.Point(loc.left, loc.top);
					// 60 is an arbitrary minimum size to make the current contents visible.
					// Enhance JohnT: figure the width needed by the widest string, add width of arrow, use that
					// as minimum
					typeComboBox.Size = new System.Drawing.Size(Math.Max(loc.right - loc.left, 60), loc.bottom - loc.top);
					typeComboBox.Text = str;
					// This also makes it visible.
					this.Controls.Add(typeComboBox);
				}
				else
				{
					// Hide combo if visible.
					// Enhance JohnT: possibly also remove on loss of focus?
					if (this.Controls.Contains(typeComboBox))
					{
						this.Controls.Remove(typeComboBox);
					}
				}
				// Todo JohnT: make something interesting happen when a selection is made.
			}
		}
	}
