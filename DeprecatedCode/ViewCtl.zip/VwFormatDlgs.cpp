/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: VwFormatDlgs.cpp
Responsibility: John Thomson
Last reviewed: never

Description:
	An implementation of DIVwFormatDlgs, which can launch the FieldWorks format dialogs
	in various ways.
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop
#undef THIS_FILE
DEFINE_THIS_FILE
/***********************************************************************************************
    Forward declarations
***********************************************************************************************/

/***********************************************************************************************
    Local Constants and static variables
***********************************************************************************************/
/***********************************************************************************************
    Constructor/Destructor
***********************************************************************************************/

VwFormatDlgs::VwFormatDlgs()
{
	m_cref = 1;
	ModuleEntry::ModuleAddRef();
}

VwFormatDlgs::~VwFormatDlgs() {
	ModuleEntry::ModuleRelease();
}

/***********************************************************************************************
    IUnknown Methods
***********************************************************************************************/
STDMETHODIMP VwFormatDlgs::QueryInterface(REFIID riid, void **ppv)
{
	if (!ppv)
		return E_POINTER;
	AssertPtr(ppv);
	*ppv = NULL;
	if (riid == IID_IUnknown)
		*ppv = static_cast<IUnknown *>(this);
	else if (riid == IID_IDispatch)
		*ppv = static_cast<IDispatch *>(this);
	else if (riid == IID_DIVwFormatDlgs)
		*ppv = static_cast<DIVwFormatDlgs *>(this);
	else
		return E_NOINTERFACE;
	AddRef();
	return NOERROR;
}

/***********************************************************************************************
    Generic factory stuff to allow creating an instance with CoCreateInstance.
***********************************************************************************************/
static GenericFactory g_factVps(
	_T("SIL.Views.VwFormatDlgs"),	
	&CLSID_VwFormatDlgs,	
	_T("SIL Format Dialog launcher"),
	_T("Apartment"),
	&VwFormatDlgs::CreateCom);


void VwFormatDlgs::CreateCom(IUnknown *punkCtl, REFIID riid, void ** ppv)
{
	AssertPtr(ppv);
	Assert(!*ppv);
	if (punkCtl)
		ThrowHr(WarnHr(CLASS_E_NOAGGREGATION));

	ComSmartPtr<VwFormatDlgs> qvfd;
	qvfd.Attach(NewObj VwFormatDlgs());		// ref count initialy 1
	CheckHr(qvfd->QueryInterface(riid, ppv));
}

/*----------------------------------------------------------------------------------------------
	Launch the Font dialog and, if the user clicks OK, apply the results
	to the selection. The selection is also used to get initial values
	for the controls in the dialog.
	Todo JohnT: make the argument a real IVwSelection when we change
	that to a dual interface.
	
	Arguments: 
		 psel				  must be IVwSelection
----------------------------------------------------------------------------------------------*/
STDMETHODIMP VwFormatDlgs::ApplyFontDialog(IUnknown * psel)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(psel);

	IVwSelectionPtr qvwsel;
	psel->QueryInterface(IID_IVwSelection, (void **)&qvwsel);

	TtpVec vqttp;
	VwPropsVec vqvps;
	int cttp;
	CheckHr(qvwsel->GetSelectionProps(0, NULL, NULL, &cttp));
	if (!cttp)
		// No text selected.
		return E_FAIL;
	vqttp.Resize(cttp);
	vqvps.Resize(cttp);
	CheckHr(qvwsel->GetHardAndSoftCharProps(cttp, (ITsTextProps **)vqttp.Begin(),
		(IVwPropertyStore **)vqvps.Begin(), &cttp));

	ILgWritingSystemFactoryPtr qwsf;
	// get_WritingSystemFactory(&qwsf)

	if (FmtFntDlg::AdjustTsTextProps(::GetFocus(), vqttp, vqvps, qwsf))
	{
		// Some change was made.
		CheckHr(qvwsel->SetSelectionProps(cttp,(ITsTextProps **)vqttp.Begin()));
	}
	return S_OK;

	END_COM_METHOD(g_factVps, IID_IDispatch);
}
