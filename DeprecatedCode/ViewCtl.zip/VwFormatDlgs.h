/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: VwFormatDlgs.h
Responsibility: John Thomson
Last reviewed: never

Description:
	Implementation of the VwFormatDlgs interface for running the format dialogs in various
	ways.
	Note: this class could reasonably be a singleton. But, creating one is not
	a high-frequency operation, and singletons are a nuisance because it is hard
	to prevent spurious memory leaks.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef VWFORMATDLGS_INCLUDED
#define VWFORMATDLGS_INCLUDED 1

class VwFormatDlgs :
	public IDispatchImpl<DIVwFormatDlgs, &IID_DIVwFormatDlgs, &LIBID_VIEWCTLLib>
{
public:
	// Static methods

	// Constructors/destructors/etc.
	VwFormatDlgs();
	virtual ~VwFormatDlgs();
	static void CreateCom(IUnknown *punkCtl, REFIID riid, void ** ppv);

	// Member variable access

	// Other public methods

	// IUnknown methods
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppv);
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return InterlockedIncrement(&m_cref);
	}
	STDMETHOD_(ULONG, Release)(void)
	{
		long cref = InterlockedDecrement(&m_cref);
		if (cref == 0) {
			m_cref = 1;
			delete this;
		}
		return cref;
	}

	// DIVwFormatDlgs methods.
	STDMETHOD(ApplyFontDialog)(IUnknown * psel);

protected:
	// Member variables
	long m_cref;

};

#endif // !VWFORMATDLGS_INCLUDED