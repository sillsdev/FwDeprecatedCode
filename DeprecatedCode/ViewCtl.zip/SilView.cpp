// SilView.cpp : Implementation of CSilView

#include "main.h"

// Dummy factory for END_COM_METHOD macro. (Although SilView can be created using
// CoCreateInstance, we don't have our standard factory because the creation is handled
// by ATL code.
static DummyFactory g_fact(_T("Sil.ViewCtl.SilView"));

/////////////////////////////////////////////////////////////////////////////
// CSilView

/*----------------------------------------------------------------------------------------------
	Return the selection of the embedded view.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP CSilView::get_Selection(IVwSelection ** ppsel)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(ppsel);

	if (m_qrootb)
	{
		return m_qrootb->get_Selection(ppsel);
	}
	return S_OK;

	END_COM_METHOD(g_fact, IID_IPersistStreamInit);
}


/*----------------------------------------------------------------------------------------------
	This is a dummy MakeRoot...that is all it does. A real client should initialize it by
	calling putref_DataAccess and SetRootObject (or similar).
----------------------------------------------------------------------------------------------*/
void CSilView::MakeRoot(IVwGraphics * pvg, ILgWritingSystemFactory * pwsf, IVwRootBox ** pprootb)
{
	ChkComArgPtrN(pwsf);
	ChkComOutPtr(pprootb);

	StrUni stuText(L"An uninitialized control");

	IVwRootBoxPtr qrootb;
	qrootb.CreateInstance(CLSID_VwRootBox);
	CheckHr(qrootb->SetSite(this)); // pass root site
	ITsStrFactoryPtr qtsf;
	qtsf.CreateInstance(CLSID_TsStrFactory);
	ITsStringPtr qtss;
	CheckHr(qtsf->MakeStringRgch(stuText.Chars(), stuText.Length(),
		StrUtil::ParseWs(L"ENG"), &qtss));
	WpDaPtr qsda;
	qsda.Attach(NewObj WpDa);
	qsda->InitNewEmpty();
	CheckHr(qsda->CacheStringProp(khvoParaMin, kflidStTxtPara_Contents, qtss));
	if (pwsf)
		CheckHr(qsda->putref_WritingSystemFactory(pwsf));
	qrootb->putref_DataAccess(qsda);
	StVcPtr qstvc;
	qstvc.Attach(NewObj StVc);
	CheckHr(qrootb->putref_DataAccess(qsda));
	CheckHr(qrootb->SetRootObject(khvoText, qstvc, kfrText, NULL));

	*pprootb = qrootb;
	(*pprootb)->AddRef();
}

/*----------------------------------------------------------------------------------------------
	Return the root box (create an empty one if necessary).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP CSilView::get_RootBox(IVwRootBox ** pprootb)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pprootb);

	if (!m_qrootb)
		m_qrootb.CreateInstance(CLSID_VwRootBox);
	*pprootb = m_qrootb;
	(*pprootb)->AddRef();

	return S_OK;

	END_COM_METHOD(g_fact, IID_IPersistStreamInit);
}

/*----------------------------------------------------------------------------------------------
	Handle window painting (WM_PAINT). If the root box is property initialized do the default
	thing, otherwise, put a dummy message.
----------------------------------------------------------------------------------------------*/
HRESULT CSilView::OnDrawAdvanced(ATL_DRAWINFO& di)
{
	HDC hdc = di.hdcDraw;
	bool fMetafile = GetDeviceCaps(di.hdcDraw, TECHNOLOGY) == DT_METAFILE;
	Rect rc(di.prcBounds->left, di.prcBounds->top, di.prcBounds->right,
		di.prcBounds->bottom);
	HoldGraphics hg(this, hdc);
	HDC hdcMeasure;
	if (fMetafile)
	{
		// Need another DC for measurements. Note that we can't use CreateCompatibleDC;
		// it returns NULL when the source DC is a metafile.
		hdcMeasure = ::CreateDC(_T("DISPLAY"), NULL, NULL, NULL);
		// Now try to make it compatible in the relevant senses, at least. (Font will be
		// handled within the VwGraphics.)
		::SetMapMode(hdcMeasure,::GetMapMode(hdc));
		SIZE size;
		::GetWindowExtEx(hdc, &size);
		::SetWindowExtEx(hdcMeasure, size.cx, size.cy, NULL);
		::GetViewportExtEx(hdc, &size);
		::SetViewportExtEx(hdcMeasure, size.cx, size.cy, NULL);
		IVwGraphicsWin32Ptr qvwg;
		CheckHr(hg.m_pvg->QueryInterface(IID_IVwGraphicsWin32, (void **) &qvwg));
		qvwg->FwSetMeasureDc(hdcMeasure);
		qvwg->FwSetClipRect(&rc);
	}
	ISilDataAccessPtr qsda;
	if (m_qrootb)
		CheckHr(m_qrootb->get_DataAccess(&qsda));
	if (!qsda)
	{
		// It hasn't been initialized properly by the container; assume being
		// embedded in a non-aware container; create a root box initialized
		// for WorldPad type data.
		MakeRoot(hg.m_pvg, NULL, &m_qrootb);
	}
	// Todo JohnT: figure whether adjustment is needed for zoom.
	int dxdAvailWidth = rc.Width();
	if (dxdAvailWidth != m_dxdLayoutWidth)
	{
		m_dxdLayoutWidth = dxdAvailWidth;
		// If we have less than 1 point, probably the window has not received its initial
		// OnSize message yet, and we can't do a meaningful layout.
		if (m_dxdLayoutWidth < 2)
		{
			m_dxdLayoutWidth = -50000; // No drawing until we get reasonable size.
			return true;
		}
		if (FAILED(m_qrootb->Layout(hg.m_pvg, dxdAvailWidth)))
		{
			Warn("Root box layout failed");
			m_dxdLayoutWidth = -50000; // No drawing until we get successful layout.
			return true;
		}
		//UpdateScrollRange();  Should we have this? JohnT
	}

	//AfVwRootSite::Draw(hdc, rc);

	// Using Draw bypasses all the tricks we did to allow for a metafile DC.
	// Using the following block instead skips all the preparation for lazy drawing.
	// Hence at present the control can't handle lazy displays.
	{
		if (!fMetafile)
			AfGfx::FillSolidRect(hdc, rc, GetWindowColor());
		CheckHr(m_qrootb->DrawRoot(m_qvg, rc, rc, true));

		HRESULT hr = m_qrootb->DrawingErrors();
		if (FAILED(hr))
			GiveDrawErrMsg(false);
	}

	if (hdcMeasure)
		::ReleaseDC(NULL, hdcMeasure);

	//::DrawText(hdc, _T("ViewCtl"), -1, &rc, DT_SINGLELINE | DT_VCENTER | DT_CENTER);

	return true;
}

#if 0
inline HRESULT CComControlBase::OnDrawAdvanced(ATL_DRAWINFO& di)
{
	BOOL bDeleteDC = FALSE;
	if (di.hicTargetDev == NULL)
	{
		di.hicTargetDev = AtlCreateTargetDC(di.hdcDraw, di.ptd);
		bDeleteDC = (di.hicTargetDev != di.hdcDraw);
	}
	RECTL rectBoundsDP = *di.prcBounds;
	BOOL bMetafile = GetDeviceCaps(di.hdcDraw, TECHNOLOGY) == DT_METAFILE;
	if (!bMetafile)
	{
		::LPtoDP(di.hicTargetDev, (LPPOINT)&rectBoundsDP, 2);
		SaveDC(di.hdcDraw);
		SetMapMode(di.hdcDraw, MM_TEXT);
		SetWindowOrgEx(di.hdcDraw, 0, 0, NULL);
		SetViewportOrgEx(di.hdcDraw, 0, 0, NULL);
		di.bOptimize = TRUE; //since we save the DC we can do this
	}
	di.prcBounds = &rectBoundsDP;
	GetZoomInfo(di);

	HRESULT hRes = OnDraw(di);
	if (bDeleteDC)
		::DeleteDC(di.hicTargetDev);
	if (!bMetafile)
		RestoreDC(di.hdcDraw, -1);
	return hRes;
}
#endif
/*----------------------------------------------------------------------------------------------
	Handle window painting (WM_PAINT). If the root box is property initialized do the default
	thing, otherwise, put a dummy message.
----------------------------------------------------------------------------------------------*/
bool CSilView::OnPaint(HDC hdcDef)
{
	int nRet;
	CComControlBase::OnPaint(WM_PAINT, (WPARAM)hdcDef, 0, nRet);
	return true;
}

WpDa * CSilView::GetWpDa()
{
	if (!m_qrootb)
		return NULL;
	ISilDataAccessPtr qsda;
	CheckHr(m_qrootb->get_DataAccess(&qsda));
	//  Todo JohnT: neater would be the QI trick for checking on an implementation.
	return dynamic_cast<WpDa *>(qsda.Ptr());
}

STDMETHODIMP CSilView::IsDirty()
{
	BEGIN_COM_METHOD
	// See if the base implementation knows we are dirty
	HRESULT hr = IPersistStreamInitImpl<CSilView>::IsDirty();
	if (hr != S_FALSE)
		return hr; // any error or if it is dirty.
	// See if we have a WpDa. If not we can't implement properly.
	WpDa * powsda = GetWpDa();
	if (!powsda)
		return S_OK; // not dirty, at least in any way we can tell. (Should we use E_NOTIMPL?)
	return powsda->IsDirty() ? S_OK : S_FALSE;

	END_COM_METHOD(g_fact, IID_IPersistStreamInit);
}

STDMETHODIMP CSilView::Load(LPSTREAM pstrm)
{
	BEGIN_COM_METHOD
	HRESULT hr = IPersistStreamInitImpl<CSilView>::Load(pstrm);
	if (FAILED(hr))
		return hr; // Todo JohnT: ensure error info if possible
	if (!m_qrootb)
	{
		HoldGraphics hg(this);
		MakeRoot(hg.m_pvg, NULL, &m_qrootb);
	}
	WpDa * powsda = GetWpDa();
	if (!powsda)
		return E_NOTIMPL; // Can't load if not in WorldPad mode.
	// Enhance JohnT: possibly we could switch to WorldPad mode in such a case?
	int fls; // JohnT: what is this!?
	powsda->LoadXmlStream(pstrm, &fls);
	if (m_dxdLayoutWidth > 0)
	{
		// Re-loading, it has been laid out before.
		m_qrootb->Reconstruct(); // Enhance JohnT: is this needed?
	}

	END_COM_METHOD(g_fact, IID_IPersistStreamInit);
}

STDMETHODIMP CSilView::Save(LPSTREAM pstrm, BOOL fClearDirty)
{
	BEGIN_COM_METHOD
	WpDa * powsda = GetWpDa();
	if (!powsda)
		return E_NOTIMPL; // Can't save if not in WorldPad mode.
	HRESULT hr = IPersistStreamInitImpl<CSilView>::Save(pstrm, fClearDirty);
	if (FAILED(hr))
		return hr; // Todo JohnT: ensure error info if possible
	powsda->SaveXmlStream(pstrm);

	if (fClearDirty)
		powsda->ClearChanges();

	END_COM_METHOD(g_fact, IID_IPersistStreamInit);
}

/*----------------------------------------------------------------------------------------------
	Show the right-click menu.
	@param hwnd Handle to the window over which the mouse was right-clicked.
	@param pt Mouse location in screen coordinates  (or -1, -1 if launched from keyboard).
	@return true to prevent the message from being sent to other windows.
----------------------------------------------------------------------------------------------*/
bool CSilView::OnContextMenu(HWND hwnd, Point pt)
{
	WpDa * powsda = GetWpDa();
	if (!powsda)
		return false; // Can't do any meaningful context menu yet
	// Make sure all currently known encodings are in the writing system factory.
	powsda->InitWithWsInRegistry();

	HMENU hmenuPopup = ::CreatePopupMenu();

	HMENU hmenuLang = ::CreatePopupMenu();

	StrApp str;

	ILgWritingSystemFactoryPtr qwsf;
	qwsf.CreateInstance(CLSID_LgWritingSystemFactory);		// BOGUS??  uses registry version!!
	int cws;
	CheckHr(qwsf->get_NumberOfWs(&cws));
	Vector<int> vws;
	vws.Resize(cws);
	CheckHr(qwsf->GetWritingSystems(vws.Begin()));
	int encUI = StrUtil::ParseWs("ENG"); // Todo JohnT: something resource based.
	for (int iws = 0; iws < cws; iws++)
	{
		ILgWritingSystemPtr qws;
		CheckHr(qwsf->get_EngineOrNull(vws[iws], &qws));
		if (!qws)
			continue;

		SmartBstr sbstr;
		CheckHr(qws->get_UiName(encUI, &sbstr));
		if (!sbstr)
			continue;
		str = sbstr.Chars();
		// +1 is used because 0 is returned if the user cancels
		::AppendMenu(hmenuLang, MF_STRING, (uint)iws + 1, str.Chars());
	}

	str = "Language"; // str.Load(kstidLanguage);
	::AppendMenu(hmenuPopup, MF_POPUP, (uint) hmenuLang, str.Chars());
	str = "Paste"; // str.Load(kstid...);
	::AppendMenu(hmenuPopup, MF_STRING, 10000, str.Chars());

	int nCmd = TrackPopupMenu(hmenuPopup,
		TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_NONOTIFY | TPM_RETURNCMD,
		pt.x, pt.y, 0, m_hwnd, NULL);
	::DestroyMenu(hmenuPopup);

	if (nCmd == 0)
		return true;
	if (nCmd == 10000)
	{
		Cmd cmd(kcidEditPaste);
		return CmdEditPaste(&cmd);
	}

	int encNew = vws[nCmd - 1];
	TtpVec vqttp;
	VwPropsVec vqvps;
	IVwSelectionPtr qvwsel;
	if (!GetCharacterProps(&qvwsel, vqttp, vqvps))
		return true; // nothing we can do
	ApplyWritingSystem(vqttp, encNew, qvwsel);

	return true;
}
