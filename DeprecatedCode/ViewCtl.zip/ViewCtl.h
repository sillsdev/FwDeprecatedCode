/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Dec 25 23:35:02 2000
 */
/* Compiler settings for c:\fw\Src\ViewCtl\ViewCtl.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __ViewCtl_h__
#define __ViewCtl_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __SilView_FWD_DEFINED__
#define __SilView_FWD_DEFINED__

#ifdef __cplusplus
typedef class SilView SilView;
#else
typedef struct SilView SilView;
#endif /* __cplusplus */

#endif 	/* __SilView_FWD_DEFINED__ */


#ifndef __ISilView_FWD_DEFINED__
#define __ISilView_FWD_DEFINED__
typedef interface ISilView ISilView;
#endif 	/* __ISilView_FWD_DEFINED__ */


#ifndef __DIVwFormatDlgs_FWD_DEFINED__
#define __DIVwFormatDlgs_FWD_DEFINED__
typedef interface DIVwFormatDlgs DIVwFormatDlgs;
#endif 	/* __DIVwFormatDlgs_FWD_DEFINED__ */


#ifndef __VwFormatDlgs_FWD_DEFINED__
#define __VwFormatDlgs_FWD_DEFINED__

#ifdef __cplusplus
typedef class VwFormatDlgs VwFormatDlgs;
#else
typedef struct VwFormatDlgs VwFormatDlgs;
#endif /* __cplusplus */

#endif 	/* __VwFormatDlgs_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_ViewCtl_0000 */
/* [local] */ 


#undef ATTACH_GUID_TO_CLASS
#if defined(__cplusplus)
#define ATTACH_GUID_TO_CLASS(type, guid, cls) \
	type __declspec(uuid(#guid)) cls;
#else // !defined(__cplusplus)
#define ATTACH_GUID_TO_CLASS(type, guid, cls)
#endif // !defined(__cplusplus)

#ifndef DEFINE_COM_PTR
#define DEFINE_COM_PTR(cls)
#endif

#undef GENERIC_DECLARE_SMART_INTERFACE_PTR
#define GENERIC_DECLARE_SMART_INTERFACE_PTR(cls, iid) \
	ATTACH_GUID_TO_CLASS(interface, iid, cls); \
	DEFINE_COM_PTR(cls);


#ifndef CUSTOM_COM_BOOL
typedef VARIANT_BOOL ComBool;

#endif

#if 0
// This is so there is an equivalent VB type.
typedef CY SilTime;

#elif defined(SILTIME_IS_STRUCT)
// This is for code that compiles UtilTime.*.
struct SilTime;
#else
// This is for code that uses a 64-bit integer for SilTime.
typedef __int64 SilTime;
#endif

ATTACH_GUID_TO_CLASS(class,
F7DC6325-7613-4DB8-AC71-23B2D206C418
,
VIEWCTLLib
);


extern RPC_IF_HANDLE __MIDL_itf_ViewCtl_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_ViewCtl_0000_v0_0_s_ifspec;


#ifndef __VIEWCTLLib_LIBRARY_DEFINED__
#define __VIEWCTLLib_LIBRARY_DEFINED__

/* library VIEWCTLLib */
/* [helpstring][version][uuid] */ 

GENERIC_DECLARE_SMART_INTERFACE_PTR(
ISilView
,
74AC1730-D8AE-4BA7-BC68-0C5EF4B3960F
);
GENERIC_DECLARE_SMART_INTERFACE_PTR(
DIVwFormatDlgs
,
E6EDB78F-4EDE-4f35-9AD6-C140BF38E4F0
);
ATTACH_GUID_TO_CLASS(class,
A8134A82-60FD-478f-94E3-9E832FFAF908
,
VwFormatDlgs
);

#define LIBID_VIEWCTLLib __uuidof(VIEWCTLLib)

#define CLSID_SilView __uuidof(SilView)

#ifdef __cplusplus

class DECLSPEC_UUID("35EAA757-ADCB-48CD-8FBC-DD632422799C")
SilView;
#endif

#ifndef __ISilView_INTERFACE_DEFINED__
#define __ISilView_INTERFACE_DEFINED__

/* interface ISilView */
/* [object][unique][oleautomation][dual][uuid] */ 


#define IID_ISilView __uuidof(ISilView)

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("74AC1730-D8AE-4BA7-BC68-0C5EF4B3960F")
    ISilView : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Selection( 
            /* [retval][out] */ /* external definition not present */ IVwSelection __RPC_FAR *__RPC_FAR *ppsel) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISilViewVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISilView __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISilView __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISilView __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISilView __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISilView __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISilView __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISilView __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Selection )( 
            ISilView __RPC_FAR * This,
            /* [retval][out] */ /* external definition not present */ IVwSelection __RPC_FAR *__RPC_FAR *ppsel);
        
        END_INTERFACE
    } ISilViewVtbl;

    interface ISilView
    {
        CONST_VTBL struct ISilViewVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISilView_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISilView_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISilView_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISilView_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISilView_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISilView_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISilView_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISilView_get_Selection(This,ppsel)	\
    (This)->lpVtbl -> get_Selection(This,ppsel)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE ISilView_get_Selection_Proxy( 
    ISilView __RPC_FAR * This,
    /* [retval][out] */ /* external definition not present */ IVwSelection __RPC_FAR *__RPC_FAR *ppsel);


void __RPC_STUB ISilView_get_Selection_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISilView_INTERFACE_DEFINED__ */


#ifndef __DIVwFormatDlgs_INTERFACE_DEFINED__
#define __DIVwFormatDlgs_INTERFACE_DEFINED__

/* interface DIVwFormatDlgs */
/* [object][unique][oleautomation][dual][uuid] */ 


#define IID_DIVwFormatDlgs __uuidof(DIVwFormatDlgs)

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E6EDB78F-4EDE-4f35-9AD6-C140BF38E4F0")
    DIVwFormatDlgs : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE ApplyFontDialog( 
            /* [in] */ IUnknown __RPC_FAR *psel) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct DIVwFormatDlgsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DIVwFormatDlgs __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DIVwFormatDlgs __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DIVwFormatDlgs __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DIVwFormatDlgs __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DIVwFormatDlgs __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DIVwFormatDlgs __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DIVwFormatDlgs __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ApplyFontDialog )( 
            DIVwFormatDlgs __RPC_FAR * This,
            /* [in] */ IUnknown __RPC_FAR *psel);
        
        END_INTERFACE
    } DIVwFormatDlgsVtbl;

    interface DIVwFormatDlgs
    {
        CONST_VTBL struct DIVwFormatDlgsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DIVwFormatDlgs_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DIVwFormatDlgs_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DIVwFormatDlgs_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DIVwFormatDlgs_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DIVwFormatDlgs_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DIVwFormatDlgs_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DIVwFormatDlgs_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define DIVwFormatDlgs_ApplyFontDialog(This,psel)	\
    (This)->lpVtbl -> ApplyFontDialog(This,psel)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE DIVwFormatDlgs_ApplyFontDialog_Proxy( 
    DIVwFormatDlgs __RPC_FAR * This,
    /* [in] */ IUnknown __RPC_FAR *psel);


void __RPC_STUB DIVwFormatDlgs_ApplyFontDialog_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __DIVwFormatDlgs_INTERFACE_DEFINED__ */


#define CLSID_VwFormatDlgs __uuidof(VwFormatDlgs)

#ifdef __cplusplus

class DECLSPEC_UUID("A8134A82-60FD-478f-94E3-9E832FFAF908")
VwFormatDlgs;
#endif
#endif /* __VIEWCTLLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
