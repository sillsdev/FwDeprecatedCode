// main.cpp : source file that includes just the standard includes
//  main.pch will be the pre-compiled header
//  main.obj will contain the pre-compiled type information

#include "main.h"

#ifdef _ATL_STATIC_REGISTRY
#include <statreg.h>
#include <statreg.cpp>
#endif

#include <atlimpl.cpp>
