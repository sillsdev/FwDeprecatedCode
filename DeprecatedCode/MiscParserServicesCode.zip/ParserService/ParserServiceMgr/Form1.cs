using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.ServiceProcess;
using SIL.FieldWorks.WordWorks.Parser;

namespace WWSTrayMenu
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.NotifyIcon notifyIcon1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ListView lvParsers;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox tbStatus;
		private System.Windows.Forms.Button btnStart;
		private System.Windows.Forms.Button btnStop;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.ComponentModel.IContainer components;
		private bool m_bReallyExit;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			m_bReallyExit = false;

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.btnStop = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.lvParsers = new System.Windows.Forms.ListView();
			this.tbStatus = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.btnStart = new System.Windows.Forms.Button();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// notifyIcon1
			// 
			this.notifyIcon1.ContextMenu = this.contextMenu1;
			this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
			this.notifyIcon1.Text = "notifyIcon1";
			this.notifyIcon1.Visible = true;
			this.notifyIcon1.DoubleClick += new System.EventHandler(this.notifyIcon1_DoubleClick);
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem6,
																						 this.menuItem4,
																						 this.menuItem1,
																						 this.menuItem7});
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 0;
			this.menuItem6.Text = "&Show Status";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 1;
			this.menuItem4.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem5});
			this.menuItem4.Text = "Other";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 0;
			this.menuItem5.Text = "Release All Parsers";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 3;
			this.menuItem7.Text = "E&xit";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// btnStop
			// 
			this.btnStop.Location = new System.Drawing.Point(96, 96);
			this.btnStop.Name = "btnStop";
			this.btnStop.Size = new System.Drawing.Size(88, 24);
			this.btnStop.TabIndex = 3;
			this.btnStop.Text = "Stop Service";
			this.btnStop.Click += new System.EventHandler(this.button3_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Running Parsers";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(24, 176);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 16);
			this.label2.TabIndex = 1;
			this.label2.Text = "Running Parsers";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(24, 8);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(40, 24);
			this.label3.TabIndex = 4;
			this.label3.Text = "Status:";
			// 
			// lvParsers
			// 
			this.lvParsers.Location = new System.Drawing.Point(24, 192);
			this.lvParsers.Name = "lvParsers";
			this.lvParsers.Size = new System.Drawing.Size(224, 80);
			this.lvParsers.TabIndex = 0;
			// 
			// tbStatus
			// 
			this.tbStatus.Location = new System.Drawing.Point(80, 8);
			this.tbStatus.Name = "tbStatus";
			this.tbStatus.ReadOnly = true;
			this.tbStatus.Size = new System.Drawing.Size(192, 20);
			this.tbStatus.TabIndex = 5;
			this.tbStatus.Text = "";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(16, 176);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(72, 24);
			this.button1.TabIndex = 1;
			this.button1.Text = "Stop";
			// 
			// btnStart
			// 
			this.btnStart.Location = new System.Drawing.Point(96, 64);
			this.btnStart.Name = "btnStart";
			this.btnStart.Size = new System.Drawing.Size(88, 24);
			this.btnStart.TabIndex = 2;
			this.btnStart.Text = "Start Service";
			this.btnStart.Click += new System.EventHandler(this.button2_Click);
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 1000;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 2;
			this.menuItem1.Text = "-";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(296, 277);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tbStatus,
																		  this.label3,
																		  this.btnStop,
																		  this.btnStart,
																		  this.label2,
																		  this.lvParsers});
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "Wordworks Service Manger";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}



		private void menuItem4_Click(object sender, System.EventArgs e)
		{

		}
		
		private ServiceController GetServiceController()
		{
			ServiceController sc;
			try
			{
				sc = new ServiceController("WWS");
				ServiceControllerStatus stat = sc.Status;
			}
			catch(Exception err)
			{
				tbStatus.Text = err.Message;
				return null;
			}

			return sc;
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			if(!this.Visible)
				return;
			

			ServiceController sc;
			ServiceControllerStatus stat;
			try
			{
				sc = new ServiceController("WWS");
				stat = sc.Status;
			}
			catch(Exception err)
			{
				tbStatus.Text = err.Message;
				return ;
			}
			tbStatus.Text =  stat.ToString();

			//set button states
			btnStart.Enabled =(stat == ServiceControllerStatus.Stopped );			
			btnStop.Enabled = ! btnStart.Enabled;
			
			lvParsers.Items.Clear();

			//we don't get to run this until it's about started anyhow
			//if(stat == ServiceControllerStatus.StartPending)
			//	MessageBox.Show("pending");

			if(stat != ServiceControllerStatus.Running)
				return;

			// initialize from the wwsService

			FWParserManager fwpm = (FWParserManager)
				Activator.GetObject(typeof(FWParserManager), 
				"tcp://localhost:8085/FWParserManager");

			foreach(String s in fwpm.GetRunningParsersKeys())
			{
				lvParsers.Items.Add(s);
			}
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			m_bReallyExit = true;
			this.Close();
		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			this.WindowState = FormWindowState.Normal;
			this.Visible = true;
			this.ShowInTaskbar = true;
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			ServiceController sc = GetServiceController();
			if(sc !=null)
			{
				tbStatus.Text = "Starting...";
				tbStatus.Update();
				btnStart.Enabled = false;
				sc.Start();  // this doesn't return until it's started
			}
		}

		private void notifyIcon1_DoubleClick(object sender, System.EventArgs e)
		{
			this.WindowState = FormWindowState.Normal;
			this.Visible = true;
			this.ShowInTaskbar = true;
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			//stop
			ServiceController sc = GetServiceController();
			if(sc !=null)
			{
				btnStop.Enabled = false;
				sc.Stop();			//start
			}

		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{

			ServiceController sc = GetServiceController();
			if(sc ==null)
			{
				MessageBox.Show("Couldn't find the WordworksService");
				return;
			}
			if(sc.Status != ServiceControllerStatus.Running)
			{
				MessageBox.Show("WordworksService isn't running.");
				return;
			}			
			FWParserManager fwpm = (FWParserManager)
				Activator.GetObject(typeof(FWParserManager), 
				"tcp://localhost:8085/FWParserManager");
			
			fwpm.ReleaseAllParsers();
			MessageBox.Show("Release Completed.");
		}

		private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			// we only close the window but don't exit if the user clicks
			// the "x" box, as is the behavior of sql server manager 
			if(!m_bReallyExit)
			{
				e.Cancel = true;
				this.ShowInTaskbar = false;
				this.Visible = false;
				this.WindowState = FormWindowState.Minimized;
			}
		}


	}
}
