using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;

//using Singleton;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

using SIL.FieldWorks.WordWorks.Parser;

namespace wws
{
	public class WWS : System.ServiceProcess.ServiceBase
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		System.Diagnostics.EventLog m_EventLog;

		public WWS()
		{
			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();

			// create an event source
			if (!System.Diagnostics.EventLog.SourceExists("WordworksService")) 
			{        
				System.Diagnostics.EventLog.CreateEventSource("WordworksService","Wordworks");
			}
			// create an event source
			if (!System.Diagnostics.EventLog.SourceExists("FWParserManager")) 
			{        
				System.Diagnostics.EventLog.CreateEventSource("FWParserManager","Wordworks");
			}
			
			// configure the event log instance to use this source name
			m_EventLog.Source = "WordworksService";
		}

		// The main entry point for the process
		static void Main()
		{
			System.ServiceProcess.ServiceBase[] ServicesToRun;
	
			// More than one user Service may run within the same process. To add
			// another service to this process, change the following line to
			// create a second service object. For example,
			//
			//   ServicesToRun = New System.ServiceProcess.ServiceBase[] {new WWS(), new MySecondUserService()};
			//
			ServicesToRun = new System.ServiceProcess.ServiceBase[] { new WWS() };

			System.ServiceProcess.ServiceBase.Run(ServicesToRun);
		}

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			this.ServiceName = "WWS";

			// turn off autologging
			AutoLog = false;
			// create an eventlog component instance
			m_EventLog = new System.Diagnostics.EventLog();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		protected override void OnStart(string[] args)
		{
			m_EventLog.WriteEntry("Starting Service.");
			// Register our singleton object on the TcpChannel
			  TcpChannel chan1 = new TcpChannel(8085);
			ChannelServices.RegisterChannel(chan1);
			RemotingConfiguration.RegisterWellKnownServiceType(typeof
				(FWParserManager), "FWParserManager", 
				WellKnownObjectMode.Singleton);


		}
 
		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			m_EventLog.WriteEntry("Stopping Service.");
		}
	}
}
