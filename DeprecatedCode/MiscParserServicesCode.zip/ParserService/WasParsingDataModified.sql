-- =============================================
-- determine if any of the objects which the  
-- WordWorks parser depends on has been modified 
-- since the given date.
-- =============================================
IF EXISTS (SELECT name 
	   FROM   sysobjects 
	   WHERE  name = N'WasParsingDataModified' 
	   AND 	  type = 'P')
    DROP PROCEDURE WasParsingDataModified
GO

CREATE PROCEDURE WasParsingDataModified 
	@dtCompare DATETIME
AS
	SELECT TOP 1 Id FROM cmobject co
 	where co.UpdDttm > @dtCompare
		and (co.Class$ BETWEEN 5026 AND 5045
                    OR co.Class$ IN
	(
	 	5005, --kclidLexicalDatabase
		5008 -- kclidLexMajorEntry 
	))

GO


