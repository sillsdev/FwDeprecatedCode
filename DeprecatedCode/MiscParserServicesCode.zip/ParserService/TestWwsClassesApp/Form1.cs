using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using SIL.FieldWorks.WordWorks.Parser;

namespace TestWwsClassesApp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;

		private FWParserManager m_fwpmLocal;
		private System.Windows.Forms.Button button5;
		private FWParserManager m_fwpmSingleton;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		private M3ParserController m_parser;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			m_fwpmLocal = new FWParserManager();
			textBox1.Text = m_fwpmLocal.test.ToString();

			// initialize from the wwsService

			m_fwpmSingleton = (FWParserManager)
				Activator.GetObject(typeof(FWParserManager), 
					"tcp://localhost:8085/FWParserManager");

			textBox2.Text = m_fwpmLocal.test.ToString();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBox1.Location = new System.Drawing.Point(144, 64);
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.Size = new System.Drawing.Size(80, 31);
			this.textBox1.TabIndex = 1;
			this.textBox1.Text = "textBox1";
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(24, 144);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(256, 32);
			this.label1.TabIndex = 3;
			this.label1.Text = "From WWService";
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(24, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(256, 32);
			this.label2.TabIndex = 3;
			this.label2.Text = "From Local Objects";
			// 
			// textBox2
			// 
			this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBox2.Location = new System.Drawing.Point(144, 192);
			this.textBox2.Name = "textBox2";
			this.textBox2.ReadOnly = true;
			this.textBox2.Size = new System.Drawing.Size(80, 31);
			this.textBox2.TabIndex = 1;
			this.textBox2.Text = "textBox1";
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(248, 192);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(136, 40);
			this.button4.TabIndex = 2;
			this.button4.Text = "Get value";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(32, 280);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(160, 40);
			this.button5.TabIndex = 4;
			this.button5.Text = "Test GetDefaultParser()";
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(336, 288);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(80, 40);
			this.button6.TabIndex = 5;
			this.button6.Text = "Release All Parsers";
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(24, 64);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(96, 40);
			this.button1.TabIndex = 0;
			this.button1.Text = "Increment";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(248, 64);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(136, 40);
			this.button2.TabIndex = 2;
			this.button2.Text = "Get value";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(24, 192);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(96, 40);
			this.button3.TabIndex = 0;
			this.button3.Text = "Increment";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(424, 288);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(64, 40);
			this.button7.TabIndex = 5;
			this.button7.Text = "Test parser";
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(520, 357);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button6,
																		  this.button5,
																		  this.label1,
																		  this.button2,
																		  this.textBox1,
																		  this.button1,
																		  this.button3,
																		  this.textBox2,
																		  this.button4,
																		  this.label2,
																		  this.button7});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			m_fwpmLocal.increment();
			textBox1.Text = m_fwpmLocal.test.ToString();
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			textBox1.Text = m_fwpmLocal.test.ToString();
		}

		private void label1_Click(object sender, System.EventArgs e)
		{

		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			m_fwpmSingleton.increment();
			textBox2.Text = m_fwpmSingleton.test.ToString();

		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			textBox2.Text = m_fwpmSingleton.test.ToString();

		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			m_parser = m_fwpmSingleton.GetDefaultParser(".\\SILFW", "ZPU", "ZPU-Yal�lag Zapotec");
		}

		private void button6_Click(object sender, System.EventArgs e)
		{
			m_fwpmSingleton.ReleaseAllParsers();
			
		}

		private void button7_Click(object sender, System.EventArgs e)
		{
			//m_parser.UpdateWordform(0,0,0,1);
		}
	}
}
