// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FwToolList.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Xml;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Collections.Specialized;
using System.Collections;

namespace SIL.Fieldworks.Common
{
	/// <summary>
	/// An abstract class for lists of applications and plug-ins which are 
	/// compliant with the FWToolBroker architecture.
	/// </summary>
	public abstract class FwToolList
	{
		protected	ArrayList m_toolInfos = new ArrayList();

		public FwToolList()
		{
		}

	
		/// <summary>
		/// Get the FieldWorks tools which an ArrayList of FwToolInfo's have discovered in the specified directory(s).
		/// </summary>
		/// <returns></returns>
		public System.Collections.ArrayList ToolInfos
		{
			get
			{
				return m_toolInfos;
			}
		}
		
	}

	/// <summary>
	/// Provides a list of runnable applications and plug-ins in the directories which have been specified to contain them.
	/// </summary>
	public class FwRunningTooList : FwToolList
	{
		/// <summary>
		/// constructor
		/// </summary>
		public FwRunningTooList()
			: base()
		{
			throw new NotImplementedException();
		}
	}

	/// <summary>
	/// Provides a list of runnable applications and plug-ins in the directories which have been specified to contain them.
	/// </summary>
	public class FwAvailableTooList : FwToolList
	{
		/// <summary>
		/// constructor
		/// </summary>
		public FwAvailableTooList()
			: base()
		{
			Initialize();
		}

		protected void Initialize ()
		{
			DiscoverTools();
		}

		protected void DiscoverTools()
		{
			m_toolInfos.Clear();

			StringCollection dirs = ChooseDirectoriesToSearch();
			
			foreach(string path in dirs)
			{
				DiscoverToolsInDirectory(path);	
			}
		}

		//currently, this just searches the same directory that was executed,
		// and all of dissembling directories indicates that this was executed from a 
		//folder which is inside ofthe ouput\debug directory.

		//Eventually, we will add a the ability to read one or more directory locations at runtime
		// (perhaps from a config file) and search those directories at runtime.
		protected StringCollection ChooseDirectoriesToSearch ()
		{
			StringCollection dirs = new StringCollection();

			//string devPath = Environment.GetEnvironmentVariable("%FWROOT%")+@"\output";
			//		dirs.Add(devPath);
			
			DirectoryInfo ourDir = Directory.GetParent(Assembly.GetExecutingAssembly().Location);
			
			//look in the same directory as this assembly
			dirs.Add(ourDir.FullName);

			//hack: if this is being run from a directory inside of the output/debug directory
			if(ourDir.FullName.IndexOf(@"output\debug")>-1)
			{
				//look in all of the sibling directories of this assembly
				DirectoryInfo parent = ourDir.Parent;
				foreach(DirectoryInfo sibling in parent.GetDirectories())
				{
					dirs.Add(sibling.FullName);
				}
			}

			return dirs;
		}

		protected void DiscoverToolsInDirectory(string path)
		{
			try
			{
				DirectoryInfo folder = new DirectoryInfo(path);
				FileInfo[] files = folder.GetFiles();
				//foreach(FileInfo info in files)	<---gave wrong results
				for(int i = 0; i<files.GetLength(0); i++)
				{
					FileInfo info=files[i];
					try
					{
						FwToolInfo toolInfo = new FwToolInfo (info.FullName);
						m_toolInfos.Add(toolInfo);
					}
					catch(Exception)
					{
						continue;	//was not a compliant exe or dll, that's OK
					}
				}
			}
			catch(Exception)
			{
					//directory not found, not quite worth choking over...
			}
		}

	}
}
