// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FwToolInfo.cs
// Responsibility:
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Xml;
using System.Diagnostics;
using System.Resources;
using System.Reflection;
using System.IO;
using System.Collections;

namespace  SIL.Fieldworks.Common
{
	/// <summary>
	/// A class for accessing the contents of the XML FwToolInfo of a compliant DLL or EXE
	/// </summary>
	public class FwToolInfo
	{
		protected XmlNode m_rootManifestNode;
		protected string m_path;
		
		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="assemblyPath">path to the DLL or EXE</param>
		public FwToolInfo(string assemblyPath)
		{
			m_path = assemblyPath;
			Assembly assem = Assembly.LoadFrom(assemblyPath);
			Stream manifestStream = null;
			
			//if this assembly has a satellite assembly matching the current culture, try
			//	to get the FieldWorks manifest out of that assembly first.
			//UNTESTED!!!!
			/*
				System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.CurrentUICulture;
				Assembly satellite=null;
				
				try
				{
					satellite = assem.GetSatelliteAssembly(ci);
				}
				catch(Exception)
				{
				}
				
				if(satellite!=null)
				{
					manifestStream = GetFwManifestStream(satellite);
				}
			*/

			if (manifestStream == null)//didn't find one there
			{
				manifestStream = GetFwManifestStream(assem);
				if(manifestStream ==null)
					throw new ArgumentException("That file did not contain a fwmanifest.xml in its resources (this is not necessarily an error).");
			}

			XmlDocument d = new XmlDocument();
			Debug.Assert(d!= null, "Could not create a new XMLDocument object. Is MSXML missing?");
			d.Load(manifestStream);
					
			m_rootManifestNode=d.GetElementsByTagName("FWToolMainfest")[0];
			Debug.Assert(m_rootManifestNode!= null);

		}

		protected Stream GetFwManifestStream(Assembly assem)
		{
			//note: if we could figure out what the default namespace 
			//was for the assembly, we would not need to Gatorade through every named resource!
			//instead, we could just ask for (namespace).fwmanifest.xml
			string[] rsrcs = assem.GetManifestResourceNames();
			foreach(string resourcename in rsrcs)
			{
				if(resourcename.ToLower().EndsWith("fwmanifest.xml"))
				{
					Stream s = assem.GetManifestResourceStream(resourcename);
					Debug.Assert(s!=null, "Could not load the fwmanifest.xml.");
					return s;
				}
			}
			return null;
		}

		/// <summary>
		/// the name given in the root node of the manifest
		/// </summary>
		public string Name
		{
			get
			{
				return m_rootManifestNode.Attributes["name"].Value;
			}
		}

		/// <summary>
		/// the path to the tool
		/// </summary>
		public string Path
		{
			get
			{
				return m_path;
			}
		}
	
		/// <summary>
		/// the names of the interfaces the tool claims to support
		/// </summary>
		public ArrayList SupportedInterfaces
		{
			get
			{
				ArrayList list = new ArrayList ();
				XmlNodeList nodes = m_rootManifestNode.SelectNodes("Interfaces/Implements");
				foreach(XmlNode node in nodes)
				{
					XmlAttribute attribute = node.Attributes["name"];
					if (attribute == null)
					{
						Debug.Assert(attribute != null,"missing 'name' attribute");
						continue;
					}
					list.Add(attribute.Value);
				}
				return list;
			}
		}

		/// <summary>
		/// Tells whether this tool implements the FwPlugin1 interface.
		/// </summary>
		public bool IsFwPlugIn1
		{
			get
			{
				return SupportedInterfaces.Contains("FwPlugin1");
			}
		}
	}
}
