// SAXErrorHandler.cpp: implementation of the SAXErrorHandler class.
//
//////////////////////////////////////////////////////////////////////

#include "main.h" //"stdafx.h"
#include "SAXErrorHandlerImpl.h"
#include <stdio.h>

extern StrUni g_stuMsg;
extern int g_iHvoOfWordformInCaseOfError;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SAXErrorHandlerImpl::SAXErrorHandlerImpl()
{

}

SAXErrorHandlerImpl::~SAXErrorHandlerImpl()
{

}

HRESULT STDMETHODCALLTYPE SAXErrorHandlerImpl::error( 
            /* [in] */ ISAXLocator __RPC_FAR *pLocator,
            /* [in] */ unsigned short * pwchErrorMessage,
			/* [in] */ HRESULT errCode)
{
	return fatalError(pLocator,pwchErrorMessage,errCode);
}
        
HRESULT STDMETHODCALLTYPE SAXErrorHandlerImpl::fatalError( 
            /* [in] */ ISAXLocator __RPC_FAR *pLocator,
            /* [in] */ unsigned short * pwchErrorMessage,
			/* [in] */ HRESULT errCode)
{
	int nLine;
	pLocator->getLineNumber(&nLine);
	int nCol;
	pLocator->getColumnNumber(&nCol);
	StrUni stuTemp;	 //we need to append the existing g_stuMsg, so use a temp string
	stuTemp.Format(L"SAX ERROR on line %d, col %d: %s (%s) Code=%11d WordformId=%11d", nLine, nCol, pwchErrorMessage, g_stuMsg.Chars(), errCode, g_iHvoOfWordformInCaseOfError);
	g_stuMsg = stuTemp;

	return S_OK;
}
        
HRESULT STDMETHODCALLTYPE SAXErrorHandlerImpl::ignorableWarning( 
            /* [in] */ ISAXLocator __RPC_FAR *pLocator,
            /* [in] */ unsigned short * pwchErrorMessage,
			/* [in] */ HRESULT errCode)
{
	return S_OK;
}

long __stdcall SAXErrorHandlerImpl::QueryInterface(const struct _GUID &,void ** )
{
	// hack-hack-hack!
	return 0;
}

unsigned long __stdcall SAXErrorHandlerImpl::AddRef()
{
	// hack-hack-hack!
	return 0;
}

unsigned long __stdcall SAXErrorHandlerImpl::Release()
{
	// hack-hack-hack!
	return 0;
}