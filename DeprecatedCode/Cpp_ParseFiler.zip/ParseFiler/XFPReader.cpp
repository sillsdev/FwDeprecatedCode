/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: XFPReader.cpp
Responsibility: John Hatton / Randy Regnier (sql statements)
Last reviewed: Never

	Content handler for reading XFP (Xml Fieldworks Parse) XML files which 
	updates the WordformInventory appropriately.
-------------------------------------------------------------------------------*//*:End Ignore*/

#include "Main.h"
#pragma hdrstop

#include "XFPReader.h"
#include "Vector_i.cpp"
#include "HashMap_i.cpp"
#include <assert.h>


//temporary
#include <time.h>


//#define VERBOSE_DEBUG
//#define MAKE_REPORT_LOG  // for use with timing and unit tests
	#include "reporter.h" //redefines TASK_START if MAKE_REPORT_LOG is undefined
#ifdef MAKE_REPORT_LOG
	extern FileReporter *g_pReporter;
#endif
//:>******************if**************************************************************************
//:>	   Global error message storing StrUni.
//:>********************************************************************************************
extern StrUni g_stuMsg;
extern int g_iHvoOfWordformInCaseOfError;

//:>********************************************************************************************
//:>	   XFPReader Methods
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.

	@param pode Pointer to DB accessor.
	@param iLpId Database ID for the language project.
	@param iLDBId Database ID for the lexical database.
	@param IParseFilerId Database ID for the wordform inventory.
----------------------------------------------------------------------------------------------*/
XFPReader::XFPReader(IOleDbEncap * pode, int iLpId, int iLDBId, int IParseFilerId, int iAnalWs)
{
	AssertPtr(pode);
	m_qode = pode;
	m_iLpId = iLpId;
	m_iLDBId = iLDBId;
	m_IParseFilerId = IParseFilerId;
	m_iAnalWs = iAnalWs;
	m_iAnalAgentId = 0;
	m_iCurrentWordformId = 0;
	m_iCurrentAnalysisId = 0;
	m_strProcessingDetails = "Normal";	//TODO: get this from the XML file when it is included 


//TODO: get time and date from the XML file when it is included 
	char bufTime[128], bufDate[128];
    _tzset();
    _strtime( bufTime );
    _strdate( bufDate );
	_bstr_t bstrTime(bufTime);
	_bstr_t bstrDate(bufDate);	
	m_strTimeLastEngineUpdate.Format(L"%s %s", (wchar *)bstrDate, (wchar *)bstrTime);
	//m_strTimeLastEngineUpdate = "1/2/3";	//TODO: get this from the XML file when it is included 
}

/*----------------------------------------------------------------------------------------------
	Destructor
----------------------------------------------------------------------------------------------*/
XFPReader::~XFPReader()
{ /* Let superclass fret about this. */ }

HRESULT STDMETHODCALLTYPE XFPReader::startDocument()
{
	if (!m_qode)
		return E_FAIL;

    return S_OK;
}

HRESULT STDMETHODCALLTYPE XFPReader::startElement( 
            /* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri,
            /* [in] */ int cchNamespaceUri,
            /* [in] */ wchar_t __RPC_FAR *pwchLocalName,
            /* [in] */ int cchLocalName,
            /* [in] */ wchar_t __RPC_FAR *pwchRawName,
            /* [in] */ int cchRawName,
            /* [in] */ ISAXAttributes __RPC_FAR *pAttributes)
{
	if (!m_qode)
	{
		g_stuMsg = L"No database connection.";
		return E_FAIL;
	}

	HRESULT hr = S_OK;
	int l;
	wchar_t * ln;
	int lnlen;
	int i;
	int iDbId;
	static wchar_t wcTemp[1000];
	StrAnsi staLocalName = pwchLocalName;
#ifdef VERBOSE_DEBUG
	StrAnsi staOutStrDbgr;
	staOutStrDbgr.Format("Found start tag: %s\n", staLocalName.Chars());
	OutputDebugString(staOutStrDbgr.Chars());
#endif
	StrAnsi staAttributeLocalName;
	StrAnsi staAttributeValue;

	pAttributes->getLength(&l);
	for (i=0; i<l; i++)
	{
		// The only attribute we really care about is "DbRef",
		// and we will hang onto its value for now.
		iDbId = 0;
		pAttributes->getLocalName(i,&ln,&lnlen);
		ZeroMemory(wcTemp, 1000);
		wcsncpy(wcTemp, ln, lnlen);
		staAttributeLocalName = wcTemp;
		if (staAttributeLocalName == "DbRef")
		{
			pAttributes->getValue(i,&ln,&lnlen);
			ZeroMemory(wcTemp, 1000);
			wcsncpy(wcTemp, ln, lnlen);
			staAttributeValue = wcTemp;
#ifdef VERBOSE_DEBUG
			staOutStrDbgr.Format("\tFound ID: %s\n", staAttributeValue.Chars());
			OutputDebugString(staOutStrDbgr.Chars());
#endif
			iDbId = atoi(staAttributeValue.Chars());
			break;
		}
	}

	if (staLocalName =="MoForm")
	{
		if (iDbId == 0)
		{
			g_stuMsg = L"No ID for form.";
			ResetMembers();
			return E_FAIL;	//  No DB id, so quit..
		}
		m_viFormIds.Push(iDbId);	// Cache the MoForm id.
		iDbId = 0;
	}
	else if (staLocalName =="MSA" || staLocalName =="MSI" /*todo: remove msi when ample is updated*/)
	{
		if (iDbId == 0)
		{
			g_stuMsg = L"No ID for MSA.";
			ResetMembers();
			return E_FAIL;	//  No DB id, so quit.
		}
		m_viMsaIds.Push(iDbId);		// Cache the MSA id.
		iDbId = 0;
	}
	else if (staLocalName =="WfiAnalysis")
	{
		if ((m_viFormIds.Size() > 0)
			|| (m_viMsaIds.Size() > 0))
		{
			// Can only get here, if we have found form or MSA tags,
			// but no WfiAnalysis end tag, which would have cleared both vectors.
			g_stuMsg = L"No end tag for 'WfiAnalysis'.";
			ResetMembers();
			return E_FAIL;
		}
		// Starting a WfiAnalysis, so clear old id.
		m_iCurrentAnalysisId = 0;
	}
	else if (staLocalName == "Wordform")
	{
		if ((m_viFormIds.Size() > 0)
			|| (m_viMsaIds.Size() > 0)
			|| (m_iCurrentAnalysisId > 0))
		{
			// Can only get here, if we have found form or MSA tags,
			// but no WfiAnalysis end tag, which would have cleared both vectors.
			// The end tag for WordForm would also have set m_iCurrentAnalysisId to 0.
			g_stuMsg = L"Missing 'WfiAnalysis' or 'WordForm' end tag.";
			ResetMembers();
			return E_FAIL;
		}

		m_iCurrentWordformId = iDbId;	// Cache id.
		g_iHvoOfWordformInCaseOfError = iDbId;

		// Check to see if wordform is in DB.
		//Enhance (JohnH): do we really need to check this?  
		//		After all, the error would hit us pretty soon in the normal course of updating analyses.
		if (!ExistsWordsform())
		{
			g_stuMsg.Format(L"Wordform '%d' not found in this LanguageProject.", m_iCurrentWordformId);
			ResetMembers();
			return E_FAIL;	//  Not found in DB, so bail out.
		}

		if (m_iAnalAgentId <= 0)
		{
			g_stuMsg = L"Found a Wordform but an analyzing agent has not been identified.";
			return E_FAIL;	// Second time we found this tag, which is bad.
		}
	
		//create or update a CMEvaluations from this agent to this Wordform.
		//this records the fact that the parser last visited this Wordform at this time,
		//even if there were no analyses found.
		UpdateOrCreateAgentEvaluation(m_iAnalAgentId,m_iCurrentWordformId, L"I am the eggman", m_strTimeLastEngineUpdate.Chars());
	}
	else if (staLocalName == "AnalyzingAgent")
	{
		if (m_iAnalAgentId > 0)
		{
			g_stuMsg = L"Found another 'AnalyzingAgent' tag.";
			return E_FAIL;	// Second time we found this tag, which is bad.
		}
		// Get information from attributes.
		StrUni stuName;
		StrUni stuVersion;
		ComBool fHuman = false;
		for (i=0; i<l; i++)
		{
			pAttributes->getLocalName(i,&ln,&lnlen);
			ZeroMemory(wcTemp, 1000);
			wcsncpy(wcTemp, ln, lnlen);
			staAttributeLocalName = wcTemp;

			pAttributes->getValue(i,&ln,&lnlen);
			ZeroMemory(wcTemp, 1000);
			wcsncpy(wcTemp, ln, lnlen);
			staAttributeValue = wcTemp;

			if (staAttributeLocalName == "name")
			{
				stuName = wcTemp;
			}
			else if (staAttributeLocalName == "human")
			{
				fHuman = (staAttributeValue == "true");
			}
			else if (staAttributeLocalName == "version")
			{
				stuVersion = wcTemp;
			}
		}
		// Find the agent, and cache its id.
		if (!GetAnalyzingAgent(&stuName, fHuman, &stuVersion))
		{
			g_stuMsg = L"Could not find (or create) the analyzing agent.";
			return E_FAIL;	// Couldn't get the agent, so quit.
		}
	}
	else if ((staLocalName == "Morphs")
		|| (staLocalName == "Morph")
		|| (staLocalName == "WordSet")
		|| (staLocalName == "AnalyzingAgentResults")
		|| (staLocalName == "StateInformation"))
	{
		// Ignore all of these tags.
		// But don't be as rude as the next guy.
#ifdef VERBOSE_DEBUG
		OutputDebugString("Ignoring tag: ");
		OutputDebugString(staLocalName.Chars());
		OutputDebugString("\n");
#endif
	}

	else if (staLocalName == "Exception")
	{
/*		There is a parameter (MaxAnalysesToReturn) you can set in xample to the number you want. If you don't set it or if you set it to NULL, it will return all analyses.

		When you use the FWParse format, it outputs an exception element when the max has been reached and tells you what the number of total analyses are. For example:

		<Exception code=�ReachedMaxAnalyses� totalAnalyses='117'/>
*/

		//enhance: note that currently we are just swallowing this so the only way you could notify the user would be if the calling object also checked for the existence of this tag.
		//	what we want to do is create a problem object in the database, but the model does not currently support that.


		//	the important thing to remember is this is not an error!
		//	however, the following situation is:
		//--------------


		//when the following happens, we will just get a failed parse.
		//the Parser is designed to keep going, but it's not much help to the user.
		//enhance: somebody somewhere should recognize what happened and create the appropriate error object.
		// so long as the number of analyses is kept small compared to the maximum size of the buffer in an xample,
		//this seems unlikely to happen. --jdh feb 2003
/*
		If the buffer is too small, it outputs an exception code message, too. For example:

		<Exception code=�ReachedMaxBufferSize� totalAnalyses='117'/>

		Given, though, that this problem can occur anywhere in the FWParse processing, there is no guarantee we'll still have well-formed XML. For example, if it were to happen inside a morph, all that might have been output could be

		<MoForm DbRef='0' Label="

		I'm not sure what we can do about this without a ton of work.

		--Andy

		*/

/*started but didn't finish... won't really work since we don't know the context of this tag.
		m_strProcessingDetails = "Parsing Exception".
		ProcessAnalysis(m_viMsaIds, m_viFormIds);
		m_strProcessingDetails = "Normal".
*/		
		//assert(FALSE);
		//StrAnsi staOutStrDbgr;
		//staOutStrDbgr.Format(_T("Found Exception tag."));
		//OutputDebugString(staOutStrDbgr.Chars());

		g_stuMsg.Format(L"Parser Exception");
		return E_FAIL;

	}
	else
	{
		// Unrecognized tag.
		g_stuMsg.Format(L"Found unrecognized tag: '%s'.", staLocalName.Chars());
		return E_FAIL;
	}

    return hr;
}

HRESULT STDMETHODCALLTYPE XFPReader::endElement( 
            /* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri,
            /* [in] */ int cchNamespaceUri,
            /* [in] */ wchar_t __RPC_FAR *pwchLocalName,
            /* [in] */ int cchLocalName,
            /* [in] */ wchar_t __RPC_FAR *pwchRawName,
            /* [in] */ int cchRawName)
{
	if (!m_qode)
	{
		g_stuMsg = L"No database connection.";
		return E_FAIL;
	}

	StrAnsi staLocalName = pwchLocalName;
#ifdef VERBOSE_DEBUG
	StrAnsi staOutStrDbgr;
	staOutStrDbgr.Format("Found end tag: %s\n", staLocalName.Chars());
	OutputDebugString(staOutStrDbgr.Chars());
#endif
	if (staLocalName == "WfiAnalysis")
	{
		// Found the end of an analysis.
		// Do some validity checking, before processing morphs.
		if ((m_iCurrentWordformId == 0)
			|| (m_iAnalAgentId == 0)
			|| (m_iCurrentAnalysisId > 0)
			|| !(m_viFormIds.Size() == m_viMsaIds.Size()))
		{
			g_stuMsg = L"Found 'WfiAnalysis' end tag, which is in wrong order.";
			ResetMembers();
			return E_FAIL;	// Preconditions for processing have not been met.
		}

		// Handle analysis.
		if (!ProcessAnalysis(m_viMsaIds, m_viFormIds))
		{
			ResetMembers();
			return E_FAIL;	// Message has been set by ProcessAnalysis.
		}

		// Clear out vectors, so they are ready for another analysis
		// of a wordform. It could be the same wordform or a different wordform.
		m_viFormIds.Clear();
		m_viMsaIds.Clear();

		// Cache the analysis id, for use by RemoveOldAnalyses.
//		m_viAnalIds.Push(m_iCurrentAnalysisId);
	}
	else if (staLocalName == "Wordform")
	{
		// Zap unloved analyses this agent used to care about, but no longer does.
		if (!RemoveOldAnalyses())
		{
			ResetMembers();
			return E_FAIL;	// Message has been set by RemoveOldAnalyses.
		}

		ResetForNextWord(); // added jdh feb 2003 since would fail if wordset had >1 wordform.

	}

	return S_OK;
}

/*----------------------------------------------------------------------------------------------
	Find (create, if not found) the analyzing agent in the database.

	@param pstuName Pointer to the agent's name.
	@param fHuman True if human is the agent, otherwise false.
	@param pstuVersion Pointer to the agent's version.
	@return True if successful, false otherwise.
----------------------------------------------------------------------------------------------*/
bool XFPReader::GetAnalyzingAgent(StrUni * pstuName, bool fHuman, StrUni * pstuVersion)
{
	TASK_START(pp, "GetAnalyzingAgent");

	Assert(m_qode);	// Got to have the connection.
	AssertPtr(pstuName);
	AssertPtr(pstuVersion);
	Assert(m_iAnalAgentId == 0);	// Shouldn't call this method more than once.

	IOleDbCommandPtr qodc;
	StrUni stuSqlStmt;
	ComBool fIsNull;
	ComBool fMoreRows;
	ULONG cbSpaceTaken;
	bool bRet = true;

	try
	{
		StrUtil::NormalizeStrUni(*pstuName, UNORM_NFD);
		StrUtil::NormalizeStrUni(*pstuVersion, UNORM_NFD);
		stuSqlStmt.Format(
			L"select aa.Id from CmAgent_ aa (readuncommitted) "
			L"left outer join CmAgent_Name aan (readuncommitted) "
				L"on aan.Obj = aa.Id and aan.Txt='%s' "
			L"where aa.Owner$ = %d and aa.Human=%d and aa.Version='%s'",
			pstuName->Chars(), m_iLpId, fHuman, pstuVersion->Chars());
		m_qode->CreateCommand(&qodc);
		
		qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
		qodc->GetRowset(0);
		qodc->NextRow(&fMoreRows);
		if(fMoreRows)
		{
			// Cache id of extant agent.
			CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_iAnalAgentId),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			Assert(m_iAnalAgentId > 0);
		}
		else
		{
			// Create a new one.
			stuSqlStmt.Format(
				L"declare @uid uniqueidentifier "
				L"exec CreateOwnedObject$ "
				L"%d, null, null, %d, %d, %d, null, 1, 1, @uid output; "
				L"exec CleanObjListTbl$ @uid",
				kclidCmAgent, m_iLpId,
				kflidLanguageProject_AnalyzingAgents, kcptOwningCollection);
			CheckHr(m_qode->CreateCommand(&qodc));
			CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtStoredProcedure));
			CheckHr(qodc->GetRowset(0));
			CheckHr(qodc->NextRow(&fMoreRows));
			// Cache its id.
			CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_iAnalAgentId),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			Assert(m_iAnalAgentId > 0);
			// Set other attributes.
			stuSqlStmt.Format(L"exec SetMultiTxt$ %d, %d, %d, '%s'; ",
				kflidCmAgent_Name, m_iAnalAgentId, m_iAnalWs, pstuName->Chars());
			stuSqlStmt.FormatAppend(L"UPDATE CmAgent SET Human=%d, Version='%s'"
					L"WHERE Id=%d",
				fHuman, pstuVersion->Chars(), m_iAnalAgentId);
			m_qode->CreateCommand(&qodc);
			qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtNoResults);
		}
		qodc.Clear();
	}
	catch (...)
	{
		bRet = false;	// Something bad happened.
	}
	return bRet;
}

/*----------------------------------------------------------------------------------------------
	Check to see if the wordform is in the inventory.

	@return True if successful, false on missing inventory, missing wordform,
		or exception thrown.
----------------------------------------------------------------------------------------------*/
bool XFPReader::ExistsWordsform()
{
	TASK_START(pp, "ExistsWordsform");

	Assert(m_qode);	// Got to have the connection.
	Assert(m_iCurrentWordformId > 0);

	IOleDbCommandPtr qodc;
	StrUni stuSqlStmt;
	ComBool fMoreRows;

	try
	{
		stuSqlStmt.Format(
			L"select * from WordformInventory_Wordforms (readuncommitted) "
			L"where Src = %d and Dst = %d", m_IParseFilerId, m_iCurrentWordformId);
		m_qode->CreateCommand(&qodc);
		qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
		qodc->GetRowset(0);
		qodc->NextRow(&fMoreRows);
		qodc.Clear();
	}
	catch (...)
	{
		fMoreRows = false;	// Something bad happened.
	}
	return fMoreRows;
}




/*----------------------------------------------------------------------------------------------
	In UpdateAnalysisAndEvaluation() the function of finding or creating the analysis has been 
	combined with the function of finding or creating the CmEvaluation.

	Therefore, this method is now defunct.  It still works though.
----------------------------------------------------------------------------------------------*/
bool XFPReader::FindOrCreateAnalysis (StrUni stuXMLAnalysis)
{
	TASK_START(fa, "FindOrCreateWfiAnalysis() method");
	bool bRet = true;
	
	StrUni stuSqlStmt;
	ComBool fMoreRows;
	IOleDbCommandPtr qodc;

	ComBool fIsNull = false;
	ULONG cbSpaceTaken;
	
	stuSqlStmt.Format(L"declare @retval int, @AnalId int "
			L"exec @retval=FindOrCreateWfiAnalysis %d, \'%s\', @AnalId output "
			L"select @retval, @AnalId", m_iCurrentWordformId, stuXMLAnalysis.Chars());
	AssertPtr(m_qode);
	CheckHr(m_qode->CreateCommand(&qodc));
	TASK_START(efc, "Executing FindOrCreateWfiAnalysis stored procedure");
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset));
	TASK_END(efc);
	CheckHr(qodc->GetRowset(0));
	CheckHr(qodc->NextRow(&fMoreRows));
	int retval;
	if (!fMoreRows)		// outer fMoreRows check
	{
		// FindOrCreateWfiAnalysis didn't return @retval.
		g_stuMsg = L"Database access problem (No @retval).";
		bRet = false;
		goto LExit;
	}
	CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&retval),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));

	if(!CheckReturnCode(retval, stuXMLAnalysis.Chars()))
		goto LExit;

	// here is where the analysis ID is finally set
	CheckHr(qodc->GetColValue(2, reinterpret_cast<ULONG *>(&m_iCurrentAnalysisId),
		isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	if (!m_iCurrentAnalysisId)
	{
		g_stuMsg = L"No analysis ID.";
		bRet = false;
		goto LExit;
	}

LExit:
	qodc.Clear();
	TASK_END(fa);
	return bRet;
}
/*----------------------------------------------------------------------------------------------
This will soon be removed in favor of the CmAgentEvaluation
----------------------------------------------------------------------------------------------*/
//bool XFPReader::AddAgentToValidatingSources()
//{
//	//
//	// Set agent to analysis, if not already connected.
//	TASK_START(sa, "Set agent");
//	StrUni stuSqlStmt;
//	ComBool fMoreRows;
//	IOleDbCommandPtr qodc;
//	
//	stuSqlStmt.Format(
//		L"select * from WfiAnalysis_ValidatingSources (readuncommitted) "
//			L"where Src=%d and Dst=%d",
//		m_iCurrentAnalysisId, m_iAnalAgentId);
//	AssertPtr(m_qode);
//	CheckHr(m_qode->CreateCommand(&qodc));
//	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset));
//	CheckHr(qodc->GetRowset(0));
//	CheckHr(qodc->NextRow(&fMoreRows));
//	if (!fMoreRows)
//	{
//		// Add agent.
//		stuSqlStmt.Format(
//			L"INSERT into WfiAnalysis_ValidatingSources  (Src, Dst) "
//				L"VALUES (%d, %d);%n",
//			m_iCurrentAnalysisId, m_iAnalAgentId);
//		CheckHr(m_qode->CreateCommand(&qodc));
//		CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtNoResults));
//	}
//
//	qodc.Clear();
//	TASK_END(sa);
//	return true;
//}

/*----------------------------------------------------------------------------------------------
This method creates a CmEvaluation with the given target, details, and time.

Since there is a more efficient way to make CmEvaluations on analyses 
and (UpdateAnalysisAndEvaluation), in practice this method is only used to create 
CmEvaluation which targets a WfiWordform.
----------------------------------------------------------------------------------------------*/
bool XFPReader::UpdateOrCreateAgentEvaluation(int hvoAgent, int hvoTarget,
											 const wchar* strDetails,
											 const wchar* strCurrentEvaluationTime)
{
	TASK_START(uae, "UpdateOrCreateAgentEvaluation");

	StrUni stuSqlStmt;
	ComBool fMoreRows;
	IOleDbCommandPtr qodc;

	ComBool fIsNull = false;
	ULONG cbSpaceTaken;
	
/*CREATE PROC [UpdOrCreateAgentEval$]
	@nAgentID INT,	
	@nEvaluatedID INT, --( A WfiAnalysis.ID or a WfiWordform.ID
	@fAccepted BIT,
	@nvcDetails NVARCHAR(4000),
	@dtEval DATETIME
*/
	stuSqlStmt.Format(L"DECLARE @d datetime;"
			L"set @d = '%s';"
			L"declare @retval int "
			L"exec @retval=UpdOrCreateAgentEval$ %d, %d, 1, 'a wordform eval', @d\n"
			L"select @retval", 
			strCurrentEvaluationTime,					//@dtEval DATETIME
			hvoAgent,							// @nAgentID INT,
			hvoTarget					//@nEvaluatedID INT, --( A WfiAnalysis.ID or a WfiWordform.ID
			//always '1' for 'accepted' here		//@fAccepted BIT,
			//nothing to say yet (for future use)	//@nvcDetails NVARCHAR(4000),
			);
	AssertPtr(m_qode);
	CheckHr(m_qode->CreateCommand(&qodc));
	TASK_START(esp, "Executing UpdOrCreateAgentEval$ stored procedure");
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset));
	TASK_END(esp);
	CheckHr(qodc->GetRowset(0));
	CheckHr(qodc->NextRow(&fMoreRows));
	int retval;
	bool bRet = true;
	if (!fMoreRows)		// outer fMoreRows check
	{
		// UpdOrCreateAgentEval didn't return @retval.
		g_stuMsg = L"Database access problem (No @retval).";
		bRet = false;
		goto LExit;
	}
	CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&retval),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	switch (retval)
	{
	case 0:	// Success.
		break;

	default:
		g_stuMsg = L"Unspecified UpdOrCreateAgentEval stored procedure problem.";
		bRet = false;
		goto LExit;
		break;
	}

	LExit:
	qodc.Clear();
	TASK_END(uae);
	return bRet;
}

/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
StrUni XFPReader:: MakeXMLForAnalysisParameter (Vector<int> & viMsaIds, Vector<int> & viFormIds)
{
		// <Pair MsaId="492" FormId="494" Ord="1"/>

		StrUni stuXML = L"<root>";
		for (int i = 0; i < viMsaIds.Size(); ++i)
		{
			stuXML.FormatAppend(L"<Pair MsaId=\"%d\" FormId=\"%d\" Ord=\"%d\"/>",
				viMsaIds[i], viFormIds[i], i);
		}
		stuXML.Append(L"</root>");
		return stuXML;
}

/*----------------------------------------------------------------------------------------------
	Process an analysis, as represented by database ids of forms and MSAs. This includes:@end
		1. Find (or create) the analysis in the DB,
			An analysis is 'found', if its MoForm ids and MSA ids match what we have.
			They must match in: quantity, identity, and order.@end
		2. Set agent to analysis, if not already connected.

	@return True if successful, false otherwise.
----------------------------------------------------------------------------------------------*/
bool XFPReader::ProcessAnalysis(Vector<int> & viMsaIds, Vector<int> & viFormIds)
{


TASK_START(pp, "ProcessAnalysis");

	bool bRet = ((m_iCurrentAnalysisId == 0)
			&& (m_iAnalAgentId > 0)
			&& (m_iLDBId > 0)
			&& (m_iCurrentWordformId > 0)
			&& (m_viFormIds.Size() == m_viMsaIds.Size()));	// Sizes must be the same.

	if (!bRet)
	{
		g_stuMsg = L"Missing some required IDs or mis-matched form-MSA sizes.";
		return bRet;
	}

	try
	{


	//if(!FindOrCreateAnalysis(MakeXMLForAnalysisParameter()))
		//	return false; //goto LExit;
		
//		if (!AddAgentToValidatingSources())
//			return false; //goto LExit;

		//if (!UpdateOrCreateAgentEvaluation())
		//	return false; //goto LExit;

	bRet= UpdateAnalysisAndEvaluation(m_iAnalAgentId,	
										m_iCurrentWordformId, 
										MakeXMLForAnalysisParameter(viMsaIds, viFormIds), 
										m_strProcessingDetails.Chars(), 
										m_strTimeLastEngineUpdate.Chars());


	}
	catch (...)
	{
		g_stuMsg = L"Error while calling UpdateAnalysisAndEvaluation (which calls UpdWfiAnalysisAndEval$).";
		bRet = false;
	}



//LExit:
	return bRet;
}

/*----------------------------------------------------------------------------------------------
	Remove analyses which have no cmEvaluations pointing at them.

	@return True //TODO fix that.
----------------------------------------------------------------------------------------------*/
bool XFPReader::RemoveOldAnalyses()
{
	TASK_START(pp, "RemoveOldAnalyses");
	StrUni stuSqlStmt;
	IOleDbCommandPtr qodc;
	stuSqlStmt.Format(L"exec RemoveUnusedAnalyses$\n");
	AssertPtr(m_qode);
	CheckHr(m_qode->CreateCommand(&qodc));
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(),knSqlStmtNoResults));
	qodc.Clear();
	TASK_END(pp);
	return TRUE;
}

/*----------------------------------------------------------------------------------------------
this calls a stored procedure which creates the analysis if necessary, 
then creates the appropriate evaluation if necessary, 
and hooks them together appropriately. 
----------------------------------------------------------------------------------------------*/
bool XFPReader::UpdateAnalysisAndEvaluation (int hvoAgent, int hvoWordform, StrUni stuXMLAnalysis,
											 const wchar* strDetails,
											 const wchar* strCurrentEvaluationTime)
{


	TASK_START(fa, "UpdateAnalysisAndEvaluation() method");
	bool bRet = true;
	
	StrUni stuSqlStmt;
	ComBool fMoreRows;
	IOleDbCommandPtr qodc;

	ComBool fIsNull = false;
	ULONG cbSpaceTaken;


	/*PROC [UpdWfiAnalysisAndEval$]
			@nAgentId INT,
			@nWfiWordFormID INT, -------
			@ntXmlFormMsaPairIds NTEXT,
			@fAccepted BIT,
			@nvcDetails NVARCHAR(4000),
			@dtEval DATETIME
	*/

	//todo: get stuDetails in there


	stuSqlStmt.Format(L"DECLARE @d datetime;"
			L"set @d = '%s';"
			L"declare @retval int "
			L"exec @retval=UpdWfiAnalysisAndEval$ %d, %d, '%s', 1, 'an analysis eval', @d\n"
			L"select @retval", 
			strCurrentEvaluationTime,					//@dtEval DATETIME
			hvoAgent,							// @nAgentID INT,
			hvoWordform, 
			stuXMLAnalysis.Chars()
			//always '1' for 'accepted' here		//@fAccepted BIT,
		//	lpszDetails	//@nvcDetails NVARCHAR(4000),
			);


	AssertPtr(m_qode);
	CheckHr(m_qode->CreateCommand(&qodc));
	TASK_START(efc, "Executing UpdWfiAnalysisAndEval stored procedure");
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset));
	TASK_END(efc);



	CheckHr(qodc->GetRowset(0));
	CheckHr(qodc->NextRow(&fMoreRows));
	int retval;
	if (!fMoreRows)		// outer fMoreRows check
	{
		// UpdWfiAnalysisAndEval didn't return @retval.
		g_stuMsg = L"Database access problem (No @retval).";
		bRet = false;
		goto LExit;
	}
	CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&retval),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));


	if(!CheckReturnCode(retval,  stuXMLAnalysis.Chars()))
	{
		bRet = false;
		goto LExit;
	}


LExit:
	qodc.Clear();
	TASK_END(fa);
	return bRet;
}

/*----------------------------------------------------------------------------------------------
if the value of the return code in his success, just returns true.
Otherwise, it sets the global error message to something appropriate and returns false.

the values of the return code are defined in FindOrCreateWfiAnalysis 
and UpdWfiAnalysisAndEval, which calls it.
----------------------------------------------------------------------------------------------*/
bool XFPReader::CheckReturnCode(int iCode, const wchar* strContext)
{
	switch (iCode)
	{
	case 0:	// Success.
		return true;
		break;
	case 1:
		g_stuMsg = L"sp_xml_preparedocument error.";
		break;
	case 2:
		g_stuMsg = L"Form or MSA have no owner.";
		break;
	case 3:
		g_stuMsg = L"Form and MSA have different owners.";
		{
			assert(FALSE);
			//StrAnsi staOutStrDbgr;
			//staOutStrDbgr.Format(_T("Form and MSA have different owners. %s\n"), strContext);
			//OutputDebugString(staOutStrDbgr.Chars());
		}
		break;
	case 4:
		g_stuMsg = L"sp_xml_removedocument error.";
		break;
	case 5:
		g_stuMsg = L"CreateOwnedObject error.";
		break;
	case 6:
		g_stuMsg = L"Could not insert form data.";
		break;
	case 7:
		g_stuMsg = L"Could not insert MSA data.";
		break;
	default:
		g_stuMsg = L"Unspecified UpdWfiAnalysisAndEval stored procedure problem.";
		break;
	}
	return false;
}

