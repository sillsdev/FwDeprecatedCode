/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 1999, SIL International. All rights reserved.

File: Main.h
Responsibility: John Hatton
Last reviewed:

-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef ParseFiler_H
#define ParseFiler_H 1

#define NO_EXCEPTIONS 1
#include "Common.h" // Most of generic

//:>**********************************************************************************
//:>	Interfaces.
//:>**********************************************************************************
#include "ParseFilerTlb.h"
#include "FwKernelTlb.h"
#include "DbAccessTlb.h"
#include "OleDb.h"

#import <msxml3.dll> raw_interfaces_only 
using namespace MSXML2;

//:>**********************************************************************************
//:>	Types and constants used in Wfi DLL
//:>*********************************************************************************/

typedef enum AfiDllModuleDefns
{
	#define CMCG_SQL_ENUM 1
	#include "CmTypes.h"
	#include "Cellar.sqh"
	#include "LangProj.sqh"
	#include "FeatSys.sqh"
	#include "Ling.sqh"
	#undef CMCG_SQL_ENUM
} AfiDllModuleDefns;

//:>**********************************************************************************
//:>	Implementations.
//:>**********************************************************************************
#include "ParseFiler.h"
#include "XFPReader.h"

#endif
