#include <io.h>
#include <iostream>
#include <fstream>
using namespace std;

#pragma warning( disable : 4511  4512)
class SubTask;

#ifdef MAKE_REPORT_LOG 
#define TASK_START(_var, _name) 	SubTask _var(g_pReporter, _name);
#define TASK_END(_var)	_var.FinishAndReport();
#else
#define TASK_START(_var, _name)
#define TASK_END(_var)
#endif

//#define TASK_START(_name) 		#ifdef MAKE_REPORT_LOG \
//			SubTask t(g_pReporter, _name);\
//		#endif\


//note: Reporter is abstract, with subclasses defining how the reporting actually 
//		gets out, whether to a log file, the Console, an event, etc.
class Reporter
{
	public: 
		Reporter():m_iDepth(0) {	}
		virtual void ReportStart (SubTask* t)=0;
		virtual void ReportFinish (SubTask* t)=0;
		int m_iDepth;
};

class FileReporter: public Reporter
{
	public: ofstream m_log;

	public: FileReporter(const char*  sOutputPath)
				: Reporter()
			{
				m_log.open(sOutputPath,ios::out | ios::trunc);
			}
	//		void CloseOutput()
	//		{
	//			m_log.close(); assert(false);
	//		}

			~FileReporter()
			{
				 m_log.close();
			}

			virtual void ReportStart (SubTask* t);
			virtual void ReportFinish (SubTask* t);

};

//Used for timing/reporting progress
// Note that use of this allows subtasks to be nested inside each other
class SubTask 
{	
	
	public:	SubTask(Reporter *pReporter, const char *sMessage);
		
			long m_lSubTaskDepth;
			~SubTask();
			void FinishAndReport();


			long m_lStartTime;
			long m_lFinishTime;
			long m_lCounts;
			const char* m_sMessage;
			
			int m_iDepth;
protected:
	Reporter *m_pReporter;

};
