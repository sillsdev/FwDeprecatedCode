// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Class1.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
 using System.IO;
using NUnit;
using NUnit.Framework;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.Common.COMInterfaces;
using System.Diagnostics;
using System.Data.SqlClient;


//using SIL.FieldWorks.Common.COMInterfaces;

using SIL.FieldWorks.WordWorks.Parser;

namespace ParseFiler_UnitTests
{
	[TestFixture]
	public class WFIUtil_UnitTest
	{
		ParseFilerClass  m_filer;
		string m_databaseName;
		string m_testDirectory;
		string m_languageprojectName;
		FdoCache m_cache;
		WordformInventory m_WFI;

		public WFIUtil_UnitTest()
		{
		}

		[SetUp]
		public virtual void Initialize()
		{
			File.Delete(LogFilePath());

			m_databaseName = "ZPU";
			m_languageprojectName="ZPU-Yal�lag Zapotec";

			m_cache =FdoCache.Create (m_databaseName);		
			m_WFI = m_cache.LanguageProject.WordformInventoryOA;

			m_testDirectory =System.Environment.GetEnvironmentVariable("FWROOT") + @"\src\WW-Parser\ParserCore\ParseFiler\ParseFiler_UnitTests\" + m_databaseName +@"\";
			CreateUpdator();
		}

		protected void CreateUpdator()
		{
			m_filer = new ParseFilerClass();
			m_filer.Init(".\\SILFW", m_databaseName,  m_languageprojectName, "FwDeveloper", "Careful");
		}

		protected string LogFilePath()
		{
			return Environment.GetEnvironmentVariable("temp")+ @"\wfiUtilLog.txt";
		}
		protected void TypeOutLog()
		{
			try
			{
				//transferred the log to the standard output so we can read it in nunit
				FileStream reader =File.OpenRead(LogFilePath());

				int c= reader.ReadByte();
				while(c>0)
				{
					Console.Write((char)c);
					c= reader.ReadByte();
				}
				reader.Close();
			}
			catch
			{
				Console.WriteLine("Could not read the log file.  This happens when the WFIDLL has not been deleted yet, has when the test throws an exception.");
			}
		}
		
		[TearDown]
		public virtual void Exit()
		{
			if(m_cache.DatabaseAccessor.IsTransactionOpen())
				m_cache.DatabaseAccessor.RollbackTrans();

			m_cache.Dispose();
			TypeOutLog();
		}


		/// /TODO JohnH:move this to the FDO test suite
		//[Test]
		public void FDOCompetingTransactions()
		{
			FdoCache a = FdoCache.Create("ZPU");
			AddWord(a);
			a.Save();
			
//			bool bIsOpen;
//			a.DatabaseAccessor.IsTransactionOpen(out bIsOpen);
//			if(bIsOpen)
//				a.DatabaseAccessor.RollbackTrans();

			a.Dispose();
			FdoCache b = FdoCache.Create("ZPU");
			AddWord(b);
			b.Dispose();

		}
				
		protected WfiWordform FindOrCreateWordform(FdoCache c, string s)
		{
			int hvo= WordformInventory.FindOrCreateWordform(c.LanguageProject, s);
			return new WfiWordform(c, hvo);
		}

		protected void AddWord(FdoCache c)
		{
			//1) delete all existing analyses on this word
			const string kWordForm = "FDOCompetingTransactions";
			WfiWordform word = this.FindOrCreateWordform(c, kWordForm);
			word.AnalysesOC.Add(new WfiAnalysis());
		}			
	

		/// /TODO JohnH:move this to the FDO test suite
		//[Test]
		public void FDOBug()
		{
			FdoCache a = FdoCache.Create("ZPU");
			WordformInventory wfi = a.LanguageProject.WordformInventoryOA;

			AddWord(a);
			a.Save();
			
			WfiWordform word = FindOrCreateWordform(a, "FDOBugWord");
			foreach(int hvo in word.AnalysesOC.HvoArray)
			{
				word.AnalysesOC.Remove(hvo);
			}
			Assertion.Assert("could not remove the analyses from the word(b4save).", word.AnalysesOC.Count ==0);

			Assertion.Assert("Analyses not removed!", word.AnalysesOC.Count ==0);
			
			a.Dispose();
		}


//		[Test]
		public void FDOAnalysisAddRemove()
		{
			const string kWordForm = "ak"; // assertion below fails iff this work is already in the db from a previous run
			WfiWordform word = FindOrCreateWordform(m_cache, kWordForm);

			word.AnalysesOC.Add(new WfiAnalysis());
					
			m_cache.Save(); //the presence or abscwse of this does not affect the outcome

			foreach(int hvo in word.AnalysesOC.HvoArray)
			{
				word.AnalysesOC.Remove(hvo);
			}
			Assertion.Assert("Analyses removal failed.", word.AnalysesOC.Count ==0);
		}

		protected WfiWordform ClearAnalysesFromWord(String wf)
		{
		//	bool didCreate;
			WfiWordform word = FindOrCreateWordform(m_cache, wf);
		//	Assertion.Assert("The word being tested did not already exist in WordformInventory. I cannot create it without giving it a different hvo then is in the Xfp file.", 
		//		!didCreate);
			foreach(int hvo in word.AnalysesOC.HvoArray)
			{
				word.AnalysesOC.Remove(hvo);
			}
//			Assertion.Assert("could not remove the analyses from the word(b4save).", word.AnalysesOC.Count ==0);
			m_cache.Save();//commit the transaction

//			Assertion.Assert("could not remove the analyses from the word.", word.AnalysesOC.Count ==0);
//			Assertion.Assert( "The attempt to remove all of the analyses using FDO did not seem to work.",
//				0==CountAnalysesOfWord(kWordForm));

			return word;
		}

		protected String ReadUnicodeFile(string path)
		{
			Assertion.Assert( "The test file "+ path + " was not found", System.IO.File.Exists( path));
			TextReader  reader  = File.OpenText(path); // for UTF-8 only?
			return reader.ReadToEnd();

		}

		
		[Test]
		public void OneGoodWord()
		{
			//run the XFP file through the WFIUtil
			m_filer.ProcessParse ("FWParse", ReadUnicodeFile(m_testDirectory+ @"\OneGoodWord.xml"));

			Assertion.Assert("ak analyses was not correctly created", 
				CountAnalysesOfWord("ak") > 0);
		}
		
		[Test]
		public void TooManyAnalysesWord()
		{
			//run the XFP file through the WFIUtil
			m_filer.ProcessParse ("FWParse", ReadUnicodeFile(m_testDirectory+ @"\XFP Exception Too Many Analyses.xml"));

			Assertion.Assert("chanll analyses was not correctly created", 
				CountAnalysesOfWord("chanll") > 0);
		}
		
		[Test]
		[Ignore("buffer overrun handling has not been implemented.")]
		public void BufferOverrunWord()
		{
			//run the XFP file through the WFIUtil
			m_filer.ProcessParse ("FWParse", ReadUnicodeFile(m_testDirectory+ @"\XFP Exception  Buffer Overrun.xml"));

			//as a February 14, 2003, this test did not pass.

			Assertion.Assert("chanll analyses was not correctly created", 
				CountAnalysesOfWord("chanll") > 0);
		}
				

		[Test]
		public void CheckForClobbering()
		{
			//TODO JohnH:need a way to remove the hard coding to a particular word here, which must be the 
			//same as the input file.
			//const string kWordForm = "ak";
			WfiWordform word1 = ClearAnalysesFromWord("ak");
			WfiWordform word2 = ClearAnalysesFromWord("ake");

			Console.WriteLine( "Before submitting the file, the 'ak' has " +CountAnalysesOfWord("ak").ToString() + " analyses.");
			Console.WriteLine( "Before submitting the file, the 'ake' has " +CountAnalysesOfWord("ake").ToString() + " analyses.");

			//2) run the XFP file through the WFIUtil
			m_filer.ProcessParse ("FWParse", ReadUnicodeFile(m_testDirectory+ @"\XFP For WfiUtil Testing1.xml"));

			//3) check to see there are some analyses now
			//ENHANCE: noticed that we are not checking how many analyses, as we have no idea how many there should be!

			Console.WriteLine( "After submitting the file, the ak now has " +CountAnalysesOfWord("ak").ToString() + " analyses.");
			Console.WriteLine( "After submitting the file, the ake now has " +CountAnalysesOfWord("ake").ToString() + " analyses.");

			int akCount = CountAnalysesOfWord("ak");
			Assertion.Assert("either ak did not parse, its analysis was not correctly created, or its analysis was clobbered by the second word.", 
				akCount > 0);
			Assertion.Assert("either ake did not parse, or its analysis was not correctly created", 
				CountAnalysesOfWord("ake") > 0);

//			Assertion.Assert("FDO did not track the change in the number of analyses", 
//				word.AnalysesOC.Count != CountAnalysesOfWord(kWordForm));

			if(word1.AnalysesOC.Count != FDOCountAnalysesOfWord("ak"))
				Console.WriteLine( @"warning\nwarning\nwarning\n. fdo did nottrack the changes that we made to a Wordform");

			//3) run the 2nd XFP file through the WFIUtil
			CreateUpdator();//make a new one, checking  a theory
			m_filer.ProcessParse ("FWParse", ReadUnicodeFile(m_testDirectory+ @"\XFP For WfiUtil Testing2.xml"));
			
			//check on the words that were parse in the first round, make sure they were not hurt.
			Assertion.Assert("The analysis of 'ak' was clobbered by the second xfp file.", 
				CountAnalysesOfWord("ak") == akCount);
}

		protected int CountAnalysesOfWord (string wordform)
		{
			//	bool didCreate;
			WfiWordform word = FindOrCreateWordform(m_cache, wordform);
			//	Assertion.Assert(!didCreate);

			// this uses FTD, which is not up to date when dealing with the work of the wfiutil:
			// return word.AnalysesOC.Count;

			return CountAnalysesOfWord(word.Hvo, m_cache.LanguageProject.DefaultVernacularWritingSystem);
		}
		protected int FDOCountAnalysesOfWord (string wordform)
		{
			//	bool didCreate;
			WfiWordform word = FindOrCreateWordform(m_cache, wordform);
			//	Assertion.Assert(!didCreate);

			// this uses FTD, which may not be up to date when dealing with the work of the wfiutil:
			 return word.AnalysesOC.Count;
		}

		protected string GetConnectionString ()
		{
			return  "Server=" + ".\\SILFW" + "; Database=" +"ZPU"+ "; User ID=FWDeveloper;"
				+ "Password=careful";

		}
		protected int CountAnalysesOfWord(int hvo, int vernacularEncoding)
		{
			using (SqlConnection connection = new SqlConnection (GetConnectionString()))
			{
				try
				{
					connection.Open();
					SqlCommand command = connection.CreateCommand ();
					command.CommandType = System.Data.CommandType.Text;
					command.CommandText = "select  count(*) from Wfiwordform_analyses (readuncommitted) where Src = "+hvo.ToString();
					int i =(int)command.ExecuteScalar();
					connection.Close ();
					return i;
				}
				catch (Exception error)
				{
					Debug.Assert( error == null);
					throw error;
				}
			}
		}

	}
}
