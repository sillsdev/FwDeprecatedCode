//#include "stdafx.h"

#include <comdef.h>
#include "assert.h"
#include <io.h>
#include <ios>
#include <strstream>
#include <time.h>
#include "reporter.h"

long GetPerfCounts()
{
	LARGE_INTEGER liCount;
	assert(QueryPerformanceCounter(&liCount)) ;

	return (long) (liCount.QuadPart);
}

SubTask::SubTask(Reporter *pReporter, const char* sMessage)
:m_pReporter(pReporter), m_lStartTime(0), m_lFinishTime(0), m_lCounts(0), m_sMessage(sMessage)
{
	assert(m_pReporter);
	m_lSubTaskDepth= m_pReporter->m_iDepth;	
	++m_pReporter->m_iDepth;

	m_lStartTime = GetPerfCounts(); //GetTickCount() ;

	m_pReporter->ReportStart(this);
}
// note that it is possible for tasks to be created and released out of order, messing things up
// ideally, we'd be sticking these things on a "subtask stack" of the reporter, removing that problem.
SubTask::~SubTask()
{
	if(m_lFinishTime ==0) // not reported yet (owner did not explicitly call FinishandReport())
		FinishAndReport();
}
void SubTask::FinishAndReport()
{
	m_lFinishTime = GetPerfCounts();// GetTickCount() 
	m_lCounts = m_lFinishTime - m_lStartTime;
	m_pReporter->ReportFinish(this);
	--m_pReporter->m_iDepth;
}

void FileReporter::ReportStart (SubTask* t)
{
	for(int i=0; i<t->m_lSubTaskDepth; i++)
		m_log << "   ";
	m_log << "Start " << t->m_sMessage << "\n";
}



void FileReporter::ReportFinish (SubTask* t)
{
	for(int i=0; i<t->m_lSubTaskDepth; i++)
		m_log << "   ";

	LARGE_INTEGER liFreq;
	assert(QueryPerformanceFrequency(&liFreq));

	double ms = 1000.0 * t->m_lCounts/liFreq.QuadPart;
	m_log << "End " << t->m_sMessage << ": "<< ms << " ms\n";
	//m_log << "End " << t->m_sMessage << ": (" << t->m_lFinishTime << "-" << t->m_lStartTime << " = "<< t->m_lCounts << ")\n";
}


