// XFPReader.h: interface for the XFPReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XFPReader_H__E1B3AF99_0FA6_44CD_82E3_55719F9E3806__INCLUDED_)
#define AFX_XFPReader_H__E1B3AF99_0FA6_44CD_82E3_55719F9E3806__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SAXContentHandlerImpl.h"

class XFPReader : public SAXContentHandlerImpl  
{
public:
	XFPReader(IOleDbEncap * pode, int iLpId, int iLDBId, int IParseFilerId, int iAnalWs);
	virtual ~XFPReader();

	virtual HRESULT STDMETHODCALLTYPE startElement( 
		/* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri,
		/* [in] */ int cchNamespaceUri,
		/* [in] */ wchar_t __RPC_FAR *pwchLocalName,
		/* [in] */ int cchLocalName,
		/* [in] */ wchar_t __RPC_FAR *pwchRawName,
		/* [in] */ int cchRawName,
		/* [in] */ ISAXAttributes __RPC_FAR *pAttributes);

	virtual HRESULT STDMETHODCALLTYPE endElement( 
		/* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri,
		/* [in] */ int cchNamespaceUri,
		/* [in] */ wchar_t __RPC_FAR *pwchLocalName,
		/* [in] */ int cchLocalName,
		/* [in] */ wchar_t __RPC_FAR *pwchRawName,
		/* [in] */ int cchRawName);

	virtual HRESULT STDMETHODCALLTYPE startDocument();

protected:
	bool ExistsWordsform();
	bool GetAnalyzingAgent(StrUni * pstuName, bool fHuman, StrUni * pstuVersion);
	bool ProcessAnalysis(Vector<int> & viMsaIds, Vector<int> & viFormIds);
	bool RemoveOldAnalyses();
	bool FindOrCreateAnalysis (StrUni stuXML);
	//bool AddAgentToValidatingSources();
	StrUni MakeXMLForAnalysisParameter (Vector<int> & viMsaIds, Vector<int> & viFormIds);
	bool CheckReturnCode(int code, const wchar*  lpszContext);
	bool UpdateAnalysisAndEvaluation (int hvoAgent, int hvoWordform, StrUni stuXMLAnalysis, 
										const wchar*  strDetails, const wchar* strCurrentEvaluationTime);

	bool UpdateOrCreateAgentEvaluation(int hvoAgent, int hvoTarget,
											 const wchar* strDetails,
											 const wchar* strCurrentEvaluationTime);

	/*------------------------------------------------------------------------------------------
		Clear out the data members, since there was an error somewhere.
	------------------------------------------------------------------------------------------*/
	void ResetMembers()
	{
		m_qode = NULL;
		m_iAnalWs = 0;
		m_iLpId = 0;
		m_iLDBId = 0;
		m_IParseFilerId = 0;
		m_iAnalAgentId = 0;
		ResetForNextWord();
	}

	/*------------------------------------------------------------------------------------------
		Clear out the data related to a particular word, get read for the next one
	------------------------------------------------------------------------------------------*/
	void ResetForNextWord()
	{
		m_iCurrentWordformId = 0;
		m_iCurrentAnalysisId = 0;
//		m_viAnalIds.Clear();
		m_viFormIds.Clear();
		m_viMsaIds.Clear();
	}

	/*------------------------------------------------------------------------------------------
		Database access object.
	------------------------------------------------------------------------------------------*/
	IOleDbEncapPtr m_qode;
	/*------------------------------------------------------------------------------------------
		Default analysis writing system.
	------------------------------------------------------------------------------------------*/
	int m_iAnalWs;
	/*------------------------------------------------------------------------------------------
		Language Project database ID.
	------------------------------------------------------------------------------------------*/
	int m_iLpId;
	/*------------------------------------------------------------------------------------------
		Lexical DB database ID.
	------------------------------------------------------------------------------------------*/
	int m_iLDBId;
	/*------------------------------------------------------------------------------------------
		Wfi database ID.
	------------------------------------------------------------------------------------------*/
	int m_IParseFilerId;
	/*------------------------------------------------------------------------------------------
		Database access object.
	------------------------------------------------------------------------------------------*/
	int m_iAnalAgentId;
	/*------------------------------------------------------------------------------------------
		Database ID for the wordform that is currently being processed.
	------------------------------------------------------------------------------------------*/
	int m_iCurrentWordformId;
	/*------------------------------------------------------------------------------------------
		Database ID for the analysis that is currently being processed.
	------------------------------------------------------------------------------------------*/
	int m_iCurrentAnalysisId;
	/*------------------------------------------------------------------------------------------
		WfiAnalysis database ids.
	------------------------------------------------------------------------------------------*/
//	Vector<int> m_viAnalIds;
	/*------------------------------------------------------------------------------------------
		MoForm database ids.
	------------------------------------------------------------------------------------------*/
	Vector<int> m_viFormIds;
	/*------------------------------------------------------------------------------------------
		MSA database ids.
	------------------------------------------------------------------------------------------*/
	Vector<int> m_viMsaIds;

	StrUni m_strTimeLastEngineUpdate;
	StrUni m_strProcessingDetails;
};

#endif // !defined(AFX_XFPReader_H__E1B3AF99_0FA6_44CD_82E3_55719F9E3806__INCLUDED_)
