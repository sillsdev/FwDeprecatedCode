// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Class1.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using NUnit.Framework;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;

using SIL.FieldWorks.FDO.Scripture;
using SIL.FieldWorks.FDO.Scripture.Generated;
using SIL.FieldWorks.FDO.Cellar.Generated;

using System.Diagnostics;
using System.Data.SqlClient;

using SIL.FieldWorks.WordWorks.Parser;

namespace Parser_UnitTests
{
	/// <summary>
	/// </summary>
	[TestFixture]
	public class TestParser
	{
		protected FdoCache m_cache;
		protected ParserWorker m_parser;

		public TestParser()
		{

		}

		/// <summary></summary>
		[SetUp]
		public virtual void SetUp()
		{
			try
			{
				m_cache = FdoCache.Create("ZPU");
			}
			catch (Exception )
			{
				Assertion.Fail("Failed to open a FDOCache on ZPU. Note: this test requires the ZPU database to be loaded.");
			}
			Assertion.Assert("Failed to open a FDOCache on ZPU. Note: this test requires the ZPU database to be loaded.", m_cache != null);

			m_parser = new ParserWorker(".\\SILFW", "ZPU", "ZPU-Yala�lag Zapotec", null);
			m_parser.  LoadGrammarAndLexicon();
		}

		protected WfiWordform FindOrCreateWordform(FdoCache c, string s)
		{
			int hvo= WordformInventory.FindOrCreateWordform(c.LanguageProject, s);
			return new WfiWordform(c, hvo);
		}
		
		protected WfiWordform ClearAnalysesFromWord(String wf)
		{
			//	bool didCreate;
			WfiWordform word = FindOrCreateWordform(m_cache, wf);
			//	Assertion.Assert("The word being tested did not already exist in WordformInventory. I cannot create it without giving it a different hvo then is in the Xfp file.", 
			//		!didCreate);
			foreach(int hvo in word.AnalysesOC.HvoArray)
			{
				word.AnalysesOC.Remove(hvo);
			}
			//			Assertion.Assert("could not remove the analyses from the word(b4save).", word.AnalysesOC.Count ==0);
			m_cache.Save();//commit the transaction

			//			Assertion.Assert("could not remove the analyses from the word.", word.AnalysesOC.Count ==0);
			//			Assertion.Assert( "The attempt to remove all of the analyses using FDO did not seem to work.",
			//				0==CountAnalysesOfWord(kWordForm));

			return word;
		}
		
		[Test]
		public void ParseSomeGoodWords()
		{
			CheckThatWordParses("ak");
			CheckThatWordParses("ake");

			//make sure the analysis did not clobber the analyses of the first word
			Assertion.Assert("Analyses of previous word got clobbered!", CountAnalysesOfWord("ak")>0);

			CheckThatWordParses("aken");
			CheckThatWordParses("chetjen");
		}

		[Test]
		public void WordWithTooManyAnalyses()
		{
			CheckThatWordParses("chanll");
		}
	

		protected void CheckThatWordParses(string word)
		{
			WfiWordform wordform = ClearAnalysesFromWord(word);
			Assertion.Assert(CountAnalysesOfWord(word) == 0);
			m_parser. UpdateWordform(wordform.Hvo);
			Assertion.Assert(CountAnalysesOfWord(word) > 0);

		}

		protected int CountAnalysesOfWord (string wordform)
		{
			//	bool didCreate;
			WfiWordform word = FindOrCreateWordform(m_cache, wordform);
			//	Assertion.Assert(!didCreate);

			// this uses FTD, which is not up today when dealing with the work of the wfiutil:
			// return word.AnalysesOC.Count;

			return CountAnalysesOfWord(word.Hvo, m_cache.LanguageProject.DefaultVernacularWritingSystem);
		}

		protected string GetConnectionString ()
		{
			return  "Server=" + ".\\SILFW" + "; Database=" +"ZPU"+ "; User ID=FWDeveloper;"
				+ "Password=careful";

		}
		protected int CountAnalysesOfWord(int hvo, int vernacularEncoding)
		{
			using (SqlConnection connection = new SqlConnection (GetConnectionString()))
			{
				try
				{
					connection.Open();
					SqlCommand command = connection.CreateCommand ();
					command.CommandType = System.Data.CommandType.Text;
					command.CommandText = "select  count(*) from Wfiwordform_analyses (readuncommitted) where Src = "+hvo.ToString();
					int i =(int)command.ExecuteScalar();
					connection.Close ();
					return i;
				}
				catch (Exception error)
				{
					Debug.Assert( error == null);
					throw error;
				}
			}
		}
	}
}
