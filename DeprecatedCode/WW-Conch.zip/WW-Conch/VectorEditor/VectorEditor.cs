// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: VectorEditor.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Collections;
using System.Diagnostics;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Xml;
using System.Reflection;
using System.IO;
using System.Resources;

using SIL.FieldWorks;
using SIL.FieldWorks.Common.Framework.TreeForms;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Utils;

namespace SIL.WordWorks.Conch
{

	/// <summary>
	/// Summary description for VectorEditor.
	/// </summary>
	public class VectorEditor : TPlugin
	{
		/// <summary>
		/// Index in owning flid of the current object, or -1 if no objects.
		/// </summary>
		protected int m_currentIndex;
		/// <summary>
		/// 
		/// </summary>
		protected XdeTemplateCollector m_xdeTemplateCollector;
		/// <summary>
		/// Tree form.
		/// </summary>
		protected DataTree m_dataEntryForm;
		/// <summary>
		/// This is the database object whose vector we are editing.
		/// </summary>
		protected CmObject m_owningObject;
		/// <summary>
		/// Field ID of the vector which we are editing.
		/// </summary>
		protected int m_flid;
		/// <summary>
		/// Mode string for DataTree to use at top level.
		/// </summary>
		protected string m_rootMode;
		/// <summary>
		/// Object currently being edited in the data entry view.
		/// </summary>
		protected CmObject m_currentObject;
		protected StatusBarPanel m_statusBarPanel;
		protected ArrayList m_insertOptions;
		protected bool m_fIsSequence;
		protected string[] m_customTemplatePaths;

		private System.Windows.Forms.ContextMenu m_contextMenu;
		private System.Windows.Forms.MenuItem m_mnuFirst;
		private System.Windows.Forms.MenuItem m_mnuPrevious;
		private System.Windows.Forms.MenuItem m_mnuNext;
		private System.Windows.Forms.MenuItem m_mnuLast;
		private System.Windows.Forms.ToolBarButton m_tbFirst;
		private System.Windows.Forms.ToolBarButton m_tbPrevious;
		private System.Windows.Forms.ToolBarButton m_tbNext;
		private System.Windows.Forms.ToolBarButton m_tbLast;
		private System.Windows.Forms.ImageList m_toolbarImages;
		private System.Windows.Forms.ToolBar m_toolBar;
		private System.Windows.Forms.ContextMenu m_contextMenuEdit;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem m_mnuDelete;
		private System.ComponentModel.IContainer components;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="VectorEditor"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public VectorEditor()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			m_currentIndex = 0;
		}

		/// <summary>
		/// prepare the plug-in for use
		/// </summary>
		/// <remarks> this is separate from the constructor because of the way we are creating with reflection</remarks>
		/// <param name="cache"></param>
		public override void Initialize(Hashtable widgets, FdoCache cache)
		{
			// MenuItem menuTools, MenuItem menuInsert, StatusBar statusBar,
			/*
			if(m_paramNode == null) //we haven't developed that feature yet
			{
				XmlDocument xdoc = new XmlDocument();
				xdoc.LoadXml("<params collectionField='Entries'> </params>");
				m_paramNode = xdoc.SelectSingleNode("params");
			}*/
			m_currentIndex = 0;

			base.Initialize(widgets, cache);
			ReadParameters();
			m_fIsSequence = cache.GetFieldType(m_flid) == (int)FieldType.kcptOwningSequence;
			m_xdeTemplateCollector = new XdeTemplateCollector(m_customTemplatePaths);
			InitializeDataTree();
			ShowRecord();
		}

		protected void InitializeDataTree()
		{
			// I (JH) could not get the designer to let me drag this on to the form, so I add it here.
			m_dataEntryForm = new DataTree();
			m_dataEntryForm.RootMode = m_rootMode;
			m_dataEntryForm.Dock = System.Windows.Forms.DockStyle.Fill;

			m_dataEntryForm.Initialize(m_cache, true);
			Controls.Add(m_dataEntryForm);
		}

		public override void ResetCache(FdoCache cache)
		{
			if((m_dataEntryForm != null) && Controls.Contains(m_dataEntryForm))
			{
				if (m_cache != null)
					m_cache.Save();
				m_dataEntryForm.Hide();
				m_dataEntryForm.Dispose();
				Controls.Remove(m_dataEntryForm);
				m_dataEntryForm = null;
			}
			m_cache = cache;
			ReadParameters();
			InitializeDataTree();
			m_currentIndex = 0;
			ShowRecord();
		}

		protected override void AddEditMenuItems()
		{
			Debug.Assert(m_menuEdit != null);
			m_menuEdit.MergeMenu(m_contextMenuEdit);
		}

		protected override void RemoveEditMenuItems()
		{
			Debug.Assert(m_menuEdit != null);
			int cnt = m_menuEdit.MenuItems.Count;
			m_menuEdit.MenuItems.RemoveAt(--cnt);
			m_menuEdit.MenuItems.RemoveAt(--cnt);
		}

		protected override void AddInsertMenuItems()
		{
			Debug.Assert(m_menuInsert != null);
			this.SuspendLayout();
			// Get rid of old sub-menu items.
			m_menuInsert.MenuItems.Clear();
			m_insertOptions = new ArrayList();
			m_cache.AddClassesForField((uint)m_flid, true, m_insertOptions);
			// Get rid of un-supported classes.
			for (int i = m_insertOptions.Count - 1; i > -1; --i)
			{
				ClassAndPropInfo cpi = (ClassAndPropInfo)m_insertOptions[i];
				if (cpi.signatureClassName == "PhNCFeatures"
					|| cpi.signatureClassName == "MoCoordinateCompound"
					|| cpi.signatureClassName == "MoBinaryCompoundRule")
					m_insertOptions.RemoveAt(i);
			}
			foreach(ClassAndPropInfo cpi in m_insertOptions)
			{
				m_menuInsert.MenuItems.Add(new MenuItem(
					cpi.signatureClassName,
					new EventHandler(HandleInsertMenuItem)));
			}
			// Add various menu items.
			m_menuInsert.Enabled = true;
			this.ResumeLayout(false);
		}

		protected override void AddToolsMenuItems()
		{
			Debug.Assert(m_menuTools != null);
			this.SuspendLayout();
			m_menuTools.MergeMenu(m_contextMenu);
			m_menuTools.Enabled = true;
			this.ResumeLayout(false);
		}

		protected override void SetupStatusBar()
		{
			Debug.Assert(m_statusBar != null && !m_statusBar.HasChildren);
			this.SuspendLayout();
			m_statusBarPanel = new StatusBarPanel();
			m_statusBarPanel.AutoSize = StatusBarPanelAutoSize.Spring;
			m_statusBar.Panels.Add(m_statusBarPanel);
			m_statusBar.Dock = DockStyle.Bottom;
			Controls.Add(m_statusBar);
			SetStatusBarContents();
			this.ResumeLayout(false);
		}

		protected override void SetupToolBars()
		{
			m_toolBars.Add(m_toolBar);
		}

		//this is a hack; it seems like we should be getting back an FDOVector, but fdocache doesn't offer one of those
		//in any case, this must be beefed up to deal with PQ there which will be changing (growing, shrinking)
		protected int[] Vector
		{
			get
			{
				return m_cache.GetVectorProperty(m_owningObject.Hvo, m_flid);
			}
		}

		/// <summary>
		/// Read in the parameters to determine which collection we are editing.
		/// </summary>
		/// <remarks> notice that currently, we do not require (or allow)
		/// the class owning object to be specified. It is inferred.
		/// Also notice that we assume that all of these collections are owned by,
		/// essentially, a Singleton object in the database.  For example,
		/// there is only one lexical database, so we do not need nor have a need for a way to
		/// specify which lexical database we want to browse.</remarks>
		/// <remarks> The initial plan was to do something smarter, so that we would not have this
		/// big switch statement.  There are various possibilities, but this is our first pass
		/// in order to get something working.</remarks>
		protected void ReadParameters()
		{
			m_customTemplatePaths = null;
			string customTemplatePaths = XmlUtils.GetOptionalAttributeValue(m_paramNode, "customTemplatePaths");
			if (customTemplatePaths != null)
				m_customTemplatePaths = customTemplatePaths.Split(',');
			XmlAttribute xa = m_paramNode.Attributes["mode"];
			if (xa != null)
				m_rootMode = xa.Value;
			string field = XmlUtils.GetManditoryAttributeValue(m_paramNode, "collectionField");
			switch(field)
			{
				default:
					System.Windows.Forms.MessageBox.Show("The field '"
						+ field
						+ "' has not been implemented in the switch statement in ReadParameters().");
					break;

				// Other supported stuff
				case "Entries":
					m_owningObject = m_cache.LanguageProject.LexicalDatabaseOA;
					m_flid = (int)SIL.FieldWorks.FDO.Ling.Generated.BaseLexicalDatabase.LexicalDatabaseTags.kflidEntries;
					break;
				case "PartsOfSpeech":
					m_owningObject = m_cache.LanguageProject.PartsOfSpeechOA;
					m_flid = (int)SIL.FieldWorks.FDO.Cellar.Generated.BaseCmPossibilityList.CmPossibilityListTags.kflidPossibilities;
					break;

				// phonology
				case "PhonemeSets":
					m_owningObject = m_cache.LanguageProject.PhonologicalDataOA;
					m_flid = (int)SIL.FieldWorks.FDO.Ling.Generated.BasePhPhonologicalData.PhPhonologicalDataTags.kflidPhonemeSets;
					break;
				case "Environments":
					m_owningObject = m_cache.LanguageProject.PhonologicalDataOA;
					m_flid = (int)SIL.FieldWorks.FDO.Ling.Generated.BasePhPhonologicalData.PhPhonologicalDataTags.kflidEnvironments;
					break;
				case "NaturalClasses":
					m_owningObject = m_cache.LanguageProject.PhonologicalDataOA;
					m_flid = (int)SIL.FieldWorks.FDO.Ling.Generated.BasePhPhonologicalData.PhPhonologicalDataTags.kflidNaturalClasses;
					break;

				// morphology
				case "AdhocCoprohibitions":
					m_owningObject = m_cache.LanguageProject.MorphologicalDataOA;
					m_flid = (int)SIL.FieldWorks.FDO.Ling.Generated.BaseMoMorphologicalData.MoMorphologicalDataTags.kflidAdhocCoProhibitions;
					break;
				case "CompoundRules":
					m_owningObject = m_cache.LanguageProject.MorphologicalDataOA;
					m_flid = (int)SIL.FieldWorks.FDO.Ling.Generated.BaseMoMorphologicalData.MoMorphologicalDataTags.kflidCompoundRules;
					break;
			}
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged 
		/// resources; <c>false</c> to release only unmanaged resources. 
		/// </param>
		/// -----------------------------------------------------------------------------------
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
					components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(VectorEditor));
			this.m_contextMenu = new System.Windows.Forms.ContextMenu();
			this.m_mnuFirst = new System.Windows.Forms.MenuItem();
			this.m_mnuPrevious = new System.Windows.Forms.MenuItem();
			this.m_mnuNext = new System.Windows.Forms.MenuItem();
			this.m_mnuLast = new System.Windows.Forms.MenuItem();
			this.m_toolBar = new System.Windows.Forms.ToolBar();
			this.m_tbFirst = new System.Windows.Forms.ToolBarButton();
			this.m_tbPrevious = new System.Windows.Forms.ToolBarButton();
			this.m_tbNext = new System.Windows.Forms.ToolBarButton();
			this.m_tbLast = new System.Windows.Forms.ToolBarButton();
			this.m_toolbarImages = new System.Windows.Forms.ImageList(this.components);
			this.m_contextMenuEdit = new System.Windows.Forms.ContextMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.m_mnuDelete = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// m_contextMenu
			// 
			this.m_contextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						  this.m_mnuFirst,
																						  this.m_mnuPrevious,
																						  this.m_mnuNext,
																						  this.m_mnuLast});
			// 
			// m_mnuFirst
			// 
			this.m_mnuFirst.Index = 0;
			this.m_mnuFirst.Shortcut = System.Windows.Forms.Shortcut.CtrlF;
			this.m_mnuFirst.Text = "&First";
			this.m_mnuFirst.Click += new System.EventHandler(this.NavigateFirst_Click);
			// 
			// m_mnuPrevious
			// 
			this.m_mnuPrevious.Index = 1;
			this.m_mnuPrevious.Shortcut = System.Windows.Forms.Shortcut.CtrlP;
			this.m_mnuPrevious.Text = "&Previous";
			this.m_mnuPrevious.Click += new System.EventHandler(this.NavigatePrevious_Click);
			// 
			// m_mnuNext
			// 
			this.m_mnuNext.Index = 2;
			this.m_mnuNext.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
			this.m_mnuNext.Text = "&Next";
			this.m_mnuNext.Click += new System.EventHandler(this.NavigateNext_Click);
			// 
			// m_mnuLast
			// 
			this.m_mnuLast.Index = 3;
			this.m_mnuLast.Shortcut = System.Windows.Forms.Shortcut.CtrlL;
			this.m_mnuLast.Text = "&Last";
			this.m_mnuLast.Click += new System.EventHandler(this.NavigateLast_Click);
			// 
			// m_toolBar
			// 
			this.m_toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						 this.m_tbFirst,
																						 this.m_tbPrevious,
																						 this.m_tbNext,
																						 this.m_tbLast});
			this.m_toolBar.ButtonSize = new System.Drawing.Size(16, 15);
			this.m_toolBar.DropDownArrows = true;
			this.m_toolBar.ImageList = this.m_toolbarImages;
			this.m_toolBar.Name = "m_toolBar";
			this.m_toolBar.ShowToolTips = true;
			this.m_toolBar.Size = new System.Drawing.Size(568, 24);
			this.m_toolBar.TabIndex = 0;
			this.m_toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
			// 
			// m_tbFirst
			// 
			this.m_tbFirst.ImageIndex = 0;
			// 
			// m_tbPrevious
			// 
			this.m_tbPrevious.ImageIndex = 1;
			// 
			// m_tbNext
			// 
			this.m_tbNext.ImageIndex = 2;
			// 
			// m_tbLast
			// 
			this.m_tbLast.ImageIndex = 3;
			// 
			// m_toolbarImages
			// 
			this.m_toolbarImages.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.m_toolbarImages.ImageSize = new System.Drawing.Size(16, 15);
			this.m_toolbarImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("m_toolbarImages.ImageStream")));
			this.m_toolbarImages.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// m_contextMenuEdit
			// 
			this.m_contextMenuEdit.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							  this.menuItem1,
																							  this.m_mnuDelete});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "-";
			// 
			// m_mnuDelete
			// 
			this.m_mnuDelete.Index = 1;
			this.m_mnuDelete.Text = "Delete...";
			this.m_mnuDelete.Click += new System.EventHandler(this.HandleDeleteMenuItem);
			// 
			// VectorEditor
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.m_toolBar});
			this.Name = "VectorEditor";
			this.Size = new System.Drawing.Size(568, 456);
			this.ResumeLayout(false);

		}
		#endregion

		protected void ShowRecord()
		{
			if (m_cache != null)
			{
				m_cache.Save();
				m_cache.DatabaseAccessor.BeginTrans();
			}
			int[] vec = Vector;
			if (vec == null || vec.Length == 0)
			{
				m_currentIndex = -1;
				m_currentObject = null;
				return;
			}
			m_currentObject = CmObject.CreateFromDBObject(m_cache, Vector[m_currentIndex]);

			try
			{
				Cursor.Current = Cursors.WaitCursor;
				m_xdeTemplateCollector.Reload();//enhance: this is just here to allow changing the templates without the starting the application.
				m_dataEntryForm.ShowObject(m_currentObject.Hvo, m_xdeTemplateCollector.Templates);
				SetStatusBarContents();
				Cursor.Current = Cursors.Default;
			}
			catch(Exception error)
			{
				System.Windows.Forms.MessageBox.Show("There was an error while trying to build the tree form for the subject. " + error.Message);
			}
		}

		private void SetStatusBarContents()
		{
			if (m_statusBarPanel == null)
				return;

			if (m_currentIndex >= 0)
				m_statusBarPanel.Text = (m_currentIndex + 1) + " / " + Vector.Length.ToString()
					+ " : " + m_currentObject.GetType().Name;
			else
				m_statusBarPanel.Text = "Use Insert menu to add the first object.";
		}

		private void NavigateFirst_Click(object sender, System.EventArgs e)
		{
			DoFirst();
		}

		private void NavigateNext_Click(object sender, System.EventArgs e)
		{
			DoNext();
		}

		private void NavigatePrevious_Click(object sender, System.EventArgs e)
		{
			DoPrevious();
		}

		private void NavigateLast_Click(object sender, System.EventArgs e)
		{
			DoLast();
		}

		private void DoFirst()
		{
			m_currentIndex = 0;
			ShowRecord();
		}

		private void DoNext()
		{
			m_currentIndex = Math.Min(m_currentIndex + 1, Vector.Length - 1);
			ShowRecord();
		}

		private void DoPrevious()
		{
			m_currentIndex = Math.Max(m_currentIndex - 1, 0);
			ShowRecord();
		}

		private void DoLast()
		{
			m_currentIndex = Math.Max(Vector.Length - 1, 0);
			ShowRecord();
		}

		private void JumpToRecord(int jumpToHvo)
		{
			int[] hvos = Vector;
			Debug.Assert(hvos != null);
			for (int i = 0; i < hvos.Length; i++)
			{
				if (hvos[i] == jumpToHvo)
				{
					m_currentIndex = i;
					ShowRecord();
					return;
				}
			}
			Debug.Assert(false); // Not in vector.
		}
		
		private void toolBar_ButtonClick(Object sender, ToolBarButtonClickEventArgs e)
		{
			switch(m_toolBar.Buttons.IndexOf(e.Button))
			{
				case 0:
					DoFirst();
					break; 
				case 1:
					DoPrevious();
					break; 
				case 2:
					DoNext();
					break;
				case 3:
					DoLast();
					break; 
			}
		}

		private void HandleInsertMenuItem(object sender, EventArgs ea)
		{
			ClassAndPropInfo cpi = (ClassAndPropInfo)m_insertOptions[((MenuItem)sender).Index];
			int ihvoPosition = Vector.Length;
			m_cache.BeginUndoTask(
				"Undo add " + cpi.signatureClassName + " to " + cpi.fieldName,
				"Redo add " + cpi.signatureClassName + " to " + cpi.fieldName);
			int hvoNew = m_cache.CreateObject((int)(cpi.signatureClsid), m_owningObject.Hvo, m_flid, ihvoPosition);
			m_cache.EndUndoTask();
			m_cache.MainCacheAccessor.PropChanged(null,
				1, /* kpctNotifyAll */
				m_owningObject.Hvo, m_flid, ihvoPosition, 1, 0);
			JumpToRecord(hvoNew);
		}

		private void HandleDeleteMenuItem(object sender, System.EventArgs e)
		{
			if (DialogResult.Yes == MessageBox.Show("Are you sure you want to zap it?",
					"Oyster", 
					MessageBoxButtons.YesNo,
					MessageBoxIcon.Question))
			{
				string className = m_currentObject.GetType().Name;
				m_cache.BeginUndoTask(
					"Undo delete " + className,
					"Redo delete " + className);
				m_cache.DeleteObject(m_currentObject.Hvo);
				m_cache.EndUndoTask();
				m_cache.MainCacheAccessor.PropChanged(null,
					1, /* kpctNotifyAll */
					m_owningObject.Hvo, m_flid, m_currentIndex--, 0, 1);
				DoNext();
			}
		}

		#region Undo/Redo Menus

		/// <summary>
		/// Perform a redo action.
		/// </summary>
		public override void Redo()
		{
			// Grab it, before it changes.
			int[] oldVec = Vector;
			base.Redo();
			UndoRedoCore(oldVec);
		}

		/// <summary>
		/// Perform an undo action.
		/// </summary>
		public override void Undo()
		{
			// Grab it, before it changes.
			int[] oldVec = Vector;
			base.Undo();
			UndoRedoCore(oldVec);
		}

		protected void UndoRedoCore(int[] oldVec)
		{
			int[] newVec = Vector;
			if (oldVec.Length == newVec.Length)
				m_dataEntryForm.RefreshList(); // Internal change only.
			else if (oldVec.Length < newVec.Length)
			{
				// Resurrection, so jump to it.
				foreach(int oldID in newVec)
				{
					if (Array.IndexOf(oldVec, oldID) == -1)
					{
						JumpToRecord(oldID);
						return;
					}
				}
				Debug.Assert(false); // Shouldn't get here.
			}
			else
			{
				// Deleted.
				if (m_currentIndex < newVec.Length)
				{
					m_currentIndex--;
					DoNext();
				}
				else
					DoLast();
			}
		}

		#endregion

	}
}
