// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ProgressDialog.cs
// Responsibility: AndyBlack
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace SIL.WordWorks.Conch
{
	/// <summary>
	/// Summary description for ProgressDialog.
	/// </summary>
	public class ProgressDialog : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label m_LabelCreationProgress;
		private System.Windows.Forms.Label m_LabelWorkingOnPrompt;
		public System.Windows.Forms.Label m_LabelWorkingOn;
		public System.Windows.Forms.ProgressBar m_ProgressBar;
		private System.Windows.Forms.Button m_CancelBtn;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Initializes a new instance of the ProgressDialog class.
		/// </summary>
		public ProgressDialog()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ProgressDialog));
			this.m_LabelCreationProgress = new System.Windows.Forms.Label();
			this.m_LabelWorkingOnPrompt = new System.Windows.Forms.Label();
			this.m_LabelWorkingOn = new System.Windows.Forms.Label();
			this.m_ProgressBar = new System.Windows.Forms.ProgressBar();
			this.m_CancelBtn = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// m_LabelCreationProgress
			// 
			this.m_LabelCreationProgress.AccessibleDescription = ((string)(resources.GetObject("m_LabelCreationProgress.AccessibleDescription")));
			this.m_LabelCreationProgress.AccessibleName = ((string)(resources.GetObject("m_LabelCreationProgress.AccessibleName")));
			this.m_LabelCreationProgress.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_LabelCreationProgress.Anchor")));
			this.m_LabelCreationProgress.AutoSize = ((bool)(resources.GetObject("m_LabelCreationProgress.AutoSize")));
			this.m_LabelCreationProgress.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_LabelCreationProgress.Dock")));
			this.m_LabelCreationProgress.Enabled = ((bool)(resources.GetObject("m_LabelCreationProgress.Enabled")));
			this.m_LabelCreationProgress.Font = ((System.Drawing.Font)(resources.GetObject("m_LabelCreationProgress.Font")));
			this.m_LabelCreationProgress.Image = ((System.Drawing.Image)(resources.GetObject("m_LabelCreationProgress.Image")));
			this.m_LabelCreationProgress.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_LabelCreationProgress.ImageAlign")));
			this.m_LabelCreationProgress.ImageIndex = ((int)(resources.GetObject("m_LabelCreationProgress.ImageIndex")));
			this.m_LabelCreationProgress.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_LabelCreationProgress.ImeMode")));
			this.m_LabelCreationProgress.Location = ((System.Drawing.Point)(resources.GetObject("m_LabelCreationProgress.Location")));
			this.m_LabelCreationProgress.Name = "m_LabelCreationProgress";
			this.m_LabelCreationProgress.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("m_LabelCreationProgress.RightToLeft")));
			this.m_LabelCreationProgress.Size = ((System.Drawing.Size)(resources.GetObject("m_LabelCreationProgress.Size")));
			this.m_LabelCreationProgress.TabIndex = ((int)(resources.GetObject("m_LabelCreationProgress.TabIndex")));
			this.m_LabelCreationProgress.Text = resources.GetString("m_LabelCreationProgress.Text");
			this.m_LabelCreationProgress.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_LabelCreationProgress.TextAlign")));
			this.m_LabelCreationProgress.Visible = ((bool)(resources.GetObject("m_LabelCreationProgress.Visible")));
			// 
			// m_LabelWorkingOnPrompt
			// 
			this.m_LabelWorkingOnPrompt.AccessibleDescription = ((string)(resources.GetObject("m_LabelWorkingOnPrompt.AccessibleDescription")));
			this.m_LabelWorkingOnPrompt.AccessibleName = ((string)(resources.GetObject("m_LabelWorkingOnPrompt.AccessibleName")));
			this.m_LabelWorkingOnPrompt.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_LabelWorkingOnPrompt.Anchor")));
			this.m_LabelWorkingOnPrompt.AutoSize = ((bool)(resources.GetObject("m_LabelWorkingOnPrompt.AutoSize")));
			this.m_LabelWorkingOnPrompt.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_LabelWorkingOnPrompt.Dock")));
			this.m_LabelWorkingOnPrompt.Enabled = ((bool)(resources.GetObject("m_LabelWorkingOnPrompt.Enabled")));
			this.m_LabelWorkingOnPrompt.Font = ((System.Drawing.Font)(resources.GetObject("m_LabelWorkingOnPrompt.Font")));
			this.m_LabelWorkingOnPrompt.Image = ((System.Drawing.Image)(resources.GetObject("m_LabelWorkingOnPrompt.Image")));
			this.m_LabelWorkingOnPrompt.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_LabelWorkingOnPrompt.ImageAlign")));
			this.m_LabelWorkingOnPrompt.ImageIndex = ((int)(resources.GetObject("m_LabelWorkingOnPrompt.ImageIndex")));
			this.m_LabelWorkingOnPrompt.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_LabelWorkingOnPrompt.ImeMode")));
			this.m_LabelWorkingOnPrompt.Location = ((System.Drawing.Point)(resources.GetObject("m_LabelWorkingOnPrompt.Location")));
			this.m_LabelWorkingOnPrompt.Name = "m_LabelWorkingOnPrompt";
			this.m_LabelWorkingOnPrompt.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("m_LabelWorkingOnPrompt.RightToLeft")));
			this.m_LabelWorkingOnPrompt.Size = ((System.Drawing.Size)(resources.GetObject("m_LabelWorkingOnPrompt.Size")));
			this.m_LabelWorkingOnPrompt.TabIndex = ((int)(resources.GetObject("m_LabelWorkingOnPrompt.TabIndex")));
			this.m_LabelWorkingOnPrompt.Text = resources.GetString("m_LabelWorkingOnPrompt.Text");
			this.m_LabelWorkingOnPrompt.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_LabelWorkingOnPrompt.TextAlign")));
			this.m_LabelWorkingOnPrompt.Visible = ((bool)(resources.GetObject("m_LabelWorkingOnPrompt.Visible")));
			// 
			// m_LabelWorkingOn
			// 
			this.m_LabelWorkingOn.AccessibleDescription = ((string)(resources.GetObject("m_LabelWorkingOn.AccessibleDescription")));
			this.m_LabelWorkingOn.AccessibleName = ((string)(resources.GetObject("m_LabelWorkingOn.AccessibleName")));
			this.m_LabelWorkingOn.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_LabelWorkingOn.Anchor")));
			this.m_LabelWorkingOn.AutoSize = ((bool)(resources.GetObject("m_LabelWorkingOn.AutoSize")));
			this.m_LabelWorkingOn.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_LabelWorkingOn.Dock")));
			this.m_LabelWorkingOn.Enabled = ((bool)(resources.GetObject("m_LabelWorkingOn.Enabled")));
			this.m_LabelWorkingOn.Font = ((System.Drawing.Font)(resources.GetObject("m_LabelWorkingOn.Font")));
			this.m_LabelWorkingOn.Image = ((System.Drawing.Image)(resources.GetObject("m_LabelWorkingOn.Image")));
			this.m_LabelWorkingOn.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_LabelWorkingOn.ImageAlign")));
			this.m_LabelWorkingOn.ImageIndex = ((int)(resources.GetObject("m_LabelWorkingOn.ImageIndex")));
			this.m_LabelWorkingOn.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_LabelWorkingOn.ImeMode")));
			this.m_LabelWorkingOn.Location = ((System.Drawing.Point)(resources.GetObject("m_LabelWorkingOn.Location")));
			this.m_LabelWorkingOn.Name = "m_LabelWorkingOn";
			this.m_LabelWorkingOn.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("m_LabelWorkingOn.RightToLeft")));
			this.m_LabelWorkingOn.Size = ((System.Drawing.Size)(resources.GetObject("m_LabelWorkingOn.Size")));
			this.m_LabelWorkingOn.TabIndex = ((int)(resources.GetObject("m_LabelWorkingOn.TabIndex")));
			this.m_LabelWorkingOn.Text = resources.GetString("m_LabelWorkingOn.Text");
			this.m_LabelWorkingOn.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_LabelWorkingOn.TextAlign")));
			this.m_LabelWorkingOn.Visible = ((bool)(resources.GetObject("m_LabelWorkingOn.Visible")));
			// 
			// m_ProgressBar
			// 
			this.m_ProgressBar.AccessibleDescription = ((string)(resources.GetObject("m_ProgressBar.AccessibleDescription")));
			this.m_ProgressBar.AccessibleName = ((string)(resources.GetObject("m_ProgressBar.AccessibleName")));
			this.m_ProgressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_ProgressBar.Anchor")));
			this.m_ProgressBar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_ProgressBar.BackgroundImage")));
			this.m_ProgressBar.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_ProgressBar.Dock")));
			this.m_ProgressBar.Enabled = ((bool)(resources.GetObject("m_ProgressBar.Enabled")));
			this.m_ProgressBar.Font = ((System.Drawing.Font)(resources.GetObject("m_ProgressBar.Font")));
			this.m_ProgressBar.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_ProgressBar.ImeMode")));
			this.m_ProgressBar.Location = ((System.Drawing.Point)(resources.GetObject("m_ProgressBar.Location")));
			this.m_ProgressBar.Maximum = 18;
			this.m_ProgressBar.Name = "m_ProgressBar";
			this.m_ProgressBar.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("m_ProgressBar.RightToLeft")));
			this.m_ProgressBar.Size = ((System.Drawing.Size)(resources.GetObject("m_ProgressBar.Size")));
			this.m_ProgressBar.Step = 1;
			this.m_ProgressBar.TabIndex = ((int)(resources.GetObject("m_ProgressBar.TabIndex")));
			this.m_ProgressBar.Text = resources.GetString("m_ProgressBar.Text");
			this.m_ProgressBar.Visible = ((bool)(resources.GetObject("m_ProgressBar.Visible")));
			// 
			// m_CancelBtn
			// 
			this.m_CancelBtn.AccessibleDescription = ((string)(resources.GetObject("m_CancelBtn.AccessibleDescription")));
			this.m_CancelBtn.AccessibleName = ((string)(resources.GetObject("m_CancelBtn.AccessibleName")));
			this.m_CancelBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_CancelBtn.Anchor")));
			this.m_CancelBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_CancelBtn.BackgroundImage")));
			this.m_CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.m_CancelBtn.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_CancelBtn.Dock")));
			this.m_CancelBtn.Enabled = ((bool)(resources.GetObject("m_CancelBtn.Enabled")));
			this.m_CancelBtn.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("m_CancelBtn.FlatStyle")));
			this.m_CancelBtn.Font = ((System.Drawing.Font)(resources.GetObject("m_CancelBtn.Font")));
			this.m_CancelBtn.Image = ((System.Drawing.Image)(resources.GetObject("m_CancelBtn.Image")));
			this.m_CancelBtn.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_CancelBtn.ImageAlign")));
			this.m_CancelBtn.ImageIndex = ((int)(resources.GetObject("m_CancelBtn.ImageIndex")));
			this.m_CancelBtn.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_CancelBtn.ImeMode")));
			this.m_CancelBtn.Location = ((System.Drawing.Point)(resources.GetObject("m_CancelBtn.Location")));
			this.m_CancelBtn.Name = "m_CancelBtn";
			this.m_CancelBtn.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("m_CancelBtn.RightToLeft")));
			this.m_CancelBtn.Size = ((System.Drawing.Size)(resources.GetObject("m_CancelBtn.Size")));
			this.m_CancelBtn.TabIndex = ((int)(resources.GetObject("m_CancelBtn.TabIndex")));
			this.m_CancelBtn.Text = resources.GetString("m_CancelBtn.Text");
			this.m_CancelBtn.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_CancelBtn.TextAlign")));
			this.m_CancelBtn.Visible = ((bool)(resources.GetObject("m_CancelBtn.Visible")));
			// 
			// ProgressDialog
			// 
			this.AccessibleDescription = ((string)(resources.GetObject("$this.AccessibleDescription")));
			this.AccessibleName = ((string)(resources.GetObject("$this.AccessibleName")));
			this.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("$this.Anchor")));
			this.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScaleBaseSize")));
			this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
			this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
			this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = ((System.Drawing.Size)(resources.GetObject("$this.ClientSize")));
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.m_CancelBtn,
																		  this.m_ProgressBar,
																		  this.m_LabelWorkingOn,
																		  this.m_LabelWorkingOnPrompt,
																		  this.m_LabelCreationProgress});
			this.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("$this.Dock")));
			this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
			this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
			this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
			this.MaximizeBox = false;
			this.MaximumSize = ((System.Drawing.Size)(resources.GetObject("$this.MaximumSize")));
			this.MinimizeBox = false;
			this.MinimumSize = ((System.Drawing.Size)(resources.GetObject("$this.MinimumSize")));
			this.Name = "ProgressDialog";
			this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
			this.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("$this.StartPosition")));
			this.Text = resources.GetString("$this.Text");
			this.Visible = ((bool)(resources.GetObject("$this.Visible")));
			this.ResumeLayout(false);

		}
		#endregion
	}
}
