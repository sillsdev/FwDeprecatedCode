// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: SqlXmlViewer.cs
// Responsibility: AndyBlack
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Xml;
using System.Xml.Xsl;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Resources;

using Microsoft.Win32;

using SIL.FieldWorks;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Utils;
using MSXML2;

namespace SIL.WordWorks.Conch
{
	/// <summary>
	/// Summary description for SqlXmlViewer.
	/// </summary>
	public class SqlXmlViewer : TPlugin
	{
		/// <summary>
		/// Name of Sketch Dump xdr annotated schema
		/// </summary>
		private const string m_ksSketchXdr = "sqlxdrSketchDump.xdr";
		/// <summary>
		/// Name of M3 Dump Cleaner transform
		/// </summary>
		private const string m_ksCleanerXSLT = "CleanFWDump.xsl";
		/// <summary>
		/// Name of M3 Dump to XLingPap transform
		/// </summary>
		private const string m_ksDumpToXLingPap = "M3SketchSvrXMLM3MorphologySketch.xsl";
		/// <summary>
		/// Name of XLingPap DTD
		/// </summary>
		private const string m_ksXLingPapDTD = "XLingPap.dtd";
		/// <summary>
		/// Name of XLingPap transform
		/// </summary>
		private const string m_ksXLingPapXSLT = "XLingPap1.xsl";
		/// <summary>
		/// Name of XLingPap Cascading Style Sheet
		/// </summary>
		private const string m_ksXLingPapCSS = "MorphSketch.css";
		/// <summary>
		/// Name of htm file to display if in the process of generating
		/// </summary>
		private const string m_ksGeneratingDocument = @"WW\Conch\SqlXmlViewer\GeneratingDocumentPleaseWait.htm";
		/// <summary>
		/// Name of htm file to display the first time
		/// </summary>
		private const string m_ksInitialDocument = @"WW\Conch\SqlXmlViewer\InitialDocument.htm";
		/// <summary>
		/// Element name for retrievals which embed other retrievals in config file
		/// </summary>
		private const string m_ksWrapItems = "wrapItems";
		/// <summary>
		/// Registry key name (from config file)
		/// </summary>
		private string m_sRegKeyName;
		/// <summary>
		/// FDO cache
		/// </summary>
		FdoCache m_Cache;
		/// <summary>
		/// Registry key info
		/// </summary>
		private string m_sRegKey;
		private const string m_ksRegKeyPath = @"Software\SIL\Fieldworks\SqlXmlViewer";
		private const string m_ksHtmlFilePath = "HtmlFilePath";
		/// <summary>
		/// title for dialog box
		/// </summary>
		private string m_sDialogTitle;
		/// <summary>
		/// special nodes in config file
		/// </summary>
		XmlNode m_retrieverNode;
		XmlNode m_transformsNode;
		/// <summary>
		/// counts for progress bar
		/// </summary>
		int m_cPrompts;
		int m_cTransforms;


		// Strings that can be localized:
		private string m_stidCleaningRetrieval;
		private string m_stidCompleted;

		private AxSHDocVw.AxWebBrowser m_browser;

		private string m_sTransformPath;
		private string m_sHtmlFileName = null;
		/// <summary>
		/// SqlXdr retriever
		/// </summary>
		private FwSqlXmlRetriever m_Retriever;

		/// <summary>
		/// Cleaned xml document
		/// </summary>
		private string m_sCleanedFile;
		private System.Windows.Forms.Button m_GenerateBtn;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SqlXmlViewer()
		{
#if CanGetStringResourcesToWork
			// Declare a Resource Manager instance
			ResourceManager locRM = new ResourceManager("SIL.WordWorks.Conch.SqlXmlViewer.SketchGeneratorStrings",typeof(SqlXmlViewer).Assembly);
			// Get the strings
			m_stidCleaningRetrieval = locRM.GetString("Cleaning retrieval");
			m_stidCompleted = locRM.GetString("Completed");
#else
			m_stidCleaningRetrieval = "Cleaning retrieval";
			m_stidCompleted = "Completed";

#endif	
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			//link up to be before navigate the event of the browser so that we know when the user clicked on something
			//note: this old version of before navigate is being used because of a bug in the.net framework.
			//win this bug is fixed, we should look at switching to using BeforeNavigate2

			this.m_GenerateBtn.Click += new EventHandler(OnGenerateButtonClick);

			m_sTransformPath = DirectoryFinder.GetFWInstallSubDirectory(@"WW\transforms");

			//need to get hold of the ActiveX object and then grab this old interface:
			SHDocVw.WebBrowser_V1 axDocumentV1 = m_browser.GetOcx() as SHDocVw.WebBrowser_V1;
		}

		/// <summary>
		/// prepare the plug-in for use
		/// </summary>
		/// <remarks> this is separate from the constructor because of the way we are creating with reflection</remarks>
		/// <param name="cache"></param>
		public override void Initialize(Hashtable widgets, FdoCache cache)
		{
			base.Initialize(widgets, cache);
			m_Cache = cache;
			InitBrowser();
			ReadParameters();
			DetermineNumberOfPrompts();
			DetermineNumberOfTransforms();
			ReadRegistry();
		}

		private void DetermineNumberOfPrompts()
		{
			m_cPrompts = 0;
			CountPrompts(m_retrieverNode);
		}
		private void CountPrompts(XmlNode parentNode)
		{
			foreach (XmlNode rNode in parentNode.ChildNodes)
			{
				if (rNode.NodeType == XmlNodeType.Element)
				{
					string sPrompt = XmlUtils.GetOptionalAttributeValue(rNode, "progressPrompt");
					if (sPrompt != null)
						m_cPrompts++;
					if (rNode.Name == m_ksWrapItems)
					{
						CountPrompts(rNode);
					}
				}
			}
		}
		private void DetermineNumberOfTransforms()
		{
			m_cTransforms = m_transformsNode.ChildNodes.Count;
		}

		private void ReadParameters()
		{
			m_sRegKeyName = XmlUtils.GetManditoryAttributeValue(m_paramNode, "regKeyName");
			m_sDialogTitle = XmlUtils.GetManditoryAttributeValue(m_paramNode, "dialogTitle");
			foreach (XmlNode rNode in m_paramNode.ChildNodes)
			{
				if (rNode.Name == "sqlxmlRetriever")
					m_retrieverNode = rNode;
				else if (rNode.Name == "transforms")
					m_transformsNode = rNode;
			}
		}

		private void ReadRegistry()
		{
			m_sHtmlFileName = null;
			m_sRegKey = BuildRegistryKey();
			RegistryKey regkey = Registry.CurrentUser.OpenSubKey(m_sRegKey);
			if (regkey != null)
			{
				m_sHtmlFileName = (string)regkey.GetValue(m_ksHtmlFilePath);
				regkey.Close();
			}
			if (!File.Exists(m_sHtmlFileName))
			{
				m_sHtmlFileName = Path.Combine(DirectoryFinder.FWInstallDirectory, m_ksInitialDocument);
			}
			ShowSketch();
		}

		private string BuildRegistryKey()
		{
			return Path.Combine(m_ksRegKeyPath, Path.Combine(m_Cache.DatabaseName, m_sRegKeyName));
		}

		void OnGenerateButtonClick(object obj, EventArgs ea)
		{
			ProduceSketch(m_Cache);
			ShowSketch();
			WriteRegistry();
		}

		private void ShowSketch()
		{
			ShowInBrowser(m_sHtmlFileName);
		}

		private void WriteRegistry()
		{
			m_sRegKey = BuildRegistryKey();
			RegistryKey regkey = Registry.CurrentUser.OpenSubKey(m_sRegKey, true);
			if (regkey == null)
				regkey = Registry.CurrentUser.CreateSubKey(m_sRegKey);
			regkey.SetValue(m_ksHtmlFilePath, m_sHtmlFileName);
			regkey.Close();
		}

		private void InitBrowser()
		{
			m_browser.Dock = DockStyle.Fill;
			//ShowInBrowser(DirectoryFinder.GetFWInstallSubDirectory(XmlUtils.GetManditoryAttributeValue(m_paramNode, "URL")));
		}

		private void ShowInBrowser(string sURL)
		{
			System.Object nullObject = 0;
			System.Object nullObjStr = "";
			m_browser.Navigate(sURL, ref nullObject, ref nullObjStr, ref nullObjStr, ref nullObjStr);
			m_browser.Refresh();
		}

		private void ProduceSketch(FdoCache cache)
		{
			ProgressDialog dlg = InitProgressDialog();
			ShowGeneratingPage();
			PerformRetrieval(cache, dlg);
			CleanRetrievedXml(dlg);
			PerformTransformations(dlg);
			UpdateProgress(m_stidCompleted, dlg);
			dlg.Close();
		}

		private ProgressDialog InitProgressDialog()
		{
			ProgressDialog dlg = new ProgressDialog();
			dlg.Owner = this.FindForm();
			dlg.m_ProgressBar.Minimum = 0;
			dlg.m_ProgressBar.Maximum = m_cPrompts + m_cTransforms + 1; // additional one is the clean XSLT
			dlg.Text = m_sDialogTitle;
			dlg.Show();
			return dlg;
		}
		private void ShowGeneratingPage()
		{
			// this doesn't work for some reason...
			m_sHtmlFileName = Path.Combine(DirectoryFinder.FWInstallDirectory, m_ksGeneratingDocument);
			ShowSketch();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(SqlXmlViewer));
			this.m_browser = new AxSHDocVw.AxWebBrowser();
			this.m_GenerateBtn = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)(this.m_browser)).BeginInit();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// m_browser
			// 
			this.m_browser.AccessibleDescription = ((string)(resources.GetObject("m_browser.AccessibleDescription")));
			this.m_browser.AccessibleName = ((string)(resources.GetObject("m_browser.AccessibleName")));
			this.m_browser.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_browser.Anchor")));
			this.m_browser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_browser.BackgroundImage")));
			this.m_browser.ContainingControl = this;
			this.m_browser.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_browser.Dock")));
			this.m_browser.Enabled = ((bool)(resources.GetObject("m_browser.Enabled")));
			this.m_browser.Font = ((System.Drawing.Font)(resources.GetObject("m_browser.Font")));
			this.m_browser.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_browser.ImeMode")));
			this.m_browser.Location = ((System.Drawing.Point)(resources.GetObject("m_browser.Location")));
			this.m_browser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("m_browser.OcxState")));
			this.m_browser.RightToLeft = ((bool)(resources.GetObject("m_browser.RightToLeft")));
			this.m_browser.Size = ((System.Drawing.Size)(resources.GetObject("m_browser.Size")));
			this.m_browser.TabIndex = ((int)(resources.GetObject("m_browser.TabIndex")));
			this.m_browser.Text = resources.GetString("m_browser.Text");
			this.m_browser.Visible = ((bool)(resources.GetObject("m_browser.Visible")));
			// 
			// m_GenerateBtn
			// 
			this.m_GenerateBtn.AccessibleDescription = ((string)(resources.GetObject("m_GenerateBtn.AccessibleDescription")));
			this.m_GenerateBtn.AccessibleName = ((string)(resources.GetObject("m_GenerateBtn.AccessibleName")));
			this.m_GenerateBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("m_GenerateBtn.Anchor")));
			this.m_GenerateBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_GenerateBtn.BackgroundImage")));
			this.m_GenerateBtn.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("m_GenerateBtn.Dock")));
			this.m_GenerateBtn.Enabled = ((bool)(resources.GetObject("m_GenerateBtn.Enabled")));
			this.m_GenerateBtn.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("m_GenerateBtn.FlatStyle")));
			this.m_GenerateBtn.Font = ((System.Drawing.Font)(resources.GetObject("m_GenerateBtn.Font")));
			this.m_GenerateBtn.Image = ((System.Drawing.Image)(resources.GetObject("m_GenerateBtn.Image")));
			this.m_GenerateBtn.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_GenerateBtn.ImageAlign")));
			this.m_GenerateBtn.ImageIndex = ((int)(resources.GetObject("m_GenerateBtn.ImageIndex")));
			this.m_GenerateBtn.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("m_GenerateBtn.ImeMode")));
			this.m_GenerateBtn.Location = ((System.Drawing.Point)(resources.GetObject("m_GenerateBtn.Location")));
			this.m_GenerateBtn.Name = "m_GenerateBtn";
			this.m_GenerateBtn.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("m_GenerateBtn.RightToLeft")));
			this.m_GenerateBtn.Size = ((System.Drawing.Size)(resources.GetObject("m_GenerateBtn.Size")));
			this.m_GenerateBtn.TabIndex = ((int)(resources.GetObject("m_GenerateBtn.TabIndex")));
			this.m_GenerateBtn.Text = resources.GetString("m_GenerateBtn.Text");
			this.m_GenerateBtn.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("m_GenerateBtn.TextAlign")));
			this.m_GenerateBtn.Visible = ((bool)(resources.GetObject("m_GenerateBtn.Visible")));
			// 
			// panel1
			// 
			this.panel1.AccessibleDescription = ((string)(resources.GetObject("panel1.AccessibleDescription")));
			this.panel1.AccessibleName = ((string)(resources.GetObject("panel1.AccessibleName")));
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("panel1.Anchor")));
			this.panel1.AutoScroll = ((bool)(resources.GetObject("panel1.AutoScroll")));
			this.panel1.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("panel1.AutoScrollMargin")));
			this.panel1.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("panel1.AutoScrollMinSize")));
			this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.m_GenerateBtn});
			this.panel1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("panel1.Dock")));
			this.panel1.Enabled = ((bool)(resources.GetObject("panel1.Enabled")));
			this.panel1.Font = ((System.Drawing.Font)(resources.GetObject("panel1.Font")));
			this.panel1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("panel1.ImeMode")));
			this.panel1.Location = ((System.Drawing.Point)(resources.GetObject("panel1.Location")));
			this.panel1.Name = "panel1";
			this.panel1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("panel1.RightToLeft")));
			this.panel1.Size = ((System.Drawing.Size)(resources.GetObject("panel1.Size")));
			this.panel1.TabIndex = ((int)(resources.GetObject("panel1.TabIndex")));
			this.panel1.Text = resources.GetString("panel1.Text");
			this.panel1.Visible = ((bool)(resources.GetObject("panel1.Visible")));
			// 
			// panel2
			// 
			this.panel2.AccessibleDescription = ((string)(resources.GetObject("panel2.AccessibleDescription")));
			this.panel2.AccessibleName = ((string)(resources.GetObject("panel2.AccessibleName")));
			this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("panel2.Anchor")));
			this.panel2.AutoScroll = ((bool)(resources.GetObject("panel2.AutoScroll")));
			this.panel2.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("panel2.AutoScrollMargin")));
			this.panel2.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("panel2.AutoScrollMinSize")));
			this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.m_browser});
			this.panel2.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("panel2.Dock")));
			this.panel2.Enabled = ((bool)(resources.GetObject("panel2.Enabled")));
			this.panel2.Font = ((System.Drawing.Font)(resources.GetObject("panel2.Font")));
			this.panel2.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("panel2.ImeMode")));
			this.panel2.Location = ((System.Drawing.Point)(resources.GetObject("panel2.Location")));
			this.panel2.Name = "panel2";
			this.panel2.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("panel2.RightToLeft")));
			this.panel2.Size = ((System.Drawing.Size)(resources.GetObject("panel2.Size")));
			this.panel2.TabIndex = ((int)(resources.GetObject("panel2.TabIndex")));
			this.panel2.Text = resources.GetString("panel2.Text");
			this.panel2.Visible = ((bool)(resources.GetObject("panel2.Visible")));
			// 
			// SqlXmlViewer
			// 
			this.AccessibleDescription = ((string)(resources.GetObject("$this.AccessibleDescription")));
			this.AccessibleName = ((string)(resources.GetObject("$this.AccessibleName")));
			this.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("$this.Anchor")));
			this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
			this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
			this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel2,
																		  this.panel1});
			this.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("$this.Dock")));
			this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
			this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
			this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
			this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
			this.Name = "SqlXmlViewer";
			this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
			this.Size = ((System.Drawing.Size)(resources.GetObject("$this.Size")));
			this.TabIndex = ((int)(resources.GetObject("$this.TabIndex")));
			this.Visible = ((bool)(resources.GetObject("$this.Visible")));
			((System.ComponentModel.ISupportInitialize)(this.m_browser)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
		public FwSqlXmlRetriever GetRetriever (FdoCache cache)
		{
			return new FwSqlXmlRetriever(cache.ServerName, cache.DatabaseName, FwSqlXmlRetriever.PathToWordworksSchemas()+m_ksSketchXdr);
		}
		public void RetrieveItems(XmlNode parentNode, ProgressDialog dlg)
		{
			foreach (XmlNode rNode in parentNode.ChildNodes)
			{
				if (rNode.NodeType == XmlNodeType.Element)
				{
					string sPrompt = XmlUtils.GetOptionalAttributeValue(rNode, "progressPrompt");
					if (sPrompt != null)
						UpdateProgress(sPrompt, dlg);
					switch (rNode.Name)
					{
						case m_ksWrapItems:
							string sWrapsItemElement = XmlUtils.GetManditoryAttributeValue(rNode, "wrappingElement");
							m_Retriever.BeginElement(sWrapsItemElement);
							RetrieveItems(rNode, dlg);
							m_Retriever.EndElement();
							break;

						case "wrappedItem":
							string sWrappedItemElement = XmlUtils.GetManditoryAttributeValue(rNode, "wrappingElement");
							string sWrappedItemXPath = XmlUtils.GetManditoryAttributeValue(rNode, "xpath");
							m_Retriever.InsertXPathQueryResults(sWrappedItemXPath, sWrappedItemElement);
							break;

						case "item":
							string sItemXPath = XmlUtils.GetManditoryAttributeValue(rNode, "xpath");
							m_Retriever.InsertXPathQueryResults(sItemXPath);
							break;
					}
				}
			}
		}
		public void PerformRetrieval(FdoCache cache, ProgressDialog dlg)
		{
			m_Retriever = GetRetriever(cache);
			string sTopMostElement = XmlUtils.GetManditoryAttributeValue(m_retrieverNode, "beginElement");
			m_Retriever.BeginElement(sTopMostElement);
			RetrieveItems(m_retrieverNode, dlg);
			m_Retriever.EndElement();
		}
		/// <summary>
		/// <remarks>Used by unit testing</remarks>
		/// </summary>
		public void CreateRetriever(FdoCache cache)
		{
			m_Retriever = GetRetriever(cache);
		}
		public void CleanRetrievedXml(ProgressDialog dlg)
		{
			UpdateProgress(m_stidCleaningRetrieval, dlg);
			XmlDocument document= m_Retriever.DOMDocument;
			XslTransform transform= new XslTransform();
			transform.Load(Path.Combine(m_sTransformPath, m_ksCleanerXSLT));
			FwTempFile tempClean = new FwTempFile(".xml");
			// REVIEW Randy: .NET 2003 requires an XmlResolver as a fourth argument.
			// I don't know what that is, but at least a null makes the compiler happy.
			transform.Transform(document, new XsltArgumentList(), tempClean.Writer, null);
			m_sCleanedFile = tempClean.CloseAndGetPath();
		}
		private void PerformTransformations(ProgressDialog dlg)
		{
			string sLastFile = m_sCleanedFile;
			foreach (XmlNode rNode in m_transformsNode.ChildNodes)
			{
				sLastFile = ApplyTransform(sLastFile, rNode, dlg);
			}
			m_sHtmlFileName = sLastFile;
		}
		private string ApplyTransform(string sInputFile, XmlNode node, ProgressDialog dlg)
		{
			string sProgressPrompt = XmlUtils.GetManditoryAttributeValue(node, "progressPrompt");
			UpdateProgress(sProgressPrompt, dlg);
			string sOutputFile = CreateOutputFile(node);
			string sXslt = XmlUtils.GetManditoryAttributeValue(node, "file");

			XSLParameter[] parameterList = CreateParameterList(node);

			TransformFileToFile(Path.Combine(m_sTransformPath, sXslt), parameterList, sInputFile, sOutputFile); 
			return sOutputFile;
		}

		private XSLParameter[] CreateParameterList(XmlNode node)
		{
			XSLParameter[] parameterList = null;
			foreach (XmlNode rNode in node.ChildNodes)
			{
				if (rNode.Name == "xsltParameters")
				{
					int cParams = CountParams(rNode);
					if (cParams > 0)
					{
						parameterList = GetParameters(cParams, rNode);
					}
				}
			}
			return parameterList;
		}

		private XSLParameter[] GetParameters(int cParams, XmlNode rNode)
		{
			XSLParameter[] parameterList = new XSLParameter[cParams];
			int i = 0;
			foreach (XmlNode rParamNode in rNode.ChildNodes)
			{
				if (rParamNode.Name == "param")
				{
					string sName = XmlUtils.GetManditoryAttributeValue(rParamNode, "name");
					string sValue = XmlUtils.GetManditoryAttributeValue(rParamNode, "value");
					if (sValue == "TransformDirectory")
					{
						sValue = m_sTransformPath;
					}
					parameterList[i] = new XSLParameter(sName, sValue);
					i++;
				}
			}
			return parameterList;
		}

		private int CountParams(XmlNode node)
		{
			int cParams = 0;
			foreach (XmlNode rNode in node.ChildNodes)
			{
				if (rNode.Name == "param")
					cParams++;
			}
			return cParams;
		}

		private string CreateOutputFile(XmlNode node)
		{
			string sExtension = XmlUtils.GetManditoryAttributeValue(node, "ext");
			FwTempFile tmpFile = new FwTempFile(sExtension);
			string sOutputFile = tmpFile.CloseAndGetPath();
			return sOutputFile;
		}
		private void UpdateProgress(string sMessage, ProgressDialog dlg)
		{
			dlg.m_LabelWorkingOn.Text = sMessage;
			dlg.m_ProgressBar.PerformStep();
			dlg.Refresh();
		}
		/// <summary>
		/// <remarks>Should be part of some class we can inherit from</remarks>
		/// </summary>
		private void TransformFileToFile (string sTransformName, XSLParameter[] parameterList, string sInputPath, string sOutputName)
		{
			//.Net framework XML transform stuff was something like 10 to 20 times slower.
			//the bug fix for this is expected with version 1 support pack 3.
			//      XslTransform transformer= new XslTransform();
			//      transformer.Load(PathToWordworksTransforms() + transformName);
			//      transformer.Transform(inputPath, m_outputDirectory + "\\"+outputName);
			//      (Need to pass parameter sWordWorksTransformPath as PathToWordworksTransforms()
			//       Not clear how to do that with this MSXML2 approach.  Easy to do with
			//       .Net.   Will wait until service pack 3 comes out.
			MSXML2.XSLTemplate40Class xslt = new MSXML2.XSLTemplate40Class();
			MSXML2.FreeThreadedDOMDocument40Class xslDoc = new
				MSXML2.FreeThreadedDOMDocument40Class();
			MSXML2.DOMDocument40Class xmlDoc = new MSXML2.DOMDocument40Class();
			MSXML2.IXSLProcessor xslProc;
 
			xslDoc.async = false;
			xslDoc.load(Path.Combine(m_sTransformPath, sTransformName));
			xslt.stylesheet = xslDoc;
			xmlDoc.async = false;
			xmlDoc.load(sInputPath);
			xslProc = xslt.createProcessor();
			xslProc.input = xmlDoc;
			AddParameters(parameterList, xslProc);
			xslProc.transform();
			StreamWriter sr = File.CreateText(sOutputName);
			sr.Write(xslProc.output);
			sr.Close();
		}

		private void AddParameters(XSLParameter[] parameterList, MSXML2.IXSLProcessor xslProc)
		{
			if (parameterList != null)
			{
				foreach(XSLParameter rParam in parameterList)
				{
					xslProc.addParameter(rParam.Name, rParam.Value, "");
				}
			}
		}
	}

	/// <summary>
	/// A class that represents a parameter of an XSL stylesheet.
	/// </summary>
	public class XSLParameter
	{
		/// <summary>
		/// Parameter name.
		/// </summary>
		private string m_sName;
    
		/// <summary>
		/// Parameter value.
		/// </summary>
		private string m_sValue;

		public XSLParameter(string sName, string sValue)
		{
			m_sName = sName;
			m_sValue = sValue;
		}
		/// <summary>
		/// Overrides method to return a more suitable string representation
		/// for the parameter.SIL.WordWorks.Conch.XSLParameter
		/// </summary>
		/// <returns>A construct of the Name and Value.
		/// </returns>
		public override string ToString()
		{
			string res;
			if (Name == null)
				res = "???";
			else
				res = Name;
			res += "=";
			if (Value == null)
				res += "???";
			else
				res += Value;
			return res;
		}

		public string Name
		{
			get
			{
				return m_sName;
			}
			set
			{
				m_sName = value;
			}
		}

		public string Value
		{
			get
			{
				return m_sValue;
			}
			set
			{
				m_sValue = value;
			}
		}
	}
}
