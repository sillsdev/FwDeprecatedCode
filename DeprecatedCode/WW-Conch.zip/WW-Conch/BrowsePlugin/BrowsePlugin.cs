using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using SIL.WordWorks.Conch;
using System.Xml;
using SIL.FieldWorks.Common.Framework.TreeForms;
using SIL.FieldWorks.FDO;


namespace SIL.WordWorks.Conch
{
	/// <summary>
	/// BrowsePlugin is a plugin for Oyster, designed to show a BrowseView.
	/// </summary>
	public class BrowsePlugin : TPlugin
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		protected BrowseView m_browseView;
		/// <summary>
		/// This is the database object whose vector we are browsing.
		/// </summary>
		protected CmObject m_owningObject;
		/// <summary>
		/// Field ID of the vector which we are browsing.
		/// </summary>
		protected int m_flid;

		public BrowsePlugin()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}
		/// <summary>
		/// prepare the plug-in for use
		/// </summary>
		/// <remarks> this is separate from the constructor because of the way we are creating with reflection</remarks>
		/// <param name="cache"></param>
		public override void Initialize(Hashtable widgets, FdoCache cache)
		{
			// MenuItem menuTools, MenuItem menuInsert, StatusBar statusBar,
			/*
			if(m_paramNode == null) //we haven't developed that feature yet
			{
				XmlDocument xdoc = new XmlDocument();
				xdoc.LoadXml("<params collectionField='Entries'> </params>");
				m_paramNode = xdoc.SelectSingleNode("params");
			}*/

			base.Initialize(widgets, cache);
			ReadParameters();
			//m_fIsSequence = cache.GetFieldType(m_flid) == (int)FieldType.kcptOwningSequence;
			InitializeBrowseView(cache);
			//ShowRecord();
		}

		protected void InitializeBrowseView(FdoCache cache)
		{
			// Modelled on VectorEditor, simplified.
			m_browseView = new SIL.FieldWorks.Common.Framework.TreeForms.BrowseView(m_paramNode,
				m_owningObject.Hvo, m_flid, cache);
			Control[] ctls = new Control[Controls.Count + 1];
			int idx = 0;
			ctls[0] = m_browseView;
			foreach(Control ctl in Controls)
				ctls[idx++] = ctl;
			this.SuspendLayout();
			Controls.Clear();
			m_browseView.Dock = System.Windows.Forms.DockStyle.Fill;
			Controls.AddRange(ctls);
			ResumeLayout(false);
		}

		void ReadParameters()
		{
			// For now it is hard-coded to display entries. Quite possibly the whole of
			// VectorEditor.ReadParameters could eventually be shared..the whole point is to
			// initialize these two variables, in both cases.
			m_owningObject = m_cache.LanguageProject.LexicalDatabaseOA;
			m_flid = (int)SIL.FieldWorks.FDO.Ling.Generated.BaseLexicalDatabase.LexicalDatabaseTags.kflidEntries;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion
	}
}
