// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: HtmlViewer2.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Xml;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Resources;

using SIL.FieldWorks;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Utils;

namespace SIL.WordWorks.Conch
{

	/// <summary>
	/// Summary description for VectorEditor.
	/// </summary>
	public class HtmlViewer : TPlugin
	{
		private AxSHDocVw.AxWebBrowser m_browser;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="HtmlViewer2"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public HtmlViewer()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			//link up to be before navigate the event of the browser so that we know when the user clicked on something
			//note: this old version of before navigate is being used because of a bug in the.net framework.
			//win this bug is fixed, we should look at switching to using BeforeNavigate2

			//need to get hold of the ActiveX object and then grab this old interface:
			SHDocVw.WebBrowser_V1 axDocumentV1 = m_browser.GetOcx() as SHDocVw.WebBrowser_V1;
			axDocumentV1.BeforeNavigate += new SHDocVw.DWebBrowserEvents_BeforeNavigateEventHandler(this.OnBeforeNavigate); 

		}

		/// <summary>
		/// prepare the plug-in for use
		/// </summary>
		/// <remarks> this is separate from the constructor because of the way we are creating with reflection</remarks>
		/// <param name="cache"></param>
		public override void Initialize(Hashtable widgets, FdoCache cache)
		{
			base.Initialize(widgets, cache);
			System.Object nullObject = 0;
			System.Object nullObjStr = "";
			m_browser.Dock = DockStyle.Fill;
			m_browser.Navigate(DirectoryFinder.GetFWInstallSubDirectory(XmlUtils.GetManditoryAttributeValue(m_paramNode, "URL")),
				ref nullObject, ref nullObjStr, ref nullObjStr, ref nullObjStr);
		}
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged 
		/// resources; <c>false</c> to release only unmanaged resources. 
		/// </param>
		/// -----------------------------------------------------------------------------------
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
					components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(HtmlViewer));
			this.m_browser = new AxSHDocVw.AxWebBrowser();
			((System.ComponentModel.ISupportInitialize)(this.m_browser)).BeginInit();
			this.SuspendLayout();
			// 
			// m_browser
			// 
			this.m_browser.Enabled = true;
			this.m_browser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("m_browser.OcxState")));
			this.m_browser.Size = new System.Drawing.Size(300, 150);
			this.m_browser.TabIndex = 0;
			// 
			// HtmlViewer
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.m_browser});
			this.Name = "HtmlViewer";
			this.Size = new System.Drawing.Size(600, 320);
			((System.ComponentModel.ISupportInitialize)(this.m_browser)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		//note: this old version of before navigate is being used because of a bug in the.net framework.
		//win this bug is fixed, we should look at switching to using BeforeNavigate2
		protected void OnBeforeNavigate(string url, int flags, string targetFrameName, 
			ref object postData, string headers, ref bool wasHandled)  
		{ 
			try
			{
				System.Windows.Forms.MessageBox.Show("Going to URL: " + url);
//				wasHandled=m_hostShell.HandleNavigationEvent(URL); 
			}
			catch (Exception error) 
			{
				System.Windows.Forms.MessageBox.Show("There was an error handling the click. "
					+ error.Message, "Program Error");
			}
		}  
	}
}
