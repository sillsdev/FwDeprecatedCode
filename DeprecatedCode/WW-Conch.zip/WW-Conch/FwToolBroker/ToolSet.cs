// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ToolSet.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
//	There are at least two subclasses, one which comes up with the list of tools by gathering
//	up all of the assemblies found in a particular folder, and another which reads and XML configuration
//	fragment.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Xml;
using System.Xml.Serialization;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Collections.Specialized;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace SIL.WordWorks.Conch
{
	/// <summary>
	/// Summary description for ToolSet.
	/// </summary>
	public abstract class ToolSet
	{
			protected static ArrayList m_tools = new ArrayList();
			protected static ContextMessage s_startingContext;
			protected static ArrayList s_contextHandlers = new ArrayList();

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ToolSet"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public ToolSet()
		{
		}

	
		/// <summary>
		/// Get the FieldWorks tools which an ArrayList of FwToolInfo's have discovered in the specified directory(s).
		/// </summary>
		/// <returns></returns>
		public virtual System.Collections.ArrayList Tools
		{
			get
			{
				return m_tools;
			}
		}

		public TreeNode FindOrAdd(TreeNodeCollection tnc, string s)
		{
			int i;

			for (i = 0; i < tnc.Count; i++)
			{
				if (tnc[i].Text == s)
					return tnc[i];
			}
			TreeNode cn = new TreeNode(s);
			tnc.Add(cn);
			return cn;
		}

		/// <summary>
		/// fill a tree collection based on this set of tools
		/// </summary>
		/// <param name="tnc"></param>
		abstract public void PopulateTree(TreeNodeCollection tnc);

		public delegate void ContextHandler(ContextMessage context);

		public static void AddContextHandler(ContextHandler handler)
		{
			s_contextHandlers.Add(handler);
		}

		public static void BroadcastNewContext(ContextMessage context)
		{
			if (context != null)
			{
				s_startingContext = context;
				foreach (ContextHandler SetContext in s_contextHandlers)
					SetContext(context);
			}
		}


	}
}
