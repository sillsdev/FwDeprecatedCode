// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Plugin.cs
// Responsibility: Michael Paul Johnson
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Xml;

using SIL.FieldWorks;
using SIL.FieldWorks.FDO;

namespace SIL.WordWorks.Conch
{
	/// <summary>
	/// Summary description for TPlugin.
	/// </summary>
	public class TPlugin : System.Windows.Forms.UserControl
	{
		protected XmlNode m_paramNode;
		protected ContextMessage m_currentContext;
		protected FdoCache m_cache;
		protected bool m_echoExpected;	// True iff context echo back is expected.
		protected MenuItem m_menuEdit;
		protected MenuItem m_menuInsert;
		protected MenuItem m_menuTools;
		protected StatusBar m_statusBar;
		protected ArrayList m_toolBars = new ArrayList();

		/// <summary>
		/// prepare the plug-in for use
		/// </summary>
		/// <remarks> this is separate from the construct or because of the way we are creating with reflection</remarks>
		/// <param name="cache"></param>
		public virtual void Initialize(Hashtable widgets, FdoCache cache)
		{
			m_cache = cache;
			m_menuEdit = (MenuItem)widgets["Edit"];
			m_menuInsert = (MenuItem)widgets["Insert"];
			m_menuTools = (MenuItem)widgets["Tools"];
			m_statusBar = (StatusBar)widgets["status"];
		}

		/// <summary>
		/// The XmlNode which holds the parameters needed to configure this plug-in.
		/// </summary>
		public XmlNode ParamNode
		{
			get
			{
				return m_paramNode;
			}
			set
			{
				m_paramNode = value;
			}
		}

		public void Show(Hashtable widgets, FdoCache cache, out ArrayList toolBars)
		{
			if (m_cache == null)
			{
				Initialize(widgets, cache);
				Location = new System.Drawing.Point(0, 0);
				Dock = DockStyle.Fill;
				((Panel)widgets["panel"]).Controls.Add(this);
			}
			AddEditMenuItems();
			AddInsertMenuItems();
			AddToolsMenuItems();
			SetupStatusBar();
			SetupToolBars();
			toolBars = m_toolBars;
			Show();
		}

		new public void Hide()
		{
			base.Hide();
			RemoveEditMenuItems();
			RemoveInsertMenuItems();
			RemoveToolsMenuItems();
			RemoveStatusBarContents();
		}

		protected virtual void AddEditMenuItems()
		{
		}

		protected virtual void AddInsertMenuItems()
		{
		}

		protected virtual void AddToolsMenuItems()
		{
		}

		protected virtual void SetupStatusBar()
		{
		}

		protected virtual void SetupToolBars()
		{
		}

		public ArrayList ToolBars
		{
			get { return m_toolBars; }
		}

		public virtual void ResetCache(FdoCache cache)
		{
		}

		protected virtual void RemoveEditMenuItems()
		{
		}

		protected void RemoveInsertMenuItems()
		{
			if (m_menuInsert != null)
			{
				this.SuspendLayout();
				m_menuInsert.Enabled = false;
				m_menuInsert.MenuItems.Clear();
				this.ResumeLayout(false);
			}
		}

		protected void RemoveToolsMenuItems()
		{
			if (m_menuTools != null)
			{
				this.SuspendLayout();
				m_menuTools.Enabled = false;
				m_menuTools.MenuItems.Clear();
				this.ResumeLayout(false);
			}
		}

		protected void RemoveStatusBarContents()
		{
			if (m_statusBar != null && m_statusBar.Panels.GetEnumerator() != null)
				m_statusBar.Panels.Clear();
		}

		public void HandleContext(ContextMessage context)
		{
			m_currentContext = context;
			if (m_echoExpected)
				m_echoExpected = false;
			return;
		}

/*
		protected void SetNewContext(ContextMessage context)
		{
			m_currentContext = context;
			m_echoExpected = true;
			FwAvailableTooList.BroadcastNewContext(context);
		}
*/

		private void InitializeComponent()
		{
			// 
			// TPlugin
			// 
			this.Name = "TPlugin";
			this.RightToLeftChanged += new System.EventHandler(this.TPlugin_RightToLeftChanged);
			this.Load += new System.EventHandler(this.TPlugin_Load);

		}

		private void TPlugin_RightToLeftChanged(object sender, System.EventArgs e)
		{
		}

		private void TPlugin_Load(object sender, System.EventArgs e)
		{
		}

		#region Undo/Redo Menus
		/// <summary>
		/// returns true if an undue is possible.
		/// </summary>
		public virtual bool CanUndo
		{
			get
			{
				return (m_cache == null) ? false : m_cache.CanUndo;
			}
		}

		/// <summary>
		/// returns true if they redo is possible.
		/// </summary>
		public virtual bool CanRedo
		{
			get
			{
				return (m_cache == null) ? false : m_cache.CanRedo;
			}
		}	
		/// <summary>
		/// returns text to show for undo
		/// </summary>
		public virtual string UndoText
		{
			get
			{
				if (DesignMode || m_cache == null)
					return "";
				string undo =  m_cache.UndoText;
				if (undo == null)
					undo = "Undo";
				return undo;
			}
		}	 

		/// <summary>
		/// returns text to show for redo
		/// </summary>
		public virtual string RedoText
		{
			get
			{
				if (DesignMode || m_cache == null)
					return "";
				string redo =  m_cache.RedoText;
				if (redo == null)
					redo = "Redo";
				return redo;
			}
		}	 

		/// <summary>
		/// perform a redo action
		/// </summary>
		public virtual void Redo()
		{
			m_cache.Redo();
		}

		/// <summary>
		/// perform and undo action
		/// </summary>
		public virtual void Undo()
		{
			m_cache.Undo();
		}

		#endregion
	}
}
