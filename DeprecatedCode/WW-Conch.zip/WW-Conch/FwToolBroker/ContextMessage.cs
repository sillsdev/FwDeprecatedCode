// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ContextMessage.cs
// Responsibility: Michael Paul Johnson
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;

namespace SIL.WordWorks.Conch
{
	/// <summary>
	/// Summary description for ContextMessage.
	/// </summary>
	public class ContextMessage
	{
		protected int m_hvo;
		protected string m_s;
		protected object m_tag;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ContextMessage"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public ContextMessage()
		{
		}

		public ContextMessage(int handle)
		{
			m_hvo = handle;
		}

		public ContextMessage(int handle, string text)
		{
			m_hvo = handle;
			m_s = text;
		}

		public ContextMessage(int handle, string text, object obj)
		{
			m_hvo = handle;
			m_s = text;
			m_tag = obj;
		}

		public string Text
		{
			get { return m_s; }
			//set ( m_s = value; }
		}
	}

	public class ContextManager
	{
		protected static ContextMessage s_mostRecentContext;

		public static ContextMessage CurrentContext
		{
			get
			{
				return s_mostRecentContext;
			}
			set
			{
				s_mostRecentContext = value;
			}
		}
	}
}
