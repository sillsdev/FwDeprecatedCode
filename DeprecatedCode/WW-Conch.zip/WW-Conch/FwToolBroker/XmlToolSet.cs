// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: XmlToolSet.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
//	Used to assemble a set of as described in an XML configuration
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Xml;
using System.Diagnostics;
using System.IO;
using System.Collections;
using System.Windows.Forms;
using System.Reflection;

using SIL.FieldWorks.Common.Utils;

namespace SIL.WordWorks.Conch
{
	/// <summary>
	/// Summary description for XmlToolSet.
	/// </summary>
	public class XmlToolSet : ToolSet
	{	
		System.Xml.XmlDocument m_doc ;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="configFileName">the filename of the XML file which must be in distfiles\ww\conch\</param>
		public XmlToolSet(string configFileName)
		{
			m_doc = new XmlDocument();
			string path = configFileName;
			try
			{
				path = DirectoryFinder.FWInstallDirectory + @"\ww\conch\" + configFileName;
				m_doc.Load(path);
			} 
			catch (Exception error)
			{
				throw new ApplicationException("Had a problem opening or reading " + path, error);
			}
		}

		protected string GetPathToPlugin(string name)
		{
			string pathname = Assembly.GetExecutingAssembly().CodeBase;
			return pathname.Substring(0, pathname.LastIndexOf(@"\") + 1) + name;
		}

		/// <summary>
		/// fill a tree collection based on this set of tools
		/// </summary>
		/// <param name="tnc"></param>
		public override void PopulateTree(TreeNodeCollection treeNodes)
		{
			treeNodes.Clear();
			XmlNodeList groups = m_doc.SelectNodes("//group");
			foreach (XmlNode group in groups)
			{
				string label = XmlUtils.GetManditoryAttributeValue(group, "label");
				TreeNode tnGroup = new TreeNode(label);
				treeNodes.Add(tnGroup);
				XmlNodeList tools = group.SelectNodes("tool");
				foreach (XmlNode tool in tools)
				{
					TreeNode tn = MakeTreeNodeForTool(tool);
					if (tn!= null)
						tnGroup.Nodes.Add(tn);
				}
				//TODO: this is not work, or else someone else is expanding it later
				if (!XmlUtils.GetBooleanAttributeValue(group, "expanded"))
					tnGroup.Collapse();
			}
		}

		protected TreeNode MakeTreeNodeForTool(XmlNode toolNode)
		{
			XmlNode blade = toolNode.SelectSingleNode(@"blade[@view='edit']");
			if(blade == null)
				return null;
		
			Assembly assy = Assembly.LoadFrom(GetPathToPlugin(XmlUtils.GetManditoryAttributeValue(blade, "dll")));
			foreach(Type type in assy.GetTypes())
			{
				if (type.IsSubclassOf(typeof(TPlugin)))
				{
					TreeNode tnTool = new TreeNode(XmlUtils.GetManditoryAttributeValue(toolNode, "label"));
					TPlugin pi = (TPlugin)assy.CreateInstance(type.ToString());
					pi.ParamNode = blade.SelectSingleNode("params"); // May be null.
					tnTool.Tag = pi;
					m_tools.Add(pi);
					return tnTool; // Sure hope there is only one of them in the assembly!
				}
			}

			return null;
		}
	}
}
