// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: OysterAppTests.cs
// Responsibility: Randy Regnier
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections;
using System.IO;

using NUnit.Framework;

using SIL.FieldWorks.Common.Utils;
using SIL.FieldWorks.Oyster;
using SIL.FieldWorks.FDO;

namespace SIL.FieldWorks.Oyster
{
	#region TestOysterApp
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// TestTeApp is derived from TeApp and FwApp, for testing.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	public class TestOysterApp : OysterApp
	{
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="rgArgs">command line args</param>
		/// ------------------------------------------------------------------------------------
		public TestOysterApp(string[] rgArgs) : base(rgArgs)
		{
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Open a main window for testing. The main app is not run.
		/// </summary>
		/// <returns>true if a new window is successfully created; false, otherwise.</returns>
		/// ------------------------------------------------------------------------------------
		public bool OpenMainWindow()
		{
			return NewMainWindow(null);
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Creates a new instance of the main Translation Editor window
		/// </summary>
		/// 
		/// <param name="cache">Instance of the FW Data Objects cache that the new main window
		/// will use for accessing the database.</param>
		/// <param name="fNewCache">Flag indicating whether one-time, application-specific
		/// initialization should be done for this cache.</param>
		/// <param name="wndCopyFrom"> Must be null for creating the original app window.
		/// Otherwise, a reference to the main window whose settings we are copying.</param>
		/// 
		/// <returns>New instance of TeMainWnd if Scripture data has been successfully loaded;
		/// null, otherwise</returns>
		/// -----------------------------------------------------------------------------------
		protected override Form NewMainAppWnd(FdoCache cache, bool fNewCache, Form wndCopyFrom)
		{
			ArrayList rgTemp = (ArrayList)s_htCommandLineArgs["t"];
			string title = (string)rgTemp[0];
			rgTemp = (ArrayList)s_htCommandLineArgs["x"];
			string configFile = (string)rgTemp[0];
			return new TestOysterMainWnd(cache, wndCopyFrom, title, configFile);
		}
	}
	#endregion // TestOysterApp

	#region TestOysterMainWnd
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Derive our own TeMainWnd for testing purposes.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	public class TestOysterMainWnd : OysterMainWnd
	{
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="cache"></param>
		/// <param name="wndCopyFrom"></param>
		/// ------------------------------------------------------------------------------------
		public TestOysterMainWnd(FdoCache cache, Form wndCopyFrom,
			string title, string configFile) : base(cache, wndCopyFrom, title, configFile)
		{
		}

		public int CountTools
		{
			get { return m_tools.Tools.Count; }
		}

		public bool HasCurrentTool
		{
			get { return m_currentPlugin != null; }
		}

		public void SelectFirstTool()
		{
			TreeView tv = TreeViewControl;
			tv.SelectedNode = tv.SelectedNode.FirstNode;
		}
	}
	#endregion // TestOysterMainWnd

	#region OysterApp tests

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Test OysterApp methods.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	// This is going away. [TestFixture]
	public class OysterAppTests
	{
		private string m_sSvrName = Environment.MachineName + @"\SILFW";
		private string m_sDbName = "testlangproj";
		private string m_ProjName = "Kalaba";
		private TestOysterApp m_testOysterApp;
		private TestOysterMainWnd m_firstMainWnd = null;
		private bool m_fMainWindowOpened = false;

		public OysterAppTests()
		{
		}

		private string TestFile
		{
			get { return "TestConfig.xml"; }
		}

		private string SourceFile
		{
			get
			{
				return DirectoryFinder.FWInstallDirectory
					+ @"\..\Src\WW-Conch\Oyster\OysterDll\OysterDllTests\"
					+ TestFile;
			}
		}

		private string DestFile
		{
			get
			{
				return DirectoryFinder.FWInstallDirectory + @"\WW\Conch\" + TestFile;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Instantiate a TestOysterApp object.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[TestFixtureSetUp]
		public void FixtureInit()
		{
			File.Copy(SourceFile, DestFile, true);
			File.SetAttributes(DestFile, FileAttributes.Normal);
			m_testOysterApp = new TestOysterApp(new string[] {
							"-t", "Unit tests",		// Window title
							"-x", TestFile,			// XML configuration file
							"-c", m_sSvrName,		// ComputerName (aka the SQL server)
							"-proj", m_ProjName,	// ProjectName
							"-db", m_sDbName});		// DatabaseName
			
			m_fMainWindowOpened = m_testOysterApp.OpenMainWindow();
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Make sure the TestOysterApp object is destroyed.
		/// Especially since the splash screen it puts up needs to be closed.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[TestFixtureTearDown]
		public void FixtureCleanUp()
		{
			m_testOysterApp.OnFileExit(null, null);
			m_testOysterApp.Dispose();
			m_testOysterApp = null;
			File.Delete(DestFile);
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// </summary>
		/// -----------------------------------------------------------------------------------
		[SetUp]
		public void Init()
		{
			if (m_fMainWindowOpened)
				m_firstMainWnd = (TestOysterMainWnd)m_testOysterApp.MainWindows[0];
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Counts the tree nodes in the far left pane.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void CountTools()
		{
			Assertion.AssertEquals("Wrong tool count", 5, m_firstMainWnd.CountTools);
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Counts the tree nodes in the far left pane.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void SelectFirstTool()
		{
			Assertion.Assert("Shouldn't have one selected now.", !m_firstMainWnd.HasCurrentTool);
			m_firstMainWnd.SelectFirstTool();
			Assertion.Assert("Should have one selected now.", m_firstMainWnd.HasCurrentTool);
		}
	}

	#endregion // OysterApp tests
}
