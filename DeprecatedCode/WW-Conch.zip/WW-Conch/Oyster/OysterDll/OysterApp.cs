// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: OysterApp.cs
// Responsibility: Randy Regnier
// Last reviewed: 
// 
// <remarks>
// Implementation of OysterApp.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Win32;
using System.Collections;

using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Framework;

namespace SIL.FieldWorks.Oyster
{
	/// <summary>
	/// Summary description for OysterApp.
	/// </summary>
	public class OysterApp : FwApp
	{
		#region OysterApp Properties
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Guid for the application (used for uniquely identifying DB items that "belong" to
		///		this app.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public static Guid AppGuid
		{
			get
			{
				return new Guid("DF12AEE2-41E9-4774-81F2-70171F491189");
			}
		}

		#endregion // OysterApp Properties

		#region Main entry point

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Application entry point. If TE isn't already running, an instance of the app is
		/// created.
		/// </summary>
		/// 
		/// <param name="rgArgs">Command-line arguments</param>
		/// 
		/// <returns>0</returns>
		/// -----------------------------------------------------------------------------------
		[STAThread]
		public static int Main(string[] rgArgs)
		{
			Process proc = ExistingProcess;
			if (proc == null)
			{
				using(OysterApp oysterApp = new OysterApp(rgArgs))
				{
					oysterApp.Run();
				}
			}
			else
			{
				// TODO: Try to figure out how to activate this process?
				MessageBox.Show("Oyster is already running. Go catch it!");
			}

			return 0;
		}

		#endregion // Main entry point

		#region Construction and Initializing

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="rgArgs">Command line arguments.</param>
		public OysterApp(string[] rgArgs) : base(rgArgs)
		{
			// TODO: What to do, if there are no Oyster args on the command line?
			// They should be:
			//	-t window title
			//	-x XML config file
			// For now, we will require them.
			Debug.Assert(s_htCommandLineArgs["t"] != null,
				"No '-t' command line switch for window title.");
			Debug.Assert(s_htCommandLineArgs["x"] != null,
				"No '-x' command line switch for XML configuration file.");
		}

		#endregion // Construction and Initializing

		#region ISettings implementation

		// Imherited implementation is just fine for: KeepWindowSizePos.

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// The RegistryKey for this application.
		/// </summary>
		///***********************************************************************************
		override public RegistryKey SettingsKey
		{
			get 
			{
				return base.SettingsKey.CreateSubKey("Oyster");
			}
		}

		/// <summary>
		/// Save the persisted settings now.
		/// </summary>
		new public void SaveSettingsNow()
		{
		}

		#endregion // ISettings implementation

		#region FwApp required methods

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Creates a new instance of the main Oyster window
		/// </summary>
		/// 
		/// <param name="cache">Instance of the FW Data Objects cache that the new main window
		/// will use for accessing the database.</param>
		/// <param name="fNewCache">Flag indicating whether one-time, application-specific
		/// initialization should be done for this cache.</param>
		/// <param name="wndCopyFrom"> Must be null for creating the original app window.
		/// Otherwise, a reference to the main window whose settings we are copying.</param>
		/// 
		/// <returns>New instance of OyserMainWnd if XML configuration was loaded;
		/// null, otherwise</returns>
		/// -----------------------------------------------------------------------------------
		protected override Form NewMainAppWnd(FdoCache cache, bool fNewCache, Form wndCopyFrom)
		{
			if (fNewCache)
			{
				// TODO: Do any needed initialization here.
			}
			ArrayList rgTemp = (ArrayList)s_htCommandLineArgs["t"];
			string title = (string)rgTemp[0];
			rgTemp = (ArrayList)s_htCommandLineArgs["x"];
			string configFile = (string)rgTemp[0];
			return new OysterMainWnd(cache, wndCopyFrom, title, configFile);
		}

		#endregion // FwApp required methods

		#region Other methods

		#endregion // Other methods
	}
}
