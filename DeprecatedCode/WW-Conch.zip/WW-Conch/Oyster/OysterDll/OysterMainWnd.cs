// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: OysterMainWnd.cs
// Responsibility: Randy Regnier
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Diagnostics;

using Fw = SIL.FieldWorks.Common.Controls;
using SIL.FieldWorks.FDO;
using Microsoft.Win32;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.RootSites;
using FwViews;
using SIL.WordWorks.Conch;

namespace SIL.FieldWorks.Oyster
{
	/// <summary>
	/// Summary description for OysterMainWnd.
	/// </summary>
	public class OysterMainWnd : System.Windows.Forms.Form, Fw.ISettings, IFwMainWnd
	{
		#region Data members for OysterMainWnd

		protected FdoCache m_cache;
		protected ArrayList m_pluginToolBars;
		protected ToolSet m_tools;
		protected TPlugin m_currentPlugin;
		/// <summary>
		/// Flag indicating whether or not this instance of OysterMainWnd is a copy of
		/// another OysterMainWnd (i.e. created by choosing the "Window/New Window" menu).
		/// </summary>		
		protected bool m_fWindowIsCopy = false;

		private enum BorderPosition
		{
			kbpAll,
			kbpSingles,  // Start of the 4 buttons that represent a single side.
			kbpTop = kbpSingles,
			kbpBottom,
			kbpLeft,
			kbpRight,
			kbpNone,
			kbpLim,
		};

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.MainMenu m_mainMenu;
		private System.Windows.Forms.MenuItem m_menuFile;
		private System.Windows.Forms.MenuItem m_menuTools;
		private System.Windows.Forms.TreeView m_treeView;
		private System.Windows.Forms.Splitter m_splitter;
		private System.Windows.Forms.StatusBar m_statusBar;
		private System.Windows.Forms.MenuItem m_menuFileOpen;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem m_menuFileExit;
		private System.Windows.Forms.MenuItem m_menuEdit;
		private System.Windows.Forms.MenuItem m_menuUndo;
		private System.Windows.Forms.MenuItem m_menuRedo;
		private System.Windows.Forms.MenuItem m_mnuInsert;
		private System.Windows.Forms.MenuItem m_menuFileSave;
		private System.Windows.Forms.Panel m_pluginPanel;

		#endregion //Data members for OysterMainWnd

		#region OysterMainWnd properties

		protected TreeView TreeViewControl
		{
			get { return m_treeView; }
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Gets a value indicating whether or not the FwMainWnd has been created as a copy of
		/// another FwMainWnd.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public bool WindowIsCopy
		{
			get 
			{
				return m_fWindowIsCopy;
			}
		}
		#endregion // OysterMainWnd properties

		#region OysterMainWnd construction and cleanup

		/// <summary>
		/// Default Constructor. Do not use directly.
		/// </summary>
		public OysterMainWnd()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Construct a new form
		/// </summary>
		/// <param name="cache">FDO cache.</param>
		/// <param name="tools">Source window to copy from.</param>
		public OysterMainWnd(FdoCache cache, Form wndCopyFrom, string title, string configFile)
		{
			InitializeComponent();
			m_cache = cache;
			m_fWindowIsCopy = (wndCopyFrom != null);
			Text = title;
			m_tools = new XmlToolSet(configFile);
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged 
		/// resources; <c>false</c> to release only unmanaged resources. 
		/// </param>
		/// -----------------------------------------------------------------------------------
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#endregion OysterMainWnd construction and cleanup

		#region Windows Form Designer generated code
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(OysterMainWnd));
			this.m_treeView = new System.Windows.Forms.TreeView();
			this.m_splitter = new System.Windows.Forms.Splitter();
			this.m_pluginPanel = new System.Windows.Forms.Panel();
			this.m_mainMenu = new System.Windows.Forms.MainMenu();
			this.m_menuFile = new System.Windows.Forms.MenuItem();
			this.m_menuFileOpen = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.m_menuFileExit = new System.Windows.Forms.MenuItem();
			this.m_menuEdit = new System.Windows.Forms.MenuItem();
			this.m_menuUndo = new System.Windows.Forms.MenuItem();
			this.m_menuRedo = new System.Windows.Forms.MenuItem();
			this.m_mnuInsert = new System.Windows.Forms.MenuItem();
			this.m_menuTools = new System.Windows.Forms.MenuItem();
			this.m_statusBar = new System.Windows.Forms.StatusBar();
			this.m_menuFileSave = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// m_treeView
			// 
			this.m_treeView.Dock = System.Windows.Forms.DockStyle.Left;
			this.m_treeView.HideSelection = false;
			this.m_treeView.ImageIndex = -1;
			this.m_treeView.Name = "m_treeView";
			this.m_treeView.SelectedImageIndex = -1;
			this.m_treeView.Size = new System.Drawing.Size(160, 453);
			this.m_treeView.TabIndex = 0;
			this.m_treeView.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView_BeforeSelect);
			// 
			// m_splitter
			// 
			this.m_splitter.Location = new System.Drawing.Point(160, 0);
			this.m_splitter.Name = "m_splitter";
			this.m_splitter.Size = new System.Drawing.Size(3, 453);
			this.m_splitter.TabIndex = 1;
			this.m_splitter.TabStop = false;
			// 
			// m_pluginPanel
			// 
			this.m_pluginPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.m_pluginPanel.Location = new System.Drawing.Point(163, 0);
			this.m_pluginPanel.Name = "m_pluginPanel";
			this.m_pluginPanel.Size = new System.Drawing.Size(469, 453);
			this.m_pluginPanel.TabIndex = 2;
			// 
			// m_mainMenu
			// 
			this.m_mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.m_menuFile,
																					   this.m_menuEdit,
																					   this.m_mnuInsert,
																					   this.m_menuTools});
			// 
			// m_menuFile
			// 
			this.m_menuFile.Index = 0;
			this.m_menuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.m_menuFileOpen,
																					   this.m_menuFileSave,
																					   this.menuItem1,
																					   this.m_menuFileExit});
			this.m_menuFile.Text = "&File";
			// 
			// m_menuFileOpen
			// 
			this.m_menuFileOpen.Index = 0;
			this.m_menuFileOpen.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
			this.m_menuFileOpen.Text = "&Open Project...";
			this.m_menuFileOpen.Click += new System.EventHandler(this.menuFileOpen_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 2;
			this.menuItem1.Text = "-";
			// 
			// m_menuFileExit
			// 
			this.m_menuFileExit.Index = 3;
			this.m_menuFileExit.Text = "E&xit";
			this.m_menuFileExit.Click += new System.EventHandler(this.menuFileExit_Click);
			// 
			// m_menuEdit
			// 
			this.m_menuEdit.Index = 1;
			this.m_menuEdit.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.m_menuUndo,
																					   this.m_menuRedo});
			this.m_menuEdit.Text = "&Edit";
			this.m_menuEdit.Popup += new System.EventHandler(this.m_menuEdit_Popup);
			// 
			// m_menuUndo
			// 
			this.m_menuUndo.Index = 0;
			this.m_menuUndo.Shortcut = System.Windows.Forms.Shortcut.CtrlZ;
			this.m_menuUndo.Text = "&Undo";
			this.m_menuUndo.Click += new System.EventHandler(this.mnuUndo_Click);
			// 
			// m_menuRedo
			// 
			this.m_menuRedo.Index = 1;
			this.m_menuRedo.Shortcut = System.Windows.Forms.Shortcut.CtrlY;
			this.m_menuRedo.Text = "&Redo";
			this.m_menuRedo.Click += new System.EventHandler(this.mnuRedo_Click);
			// 
			// m_mnuInsert
			// 
			this.m_mnuInsert.Index = 2;
			this.m_mnuInsert.Text = "&Insert";
			// 
			// m_menuTools
			// 
			this.m_menuTools.Enabled = false;
			this.m_menuTools.Index = 3;
			this.m_menuTools.Text = "&Tool";
			// 
			// m_statusBar
			// 
			this.m_statusBar.Location = new System.Drawing.Point(163, 431);
			this.m_statusBar.Name = "m_statusBar";
			this.m_statusBar.ShowPanels = true;
			this.m_statusBar.Size = new System.Drawing.Size(469, 22);
			this.m_statusBar.TabIndex = 3;
			// 
			// m_menuFileSave
			// 
			this.m_menuFileSave.Index = 1;
			this.m_menuFileSave.Text = "&Save";
			this.m_menuFileSave.Click += new System.EventHandler(this.m_menuFileSave_Click);
			// 
			// OysterMainWnd
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(632, 453);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.m_statusBar,
																		  this.m_pluginPanel,
																		  this.m_splitter,
																		  this.m_treeView});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.m_mainMenu;
			this.Name = "OysterMainWnd";
			this.Text = "Oyster";
			this.ResumeLayout(false);

		}
		#endregion

		#region ISettings implementation

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Registry key for settings for this window.
		/// </summary>
		/// <remarks>Part of the ISettings interface.</remarks>
		/// -----------------------------------------------------------------------------------
		virtual public RegistryKey SettingsKey
		{
			get
			{
				return Registry.CurrentUser.CreateSubKey(@"Software\SIL\FieldWorks\Oyster");
			}
		}

		/// <summary>
		/// Save the persisted settings now.
		/// </summary>
		public void SaveSettingsNow()
		{
			RegistryKey key = SettingsKey;

			// Save Database Settings
			key.SetValue("LatestDatabaseName", m_cache.DatabaseName);
			key.SetValue("LatestDatabaseServer", m_cache.ServerName);
			key.SetValue("LatestProjectName", m_cache.LanguageProject.Name.AnalysisDefaultWritingSystem);
		}

		///***********************************************************************************
		/// <summary>
		/// Gets a window creation option.
		/// </summary>
		/// <value>Returns true if this window is to be a copy of another OysterMainWnd, in 
		/// which case we calculate a new window size and position, and ignore the
		/// size and position values persisted in the registry.</value>
		///***********************************************************************************
		[Browsable(false)]
		public bool KeepWindowSizePos
		{
			get 
			{
				return WindowIsCopy;
			}
		}

		#endregion // ISettings implementation

		#region IFwMainWnd implementation

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Gets or sets the data objects cache.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public virtual FdoCache Cache
		{
			get
			{
				return m_cache;
			}
			set
			{
				if (m_cache != null)
				{
					// TODO TomB: Probably all kinds of stuff needs to be done if the connection is
					// being changed.
					Debug.Assert(false);
				}
				m_cache = value;
			}
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Create the client windows and add corresponding stuff to the sidebar, View menu,
		/// etc.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public void InitAndShowClient()
		{
			Debug.Assert(m_cache != null);
			Debug.Assert(m_tools != null);

			// TODO: Set up sidebar in this method.
			// "sideBarFw" data member for the side bar. From FwMainWnd.

			m_treeView.BeginUpdate();
			m_tools.PopulateTree(m_treeView.Nodes);
			m_treeView.ExpandAll();
			m_treeView.EndUpdate();

			m_mnuInsert.Enabled = false;
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Enable or disable this window.
		/// </summary>
		/// 
		/// <param name="fEnable">Enable (true) or disable (false).</param>
		/// -----------------------------------------------------------------------------------
		public void EnableWindow(bool fEnable)
		{
			// TODO: Implement this.
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Returns the NormalStateDesktopBounds property from the persistence object.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public Rectangle NormalStateDesktopBounds
		{
			get
			{
				return new Rectangle(Location, Size);
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Save all data in this window, ending the current transaction.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public void SaveData()
		{
			// REVIEW: If this class someday implements record-based stuff,
			// we may need to updated the DateModified in the records.
			// Ref RecMainWnd::SaveData().
			if (m_cache != null)
			{
				m_cache.Save();
				m_cache.DatabaseAccessor.BeginTrans();
			}
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// User has changed the style sheet. 
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">An <see cref="EventArgs"/> that contains the event data.</param>
		/// ------------------------------------------------------------------------------------
		public void OnStyleSheetChanged(object sender, EventArgs e)
		{
			// TODO: do something intelligent, here.
			//if (StyleSheetChanged != null)
			//	StyleSheetChanged(sender, e);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// This begins the syncroization process for an application so other applications and
		/// their views will reflect changes made to the DB from the current application.
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public virtual void BeginSyncronization(SyncInfo sync)
		{
			// TODO: Implement it. This is copied from TE.
			//Cache.StoreSync(TeApp.AppGuid, sync);
			//FwApp.App.Synchronize(sync, Cache);
		}
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called just before a window syncronizes it's views with DB changes (e.g. when an
		/// undo or redo command is issued).
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public virtual bool PreSynchronize(SyncInfo sync)
		{
			// TODO: Implement it. This is copied from TE.
			return true;
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called when a window syncronizes it's views with DB changes (e.g. when an undo or
		/// redo command is issued).
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public virtual bool Synchronize(SyncInfo sync)
		{
			// TODO: Implement it. This is copied from TE.
			//Updating views in all windows.
			//FwApp.App.RefreshAllViews();
			return true;
		}

		#endregion // IFwMainWnd implementation

		#region Other methods

		protected void ShutdownCurrentTool()
		{
			if (m_pluginToolBars != null)
			{
				foreach(ToolBar tb in m_pluginToolBars)
				{
					tb.Hide();
					Controls.Remove(tb);
				}
				m_pluginToolBars.Clear();
				m_pluginToolBars = null;
			}
			if(m_currentPlugin != null)
			{
				SaveData();
				m_currentPlugin.Hide();
				m_currentPlugin = null;
			}
		}

		#endregion // Other methods

		#region OysterMainWnd event handlers and delegates

		/// <summary>Occurs when the user changed the definition of a style</summary>
		//public event EventHandler StyleSheetChanged;

		private void treeView_BeforeSelect(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			if (e.Node.Tag == null)
			{
				ShutdownCurrentTool();
				return;
			}

			if (m_treeView.SelectedNode != null)
				ShutdownCurrentTool();

			Hashtable widgets = new Hashtable(5);
			widgets.Add("panel", m_pluginPanel);
			widgets.Add("status", m_statusBar);
			widgets.Add("Edit", m_menuEdit);
			widgets.Add("Insert", m_mnuInsert);
			widgets.Add("Tools", m_menuTools);
			m_currentPlugin = (TPlugin)e.Node.Tag;
			m_currentPlugin.Show(widgets, m_cache, out m_pluginToolBars);
			if (m_pluginToolBars != null)
				foreach(ToolBar tb in m_pluginToolBars)
				{
					Controls.Add(tb);
					tb.Show();
				}
		}

		protected void menuFileExit_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			if (m_cache != null)
				SaveSettingsNow();
			base.OnClosing(e);
		}

		private void menuFileOpen_Click(object sender, System.EventArgs e)
		{
			string sWsUser = "en";		// should load from resource rather than assume English.
			// Results parms for the dlg.
			bool fHaveProject;
			int hvoProj;
			string sProject;
			Guid guid;
			bool fHaveSubitem;
			int hvoSubitem;
			string sName;
			string sServer = (m_cache != null) ? m_cache.ServerName : Environment.MachineName + "\\SILFW";
			string sDatabase;

			FwViews.OpenFWProjectDlgClass dlg = new FwViews.OpenFWProjectDlgClass();
			dlg.Show(null, sServer, sWsUser, (uint)this.Handle, true, 0, "MyHelpFile.htm");
			dlg.GetResults(out fHaveProject, out hvoProj, out sProject,
				out sDatabase, out sServer, out guid, out fHaveSubitem, out hvoSubitem, out sName);
			System.Runtime.InteropServices.Marshal.ReleaseComObject(dlg);
			// Only change it, if we have one and it is different from what we already have.
			if (fHaveProject && (sServer != m_cache.ServerName || sDatabase != m_cache.DatabaseName))
			{
				FdoCache newCache = FdoCache.Create(sServer, sDatabase, sProject, null);
				foreach(TPlugin pi in m_tools.Tools)
					pi.ResetCache(newCache);
				if (m_cache != null)
					m_cache.Dispose();
				m_cache = newCache;
			}
		}

		private void mnuUndo_Click(object sender, System.EventArgs e)
		{
			if(m_currentPlugin!= null)
				m_currentPlugin.Undo();
		}

		private void mnuRedo_Click(object sender, System.EventArgs e)
		{
			if(m_currentPlugin!= null)
				m_currentPlugin.Redo();		
		}

		private void m_menuEdit_Popup(object sender, System.EventArgs e)
		{
			if(m_currentPlugin == null)
			{
				m_menuUndo.Text = "Undo";
				m_menuUndo.Enabled = false;
				m_menuRedo.Text = "Redo";
				m_menuRedo.Enabled = false;
			}
			else
			{
				m_menuUndo.Text = m_currentPlugin.UndoText;
				m_menuUndo.Enabled = m_currentPlugin.CanUndo;
				m_menuRedo.Text = m_currentPlugin.RedoText;
				m_menuRedo.Enabled = m_currentPlugin.CanRedo;
			}
		}

		private void m_menuFileSave_Click(object sender, System.EventArgs e)
		{
			SaveData();
		}

		#endregion // OysterMainWnd event handlers and delegates

	}
}
