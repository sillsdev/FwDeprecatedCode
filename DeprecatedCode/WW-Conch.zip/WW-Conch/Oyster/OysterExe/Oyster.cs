// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Oyster.cs
// Responsibility: Randy Regnier
// Last reviewed: 
// 
// <remarks>
// Application entry point for Oyster.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;

namespace SIL.FieldWorks.Oyster
{
	/// <summary>
	/// Summary description for Oyster.
	/// </summary>
	public class Oyster
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Application entry point. If Oyster isn't already running,
		/// an instance of the app is created.
		/// </summary>
		/// <param name="rgArgs">Command-line arguments</param>
		/// <returns>0</returns>
		/// -----------------------------------------------------------------------------------
		[STAThread]
		public static int Main(string[] rgArgs)
		{
			return OysterApp.Main(rgArgs);
		}
	}
}
