// DeViewSpec.h: interface for the DeViewSpec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVIEWSPEC_H__78C577EF_D0E1_4591_9FEB_FDEE32EA3A0C__INCLUDED_)
#define AFX_DEVIEWSPEC_H__78C577EF_D0E1_4591_9FEB_FDEE32EA3A0C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDeViewSpec  : public GenRefObj
{
public:
	virtual void Init();
	virtual void FinishInit(DeDbInfoPtr qdbi);
	int GetPossListForField(int flid);
	virtual void AddBlockSpecs(UserViewSpecPtr& quvs, DeDbInfoPtr& qdbi);
	virtual void GetTags(int *ptagRootItems, int *ptagItemSort);
	virtual void GetRootObjectClass(int *pclsid);
	CDeViewSpec(HVO hvoLP);
	virtual ~CDeViewSpec();

	virtual void SetTreeHeader(CustViewDaPtr qvcd, HVO hvo, int flid, ITsString ** pptss, DeLpInfo *plpi);

protected:
	void RegisterPossList(DeDbInfoPtr qdbi, long kflid, LPCOLESTR  pszListName, LPCOLESTR  pszListOwnerName);
	void MakePossListQuery(SmartBstr &bstrListName, SmartBstr &bstrOwnerName, int iLangProj, StrUni *pstu);
	int GetIntFromQuery(IOleDbEncapPtr qode, StrUni stuQuery);
	virtual void GetPossListIds(DeDbInfoPtr qdbi);
	
	// What poss lists to use for what fields
	IntMap m_imFieldsToPossLists; 
	HVO m_hvoLp;	// language project

};
// these are here temporarily, will be moved to custviewda.h when they are official
typedef enum FldTypeX
{
	kftAtomicRefNPI = 500 // non-possibility item
} FldTypeX; // Hungarian ft.


#endif // !defined(AFX_DEVIEWSPEC_H__78C577EF_D0E1_4591_9FEB_FDEE32EA3A0C__INCLUDED_)
