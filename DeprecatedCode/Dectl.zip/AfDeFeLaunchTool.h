/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2000, SIL International. All rights reserved.

File: AfDeFeLaunchTool.h
Responsibility: John Hatton
Last reviewed: never

Description:

-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef AFDEFE_LaunchTool_INCLUDED
#define AFDEFE_LaunchTool_INCLUDED 1

/*----------------------------------------------------------------------------------------------
	This node is used to provide tree structures in data entry editors.
	Hungarian: delt.
----------------------------------------------------------------------------------------------*/

class AfDeFeLaunchTool : public AfDeFeEdBoxBut
{
public:
	typedef AfDeFeEdBoxBut SuperClass;

	AfDeFeLaunchTool();
	~AfDeFeLaunchTool();

	void InitContents(int gdat);
	//virtual bool SaveEdit();
	//virtual void EndEdit();
	virtual void ProcessChooser();
	virtual void UpdateField();
	virtual bool SaveEdit();
	//virtual bool BeginEdit(HWND hwnd, Rect & rc, int dxpCursor = 0, bool fTopCursor = true,
	//	TptEditable tpte = ktptIsEditable);
	//virtual bool IsOkToClose();

protected:
};


#endif // AFDEFE_LaunchTool_INCLUDED
