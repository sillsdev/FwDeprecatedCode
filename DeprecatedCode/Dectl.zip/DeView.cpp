// DeView.cpp : Implementation of CDeView

#include "main.h"
#include "DeViewSpec.h"
#include "AfDeFeLaunchTool.h"

class AfDeFeLaunchTool;
typedef GenSmartPtr<AfDeFeLaunchTool> AfDeFeLaunchToolPtr;

#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

// this is just a temporary hack... need to get this info from elsewhere in the right writing system

LPCOLESTR GetObjTypeName(int clid)
{
	switch (clid)
	{
	case kclidRnEvent:
		return L"Event";
		break;
	case kclidMoStemAllomorph:
		return L"StemAllomorph";
		break;
	case kclidMoAffixAllomorph:
		return L"AffixAllomorph";
		break;

	//MSIs

	case kclidMoStemMsi:
		return L"StemMSI";
		break;
	case kclidMoDerivationalAffixMsi:
		return L"DerivAffixMSI";
		break;
	case kclidMoInflectionalAffixMsi:
		return L"InflAffixMSI";
		break;


	case kclidPartOfSpeech:
		return L"POS";
		break;
	case kclidLexSense:
		return L"Sense";
		break;

	default:
		return L"?type?";
		break;
	}
}


/////////////////////////////////////////////////////////////////////////////
// CDeView

STDMETHODIMP CDeView::Startup(BSTR bstrDataSourceXML, BSTR bstrViewSpecPath, int iRootObjectID)
{
	Assert(m_bstrDBConnectionXML.Length()==0); // don't call Init() twice!
	//m_bstrDBConnectionXML = bstrDBConnectionXML;

	SmartBstr bstrDSXML = bstrDataSourceXML;
	// for simple web page demo
	if (bstrDSXML == L"") 
		bstrDSXML = L"<DataAccessSetup Server= '' DB= 'testlangproj' LangProj='DEB-Debug'/>";

	ReadDataSourceXML(BSTR(bstrDSXML));

	m_bstrViewSpecPath = bstrViewSpecPath;
	m_hcRoot.hvo = iRootObjectID;
 

	return 	StartupView();
}

/*----------------------------------------------------------------------------------------------
	These next three are the methods I added, and the fourth, 
	CreateChild(), is where I extracted them from.  This might not be 
	the best way to organize it; it was the most convenient.
----------------------------------------------------------------------------------------------*/
void CDeView::InitViewSpec()
{
	if(m_bstrViewSpecPath  == L"RN" || m_bstrViewSpecPath == L"")
	{
		if(m_hcRoot.hvo ==0)	// Init won't have been called if we're in a Form Editor of VB
			m_hcRoot.hvo = 1576;	
		m_qdvs = NewObj CDeViewSpec(m_hvoLp);
		m_qdvs->Init();	// all the initing that can be done w/out db access


	}
	else if(m_bstrViewSpecPath  == L"Lex")
	{
		if(m_hcRoot.hvo ==0)	// Init won't have been called if we're in a Form Editor of VB
			m_hcRoot.hvo = 1175; 	
		m_qdvs= NewObj CDeViewSpecLex(m_hvoLp);
		m_qdvs->Init();	// all the initing that can be done w/out db access
	}
	else
	{
		CDeViewSpecXML* pdvsxml = NewObj CDeViewSpecXML(m_hvoLp);
		pdvsxml->Init(m_bstrViewSpecPath);	// all the initing that can be done w/out db access
		m_qdvs = pdvsxml;
	}

	// todo JohnH: better, check to see that the class of the root were given agrees with what the spec expects
	m_qdvs->GetRootObjectClass(&(m_hcRoot.clsid));

}

void CDeView::SetCustViewDaTags(CustViewDaPtr qcvd)
{
	AssertPtr(m_qdvs);
	AssertPtr(qcvd);
	
	int tagRootItems,  tagItemSort;
	m_qdvs->GetTags(&tagRootItems, &tagItemSort);
	qcvd->SetTags(tagRootItems);

}



/*----------------------------------------------------------------------------------------------
	Create (and return in pascNew) a child window to show the content of this split window.
	If psplcCopy is null this is the first and primary pane; if not, psplcCopy points at the
	first child (previously created by this same method) and the second child (under the
	splitter bar) is to be created.
----------------------------------------------------------------------------------------------*/
void CDeView::CreateChild(class AfSplitChild * psplcCopy, class AfSplitChild ** psplcNew)
{
	AssertPtr(psplcNew);
	AssertPtrN(psplcCopy);


	// Now create a window.
	WndCreateStruct wcs;
	wcs.InitChild("AfDeSplitChild", m_hwnd, 0);
	wcs.style |=  WS_VISIBLE;

	DeViewDeWndPtr qadw;
	qadw.Create();

	*psplcNew = qadw;
	qadw->CreateHwnd(wcs);

	// If the window is being split, Add information to the new child.
	if (psplcCopy)
	{
		AssertPtr(m_qdbi);
		m_qdbi->AssertValid();
		
		// Make sure the child is resized once it is created before setting the root object.
		// ENHANCE JohnT: do we need to do this? Why isn't this done by the base class after
		// inserting a child window, to lay it out at the right position?
		Rect rc;
		GetClientRect(&rc);
		OnSize(kwstRestored, rc.Width(), rc.Height());

		// We are making a second child window where one exists already.
		// Make everything the same as the one we are copying.
		AfDeSplitChild * padwCopy = dynamic_cast<AfDeSplitChild *>(psplcCopy);
		qadw->SetTreeWidth(padwCopy->GetTreeWidth());

		// We don't need to do anything about loading the data, because this is a second pane
		// showing the same thing.
	}

	qadw.Detach(); // assign ref count to *psplcNew
	//	StartupView();
}


/*----------------------------------------------------------------------------------------------
	Add to the specifid AfDeSplitChild (or subclass) the appropriate fields for the specified object
	which is affirmed to be of the specified class.
	ENHANCE JohnT: could this move to AfDeSplitChild? Depends on COM interface strategy...

	Note: this is an override of a (trivial) method which AfDeSplitChild calls when it needs to
	expand a tree node. It must continue to have the same arguments as the overridden method
	to make tree expansion work.
----------------------------------------------------------------------------------------------*/
int DeViewDeWnd::AddFields(HVO hvoRoot, ClsLevel & clev, CustViewDa *pcvd, int idfe, int nInd)
{
	RecordSpecPtr qrsp;
	CDeView * pcdv = dynamic_cast<CDeView *>(m_qsplf.Ptr());
	AssertPtr(pcdv);
	UserViewSpec * puvs = pcdv->m_quvs;
	puvs->m_hmclevrsp.Retrieve(clev, qrsp);

	//	AssertPtr(qrsp); failure here means we have a kind of object which we haven't provided a blockspec for (JohnH)
	if(!qrsp) // allows us to "ignore" the assert and continue
		return idfe;

	// Loop over the block specs
	int cbsp = qrsp->m_vqbsp.Size();
	for (int ibsp = 0; ibsp < cbsp; ++ibsp)
	{
		AddField(hvoRoot, clev.m_clsid, clev.m_nLevel, qrsp->m_vqbsp[ibsp], pcvd, idfe);
	}
	return idfe;
}

/*----------------------------------------------------------------------------------------------
	Add to the specifid AfDeSplitChild (or subclass) the specified field for the specified object
	which is affirmed to be of the specified class.
	The BlockSpec indicates which field and possibly some variations on how it is displayed.
	ENHANCE JohnT: merge in field types supported by Choices list editor and others.
	Make this a (virtual) method of AfDeSplitChild?
	ENHANCE JohnT: when we make DE a COM interface, how to we divide labor so that common
	field types can be supported by the component, specialized ones can be done by the
	client?
----------------------------------------------------------------------------------------------*/
void DeViewDeWnd::AddField(HVO hvoRoot, int clid, int lev, FldSpec * pfsp, CustViewDa * pcvd,
	int & idfe, int nInd, bool fAlwaysVisible)
{
	// If the user never wants to see this field, skip it.
	if (pfsp->m_eVisibility == kFTVisNever)
		return;
	// The primary analysis writing system, used as a default for various things.
	int encAnalysis = m_qlpi->AnalWs();
	switch(pfsp->m_ft)
	{
	default:
			switch((FldTypeX) pfsp->m_ft)
			{
				default:
					Assert(false);
					break;
			
				case (FldType)kftAtomicRefNPI:
				{
					//int gdat;
					//CheckHr(m_qcvd->get_IntProp(hvoRoot, pfsp->m_flid, &gdat));
					//if (pfsp->m_eVisibility == kFTVisIfData && !gdat) // otherwise kFTVisAlways, no need to check
					//	return;

					AfDeFeLaunchToolPtr qdelt = NewObj AfDeFeLaunchTool;
					qdelt->Initialize(hvoRoot, pfsp->m_flid, lev, pfsp->m_qtssLabel,
						pfsp->m_qtssHelp,
						this, pfsp);
		//			qdelt->InitContents(gdat);
					this->AddFieldDirect(idfe++, qdelt);

					break;
				}
			}
			break;
		// ENHANCE JohnT: when we make this into an AfDeSplitChild method, we may want this to
		// just return a failure code, indicating we don't have a standard way to handle
		// this field type.
		// FALL THROUGH
	case kftGroup: // Should not get groups in DE spec.
		Assert(false);
		break;

	case kftRefAtomic:
		{
			HVO hvoRef;
			CheckHr(pcvd->get_ObjectProp(hvoRoot, pfsp->m_flid, &hvoRef));
			if (pfsp->m_eVisibility == kFTVisIfData) // otherwise kFTVisAlways, no need to check
			{
				if (!hvoRef)
					return;
			}
			AfDeFeCliRefPtr qdecr;
			qdecr.Attach(NewObj AfDeFeCliRef);
			ITsStringPtr qtss;
			CheckHr(pcvd->get_MultiStringAlt(hvoRef, kflidCmPossibility_Name, encAnalysis, &qtss));
			//qdecr->Initialize(hvoRoot, pfsp->m_flid, lev, staLabel.Chars(),
			//	strHelp.Chars(), this, pfsp);
			qdecr->Initialize(hvoRoot, pfsp->m_flid, lev, pfsp->m_qtssLabel,
				pfsp->m_qtssHelp, this, pfsp);
			qdecr->SetContents(qtss);
			qdecr->SetItem(hvoRef);
			int pssl = 0;
			// ENHANCE RandB (JohnT): I have add a variable to FldSpec to store the Choices List for
			// ref attrs;
			// Change this code to use that field instead of the switch here; and initialize
			// the field specs appropriately.
/*			switch (pfsp->m_flid)
			{
			// Todo JohnH: for now, when you use this field type you need to fill something
			// in in this switch. Here are a couple of examples. However, note that
			// we currently don't have a plpi (an LpInfo object) available in the control.
				
			//case kflidRnEvent_TimeOfEvent:
			//	pssl = m_qlpi->GetPsslIds()[DeLpInfo::kpidPsslTim]; // Time of event list.
			//	break;
			case kflidRnEvent_Type:
				pssl = m_qlpi->GetPsslIds()[DeLpInfo::kpidPsslTyp]; // Event Type list.
				break;
				
			default:
				Assert(false); // A list must be provided above.
				break;
			}
*/
			CDeView * pcdv = dynamic_cast<CDeView *>(m_qsplf.Ptr());
			AssertPtr(pcdv);
			pssl = pcdv->m_qdvs->GetPossListForField(pfsp->m_flid); //johnH
			
			qdecr->SetList(pssl);
			qdecr->InitContents(pfsp->m_fHier, pfsp->m_pnt);
			this->AddFieldDirect(idfe++, qdecr);
		}
		break;
#if 0 // needs work to determine where to get a possibility list object
	case kftRefCombo:
		{
			HVO hvoRef;
			CheckHr(pcvd->get_ObjectProp(hvoRoot, pfsp->m_flid, &hvoRef));
			if (pfsp->m_eVisibility == kFTVisIfData) // otherwise kFTVisAlways, no need to check
			{
				if (!hvoRef)
					return;
			}
			AfDeFeComboBoxPtr qdecb;
			qdecb.Attach(NewObj AfDeFeComboBox());
			ITsStringPtr qtss;
			CheckHr(pcvd->get_MultiStringAlt(hvoRef, kflidCmPossibility_Name, encAnalysis, &qtss));
			qdecb->Initialize(hvoRoot, pfsp->m_flid, lev, staLabel.Chars(),
				strHelp.Chars(), this, pfsp);
			qdecb->Init(pfsp->m_pnt);
			int pssl;
			switch (pfsp->m_flid)
			{
			// Todo JohnH: for now, when you use this field type you need to fill something
			// in in this switch. Here are a couple of examples. However, note that
			// we currently don't have a plpi (an LpInfo object) available in the control.
				/*
			case kflidRnGenericRecord_Confidence:
				pssl = plpi->GetPsslIds()[DeLpInfo::kpidPsslCon]; // Confidence list.
				break;
			case kflidRnAnalysis_Status:
				pssl = plpi->GetPsslIds()[DeLpInfo::kpidPsslAna]; // Analysis status list.
				break;
				*/
			default:
				Assert(false); // A list must be provided above.
				break;
			}
			
			PossListInfoPtr qpli;
			plpi->LoadPossList(pssl, ws, &qpli);
			if (qpli)
			{
				qdecb->SetPssl(pfsp->m_hvoPssl);
				if (hvoRef)
				{
					// If not null, select the appropriate item.
					int itss = qpli->GetIndexFromId(hvoRef);
					qdecb->SetIndex(itss);
				}
			}
			this->AddFieldDirect(idfe++, qdecb);
		}
		break;
#endif

#if 0 // JohnT: finish converting this to current approach.
	// Typical changes needed:
		// - Use AddFieldDirect to add items
		// Declare a smart pointer to hold the new field editor.
	case kftEnum:
		{

			// Review PM (JohnT): is there any way for an enum field to be VisIfData?
			pdecb = NewObj AfDeFeComboBox();
			ITsStrFactoryPtr qtsf;
			qtsf.CreateInstance(CLSID_TsStrFactory);
			int itss;
			CheckHr(pcvd->get_IntProp(hvoRoot, pfsp->m_flid, &itss));
			pdecb->Initialize(hvoRoot, pfsp->m_flid, lev, staLabel.Chars(),
				strHelp.Chars(), this, pfsp);
			pdecb->Init(pfsp->m_pnt);
			ComVector<ITsString> * pvtss;
			pvtss = pdecb->GetVec();
			switch (pfsp->m_flid)
			{
			/*
			case kflidRnEvent_Type:
				qtsf->MakeStringRgch(L"Observation", 11, ws, &qtss);
				pvtss->Push(qtss);
				qtsf->MakeStringRgch(L"Almanac", 7, ws, &qtss);
				pvtss->Push(qtss);
				qtsf->MakeStringRgch(L"Conversation", 12, ws, &qtss);
				pvtss->Push(qtss);
				qtsf->MakeStringRgch(L"Performance", 11, ws, &qtss);
				pvtss->Push(qtss);
				qtsf->MakeStringRgch(L"Literature Summary", 18, ws, &qtss);
				pvtss->Push(qtss);
				break;
			*/
			default:
				Assert(false); // A list must be provided above.
				break;
			}
			pdecb->SetIndex(itss);
			m_vdfe.Insert(idfe++, pdecb);
		}
		break;
#endif
	case kftString:
		{
			ITsStringPtr qtss;
			CheckHr(pcvd->get_StringProp(hvoRoot, pfsp->m_flid, &qtss));
			int cch;
			CheckHr(qtss->get_Length(&cch));

			if (pfsp->m_eVisibility == kFTVisIfData) // otherwise kFTVisAlways, no need to check
			{
				if (!cch)
					return;
			}
			// If the string is empty and has no writing system, change to analyis writing system.
			// ENHANCE JohnT: eventually, we need (a) a field type that indicates vernacular or
			// analysis, or (b) to use a template, or both.
			int ws, nVar;
			ITsTextPropsPtr qttp;
			CheckHr(qtss->get_Properties(0, &qttp));
			CheckHr(qttp->GetIntPropValues(ktptWs, &nVar, &ws));
			if (ws == 0)
			{
				ITsStrFactoryPtr qtsf;
				qtsf.CreateInstance(CLSID_TsStrFactory);
				CheckHr(qtsf->MakeStringRgch(L"", 0, encAnalysis, &qtss));
				pcvd->CacheStringProp(hvoRoot, pfsp->m_flid, qtss);
			}
			AfDeFeStringPtr qdes;
			qdes.Attach(NewObj AfDeFeString);
			qdes->Initialize(hvoRoot, pfsp->m_flid, lev, pfsp->m_qtssLabel,
				pfsp->m_qtssHelp, this, pfsp);
			qdes->Initialize(hvoRoot, pfsp->m_flid, lev, pfsp->m_qtssLabel,
				pfsp->m_qtssHelp, this, pfsp);
			qdes->Init();
			this->AddFieldDirect(idfe++, qdes);
		}
		break;

	case kftRefSeq:
		{
			if (pfsp->m_eVisibility == kFTVisIfData) // otherwise kFTVisAlways, no need to check
			{
				int chvo;
				CheckHr(pcvd->get_VecSize(hvoRoot, pfsp->m_flid, &chvo));
				if (!chvo)
					return;
			}
			Vector<HVO> vpssl;
			bool fMultiList = false;
			Assert(pfsp->m_hvoPssl);
			vpssl.Push(pfsp->m_hvoPssl);
			GenSmartPtr<AfDeFeTags> qdft;
			qdft.Attach(NewObj AfDeFeTags);
			qdft->Initialize(hvoRoot, pfsp->m_flid, lev, pfsp->m_qtssLabel,
				pfsp->m_qtssHelp, this, pfsp);
			qdft->Init(vpssl, fMultiList, pfsp->m_fHier, pfsp->m_pnt);
			this->AddFieldDirect(idfe++, qdft);
		}
		break;

	case kftMsa:
	case kftMta:
		{
			Vector<int> vwsT;
			Vector<int> & vws = vwsT;
			switch (pfsp->m_ws)
			{
			case kwsAnals:
				vws = m_qlpi->AnalWss();
				break;
			case kwsVerns:
				vws = m_qlpi->VernWss();
				break;
			case kwsAnal:
				vwsT.Push(m_qlpi->AnalWs());
				break;
			case kwsVern:
				vwsT.Push(m_qlpi->VernWs());
				break;
			case kwsAnalVerns:
				vws = m_qlpi->AnalVernWss();
				break;
			case kwsVernAnals:
				vws = m_qlpi->VernAnalWss();
				break;
			default:
				vwsT.Push(pfsp->m_ws);
				break;
			}

			// An extra ref count is created here which is eventually assigned to the vector.
			AfDeFeStringPtr qdfs = NewObj AfDeFeString;
			qdfs->Initialize(hvoRoot, pfsp->m_flid, lev, pfsp->m_qtssLabel,
				pfsp->m_qtssHelp,
				this, pfsp);

			if (pfsp->m_ft == kftMta)
				qdfs->Init(&vws, ktptSemiEditable);
			else
				qdfs->Init(&vws, ktptIsEditable);
			this->AddFieldDirect(idfe++, qdfs);
		}
		break; 

	case kftStText:
		{
			if (pfsp->m_eVisibility == kFTVisIfData) // otherwise kFTVisAlways, no need to check
			{
				HVO hvoText;
				CheckHr(pcvd->get_ObjectProp(hvoRoot, pfsp->m_flid, &hvoText));
				if (!hvoText)
					return; // no text at all
				int chvo;
				CheckHr(pcvd->get_VecSize(hvoText, kflidStText_Paragraphs, &chvo));
				if (!chvo)
					return; // text has no paragraphs
				if (chvo == 1)
				{
					// If only one paragraph, still count as empty if no text.
					HVO hvoPara;
					CheckHr(pcvd->get_VecItem(hvoText, kflidStText_Paragraphs, 0, &hvoPara));
					ITsStringPtr qtss;
					CheckHr(pcvd->get_StringProp(hvoPara, kflidStTxtPara_Contents, &qtss));
					// ENHANCE JohnT (v2) when we have tables, may need a further check here.
					int cch;
					CheckHr(qtss->get_Length(&cch));
					if (!cch)
						return;
				}
			}
			// Structured text. Use specialized field editor.
			GenSmartPtr<AfDeFeSt> qadfs;
			qadfs.Attach(NewObj AfDeFeSt);
			HVO hvoText;
			pcvd->get_ObjectProp(hvoRoot, pfsp->m_flid, &hvoText);
			qadfs->Initialize(hvoRoot, pfsp->m_flid, lev, pfsp->m_qtssLabel,
				pfsp->m_qtssHelp,
				this, pfsp);
			qadfs->Init(pcvd, hvoText);
			this->AddFieldDirect(idfe++, qadfs);
		}
		break;
#if 0 // fix these later
	case kftDateRO:
		{
			// Read-only date/time
			// Review PM (JohnT): can a date have no data?
			if (pfsp->m_eVisibility == kFTVisIfData) // otherwise kFTVisAlways, no need to check
			{
				int64 nTime;
				CheckHr(pcvd->get_TimeProp(hvoRoot, pfsp->m_flid, &nTime));
				if (!nTime)
					return;
			}
			AfDeFeTimePtr qdeti = NewObj AfDeFeTime;
			qdeti->Initialize(hvoRoot, pfsp->m_flid, lev, staLabel.Chars(),
				strHelp.Chars(), this, pfsp);
			qdeti->Init();
			m_vdfe.Insert(idfe++, qdeti);
			break;
		}

#endif // disabled code

	case kftGenDate:
		{
			int gdat;
			CheckHr(pcvd->get_IntProp(hvoRoot, pfsp->m_flid, &gdat));
			if (pfsp->m_eVisibility == kFTVisIfData && !gdat) // otherwise kFTVisAlways, no need to check
				return;

			AfDeFeGenDatePtr qdegd = NewObj AfDeFeGenDate;
			qdegd->Initialize(hvoRoot, pfsp->m_flid, lev, pfsp->m_qtssLabel,
				pfsp->m_qtssHelp,
				this, pfsp);
			qdegd->InitContents(gdat);
			this->AddFieldDirect(idfe++, qdegd);
			break;
		}
	/* Not currently used in Notebook, but left here as a sample.
	case kftUnicode:
		{
				SmartBstr sbstr;
				CheckHr(pcvd->get_UnicodeProp(hvoRoot, qbsp->m_flid, &sbstr));
				if (qbsp->m_eVisibility == kFTVisIfData && !sbstr.Length())
					continue;
				AfDeFeUniPtr qdeu = NewObj AfDeFeUni;
				qdeu->Initialize(hvoRoot, qbsp->m_flid, nInd, qbsp->m_qtssLabel, qbsp->m_qtssHelp,
					this, qbsp);
				qdeu->Init();
				m_vdfe.Insert(idfe++, qdeu);
				break;
		} */
	case kftSubItems:
		{
			// Add a line for each subrecord.
			// This is automatically invisible if there are none.
			int chvoSub;
			StrAppBuf strb;
			CheckHr(pcvd->get_VecSize(hvoRoot, pfsp->m_flid, &chvoSub));
			for (int ihvoSub = 0; ihvoSub < chvoSub; ++ihvoSub)
			{
				long hvoSub;
				int clsid;
				CheckHr(pcvd->get_VecItem(hvoRoot, pfsp->m_flid, ihvoSub, &hvoSub));
				CheckHr(pcvd->get_IntProp(hvoSub, kflidCmObject_Class, &clsid));
				// This will need to be smarter if we have more than one kind of subentry
				// Todo JohnH: needs to change for differnt kinds of embedded objects
				// (Should come from resource.)
				strb = GetObjTypeName(clsid);
				
				AfDeFeTreeNodePtr qdetn;
				qdetn.Attach(NewObj AfDeFeTreeNode);
				qdetn->Initialize(hvoRoot, pfsp->m_flid, lev,pfsp->m_qtssLabel,
					pfsp->m_qtssHelp, this, pfsp);
				qdetn->Init();
				qdetn->SetClsid(clsid);
				qdetn->SetTreeObj(hvoSub);
				qdetn->SetExpansion(pfsp->m_fExpand ? kdtsExpanded : kdtsCollapsed);
				SetTreeHeader(qdetn);
				this->AddFieldDirect(idfe++, qdetn);
				// Automatically expand the subrecord if the option is set.
				if (pfsp->m_fExpand)
				{
					// Review JohnH (JohnT): I changed this back to 1 (you had lev + 1).
					// Unless you improve CustViewDa as well as actually making record specs
					// for every possible leve, I don't think using numbers >1 will work.
					ClsLevel clev(clsid, 1);
					idfe = AddFields(hvoSub, clev, pcvd, idfe, lev + 1);
				}
			}
			break;
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Set the title of the tree node. This is just an example, for an RnGenericRecord or
	subclass.
----------------------------------------------------------------------------------------------*/
void DeViewDeWnd::SetTreeHeader(AfDeFeTreeNode * pdetn)
{
	AssertPtr(pdetn);

	ITsStringPtr qtss;
	StrUni stu;
	HVO hvo = pdetn->GetTreeObj();
	Assert(hvo); // This needs to be set prior to calling this.
	CustViewDaPtr qcvd;
	m_qlpi->GetDataAccess(&qcvd);

	AssertPtr(m_qdvs);
	m_qdvs->SetTreeHeader(qcvd, hvo, pdetn->GetFlid(), &qtss, m_qlpi);

	AssertPtr(qtss);

	if (pdetn->GetOutlineSty() != konsNone)
	{
		bool fFinalDot = pdetn->GetOutlineSty() == konsNumDot;
		HRESULT hr;
		SmartBstr sbstr;
		hr = qcvd->GetOutlineNumber(hvo, pdetn->GetFlid(), fFinalDot, &sbstr);
		stu = sbstr.Chars();
		if (!FAILED(hr))
		{
			// Insert the number in front of the title.
			stu.Append(L"  ");
			ITsStrBldrPtr qtsb;
			qtss->GetBldr(&qtsb);
			Assert(qtsb);
			qtsb->ReplaceRgch(0, 0, stu.Chars(), stu.Length(), NULL);
			qtsb->GetString(&qtss);
		}
	}
	pdetn->SetContents(qtss);

}



/***********************************************************************************************
	DeLpInfo methods.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Open a language project and load the necessary information from it.
	Most of this is #ifdef'd out, and more could be for now: this simple demo only uses
	the first analysis writing system. More needs to be reinstated if we start working with
	possibility lists.
----------------------------------------------------------------------------------------------*/
bool DeLpInfo::OpenProject()
{
	if (!LoadWritingSystems())
		return false;

	// Load the project ids and names.
	if (!LoadProjBasics())
		return false;

#if 0 // Reinstate if you want to use the language project's default style sheet
	// Load the stylesheet for this language project.
	m_qasts.Attach(NewObj AfStylesheet);
	m_qasts->Init(this, m_hvoLp);
#endif

	return true;
}


/*----------------------------------------------------------------------------------------------
	Load basic information for the project (ids, names).
	@return true if successful
----------------------------------------------------------------------------------------------*/
bool DeLpInfo::LoadProjBasics()
{
	IOleDbEncapPtr qode;
	IOleDbCommandPtr qodc;
	StrUni stu;
	ComBool fIsNull;
	ComBool fMoreRows;
	m_vhvoPsslIds.Clear(); // Clear any old values.
	m_vhvoPsslIds.Resize(kpidPsslLim);

	//  Obtain pointer to IOleDbEncap interface and execute the given SQL select command.
	AssertPtr(m_qdbi);
	m_qdbi->GetDbAccess(&qode);

#if 0 // something like this may be needed if we want to use possibility lists.
	// We need to get the UID of the list from somewhere.
	try
	{
	/* Sample query:
		select rnb.dst rnb, con.dst con, res.dst res, wea.dst wea, rol.dst rol, peo.dst peo,
		loc.dst loc, ana.dst ana, typ.dst typ, tim.dst tim, edu.dst edu, pos.dst pos, cpn.Txt
		from LanguageProject lp
		left outer join LanguageProject_ResearchNotebook rnb on rnb.src = lp.id
		left outer join LanguageProject_ConfidenceLevels con on con.src = lp.id
		left outer join LanguageProject_Restrictions res on res.src = lp.id
		left outer join LanguageProject_WeatherConditions wea on wea.src = lp.id
		left outer join LanguageProject_Roles rol on rol.src = lp.id
		left outer join LanguageProject_People peo on peo.src = lp.id
		left outer join LanguageProject_Locations loc on loc.src = lp.id
		left outer join LanguageProject_AnalysisStatus ana on ana.src = lp.id
		left outer join RnResearchNotebook_EventTypes typ on typ.src = rnb.dst
		left outer join LanguageProject_TimeOfDay tim on tim.src = lp.id
		left outer join LanguageProject_Education edu on edu.src = lp.id
		left outer join LanguageProject_Positions psn on psn.src = lp.id
		left outer join LanguageProject_PartsOfSpeech pos on pos.src = lp.id
		left outer join CmProject_Name cpn on cpn.obj = lp.id
		where lp.id = 1 and cpn.Ws = 740664001
	  Sample results:
		rnb   con  res  wea  rol  peo  loc  ana  typ  tim  edu  pos  anit  Txt
		----- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----------
		1611  25   30   35   62   66   77   13   1707 86   17   98   443  FRN-French
		*/
		stu.Format(L"select rnb.dst rnb, con.dst con, res.dst res, wea.dst wea, rol.dst rol, "
			L"peo.dst peo, loc.dst loc, ana.dst ana, typ.dst typ, tim.dst tim, edu.dst edu, "
			L"psn.dst psn, pos.dst pos, anit.dst anit, cpn.Txt "
			L"from LanguageProject lp (readuncommitted) "
			L"left outer join LanguageProject_ResearchNotebook rnb (readuncommitted) on rnb.src = lp.id "
			L"left outer join LanguageProject_ConfidenceLevels con (readuncommitted) on con.src = lp.id "
			L"left outer join LanguageProject_Restrictions res (readuncommitted) on res.src = lp.id "
			L"left outer join LanguageProject_WeatherConditions wea (readuncommitted) on wea.src = lp.id "
			L"left outer join LanguageProject_Roles rol (readuncommitted) on rol.src = lp.id "
			L"left outer join LanguageProject_People peo (readuncommitted) on peo.src = lp.id "
			L"left outer join LanguageProject_Locations loc (readuncommitted) on loc.src = lp.id "
			L"left outer join LanguageProject_AnalysisStatus ana (readuncommitted) on ana.src = lp.id "
			L"left outer join RnResearchNotebook_EventTypes typ (readuncommitted) on typ.src = rnb.dst "
			L"left outer join LanguageProject_TimeOfDay tim (readuncommitted) on tim.src = lp.id "
			L"left outer join LanguageProject_Education edu (readuncommitted) on edu.src = lp.id "
			L"left outer join LanguageProject_Positions psn (readuncommitted) on psn.src = lp.id "
			L"left outer join LanguageProject_PartsOfSpeech pos (readuncommitted) on pos.src = lp.id "
			L"left outer join LanguageProject_AnthroList anit (readuncommitted) on anit.src = lp.id "
			L"left outer join CmProject_Name cpn (readuncommitted) on cpn.obj = lp.id "
			L"where lp.id = %d and cpn.Ws = %d ", m_hvoLp, m_vwsAnal[0]);
		CheckHr(qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));
		if (fMoreRows)
		{ 
			//johnH pasted in from Notebk.cpp
				m_vhvoPsslIds.Resize(kpidPsslLim);

			//johnH commented out CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_hvoRn),
			//	isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(2, reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslCon]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(3, reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslRes]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(4, reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslWea]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(5, reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslRol]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(6, reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslPeo]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(7, reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslLoc]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(8, reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslAna]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(9, reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslTyp]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(10,
				reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslTim]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(11,
				reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslEdu]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(12,
				reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslPsn]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(14,
				reinterpret_cast<ULONG *>(&m_vhvoPsslIds[kpidPsslAnit]),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(15, reinterpret_cast <ULONG *>(rgchProjName),
				isizeof(rgchProjName), &cbSpaceTaken, &fIsNull, 2));
//johnH/			CheckHr(qodc->GetColValue(14, reinterpret_cast <ULONG *>(rgchProjName),
		//		80, &cbSpaceTaken, &fIsNull, 2));
		}
		else
		{
			// If we don't have any rows, we used a wrong language project id (m_hvoLp),
			// or one or more essential possibility lists are missing,
			// so return and let the user open a project from the Debug menu (for now).
			Assert(false);
			return false;
		}
//johnH//		m_stuPrjName = rgchProjName;
	}
	catch (...)
	{
		return false;
	}
#endif
	return true;
}


STDMETHODIMP CDeView::Refresh()
{
    HvoClsidVec vhcT;
     vhcT.Push(m_hcRoot);
	
    m_qcvd->LoadData(vhcT, m_quvs, NULL, true);

	//	Get rid of the display of the old object for both panes, if there are two

    for (int i = 0; i < 2; i++)
    {
         DeViewDeWnd * padw = dynamic_cast<DeViewDeWnd *>(GetPane(i));
         if (padw)
         { 
			 padw->CloseAllEditors();

			//     set up the initial fields:

			int idfe = 0; // where to add new fields
			padw->SetLpInfo(m_qlpi);
			ClsLevel clev(m_hcRoot.clsid, 0);
			padw->AddFields(m_hcRoot.hvo, clev, m_qcvd, idfe, 0);
			padw->SetHeight();
		 }
	}


	// (e) Finally, call OpenNextEditor() on one of the panes to get
	//editing going.
   
    //for (int i = 0; i < 2; i++)
    {
         AfDeSplitChild * padw = dynamic_cast<AfDeSplitChild *>(GetPane(0));
         if (padw)
              padw->OpenNextEditor();
    }
	return S_OK;
}

STDMETHODIMP CDeView::GetSILDataAccess(ISilDataAccess** ppsildb)
{
	AssertPtr(ppsildb);
	return m_qcvd->QueryInterface(IID_ISilDataAccess, (void **)ppsildb);
}

STDMETHODIMP CDeView::GetActionHandler(IActionHandler** ppacth)
{
	AssertPtr(m_qlpi);

	AssertPtr(ppacth);
	
	m_qlpi->GetActionHandler(ppacth);
	AssertPtr(*ppacth);
	return S_OK;
}

// ENHANCE: this is of limitted usefullness until IDbAccess stops using ulongs for ids, which VB can't handle
STDMETHODIMP CDeView::GetMetaDataCache(IFwMetaDataCache ** ppmdc)
{
	AssertPtr(ppmdc);

    AfDeSplitChild * padw = dynamic_cast<AfDeSplitChild *>(GetPane(0));
    if (!padw)
		return E_FAIL;

			 
	padw->GetLpInfo()->GetDbInfo()->GetFwMetaDataCache(ppmdc);
	AssertPtr(*ppmdc);
	//return  m_qcvd->QueryInterface(IID_ISilDataAccess, (void **)ppmdc);

	return S_OK;
}

STDMETHODIMP CDeView::get_RootObject(long *pVal)
{
	*pVal = m_hcRoot.hvo;

	return S_OK;
}


/*STDMETHODIMP CDeView::GetClassName(long lObjId, BSTR* pbstrName)
{
    AfDeSplitChild * padw = dynamic_cast<AfDeSplitChild *>(GetPane(0));
    if (!padw)
		return E_FAIL;

			 
	IFwMetaDataCachePtr qmdc;
	padw->GetLpInfo()->GetDbInfo()->GetFwMetaDataCache(qmdc);
	int iClid=0;
	CHECK_HR(qmdc->GetClassId(lObjId, &iClid));

	CHECK_HR(qmdc->GetClassName(iClid, pbstrName));
	return S_OK;
}
*/
STDMETHODIMP CDeView::get_FocusObject(long *pVal)
{
	AfDeSplitChildPtr qadw;
	qadw = ((AfDeSplitChild*)(m_rgqsplc[0].Ptr()));	// note: first pane only

	int idyp_unused=0;
	int iFldIndex = qadw->GetEditorIndex(&idyp_unused);
	if (iFldIndex < 0)
	{
		*pVal = 0;
		return S_FALSE; // no active editor
	}

	DeEditorVec & rvEditors = qadw->GetEditors();
	*pVal = rvEditors[iFldIndex]->GetOwner();

	return S_OK;
}
STDMETHODIMP CDeView::get_FocusField(long *pVal)
{
	AfDeSplitChildPtr qadw;
	qadw = ((AfDeSplitChild*)(m_rgqsplc[0].Ptr()));	// note: first pane only

	int idyp_unused=0;
	int iFldIndex = qadw->GetEditorIndex(&idyp_unused);
	if (iFldIndex < 0)
	{
		*pVal = 0;
		return S_FALSE; // no active editor
	}

	DeEditorVec & rvEditors = qadw->GetEditors();
	*pVal = rvEditors[iFldIndex]->GetOwnerFlid();

	return S_OK;
}
	
	STDMETHODIMP CDeView::put_RootObject(long newVal)
{
	if(m_hcRoot.hvo == newVal)
		return S_OK;
	
	m_hcRoot.hvo = newVal;
	
	if(!m_qdbi)	// not visible yet
		return S_OK;

      // Load the data about this HVO into the data access object.
     // It is capable of loading data about a whole vector of objects, but we have
     // just one. Put that one into the vector.
  //   HvoClsidVec vhcT;
 //    vhcT.Push(m_hcRoot);

     // The last argument can be a status bar for  reporting progress. We need to wrap this
     // in an interface.
 //    m_qcvd->LoadData(vhcT, m_quvs, NULL, true);




	return Refresh();
}


HRESULT  CDeView::StartupView()
{
	InitViewSpec();
	AssertPtr(m_qdvs);

	// If calling for the first time, set up the database connection, the view defn, etc.
	if (!m_qdbi)
	{
		// Create the database and language project info objects. These also contain the
		// database and metadatacache and CustViewDa objects.
		// Added NULL IStream pointer to m_qdbi->Init. This to satisfy the new interface spec.;
		// logging is, of course, not enabled.
		m_qdbi.Create();
		IStream * pfist = NULL;
		m_qdbi->Init(m_stuSvrName.Chars(), m_stuDbName.Chars(), pfist);
		m_qlpi.Create();
		m_qdbi->SetLpInfo(m_qlpi);
		m_qlpi->Init(m_qdbi, m_hvoLp);
		m_qlpi->OpenProject();
		m_qlpi->GetDataAccess(&m_qcvd);

		m_qdvs->FinishInit(m_qdbi);		// now that we have the db connection, can finish initializing the view spec


		SetCustViewDaTags(m_qcvd);	//johnh

		// Create the "UserView" that defines what data to load and how to display.
		m_quvs.Attach(NewObj UserViewSpec);

		m_qdvs->AddBlockSpecs(m_quvs, m_qdbi);

/*		ClsLevel clevKey; // Key for specifying records in UserViewSpec
			//clevKey.m_clsid = kclidRnEvent;
		clevKey.m_clsid = m_hcRoot.clsid; //johnh: we already have this here, I assume we can reuse it

		for (int iLev = 0; iLev < 2; iLev++)
		{
			// We are creating a record spec for Level iLev objects
			// (0..the top-level object. 1...anything lower.)
			// Currently we are making the two the same.
			clevKey.m_nLevel = iLev;


		
			// Create a record spec for this object class and level
			RecordSpecPtr qrsp;
			qrsp.Attach(NewObj RecordSpec(m_hcRoot.clsid,  iLev));	// jh was  kclidRnEvent
			// Install it in the user view spec
			m_quvs->m_hmclevrsp.Insert(clevKey, qrsp, true);

			m_qdvs->AddBlockSpecs(qrsp, iLev);

			// Use the MetaDataCache to fill in required actual field names based on the flids
			qrsp->SetMetaNames(m_qdbi);
		} // loop making record specs for two levels
*/
	} // not already initialized

	
	DeViewDeWndPtr qadw;
	qadw = ((DeViewDeWnd*)(m_rgqsplc[0].Ptr()));
	{
		qadw->Init(  m_qdvs , m_qlpi); //johnH
			
		// This is the first child window we are making.
		// For now, set tree width to an arbitrary 100 pixels. Later, we may want to persist
		// the user's setting somewhere.
		qadw->SetTreeWidth(100);
		// Load the data about this HVO into the data access object.
		// It is capable of loading data about a whole vector of objects, but we have
		// just one. Put that one into the vector.
		HvoClsidVec vhcT;
		vhcT.Push(m_hcRoot);
		// The last argument can be a status bar for reporting progress. We need to wrap this
		// in an interface.
		m_qcvd->LoadData(vhcT, m_quvs, NULL);
	}

	// Common initialization
	// Add fields for root at position 0, level 0.
	int idfe = 0; // where to add new fields
	qadw->SetLpInfo(m_qlpi);

	ClsLevel clev(m_hcRoot.clsid, 0);
	qadw->AddFields(m_hcRoot.hvo, clev, m_qcvd, idfe, 0);
	qadw->SetHeight();
		qadw->OpenNextEditor();
	return S_OK;
}

HRESULT getTextAttr(MSXML::IXMLDOMNode* pNode, const OLECHAR* wStr, BSTR* pbstrVal)
{
	AssertPtr(pbstrVal);
	
	HRESULT hr = S_OK;
	MSXML::IXMLDOMNamedNodeMap* pattrs;
	MSXML::IXMLDOMNode* pAttrNode;
	
	BSTR bstrAttrName = SysAllocString(wStr);

	CheckHr(pNode->get_attributes(&pattrs));
	AssertPtr(pattrs);
	CheckHr(pattrs->getNamedItem(bstrAttrName, &pAttrNode));
	AssertPtr(pAttrNode);
	CheckHr(pAttrNode->get_text(pbstrVal));

	return hr;
}

void CDeView::ReadDataSourceXML(BSTR bstrDataSourceXML)
{
	
    MSXML::IXMLDOMDocument *pDoc = NULL;
    MSXML::IXMLDOMNode* pNode = NULL;
 
    // Create an empty XML document
    CheckHr(CoCreateInstance(MSXML::CLSID_DOMDocument, NULL, CLSCTX_INPROC_SERVER,
                                MSXML::IID_IXMLDOMDocument, (void**)&pDoc));
	VARIANT_BOOL vbOK;
	pDoc->loadXML(bstrDataSourceXML, &vbOK); // L"<DataAccessSetup Server='.'  DB='TestLangProj' LangProj='1'/>", &vbOK);
	Assert(vbOK);
	

	BSTR pQry = SysAllocString(L"/DataAccessSetup");
	MSXML::IXMLDOMNodeList* pNodeList;
	CheckHr(pDoc->selectNodes(pQry, &pNodeList));
	Assert(S_OK ==pNodeList->get_item(0, &pNode));
	CheckHr(pNodeList->Release());

	BSTR pAttrVal;
	getTextAttr(pNode, L"Server", &pAttrVal);
	m_stuSvrName = pAttrVal;

	getTextAttr(pNode, L"DB", &pAttrVal);
	m_stuDbName = pAttrVal;


	CheckHr(pNode->Release());

}

/*----------------------------------------------------------------------------------------------
	This is a required method for anything inheriting from AfWnd which contains smart
	pointers. It should clear them. This is done to break cycles and prevent memory
	leaks. Not every pointer absolutely must be released (if they couldn't possibly
	be involved in a cycle with this object), but clearing them all will reduce the
	mass of memory leaks when there are some and make it easier to find the real one.
----------------------------------------------------------------------------------------------*/
void CDeView::OnReleasePtr()
{
/*	if(m_qdvs)
	{
		delete(m_qdvs);
		m_qdvs = NULL;
	}
*/
	m_qdvs.Clear();

	// Need these cleanup calls to break the cycle of references between the DbInfo and the
	// LpInfo. Note that, if they are ever shared by other windows, some other strategy
	// will be needed.
	if (m_qdbi)
		m_qdbi->CleanUp();
	if (m_qlpi)
		m_qlpi->CleanUp();
	m_qdbi.Clear(); 
	m_qlpi.Clear();
	m_qcvd.Clear();
	m_quvs.Clear();

	SuperClass::OnReleasePtr();
}


