/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Jan 10 08:57:05 2001
 */
/* Compiler settings for c:\fw\Src\DeCtl\DeCtl.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __DeCtl_h__
#define __DeCtl_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDeView_FWD_DEFINED__
#define __IDeView_FWD_DEFINED__
typedef interface IDeView IDeView;
#endif 	/* __IDeView_FWD_DEFINED__ */


#ifndef __DeView_FWD_DEFINED__
#define __DeView_FWD_DEFINED__

#ifdef __cplusplus
typedef class DeView DeView;
#else
typedef struct DeView DeView;
#endif /* __cplusplus */

#endif 	/* __DeView_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_DeCtl_0000 */
/* [local] */ 


#undef ATTACH_GUID_TO_CLASS
#if defined(__cplusplus)
#define ATTACH_GUID_TO_CLASS(type, guid, cls) \
	type __declspec(uuid(#guid)) cls;
#else // !defined(__cplusplus)
#define ATTACH_GUID_TO_CLASS(type, guid, cls)
#endif // !defined(__cplusplus)

#ifndef DEFINE_COM_PTR
#define DEFINE_COM_PTR(cls)
#endif

#undef GENERIC_DECLARE_SMART_INTERFACE_PTR
#define GENERIC_DECLARE_SMART_INTERFACE_PTR(cls, iid) \
	ATTACH_GUID_TO_CLASS(interface, iid, cls); \
	DEFINE_COM_PTR(cls);


#ifndef CUSTOM_COM_BOOL
typedef VARIANT_BOOL ComBool;

#endif

#if 0
// This is so there is an equivalent VB type.
typedef CY SilTime;

#elif defined(SILTIME_IS_STRUCT)
// This is for code that compiles UtilTime.*.
struct SilTime;
#else
// This is for code that uses a 64-bit integer for SilTime.
typedef __int64 SilTime;
#endif

ATTACH_GUID_TO_CLASS(class,
BCF40BC5-F319-4e47-98A5-8288D4EEAE33
,
DeCtlLib
);


extern RPC_IF_HANDLE __MIDL_itf_DeCtl_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_DeCtl_0000_v0_0_s_ifspec;


#ifndef __DeCtlLib_LIBRARY_DEFINED__
#define __DeCtlLib_LIBRARY_DEFINED__

/* library DeCtlLib */
/* [helpstring][version][uuid] */ 

GENERIC_DECLARE_SMART_INTERFACE_PTR(
IDeView
,
936BAE9A-D2BB-4c9c-AF16-14A3D8AC33B5
);
ATTACH_GUID_TO_CLASS(class,
F1508112-DC3B-4323-A7EF-30B623B3DCDB
,
DeView
);

#define LIBID_DeCtlLib __uuidof(DeCtlLib)

#ifndef __IDeView_INTERFACE_DEFINED__
#define __IDeView_INTERFACE_DEFINED__

/* interface IDeView */
/* [object][unique][oleautomation][dual][uuid] */ 


#define IID_IDeView __uuidof(IDeView)

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("936BAE9A-D2BB-4c9c-AF16-14A3D8AC33B5")
    IDeView : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IDeViewVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDeView __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDeView __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDeView __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDeView __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDeView __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDeView __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDeView __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IDeViewVtbl;

    interface IDeView
    {
        CONST_VTBL struct IDeViewVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDeView_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDeView_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDeView_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDeView_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDeView_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDeView_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDeView_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IDeView_INTERFACE_DEFINED__ */


#define CLSID_DeView __uuidof(DeView)

#ifdef __cplusplus

class DECLSPEC_UUID("F1508112-DC3B-4323-A7EF-30B623B3DCDB")
DeView;
#endif
#endif /* __DeCtlLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
