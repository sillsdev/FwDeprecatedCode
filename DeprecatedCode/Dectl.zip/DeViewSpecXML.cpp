// DeViewSpecXML.cpp: implementation of the CDeViewSpecXML class.
//
//////////////////////////////////////////////////////////////////////

#include "main.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDeViewSpecXML::CDeViewSpecXML(HVO hvoLP)
:CDeViewSpec(hvoLP)
{

}

CDeViewSpecXML::~CDeViewSpecXML()
{

}

void CDeViewSpecXML::Init(BSTR bstrViewSpecPath)
{
	OutputDebugString("Init XML\n");
}
