/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2000, SIL International. All rights reserved.

File: AfDeFeLaunchTool.cpp
Responsibility: John Hatton
Last reviewed: never

Description:

-------------------------------------------------------------------------------*//*:End Ignore*/
#include "Main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

AfDeFeLaunchTool::AfDeFeLaunchTool()
{
}


AfDeFeLaunchTool::~AfDeFeLaunchTool()
{
}


//:>********************************************************************************************
//:>	AfDeFeLaunchTool methods.
//:>********************************************************************************************


/*----------------------------------------------------------------------------------------------
	This initializes the string based on the input date.
----------------------------------------------------------------------------------------------*/
void AfDeFeLaunchTool::InitContents(int gdat)
{
	SuperClass::Init(); // Initialize the superclass.
/*
	m_gdat = gdat;

	ITsStringPtr qtss;
	ITsStrFactoryPtr qtsf;
	StrUni stu;
	stu.Format(L"%D", m_gdat);

	qtsf.CreateInstance(CLSID_TsStrFactory);
	qtsf->MakeStringRgch(stu.Chars(), stu.Length(), m_ws, &qtss);
	m_qtss = qtss;
*/
}


/*----------------------------------------------------------------------------------------------
	Refresh the field from the data cache.
----------------------------------------------------------------------------------------------*/
void AfDeFeLaunchTool::UpdateField()
{
/*	// Get the date from the cache.
	int gdat;
	CustViewDaPtr qcvd;
	m_qadw->GetLpInfo()->GetDataAccess(&qcvd);
	AssertPtr(qcvd);
	CheckHr(qcvd->get_IntProp(m_hvoObj, m_flid, &gdat));

	// Set it to standard form.
	InitContents(gdat);
	// If we have an edit box, update the contents.
	if (m_hwnd)
		::SendMessage(m_hwnd, FW_EM_SETTEXT, 0, (LPARAM)m_qtss.Ptr());
*/
}

/*----------------------------------------------------------------------------------------------
	Process commands. Return true if processed.
----------------------------------------------------------------------------------------------*/
void AfDeFeLaunchTool::ProcessChooser()
{
	::MessageBox(m_hwnd, "Click", NULL, MB_OK);
}


/*----------------------------------------------------------------------------------------------
	Save changes that have been made to the current editor. This one does not really support
	editing. but because it subclasses AfDeFeEdBoxBut it needs to remove the mark from the
	undo stack.
----------------------------------------------------------------------------------------------*/
bool AfDeFeLaunchTool::SaveEdit()
{
	IActionHandler * pacth;
	pacth = EndTempEdit();
	return true;
}
