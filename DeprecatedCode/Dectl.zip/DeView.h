// DeView.h : Declaration of the CDeView

#ifndef __DeView_H_
#define __DeView_H_

//#include "DeViewSpec.h"
class CDeViewSpec;
typedef GenSmartPtr<CDeViewSpec> CDeViewSpecPtr;

/*----------------------------------------------------------------------------------------------
	This class contains information about a language project. It is adapted (mostly simplified)
	from RnLpInfo. We need it because a CustViewDa requires an AfLpInfo, and the most
	straightforward way to initialize one is by implementing an OpenProject method like
	RnLpInfo.
	ENHANCE JohnT: figure a way that not all this logic needs to be in every client. At least
	some of the queries involved in OpenProject are common to all LpInfos and could be methods
	on the base class.
----------------------------------------------------------------------------------------------*/
class DeLpInfo : public AfLpInfo
{
public:
	virtual bool OpenProject();
	virtual bool LoadProjBasics();
	
	enum	//johnh
	{
		kpidPsslCon = 0,
		kpidPsslRes,
		kpidPsslWea,
		kpidPsslRol,
		kpidPsslPeo,
		kpidPsslLoc,
		kpidPsslAna,
		kpidPsslTyp,
		kpidPsslTim,
		kpidPsslEdu,
		kpidPsslPsn,
		kpidPsslPos,
		kpidPsslAnit,

		kpidPsslLim,
	};

protected:
};

typedef GenSmartPtr<DeLpInfo> DeLpInfoPtr;

/*----------------------------------------------------------------------------------------------
	This class is overridden to allow us to simply store a DeLpInfo structure.
	The GetLpInfo method is pure virtual on the superclass.
----------------------------------------------------------------------------------------------*/
class DeDbInfo : public AfDbInfo
{
	typedef AfDbInfo SuperClass;
public:

	virtual AfLpInfo * GetLpInfo(HVO hvoLp)
	{
		return m_qlpi;
	}
	void SetLpInfo(DeLpInfo * plpi)
	{
		m_qlpi = plpi;
	}
	virtual void CleanUp()
	{
		m_qlpi.Clear();
		SuperClass::CleanUp();
	}

protected:
	DeLpInfoPtr m_qlpi;
};

typedef GenSmartPtr<DeDbInfo> DeDbInfoPtr;

class DeViewDeWnd : public AfDeSplitChild
{
	typedef AfDeSplitChild SuperClass;
public:
	virtual int AddFields(HVO hvoRoot, ClsLevel & clev, CustViewDa *pcvd, int idfe, int nInd);
	virtual void AddField(HVO hvoRoot, int clid, int nLev, FldSpec * pfsp, 
		CustViewDa * pcvd, int & idfe, int nInd = 0, bool fAlwaysVisible = false);
	void SetTreeHeader(AfDeFeTreeNode * pdetn);
	void Init(CDeViewSpecPtr qdvs, DeLpInfoPtr qlpi)//johnh
	{
		AssertPtr(qdvs);
		AssertPtr(qlpi);
		m_qdvs = qdvs;
		m_qlpi = qlpi;
	}
protected:
	CDeViewSpecPtr m_qdvs;	// johnH
	DeLpInfoPtr m_qlpi; // johnH
};

typedef GenSmartPtr<DeViewDeWnd> DeViewDeWndPtr;

/////////////////////////////////////////////////////////////////////////////
// CDeView
//class ATL_NO_VTABLE CDeView : 
class CDeView : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IDispatchImpl<IDeView, &IID_IDeView, &LIBID_DeCtlLib>,
	public AfAtlSplitControl<CDeView>,
	public IPersistStreamInitImpl<CDeView>,
	public IOleControlImpl<CDeView>,
	public IOleObjectImpl<CDeView>,
	public IOleInPlaceActiveObjectImpl<CDeView>,
	public IViewObjectExImpl<CDeView>,
	public IOleInPlaceObjectWindowlessImpl<CDeView>,
	public IPersistStorageImpl<CDeView>,
	public ISpecifyPropertyPagesImpl<CDeView>,
	public IQuickActivateImpl<CDeView>,
	public IDataObjectImpl<CDeView>,
	public IProvideClassInfo2Impl<&CLSID_DeView, NULL, &LIBID_DeCtlLib>,
	public CComCoClass<CDeView, &CLSID_DeView>
{
	// From the point of view of the FieldWorks class hierarchy, this is the most
	// natural superclass, the only one that is a FieldWorks window class.
	typedef AfAtlSplitControl<CDeView> SuperClass;
	friend class DeViewDeWnd;
public:


DECLARE_REGISTRY_RESOURCEID(IDR_DeView)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDeView)
	COM_INTERFACE_ENTRY(IDeView)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
END_COM_MAP()

BEGIN_PROP_MAP(CDeView)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("Root viewable object", 1, CLSID_NULL)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_MSG_MAP(CDeView)
	CHAIN_MSG_MAP(AfAtlSplitControl<CDeView>)
	DEFAULT_REFLECTION_HANDLER()
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);



// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)


public:
	CDeView()
	{
		m_bWindowOnly = true;
//		m_pdvs=NULL;
		m_hcRoot.hvo = 0;
		m_hcRoot.clsid = 0;
		m_hvoLp = 1;
		// Display this arbitrary event in this arbitrary language project unless overridden
		// (e.g., by making this info accessible by property).
		// This will only work in TestLangProj.
		//johnH moved all this to InitControlParams()
		//m_stuDbName = L"TestLangProj";
		//m_hcRoot.hvo = 1579;
		//m_hcRoot.clsid = kclidRnEvent;
		//m_hvoLp = 1;
	};
	virtual void OnReleasePtr();

// IDeView
protected:
	DeDbInfoPtr m_qdbi; // DbInfo, basic info about the database we are manipulating.
	DeLpInfoPtr m_qlpi; // AfLpInfo subclass, info about the language project we are part of.
#if 0 // Don't think we need this now we have the info objects above, keep until sure.
	// Comments about these objects which are now embedded in the info objects may be useful.
	IOleDbEncapPtr m_qode;	//  Current data access object.
	IFwMetaDataCachePtr m_qmdc;	//  Current meta data cache.
#endif

	// The CustViewDa stores the data from the database. Eventually this will be replaced
	// with a full COM component that may be implemented by another DLL (probably DbAccess).
	// It is initialized by and obtained from the LpInfo object.
	CustViewDaPtr m_qcvd;

	// This is set up to specify the fields to be displayed.
	UserViewSpecPtr m_quvs;

	// These should eventually be settable by property.
	// Changing them would produce a save and regenerate.
	// May need special approach to allow several things to be changed at once.
	StrUni m_stuSvrName; // path to the server, default empty
	StrUni m_stuDbName; // name of the particular database, default currently TestLangProj

	// HVO and CLSID of the root object we are editing.
	// The HVO should be settable by a property. The CLSID could be obtained from the
	// database; for this demo we set it manually.
	HvoClsid m_hcRoot; 
	// HVO of the language project it is part of.
	// ENHANCE JohnT: what will (and what should) happen if the user gets them wrong?
	HVO m_hvoLp;

	// Defines what this control actually shows
	CDeViewSpecPtr m_qdvs;

	SmartBstr m_bstrDBConnectionXML;	// how to connect to the db and which lang proj
	SmartBstr m_bstrViewSpecPath;		// defines what this control should display

protected: // Override these to customize control.
	void ReadDataSourceXML(BSTR bstrDataSourceXML);
	virtual void InitViewSpec(); //johnH added
	virtual void SetCustViewDaTags(CustViewDaPtr qcvd); //johnH added

public:
	// Add most new methods here.
	void CreateChild(class AfSplitChild * pasc, class AfSplitChild ** ppascNew);
public:
	STDMETHOD(get_RootObject)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_RootObject)(/*[in]*/ long newVal);
	STDMETHOD(get_FocusField)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_FocusObject)(/*[out, retval]*/ long *pVal);
	STDMETHOD(Startup)(BSTR bstrDataSourceXML, BSTR bstrViewSpecPath, int iRootObjectID);
	STDMETHOD(Refresh)();
	STDMETHOD(GetSILDataAccess)(/*[out, retval]*/ ISilDataAccess** ppsildb);
	STDMETHOD(GetActionHandler)(IActionHandler** ppacth);

	STDMETHOD (GetMetaDataCache)(/*[out, retval]*/IFwMetaDataCache ** ppmdc);
	//STDMETHOD(GetClassName)(/*[in]*/long lObjId, /*[out, retval]*/BSTR* pbstrName);

public:
	HRESULT StartupView();
	// Add most new methods here.

};

#endif //__DeView_H_
