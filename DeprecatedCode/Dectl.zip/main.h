// main.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__510BA25F_2712_498A_976C_ED703C12357A__INCLUDED_)
#define AFX_STDAFX_H__510BA25F_2712_498A_976C_ED703C12357A__INCLUDED_
#pragma once

#include "common.h"
#include "AfCore.h"
#include "AfDeCore.h"

#define _ATL_APARTMENT_THREADED

// ENHANCE JohnT: are any of these in common.h? Should they be?

#include <atlbase.h>
//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module
extern CComModule _Module;
#include <atlcom.h>
#include <atlctl.h>

#include "resource.h"
#include <initguid.h>
#include "DeCtlTlb.h"

#include "resource.h"       // main symbols
#include <atlctl.h>

// Will probabably become part of AppCore soon.
#include "AfAxWnd.h"
#include "AfAtlVwWnd.h"

// Add new includes for this component here.
#include "intmap.h"
#include "DeView.h"
#include "DeViewSpec.h"
#include "DeViewSpecLex.h"
#include "DeViewSpecXML.h"
#include "RecordSpecMaker.h"

#include "AfDeFeLaunchTool.h"

#define CMCG_SQL_DEFNS
	#include "Ling.sqh"
#undef CMCG_SQL_DEFNS

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__510BA25F_2712_498A_976C_ED703C12357A__INCLUDED)
