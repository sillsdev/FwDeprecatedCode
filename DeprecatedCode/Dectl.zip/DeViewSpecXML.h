// DeViewSpecXML.h: interface for the CDeViewSpecXML class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVIEWSPECXML_H__9273DC05_8B96_4070_B4E7_FF3A28293D16__INCLUDED_)
#define AFX_DEVIEWSPECXML_H__9273DC05_8B96_4070_B4E7_FF3A28293D16__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DeViewSpec.h"

#import "msxml.dll" named_guids raw_interfaces_only

typedef GenSmartPtr<MSXML::IXMLDOMDocument> XMLDOMDocumentPtr;

class CDeViewSpecXML : public CDeViewSpec  
{
public:
	void Init(BSTR bstrViewSpecPath);
	CDeViewSpecXML(HVO hvoLP);
	virtual ~CDeViewSpecXML();

protected:
	XMLDOMDocumentPtr m_qdoc;
};

#endif // !defined(AFX_DEVIEWSPECXML_H__9273DC05_8B96_4070_B4E7_FF3A28293D16__INCLUDED_)
