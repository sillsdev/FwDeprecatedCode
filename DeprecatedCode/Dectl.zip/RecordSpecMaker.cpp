// RecordSpecMaker.cpp: implementation of the CRecordSpecMaker class.
//
//////////////////////////////////////////////////////////////////////
#include "main.h"
#pragma hdrstop
#undef THIS_FILE
DEFINE_THIS_FILE

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRecordSpecMaker::CRecordSpecMaker(UserViewSpecPtr& quvs, long clidRootObject, int nLevel)
:bDidFinish(false)
{
	AssertPtr(quvs);
	quvs->AssertValid();
//	m_quvs = quvs;

	ClsLevel clevKey; // Key for specifying records in UserViewSpec
	clevKey.m_clsid = clidRootObject;
	clevKey.m_nLevel = nLevel;

	m_qrsp.Attach(NewObj RecordSpec(clidRootObject,  nLevel));
	// Install it in the user view spec
	quvs->m_hmclevrsp.Insert(clevKey, m_qrsp, true);

}

CRecordSpecMaker::~CRecordSpecMaker()
{
	Assert(bDidFinish==true);
}

void CRecordSpecMaker::AddField//(const OLECHAR *pszLabel, int iTag, FldType ftFieldType, FldVis fldVisible, 
							   //FldReq fldReq, OutlineNumSty onsOutlineStyle, LPCOLESTR pszHelp,
							  // LPCOLESTR pszStyle)
		(LPCOLESTR pszLabel, 
		int iTag, 
		int iEnc, 
		FldType ftFieldType, 
		FldVis fldVisible, 
		FldReq fldReq,
		OutlineNumSty onsOutlineStyle, 
		HVO listid, 
		LPCOLESTR pszHelp, 
		LPCOLESTR pszStyle, 
		bool bIsCustFld)
{
	Assert(bDidFinish==false);

	ITsStrFactoryPtr qtsf;
	qtsf.CreateInstance(CLSID_TsStrFactory);

	// Labels are made in some writing system. Arbitrarily use English for this demo.
	int ws = StrUtil::ParseWs("ENG");

	ITsStringPtr qtssLabel; // used for label of each field.
	ITsStringPtr qtssHelp; // used for label of each field.
	BlockSpecPtr qbsp;


	CheckHr(qtsf->MakeStringRgch(pszLabel, wcslen(pszLabel), ws, &qtssLabel));
	CheckHr(qtsf->MakeStringRgch(pszHelp, wcslen(pszHelp), ws, &qtssHelp));
	qbsp.Attach(NewObj BlockSpec(qtssLabel, // string for tree/outline
		qtssHelp, // help string
		iTag, // field in database
		ftFieldType, 
		fldVisible,
		fldReq, 
		pszStyle,
		iEnc, //writing system
		bIsCustFld,
		listid)); 
	qbsp->m_ons = onsOutlineStyle; 

	m_qrsp->m_vqbsp.Push(qbsp);
}

void CRecordSpecMaker::Finish(DeDbInfoPtr &qdbi)
{
	// Use the MetaDataCache to fill in required actual field names based on the flids
	m_qrsp->SetMetaNames(qdbi);
	bDidFinish=true;
}
