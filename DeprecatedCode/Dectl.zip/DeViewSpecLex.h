// DeViewSpec.h: interface for the DeViewSpec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVIEWSPECLex_H__78C577EF_D0E1_4591_9FEB_FDEE32EA3A0C__INCLUDED_)
#define AFX_DEVIEWSPECLex_H__78C577EF_D0E1_4591_9FEB_FDEE32EA3A0C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDeViewSpecLex : public CDeViewSpec 
{
public:
	CDeViewSpecLex(HVO hvoLP);
	virtual ~CDeViewSpecLex();

	virtual void Init();
	virtual void FinishInit(DeDbInfoPtr m_qdbi);
	int GetPossListForField(int flid);
	virtual void GetTags(int *ptagRootItems, int *ptagItemSort);
	virtual void GetRootObjectClass(int *pclsid);

	virtual void AddBlockSpecs(UserViewSpecPtr& quvs, DeDbInfoPtr& qdbi);
	virtual void SetTreeHeader(CustViewDaPtr qvcd, HVO hvo, int flid, ITsString ** pptss, DeLpInfo *plpi);

protected:
	void GetPossListIds(DeDbInfoPtr qdbi);
};

#endif // !defined(AFX_DEVIEWSPEC_H__78C577EF_D0E1_4591_9FEB_FDEE32EA3A0C__INCLUDED_)
