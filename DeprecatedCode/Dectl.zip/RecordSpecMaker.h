// RecordSpecMaker.h: interface for the CRecordSpecMaker class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BLOCKSPECMAKER_H__2D28AB06_1DE1_43BB_9CC5_94C27385A3EE__INCLUDED_)
#define AFX_BLOCKSPECMAKER_H__2D28AB06_1DE1_43BB_9CC5_94C27385A3EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRecordSpecMaker  
{
public:
	bool bDidFinish;
	CRecordSpecMaker(UserViewSpecPtr& quvs, long clidRootObject, int nLevel);
	virtual ~CRecordSpecMaker();
	void AddField(LPCOLESTR pszLabel, int iTag, int iEnc, FldType ftFieldType,  FldVis fldVisible=kFTVisAlways, FldReq fldReq=kFTReqNotReq,
		OutlineNumSty onsOutlineStyle=konsNone, HVO listid=NULL, LPCOLESTR pszHelp=L"", LPCOLESTR pszStyle=L"", bool isCustFld=false);
	void Finish(DeDbInfoPtr& qdbi);

protected:
	//UserViewSpecPtr m_quvs;
	RecordSpecPtr m_qrsp;

};

#endif // !defined(AFX_BLOCKSPECMAKER_H__2D28AB06_1DE1_43BB_9CC5_94C27385A3EE__INCLUDED_)
