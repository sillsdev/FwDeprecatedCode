/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Nov 23 07:58:12 2000
 */
/* Compiler settings for C:\fw\Src\DeCtl\DeCtl.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IDeView = {0x74AC1730,0xD8AE,0x4BA7,{0xBC,0x68,0x0C,0x5E,0xF4,0xB3,0x96,0x0F}};


const IID LIBID_DeCtlLib = {0xF7DC6325,0x7613,0x4DB8,{0xAC,0x71,0x23,0xB2,0xD2,0x06,0xC4,0x18}};


const CLSID CLSID_DeView = {0x35EAA757,0xADCB,0x48CD,{0x8F,0xBC,0xDD,0x63,0x24,0x22,0x79,0x9C}};


#ifdef __cplusplus
}
#endif

