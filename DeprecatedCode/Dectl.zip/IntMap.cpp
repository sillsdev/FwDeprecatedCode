// IntMap.cpp: implementation of the IntMap class.
//
//////////////////////////////////////////////////////////////////////

#include "main.h"
#include "IntMap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////



void IntMap::add(int iKey, int iValue)
{
	m_vkeys.Push(iKey);
	m_vvalues.Push(iValue);
}

int IntMap::lookup(int iKey) const
{
	for(int i=0; i<m_vkeys.Size();i++)
	{
		if (m_vkeys[i] == iKey)
			return m_vvalues[i];
	}

	Assert(FALSE);
	return -1;
}
