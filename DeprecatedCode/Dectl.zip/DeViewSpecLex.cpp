// DeViewSpecLex.cpp: implementation of the CDeViewSpecLex class.
//
//////////////////////////////////////////////////////////////////////

#include "main.h"

#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDeViewSpecLex::CDeViewSpecLex(HVO hvoLP)
:CDeViewSpec(hvoLP)
{

}

CDeViewSpecLex::~CDeViewSpecLex()
{

}



void CDeViewSpecLex::GetRootObjectClass(int *pclsid)
{
	AssertPtr(pclsid);
	*pclsid = kclidLexEntry;	
}

void CDeViewSpecLex::GetTags(int *ptagRootItems, int *ptagItemSort)
{		
	AssertPtr(ptagRootItems);
	AssertPtr(ptagItemSort);
	*ptagRootItems =kflidLexicalDatabase_Entries;//kflidRnResearchNotebook_Records;
	*ptagItemSort =kflidLexEntry_DateCreated; //kflidRnGenericRecord_DateCreated;
}

void CDeViewSpecLex::AddBlockSpecs(UserViewSpecPtr& quvs, DeDbInfoPtr& qdbi)
{
	DeLpInfo *plpi = (DeLpInfo*)qdbi->GetLpInfo(NULL);
	AssertPtr(plpi);
	int encVern = plpi->VernWs();
	int encAnal = plpi->AnalWs();
	
	// Level 0: Fields of a LexEntry
	
	{
		CRecordSpecMaker rsm(quvs, kclidLexEntry, 0);
		rsm.AddField(L"CitationForm",
			kflidLexEntry_CitationForm, // field in database
			encVern,
			kftMsa, // It is a simple string field
			kFTVisAlways, // It is always displayed (even if empty)
			kFTReqReq, // It is required (may not be empty in new records)
			konsNone,
			NULL, // not a list item
			L"Citation form", // help string
			L"Title Text"); // Display using this style (if defined)


		rsm.AddField(L"Allomorph",
				kflidLexEntry_Allomorphs, 
				0, // not a string
				kftSubItems, kFTVisIfData, 
				kFTReqNotReq, konsNumDot);

		rsm.AddField(L"MSI",
				kflidLexEntry_MorphoSyntaxInfo, 
				0, // not a string
				kftSubItems, kFTVisIfData, 
				kFTReqNotReq, konsNumDot);

		rsm.AddField(L"Sense",
				kflidLexEntry_Senses, 
				0, // not a string
				kftSubItems, kFTVisIfData, 
				kFTReqNotReq, konsNumDot);

		rsm.Finish(qdbi);

	}

	// Level 1: Fields of objects which are elements of a LexEntry

	{
		CRecordSpecMaker rsm(quvs, kclidMoStemAllomorph, 1);
		rsm.AddField(L"StemForm",
			kflidMoForm_Form,
			encVern,
			kftMsa, kFTVisAlways, kFTReqReq);
		rsm.AddField(L"morphtype",
			kflidMoForm_MorphType,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqReq);


		rsm.Finish(qdbi);
	}

	{
		CRecordSpecMaker rsm(quvs, kclidMoAffixAllomorph, 1);
		rsm.AddField(L"AffixForm",
			kflidMoForm_Form,
			encVern,
			kftMsa, kFTVisAlways, kFTReqReq);

		rsm.AddField(L"Morph Type",
			kflidMoForm_MorphType,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqReq);

		rsm.Finish(qdbi);
	}

	{
		CRecordSpecMaker rsm(quvs, kclidMoStemMsi, 1);
		rsm.AddField(L"Stem POS",
			kflidMoStemMsi_PartOfSpeech,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisIfData, kFTReqNotReq);
		rsm.Finish(qdbi);
	}
	//	InflectionalAffixMsi
	{
		CRecordSpecMaker rsm(quvs, kclidMoInflectionalAffixMsi, 1);
		rsm.AddField(L"Affix Cat",
			kflidMoInflectionalAffixMsi_AffixCategory,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqNotReq);
		rsm.Finish(qdbi);
	}


	//	DerivationalAffixMsi
	{
		CRecordSpecMaker rsm(quvs, kclidMoDerivationalAffixMsi, 1);
		rsm.AddField(L"Affix Cat",
			kflidMoDerivationalAffixMsi_AffixCategory,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqNotReq); 

		rsm.AddField(L"From POS",
			kflidMoDerivationalAffixMsi_FromPartOfSpeech,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqNotReq);

		rsm.AddField(L"To POS",
			kflidMoDerivationalAffixMsi_ToPartOfSpeech,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqNotReq);
		rsm.Finish(qdbi);
	}


	//	LexSense
	{
		CRecordSpecMaker rsm(quvs, kclidLexSense, 1);
		rsm.AddField(L"Gloss",
			kflidLexSense_Gloss,
			encAnal,
			kftMta, kFTVisAlways, kFTReqNotReq);

/*		rsm.AddField(L"MSI",
			kflidLexSense_MorphoSyntaxInfo,
			kftSubItems, kFTVisAlways, kFTReqNotReq);

*/
		rsm.AddField(L"MSI",
				kflidLexSense_MorphoSyntaxInfo, 
				encAnal,	// is that right?
				(FldType)kftAtomicRefNPI, kFTVisAlways, 
				kFTReqReq, konsNone);

		rsm.Finish(qdbi);
	}
	
	// Level 2: Fields like name of pos of msi

	//TODO none of this works yet!!!!!

	//TODO this is just a copy of msi code from level 1; refactor it!
	{
		CRecordSpecMaker rsm(quvs, kclidMoStemMsi, 2);
		rsm.AddField(L"StemMsi",
			kflidMoStemMsi_PartOfSpeech,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisIfData, kFTReqNotReq);
		rsm.Finish(qdbi);
	}

	//	InflectionalAffixMsi
	{
		CRecordSpecMaker rsm(quvs, kclidMoInflectionalAffixMsi, 2);
		rsm.AddField(L"InflAffixMsi",
			kflidMoInflectionalAffixMsi_AffixCategory,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqNotReq);
		rsm.Finish(qdbi);
	}


	//	DerivationalAffixMsi
	{
		CRecordSpecMaker rsm(quvs, kclidMoDerivationalAffixMsi, 2);
		rsm.AddField(L"DerivAffixMsi",
			kflidMoDerivationalAffixMsi_AffixCategory,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqNotReq); 

		rsm.AddField(L"FromPOS",
			kflidMoDerivationalAffixMsi_FromPartOfSpeech,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqNotReq);

		rsm.AddField(L"ToPOS",
			kflidMoDerivationalAffixMsi_ToPartOfSpeech,
			encAnal,	// is that right?
			kftRefAtomic, kFTVisAlways, kFTReqNotReq);
		rsm.Finish(qdbi);
	}

/*	{
		CRecordSpecMaker rsm(quvs, kclidPartOfSpeech, 2);
		rsm.AddField(L"POSabr",
			kflidCmPossibility_Abbreviation,
			encAnal,
			kftMta, kFTVisAlways, kFTReqReq);

		rsm.AddField(L"POSname",
			kflidCmPossibility_Name,
			encAnal,
			kftMta, kFTVisAlways, kFTReqReq);

		rsm.Finish(qdbi);
	}
*/

} 




void CDeViewSpecLex::FinishInit(DeDbInfoPtr qdbi)
{
	GetPossListIds(qdbi);
}

int CDeViewSpecLex::GetPossListForField(int flid)
{
	return m_imFieldsToPossLists.lookup(flid);
}

void CDeViewSpecLex::GetPossListIds(DeDbInfoPtr qdbi)
{ 
	RegisterPossList(qdbi, kflidMoStemMsi_PartOfSpeech,	//field
					L"LanguageProject_PartsOfSpeech",	//list
					L"LanguageProject");				//who owns the list
	
	RegisterPossList(qdbi, kflidMoForm_MorphType,		//field
					L"LexicalDatabase_MorphTypes",		//list
					L"LexicalDatabase");				//who owns the list

	RegisterPossList(qdbi, kflidMoDerivationalAffixMsi_AffixCategory,		//field
					L"LanguageProject_AffixCategories",		//list
					L"LanguageProject");				//who owns the list

		
	RegisterPossList(qdbi, kflidMoInflectionalAffixMsi_AffixCategory,		//field
					L"LanguageProject_AffixCategories",		//list
					L"LanguageProject");				//who owns the list

		
	RegisterPossList(qdbi, kflidMoDerivationalAffixMsi_FromPartOfSpeech,		//field
					L"LanguageProject_PartsOfSpeech",		//list
					L"LanguageProject");				//who owns the list


		RegisterPossList(qdbi, kflidMoDerivationalAffixMsi_ToPartOfSpeech,		//field
					L"LanguageProject_PartsOfSpeech",		//list
					L"LanguageProject");				//who owns the list
}

void CDeViewSpecLex::Init()
{

}


void CDeViewSpecLex::SetTreeHeader(CustViewDaPtr qvcd, HVO hvo, int flid, ITsString ** pptss,  DeLpInfo *plpi)
{
	AssertPtr(pptss);
	AssertPtr(plpi);
	ITsStrFactoryPtr qtsf;
	qtsf.CreateInstance(CLSID_TsStrFactory);
	switch(flid)
	{
	default:
		qtsf->MakeStringRgch(L"SMILE", 5, AfApp::UserWs(), pptss);
		break;
	case kflidLexEntry_Allomorphs:
		CheckHr(qvcd->get_MultiStringAlt(hvo, kflidMoForm_Form, plpi->VernWs(), pptss));
		break;

	case kflidLexEntry_Senses:
		CheckHr(qvcd->get_MultiStringAlt(hvo, kflidLexSense_Gloss, plpi->AnalWs(), pptss));
		break;


	case kflidLexEntry_MorphoSyntaxInfo:
		int clsid = 0;
		switch(clsid)
		{
			default: 
			qtsf->MakeStringRgch(L"Unknown MSI Type", 16, AfApp::UserWs(), pptss);
			break;

		}
		break;

	}
	AssertPtr(*pptss);
}