// DeViewSpec.cpp: implementation of the CDeViewSpec class.
//
//////////////////////////////////////////////////////////////////////

#include "main.h"

#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDeViewSpec::CDeViewSpec(HVO hvoLp)
:m_hvoLp(hvoLp)
{

}

CDeViewSpec::~CDeViewSpec()
{

}

//DEL void CDeViewSpec::GetLPConnectionInfo(BSTR* bstrDB, HVO* hvoLp)
//DEL {
//DEL 	AssertPtr(bstrDB);
//DEL 	AssertPtr(hvoLp);
//DEL 	*bstrDB = SysAllocString(L"TestLangProj");
//DEL 	*hvoLp = 1;
//DEL }

void CDeViewSpec::GetRootObjectClass(int *pclsid)
{
	AssertPtr(pclsid);
	*pclsid = kclidRnEvent;	
}

void CDeViewSpec::GetTags(int *ptagRootItems, int *ptagItemSort)
{		
	AssertPtr(ptagRootItems);
	AssertPtr(ptagItemSort);
	*ptagRootItems =kflidRnResearchNotebook_Records;
	*ptagItemSort =kflidRnGenericRecord_DateCreated;
}

/*----------------------------------------------------------------------------------------------
	
----------------------------------------------------------------------------------------------*/
void CDeViewSpec::AddBlockSpecs(UserViewSpecPtr& quvs, DeDbInfoPtr& qdbi)
{
	int eng = StrUtil::ParseWs("ENG");

	for(int iLev=0; iLev < 2; iLev++)
	{
		CRecordSpecMaker rsm(quvs, kclidRnEvent, iLev);
		rsm.AddField(L"Title",
			kflidRnGenericRecord_Title, // field in database
			eng,
			kftString, // It is a simple string field
			kFTVisAlways, // It is always displayed (even if empty)
			kFTReqReq, // It is required (may not be empty in new records)
			konsNone,
			NULL, // not a list item
			L"Help",
			L"Title Text"); // Display using this style (if defined)

		rsm.AddField(L"Description",
			kflidRnEvent_Description, // field in database
			eng, 
			kftStText, 
			kFTVisAlways, kFTReqReq);

		rsm.AddField(L"Type",
			kflidRnEvent_Type, // field in database
			eng, 
			kftRefAtomic,kFTVisAlways, kFTReqReq);

		if(iLev ==0)
		{
			rsm.AddField(L"Subentries",
				kflidRnGenericRecord_SubRecords, // field in database
				eng, 
				kftSubItems, kFTVisAlways, kFTReqNotReq );

			//qbsp->m_ons = konsNumDot; // Numbering style is relevant for subrecords
		}

		rsm.Finish(qdbi);
	}
/*}

void CDeViewSpec::AddBlockSpecs(RecordSpecPtr qrsp, int iLev)
{


		AssertPtr(qrsp);
	
	ITsStrFactoryPtr qtsf;
	qtsf.CreateInstance(CLSID_TsStrFactory);

	// Labels are made in some writing system. Arbitrarily use English for this demo.
	int ws = StrUtil::ParseWs("ENG");

	ITsStringPtr qtssLabel; // used for label of each field.
	ITsStringPtr qtssHelp; // used for label of each field.
	BlockSpecPtr qbsp;
	// Add a sequence of field specs to define how to load and display
	// this kind of object at this level.
	// Each of the following blocks adds one field.
	// Note: in real life the label and help strings should come from a resource
	// file. We haven't figured out the best way to do this in a control yet.

	CheckHr(qtsf->MakeStringRgch(L"Title", wcslen(L"Title"), ws, &qtssLabel));
	CheckHr(qtsf->MakeStringRgch(L"Help", wcslen(L"Help!"), ws, &qtssHelp));
	qbsp.Attach(NewObj BlockSpec(qtssLabel, // string for tree/outline
		qtssHelp, // help string
		kflidRnGenericRecord_Title, // field in database
		kftString, // It is a simple string field
		kFTVisAlways, // It is always displayed (even if empty)
		kFTReqReq, // It is required (may not be empty in new records)
		L"Title Text")); // Display using this style (if defined)
	qrsp->m_vqbsp.Push(qbsp);
				
	CheckHr(qtsf->MakeStringRgch(L"Description", wcslen(L"Description"), ws, &qtssLabel));
	qbsp.Attach(NewObj BlockSpec(qtssLabel,
		qtssHelp,
		kflidRnEvent_Description,
		kftStText, kFTVisAlways, kFTReqReq));
	qrsp->m_vqbsp.Push(qbsp);

				
	CheckHr(qtsf->MakeStringRgch(L"Type", wcslen(L"Type"), ws, &qtssLabel));
	qbsp.Attach(NewObj BlockSpec(qtssLabel,
		qtssHelp,
		kflidRnEvent_Type,
		kftRefAtomic, kFTVisAlways, kFTReqReq));
	qrsp->m_vqbsp.Push(qbsp);
	
	if(iLev ==0)
	{
		CheckHr(qtsf->MakeStringRgch(L"Subentries", wcslen(L"Subentries"), ws, &qtssLabel));
		qbsp.Attach(NewObj BlockSpec(qtssLabel, 
			qtssHelp,
			kflidRnGenericRecord_SubRecords, kftSubItems, kFTVisAlways, kFTReqNotReq));
		qbsp->m_ons = konsNumDot; // Numbering style is relevant for subrecords
		qrsp->m_vqbsp.Push(qbsp);
	}
	*/
}


void CDeViewSpec::FinishInit(DeDbInfoPtr qdbi)
{
	GetPossListIds(qdbi);
}

int CDeViewSpec::GetPossListForField(int flid)
{
	return m_imFieldsToPossLists.lookup(flid);
}

void CDeViewSpec::GetPossListIds(DeDbInfoPtr qdbi)
{
//	const int kFIXTHIS_hvo_lp=1;	// FIX THIS!!!!!!

	IOleDbEncapPtr qode;
	//  Obtain pointer to IOleDbEncap interface and execute the given SQL select command.
	AssertPtr(qdbi);
	qdbi->GetDbAccess(&qode);

	// for each possibility list we need to handle
	// for( )
/*	{
		//make a mapping between the field and the possibilities list

		SmartBstr bstrList =  L"RnResearchNotebook_EventTypes";
		SmartBstr bstrOwner = L"LanguageProject_ResearchNotebook";
		StrUni stuQuery;
		
		// create the sql statement
		MakePossListQuery(bstrList, bstrOwner, kFIXTHIS_hvo_lp, &stuQuery);
		
		// query the db
		int iPsslId=GetIntFromQuery(qode, stuQuery);

		// save that in our map
		m_imFieldsToPossLists.add(kflidRnEvent_Type, iPsslId); 
	}
*/
	RegisterPossList(qdbi, kflidRnEvent_Type,	//field
					L"RnResearchNotebook_EventTypes",	//list
					L"RnResearchNotebook");				//who owns the list
	
	//test
//	int y = m_imFieldsToPossLists.lookup(kflidRnEvent_Type);
//	Assert(y==1679);
}

void CDeViewSpec::Init()
{

}

int CDeViewSpec::GetIntFromQuery(IOleDbEncapPtr qode, StrUni stuQuery)
{
	IOleDbCommandPtr qodc;
	try
	{
		CheckHr(qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stuQuery.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
	} catch (...)
	{
			Assert(FALSE);
	}
	ComBool fMoreRows;
	CheckHr(qodc->NextRow(&fMoreRows));
	int iResult=0;
	
	if (fMoreRows)
	{ 
		ComBool fIsNull;
		ULONG cbSpaceTaken;

		CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&iResult),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));

		return iResult;
	}
	throw __LINE__;
	return -1;
}

// todo should be possible to make a generalize version of this query that would
// work with any owner/list combination
void CDeViewSpec::MakePossListQuery(SmartBstr &bstrListName, SmartBstr &bstrOwnerName, int iLangProj, StrUni *pstu)
{
	if(bstrOwnerName==L"LanguageProject" ||
		bstrOwnerName==L"")
	{
		pstu->Format(L"select possList.dst possList"
					L" from LanguageProject lp (readuncommitted) "
					L" left outer join %s possList (readuncommitted) on possList.src = lp.id "
					L" where lp.id = %d",  bstrListName.Chars(), iLangProj);
	}
	
	else	// owned by an object which is owned by LangProj
	{
		pstu->Format(L"select x.dst from %s x (readuncommitted) "
					 L" left outer join %s_ y (readuncommitted) on y.id = x.src "
					 L" left outer join LanguageProject lp (readuncommitted) on y.Owner$ = lp.id "
					 L" where lp.id = %d",bstrListName.Chars(), bstrOwnerName.Chars(), iLangProj);
	}

	//	NOTE WE DON'T CURRENTLY HANDLE CASE WHERE OWNING OBJ IS NOT ITSELF OWNED BY THE LP DIRECTLY!
}

void CDeViewSpec::RegisterPossList(DeDbInfoPtr qdbi, long kflid, LPCOLESTR  pszListName, LPCOLESTR  pszListOwnerName)
{
	IOleDbEncapPtr qode;
	//  Obtain pointer to IOleDbEncap interface and execute the given SQL select command.
	AssertPtr(qdbi);
	qdbi->GetDbAccess(&qode);

	//make a mapping between the field and the possibilities list

	SmartBstr bstrList =  pszListName;
	SmartBstr bstrOwner = pszListOwnerName;
	StrUni stuQuery;
	
	// create the sql statement
	MakePossListQuery(bstrList, bstrOwner, m_hvoLp, &stuQuery);
	
	// query the db
	int iPsslId=GetIntFromQuery(qode, stuQuery);

	Assert(iPsslId > 0); // if this fails, check stuQuery against the database

 	// save that in our map
	m_imFieldsToPossLists.add(kflid, iPsslId);
}

void CDeViewSpec::SetTreeHeader(CustViewDaPtr qvcd, HVO hvo, int flid, ITsString ** pptss, DeLpInfo *plpi)
{ 
	AssertPtr(pptss);
	ITsStrFactoryPtr qtsf;
	qtsf.CreateInstance(CLSID_TsStrFactory);

	switch (flid)
	{
	case kflidRnGenericRecord_SubRecords:
		CheckHr(qvcd->get_StringProp(hvo, kflidRnGenericRecord_Title, pptss));
		break;

	default:
		CheckHr(qtsf->MakeStringRgch(L"SMILE", 5, AfApp::UserWs(), pptss));
		break;
	}
	AssertPtr(*pptss);
}
