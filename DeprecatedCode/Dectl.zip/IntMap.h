// IntMap.h: interface for the IntMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTMAP_H__D4CBE30A_AD59_48EB_B3B6_A7B9720D0C37__INCLUDED_)
#define AFX_INTMAP_H__D4CBE30A_AD59_48EB_B3B6_A7B9720D0C37__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class IntMap  
{
public:
	int lookup(int iKey) const;
	void add(int iKey, int iValue);
	IntMap(){}
	virtual ~IntMap() {}
protected:
	Vector<int> m_vkeys;
	Vector<int> m_vvalues;
};

#endif // !defined(AFX_INTMAP_H__D4CBE30A_AD59_48EB_B3B6_A7B9720D0C37__INCLUDED_)
