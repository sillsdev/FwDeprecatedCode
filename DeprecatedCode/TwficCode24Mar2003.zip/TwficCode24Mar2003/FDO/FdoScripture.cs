// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FdoScripture.cs
// Responsibility: TomB
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using SIL.FieldWorks.FDO.Scripture.Generated;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.Utils;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using FwCellar;

namespace SIL.FieldWorks.FDO.Scripture
{
	#region class ScriptureChangeWatcher
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// The ScriptureChangeWatcher class receives notifications of paragraph edits and implements
	/// the desired side effects of re-parsing the paragraph for wordforms.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	public class ScriptureChangeWatcher : ChangeWatcher
	{
		#region Data members
		/// <summary>
		/// The Scripture object that handles parsing when a paragraph changes
		/// </summary>
		protected Scripture m_Scripture;
		#endregion

		#region Construction

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// This is the publicly accessible way to create a ScriptureChangeWatcher. Upon
		/// construction, the change watcher automatically registers itself and assumes a life
		/// of its own, so nothing is returned to the caller.
		/// </summary>
		/// <param name="scripture">The Scripture object from which we get the DB access info
		/// </param>
		/// ------------------------------------------------------------------------------------
		public static void Create(Scripture scripture)
		{
			Debug.Assert(scripture != null);
			Debug.Assert(scripture.Cache != null);
			if (scripture.Cache.ChangeWatchers != null)
			{
				foreach (ChangeWatcher cw in scripture.Cache.ChangeWatchers)
				{
					if (cw is ScriptureChangeWatcher)
						return; // Only one of these allowed per DB connection
				}
			}
			// No need to assign this to a member variable because the change watcher registers
			// itself (and thereby takes on a life of its own).
			new ScriptureChangeWatcher(scripture);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="scripture">The Scripture object from which we get the DB access info
		/// </param>
		/// ------------------------------------------------------------------------------------
		protected ScriptureChangeWatcher(Scripture scripture) :
			base(scripture.Cache, (int)BaseStTxtPara.StTxtParaTags.kflidContents)
		{
			m_Scripture = scripture;
		}
		#endregion

		#region DoEffectsOfPropChanged Method
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Calls ParseStTxtPara to carry out the desired side effects: re-parsing the paragraph
		/// for wordforms, ???.
		/// </summary>
		/// <param name="hvoPara">The Paragraph that was changed</param>
		/// <param name="ivMin">the starting character index where the change occurred</param>
		/// <param name="cvIns">the number of characters inserted</param>
		/// <param name="cvDel">the number of characters deleted</param>
		/// ------------------------------------------------------------------------------------
		protected override void DoEffectsOfPropChange(int hvoPara, int ivMin, int cvIns, int cvDel)
		{
			// ENHANCE (BryanW): check that the owner of the paragraph is Scripture, if our CustViewDa
			// is ever used to modify non-scripture paragraphs

			ScrTxtPara para = new ScrTxtPara(m_Scripture.Cache, hvoPara);
			para.ParseStTxtPara(ivMin, cvIns, cvDel);

			// More to do here???
		}

		#endregion
	}
	#endregion

	#region class Scripture
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Scripture represents a vernacular translation (one per language project).
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	public class Scripture : BaseScripture
	{
		#region Data Members
		#endregion

		#region Construction and Initialization
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Used for code like this foo.blah = new Scripture().
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public Scripture() :base()
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Constructor that creates a Scripture object based on an HVO in the database.
		/// </summary>
		/// <param name="fcCache">Represents DB connection</param>
		/// <param name="hvo">Id of the Scripture object in the DB</param>
		/// ------------------------------------------------------------------------------------
		public Scripture(FdoCache fcCache, int hvo) :base(fcCache, hvo)
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes ChangeWatcher
		/// </summary>
		/// ------------------------------------------------------------------------------------		
		public void Init()
		{
			ScriptureChangeWatcher.Create(this);
		}
		#endregion

		#region Scripture Properties

		/// <summary>
		/// The FDO cache representing the DB connection
		/// </summary>
		protected internal FdoCache Cache
		{
			get
			{
				return m_cache;
			}
		}

		// REVIEW TomB: Do we want the default values for the following four properties to come
		// from a resource file so they can be localized?

		/// <summary>
		/// A string (usually one character) that separates complete	references or
		/// chapter/verse references in a list. In the U.S.A., this is traditionally a
		/// semi-colon (;), e.g., Mat 24:16; Rev 1:2;4:5.
		/// </summary>
		public new string RefSepr
		{
			get
			{		
				string s = base.RefSepr;
				if (s == null)
				{
					s = ";";
					base.RefSepr = s;
				}
				return s;
			}
			set
			{
				base.RefSepr = value;
			}
		}
				

		/// <summary>
		/// A string (usually one character) that separates the chapter number from the verse
		/// number in a reference. In the U.S.A., this is a traditionally colon (:),
		/// e.g., Mat 24:16.
		/// </summary>
		public new string ChapterVerseSepr
		{
			get
			{		
				string s = base.ChapterVerseSepr;
				if (s == null)
				{
					s = ":";
					base.ChapterVerseSepr = s;
				}
				return s;
			}
			set
			{
				base.ChapterVerseSepr = value;
			}
		}
			
		/// <summary>
		/// A string (usually one character) that separates non-contiguous verse numbers in a
		/// list. In the U.S.A., this is traditionally a comma (,), e.g., Mat 24:16,25.
		/// </summary>
		public new string VerseSepr
		{
			get
			{		
				string s = base.VerseSepr;
				if (s == null)
				{
					s = ",";
					base.VerseSepr = s;
				}
				return s;
			}
			set
			{
				base.VerseSepr = value;
			}
		}
				
		/// <summary>
		/// A string (usually one character) that bridges contiguous chapter and/or verse ranges
		/// in a reference. In the U.S.A., this is traditionally a dash (-), e.g., Mat 24:16-25;
		/// Rev 1:7-2:9.
		/// </summary>
		public new string Bridge
		{
			get
			{
				string s = base.Bridge;
				if (s == null)
				{
					s = "-";
					base.Bridge = s;
				}
				return s;
			}
			set
			{
				base.Bridge = value;
			}
		}
		#endregion
	}
	#endregion
}
