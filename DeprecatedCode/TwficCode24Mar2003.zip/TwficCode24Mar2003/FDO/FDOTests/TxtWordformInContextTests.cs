// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: TxtWordformInContextTests.cs
// Responsibility: BryanW
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Data.SqlClient;
using System.Collections;
using NUnit.Framework;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.FDO.Scripture;
using SIL.FieldWorks.FDO.Scripture.Generated;
using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.FDO.FDOTests
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Test the TxtWordformInContextTests class.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public class TxtWordformInContextTests: FdoTestBase
	{
		private BCVRef Phm_1_17 = new BCVRef(57, 1, 17);
		private BCVRef Phm_1_18 = new BCVRef(57, 1, 18);
		private BCVRef Phm_1_19 = new BCVRef(57, 1, 19);

		// HVOs in TestLangProj used for testing
		// HVO 5540 is Phm 1:17-21
		private int m_hvoPhm_17_21 = 5540;
		private int m_hvoPhm_22_25 = 5659;
		private int m_hvoPhm_8_16 = 5338;
		private int m_hvoPhmLastIntroPara = 5159;

		/// <summary>The paragraph we use for testing</summary>
		private ScrTxtPara m_para;

		private SqlConnection m_sqlConMaster;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="TxtWordformInContextTests"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public TxtWordformInContextTests()
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Load the object <paramref name="hvo"/> and all its parent objects into the cache.
		/// </summary>
		/// <param name="hvoStTxtPara">The HVO for a <see cref="ScrTxtPara"/> paragraph.</param>
		/// ------------------------------------------------------------------------------------
		private ScrTxtPara LoadIntoCache(int hvoStTxtPara)
		{
			ScrTxtPara txtpara = new ScrTxtPara(m_fdoCache, hvoStTxtPara);
			StText text = new StText(m_fdoCache, txtpara.ownerHVO);
			ScrSection section = new ScrSection(m_fdoCache, text.ownerHVO);

			// the next line initializes static variables in TxtWordformInContext.
			Scripture.Scripture scripture = new Scripture.Scripture(m_fdoCache, 
				m_fdoCache.LanguageProject.TranslatedScriptureOAHvo);

			return txtpara;
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Make sure that StTxtPara with HVO 5540 is loaded in the cache.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[SetUp]
		public override void Initialize()
		{
			base.Initialize();

			m_sqlConMaster = new SqlConnection(string.Format("Server={0}; Database={1};" +
				"User ID = sa; Password=inscrutable;Connect Timeout = 2;", 
				m_fdoCache.ServerName, m_fdoCache.DatabaseName));
			m_sqlConMaster.Open();

			SqlCommand sqlComm = m_sqlConMaster.CreateCommand();
			string sSql = @"select MIN(Owner$) from TxtWordformInContext_ (readuncommitted)
				where VerseRefStart = 57001017";
			sqlComm.CommandText = sSql;
			SqlDataReader sqlreader =
				sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			if (sqlreader.Read())
			{
				m_hvoPhm_17_21 = sqlreader.GetInt32(0);
			}
			sqlreader.Close();

			m_para = LoadIntoCache(m_hvoPhm_17_21);

			sSql = @"select MIN(Owner$) from TxtWordformInContext_ (readuncommitted)
				where VerseRefStart = 57001022";
			sqlComm.CommandText = sSql;
			sqlreader = sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			if (sqlreader.Read())
			{
				m_hvoPhm_22_25 = sqlreader.GetInt32(0);
			}
			sqlreader.Close();

			sSql = @"select MIN(Owner$) from TxtWordformInContext_ (readuncommitted)
				where VerseRefStart = 57001016";
			sqlComm.CommandText = sSql;
			sqlreader = sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			if (sqlreader.Read())
			{
				m_hvoPhm_8_16 = sqlreader.GetInt32(0);
			}
			sqlreader.Close();

			sSql = @"select MAX(Owner$) from TxtWordformInContext_ (readuncommitted)
				where VerseRefStart = 57001000 and ParaCharOffset > 100";
			sqlComm.CommandText = sSql;
			sqlreader = sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			if (sqlreader.Read())
			{
				m_hvoPhmLastIntroPara = sqlreader.GetInt32(0);
			}
			sqlreader.Close();
		}

		[TearDown]
		public override void Exit()
		{
			base.Exit();

			m_sqlConMaster.Close();
			m_sqlConMaster = null;
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test adding a TxtWordformInContext
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void AddWordformInContextTest()
		{
			BCVRef startRef = new BCVRef(1,1,1);
			BCVRef endRef = new BCVRef(9,9,9);
			TxtWordformInContext twfic = null;

			// Test inserting TWFIC somewhere in the middle of the vector. Make sure
			// that cache gets updated.
			TxtWordformInContext twfic100 = 
				(TxtWordformInContext)m_para.AnalyzedTextObjectsOS[99];

			TxtWordformInContext.AddWordformInContext(m_fdoCache.LanguageProject, "AddWordformInContextTest", 
				m_hvoPhm_17_21, 3333, startRef, endRef, 99, false, false);

			FdoOwningSequence analyzedTextObjects = m_para.AnalyzedTextObjectsOS;
			int i = 0;
			foreach(TxtWordformInContext twficTmp in analyzedTextObjects)
			{
				i++;
				if (twficTmp.ParaCharOffset == 3333)
				{ // found our dummy twfic
					twfic = twficTmp;
					break;
				}
			}

			TxtWordformInContext newTwfic100 = 
				(TxtWordformInContext)m_para.AnalyzedTextObjectsOS[99];
			TxtWordformInContext newTwfic101 = 
				(TxtWordformInContext)m_para.AnalyzedTextObjectsOS[100];

			Assertion.AssertNotNull(twfic);
			Assertion.AssertEquals(100, i);
			Assertion.AssertEquals("AddWordformInContextTest", twfic.Form.Text);
			Assertion.AssertEquals(m_hvoPhm_17_21, twfic.ownerHVO);
			Assertion.AssertEquals(3333, twfic.ParaCharOffset);
			Assertion.AssertEquals(0, twfic.SoundFileBeginOffset);
			Assertion.AssertEquals(startRef, twfic.VerseRefStart);
			Assertion.AssertEquals(endRef, twfic.VerseRefEnd);
			// we added twific 100
			Assertion.AssertEquals(newTwfic100.hvo, twfic.hvo);
			// original twific 100 was moved to 101
			Assertion.AssertEquals(twfic100.hvo, newTwfic101.hvo);

			// Test inserting TWFIC at the end of the vector. Cache should be updated.
			int cTwfics = m_para.AnalyzedTextObjectsOS.Count;
			TxtWordformInContext twficN =
				(TxtWordformInContext)m_para.AnalyzedTextObjectsOS[cTwfics - 1];

			TxtWordformInContext.AddWordformInContext(m_fdoCache.LanguageProject, "AddWordformInContextTest2",
				m_hvoPhm_17_21, 4444, startRef, endRef, cTwfics, true, false);

			Assertion.AssertEquals(cTwfics + 1, m_para.AnalyzedTextObjectsOS.Count);
			TxtWordformInContext newTwficNMinus1 = 
				(TxtWordformInContext)m_para.AnalyzedTextObjectsOS[cTwfics - 1];
			twfic = (TxtWordformInContext)m_para.AnalyzedTextObjectsOS[cTwfics];

			Assertion.AssertNotNull(twfic);
			Assertion.AssertEquals("AddWordformInContextTest2", twfic.Form.Text);
			Assertion.AssertEquals(m_hvoPhm_17_21, twfic.ownerHVO);
			Assertion.AssertEquals(4444, twfic.ParaCharOffset);
			Assertion.AssertEquals(0, twfic.SoundFileBeginOffset);
			Assertion.AssertEquals(startRef, twfic.VerseRefStart);
			Assertion.AssertEquals(endRef, twfic.VerseRefEnd);
			// we added a new twific N
			Assertion.Assert(twficN.hvo != twfic.hvo);
			// original twific N was moved to N-1
			Assertion.AssertEquals(twficN.hvo, newTwficNMinus1.hvo);
			// this test passes because we manipulate the cache. In the database, however
			// the new twific N was inserted as N-1!
			SqlCommand sqlComm = m_sqlConMaster.CreateCommand();
			string sSql = string.Format(@"select ParaCharOffset from TxtWordformInContext_
				(readuncommitted) where Owner$ = {0} and OwnOrd$ = (select Max(OwnOrd$)
				from TxtWordformInContext_ (readuncommitted) where Owner$ = {0})", m_para.hvo);
			sqlComm.CommandText = sSql;
			SqlDataReader sqlreader =
				sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			int paraOffset = 0;
			if (sqlreader.Read())
			{
				paraOffset = sqlreader.GetInt32(0);
			}
			sqlreader.Close();
			Assertion.AssertEquals(4444, paraOffset);

			// Test inserting TWFIC somewhere in the middle of the vector. No cache update.
			TxtWordformInContext twfic50 = 
				(TxtWordformInContext)m_para.AnalyzedTextObjectsOS[49];

			cTwfics = m_para.AnalyzedTextObjectsOS.Count;

			TxtWordformInContext.AddWordformInContext(m_fdoCache.LanguageProject, "AddWordformInContextTest3", 
				m_hvoPhm_17_21, 5555, startRef, endRef, 49, false, true);

			Assertion.AssertEquals(cTwfics, m_para.AnalyzedTextObjectsOS.Count);

			sqlComm = m_sqlConMaster.CreateCommand();
			sSql = string.Format(@"select count(*) from TxtWordformInContext_ 
				(readuncommitted) where Owner$ = {0}", m_para.hvo);
			sqlComm.CommandText = sSql;
			sqlreader = sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			int cTwficsDb = 0;
			if (sqlreader.Read())
			{
				cTwficsDb = sqlreader.GetInt32(0);
			}
			sqlreader.Close();
			Assertion.AssertEquals(cTwfics + 1, cTwficsDb);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test inserting TWFIC at the end of the vector after removing some twfics in the
		/// middle.
		/// </summary>
		/// <remarks>
		/// Need to fix this in one of the following ways:
		/// 1) remove optimization to assume that the max OwnOrd$ == the number of twfics
		/// 2) Make twfics into an unordered collection instead of an explicit sequence, and use
		///    ParaCharOffset to implement ordering
		/// 3) Use OwnOrd$ to store character offset, and remove ParaCharOffset.
		/// 4) Store and retrieve the max OwnOrd$ value for each paragraph's twfics
		/// 5) Pass the hvo of the object to insert after and let the s'proc retrieve it's
		///    OwnOrd$ value, incrment it, and insert the new twfic.
		/// </remarks>
		/// ------------------------------------------------------------------------------------
		[Test] [Ignore("Test fails AddWordformInContext assumes that OwnOrd$ is contiguous")]
		public void InsertTwficAtEndAfterEdit()
		{
			BCVRef startRef = new BCVRef(2, 2, 2);
			BCVRef endRef = new BCVRef(8, 8, 8);

			TxtWordformInContext twficN = null;
			// The TxtWordformInContext enumerator reads directly from the database
			foreach (TxtWordformInContext twficTmp in m_para.AnalyzedTextObjectsOS)
				twficN = twficTmp;

			// Remove some twfics to make "holes" in the OwnOrd$ sequence.
			TxtWordformInContext.RemoveEditedAnalyzedTextObjects(m_para, 30, 0, 20);

			// Add a new twfic at the end.
			TxtWordformInContext.AddWordformInContext(m_fdoCache.LanguageProject, "InsertTwficAtEndAfterEdit",
				m_hvoPhm_17_21, 6666, startRef, endRef, m_para.AnalyzedTextObjectsOS.Count,
				true, false);

			TxtWordformInContext newTwficNminus1 = null;
			TxtWordformInContext newTwficN = null;

			// The TxtWordformInContext enumerator reads directly from the database
			// The next line fails, because we now have doubled OwnOrd$s
			foreach (TxtWordformInContext twficTmp in m_para.AnalyzedTextObjectsOS)
			{
				newTwficNminus1 = newTwficN;
				newTwficN = twficTmp;
			}

			// we added a new twific N
			Assertion.Assert(twficN.hvo != newTwficN.hvo);
			// original twific N was moved to N-1
			Assertion.AssertEquals(twficN.hvo, newTwficNminus1.hvo);

			SqlCommand sqlComm = m_sqlConMaster.CreateCommand();
			string sSql = string.Format(@"select ParaCharOffset from TxtWordformInContext_
				(readuncommitted) where Owner$ = {0} and OwnOrd$ = (select Max(OwnOrd$)
				from TxtWordformInContext_ (readuncommitted) where Owner$ = {0})", m_para.hvo);
			sqlComm.CommandText = sSql;
			SqlDataReader sqlreader =
				sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			int paraOffset = 0;
			if (sqlreader.Read())
			{
				paraOffset = sqlreader.GetInt32(0);
			}
			sqlreader.Close();
			Assertion.AssertEquals(6666, paraOffset);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test that GetNextScrTwficInText method gets the right TWFIC and returns the right
		/// values.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void GetNextScrTwficInText()
		{
			// Simulate editing the first word in a verse
			int hvoParaForNextTwfic, ichParaCharOffset, nScrRefStartTwfic, nScrRefEndTwfic;
			bool fRet = TxtWordformInContext.GetNextScrTwficInText(m_para, 2,
				out hvoParaForNextTwfic, out ichParaCharOffset, out nScrRefStartTwfic,
				out nScrRefEndTwfic);
			Assertion.AssertEquals(true, fRet);
			Assertion.AssertEquals(m_hvoPhm_17_21, hvoParaForNextTwfic);
			Assertion.AssertEquals(5, ichParaCharOffset);
			Assertion.AssertEquals(57001017, nScrRefStartTwfic);
			Assertion.AssertEquals(57001017, nScrRefEndTwfic);

			// Simulate a twfic whose reference represents a verse bridge (this sets up
			// for the next "real" test)
			TxtWordformInContext twficWithBridge =
				(TxtWordformInContext)m_para.AnalyzedTextObjectsOS[18];
			Assertion.AssertEquals("make sure DB is in expected state",
				82, twficWithBridge.ParaCharOffset);
			twficWithBridge.VerseRefEnd = 57001020;
			// Simulate editing the last word in a verse which is followed by a (simulated)
			// verse bridge.
			fRet = TxtWordformInContext.GetNextScrTwficInText(m_para, 77,
				out hvoParaForNextTwfic, out ichParaCharOffset, out nScrRefStartTwfic,
				out nScrRefEndTwfic);
			Assertion.AssertEquals(true, fRet);
			Assertion.AssertEquals(m_hvoPhm_17_21, hvoParaForNextTwfic);
			Assertion.AssertEquals(82, ichParaCharOffset);
			Assertion.AssertEquals(57001018, nScrRefStartTwfic);
			Assertion.AssertEquals(57001020, nScrRefEndTwfic);

			// Simulate editing the last word in a paragraph
			fRet = TxtWordformInContext.GetNextScrTwficInText(m_para, 532,
				out hvoParaForNextTwfic, out ichParaCharOffset, out nScrRefStartTwfic,
				out nScrRefEndTwfic);
			Assertion.AssertEquals(true, fRet);
			Assertion.AssertEquals(m_hvoPhm_22_25, hvoParaForNextTwfic);
			Assertion.AssertEquals(2, ichParaCharOffset);
			Assertion.AssertEquals(57001022, nScrRefStartTwfic);
			Assertion.AssertEquals(57001022, nScrRefEndTwfic);

			// Simulate editing the last word in the last section of a book
			ScrTxtPara paraLastInSection = LoadIntoCache(m_hvoPhm_22_25);
			fRet = TxtWordformInContext.GetNextScrTwficInText(paraLastInSection, 275,
				out hvoParaForNextTwfic, out ichParaCharOffset, out nScrRefStartTwfic,
				out nScrRefEndTwfic);
			Assertion.AssertEquals(false, fRet);

			// Simulate editing the last intro paragraph. GetNextScrTwficInText should not
			// find a TWFIC because the "next" paragraph is in a different section.
			ScrTxtPara paraLastInIntro = LoadIntoCache(m_hvoPhmLastIntroPara);
			fRet = TxtWordformInContext.GetNextScrTwficInText(paraLastInIntro, 195,
				out hvoParaForNextTwfic, out ichParaCharOffset, out nScrRefStartTwfic,
				out nScrRefEndTwfic);
			Assertion.AssertEquals(false, fRet);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Adjust the reference. If we want to compare book, chapter and verse, simply return
		/// the original value, otherwise set the verse number to 0.
		/// </summary>
		/// <param name="origRef">Reference</param>
		/// <param name="fCheckVerse"><c>true</c> to check book, chapter and verse, otherwise
		/// check only book and verse.</param>
		/// <returns>Adjusted reference</returns>
		/// ------------------------------------------------------------------------------------
		private int AdjustReference(int origRef, bool fCheckVerse)
		{
			if (fCheckVerse)
				return origRef;
			else
				return origRef / 1000 * 1000;
		}
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Assert that the twfics really got updated.
		/// </summary>
		/// <param name="ichStart">Starting ParaCharOffset</param>
		/// <param name="ichLim">Ending ParaCharOffset (not included)</param>
		/// <param name="startRef">Expected start reference</param>
		/// <param name="endRef">Expected end reference</param>
		/// <param name="twfics">FDO vector with twfics to test</param>
		/// <param name="fCheckVerse"><c>true</c> if we should check book, chapter and verse,
		/// <c>false</c> to check book and chapter only.</param>
		/// ------------------------------------------------------------------------------------
		private void AssertUpdatedTwfics(int ichStart, int ichLim, BCVRef startRef, 
			BCVRef endRef, FdoOwningSequence twfics, bool fCheckVerse)
		{
			BCVRef newStartRef = new BCVRef(AdjustReference(startRef, fCheckVerse));
			BCVRef newEndRef = new BCVRef(AdjustReference(endRef, fCheckVerse));

			// test the twfics in the cache
			foreach (int hvo in twfics.hvoArray)
			{
				bool fInCache;
				int nParaCharOffset = m_fdoCache.VwCacheDaAccessor.get_CachedIntProp(hvo, 
					(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidParaCharOffset,
					out fInCache);
				if (fInCache && nParaCharOffset >= ichStart && nParaCharOffset < ichLim)
				{
					int nRefStart = m_fdoCache.VwCacheDaAccessor.get_CachedIntProp(hvo, 
						(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidVerseRefStart,
						out fInCache);
					if (fInCache)
					{
						Assertion.AssertEquals(string.Format(
							"Wrong cached start reference for twfic {0}", hvo), 
							newStartRef, AdjustReference(nRefStart, fCheckVerse));
					}
					int nRefEnd = m_fdoCache.VwCacheDaAccessor.get_CachedIntProp(hvo, 
						(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidVerseRefEnd,
						out fInCache);
					if (fInCache)
					{
						Assertion.AssertEquals(string.Format(
							"Wrong cached end reference for twfic {0}", hvo), 
							newEndRef, AdjustReference(nRefEnd, fCheckVerse));
					}
				}
			}

			// test the twfics in the database
			foreach (TxtWordformInContext twfic in twfics)
			{
				if (twfic.ParaCharOffset >= ichStart && twfic.ParaCharOffset < ichLim)
				{
					Assertion.AssertEquals(string.Format("Wrong start reference for twfic {0}", 
						twfic.hvo), newStartRef, 
						AdjustReference(twfic.VerseRefStart, fCheckVerse));
					Assertion.AssertEquals(string.Format("Wrong end reference for twfic {0}", 
						twfic.hvo), newEndRef, AdjustReference(twfic.VerseRefEnd, fCheckVerse));
				}
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test updating the references in TWFICs.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void UpdateTwficScrRefs()
		{
			BCVRef refStart = new BCVRef(1, 1, 1);
			BCVRef refEnd = new BCVRef(1, 2, 2);

			// Test V & C stamping inside of a paragraph
			TxtWordformInContext.UpdateTwficScrRefs(m_fdoCache, refStart, refEnd, m_para.hvo, 
				400, m_para.hvo, 450, 0, 0);
			AssertUpdatedTwfics(400, 450, refStart, refEnd, m_para.AnalyzedTextObjectsOS, true);

			// Test V & C stamping across paragraphs
			TxtWordformInContext.UpdateTwficScrRefs(m_fdoCache, refStart, refEnd, m_para.hvo, 
				510, m_hvoPhm_22_25, 10, 0, 0);
			AssertUpdatedTwfics(510, 700, refStart, refEnd, m_para.AnalyzedTextObjectsOS, true);
			ScrTxtPara para = LoadIntoCache(m_hvoPhm_22_25);
			AssertUpdatedTwfics(0, 10, refStart, refEnd, para.AnalyzedTextObjectsOS, true);

			// Test C stamping inside of a paragraph
			TxtWordformInContext.UpdateTwficScrRefs(m_fdoCache, refStart, refEnd, m_para.hvo, 
				300, 0, 0, m_para.hvo, 321);
			AssertUpdatedTwfics(300, 321, refStart, refEnd, m_para.AnalyzedTextObjectsOS, false);

			// Test C stamping across paragraphs
			TxtWordformInContext.UpdateTwficScrRefs(m_fdoCache, refStart, refEnd, m_hvoPhm_8_16, 
				983, 0, 0, m_para.hvo, 5);
			para = LoadIntoCache(m_hvoPhm_8_16);
			AssertUpdatedTwfics(983, 1000, refStart, refEnd, para.AnalyzedTextObjectsOS, false);
			AssertUpdatedTwfics(0, 5, refStart, refEnd, m_para.AnalyzedTextObjectsOS, false);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Tests getting the range of changed TWFICS.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void GetRgChangedTwfics()
		{
			int ihvoMin;
			int ihvoLim;
			TxtWordformInContext.GetRgChangedTwfics(m_para, 40, 22, out ihvoMin, out ihvoLim);

			int ihvoMinExp = 0;
			int ihvoLimExp = 0;
			int i = 0;
			foreach(TxtWordformInContext twfic in m_para.AnalyzedTextObjectsOS)
			{
				if (twfic.ParaCharOffset >= 40)
				{
					if (ihvoMinExp == 0)
						ihvoMinExp = i;
					else if (twfic.ParaCharOffset <= 64)
						ihvoLimExp = i;
					else if (twfic.ParaCharOffset > 64)
						break; // performance improvement
				}
				i++;
			}
			Assertion.AssertEquals(ihvoMinExp, ihvoMin);
			Assertion.AssertEquals(ihvoLimExp, ihvoLim);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test getting the scripture reference from a Twfic.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void GetReferenceFromTwfic()
		{
			ScrTxtPara para = new ScrTxtPara(m_fdoCache, m_hvoPhm_17_21);

			BCVRef refStart, refEnd;

			bool fRet = TxtWordformInContext.GetReferenceFromTwfic(para, 140, 140, 
				out refStart, out refEnd);
			Assertion.Assert(!fRet);

			fRet = TxtWordformInContext.GetReferenceFromTwfic(para, 143, 147, 
				out refStart, out refEnd);
			Assertion.Assert(fRet);
			Assertion.AssertEquals(Phm_1_18, refStart);
			Assertion.AssertEquals(Phm_1_18, refEnd);

			fRet = TxtWordformInContext.GetReferenceFromTwfic(para, 165, 176, 
				out refStart, out refEnd);
			Assertion.Assert(fRet);
			Assertion.AssertEquals(Phm_1_18, refStart);
			Assertion.AssertEquals(Phm_1_18, refEnd);

			fRet = TxtWordformInContext.GetReferenceFromTwfic(para, 165, 177, 
				out refStart, out refEnd);
			Assertion.Assert(fRet);
			Assertion.AssertEquals(Phm_1_18, refStart);
			Assertion.AssertEquals(Phm_1_18, refEnd);

			fRet = TxtWordformInContext.GetReferenceFromTwfic(para, 165, 178, 
				out refStart, out refEnd);
			Assertion.Assert(fRet);
			Assertion.AssertEquals(Phm_1_19, refStart);
			Assertion.AssertEquals(Phm_1_19, refEnd);

			fRet = TxtWordformInContext.GetReferenceFromTwfic(para, 140, 200, 
				out refStart, out refEnd);
			Assertion.Assert(fRet);
			Assertion.AssertEquals(Phm_1_19, refStart);
			Assertion.AssertEquals(Phm_1_19, refEnd);

			fRet = TxtWordformInContext.GetReferenceFromTwfic(para, -1, 5, 
				out refStart, out refEnd);
			Assertion.Assert(fRet);
			Assertion.AssertEquals(Phm_1_17, refStart);
			Assertion.AssertEquals(Phm_1_17, refEnd);

			fRet = TxtWordformInContext.GetReferenceFromTwfic(para, 600, 700, 
				out refStart, out refEnd);
			Assertion.Assert(!fRet);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test removing and adjusting twfics.
		/// </summary>
		/// <param name="ivMin">the starting character index where the change occurred.</param>
		/// <param name="cchIns">the number of characters inserted.</param>
		/// <param name="cchDel">the number of characters deleted.</param>
		/// <param name="iDelExpected">Expected start index of deleted twfics</param>
		/// <param name="cDelExpected">Expected number of deleted twfics</param>
		/// ------------------------------------------------------------------------------------
		private void CheckAdjustedTwfics(int ivMin, int cchIns, int cchDel, int iDelExpected,
			int cDelExpected)
		{
			int cTwficsBefore = m_para.AnalyzedTextObjectsOS.Count;
			ArrayList twficsBefore = new ArrayList(cTwficsBefore);
			foreach (TxtWordformInContext twfic in m_para.AnalyzedTextObjectsOS)
			{
				twficsBefore.Add(twfic.ParaCharOffset);
			}

			int iDel = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(m_para, ivMin, cchIns,
				cchDel);
			int cTwficsAfter = m_para.AnalyzedTextObjectsOS.Count;

			Assertion.AssertEquals(cTwficsBefore, cTwficsAfter + cDelExpected);
			Assertion.AssertEquals(iDelExpected, iDel);

			int i = 0;
			foreach (TxtWordformInContext twfic in m_para.AnalyzedTextObjectsOS)
			{
				if (i >= iDel)
					Assertion.AssertEquals(
						(int)twficsBefore[i + cDelExpected] - cchDel + cchIns, 
						twfic.ParaCharOffset);
				else
					Assertion.AssertEquals((int)twficsBefore[i], twfic.ParaCharOffset);
				i++;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test the RemoveEditedAnalyzedTextObjects method
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void AdjustEditedTwfics()
		{
			string savePoint;
			m_fdoCache.DatabaseAccessor.SetSavePoint(out savePoint);

			// Delete 6 characters in the middle of a word: pl(us enc)ore
			CheckAdjustedTwfics(512, 0, 6, 109, 2);
			
			// Delete 9 characters (2 twfics): (mon coeur)
			CheckAdjustedTwfics(401, 0, 9, 86, 2);
			
			// Delete 10 characters at the beginning of a word: (rends moi c)e
			CheckAdjustedTwfics(354, 0, 10, 77, 3);
			
			// Delete 6 and insert 6 characters at the beginning of a word: (toi me)me
			CheckAdjustedTwfics(327, 6, 6, 73, 2);
			
			// Don't do anything
			CheckAdjustedTwfics(0, 0, 0, 0, 0);
			
			m_fdoCache.DatabaseAccessor.RollbackSavePoint(savePoint);
			m_fdoCache.VwCacheDaAccessor.ClearInfoAbout(m_para.ownerHVO, true);
			m_para = LoadIntoCache(m_hvoPhm_17_21);
			m_fdoCache.DatabaseAccessor.SetSavePoint(out savePoint);

			// Starting after the end of the paragraph don't do anything
			CheckAdjustedTwfics(2000, 0, 0, 115, 0);
			
			// Insert 2000 characters
			CheckAdjustedTwfics(0, 2000, 0, 0, 0);
			
			// Delete all twfics
			CheckAdjustedTwfics(0, 0, 4000, 0, 115);

			// rollback will be done by TearDown method
		}

	}
}
