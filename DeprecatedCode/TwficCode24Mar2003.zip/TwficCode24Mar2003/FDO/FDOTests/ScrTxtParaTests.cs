// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ScrTxtParaTests.cs
// Responsibility: BryanW
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Data.SqlClient;
using NUnit.Framework;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.FDO.Scripture;
using SIL.FieldWorks.FDO.Scripture.Generated;
using SIL.FieldWorks.Common.Utils;
using SIL.FieldWorks.Common.COMInterfaces;

namespace SIL.FieldWorks.FDO.FDOTests
{
	#region DummyScrTxtPara class
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Test class that allows access to protected methods of class <see cref="ScrTxtPara"/>.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	internal class DummyScrTxtPara: ScrTxtPara
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="DummyScrTxtPara"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public DummyScrTxtPara(): base() {}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="DummyScrTxtPara"/> class.
		/// </summary>
		/// <param name="fcCache">The FDO cache object</param>
		/// -----------------------------------------------------------------------------------
		public DummyScrTxtPara(FdoCache fcCache): base(fcCache) {}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="DummyScrTxtPara"/> class.
		/// </summary>
		/// <param name="fcCache">The FDO cache object</param>
		/// <param name="hvo">HVO of the new object</param>
		/// ------------------------------------------------------------------------------------
		public DummyScrTxtPara(FdoCache fcCache, int hvo)
			: base(fcCache, hvo) {}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="DummyScrTxtPara"/> class.
		/// </summary>
		/// <param name="fcCache">The FDO cache object</param>
		/// <param name="hvo">HVO of the new object</param>
		/// <param name="sectRefStart">The start reference for the whole section</param>
		/// <param name="sectRefEnd">The end reference for the whole section</param>
		/// <remarks>You can use this constructor if you previously constructed a paragraph in 
		/// the same section.</remarks>
		/// ------------------------------------------------------------------------------------
		public DummyScrTxtPara(FdoCache fcCache, int hvo, BCVRef sectRefStart, BCVRef sectRefEnd)
			: base(fcCache, hvo, sectRefStart, sectRefEnd) {}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Find the start and end reference at the end of this paragraph.
		/// </summary>
		/// <param name="refStart">[out] Start reference for the paragraph.</param>
		/// <param name="refEnd">[out] End reference for the paragraph.</param>
		/// <returns>A value of <see cref="ScrTxtPara.ChapterVerseFound"/> that tells if a 
		/// chapter and/or verse number was found in the paragraph.</returns>
		/// ------------------------------------------------------------------------------------
		internal new ChapterVerseFound GetBCVRefAtEndOfPara(out BCVRef refStart, out BCVRef refEnd)
		{
			return base.GetBCVRefAtEndOfPara(out refStart, out refEnd);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Find the start and end reference, by searching backwards in this paragraph from the
		/// given position.
		/// </summary>
		/// <param name="ivLim">Index of last character in paragraph where search begins 
		/// (backwards). If calling for a paragraph that was not edited, set 
		/// <paramref name="ivLim"/> to the length of the paragraph.</param>
		/// <param name="refStart">[out] Start reference for the paragraph.</param>
		/// <param name="refEnd">[out] End reference for the paragraph.</param>
		/// <returns>A value of <see cref="ScrTxtPara.ChapterVerseFound"/> that tells if a 
		/// chapter and/or verse number was found in this paragraph.</returns>
		/// ------------------------------------------------------------------------------------
		internal new ChapterVerseFound GetBCVRefAtPosWithinPara(int ivLim, out BCVRef refStart, 
			out BCVRef refEnd)
		{
			return base.GetBCVRefAtPosWithinPara(ivLim, out refStart, out refEnd);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Get the start and end reference of the specified position <paramref name="ivPos"/>
		/// in the paragraph.
		/// </summary>
		/// <param name="ivPos">Character offset in the paragraph.</param>
		/// <param name="refStart">[out] Start reference</param>
		/// <param name="refEnd">[out] End reference</param>
		/// ------------------------------------------------------------------------------------
		internal new void GetBCVRefAtPosition(int ivPos, out BCVRef refStart, out BCVRef refEnd)
		{
			base.GetBCVRefAtPosition(ivPos, out refStart, out refEnd);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Determine the start and end reference for the section this paragraph belongs to.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		internal new void GetSectionStartAndEndReference()
		{
			base.GetSectionStartAndEndReference();
		}
	}
	#endregion

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Test the <see cref="ScrTxtPara"/> class
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public class ScrTxtParaTests: FdoTestBase
	{
		private BCVRef Empty = new BCVRef(0, 0, 0);
		private BCVRef Verse_17 = new BCVRef(0, 0, 17);

		private BCVRef Phm_1_0 = new BCVRef(57, 1, 0);
		private BCVRef Phm_1_1 = new BCVRef(57, 1, 1);
		private BCVRef Phm_1_3 = new BCVRef(57, 1, 3);
		private BCVRef Phm_1_16 = new BCVRef(57, 1, 16);
		private BCVRef Phm_1_17 = new BCVRef(57, 1, 17);
		private BCVRef Phm_1_18 = new BCVRef(57, 1, 18);
		private BCVRef Phm_1_19 = new BCVRef(57, 1, 19);
		private BCVRef Phm_1_20 = new BCVRef(57, 1, 20);
		private BCVRef Phm_1_21 = new BCVRef(57, 1, 21);
		private BCVRef Phm_1_22 = new BCVRef(57, 1, 22);
		private BCVRef Phm_1_24 = new BCVRef(57, 1, 24);
		private BCVRef Phm_1_25 = new BCVRef(57, 1, 25);
		private BCVRef Phm_2_1  = new BCVRef(57, 2, 1);
		private BCVRef Phm_3_1  = new BCVRef(57, 3, 1);
		private BCVRef Phm_4_1  = new BCVRef(57, 4, 1);
		private BCVRef Phm_5_1  = new BCVRef(57, 5, 1);
		private BCVRef Phm_5_2  = new BCVRef(57, 5, 2);
		private BCVRef Phm_25_1 = new BCVRef(57, 25, 1);
		private BCVRef Phm_25_26 = new BCVRef(57, 25, 26);
		private BCVRef Phm_25_27 = new BCVRef(57, 25, 27);
		private BCVRef Phm_25_29 = new BCVRef(57, 25, 29);
		private BCVRef Phm_25_30 = new BCVRef(57, 25, 30);
		private BCVRef Phm_25_31 = new BCVRef(57, 25, 31);
		private BCVRef Phm_25_32 = new BCVRef(57, 25, 32);
		private BCVRef Phm_25_33 = new BCVRef(57, 25, 33);
		

		// HVOs in TestLangProj for StTxtParas used for testing
		// HVO 5540 is Phm 1:17-21
		// a typical paragraph of scripture text
		private int hvoPhm_17_21 = 5540;
		// HVO 5196 is Phm 1:1-3
		private int hvoPhm_1_3 = 5196;
		// HVO 5193 is a section heading in Phm
		private int hvoPhm_1_SectHead = 5193;
		// HVO 4789 is one paragraph in introduction to Phm
		private int hvoPhm_Intro = 4789;
		// HVO 5704 is the book title for Phm
		private int hvoPhm_BookTitle = 5704;

		// Styles for verse, chapter and other text
		private ITsTextProps m_ttpVerse;
		private ITsTextProps m_ttpChapter;
		private ITsTextProps m_ttpNormal;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ScrTxtParaTests"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public ScrTxtParaTests()
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Load the object <paramref name="hvo"/> and all its parent objects into the cache.
		/// </summary>
		/// <param name="hvo">The HVO for a <see cref="StTxtPara"/></param>
		/// ------------------------------------------------------------------------------------
		private void LoadIntoCache(int hvo)
		{
			StTxtPara txtpara = new StTxtPara(m_fdoCache, hvo);
			StText text = new StText(m_fdoCache, txtpara.ownerHVO);
			ScrSection section = new ScrSection(m_fdoCache, text.ownerHVO);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Retrieve the HVOs for different paragraphs
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[FixtureSetUp]
		private void RetrieveHvos()
		{
			SqlConnection sqlConMaster = new SqlConnection(string.Format(@"Server=.\SILFW; " +
				"Database={0}; User ID = sa; Password=inscrutable;Connect Timeout = 2;", 
				DatabaseName));
			sqlConMaster.Open();

			SqlCommand sqlComm = sqlConMaster.CreateCommand();
			string sSql = @"select MIN(Owner$) from TxtWordformInContext_ (readuncommitted)
				where VerseRefStart = 57001017";
			sqlComm.CommandText = sSql;
			SqlDataReader sqlreader =
				sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			if (sqlreader.Read())
				hvoPhm_17_21 = sqlreader.GetInt32(0);
			sqlreader.Close();

			sSql = @"select MIN(Owner$) from TxtWordformInContext_ (readuncommitted)
				where VerseRefStart = 57001003";
			sqlComm.CommandText = sSql;
			sqlreader = sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			if (sqlreader.Read())
				hvoPhm_1_3 = sqlreader.GetInt32(0);
			sqlreader.Close();

			sSql = @"select dst from StText_paragraphs where src=(select dst from 
				ScrSection_Heading where src=(select id from ScrSection_ where 
				VerseRefStart=57001001))";
			sqlComm.CommandText = sSql;
			sqlreader = sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			if (sqlreader.Read())
				hvoPhm_1_SectHead = sqlreader.GetInt32(0);
			sqlreader.Close();
			
			sSql = @"select owner$ from TxtWordformInContext_ where Form='C' and ParaCharOffset=0";
			sqlComm.CommandText = sSql;
			sqlreader = sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			if (sqlreader.Read())
				hvoPhm_Intro = sqlreader.GetInt32(0);
			sqlreader.Close();

			sSql = @"select dst from StText_paragraphs where src=
					(select dst from ScrBook_Title)";
			sqlComm.CommandText = sSql;
			sqlreader = sqlComm.ExecuteReader(System.Data.CommandBehavior.SingleResult);
			if (sqlreader.Read())
				hvoPhm_BookTitle = sqlreader.GetInt32(0);
			sqlreader.Close();

			ITsPropsBldr tsPropsBldr = (ITsPropsBldr)new FwKernelLib.TsPropsBldrClass();
			tsPropsBldr.SetStrPropValue((int)FwKernelLib.FwTextPropType.ktptNamedStyle, 
				StStyle.ScrVerseNumberStyleName);
			m_ttpVerse = tsPropsBldr.GetTextProps();

			tsPropsBldr.SetStrPropValue((int)FwKernelLib.FwTextPropType.ktptNamedStyle, 
				StStyle.ScrChapterNumberStyleName);
			m_ttpChapter = tsPropsBldr.GetTextProps();

			tsPropsBldr.SetStrPropValue((int)FwKernelLib.FwTextPropType.ktptNamedStyle, 
				StStyle.ScrParagraphStyleName);
			m_ttpNormal = tsPropsBldr.GetTextProps();
			sqlConMaster.Close();
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Make sure that StTxtPara with HVO 5540 is loaded in the cache.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[SetUp]
		public override void Initialize()
		{
			base.Initialize();
			LoadIntoCache(hvoPhm_17_21);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Tests getting the section start and end reference for a paragraph
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void SectionReferencesTest()
		{
			// Test a typical paragraph of scripture text
			// Create StTxtPara that we will test and load it from database
			DummyScrTxtPara para = new DummyScrTxtPara(m_fdoCache, hvoPhm_17_21);

			Assertion.AssertEquals(Phm_1_1, para.SectRefStart);
			Assertion.AssertEquals(Phm_1_25, para.SectRefEnd);

			// Test a section heading
			// HVO 5193 in TestLangProj is a section heading in Phm
			LoadIntoCache(hvoPhm_1_SectHead);
			para = new DummyScrTxtPara(m_fdoCache, hvoPhm_1_SectHead);

			Assertion.AssertEquals(Phm_1_1, para.SectRefStart);
			Assertion.AssertEquals(Phm_1_25, para.SectRefEnd);

			// Test an introduction paragraph
			// HVO 4789 in TestLangProj is one paragraph in introduction to Phm
			LoadIntoCache(hvoPhm_Intro);
			para = new DummyScrTxtPara(m_fdoCache, hvoPhm_Intro);

			Assertion.AssertEquals(Phm_1_0, para.SectRefStart);
			Assertion.AssertEquals(Phm_1_0, para.SectRefEnd);

			// Test a book title
			// we have to load the book, scrRef, and StText so that it is loaded in the cache.
			StTxtPara txtpara = new StTxtPara(m_fdoCache, hvoPhm_BookTitle);
			StText text = new StText(m_fdoCache, txtpara.ownerHVO);
			ScrBook scrBook = new ScrBook(m_fdoCache, text.ownerHVO);
			ScrBookRef scrRef = scrBook.BookIdRA;
			// HVO 5704 in TestLangProj is the book title for Phm
			para = new DummyScrTxtPara(m_fdoCache, hvoPhm_BookTitle);

			Assertion.AssertEquals(Phm_1_0, para.SectRefStart);
			Assertion.AssertEquals(Phm_1_0, para.SectRefEnd);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test ExtractVerseNums
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void ExtractVerseNums()
		{
			// just any arbitrary hvo - we have to call that c'tor to get the CharPropEngine
			// initialized
			DummyScrTxtPara para = new DummyScrTxtPara(m_fdoCache, hvoPhm_17_21);

			int nVerseStart, nVerseEnd;
			para.ExtractVerseNums("5-7", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(5, nVerseStart);
			Assertion.AssertEquals(7, nVerseEnd);

			para.ExtractVerseNums(" 8 - 15 ", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(8, nVerseStart);
			Assertion.AssertEquals(15, nVerseEnd);

			para.ExtractVerseNums("-16", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(16, nVerseStart);
			Assertion.AssertEquals(16, nVerseEnd);

			para.ExtractVerseNums("17-", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(17, nVerseStart);
			Assertion.AssertEquals(17, nVerseEnd);

			para.ExtractVerseNums("12", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(12, nVerseStart);
			Assertion.AssertEquals(12, nVerseEnd);

			para.ExtractVerseNums("a-b", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(0, nVerseStart);
			Assertion.AssertEquals(0, nVerseEnd);

			para.ExtractVerseNums("1215", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(999, nVerseStart);
			Assertion.AssertEquals(999, nVerseEnd);

			para.ExtractVerseNums(" 18 20 ", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(18, nVerseStart);
			Assertion.AssertEquals(20, nVerseEnd);

			para.ExtractVerseNums(" 21 22 23 ", out nVerseStart, out nVerseEnd);
			// code works this way now; a different result may be desired
			Assertion.AssertEquals(21, nVerseStart);
			Assertion.AssertEquals(23, nVerseEnd);

			para.ExtractVerseNums("", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(0, nVerseStart);
			Assertion.AssertEquals(0, nVerseEnd);

			para.ExtractVerseNums(" ", out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(0, nVerseStart);
			Assertion.AssertEquals(0, nVerseEnd);

			para.ExtractVerseNums(null, out nVerseStart, out nVerseEnd);
			Assertion.AssertEquals(0, nVerseStart);
			Assertion.AssertEquals(0, nVerseEnd);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test ExtractChapterNums
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void ExtractChapterNums()
		{
			// just any arbitrary hvo - we have to call that c'tor to get the CharPropEngine
			// initialized
			DummyScrTxtPara para = new DummyScrTxtPara(m_fdoCache, hvoPhm_17_21);

			Assertion.AssertEquals(7, para.ExtractChapterNum("7"));
			Assertion.AssertEquals(10, para.ExtractChapterNum(" 10 "));
			Assertion.AssertEquals(11, para.ExtractChapterNum(" -11 "));
			Assertion.AssertEquals(12, para.ExtractChapterNum(" 12- "));
			Assertion.AssertEquals(0, para.ExtractChapterNum(" a "));
			Assertion.AssertEquals(999, para.ExtractChapterNum("1216"));
			Assertion.AssertEquals(8, para.ExtractChapterNum("8-9"));
			Assertion.AssertEquals(8, para.ExtractChapterNum(" 8 9"));
			Assertion.AssertEquals(0, para.ExtractChapterNum(""));
			Assertion.AssertEquals(0, para.ExtractChapterNum(" "));
			Assertion.AssertEquals(0, para.ExtractChapterNum(null));
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test getting a reference from a single paragraph
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void GetReferenceWithinPara()
		{
			ScrTxtPara.ChapterVerseFound retVal;
			BCVRef refStart, refEnd;

			DummyScrTxtPara para = new DummyScrTxtPara(m_fdoCache, hvoPhm_17_21);
			retVal = para.GetBCVRefAtEndOfPara(out refStart, out refEnd);
			Assertion.AssertEquals(
				ScrTxtPara.ChapterVerseFound.Verse | ScrTxtPara.ChapterVerseFound.Chapter,
				retVal);
			Assertion.AssertEquals(Phm_1_21, refStart);
			Assertion.AssertEquals(Phm_1_21, refEnd);

			retVal = para.GetBCVRefAtPosWithinPara(para.Contents.Text.Length-1, out refStart, out refEnd);
			Assertion.AssertEquals(
				ScrTxtPara.ChapterVerseFound.Verse | ScrTxtPara.ChapterVerseFound.Chapter,
				retVal);
			Assertion.AssertEquals(Phm_1_21, refStart);
			Assertion.AssertEquals(Phm_1_21, refEnd);

			retVal = para.GetBCVRefAtPosWithinPara(0, out refStart, out refEnd);
			Assertion.AssertEquals(ScrTxtPara.ChapterVerseFound.None, retVal);

			retVal = para.GetBCVRefAtPosWithinPara(1, out refStart, out refEnd);
			Assertion.AssertEquals(ScrTxtPara.ChapterVerseFound.Verse, retVal);
			Assertion.AssertEquals(Verse_17, refStart);
			Assertion.AssertEquals(Verse_17, refEnd);

			retVal = para.GetBCVRefAtPosWithinPara(2, out refStart, out refEnd);
			Assertion.AssertEquals(ScrTxtPara.ChapterVerseFound.Verse, retVal);
			Assertion.AssertEquals(Verse_17, refStart);
			Assertion.AssertEquals(Verse_17, refEnd);

			retVal = para.GetBCVRefAtPosWithinPara(90, out refStart, out refEnd);
			Assertion.AssertEquals(
				ScrTxtPara.ChapterVerseFound.Verse | ScrTxtPara.ChapterVerseFound.Chapter, 
				retVal);
			Assertion.AssertEquals(Phm_1_18, refStart);
			Assertion.AssertEquals(Phm_1_18, refEnd);

			DummyScrTxtPara para2 = new DummyScrTxtPara(m_fdoCache, hvoPhm_17_21, para.SectRefStart, 
				para.SectRefEnd);
			retVal = para2.GetBCVRefAtPosWithinPara(1, out refStart, out refEnd);
			Assertion.AssertEquals(ScrTxtPara.ChapterVerseFound.Verse, retVal);
			Assertion.AssertEquals(Verse_17, refStart);
			Assertion.AssertEquals(Verse_17, refEnd);

			// now test without having a section reference
			para = new DummyScrTxtPara(m_fdoCache, hvoPhm_17_21, 0, 0);
			retVal = para.GetBCVRefAtPosWithinPara(1, out refStart, out refEnd);
			Assertion.AssertEquals(ScrTxtPara.ChapterVerseFound.Verse, retVal);
			Assertion.AssertEquals(Verse_17, refStart);
			Assertion.AssertEquals(Verse_17, refEnd);
		}

		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test getting a reference at a given position in the paragraph.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void GetReferenceAtPosition()
		{
			BCVRef refStart, refEnd;
			// Test middle of a paragraph somewhere in the section
			DummyScrTxtPara para = new DummyScrTxtPara(m_fdoCache, hvoPhm_17_21);
			para.GetBCVRefAtPosition(90, out refStart, out refEnd);
			Assertion.AssertEquals(Phm_1_18, refStart);
			Assertion.AssertEquals(Phm_1_18, refEnd);

			// Test begin of paragraph at beginnning of section
			para = new DummyScrTxtPara(m_fdoCache, hvoPhm_1_3);
			para.GetBCVRefAtPosition(1, out refStart, out refEnd);
			Assertion.AssertEquals(Phm_1_1, refStart);
			Assertion.AssertEquals(Phm_1_1, refEnd);

			// test a new paragraph in a new section
			ScrBook book = 
				(ScrBook)m_fdoCache.LanguageProject.TranslatedScriptureOA.ScriptureBooksOS[0];
			ScrSection section = new ScrSection();
			book.SectionsOS.Append(section);
			StText text = section.ContentOA = new StText();
			DummyScrTxtPara newPara = new DummyScrTxtPara();
			text.ParagraphsOS.Append(newPara);
			newPara.Contents.Text = "This is a test";
			newPara.GetSectionStartAndEndReference();

			para = new DummyScrTxtPara(m_fdoCache, newPara.hvo);
			para.GetBCVRefAtPosition(1, out refStart, out refEnd);
			Assertion.AssertEquals(Empty, refStart);
			Assertion.AssertEquals(Empty, refEnd);

			// test a new paragraph at the beginning of an existing section
			para = new DummyScrTxtPara(m_fdoCache, hvoPhm_17_21);
			text = new StText(m_fdoCache, para.ownerHVO);

			newPara = new DummyScrTxtPara();
			text.ParagraphsOS.InsertAt(newPara, 0);
			newPara.Contents.Text = "Some text at beginning of section without previous verse";

			para = new DummyScrTxtPara(m_fdoCache, newPara.hvo);
			para.GetBCVRefAtPosition(1, out refStart, out refEnd);
			Assertion.AssertEquals(Phm_1_1, refStart);
			Assertion.AssertEquals(Phm_1_1, refEnd);

			// test a new paragraph at the end of an existing section
			newPara = new DummyScrTxtPara();
			text.ParagraphsOS.Append(newPara);
			newPara.Contents.Text = "Text at the end of the section.";
			newPara.GetSectionStartAndEndReference();

			para = new DummyScrTxtPara(m_fdoCache, newPara.hvo);
			para.GetBCVRefAtPosition(1, out refStart, out refEnd);
			Assertion.AssertEquals(Phm_1_25, refStart);
			Assertion.AssertEquals(Phm_1_25, refEnd);
		}

		/// <summary>Characters to trim from beginning/end of twfic for testing.</summary>
		private char[] rgchTrim = new char[] { '.', '0', '1', '2', '3', '4', '5', '6', 
												 '7', '8', '9', ' ', '-' };
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Assert that parsed twfics are valid.
		/// </summary>
		/// <param name="para">The paragraph.</param>
		/// ------------------------------------------------------------------------------------
		private void AssertTwfics(ScrTxtPara para)
		{
			string text = para.Contents.Text;
			string[] words = text.Trim(rgchTrim).Split(rgchTrim);

			int i = 0;
			foreach(TxtWordformInContext twfic in para.AnalyzedTextObjectsOS)
			{
				while (words[i].Trim(rgchTrim).Length == 0)
					i++;

				Assertion.AssertEquals(words[i].Trim(rgchTrim), twfic.Form.Text);
				Assertion.AssertEquals(
					text.Substring(twfic.ParaCharOffset, twfic.Form.Text.Length), 
					twfic.Form.Text);
				i++;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Assert that references of the parsed twfics are as expected.
		/// </summary>
		/// <param name="para">The paragraph.</param>
		/// <param name="startRef">The expected start reference of the twfics.</param>
		/// <param name="endRef">The expected end reference of the twifcs.</param>
		/// <remarks>This method only works if all twfics of a paragraph have the same
		/// reference.</remarks>
		/// ------------------------------------------------------------------------------------
		private void AssertTwficReferences(ScrTxtPara para, BCVRef startRef, BCVRef endRef)
		{
			foreach(TxtWordformInContext twfic in para.AnalyzedTextObjectsOS)
			{
				Assertion.AssertEquals(startRef, twfic.VerseRefStart);
				Assertion.AssertEquals(endRef, twfic.VerseRefEnd);
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Assert that parsed twfics are valid.
		/// </summary>
		/// <param name="paras">Array of paragraphs.</param>
		/// <param name="expectedRefs">Array of expected references for each twfic in each 
		/// paragraph.</param>
		/// ------------------------------------------------------------------------------------
		private void AssertTwficsAndReferences(ScrTxtPara[] paras, int[][] expectedRefs)
		{
			int iParas = 0;
			foreach (ScrTxtPara para in paras)
			{
				string text = para.Contents.Text;
				string[] words = text.Trim(rgchTrim).Split(rgchTrim);

				int iWords = 0;
				int iRefs = 0;
				foreach(TxtWordformInContext twfic in para.AnalyzedTextObjectsOS)
				{
					// skip empty 'words'
					while (words[iWords].Trim(rgchTrim).Length == 0)
						iWords++;

					Assertion.AssertEquals(words[iWords].Trim(rgchTrim), twfic.Form.Text);
					Assertion.AssertEquals(
						text.Substring(twfic.ParaCharOffset, twfic.Form.Text.Length), 
						twfic.Form.Text);
					Assertion.AssertEquals(expectedRefs[iParas][iRefs], twfic.VerseRefStart);
					Assertion.AssertEquals(expectedRefs[iParas][iRefs], twfic.VerseRefEnd);
					iWords++;
					iRefs++;
				}
				iParas++;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test parsing a paragraph.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void ParseParaTest()
		{
			BCVRef startRef = new BCVRef(5, 5, 5);
			StText stText = ((ScrSection)((ScrBook)m_fdoCache.LanguageProject
				.TranslatedScriptureOA.ScriptureBooksOS[0]).SectionsOS[0]).ContentOA;
			DummyScrTxtPara newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			// add a new paragraph
			string text = newPara.Contents.Text = "This is a completely new paragraph.";
			int nOldcount = newPara.AnalyzedTextObjectsOS.Count;
			Assertion.AssertEquals(0, nOldcount);

			newPara.ParsePara(0, text.Length, 0, ref startRef, ref startRef, false, 0);

			Assertion.AssertEquals("Make sure 6 twfics were added.", 6, 
				newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);

			// add word at end of paragraph
			newPara.Contents.Text = "This is a completely new paragraph. test";
			int ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 35, 
				5, 0);
			Assertion.AssertEquals(6, ihvoTwfic);
			newPara.ParsePara(35, 5, 0, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(7, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);

			// insert and delete a word (change)
			newPara.Contents.Text = "This is a completely older paragraph. test";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 21, 5, 3);
			Assertion.AssertEquals(4, ihvoTwfic);
			newPara.ParsePara(21, 5, 3, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(7, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);

			// delete some characters
			newPara.Contents.Text = "This is a completely older para. test";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 31, 0, 5);
			Assertion.AssertEquals(5, ihvoTwfic);
			newPara.ParsePara(31, 0, 5, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(7, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);

			// delete two whole words
			newPara.Contents.Text = "a completely older para. test";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 0, 0, 8);
			Assertion.AssertEquals(0, ihvoTwfic);
			newPara.ParsePara(0, 0, 8, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(5, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);

			// insert a word at the beginning of the para
			newPara.Contents.Text = "What a completely older para. test";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 0, 5, 0);
			Assertion.AssertEquals(0, ihvoTwfic);
			newPara.ParsePara(0, 5, 0, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(6, newPara.AnalyzedTextObjectsOS.Count);
			Assertion.AssertEquals("What",
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).Form.Text);

			AssertTwfics(newPara);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test all the different cases that can happen when parsing: modified words
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void WordModParseTests()
		{
			BCVRef startRef = new BCVRef(5, 5, 5);
			StText stText = ((ScrSection)((ScrBook)m_fdoCache.LanguageProject
				.TranslatedScriptureOA.ScriptureBooksOS[0]).SectionsOS[0]).ContentOA;

			// delete the space between two words: xxx yyy -> xxxyyy
			DummyScrTxtPara newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();
			newPara.Contents.Text = "xxx yyy";
			newPara.ParsePara(0, 7, 0, ref startRef, ref startRef, false, 0);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			newPara.Contents.Text = "xxxyyy";
			int ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 3, 0, 1);
			newPara.ParsePara(3, 0, 1, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			// adding a space & second word after the first one: xxx -> xxx yyy
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();
			newPara.Contents.Text = "xxx";
			newPara.ParsePara(0, 3, 0, ref startRef, ref startRef, false, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			newPara.Contents.Text = "xxx yyy";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 3, 4, 0);
			newPara.ParsePara(3, 4, 0, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			// adding a second word after the first word & space: xxx -> xxx yyy
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();
			newPara.Contents.Text = "xxx ";
			newPara.ParsePara(0, 4, 0, ref startRef, ref startRef, false, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			newPara.Contents.Text = "xxx yyy";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 4, 3, 0);
			newPara.ParsePara(4, 3, 0, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			// modifying a word by inserting one letter: xxx -> xyxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();
			newPara.Contents.Text = "xxx";
			newPara.ParsePara(0, 3, 0, ref startRef, ref startRef, false, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			newPara.Contents.Text = "xyxx";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 1, 1, 0);
			newPara.ParsePara(1, 1, 0, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			// adding a new letter to the beginning of a word: xxx -> yxxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();
			newPara.Contents.Text = "xxx";
			newPara.ParsePara(0, 3, 0, ref startRef, ref startRef, false, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			newPara.Contents.Text = "yxxx";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 0, 1, 0);
			newPara.ParsePara(0, 1, 0, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			// adding a new letter to the end of a word: xxx -> xxxy
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();
			newPara.Contents.Text = "xxx";
			newPara.ParsePara(0, 3, 0, ref startRef, ref startRef, false, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			newPara.Contents.Text = "xxxy";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 3, 1, 0);
			newPara.ParsePara(3, 1, 0, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			// splitting one word into two words: xxx -> x xx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();
			newPara.Contents.Text = "xxx";
			newPara.ParsePara(0, 3, 0, ref startRef, ref startRef, false, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			
			newPara.Contents.Text = "x xx";
			ihvoTwfic = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(newPara, 1, 1, 0);
			newPara.ParsePara(1, 1, 0, ref startRef, ref startRef, false, ihvoTwfic);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test all the different cases that can happen when parsing: modified verse numbers.
		/// Tests the ParseStTxtPara method.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void VerseModParseTests()
		{
			StText stText = ((ScrSection)((ScrBook)m_fdoCache.LanguageProject
				.TranslatedScriptureOA.ScriptureBooksOS[0]).SectionsOS[0]).ContentOA;

			// Change verse number: 16xxx -> 1xxx
			DummyScrTxtPara newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			ITsStrBldr paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "16", m_ttpVerse);
			paraStrBldr.Replace(2, 2, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 5, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_1_16, Phm_1_16);

			paraStrBldr.Replace(0, 2, "1", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 0, 1);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_1_1, Phm_1_1);

			// Change verse number: 17xxx -> 18xxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "17", m_ttpVerse);
			paraStrBldr.Replace(2, 2, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 5, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_1_17, Phm_1_17);

			paraStrBldr.Replace(1, 2, "8", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 1, 1);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_1_18, Phm_1_18);

			// Delete verse number (after space):  19xxx ->  xxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, " ", m_ttpNormal);
			paraStrBldr.Replace(1, 1, "19", m_ttpVerse);
			paraStrBldr.Replace(3, 3, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 6, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_1_19, Phm_1_19);

			paraStrBldr.Replace(1, 3, "", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 0, 2);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_1_18, Phm_1_18);

			// Deleting a character & period & inserting a space:  yy.20xxx ->  y 20xxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "yy.", m_ttpNormal);
			paraStrBldr.Replace(3, 3, "20", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 8, 0);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			Assertion.AssertEquals(Phm_1_18, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_18, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefEnd);
			Assertion.AssertEquals(Phm_1_20, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_20, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefEnd);

			paraStrBldr.Replace(1, 3, " ", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 1, 2);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			Assertion.AssertEquals(Phm_1_18, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_18, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefEnd);
			Assertion.AssertEquals(Phm_1_20, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_20, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefEnd);

			// Deleting a period:  yy.21xxx ->  yy21xxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "yy.", m_ttpNormal);
			paraStrBldr.Replace(3, 3, "21", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 8, 0);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			Assertion.AssertEquals(Phm_1_20, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_20, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefEnd);
			Assertion.AssertEquals(Phm_1_21, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_21, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefEnd);

			paraStrBldr.Replace(1, 2, "", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 0, 1);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			Assertion.AssertEquals(Phm_1_20, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_20, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefEnd);
			Assertion.AssertEquals(Phm_1_21, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_21, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefEnd);

			// Changing verse number and make it a bridge:  yy. 22xxx ->  yy. 22-24xxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "yy. ", m_ttpNormal);
			paraStrBldr.Replace(4, 4, "22", m_ttpVerse);
			paraStrBldr.Replace(6, 6, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 9, 0);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			Assertion.AssertEquals(Phm_1_21, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_21, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefEnd);
			Assertion.AssertEquals(Phm_1_22, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_22, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefEnd);

			paraStrBldr.Replace(6, 6, "-24", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(6, 3, 0);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			Assertion.AssertEquals(Phm_1_21, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_21, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefEnd);
			Assertion.AssertEquals(Phm_1_22, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefStart);
			Assertion.AssertEquals(Phm_1_24, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefEnd);

			// Change verse number into chapter number: ' 25xxx' -> ' 25xxx'
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, " ", m_ttpNormal);
			paraStrBldr.Replace(1, 1, "25", m_ttpVerse);
			paraStrBldr.Replace(3, 3, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 6, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_1_25, Phm_1_25);

			paraStrBldr.Replace(1, 3, " 25", m_ttpChapter);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 3, 2);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_25_1, Phm_25_1);

			// Change verse number into normal number: ' 26xxx' -> ' 26xxx'
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, " ", m_ttpNormal);
			paraStrBldr.Replace(1, 1, "26", m_ttpVerse);
			paraStrBldr.Replace(3, 3, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 6, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_25_26, Phm_25_26);

			paraStrBldr.Replace(1, 3, " 26", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 3, 2);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_25_1, Phm_25_1);

			// Change verse bridge into single verse number: 27-29xxx -> 27xxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "27-29", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 8, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_25_27, Phm_25_29);

			paraStrBldr.Replace(0, 5, "27", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 2, 5);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_25_27, Phm_25_27);

			// Change verse bridge: 30-32xxx -> 30-31xxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "30-32", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 8, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_25_30, Phm_25_32);

			paraStrBldr.Replace(3, 5, "31", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(3, 2, 2);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_25_30, Phm_25_31);

			// Insert additional verse number:  yy 33xxx ->  33yy 33xxx
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "yy ", m_ttpNormal);
			paraStrBldr.Replace(3, 3, "33", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 8, 0);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			Assertion.AssertEquals(Phm_25_30, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefStart);
			Assertion.AssertEquals(Phm_25_31, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[0]).VerseRefEnd);
			Assertion.AssertEquals(Phm_25_33, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefStart);
			Assertion.AssertEquals(Phm_25_33, 
				((TxtWordformInContext)newPara.AnalyzedTextObjectsOS[1]).VerseRefEnd);

			paraStrBldr.Replace(0, 0, "33", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 2, 0);

			Assertion.AssertEquals(2, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_25_33, Phm_25_33);

		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Test all the different cases that can happen when parsing: modified chapter numbers.
		/// Tests the ParseStTxtPara method.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void ChapterModParseTests()
		{
			int nSections = ((ScrBook)m_fdoCache.LanguageProject
				.TranslatedScriptureOA.ScriptureBooksOS[0]).SectionsOS.Count;
			StText stText = ((ScrSection)((ScrBook)m_fdoCache.LanguageProject
				.TranslatedScriptureOA.ScriptureBooksOS[0]).SectionsOS[nSections-1]).ContentOA;

			// Delete chapter number: '2 xxx' -> xxx
			DummyScrTxtPara newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			ITsStrBldr paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "2 ", m_ttpChapter);
			paraStrBldr.Replace(2, 2, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 5, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_2_1, Phm_2_1);

			paraStrBldr.Replace(0, 2, "", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 0, 2);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_1_25, Phm_1_25);

			// Change chapter number into a verse number: '3 xxx' -> '3 xxx'
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "3 ", m_ttpChapter);
			paraStrBldr.Replace(2, 2, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 5, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_3_1, Phm_3_1);

			paraStrBldr.Replace(0, 2, "3 ", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 2, 2);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_1_3, Phm_1_3);

			// Change chapter number into a different chapter number: '4 xxx' -> '3 xxx'
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "4 ", m_ttpChapter);
			paraStrBldr.Replace(2, 2, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 5, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_4_1, Phm_4_1);

			paraStrBldr.Replace(0, 2, "3 ", m_ttpChapter);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 2, 2);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_3_1, Phm_3_1);

			// Insert verse number after chapter number: '5 xxx' -> '51xxx'
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "5 ", m_ttpChapter);
			paraStrBldr.Replace(2, 2, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 5, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_5_1, Phm_5_1);

			paraStrBldr.Replace(1, 1, "1", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 1, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_5_1, Phm_5_1);

			// Remove verse number after chapter number: '51xxx' -> '5xxx'
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "5", m_ttpChapter);
			paraStrBldr.Replace(1, 1, "1", m_ttpVerse);
			paraStrBldr.Replace(2, 2, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 5, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_5_1, Phm_5_1);

			paraStrBldr.Replace(1, 2, "", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 0, 1);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_5_1, Phm_5_1);

			// Change verse number after chapter number: '51xxx' -> '52xxx'
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "5", m_ttpChapter);
			paraStrBldr.Replace(1, 1, "1", m_ttpVerse);
			paraStrBldr.Replace(2, 2, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 5, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_5_1, Phm_5_1);

			paraStrBldr.Replace(1, 2, "2", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 1, 1);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_5_2, Phm_5_2);

			// Insert verse number after chapter number: '5xxx' -> '52xxx'
			newPara = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(newPara);
			newPara.GetSectionStartAndEndReference();

			paraStrBldr = newPara.Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "5", m_ttpChapter);
			paraStrBldr.Replace(1, 1, "xxx", m_ttpNormal);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(0, 4, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_5_1, Phm_5_1);

			paraStrBldr.Replace(1, 1, "2", m_ttpVerse);
			newPara.Contents.UnderlyingTsString = paraStrBldr.GetString();
			newPara.ParseStTxtPara(1, 1, 0);

			Assertion.AssertEquals(1, newPara.AnalyzedTextObjectsOS.Count);
			AssertTwfics(newPara);
			AssertTwficReferences(newPara, Phm_5_2, Phm_5_2);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Tests the re-stamping of TWFICS. Tests the ParseStTxtPara method.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void Restamping()
		{
			int nSections = ((ScrBook)m_fdoCache.LanguageProject
				.TranslatedScriptureOA.ScriptureBooksOS[0]).SectionsOS.Count;
			StText stText = ((ScrSection)((ScrBook)m_fdoCache.LanguageProject
				.TranslatedScriptureOA.ScriptureBooksOS[0]).SectionsOS[nSections-1]).ContentOA;


			// Delete chapter number: '2 xxx' -> xxx
			DummyScrTxtPara[] paras = new DummyScrTxtPara[2];
			int[][] expectedRefs = new int[2][];
			string savePoint;
			m_fdoCache.DatabaseAccessor.SetSavePoint(out savePoint);
			paras[0] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[0]);
			paras[0].GetSectionStartAndEndReference();

			ITsStrBldr paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "2 ", m_ttpChapter);
			paraStrBldr.Replace(2, 2, "Aaa Vvv", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "2", m_ttpVerse);
			paraStrBldr.Replace(10, 10, "bbb", m_ttpNormal);
			paraStrBldr.Replace(13, 13, "3", m_ttpVerse);
			paraStrBldr.Replace(14, 14, " ccc.", m_ttpNormal);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(0, 19, 0);

			paras[1] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[1]);
			paras[1].GetSectionStartAndEndReference();

			paraStrBldr = paras[1].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "Ddd ", m_ttpNormal);
			paraStrBldr.Replace(4, 4, "4", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "eee.", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "3", m_ttpChapter);
			paraStrBldr.Replace(10, 10, " Fff.", m_ttpNormal);
			paras[1].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[1].ParseStTxtPara(0, 15, 0);

			expectedRefs[0] = new int[] { 57002001, 57002001, 57002002, 57002003 };
			expectedRefs[1] = new int[] { 57002003, 57002004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 2, "", m_ttpNormal);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(0, 0, 2);

			expectedRefs[0] = new int[] { 57001025, 57001025, 57001002, 57001003 };
			expectedRefs[1] = new int[] { 57001003, 57001004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			m_fdoCache.DatabaseAccessor.RollbackSavePoint(savePoint);
			m_fdoCache.VwCacheDaAccessor.ClearInfoAbout(paras[0].ownerHVO, true);

			// Change chapter number to a verse number: '2 xxx xxx' -> '2 xxx xxx'

			m_fdoCache.DatabaseAccessor.SetSavePoint(out savePoint);
			paras[0] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[0]);
			paras[0].GetSectionStartAndEndReference();

			paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "2 ", m_ttpChapter);
			paraStrBldr.Replace(2, 2, "Aaa Vvv", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "2", m_ttpVerse);
			paraStrBldr.Replace(10, 10, "bbb", m_ttpNormal);
			paraStrBldr.Replace(13, 13, "3", m_ttpVerse);
			paraStrBldr.Replace(14, 14, " ccc.", m_ttpNormal);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(0, 19, 0);

			paras[1] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[1]);
			paras[1].GetSectionStartAndEndReference();

			paraStrBldr = paras[1].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "Ddd ", m_ttpNormal);
			paraStrBldr.Replace(4, 4, "4", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "eee.", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "3", m_ttpChapter);
			paraStrBldr.Replace(10, 10, " Fff.", m_ttpNormal);
			paras[1].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[1].ParseStTxtPara(0, 15, 0);

			expectedRefs[0] = new int[] { 57002001, 57002001, 57002002, 57002003 };
			expectedRefs[1] = new int[] { 57002003, 57002004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 2, "2 ", m_ttpVerse);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(0, 2, 2);

			expectedRefs[0] = new int[] { 57001002, 57001002, 57001002, 57001003 };
			expectedRefs[1] = new int[] { 57001003, 57001004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			m_fdoCache.DatabaseAccessor.RollbackSavePoint(savePoint);
			m_fdoCache.VwCacheDaAccessor.ClearInfoAbout(paras[0].ownerHVO, true);

			// Change verse number to a chapter number: '2 xxx xxx' -> '2 xxx xxx'

			m_fdoCache.DatabaseAccessor.SetSavePoint(out savePoint);
			paras[0] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[0]);
			paras[0].GetSectionStartAndEndReference();

			paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "2 ", m_ttpVerse);
			paraStrBldr.Replace(2, 2, "Aaa Vvv", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "2", m_ttpVerse);
			paraStrBldr.Replace(10, 10, "bbb", m_ttpNormal);
			paraStrBldr.Replace(13, 13, "3", m_ttpVerse);
			paraStrBldr.Replace(14, 14, " ccc.", m_ttpNormal);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(0, 19, 0);

			paras[1] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[1]);
			paras[1].GetSectionStartAndEndReference();

			paraStrBldr = paras[1].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "Ddd ", m_ttpNormal);
			paraStrBldr.Replace(4, 4, "4", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "eee.", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "3", m_ttpChapter);
			paraStrBldr.Replace(10, 10, " Fff.", m_ttpNormal);
			paras[1].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[1].ParseStTxtPara(0, 15, 0);

			expectedRefs[0] = new int[] { 57001002, 57001002, 57001002, 57001003 };
			expectedRefs[1] = new int[] { 57001003, 57001004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 2, "2 ", m_ttpChapter);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(0, 2, 2);

			expectedRefs[0] = new int[] { 57002001, 57002001, 57002002, 57002003 };
			expectedRefs[1] = new int[] { 57002003, 57002004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			m_fdoCache.DatabaseAccessor.RollbackSavePoint(savePoint);
			m_fdoCache.VwCacheDaAccessor.ClearInfoAbout(paras[0].ownerHVO, true);

			// Change verse number to a different verse number: '2 xxx xxx' -> '3 xxx xxx'

			m_fdoCache.DatabaseAccessor.SetSavePoint(out savePoint);
			paras[0] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[0]);
			paras[0].GetSectionStartAndEndReference();

			paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "2 ", m_ttpVerse);
			paraStrBldr.Replace(2, 2, "Aaa Vvv", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "2", m_ttpVerse);
			paraStrBldr.Replace(10, 10, "bbb", m_ttpNormal);
			paraStrBldr.Replace(13, 13, "3", m_ttpVerse);
			paraStrBldr.Replace(14, 14, " ccc.", m_ttpNormal);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(0, 19, 0);

			paras[1] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[1]);
			paras[1].GetSectionStartAndEndReference();

			paraStrBldr = paras[1].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "Ddd ", m_ttpNormal);
			paraStrBldr.Replace(4, 4, "4", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "eee.", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "3", m_ttpChapter);
			paraStrBldr.Replace(10, 10, " Fff.", m_ttpNormal);
			paras[1].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[1].ParseStTxtPara(0, 15, 0);

			expectedRefs[0] = new int[] { 57001002, 57001002, 57001002, 57001003 };
			expectedRefs[1] = new int[] { 57001003, 57001004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 2, "5 ", m_ttpVerse);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(0, 2, 2);

			expectedRefs[0] = new int[] { 57001005, 57001005, 57001002, 57001003 };
			expectedRefs[1] = new int[] { 57001003, 57001004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			m_fdoCache.DatabaseAccessor.RollbackSavePoint(savePoint);
			m_fdoCache.VwCacheDaAccessor.ClearInfoAbout(paras[0].ownerHVO, true);

			// Change verse number at the end of a paragraph: 'xxx xxx 2' 'xxx' -> 'xxx xxx' '3xxx'

			m_fdoCache.DatabaseAccessor.SetSavePoint(out savePoint);
			paras[0] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[0]);
			paras[0].GetSectionStartAndEndReference();

			paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "2 ", m_ttpChapter);
			paraStrBldr.Replace(2, 2, "Aaa Vvv", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "2", m_ttpVerse);
			paraStrBldr.Replace(10, 10, "bbb", m_ttpNormal);
			paraStrBldr.Replace(13, 13, "3", m_ttpVerse);
			paraStrBldr.Replace(14, 14, " ccc.", m_ttpNormal);
			paraStrBldr.Replace(19, 19, "4", m_ttpChapter);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(0, 20, 0);

			paras[1] = new DummyScrTxtPara(m_fdoCache);
			stText.ParagraphsOS.Append(paras[1]);
			paras[1].GetSectionStartAndEndReference();

			paraStrBldr = paras[1].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "Ddd ", m_ttpNormal);
			paraStrBldr.Replace(4, 4, "4", m_ttpVerse);
			paraStrBldr.Replace(5, 5, "eee.", m_ttpNormal);
			paraStrBldr.Replace(9, 9, "3", m_ttpChapter);
			paraStrBldr.Replace(10, 10, " Fff.", m_ttpNormal);
			paras[1].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[1].ParseStTxtPara(0, 15, 0);

			expectedRefs[0] = new int[] { 57002001, 57002001, 57002002, 57002003 };
			expectedRefs[1] = new int[] { 57004001, 57004004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			paraStrBldr = paras[0].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(19, 20, "", m_ttpVerse);
			paras[0].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[0].ParseStTxtPara(19, 0, 1);
			paraStrBldr = paras[1].Contents.UnderlyingTsString.GetBldr();
			paraStrBldr.Replace(0, 0, "5", m_ttpChapter);
			paras[1].Contents.UnderlyingTsString = paraStrBldr.GetString();
			paras[1].ParseStTxtPara(0, 1, 0);

			expectedRefs[0] = new int[] { 57002001, 57002001, 57002002, 57002003 };
			expectedRefs[1] = new int[] { 57005001, 57005004, 57003001 };

			AssertTwficsAndReferences(paras, expectedRefs);

			m_fdoCache.DatabaseAccessor.RollbackSavePoint(savePoint);
			m_fdoCache.VwCacheDaAccessor.ClearInfoAbout(paras[0].ownerHVO, true);
		}
	}
}
