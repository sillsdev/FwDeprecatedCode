// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ScrTxtPara.cs
// Responsibility: BryanW
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.FDO.Scripture;
using SIL.FieldWorks.FDO.Scripture.Generated;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.Utils;
using FwCellar;

namespace SIL.FieldWorks.FDO
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Specialized <see cref="StTxtPara"/> that knows how to parse itself and apply 
	/// scripture references.
	/// </summary>
	/// <remarks>This class does not have a corresponding table in the database.</remarks>
	/// ----------------------------------------------------------------------------------------
	public class ScrTxtPara: StTxtPara
	{
		/// <summary>The type of paragraph (content, heading, title...)</summary>
		protected int m_nFlid;

		private LanguageProject m_lp;
		private ILgCharacterPropertyEngine m_lgCharPropEngineVern; 
		private uint intSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(int));

		private BCVRef m_SectRefStart;
		private BCVRef m_SectRefEnd;

		#region Constructors and initialization

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ScrTxtPara"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public ScrTxtPara()
		{
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ScrTxtPara"/> class.
		/// </summary>
		/// <param name="fcCache">The FDO cache object</param>
		/// -----------------------------------------------------------------------------------
		public ScrTxtPara(FdoCache fcCache): base()
		{
			m_cache = fcCache;
			Init();
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ScrTxtPara"/> class.
		/// </summary>
		/// <param name="fcCache">The FDO cache object</param>
		/// <param name="hvo">HVO of the new object</param>
		/// ------------------------------------------------------------------------------------
		public ScrTxtPara(FdoCache fcCache, int hvo)
			: base(fcCache, hvo) 
		{
			GetSectionStartAndEndReference();
			Init();
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ScrTxtPara"/> class.
		/// </summary>
		/// <param name="fcCache">The FDO cache object</param>
		/// <param name="hvo">HVO of the new object</param>
		/// <param name="sectRefStart">The start reference for the whole section</param>
		/// <param name="sectRefEnd">The end reference for the whole section</param>
		/// <remarks>You can use this constructor if you previously constructed a paragraph in 
		/// the same section.</remarks>
		/// ------------------------------------------------------------------------------------
		public ScrTxtPara(FdoCache fcCache, int hvo, BCVRef sectRefStart, BCVRef sectRefEnd)
			: base(fcCache, hvo) 
		{
			m_SectRefStart = sectRefStart;
			m_SectRefEnd = sectRefEnd;
			Init();
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializations that (almost) all constructors use
		/// </summary>
		/// ------------------------------------------------------------------------------------
		private void Init()
		{
			m_lp = m_cache.LanguageProject;

			// Get a default character property engine.
			// REVIEW SteveMc(TomB): We need the cpe for the primary vernacular encoding. What
			// should we be passing as the second param (i.e., the writing system)? For now,
			// 0 seems to work.
			m_lgCharPropEngineVern = (ILgCharacterPropertyEngine)
				m_cache.LanguagegEncodingFactoryAccessor.get_CharPropEngine(
				m_lp.DefaultVernacularEncoding, 0);
		}
		#endregion

		#region Properties
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Gets the starting BCV reference of the section this para is in.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public BCVRef SectRefStart
		{
			get
			{
				return m_SectRefStart;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Gets the ending BCV reference of the section this para is in.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public BCVRef SectRefEnd
		{
			get
			{
				return m_SectRefEnd;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Gets the <see cref="FdoCache"/>.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public FdoCache Cache
		{
			get 
			{
				return m_cache;
			}
		}

		#endregion

		#region Methods for interpreting text as chapter/verse numbers
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// This is a helper function to get a starting and ending verse number from a string
		/// which may or may not represent a verse bridge.
		/// </summary>
		/// 
		/// <param name="sVerseNum">the string representing the verse number(s).</param>
		/// <param name="nVerseStart">the starting verse number in sVerseNum.</param>
		/// <param name="nVerseEnd">the ending verse number in sVerseNum (will be different from
		/// startRef if sVerseNum represents a verse bridge).</param>
		/// ------------------------------------------------------------------------------------
		public void ExtractVerseNums(string sVerseNum, out int nVerseStart, out int nVerseEnd)
		{
			int nFactor = 1;
			int nVerseT = 0;
			nVerseStart = nVerseEnd = 0;
			// nVerseFirst is the left-most (or right-most if R2L) non-zero number found.
			int nVerseFirst = nVerseT;
			bool fVerseBridge = false;
			if (sVerseNum == null)
				return;
			// REVIEW JohnW (TomB): For robustness, our initial implementation will assume
			// that the first set of contiguous numbers is the starting verse number and
			// the last set of contiguous numbers is the ending verse number. This way, we
			// don't have to know what all the legal possibilities of bridge markers and
			// sub-verse segment indicators are.
			for (int i = sVerseNum.Length - 1; i >= 0; i--)
			{
				int numVal = -1;
				if (m_lgCharPropEngineVern.get_IsNumber(sVerseNum[i]))
				{
					numVal = m_lgCharPropEngineVern.get_NumericValue(sVerseNum[i]);
				}
				if (numVal >= 0 && numVal <= 9)
				{
					if (nFactor > 100) // verse number greater than 999
					{
						// REVIEW JohnW (TomB): Need to decide how we want to display this.
						nVerseT = 999;
					}
					else
					{
						nVerseT += nFactor * numVal;
						nFactor *= 10;
					}
					nVerseFirst = nVerseT;
				}
				else if (nVerseT > 0)
				{
					if (!fVerseBridge)
					{
						fVerseBridge = true;
						nVerseFirst = nVerseEnd = nVerseT;
					}
					nVerseT = 0;
					nFactor = 1;
				}
			}
			nVerseStart = nVerseFirst;
			if (!fVerseBridge)
			{
				nVerseEnd = nVerseFirst;
			}
			// Don't want to use an assertion for this because it could happen due to bad input data.
			// If this causes problems, just pick one ref and use it for both or something.
			// TODO TomB: Later, we need to catch this and flag it as an error.
			//Assert(nVerseStart <= nVerseEnd);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// This is a helper function to get a chapter number from a string.
		/// </summary>
		/// 
		/// <param name="sChapterNum">the string representing the chapter number.</param>
		/// <returns>The extracted chapter number as an integer value.</returns>
		/// ------------------------------------------------------------------------------------
		public int ExtractChapterNum(string sChapterNum)
		{
			int nFactor = 1;
			int nChapter = 0;
			int nSave = 0;
			if (sChapterNum == null)
				return 0;

			for (int i = sChapterNum.Length - 1; i >= 0; i--)
			{
				int numVal = -1;
				if (m_lgCharPropEngineVern.get_IsNumber(sChapterNum[i]))
				{
					numVal = m_lgCharPropEngineVern.get_NumericValue(sChapterNum[i]);
				}
				if (numVal >= 0 && numVal <= 9)
				{
					if (nFactor > 100) // chapter number greater than 999
					{
						// REVIEW JohnW (TomB): Need to decide how we want to display this.
						nChapter = 999;
					}
					else
					{
						nChapter += nFactor * numVal;
						nFactor *= 10;
					}
				}
				else
				{
					// non-number found; clear nChapter (but save a copy)
					if (nChapter > 0)
						nSave = nChapter;
					nChapter = 0;
					nFactor = 1;
				}
			}
			// in case of leading spaces, restore the number we found
			if (nChapter == 0 && nSave > 0)
				nChapter = nSave;

			return nChapter;
		}
		#endregion

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Determine the start and end reference for the section this paragraph belongs to.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		protected void GetSectionStartAndEndReference()
		{
			// Start by getting the start and end references from the section.
			m_SectRefStart = 0;
			m_SectRefEnd = 0;

			m_nFlid = m_cache.GetOwningFlidOfObject(ownerHVO);
			switch (m_nFlid)
			{
				case (int)BaseScrSection.ScrSectionTags.kflidContent:
				case (int)BaseScrSection.ScrSectionTags.kflidHeading:
				{
					int hvoScrSection = m_cache.GetOwnerOfObject(ownerHVO);
					int nSectRefStart = m_cache.GetIntProperty(hvoScrSection, 
						(int)BaseScrSection.ScrSectionTags.kflidVerseRefStart);
					int nSectRefEnd = m_cache.GetIntProperty(hvoScrSection,
						(int)BaseScrSection.ScrSectionTags.kflidVerseRefEnd);
					m_SectRefStart = new BCVRef(nSectRefStart);
					m_SectRefEnd = new BCVRef(nSectRefEnd);
					// Must have a non-zero book and chapter number and the end ref must not be
					// less than the start ref, unless data isn't loaded in the cache.
					if (nSectRefStart > 0 || nSectRefEnd > 0)
					{
						Debug.Assert(m_SectRefStart.Valid);
						Debug.Assert(m_SectRefEnd.Valid);
						Debug.Assert(m_SectRefStart <= m_SectRefEnd);
					}
					break;
				}
				case (int)BaseScrBook.ScrBookTags.kflidTitle:
				{
					ScrBook scrBook = new ScrBook(m_cache, m_cache.GetOwnerOfObject(ownerHVO));
					int hvoScrBookRef = scrBook.BookIdRAHvo;
					short nBook = (short)m_cache.GetIntProperty(hvoScrBookRef,
						(int)CmObjectFields.kflidCmObject_OwnOrd);
					m_SectRefStart = m_SectRefEnd = new BCVRef(nBook, 1, 0);
					break;
				}
				default:
					Debug.Assert(false); // Unexpected owning field for StText
					m_SectRefStart = m_SectRefEnd = new BCVRef();
					break;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Flags that show if verse and/or chapter are found
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Flags]
		public enum ChapterVerseFound
		{
			/// <summary>Nothing found</summary>
			None = 0,
			/// <summary>Verse was found</summary>
			Verse = 1,
			/// <summary>Chapter was found</summary>
			Chapter = 2
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Find the start and end reference at the end of this paragraph.
		/// </summary>
		/// <param name="refStart">[out] Start reference for the paragraph.</param>
		/// <param name="refEnd">[out] End reference for the paragraph.</param>
		/// <returns>A value of <see cref="ChapterVerseFound"/> that tells if a chapter and/or
		/// verse number was found in the paragraph.</returns>
		/// ------------------------------------------------------------------------------------
		protected ChapterVerseFound GetBCVRefAtEndOfPara(out BCVRef refStart, out BCVRef refEnd)
		{
			return GetBCVRefAtPosWithinPara(Contents.Text.Length, out refStart, out refEnd);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Find the start and end reference, by searching backwards in this paragraph from the
		/// given position.
		/// </summary>
		/// <param name="ivLim">Index of last character in paragraph where search begins 
		/// (backwards). If calling for a paragraph that was not edited, set 
		/// <paramref name="ivLim"/> to the length of the paragraph.
		/// </param>
		/// <param name="refStart">[out] Start reference for the paragraph.</param>
		/// <param name="refEnd">[out] End reference for the paragraph.</param>
		/// <returns>A value of <see cref="ChapterVerseFound"/> that tells if a chapter and/or
		/// verse number was found in this paragraph.</returns>
		/// 
		/// <remarks>If we're in the run that was edited, we can't consider any twfics beyond 
		/// the start of the edit because a verse number may have been deleted, which would 
		/// leave later TWFICS in this run with an old reference (which we are about to try to 
		/// replace with the new one).
		/// </remarks>
		/// ------------------------------------------------------------------------------------
		protected ChapterVerseFound GetBCVRefAtPosWithinPara(int ivLim, out BCVRef refStart, 
			out BCVRef refEnd)
		{
			refStart = new BCVRef();
			refEnd = new BCVRef();

			FwKernelLib.TsRunInfo tsi;
			ITsTextProps ttpRun;
			bool fGotVerse = false;
			ChapterVerseFound retVal = ChapterVerseFound.None;
			for (int ich = ivLim - 1; ich >= 0; ich--)
			{
				// Get props of current run.
				ttpRun = Contents.UnderlyingTsString.FetchRunInfoAt(ich, out tsi);
				// See if it is our verse number style.
				if (!fGotVerse && StStyle.IsStyle(ttpRun, StStyle.ScrVerseNumberStyleName))
				{
					// The whole run is the verse number. Extract it.
					string sVerseNum = Contents.Text.Substring(tsi.ichMin,
						tsi.ichLim - tsi.ichMin);
					int startVerse, endVerse;
					ExtractVerseNums(sVerseNum, out startVerse, out endVerse);
					refStart.Verse = startVerse;
					refEnd.Verse = endVerse;
					fGotVerse = true;
					retVal = ChapterVerseFound.Verse;
					// REVIEW TomB: Make sure this works. This seemed like a good
					// optimization, but it wasn't in the original WLC code.
					// If section doesn't cross chapter break, then we're done.
					// ANSWER (EberhardB): This doesn't work, because the section reference
					// might not be correct (right now they aren't updated at all).
					// This would result in wrong chapter numbers.
					//if (m_SectRefStart != null && 
					//	m_SectRefStart.Chapter == m_SectRefEnd.Chapter)
					//{
					//	Debug.Assert(m_SectRefStart.Book == m_SectRefEnd.Book);
					//	refStart.Book = refEnd.Book = m_SectRefStart.Book;
					//	refStart.Chapter = refEnd.Chapter = m_SectRefStart.Chapter;
					//	retVal |= ChapterVerseFound.Chapter;
					//	break;
					//}
				}
				// See if it is our chapter number style.
				else if (StStyle.IsStyle(ttpRun, StStyle.ScrChapterNumberStyleName))
				{
					// Assume the whole run is the chapter number. Extract it.
					string sChapterNum = Contents.Text.Substring(tsi.ichMin,
						tsi.ichLim - tsi.ichMin);
					int nChapter = ExtractChapterNum(sChapterNum);
					// REVIEW TomB: What if we get nChapter == 0? For now, let's pretend
					// we didn't see a chapter number style at all and just keep looking.
					if (nChapter > 0)
					{
						if (m_SectRefStart != 0)
							refStart.Book = refEnd.Book = m_SectRefStart.Book;

						refStart.Chapter = refEnd.Chapter = nChapter;

						if (fGotVerse)
						{
							// Found a chapter number to go with the verse number we
							// already found, so build the full reference using this
							// chapter with the previously found verse (already set).
							retVal |= ChapterVerseFound.Chapter;
						}
						else
						{
							// Found a chapter number but no verse number, so assume the
							// edited text is in verse 1 of the chapter.
							refStart.Verse = refEnd.Verse = 1;
							fGotVerse = true;
							retVal = ChapterVerseFound.Chapter | ChapterVerseFound.Verse;
						}
						break;
					}
				}
				else
				{
					// Review TeTeam: Would performance be better if we scanned all the runs in 
					// the paragraphs, and likely find a verse number, before we resort to 
					// looking up a TWFIC in the db?

					// Try to get the reference from a TWFIC in this run.
					int ichLim = tsi.ichLim;
					// If we're in the run that was edited, we can't consider any twfics
					// beyond the start of the edit because a verse number may have been
					// deleted, which would leave later TWFICS in this run with an old
					// reference (which we are about to try to replace with the new one).
					if (ivLim < tsi.ichLim)
					{
						ichLim = ivLim;
					}
					BCVRef twficRefstart, twficRefEnd;

					if (!TxtWordformInContext.GetReferenceFromTwfic(this, tsi.ichMin, ichLim, 
						out twficRefstart, out twficRefEnd))
					{
						// No TWFICS found in run, so keep looking backward.
						continue;
					}
					if (fGotVerse)
					{
						// Use only the book and chapter number of the references we just got.
						// Verse numbers have already been set.
						//if (m_SectRefStart != null)
						//	refStart.Book = refEnd.Book = m_SectRefStart.Book;

						// Twfics always contain the book number, so use that
						refStart.Book = refEnd.Book = twficRefstart.Book;
						refStart.Chapter = refEnd.Chapter = twficRefstart.Chapter;
						retVal |= ChapterVerseFound.Chapter;
						break;
					}
					else
					{
						// Use the references we just got.
						refStart = twficRefstart;
						refEnd = twficRefEnd;
						fGotVerse = true;
						retVal = ChapterVerseFound.Chapter | ChapterVerseFound.Verse;
						break;
					}
				}
				// move index (going backwards) to the Min of the run we just looked at
				ich = tsi.ichMin;
			}
			return retVal;
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Get the start and end reference of the specified position <paramref name="ivPos"/>
		/// in the paragraph.
		/// </summary>
		/// <param name="ivPos">Character offset in the paragraph.</param>
		/// <param name="refStart">[out] Start reference</param>
		/// <param name="refEnd">[out] End reference</param>
		/// <remarks><p><paramref name="refStart"/> and <paramref name="refEnd"/> are only 
		/// different if we have bridged verse numbers.</p>
		/// <p>They may not be complete or valid references if, for example, the section
		/// object does not have a valid start reference.</p></remarks>
		/// ------------------------------------------------------------------------------------
		protected void GetBCVRefAtPosition(int ivPos, out BCVRef refStart, out BCVRef refEnd)
		{
			refStart = 0;
			refEnd = 0;

			ChapterVerseFound found = ChapterVerseFound.None;
			ScrTxtPara para = this; // curent paragraph being examined for reference
			int ich = ivPos - 1; // index to step thru para contents
			int chvoParas = 0; // count of paragraphs in the section
			int ihvoPara = 0; // index of the paragraph within the section

			while (true)
			{
				if (para == this)
					found = para.GetBCVRefAtPosWithinPara(ivPos, out refStart, out refEnd);
				else
					found = para.GetBCVRefAtEndOfPara(out refStart, out refEnd);

				if (found == (ChapterVerseFound.Verse | ChapterVerseFound.Chapter))
					break; //we are done

				// We got to the beginning of the paragraph being edited and still haven't
				// found a decent reference for our edited text, so keep looking back to
				// get it from a previous paragraph.

				// First time thru, figure out which paragraph we are in
				// ENHANCE TomB: If we load ord numbers for paragraphs, we can avoid this loop.
				if (chvoParas == 0)
				{
					// REVIEW (EberhardB): does this work if not all paragraphs are 
					// loaded in the cache?
					chvoParas = m_cache.GetVectorSize(ownerHVO, 
						(int)BaseStText.StTextTags.kflidParagraphs);
					// Go forward through vector of paragraphs to find the one being parsed
					for (ihvoPara = 0; ihvoPara < chvoParas; ihvoPara++)
					{
						int hvoPara = m_cache.GetVectorItem(ownerHVO,
							(int)BaseStText.StTextTags.kflidParagraphs,	ihvoPara);
						if (hvoPara == hvo)
							break; // found our current para
					}
				}

				// Move to the previous paragraph
				ihvoPara--;

				if (ihvoPara < 0)
				{
					// We are at the beginning of the section. We can't look back any further.
					// ENHANCE TomB: If we search all the way through to the beginning of the
					// section and never get a valid reference, this section begins in the
					// middle of a verse or chapter (unlikely in the case of a verse, but
					// quite likely in the case of a chapter). OR (most likely) this edit 
					// happened at the very beginning of the section, and when we start 
					// parsing, the first thing we'll get is a decent reference.
					if ((found & ChapterVerseFound.Verse) == ChapterVerseFound.Verse)
					{
						// Use the verse we got previously (already set), along with the
						// first chapter for the section and the book.
						if (m_SectRefStart != 0)
						{
							refStart.Chapter = refEnd.Chapter = m_SectRefStart.Chapter;
							refStart.Book = refEnd.Book = m_SectRefStart.Book;
						}
					}
					else
					{
						// For now, we're just using the first verse for the section, but this
						// could be wrong if the section begins in the middle of a verse bridge
						// or misleading if the section just doesn't yet have verse numbers 
						// marked.
						refStart = refEnd = m_SectRefStart;
					}
					break; //we are done
				}

				// Set up for the previous paragraph in this section, and we'll try again
				int hvoNewPara = m_cache.GetVectorItem(ownerHVO,
					(int)BaseStText.StTextTags.kflidParagraphs, ihvoPara);
				// use a special constructor since we already know the section refs
				para = new ScrTxtPara(m_cache, hvoNewPara, para.SectRefStart,
					para.SectRefEnd);
				ich = para.Contents.Text.Length - 1;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		///	This is the main routine for actually parsing an StTxtPara: identify the words and
		/// insert character offsets and references into the TxtWordformInContext table. This is
		/// a private method intended for use by ParseNewStTxtPara and ParseStTxtPara.
		/// </summary>
		/// <param name="ichMin">ichMin index of first inserted character. If this is in the
		/// middle of a word, parsing will take this into account.</param>
		/// <param name="cchParse">number of characters inserted. This is the minimum number of
		/// characters to parse. Once we hit pchStart + ichMin + cchParse, we have to keep going
		/// until we hit the end of the current word.</param>
		/// <param name="ichDel">number of characters deleted.</param>
		/// <param name="startRef">Start verse reference to be used for any text up to the first
		/// chapter/verse change.</param>
		/// <param name="endRef">End verse reference to be used for any text up to the first
		/// chapter/verse change (will be different from start ref if this is a verse bridge).
		/// </param>
		/// <param name="fImporting">Hint to improve performance. Pass false if cache does not
		/// need to be updated with twfic information and PropChanged notifications should not
		///	be sent.</param>
		/// <param name="ihvoTwfic">0-based index of first TextWordformIncontext to be inserted
		/// (we will increment this every time we add a new relationship in the parsing loop)
		/// </param>
		/// ------------------------------------------------------------------------------------
		public void ParsePara(int ichMin, int cchParse, int ichDel, ref BCVRef startRef, 
			ref BCVRef endRef, bool fImporting, int ihvoTwfic)
		{
			ITsString tssPara = Contents.UnderlyingTsString;
			int ichParseLim = ichMin + cchParse;
			int ichParaLim = tssPara.get_Length();
			int ichStartParse = 0;
			FwKernelLib.TsRunInfo tsi;
			ITsTextProps ttpRun;
			string sPara = tssPara.get_Text();
			Debug.Assert(ichParseLim <= sPara.Length);

			if (ichMin > 0)
			{
				// When parsing only part of a paragraph, we can skip ahead to the beginning of
				// the run that contains the first inserted character (or the first character
				// after the deleted text, if no characters were inserted).
				tssPara.FetchRunInfoAt(ichMin, out tsi);
				// But if this is the very beginning of a run and characters were deleted, then
				// we need to back up to the previous run because characters may have been
				// deleted there.
				// REVIEW TomB: The above comment agrees with the following line of code, but it
				// is commented out. I think the comment needs to change, but first try to
				// confirm this if possible and document the reason we have to back up if we're
				// starting parsing at the very beginning of a run.
				//		if (ichMin == tsi.ichMin && ichDel > 0)
				if (ichMin == tsi.ichMin)
				{
					tssPara.FetchRunInfoAt(ichMin - 1, out tsi);		
				}
				ichStartParse = tsi.ichMin;
			}
		
			// Now we will look for sequences of word-forming characters.
			// TODO TomB: We need to limit the concordance to text in a particular encoding
			int ichStartWord = ichStartParse;
			bool fPrevCharInWord = false; // 1st char in run is potentially the start of a word
			tsi.ichLim = -1; // Force initial read of props for first char

			// Make an entry in the TxtWordformInContext table for each word in paragraph
			int ich;
			for (ich = ichStartParse; ich <= ichParseLim || fPrevCharInWord; ich++)
			{
				// If we're at the start of a run of text, get its properties. If it's a
				// "special" run, we will process it as a single element, and we may come back
				// around. If it's normal text, we'll fall out of this loop and let the outside
				// for loop handle character-by-character processing.
				while (ich >= tsi.ichLim)
				{
					// Get props of current run.
					ttpRun = tssPara.FetchRunInfoAt(ich, out tsi);
					// ENHANCE TomB: Finish this if-statement to determine if the new run can
					// legitimately continue a word in a previous run. If the language changes,
					// we have to regard it as a word break (and add a twfic for previous word
					// if needed -- though normally we would expect whitespace). Potentially,
					// some style changes may be able to occur mid-word; we'll have to see...
					if (fPrevCharInWord /* && this run-break amounts to a word-break */ )
					{
						// This is a run-break
						// Now add this word to the WFI if needed, and also create Twfic.
						string sWord = sPara.Substring(ichStartWord, ich - ichStartWord);
						TxtWordformInContext.AddWordformInContext(m_lp, sWord, hvo, 
							ichStartWord /* offset */, startRef, endRef, ihvoTwfic++ /* ord */,
							(ichMin == 0)? true : false /* at para end */, fImporting);
						fPrevCharInWord = false;
					}
					if (ich >= ichParaLim)
						return;

					if (StStyle.IsStyle(ttpRun, StStyle.ScrVerseNumberStyleName))
					{
						// If it is our verse number style, assume the whole run is the verse
						// number.
						string sVerseNum = sPara.Substring(ich, tsi.ichLim - tsi.ichMin);
						int nVerseStart, nVerseEnd;
						ExtractVerseNums(sVerseNum, out nVerseStart, out nVerseEnd);
						startRef.Verse = nVerseStart;
						endRef.Verse = nVerseEnd;
						ich += sVerseNum.Length;
						// Check for unusual case where paragraph ends with a verse number (this
						// should not happen with finished Scriptures, but it can happen with 
						// work in progress).
						if (ich > ichParseLim)
							return;
					}
					else if (StStyle.IsStyle(ttpRun, StStyle.ScrChapterNumberStyleName))
					{
						// If it is our chapter number style, assume the whole run is the
						// chapter number.
						string sChapterNum = sPara.Substring(ich, tsi.ichLim - tsi.ichMin);
						int nChapterT = ExtractChapterNum(sChapterNum);
						// REVIEW TomB: What if we get nChapterT == 0? For now, let's pretend
						// we didn't see a chapter number style at all and just keep looking.
						if (nChapterT > 0)
						{
							startRef.Chapter = endRef.Chapter = nChapterT;
							// Set the verse number to 1, since the first verse number after a
							// chapter is optional. If we happen to get a verse number in the
							// next run, this '1' will be overridden (though it will probably
							// still be a 1).
							startRef.Verse = endRef.Verse = 1;
						}
						ich += sChapterNum.Length;
						// Check for unusual case where paragraph ends with a chapter number 
						// (thisshould not happen with finished Scriptures, but it can happen 
						// with work in progress).
						if (ich > ichParseLim)
							return;
					}
					else
						break;
				}
				// If this is a word-forming character...
				if (m_lgCharPropEngineVern.get_IsWordForming(sPara[ich]))
				{
					if (!fPrevCharInWord)
					{
						ichStartWord = ich;
						fPrevCharInWord = true;
					}
				}
				else
				{
					if (fPrevCharInWord)
					{
						// We have found the end of the Word! It is from ichStartWord to ich.
						// Length is: ich - ichStartWord.
						// If its end is before the beginning of the edited portion, do nothing.
						if (ich >= ichMin)
						{
							// This is a regular word-break
							// Now add this word to the WFI if needed, and also create Twfic.
							string sWord = sPara.Substring(ichStartWord, ich - ichStartWord);
							TxtWordformInContext.AddWordformInContext(m_lp, sWord, hvo, 
								ichStartWord /* offset */, startRef, endRef, 
								ihvoTwfic++ /* ord */, 
								(ichMin == 0)? true : false /* at para end */, fImporting);
						}
						fPrevCharInWord = false;
					}
				}
			} // end of for (ich = ichStartParse...
		
			// If paragraph ends in a word (not followed by spaces or punctuation), add it
			if (fPrevCharInWord)
			{
				// These are the remaining characters
				string sWord = sPara.Substring(ichStartWord, ich - ichStartWord);
				TxtWordformInContext.AddWordformInContext(m_lp, sWord, hvo, 
					ichStartWord /* offset */, startRef, endRef, ihvoTwfic /* ord */,
					(ichMin == 0)? true : false /* at para end */, fImporting);
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Update references for any Twfics following edited portion of paragraph (this 
		/// could include twfics in subsequent paragraphs as well).
		/// </summary>
		/// <param name="ivMin">the starting character index where the change occurred.</param>
		/// <param name="cchIns">the number of characters inserted.</param>
		/// <param name="refStartStamp">Start reference</param>
		/// <param name="refEndStamp">End reference</param>
		/// ------------------------------------------------------------------------------------
		protected void PerformStamping(int ivMin, int cchIns, BCVRef refStartStamp, 
			BCVRef refEndStamp)
		{
			FwKernelLib.TsRunInfo tsi;
			ITsTextProps ttpRun;
			int hvoParaForNextTwfic, ichParaCharOffset, nScrRefStartTwfic, nScrRefEndTwfic;

			if (TxtWordformInContext.GetNextScrTwficInText(this, ivMin + cchIns, 
				out hvoParaForNextTwfic, out ichParaCharOffset, out nScrRefStartTwfic,
				out nScrRefEndTwfic))
			{
				BCVRef refStartTwfic = new BCVRef(nScrRefStartTwfic);
				BCVRef refEndTwfic = new BCVRef(nScrRefEndTwfic);
		
				StTxtPara para = this; // curent paragraph being examined for out-of-date twfics
				// These two variables remember where to stop doing verse AND chapter stamping.
				int hvoParaEndOfVerseStamping = 0;
				int ichLimEndOfVerseStamping = 0;
				// Index to step through paragraph contents is initialized to beginning of
				// the text after the edited stuff.
				int ich = ivMin + cchIns; 
				int chvoParas = 0; // ENHANCE TomB: Could try to reuse data calculated up above.
				int ihvoP = 0;
					
				// Done searching; don't need to stamp
				bool fDone = false;
				// Done searching; need to stamp some twfics
				bool fStartStamping = false;
				// Stamp some twfics using new verse AND chapter
				bool fDoVerseAndChapterStamping = true;
				// Stamp some twfics using the new chapter # only
				bool fChapterNumsOnly = false;
				// We've gotten to the run containing the twfic (but need to keep looking to
				// find the ending spot)
				bool fFoundTwfic = false;
				// The following line is required to keep the compiler from thinking we're
				// using uninitialized values further down.
				tsi.ichMin = tsi.ichLim = 0;
				while (!fDone && !fStartStamping)
				{
					// This while loop looks for the end of the twfics that need to have 
					// new reference stamps in the current paragraph. If it finds the end, 
					// then either fDone or fStartStamping is set to true, depending on 
					// whether anything actually needs to be stamped.
					while (ich < para.Contents.Text.Length)
					{
						// Get props of current run.
						ttpRun = para.Contents.UnderlyingTsString.FetchRunInfoAt(ich, 
							out tsi);
						// See if this is the run containing the ch
						if (!fFoundTwfic && para.hvo == hvoParaForNextTwfic &&
							tsi.ichLim > ichParaCharOffset)
						{
							fFoundTwfic = true;
						}
						else if (StStyle.IsStyle(ttpRun, StStyle.ScrVerseNumberStyleName))
						{
							// If not at the start of the run, we've already accounted for
							// this verse number (in PPAux), so skip it and keep looking.
							if (ich == tsi.ichMin)
							{
								if (!fFoundTwfic)
								{
									// This is the case where we find a new verse number 
									// BEFORE we get to the first post-edit TWFIC.
					
									// The whole run is the verse number.
									string sVerseNum = para.Contents.Text.Substring(
										tsi.ichMin, tsi.ichLim - tsi.ichMin);
									int nVerseStartStamp, nVerseEndStamp;
									ExtractVerseNums(sVerseNum, out nVerseStartStamp, 
										out nVerseEndStamp);
									if (nVerseStartStamp == refStartTwfic.Verse &&
										nVerseEndStamp == refEndTwfic.Verse)
									{
										// If the start/end chapter of the next TWFIC in the
										// text already matches the start/end "stamp" 
										// chapter, we're done.
										if (refStartTwfic.Chapter == refStartStamp.Chapter 
											&& refEndTwfic.Chapter == refStartStamp.Chapter)
										{
											fDone = true;
											break;
										}
										else
										{
											// For stamping, we'll use the new chapter number, but
											// the existing TWFIC verse numbers. We aren't done,
											// because there could yet be a chapter number change
											// before we get to the TWFIC, in which case we
											// wouldn't want to stamp at all.
											fDoVerseAndChapterStamping = false;
											fChapterNumsOnly = true;
										}
									}
									refStartStamp.Verse = nVerseStartStamp;
									refEndStamp.Verse = nVerseEndStamp;
								}
								else
								{
									// This is a verse number AFTER we've passed the first
									// post-edit TWFIC.
									// If the start/end chapter of the first post-edit TWFIC in the
									// text matched the start/end "stamp" chapter, we're done
									// searching, and can begin stamping twfics with new verse
									// and chapter numbers.
									if (!fChapterNumsOnly)
									{
										hvoParaEndOfVerseStamping = para.hvo;
										ichLimEndOfVerseStamping = tsi.ichMin;
									}
									if (refStartTwfic.Chapter == refStartStamp.Chapter &&
										refEndTwfic.Chapter == refEndStamp.Chapter)
									{
										fStartStamping = true;
										break;
									}
									else
									{
										// For stamping, we'll use chapter AND verse numbers for
										// all TWFICS up to this point, but only the new chapter
										// number for TWFICS AFTER this point (until we hit a
										// chapter change).
										fChapterNumsOnly = true;
									}
								}
							}
						}
						else if (StStyle.IsStyle(ttpRun, StStyle.ScrChapterNumberStyleName))
						{
							// If not at the start of the run, we've already accounted for
							// this chapter number (in PPAux), so skip it and keep looking.
							if (ich == tsi.ichMin)
							{
								if (!fFoundTwfic)
								{
									// This is the case where we find a new chapter number BEFORE
									// we get to the first post-edit TWFIC.
									fDone = true;
								}
								else
								{
									fStartStamping = true;
								}
								break;
							}
						}
						ich = tsi.ichLim;
					}
					if (fDone || fStartStamping)
						break;
					
					// We got to the end of the current paragraph and still haven't figured 
					// out the the extent of the twfics that need stamping, so get the next 
					// paragraph.
					// ENHANCE TomB: If we load ord numbers for paragraphs, we can avoid this loop.
					if (chvoParas == 0)
					{
						// REVIEW (EberhardB): does this work if not all paragraphs are 
						// loaded in the cache?
						chvoParas = m_cache.GetVectorSize(ownerHVO,
							(int)BaseStText.StTextTags.kflidParagraphs);
						// Go forward through vector of paragraphs to find the one being parsed
						for (; ihvoP < chvoParas; ihvoP++)
						{
							int hvoPara = m_cache.GetVectorItem(ownerHVO,
								(int)BaseStText.StTextTags.kflidParagraphs,	ihvoP);
							if (hvoPara == hvo)
								break;
						}
					}
					ihvoP++;
					if (ihvoP >= chvoParas)
					{
						// We've dealt with all the paragraphs in this text.
						// ENHANCE TomB: If we search all the way through to the end of the 
						// section and don't find a valid stopping place, something may need to 
						// be done to "push" the ending reference forward into the next section 
						// and/or we may want to reset the ending reference for this section.
						if (fFoundTwfic)
						{
							if (fChapterNumsOnly)
							{
								// tsi.ichMin is expected to be the beginning of the first run 
								// that does NOT get stamped, so fast-forward it.
								tsi.ichMin = tsi.ichLim;
							}
							else
							{
								hvoParaEndOfVerseStamping = para.hvo; 
								ichLimEndOfVerseStamping = tsi.ichLim;
							}
							fStartStamping = true;
						}
						else
						{
							// GetNextScrTwficInText should have returned false if there
							// were no twfics to stamp.
							Debug.Assert(fFoundTwfic);
							fDone = true;
						}
						break;
					}
					para = new StTxtPara(m_cache, m_cache.GetVectorItem(ownerHVO,
						(int)BaseStText.StTextTags.kflidParagraphs, ihvoP));
					ich = 0;
				}
				if (fStartStamping)
				{
					// We'd better be set up to do one or both kinds of stamping.
					Debug.Assert(fDoVerseAndChapterStamping || fChapterNumsOnly);
					TxtWordformInContext.UpdateTwficScrRefs(m_cache, 
						// References to use for stamping
						refStartStamp, refEndStamp,
						// Paragraph and character offset where stamping should begin
						hvoParaForNextTwfic, ichParaCharOffset,
						// Paragraph (if any) and offset where V & C stamping should end
						(fDoVerseAndChapterStamping? hvoParaEndOfVerseStamping : 0), 
						ichLimEndOfVerseStamping,
						// Paragraph (if any) and offset where C-only stamping should end
						(fChapterNumsOnly? para.hvo : 0), tsi.ichMin);
				}
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Parse a StTxtPara: identify the words and insert character offsets and references 
		/// into  the StTxtPara_AnalyzedTextObjects table.
		/// </summary>
		/// <param name="ivMin">the starting character index where the change occurred.</param>
		/// <param name="cchIns">the number of characters inserted.</param>
		/// <param name="cchDel">the number of characters deleted.</param>
		/// ------------------------------------------------------------------------------------
		public void ParseStTxtPara(int ivMin, int cchIns, int cchDel)
		{
			//#if DEBUG
			//	time(&startParseStTxtPara);
			//#endif
			
			// REVIEW JohnT (TomB): Is there any reason why this could happen? Should we do 
			// anything if it does?
			if (ivMin == 0 && cchIns == 0 && cchDel == 0)
				return;
			
			// Remove any existing StTxtPara_AnalyzedTextObjects relationships for the edited 
			// portion of this paragraph.
			int ihvoMin = TxtWordformInContext.RemoveEditedAnalyzedTextObjects(this, ivMin, 
				cchIns, cchDel);

			// Now get the starting reference for the edited text.
			BCVRef bbCccVvvStart = m_SectRefStart;
			BCVRef bbCccVvvEnd = m_SectRefEnd;
			
			int nFlid = m_cache.GetOwningFlidOfObject(ownerHVO);

			// If we are in the Content of a section, we have the starting and ending BCV's for 
			// the section, but we need to find the starting chapter and verse for the changed 
			// portion of this paragraph.
			// To find verse and chapter numbers, start at the place
			// in this paragraph where the editing starts and look backward toward the start of 
			// the paragraph. If it isn't found in this paragraph, keep searching backward 
			// through preceeding paragraphs until it's found.
			if (nFlid == (int)BaseScrSection.ScrSectionTags.kflidContent)
			{
				GetBCVRefAtPosition(ivMin, out bbCccVvvStart, out bbCccVvvEnd);

			}
			
			// This actually parses the stuff and creates the new TWFICS
			ParsePara(ivMin, cchIns, cchDel, ref bbCccVvvStart, ref bbCccVvvEnd, false, 
				ihvoMin);

			// REVIEW TomB: This whole section of code needs to be reviewed in light of
			// concurrent edits. What happens if user A edits the first paragraph in a section,
			// kicking off a series of reference updates that affects a subsequent paragraph,
			// but user B, meanwhile, edits one of those subsequent paragraphs? Will our current
			// locking strategy effectively block one of the users?

			// If we are in the Content of a section, update references for any Twfics following 
			// edited portion of paragraph (this could include twfics in subsequent paragraphs 
			// as well).
			if (nFlid == (int)BaseScrSection.ScrSectionTags.kflidContent)
			{
				PerformStamping(ivMin, cchIns, bbCccVvvStart, bbCccVvvEnd);
			}

			// TODO TomB: Eventually, when the section focus changes, we'll have to alert the
			// user if any twfics are out of range based on the stored section reference. That
			// will NOT be done here, but I'm putting the TODO here anyway.
		}
	}
}
