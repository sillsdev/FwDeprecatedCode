/*----------------------------------------------------------------------------------------------
Copyright (C) 2002 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: WfiWordform.cs
Responsibility: John Hatton
Last reviewed: never

	This file contains the following classes:
		WfiWordform 
----------------------------------------------------------------------------------------------*/

using System;
using SIL.FieldWorks.FDO;
using FwViews;
using SIL.FieldWorks.FDO.Ling.Generated;
using  SIL.FieldWorks.FDO.Cellar;
using  SIL.FieldWorks.FDO.Cellar.Generated;
using System.Diagnostics;


namespace SIL.FieldWorks.FDO.Ling
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Wordform Inventory Wordform class
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	public class WfiWordform : BaseWfiWordform
	{
		#region Construction
		/// ------------------------------------------------------------------------------------
		/// <summary xmlns:msxsl="urn:schemas-microsoft-com:xslt">
		/// Used for code like this foo.blah = new  WfiWordform().
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public WfiWordform() :base()
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary xmlns:msxsl="urn:schemas-microsoft-com:xslt">
		/// Constructor that creates a WfiWordform object based on an HVO in the database.
		/// </summary>
		/// <param name="fcCache">Represents DB connection</param>
		/// <param name="hvo">Id of the WfiWordform object in the DB</param>
		/// ------------------------------------------------------------------------------------
		public WfiWordform(FdoCache fcCache, int hvo) :base(fcCache, hvo)
		{
		}
		#endregion
	
		#region Custom Tags and Properties
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Custom tags (ScrBookRef)
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public enum CustTags: int
		{
			// TODO TomB: Need to come up with scheme to generate unique tags for each filter
			// in effect so that we can store the count based on the filter rules.
			// Probably need an array of filters owned by WfiWordform and methods to increment
			// and decrement all counts, given a twfic (based on whether the filter in effect
			// for the particular count includes the twfic being added or removed).
			/// <summary>Count of occurrences in (filtered) TxtWordformInContext table: Int
			/// </summary>
			ktagTwficCount = 5062999,
		};

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Count of occurrences in (filtered) TxtWordformInContext table
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public int TwficCount
		{
			get
			{		
				return m_cache.GetIntProperty(m_hvo, (int)CustTags.ktagTwficCount);
			}
			set
			{
				m_cache.VwCacheDaAccessor.CacheIntProp(m_hvo, (int)CustTags.ktagTwficCount,
					value);
			}
		}

		#endregion
		#region parsing related things

		/// <summary>
		/// get the date that they given agent last evaluated this Wordform.
		/// </summary>
		/// <param name="hvoAgent"></param>
		/// <returns></returns>
		public string GetLastEvaluationDate (int hvoAgent)
		{
			//Enhance (JohnH): we don't really need to load the whole CmEvaluation, 
			//	if we just used a SQL query we could just grab the date we need.

			CmAgentEvaluation evaluation =GetEvaluationFromAgent(hvoAgent);
			if (evaluation == null)
				return "not evaluated yet";
			else
			{
				DateTime dt = evaluation.DateCreated;
				string day;
				if(dt.Date == DateTime.Now.Date)
					day = "today at ";
				else
					day = dt.ToShortDateString();
				return day + dt.ToShortTimeString();
			}
		}

		/// <summary>
		/// get an agent's evaluation of this Wordform.
		/// </summary>
		/// <param name="hvoAgent"></param>
		/// <returns></returns>
		public CmAgentEvaluation GetEvaluationFromAgent (int hvoAgent)
		{
			CmAgent agent = new CmAgent (m_cache, hvoAgent);
			string query = "select id, class$ from CmAgentEvaluation_ where target=" +m_hvo.ToString()
				+" and owner$=" +hvoAgent.ToString();

			FdoObjectSet evaluations = new FdoObjectSet (m_cache,query,false);
			Debug.Assert( evaluations.Count < 2,  "program error: there should not be more than one evaluation on this Wordform from this agent.");
			return ( CmAgentEvaluation)evaluations.FirstItem;


		}
		#endregion
	}
}
