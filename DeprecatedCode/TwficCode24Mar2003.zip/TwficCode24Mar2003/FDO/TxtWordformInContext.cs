// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: TxtWordformInContext.cs
// Responsibility: BryanW
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.LangProj.Generated;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.FDO.Ling
{
	/// <summary>
	/// TxtWordformInContext class
	/// </summary>
	public class TxtWordformInContext: BaseTxtWordformInContext
	{
		/// <summary></summary>
		public static ITsStrFactory s_StringFactory;
		/// <summary>Dummy byte array used in parsing.</summary>
		// REVIEW (EberhardB): do we really need the formatting for TxtWordformInContext
		public static byte[] s_rgbVernFmt;
		/// <summary>Size of <see cref="s_rgbVernFmt"/>.</summary>
		public static int s_cbVernFmt;

		private static uint s_byteSize = 
			(uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(byte));
		private static uint s_intSize = 
			(uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(int));

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="TxtWordformInContext"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public TxtWordformInContext()
			:base() {}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="TxtWordformInContext"/> class.
		/// </summary>
		/// <param name="fcCache"></param>
		/// <param name="hvo"></param>
		/// ------------------------------------------------------------------------------------
		public TxtWordformInContext(FdoCache fcCache, int hvo)
			:base(fcCache, hvo) 
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Add WordformInContext to DB.
		/// </summary>
		/// <param name="lp">Language project whose WordformInventory should be searched
		/// and/or added to</param>
		/// <param name="sWord">Parsed word</param>
		/// <param name="hvoPara">HVO of paragraph being parsed</param>
		/// <param name="iOffset">Character offset where word occurs in paragraph</param>
		/// <param name="startRef">Starting verse reference for this occurrence of this word
		/// </param>
		/// <param name="endRef">Ending verse reference for this occurrence of this word (will be
		/// different from starting ref if it occurs in a bridge or section head section body
		/// that has not been broken into verses</param>
		/// <param name="iOrd">0-based index of where this word fits in the sequence of words in
		/// paragraph. To insert at the end of the paragraph, pass the Lim for the vector of
		/// twfics for this para.</param>
		/// <param name="fAtParaEnd">Hint to improve performance. Pass true if caller can
		/// guarantee that insertion is at end of paragraph (i.e., iOrd = Lim).</param>
		/// <param name="fImporting">Hint to improve performance. Pass true if cache does
		/// not need to be updated with twfic information and PropChanged notifications should
		/// not be sent.</param>
		/// ------------------------------------------------------------------------------------
		static public void AddWordformInContext(LanguageProject lp, string sWord, int hvoPara, 
			int iOffset, BCVRef startRef, BCVRef endRef, int iOrd, bool fAtParaEnd, 
			bool fImporting)
		{
			ITsString tssWord =	s_StringFactory.MakeString(sWord, lp.DefaultVernacularEncoding);
			FdoCache cache = lp.Cache;
		
			// TODO TomB: This logic needs to take into consideration the rules for dealing with
			// case. For now, we're just storing each different casing as a separate wordform.
			// This is probably okay. I think what we'll need is for each main window to have a
			// separate cache which is sorted, filtered, and smushed by case as required. In
			// other words, each node in that cache might represent more than one actual HVO if
			// smushing is in effect.
			int hvoWf = WordformInventory.FindOrCreateWordform(lp, sWord);
			// TODO TomB: Need to come up with scheme to generate unique tags for each filter
			// in effect so that we can store the count based on the filter rules.
			int cTwfic = cache.MainCacheAccessor.get_IntProp(hvoWf,
				(int)WfiWordform.CustTags.ktagTwficCount);
			cache.VwCacheDaAccessor.CacheIntProp(hvoWf,
				(int)WfiWordform.CustTags.ktagTwficCount, cTwfic + 1);
		
			// TODO BryanW: when sorted, the PropChanged needs to indicate the correct position.
			if (!fImporting)
			{
				cache.MainCacheAccessor.PropChanged(null,
					(int)FwViews.PropChangeType.kpctNotifyAll,
					lp.WordformInventoryOAHvo,
					(int)BaseWordformInventory.WordformInventoryTags.kflidWordforms,
					0, 1, 0);
			}
		
			// Now add the relationship between StTxtPara and AnalyzedTextObjects
			// with the character offset and Scripture reference.
			int hvoTwfic;
			string sSql;
			IOleDbCommand odc;
			cache.DatabaseAccessor.CreateCommand(out odc);
		
			// Form the SQL query
			int iOrdTemp = iOrd + 1;
//			int iOrdTemp;
//			if (fAtParaEnd)
//			{
//				// Note: we can't just assume the count of twfics is the last OwnOrd$, because
//				// there are holes in the sequence.
//				StTxtPara para = new StTxtPara(cache, hvoPara);
//				CmObject lastTwfic =
//					para.AnalyzedTextObjectsOS[para.AnalyzedTextObjectsOS.Count-1];
//				iOrdTemp = lastTwfic.OwnOrd + 1;
//			}
//			else
//			{
//				iOrdTemp = iOrd + 1;
//			}
			sSql = string.Format("exec CreateObj_TxtWordFormInContext {0}, {1}, '{2}', ?, " +
				"{3}, {4}, {5}, {6}, ? output", hvoPara, hvoWf, sWord.Replace("'", "''"),
				iOffset, startRef, endRef, iOrdTemp);
			// When importing, we always parse from beginning to end of paragraph, so we're 
			// always inserting at the end of sequence of twfics. So we can pass an optional 
			// flag to tell the stored procedure not to bother to look for trailing twfics 
			// whose Ord numbers might need to be incremented. This flag may also be true when
			// we're not importing, but just happen to be editing the end of the paragraph.
			if (fAtParaEnd)
				sSql += ", 1";

			// Set the parameters.
			odc.SetByteBuffParameter(1, (uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISINPUT,
				null, s_rgbVernFmt, s_byteSize * (uint)s_cbVernFmt);
			odc.SetParameter(2,	(uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISOUTPUT,
				null, (ushort)DBTYPEENUM.DBTYPE_I4, new uint[1] {0}, s_intSize);
		
			odc.ExecCommand(sSql, (int)FwDbAccess.SqlStmtType.knSqlStmtNoResults);
			bool fIsNull;
			ArrayPtr rgHvo = MarshalEx.ArrayToNative(1, typeof(uint));
			odc.GetParameter(2, rgHvo, s_intSize, out fIsNull);
			if (fIsNull)
			{
				System.Runtime.InteropServices.Marshal.ReleaseComObject(odc);
				throw new Exception("Invalid HVO returned from CreateObj_TxtWordFormInContext");
			}
			hvoTwfic = (int)((uint[])MarshalEx.NativeToArray(rgHvo, 1, typeof(uint)))[0];
			Debug.Assert(hvoTwfic > 0);
			System.Runtime.InteropServices.Marshal.ReleaseComObject(odc);

			if (!fImporting)
			{
				// Local variable to allow us to access the IDLImp versions of the data access
				// methods that only affect the in-memory cache, not the DB
				SIL.FieldWorks.Common.COMInterfaces.IVwCacheDa cacheOnly = cache.VwCacheDaAccessor;
				cacheOnly.CacheReplace(hvoPara,
					(int)BaseStTxtPara.StTxtParaTags.kflidAnalyzedTextObjects,
					iOrd, iOrd, // Insert into sequence at this position.
					new int[1] {hvoTwfic}, 1);
				cacheOnly.CacheStringProp(hvoTwfic,
					(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidForm,
					tssWord);
				cacheOnly.CacheObjProp(hvoTwfic,
					(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidAnalysis,
					hvoWf);
				cacheOnly.CacheIntProp(hvoTwfic,
					(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidParaCharOffset,
					iOffset);
				cacheOnly.CacheIntProp(hvoTwfic,
					(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidVerseRefStart,
					(int)startRef);
				cacheOnly.CacheIntProp(hvoTwfic,
					(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidVerseRefEnd,
					(int)endRef);
		
				// ENHANCE TomB (JohnT): we might make a somewhat more automatic way to get the back-ref
				// updated.
				cacheOnly.CacheReplace(hvoWf,
					(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidAnalysis,
					0, 0, // Insert into sequence at this position.
					new int[1] {hvoTwfic}, 1);
				cache.MainCacheAccessor.PropChanged(null,
					(int)FwViews.PropChangeType.kpctNotifyAll, hvoWf,
					(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidAnalysis, 0, 1, 0);
				cache.MainCacheAccessor.PropChanged(null,
					(int)FwViews.PropChangeType.kpctNotifyAll, hvoWf,
					(int)WfiWordform.CustTags.ktagTwficCount, 0, 0, 0);
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Get the next twfic for a Scripture text (i.e., Section Contents) based on a 
		/// Paragraph and a character offset. Return the next twfic after the given offset for 
		/// the paragraph, if any. If none, then get the first twfic in a subsequent paragraph 
		/// within the same text.
		/// </summary>
		/// <param name="para">Paragraph which was edited</param>
		/// <param name="ichPos">Character position to start looking for twfics</param>
		/// <param name="hvoParaForNextTwfic">[out] Paragraph containing the next TWFIC</param>
		/// <param name="ichParaCharOffset">[out] Character Offset of the next TWFIC</param>
		/// <param name="nScrRefStartTwfic">[out] Start Verse ref of the TWFIC</param>
		/// <param name="nScrRefEndTwfic">[out] End Verse ref of the TWFIC </param>
		/// <returns><c>true</c> if TWFIC is found.</returns>
		/// <remarks>
		/// Returns a TWFIC that is strictly greater than the given  offset. A twfic whose
		/// offset is exactly equal would have just been deleted and recreated with the
		/// correct reference.
		/// </remarks>
		/// ------------------------------------------------------------------------------------
		public static bool GetNextScrTwficInText(ScrTxtPara para, int ichPos, 
			out int hvoParaForNextTwfic, out int ichParaCharOffset, out int nScrRefStartTwfic,
			out int nScrRefEndTwfic)
		{
			bool fIsNull1, fIsNull2, fIsNull3, fIsNull4;		

			IOleDbCommand odc;
			para.Cache.DatabaseAccessor.CreateCommand(out odc);
			try
			{
				string sSql = string.Format(@"exec GetNextScrTwficInText {0}, {1}, {2}, 
					? output, ? output, ? output, ? output", para.ownerHVO, para.hvo, ichPos);

				odc.SetParameter(1, (uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISOUTPUT,
					null, (ushort)DBTYPEENUM.DBTYPE_I4, new uint[1] {0}, s_intSize);
				odc.SetParameter(2,	(uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISOUTPUT,
					null, (ushort)DBTYPEENUM.DBTYPE_I4, new uint[1] {0}, s_intSize);
				odc.SetParameter(3, (uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISOUTPUT,
					null, (ushort)DBTYPEENUM.DBTYPE_I4, new uint[1] {0}, s_intSize);
				odc.SetParameter(4,	(uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISOUTPUT,
					null, (ushort)DBTYPEENUM.DBTYPE_I4, new uint[1] {0}, s_intSize);

				odc.ExecCommand(sSql, (int)FwDbAccess.SqlStmtType.knSqlStmtNoResults);

				ArrayPtr rghvoParaForNextTwfic = MarshalEx.ArrayToNative(1, typeof(uint));
				odc.GetParameter(1, rghvoParaForNextTwfic, s_intSize, out fIsNull1);
				// HVO of paragraph containing the next TWFIC (the first twfic after the last
				// one that was just created as a result of parsing the edited portion).
				hvoParaForNextTwfic =
					(int)((uint[])MarshalEx.NativeToArray(rghvoParaForNextTwfic, 1,
					typeof(uint)))[0];
				ArrayPtr rgnParaCharOffset = MarshalEx.ArrayToNative(1, typeof(uint));
				odc.GetParameter(2, rgnParaCharOffset, s_intSize, out fIsNull2);
				// Character offset of the next TWFIC (the first twfic after the last one that
				// was just created as a result of parsing the edited portion). Note that this
				// may not be in the same paragraph (see param 1).
				ichParaCharOffset =
					(int)((uint[])MarshalEx.NativeToArray(rgnParaCharOffset, 1,
					typeof(uint)))[0];
				ArrayPtr rgnScrRefStartTwfic = MarshalEx.ArrayToNative(1, typeof(uint));
				odc.GetParameter(3, rgnScrRefStartTwfic, s_intSize, out fIsNull3);
				// The final two outputs are the EXISTING start and end references for the next
				// twfic that needs to be updated. We use these to help us find the end of the
				// out-of-date twfics, since we only need to modify the references of twfics
				// which:
				// * match exactly on the entire reference, OR
				// * match on the chapter if the chapter of the first updatable twfic is being
				//   changed.
				nScrRefStartTwfic =
					(int)((uint[])MarshalEx.NativeToArray(rgnScrRefStartTwfic, 1,
					typeof(uint)))[0];
				ArrayPtr rgnScrRefEndTwfic = MarshalEx.ArrayToNative(1, typeof(uint));
				odc.GetParameter(4, rgnScrRefEndTwfic, s_intSize, out fIsNull4);
				nScrRefEndTwfic =
					(int)((uint[])MarshalEx.NativeToArray(rgnScrRefEndTwfic, 1,
					typeof(uint)))[0];
			}
			catch(Exception e)
			{
				// rethrow
				throw e;
			}
			finally
			{
				System.Runtime.InteropServices.Marshal.ReleaseComObject(odc);
			}
			return !fIsNull1 && !fIsNull2 && !fIsNull3 && !fIsNull4;
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Updates the start/end references for twfics as needed following a change to the 
		/// paragraph contents, both in the database and in the cache.
		/// </summary>
		/// <param name="cache">FdoCache</param>
		/// <param name="refStart">Start reference to use for stamping</param>
		/// <param name="refEnd">End reference to use for stamping</param>
		/// <param name="hvoParaForNextTwfic">Paragraph where stamping should begin</param>
		/// <param name="ichParaCharOffset">Character offset where stamping should begin</param>
		/// <param name="hvoParaEndOfVerseStamping">Paragraph where V and C stamping should 
		/// end, or 0 for no V and C stamping.</param>
		/// <param name="ichLimEndOfVerseStamping">Character offset limit where V and C 
		/// stamping should end.</param>
		/// <param name="hvoParaEndOfCStamping">Paragraph where C-only stamping should end, or
		/// 0 for no C stamping.</param>
		/// <param name="ichLimEndOfCStamping">Character offset limit where C-only stamping 
		/// should end.</param>
		/// <remarks>Chapter only stamping also updates the book; it keeps the current verse
		/// numbers in the reference.</remarks>
		/// ------------------------------------------------------------------------------------
		public static void UpdateTwficScrRefs(FdoCache cache, BCVRef refStart, BCVRef refEnd, 
			int hvoParaForNextTwfic, int ichParaCharOffset, int hvoParaEndOfVerseStamping, 
			int ichLimEndOfVerseStamping, int hvoParaEndOfCStamping, int ichLimEndOfCStamping)
		{
			// Call Stored procedure to stamp TWFICs
			IOleDbCommand odc;
			cache.DatabaseAccessor.CreateCommand(out odc);
			try
			{
				string sSql = string.Format(
					@"exec UpdateTwficScrRefs {0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}",
					// References to use for stamping
					refStart, refEnd,
					// Paragraph and character offset where stamping should begin
					hvoParaForNextTwfic, ichParaCharOffset,
					// Paragraph (if any) and offset where V & C stamping should end
					hvoParaEndOfVerseStamping, ichLimEndOfVerseStamping,
					// Paragraph (if any) and offset where C-only stamping should end
					hvoParaEndOfCStamping, ichLimEndOfCStamping);

				odc.ExecCommand(sSql, (int)FwDbAccess.SqlStmtType.knSqlStmtStoredProcedure);
				odc.GetRowset(0);
				bool fMoreRows;
				uint cbSpaceTaken;
				int hvoTwficCur;
				bool fIsNull;
				uint uintSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(uint));
				// Process results to update m_cache.
				odc.NextRow(out fMoreRows);
				while (fMoreRows)
				{
					ArrayPtr rguint1 = MarshalEx.ArrayToNative(1, typeof(uint));
					odc.GetColValue(1, rguint1, uintSize, out cbSpaceTaken, out fIsNull, 0);
					hvoTwficCur = (int)((uint[])MarshalEx.NativeToArray(rguint1, 1, typeof(uint)))[0];
					Debug.Assert(hvoTwficCur > 0);
					// Check to see if this TWFIC is loaded in the m_cache. This returns S_FALSE
					// if the property is not loaded.
					bool fInCache;
					cache.VwCacheDaAccessor.get_CachedIntProp(hvoTwficCur,
						(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidVerseRefStart,
						out fInCache);
					// If the value isn't in the m_cache at all, we don't need to fix it.
					if (fInCache)
					{
						// If this TWFIC is in the m_cache, update it and notify all views.
						rguint1 = MarshalEx.ArrayToNative(1, typeof(uint));
						odc.GetColValue(2, rguint1, uintSize, out cbSpaceTaken, out fIsNull, 0);
						BCVRef refStartTwfic = new BCVRef((int)((uint[])MarshalEx.NativeToArray(
							rguint1, 1, typeof(uint)))[0]);
						Debug.Assert(refStartTwfic.Book == refStart.Book);
						Debug.Assert(refStartTwfic.Valid);
						rguint1 = MarshalEx.ArrayToNative(1, typeof(uint));
						odc.GetColValue(3, rguint1, uintSize, out cbSpaceTaken, out fIsNull, 0);
						BCVRef refEndTwfic = new BCVRef((int)((uint[])MarshalEx.NativeToArray(
							rguint1, 1, typeof(uint)))[0]);
						Debug.Assert(refEndTwfic.Book == refStartTwfic.Book);
						Debug.Assert(refEndTwfic.Valid);
								
						cache.VwCacheDaAccessor.CacheIntProp(hvoTwficCur,
							(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidVerseRefStart,
							(int)refStartTwfic);
						cache.PropChanged(null, FwViews.PropChangeType.kpctNotifyAll, hvoTwficCur, 
							(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidVerseRefStart,
							0, 0, 0);
						cache.VwCacheDaAccessor.CacheIntProp(hvoTwficCur,
							(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidVerseRefEnd,
							(int)refEndTwfic);
						cache.PropChanged(null, FwViews.PropChangeType.kpctNotifyAll, hvoTwficCur, 
							(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidVerseRefEnd,
							0, 0, 0);
					}
					odc.NextRow(out fMoreRows);
				}
			}
			catch(Exception e)
			{
				throw e;
			}
			finally
			{
				System.Runtime.InteropServices.Marshal.ReleaseComObject(odc);
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Get the affected range of TWFiCs.
		/// </summary>
		/// <param name="para">Paragraph</param>
		/// <param name="ivMin">Character offset</param>
		/// <param name="cchDel">Number of deleted characters</param>
		/// <param name="ihvoMin">[out] First effected TWFIC hvo</param>
		/// <param name="ihvoLim">[out] First TWFIC hvo after the edited text.</param>
		/// <returns><c>true</c> if changed twfics found.</returns>
		/// ------------------------------------------------------------------------------------
		public static bool GetRgChangedTwfics(ScrTxtPara para, int ivMin, int cchDel, 
			out int ihvoMin, out int ihvoLim)
		{
			bool fIsNull1, fIsNull2;
			IOleDbCommand odc;
			para.Cache.DatabaseAccessor.CreateCommand(out odc);
			try
			{
				string sSql = string.Format(
					"exec GetRgChangedTwfics {0}, {1}, {2}, ? output, ? output", 
					para.hvo, ivMin, cchDel);
				odc.SetParameter(1, (uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISOUTPUT,
					null, (ushort)DBTYPEENUM.DBTYPE_I4, new uint[1] {0}, s_intSize);
				odc.SetParameter(2,	(uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISOUTPUT,
					null, (ushort)DBTYPEENUM.DBTYPE_I4, new uint[1] {0}, s_intSize);
				odc.ExecCommand(sSql, (int)FwDbAccess.SqlStmtType.knSqlStmtNoResults);
				ArrayPtr rgHvoMinIndex = MarshalEx.ArrayToNative(1, typeof(uint));
				odc.GetParameter(1, rgHvoMinIndex, s_intSize, out fIsNull1);
				ihvoMin = (int)((uint[])MarshalEx.NativeToArray(rgHvoMinIndex, 1, typeof(uint)))[0];
				ArrayPtr rgHvoLimIndex = MarshalEx.ArrayToNative(1, typeof(uint));
				odc.GetParameter(2, rgHvoLimIndex, s_intSize, out fIsNull2);
				ihvoLim = (int)((uint[])MarshalEx.NativeToArray(rgHvoLimIndex, 1, typeof(uint)))[0];
			}
			catch(Exception e)
			{
				throw e;
			}
			finally
			{
				System.Runtime.InteropServices.Marshal.ReleaseComObject(odc);
			}
			return !fIsNull1 && !fIsNull2;
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Remove any existing StTxtPara_AnalyzedTextObjects relationships for the edited 
		/// portion of this paragraph.
		/// </summary>
		/// <param name="para">The paragraph</param>
		/// <param name="ivMin">the starting character index where the change occurred.</param>
		/// <param name="cchIns">the number of characters inserted.</param>
		/// <param name="cchDel">the number of characters deleted.</param>
		/// <returns>0-based index of first deleted TextWordformIncontext</returns>
		/// ------------------------------------------------------------------------------------
		public static int RemoveEditedAnalyzedTextObjects(ScrTxtPara para, int ivMin, int cchIns, 
			int cchDel)
		{
			int chvoTwfic = para.AnalyzedTextObjectsOS.Count;
		
			// set ihvoMin and ihvoLim to bracket the changed portion of the paragraph, so we can
			// delete now bogus TWFICs
			int ihvoMin;
			int ihvoLim;

			bool fRet = TxtWordformInContext.GetRgChangedTwfics(para, ivMin, cchDel, 
				out ihvoMin, out ihvoLim);
			if (!fRet || ihvoMin < 0 || ihvoLim < ihvoMin)
			{
				// Something odd has happened, so discard all twfics and reparse entire paragraph.
				ihvoMin = 0;
				ihvoLim = chvoTwfic;
			}
			else if (cchIns != cchDel && ihvoLim < chvoTwfic)
			{
				// Adjust (in the DB) the paragraph offsets of all the Twfics after the edited
				// portion.
				int cchAdj = cchIns - cchDel;
				IOleDbCommand odc;
				para.Cache.DatabaseAccessor.CreateCommand(out odc);
				try
				{
					string sSql = string.Format("exec AdjustTwficOffsets {0}, {1}, {2}", 
						para.hvo, (ivMin + cchDel), cchAdj);
					odc.ExecCommand(sSql, (int)FwDbAccess.SqlStmtType.knSqlStmtNoResults);
				}
				catch(Exception e)
				{
					throw e;
				}
				finally
				{
					System.Runtime.InteropServices.Marshal.ReleaseComObject(odc);
				}

				// Now fix the cached character offset values in the TWFIC table.
				for (int ihvo = ihvoLim; ihvo < chvoTwfic; ihvo++)
				{
					int hvoTwfic = para.AnalyzedTextObjectsOS[ihvo].hvo;
					bool fInCache;
					int kflidParaCharOffset =
						(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidParaCharOffset;
					int ichParaOffset = para.Cache.VwCacheDaAccessor.get_CachedIntProp(hvoTwfic,
						kflidParaCharOffset, out fInCache);
					// If the value isn't in the para.Cache at all, we don't need to fix it.
					if (fInCache)
					{
						para.Cache.VwCacheDaAccessor.CacheIntProp(hvoTwfic, kflidParaCharOffset,
							ichParaOffset + cchAdj);
						para.Cache.PropChanged(null, FwViews.PropChangeType.kpctNotifyAll, hvoTwfic,
							kflidParaCharOffset, 0, 0, 0);
					}
				}
			}

			// now remove the range of changed TWFICS
			for (int ihvo = ihvoMin; ihvo < ihvoLim; ihvo++)
			{
				// We're deleting from the beginning, so just keep deleting the Min hvo.
				int hvoTwfic = para.AnalyzedTextObjectsOS[ihvoMin].hvo;
				TxtWordformInContext twfic = new TxtWordformInContext(para.Cache, hvoTwfic);
				
				// Note: We do NOT want to create an FDO object to represent the wordform,
				// because we only want to fix any of its properties already in the para.Cache.
				int hvoWordform = twfic.AnalysisRAHvo;
				// I don't think this should ever happen, but if it does, it's probably
				// no big deal. If it does, try to figure out why. If there's a real
				// problem, fix it. Otherwise, remove this ASSERT and add a condition here to
				// not attempt to fix the para.Cache if hvoWordform == 0.
				Debug.Assert(hvoWordform > 0);
					
				// Actually blow away the twfic (from DB and para.Cache)
				// TODO TomB: Need to create a stored proc to do this so we can also blow away
				// the wordform if it has no other twfics and only has default values set for
				// its other properties. Need to return a boolean parameter to tell us if the
				// wordform was trashed. If so, then we need to remove it from the FW para.Cache and
				// also from FDO hashmap of wordforms to HVOs.
				twfic.DeleteUnderlyingObject();
				twfic = null;

				// Delete from the para.Cache the wordform's back-reference for the
				// TxtWordformInContext object we just blew away.
				int kflidAnalysis =
					(int)BaseTxtWordformInContext.TxtWordformInContextTags.kflidAnalysis;
				int chvoTwficForWordform = para.Cache.GetVectorSize(hvoWordform, kflidAnalysis);
				for (int ihvoTwfic = 0; ihvoTwfic < chvoTwficForWordform; ihvoTwfic++)
				{
					if (hvoTwfic == para.Cache.GetVectorItem(hvoWordform, kflidAnalysis, ihvoTwfic))
					{
						para.Cache.VwCacheDaAccessor.CacheReplace(hvoWordform, kflidAnalysis,
							ihvoTwfic, ihvoTwfic + 1, // Delete from sequence at this position.
							null, 0);
						para.Cache.PropChanged(null, FwViews.PropChangeType.kpctNotifyAll, hvoWordform,
							kflidAnalysis, ihvoTwfic, 0, 1);
						break;
					}
				}

				// Decrement the wordform's twfic count in the para.Cache. Note: this could be
				// different fromt the above count based on the vector size, because the
				// above is based on the number of twfics actually loaded in the para.Cache for
				// the wordform, while this number is the total number of extant twfics,
				// including those not loaded in the para.Cache.
				chvoTwficForWordform = para.Cache.GetIntProperty(hvoWordform,
					(int)WfiWordform.CustTags.ktagTwficCount);
				if (chvoTwficForWordform > 0)
				{
					chvoTwficForWordform--;
					para.Cache.VwCacheDaAccessor.CacheIntProp(hvoWordform,
						(int)WfiWordform.CustTags.ktagTwficCount, chvoTwficForWordform);
					para.Cache.PropChanged(null, FwViews.PropChangeType.kpctNotifyAll, hvoWordform, 
						(int)WfiWordform.CustTags.ktagTwficCount, 0, 0, 0);
				}
			}

			return ihvoMin;
		}
	
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Get a reference from any TWFIC in this run of this paragraph.
		/// </summary>
		/// <param name="para">The paragraph</param>
		/// <param name="ichMin">Index of first character of the run</param>
		/// <param name="ichLim">Index of last character of the run</param>
		/// <param name="refStart">[out] Start reference for the part of the paragraph.</param>
		/// <param name="refEnd">[out] End reference for the part of the paragraph.<p>
		/// The ending verse number will be different from refStart only if this run is for a
		/// verse bridge).</p></param>
		/// <returns><c>true</c> if references are found, <c>false</c> otherwise.</returns>
		/// ------------------------------------------------------------------------------------
		public static bool GetReferenceFromTwfic(ScrTxtPara para, int ichMin, int ichLim, 
			out BCVRef refStart, out BCVRef refEnd)
		{
			refStart = refEnd = 0;

			IOleDbCommand odc;
			bool fIsNull1, fIsNull2;
			int nScrRefStart = 0;
			int nScrRefEnd = 0;
			para.Cache.DatabaseAccessor.CreateCommand(out odc);
			try
			{
				string sSql = string.Format(
					"exec GetScrRefsForRun {0}, {1}, {2}, ? output, ? output", para.hvo, ichMin, 
					ichLim);
				odc.SetParameter(1, (uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISOUTPUT,
					null, (ushort)DBTYPEENUM.DBTYPE_I4, new uint[1] {0}, s_intSize);
				odc.SetParameter(2,	(uint)DBPARAMFLAGSENUM.DBPARAMFLAGS_ISOUTPUT,
					null, (ushort)DBTYPEENUM.DBTYPE_I4, new uint[1] {0}, s_intSize);

				odc.ExecCommand(sSql, (int)FwDbAccess.SqlStmtType.knSqlStmtNoResults);

				ArrayPtr rgnStartRef = MarshalEx.ArrayToNative(1, typeof(uint));
				odc.GetParameter(1, rgnStartRef, s_intSize, out fIsNull1);
				nScrRefStart = (int)((uint[])MarshalEx.NativeToArray(rgnStartRef, 1, typeof(uint)))[0];
				ArrayPtr rgEndRef = MarshalEx.ArrayToNative(1, typeof(uint));
				odc.GetParameter(2, rgEndRef, s_intSize, out fIsNull2);
				nScrRefEnd = (int)((uint[])MarshalEx.NativeToArray(rgEndRef, 1, typeof(uint)))[0];
			}
			catch(Exception e)
			{
				throw e;
			}
			finally
			{
				System.Runtime.InteropServices.Marshal.ReleaseComObject(odc);
			}

			if (fIsNull1 || fIsNull2)
				return false;

			refStart = new BCVRef(nScrRefStart);
			refEnd = new BCVRef(nScrRefEnd);
			Debug.Assert(refStart.Valid && refEnd.Valid &&
				refStart.Book == refEnd.Book &&
				refStart.Chapter == refEnd.Chapter);
			return true;
		}

	}
}
