/***********************************************************************************************
	Final model creation processes for the Scripture domain.

	Note: These declarations need to be ordered, such that if stored procedure X
	calls stored procedure Y, then X should be created first, then Y.
	Doing this avoids an error message about dendencies.
***********************************************************************************************/

print '****************************** Loading ScriptureSP.sql ******************************'
go


IF EXISTS (SELECT * 
	   FROM   sysobjects 
	   WHERE  name = 'UpdateTwficScrRefs') 
    DROP PROCEDURE UpdateTwficScrRefs
GO
print 'creating proc UpdateTwficScrRefs'
go
/*****************************************************************************
 * UpdateTwficScrRefs
 *
 * Description: Updates the start/end references for twfics as needed
 * following a change to the paragraph contents.
 *
 * Parameters:
 * 
 *	nBbCccVvvStart		References to use for stamping
 *	nBbCccVvvEnd
 *	hvoParaForNextTwfic	Paragraph and
 *	ichMinParaCharOffset	  character offset where stamping should begin
 *	hvoParaEndOfVStamping	Paragraph (if any) and
 *	ichLimEndOfVStamping	  offset where V & C stamping should end
 *	hvoParaEndOfCStamping	Paragraph (if any) and
 *	ichLimEndOfCStamping	  offset where C-only stamping should end
 *		
 * Returns: Error code if an error occurs
 *	    Returns a result set with one row for each updated TWFIC with the
 *	    following columns:
 *		hvoTwfic
 *		VerseRefStart (a BCV value)
 *		VerseRefEnd (a BCV value)
 *
 *****************************************************************************/
CREATE PROCEDURE UpdateTwficScrRefs
	@nBbCccVvvStart		int,
	@nBbCccVvvEnd		int,
	@hvoParaForNextTwfic	int,
	@ichMinParaCharOffset	int,
	@hvoParaEndOfVStamping	int,
	@ichLimEndOfVStamping	int,
	@hvoParaEndOfCStamping	int,
	@ichLimEndOfCStamping	int
AS
	DECLARE @nTrnCnt int, @sTranName varchar(50), @fIsNocountOn int, @hvoText int, @StartOrd int, @EndOrd int,
		@nBook int, @nChapterStart int, @nChapterEnd int, @hvoParaStart int, @ichMin int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'UpdateTwficScrRefs_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Create Temp table to prepare for update and return results
	DECLARE @NewTwficScrRefs table
		(
		hvoTwfic int,
		VerseRefStart int,
		VerseRefEnd int
		)
	-- Fill in the temp table

	-- Handle Verse & Chapter updates
	if @hvoParaEndOfVStamping > 0
	begin
		-- Get any twfics of the edited paragraph that need to be updated
		if @ichMinParaCharOffset > 0
		begin
			insert into @NewTwficScrRefs
			select	[Id], @nBbCccVvvStart, @nBbCccVvvEnd
			from	TxtWordFormInContext_ (readuncommitted)
			where	Owner$ = @hvoParaForNextTwfic
			and	ParaCharOffset >= @ichMinParaCharOffset
			and	(@hvoParaForNextTwfic <> @hvoParaEndOfVStamping
			or	ParaCharOffset < @ichLimEndOfVStamping)
		end
		-- Get any twfics from subsequent paragraphs that need to be updated
		if @hvoParaForNextTwfic <> @hvoParaEndOfVStamping
		begin

			select	@hvoText = Owner$,
				@StartOrd = OwnOrd$
			from	StTxtPara_ (readuncommitted)
			where	[Id] = @hvoParaForNextTwfic

			select @EndOrd = OwnOrd$
			from	StTxtPara_ (readuncommitted)
			where	[Id] = @hvoParaEndOfVStamping

			insert into @NewTwficScrRefs
			select	t.[Id], @nBbCccVvvStart, @nBbCccVvvEnd
			from	TxtWordFormInContext_ t (readuncommitted)
			join	StTxtPara_ p (readuncommitted) on p.[id] = t.Owner$
			and	p.Owner$ = @hvoText
			and	p.OwnOrd$ > @StartOrd
			and	p.OwnOrd$ <= @EndOrd
			where	(t.Owner$ <> @hvoParaEndOfVStamping
			or	ParaCharOffset < @ichLimEndOfVStamping)
		end
	end
	-- Handle Chapter-only updates
	if @hvoParaEndOfCStamping > 0
	begin
		set @nBook = @nBbCccVvvStart / 1000000
		set @nChapterStart = @nBbCccVvvStart / 1000 - @nBook * 1000
		set @nChapterEnd = @nBbCccVvvEnd / 1000 - @nBook * 1000

		if @hvoParaEndOfVStamping > 0
		begin
			set @hvoParaStart = @hvoParaEndOfVStamping
			set @ichMin = @ichLimEndOfVStamping
		end
		else
		begin
			set @hvoParaStart = @hvoParaForNextTwfic
			set @ichMin = @ichMinParaCharOffset
		end

		-- Get any twfics of the edited paragraph that need to be updated
		if @ichMinParaCharOffset > 0
		begin
			insert into @NewTwficScrRefs
			select	[Id],
				@nBook * 1000000 + @nChapterStart * 1000 + (VerseRefStart - ((VerseRefStart / 1000) * 1000)),
				@nBook * 1000000 + @nChapterEnd * 1000 + (VerseRefEnd - ((VerseRefEnd / 1000) * 1000))
			from	TxtWordFormInContext_ (readuncommitted)
			where	Owner$ = @hvoParaForNextTwfic
			and	ParaCharOffset >= @ichMin
			and	(@hvoParaStart <> @hvoParaEndOfCStamping
			or	ParaCharOffset < @ichLimEndOfCStamping)
		end
		-- Get any twfics from subsequent paragraphs that need to be updated
		if @hvoParaStart <> @hvoParaEndOfCStamping
		begin
			select	@hvoText = Owner$,
				@StartOrd = OwnOrd$
			from	StTxtPara_ (readuncommitted)
			where	[Id] = @hvoParaStart

			select @EndOrd = OwnOrd$
			from	StTxtPara_ (readuncommitted)
			where	[Id] = @hvoParaEndOfCStamping

			insert into @NewTwficScrRefs
			select	t.[Id],
				@nBook * 1000000 + @nChapterStart * 1000 + (VerseRefStart - ((VerseRefStart / 1000) * 1000)),
				@nBook * 1000000 + @nChapterEnd * 1000 + (VerseRefEnd - ((VerseRefEnd / 1000) * 1000))
			from	TxtWordFormInContext_ t (readuncommitted)
			join	StTxtPara_ p (readuncommitted) on p.[id] = t.Owner$
			and	p.Owner$ = @hvoText
			and	p.OwnOrd$ > @StartOrd
			and	p.OwnOrd$ <= @EndOrd
			where	(t.Owner$ <> @hvoParaEndOfCStamping
			or	ParaCharOffset < @ichLimEndOfCStamping)
		end
	end		

	-- Do the adjustment
	update	TxtWordformInContext
	set	VerseRefStart = new.VerseRefStart,
		VerseRefEnd = new.VerseRefEnd
	from	@NewTwficScrRefs new
	where	[Id] = new.hvoTwfic

	-- Pass back results so the caller can update the cache
	select * from @NewTwficScrRefs

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName

	return 0
GO

if exists (select *
             from sysobjects
            where name = 'GetSectionScrRefsFromTwfics')
	drop proc GetSectionScrRefsFromTwfics
go
print 'creating proc GetSectionScrRefsFromTwfics'
go
/*****************************************************************************
 * GetSectionScrRefsFromTwfics
 *
 * Description: Get the min and max reference for the section based on the
 * TWFICS.  
 *
 * Parameters:
 *	hvoSection	Id of section
 *	nBbCccVvvMin	Lowest reference for section - output
 *	nBbCccVvvMax	Highest reference for section - output
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc GetSectionScrRefsFromTwfics
	@hvoSection	int,
	@nBbCccVvvMin	int = null output,
	@nBbCccVvvMax	int = null output
as
	select	@nBbCccVvvMin = Min(VerseRefStart),
		@nBbCccVvvMax = Max(VerseRefEnd)
	from TxtWordFormInContext_ C (readuncommitted)
	join StTxtPara_ P (readuncommitted) on c.owner$ = p.id and p.ownflid$ = 14001
	join StText_ T (readuncommitted) on p.owner$ = t.id and t.ownflid$ = 3005002 and t.owner$ = @hvoSection
	where c.ownflid$ = 16005
GO

if exists (select *
             from sysobjects
            where name = 'GetNextScrTwficInText')
	drop proc GetNextScrTwficInText
go
print 'creating proc GetNextScrTwficInText'
go
/*****************************************************************************
 * GetNextScrTwficInText
 *
 * Description: Get the next twfic for a Scripture text (i.e., Section
 * Contents) based on a Paragraph hvo and a character offset. Return the next
 * twfic after* the given offset for the paragraph, if any. If none, then
 * get the first twfic in a subsequent paragraph within the same text.
 * *We want a TWFIC that is strictly greater than the given offset. A twfic
 * whose offset is exactly equal would have just been deleted and recreated with
 * the correct reference.
 *
 * Parameters:
 *	hvoStText	Id of text
 *	hvoPara		Id of paragraph
 *	ichPos		Character position to start looking for twfics
 *	hvoTwficPara	Paragraph containing the next TWFIC - output
 *	ichParaOffset	Character Offset of the next TWFIC - output
 *	nVerseRefStart	Start Verse ref of the TWFIC - output
 *	nVerseRefEnd	End Verse ref of the TWFIC - output
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc GetNextScrTwficInText
	@hvoStText	int,
	@hvoPara	int,
	@ichPos		int,
	@hvoTwficPara	int = null output,
	@ichParaOffset	int = null output,
	@nVerseRefStart	int = null output,
	@nVerseRefEnd	int = null output
as
	select	@hvoTwficPara = Owner$,
		@ichParaOffset = paracharoffset,
		@nVerseRefStart = VerseRefStart,
		@nVerseRefEnd = VerseRefEnd
	from TxtWordFormInContext_ (readuncommitted)
	where paracharoffset = (select min(paracharoffset)
				from TxtWordFormInContext_ (readuncommitted)
				where owner$ = @hvoPara
				and paracharoffset > @ichPos)
	and owner$ = @hvoPara
	
	if @hvoTwficPara is null
	begin
		select	@hvoTwficPara = Owner$,
			@ichParaOffset = paracharoffset,
			@nVerseRefStart = VerseRefStart,
			@nVerseRefEnd = VerseRefEnd
		from TxtWordFormInContext_ (readuncommitted)
		where Convert(char(8), ParaCharOffset) + Convert(char(8), Owner$)= (
		select Convert(char(8), min(t.ParaCharOffset)) + Convert(char(8), min(t.Owner$))
		from TxtWordFormInContext_ t (readuncommitted)
			join sttxtpara_ s (readuncommitted) on s.id = t.owner$
		where	s.owner$ = @hvoStText
		and	s.ownord$ = (select min(p.ownord$)
					from sttxtpara_ p(readuncommitted)
					where p.owner$ = @hvoStText
					and p.ownord$ > (select ownord$ from sttxtpara_ (readuncommitted) where id = @hvoPara)
					and exists(select * from TxtWordFormInContext_ c(readuncommitted) where c.owner$ = p.[id])))
	end
GO


if exists (select *
             from sysobjects
            where name = 'GetScrRefsForRun')
	drop proc GetScrRefsForRun
go
print 'creating proc GetScrRefsForRun'
go
/*****************************************************************************
 * GetScrRefsForRun
 *
 * Description: Get the Scripture reference from a TWFIC in the given run of a
 *              paragraph.
 * Parameters:
 *	hvoPara		Id of paragraph
 *	ichMin		Start of run
 *	ichLim		End of run
 *	nScrRefStart	Start reference - output
 *	nScrRefEnd	End reference - output
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc GetScrRefsForRun
	@hvoPara	int,
	@ichMin		int,
	@ichLim		int,
 	@nScrRefStart	int = null output,
	@nScrRefEnd	int = null output
as
	select	@nScrRefStart = max([VerseRefStart]), -- use of max is arbitrary.  All references within run must be equal.
		@nScrRefEnd = max([VerseRefEnd])
	from	TxtWordformInContext_ 
	where	Owner$ = @hvoPara
	and	ParaCharOffset >= @ichMin
	and	ParaCharOffset < @ichLim
GO


if exists (select *
             from sysobjects
            where name = 'Import_NewScrBook')
	drop proc Import_NewScrBook
go
print 'creating proc Import_NewScrBook'
go
/*****************************************************************************
 * Import_NewScrBook
 *
 * Description: Deletes an existing book (if any) and creates a new one having
 * the given "canonical" book number. It also creates a title object for the
 * book.
 * Parameters:
 *	hvoScripture	Id of owning Scripture
 *      nBookNumber	"canonical" book number (e.g., 1=GEN, 2=EXO, ...)
 *	hvoBook		id of new ScrBook object - output
 *	hvoBookTitle	id of new Title (an StText object) - output
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc Import_NewScrBook
	@hvoScripture	int,
	@nBookNumber	int,
 	@hvoBook	int = null output,
	@hvoBookTitle	int = null output
as
  	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int, @ord int, @hvoScrBookRef int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'NewScrBook_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Determine the ScrBookRef corresponding to this book and the relative position
	-- of this book in the ScrBook table.
	set @hvoScrBookRef = 0
	select @hvoScrBookRef = [id]
	from ScrBookRef_
	where OwnOrd$ = @nBookNumber
	if @hvoScrBookRef = 0 begin
		set @err = 55678
		raiserror('No matching ScrBookRef: %d', 16, 1, @nBookNumber) 
		goto LFail
	end

  	set @clid = 3002 -- ScrBook
	set @flid = 3001001 -- Scripture_ScriptureBooks
	set @ord = 0
	select @ord = OwnOrd$, @hvoBook = [id]
	from ScrBook_
	where BookId = @hvoScrBookRef

	if @ord > 0 begin
		-- Delete the existing book
		declare @uid uniqueidentifier
		exec DeleteObject$ @uid, @objId = @hvoBook
-- REVIEW TomB: Should we be calling DeletOwnSeq here instead in order to preserve other book info?
	end
	else begin
		-- Select the lowest ord for any existing book beyond the one we want
		-- to create.
		select	@ord = coalesce(max(bk.[OwnOrd$])+1, 1)
		from	[ScrBook_] bk with (serializable)
		join	ScrBookRef_ on ScrBookRef_.[id] = bk.BookId
		and	ScrBookRef_.OwnOrd$ < @nBookNumber
		where	bk.[Owner$] = @hvoScripture
			and bk.[OwnFlid$] = @flid
  
  		update	[CmObject] with (serializable)
  		set 	[OwnOrd$]=[OwnOrd$]+1
  		where 	[Owner$] = @hvoScripture
  			and [OwnFlid$] = @flid
  			and [OwnOrd$] >= @ord
	end

	-- Create the new ScrBook (base) object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoScripture, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoBook = @@identity

	-- Create the new Title (base) object
	set @clid = 14 -- StText
	set @flid = 3002004 -- Scripture_ScriptureBooks
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoBook, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoBookTitle = @@identity

	-- Insert into ScrBook
	insert [ScrBook] ([Id], [BookId])
	values(@hvoBook, @hvoScrBookRef)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to ScrBook: ID=%d', 16, 1, @hvoBook) 
		goto LFail
	end

	-- Insert into StText
	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoBookTitle, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoBookTitle) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'Import_NewScrBookJRP')
	drop proc Import_NewScrBookJRP
go
print 'creating proc Import_NewScrBookJRP'
go
/*****************************************************************************
 * Import_NewScrBookJRP
 *
 * THIS IS FOR PERFORMANCE TEST PURPOSES ONLY!!!
 *
 * Description: Deletes an existing book (if any) and creates a new one having
 * the given "canonical" book number. It also creates a title object for the
 * book.
 * Parameters:
 *	hvoScripture	Id of owning Scripture
 *      nBookNumber	"canonical" book number (e.g., 1=GEN, 2=EXO, ...)
 *	hvoBook		id of new ScrBook object - output
 *	hvoBookTitle	id of new Title (an StText object) - output
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc Import_NewScrBookJRP
	@hvoScripture	int,
	@nBookNumber	int,
 	@hvoBook	int = null output,
	@hvoBookTitle	int = null output
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int, @ord int, @hvoScrBookRef int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'NewScrBookJRP_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Determine the ScrBookRef corresponding to this book and the relative position
	-- of this book in the ScrBook table.
	set @hvoScrBookRef = 0
	select @hvoScrBookRef = [id]
	from ScrBookRef_
	where OwnOrd$ = @nBookNumber
	if @hvoScrBookRef = 0 begin
		set @err = 55678
		raiserror('No matching ScrBookRef: %d', 16, 1, @nBookNumber) 
		goto LFail
	end

	set @flid = 3001001 -- Scripture_ScriptureBooks
	set @ord = 0
	select @ord = OwnOrd$, @hvoBook = [id]
	from ScrBook_
	where BookId = @hvoScrBookRef

	if @ord > 0 begin
		-- Delete the existing book
		declare @uid uniqueidentifier
		exec DeleteObject$ @uid, @objId = @hvoBook
-- REVIEW TomB: Should we be calling DeletOwnSeq here instead in order to preserve other book info?
	end
	else begin
		-- Select the lowest ord for any existing book beyond the one we want
		-- to create.
		select	@ord = coalesce(max(bk.[OwnOrd$])+1, 1)
		from	[ScrBook_] bk with (serializable)
		join	ScrBookRef_ on ScrBookRef_.[id] = bk.BookId
		and	ScrBookRef_.OwnOrd$ < @nBookNumber
		where	bk.[Owner$] = @hvoScripture
			and bk.[OwnFlid$] = @flid
	end

	-- Create the new ScrBook (base) object
	exec CreateObject_ScrBook
	@ScrBook_Name_enc = NULL, @ScrBook_Name_txt = NULL, 
	@ScrBook_Abbrev_enc = NULL, @ScrBook_Abbrev_txt = NULL, 
	@Owner = @hvoScripture,
	@OwnFlid = @flid,
	@StartObj = NULL,
	@NewObjId = @hvoBook output,
	@NewObjGuid = NULL

	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoScripture, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoBook = @@identity

	-- Create the new Title (base) object
	set @clid = 14 -- StText
	set @flid = 3002004 -- Scripture_ScriptureBooks
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoBook, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoBookTitle = @@identity

	-- Insert into ScrBook
	insert [ScrBook] ([Id], [BookId])
	values(@hvoBook, @hvoScrBookRef)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to ScrBook: ID=%d', 16, 1, @hvoBook) 
		goto LFail
	end

	-- Insert into StText
	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoBookTitle, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoBookTitle) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'Import_AppendScrSection')
	drop proc Import_AppendScrSection
go
print 'creating proc Import_AppendScrSection'
go
/*****************************************************************************
 * Import_AppendScrSection
 *
 * Description: Adds a Scripture ection to the end of the given ScrBook
 *
 * Parameters:
 *	hvoScrBook	Id of owning ScrBook
 *	ord		position for new section - must be max(OwningOrd$ + 1)
 *	hvoSection	Id of new ScrSection - output (optional)
 *	hvoSectHeading	Id of new StText to hold the section heading (optional)
 *	hvoSectContent	Id of new StText to hold the section contents (optional)
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc Import_AppendScrSection
	@hvoScrBook int,			-- Id of owning ScrBook
	@ord int,				-- position for new section
	@hvoSection int = null output,		-- Id of new ScrSection
	@hvoSectHeading int = null output,	-- Id of new StText for section heading
	@hvoSectContent int = null output	-- Id of new StText for section contents
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'AppendScrSection_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	set @clid = 3005 -- ScrSection
	set @flid = 3002001 -- ScrBook_Sections

	-- Create the new ScrSection object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoScrBook, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoSection = @@identity

	insert [ScrSection] ([Id])
	values(@hvoSection)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to ScrSection: ID=%d', 16, 1, @hvoSection) 
		goto LFail
	end

	-- Create the StTexts
	set @clid = 14 -- StText

	-- Create the new Section Heading object
	set @flid = 3005001 -- ScrSection_Heading
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoSection, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoSectHeading = @@identity

	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoSectHeading, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoSectHeading) 
		goto LFail
	end

	-- Create the new Section Content object
	set @flid = 3005002 -- ScrSection_Content
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoSection, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoSectContent = @@identity

	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoSectContent, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoSectContent) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'Import_AppendPara')
	drop proc Import_AppendPara
go
print 'creating proc Import_AppendPara'
go
/*****************************************************************************
 * Import_AppendPara
 *
 * Description: Adds a paragraph to the end of the given StText.
 *
 * Parameters:
 *	hvoText		Id of owning StText
 *	ord		position for new paragraph - must be max(OwningOrd$ + 1)
 *	stuContents	Contents of new paragraph
 *	rgbContentsFmt	Format data for Contents
 *	hvoPara		id of new object - output (optional)
 *      rgbStParaFmt	Format data (named style) for StPara (optional)
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc Import_AppendPara
	@hvoText int,
	@ord int,				-- position for new paragraph
	@stuContents ntext,		-- Contents of new paragraph
	@rgbContentsFmt image,	-- format data for Contents
	@hvoPara int = null output,		-- id of new object
	@rgbStParaFmt varbinary(8000) = null	-- format data for paragraph
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @clid = 16 -- StTxtPara
	set @flid = 14001 -- StText_Paragraphs

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'AppendPara_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Create the new object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoText, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoPara = @@identity

	-- Insert into StPara
	insert [StPara] ([Id], [StyleRules])
	values(@hvoPara, @rgbStParaFmt)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StPara: ID=%d', 16, 1, @hvoPara) 
		goto LFail
	end

	-- Insert into StTxtPara
	insert StTxtPara ([Id],[Contents],[Contents_Fmt])
	values (@hvoPara, @stuContents, @rgbContentsFmt)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StTextPara: ID=%d', 16, 1, @hvoPara) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'GetScrBookInfo')
	drop proc GetScrBookInfo
go
print 'creating proc GetScrBookInfo'
go
/*****************************************************************************
 * GetScrBookInfo
 *
 * Description: Retrieves IDs (for joining to ScrBookRef), names and
 *		abbreviations for all Scripture books; retrieves all available
 *		encodings for Name and Abbrev fields.
 *
 * Parameters:
 *	hvoScripture	Id of Scripture
 * Returns: 0
 *
 *****************************************************************************/
create proc GetScrBookInfo
	@hvoScripture	int
as
	select	bk.[Id],
		bk.BookId,
		nm_or_abbrev.[Txt],
		nm_or_abbrev.[Flid],
		nm_or_abbrev.[Enc],
		NULL "Fmt"
	from	ScrBook_ bk
	left outer join	MultiTxt$ nm_or_abbrev on nm_or_abbrev.[Obj] = bk.[Id]
		and nm_or_abbrev.[Flid] in (3002002, 3002005)
	where	bk.Owner$ = @hvoScripture
		and bk.OwnFlid$ = 3001001 -- Scripture_ScriptureBooks
	order by bk.OwnOrd$
go


if exists (select *
             from sysobjects
            where name = 'GetScrBookTitle')
	drop proc GetScrBookTitle
go
print 'creating proc GetScrBookTitle'
go
/*****************************************************************************
 * GetScrBookTitle
 *
 * Description: Retrieves title of a given ScrBook.
 *
 * Parameters:
 *	hvoScrBook	Id of ScrBook
 * Returns: 0
 *
 *****************************************************************************/
create proc GetScrBookTitle
	@hvoScrBook	int
as
	select	[Id] "hvoTitle",
		[Owner$] "hvoOwner"
	from	StText_
	where	[Owner$] = @hvoScrBook
		and [OwnFlid$] = 3002004 -- ScrBook_Ttitle
go


IF EXISTS (SELECT * 
	   FROM   sysobjects 
	   WHERE  name = 'AdjustTwficOffsets') 
    DROP PROCEDURE AdjustTwficOffsets
GO
print 'creating proc AdjustTwficOffsets'
go
/*****************************************************************************
 * AdjustTwficOffsets
 *
 * Description: Increases or decreases the ParaCharOffset of an edited
 * paragraph's TxtWordformInContext entries
 *
 * Parameters:
 *		
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
CREATE PROCEDURE AdjustTwficOffsets
	@hvoPara	int,
	@ichMin		int, -- Min charcater offset for TWFICs to change
	@cchAdjust	int -- number of characters to adjust by (+ or -)
AS
	DECLARE @nTrnCnt int, @sTranName varchar(50), @fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'AdjustTwficOffsets_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Do the adjustment
	update	TxtWordformInContext
	set	ParaCharOffset = ParaCharOffset + @cchAdjust
	FROM cmObject co (READUNCOMMITTED) 
	WHERE co.[Id] = TxtWordformInContext.[Id]
	AND co.Owner$ = @hvoPara
        AND paracharoffset > @ichMin

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0
GO


IF EXISTS (SELECT * 
	   FROM   sysobjects 
	   WHERE  name = 'GetRgChangedTwfics') 
    DROP PROCEDURE GetRgChangedTwfics
GO
print 'creating proc GetRgChangedTwfics'
go
/*****************************************************************************
 * GetRgChangedTwfics
 *
 * Description: For an edited StTxtPara, given the offset where edit began and
 * the number of characters deleted, get the number of TxtWordformInContext to
 * retain prior to the edited portion and the ord number of the max entry that
 * needs to be deleted prior to reparsing the modified substring of the
 * paragraph contents. In the C++ program, these will translate into a Min and
 * Lim in the vector of HVOs, since the vector index is one less than the ord
 * number in the database.
 *
 * Parameters:
 *		
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
CREATE PROCEDURE GetRgChangedTwfics
	@hvoPara	int,
	@ichMin		int,
	@cchDel		int,
	@iMin		int output,
	@iLim		int output
AS

	select	@iMin = count(*)
	from	TxtWordformInContext_ (readuncommitted)
	where	Owner$ = @hvoPara
	and	ParaCharOffset < @ichMin - Len([Form])
	
	select	@iLim = count(*)
	from	TxtWordformInContext_ (readuncommitted)
	where	Owner$ = @hvoPara
	and	ParaCharOffset <= @ichMin + @cchDel

	return 0
GO


if exists (select *
             from sysobjects
            where name = 'GetScrConcWordforms')
	drop proc GetScrConcWordforms
go
print 'creating proc GetScrConcWordforms'
go
/*****************************************************************************
 * GetScrConcWordforms
 *
 * Description: Retrieves HVOs and forms of all wordforms of a given language
 * which are used in Scripture. For now, order the results by form. This will
 * probably eventually be replaced by true sorting in the program.
 *
 * Parameters:
 *      lpid		Id of the language project
 *	hvoEnc		Id of language encoding
 * Returns: 0
 *
 *****************************************************************************/
create proc GetScrConcWordforms
--	@lpid	int,
	@hvoEnc int
as
/* Old way was slow, but took lpid into consideration...
	select w.[Obj], w.[Txt], wf.[SpellingStatus]
	  from WfiWordform_Form w,
	  WfiWordform wf
	 where w.[Obj] = wf.[id]
	   and w.enc = @hvoEnc
	   and exists (select *
			 from TxtWordformInContext_,
			      StTxtPara_,
			      StText_,
			      ScrSection_,
			      ScrBook_,
			      Scripture_
			where w.[Obj] = TxtWordformInContext_.[Analysis]
			  and TxtWordformInContext_.[Owner$] = StTxtPara_.[id]
			  and StTxtPara_.[Owner$] = StText_.[id]
			  and ((StText_.[Owner$] = ScrSection_.[id]
			  and   ScrSection_.[Owner$] = ScrBook_.[id])
			  or   (StText_.[Owner$] = ScrBook_.[id]))
			  and ScrBook_.[Owner$] = Scripture_.[id]
			  and Scripture_.[Owner$] = @lpid)
	order by w.[Txt]
*/
	select	w.[Id], wf.[Txt], w.[SpellingStatus], count(*) "twficcount"
	  from	WfiWordform_Form wf (readuncommitted),
		WfiWordform w (readuncommitted),
		TxtWordformInContext twfic (readuncommitted)
	 where	w.[Id] = wf.[Obj]
	   and	wf.[Enc] = @hvoEnc
	   and	w.[Id] = twfic.[Analysis]
	   and	twfic.[VerseRefstart] <> 0
	group by w.[Id], wf.[Txt], w.[SpellingStatus]
	order by wf.[Txt] -- or by twficcount when sorting by count

	return 0 
go


if exists (select *
             from sysobjects
            where name = 'GetScrConcWordformInContext')
	drop proc GetScrConcWordformInContext
go
print 'creating proc GetScrConcWordformInContext'
go
/*****************************************************************************
 * GetScrConcWordformInContext
 *
 * Description: Retrieves HVOs, forms, paragraph offsets, references, and back
 * ref to paragraph for all occurrences of a given wordform in the translated
 * Scripture of a given language project.
 *
 * Parameters:
 *      lpid		Id of the language project
 *	hvoWordform	Id of wordform
 * Returns: 0
 *
 * Note: A lot of different approaches have been tried to optimize performance
 * of this procedure. Before trying something, check with Tom Bogle. He has a
 * file called GetScrConcWordformInContext3-4.sql that should be consulted to
 * see what's already been tried.
 *****************************************************************************/
create proc GetScrConcWordformInContext
	@hvoWordform int
as
	select	twfic.[Id],
		twfic.[Form],
		twfic.[Form_Fmt],
		twfic.[ParaCharOffset],
		twfic.[VerseRefStart],
		twfic.[VerseRefEnd],
		@hvoWordform, -- Needed to set Analysis prop of twfic
		twfic.[Owner$],
		para.[Contents],
		para.[Contents_Fmt]
	from	TxtWordformInContext_ twfic (readuncommitted)
		join StTxtPara_ para (readuncommitted) on para.[Id] = twfic.[Owner$]
			and para.[Class$] = 16 -- class Id of StTxtPara
	where	twfic.[Analysis] = @hvoWordform
	and	twfic.[VerseRefstart] <> 0
	order by twfic.[VerseRefstart],
		 twfic.[VerseRefEnd] desc,
		 para.[Owner$],
		 para.[OwnOrd$],
		 twfic.[ParaCharOffset]
	return 0 
go


if exists (select *
             from sysobjects
            where name = 'CreateObj_WfiWordForm')
	drop proc CreateObj_WfiWordForm
go
print 'creating proc CreateObj_WfiWordForm'
go
/*****************************************************************************
 * CreateObj_WfiWordForm
 *
 * Description: Adds a WfiWordForm object, if needed. If the wordform to be
 * created already exists, then just return the HVO. Otherwise, create it and
 * set its Form property using the given encoding.
 * Parameters:
 *	hvoWfi		Id of owning Wordform Inventory
 *	stuForm		wordform
 *	enc		character offset into StTxtPara
 *	id		Id of new (or existing) wordform
 *	nSpellingStat	Spelling status
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc CreateObj_WfiWordForm
	@hvoWfi		int,
	@stuForm	nvarchar(4000),
	@enc		int,
	@id		int = null output,
	@nSpellingStat	tinyint = 0 output
as
	-- Begin by checking to see if it already exists. If so, then our
	-- job is easy.
	select	@id = f.[Obj],
		@nSpellingStat = w.[SpellingStatus]
	from	WfiWordform_Form f
	join	WfiWordform w on w.[id] = f.[Obj]
	where	CONVERT ( varbinary(8000), f.[Txt]) = CONVERT ( varbinary(8000), @stuForm)
	and	f.[Enc] = @enc

	if @id is not null return 0

	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @clid = 5062 -- WfiWordform
	set @flid = 5063001 -- WordformInventory_Wordforms

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'WfiWordform_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Create the new object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoWfi, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @id = @@identity

	-- Insert into WfiWordform
	insert WfiWordform ([Id], [SpellingStatus])
	values (@id, @nSpellingStat)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to WfiWordform: ID=%d', 16, 1, @id) 
		goto LFail
	end

	-- Insert into WfiWordform_Form (which is a view on MultiTxt$)
	insert MultiTxt$ ([Obj],[Flid],[Enc],[Txt])
	values (@id, 5062001, @enc, @stuForm)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to MultiTxt$: ID=%d, Flid=%d, Enc=%d, Txt=%s', 16, 1, @id, 5062001, @enc, @stuForm) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err

GO


if exists (select *
             from sysobjects
            where name = 'CreateObj_TxtWordFormInContext')
	drop proc CreateObj_TxtWordFormInContext
go
print 'creating proc CreateObj_TxtWordFormInContext'
go
/*****************************************************************************
 * CreateObj_TxtWordFormInContext
 *
 * Description: Adds a TxtWordFormInContext object, along with the StTxtPara
 * offset and Scripture reference.
 * Parameters:
 *	hvoStTxtPara	Id of owning paragraph
 *	hvoWfiWordform	Id of wordform (or analysis, interpretation, or gloss)
 *	stuForm		surface form in context
 *	rgbVernFmt	format data for surface form
 *	nOffset		character offset into StTxtPara
 *	VerseRefStart	Starting Scripture reference (book/chapter/verse)
 *	VerseRefEnd	Ending Scripture reference (book/chapter/verse)
 *	ord		position for new object - default to end
 *	id		id of new object - output
 *	OrdIsEnd	1 if explicit ord value is the Lim of the sequence
 *			This is mainly a hint to make importing faster
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc CreateObj_TxtWordFormInContext
	@hvoStTxtPara int,
	@hvoWfiWordform int,
	@stuForm nvarchar(4000),	-- surface form in context
	@rgbVernFmt varbinary(8000),	-- format data for surface form
	@nOffset int,			-- character offset into StTxtPara
	@VerseRefStart int = null,	-- Starting Scripture reference (BCV)
	@VerseRefEnd int = null,	-- Ending Scripture reference (BCV)
	@ord int = null,		-- position for new object - default to end
	@id int = null output,		-- id of new object
	@OrdIsEnd int = 0		-- 1 if explicit ord value is the Lim of the sequence
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @clid = 5058 -- TxtWordformInContext
	set @flid = 16005 -- StTxtPara_AnalyzedTextObjects

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'TxtWordformInContext_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- determine if the object(s) should be added to the end of the sequence
	if @ord is null begin
		select	@ord = coalesce(max([OwnOrd$])+1, 1)
		from	[CmObject] with (serializable)
		where	[Owner$] = @hvoStTxtPara
			and [OwnFlid$] = @flid
	end
	else if @OrdIsEnd = 0 begin
		-- increment the ordinal value(s) of the object(s) in the sequence
		-- that occur at or after the new object(s)
		-- REVIEW TomB: Do tfics really need to be ordered? It's a big pain
		-- and so far the OwnOrd is getting messed up using either "with
		-- (serializable)" or "(readuncommitted)". Nothing bad seems to happen
		-- in the software since we rely on ParaCharOffset for ordering. 
		update	[CmObject] -- with (serializable)
		set 	[OwnOrd$]=[OwnOrd$]+1
		from	CmObject (readuncommitted)
		where 	[Owner$] = @hvoStTxtPara
			and [OwnFlid$] = @flid
			and [OwnOrd$] >= @ord
	end

	-- Create the new object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoStTxtPara, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @id = @@identity

	-- Insert into TxtWordformInContext
	insert TxtWordformInContext ([Id],[Form],[Form_Fmt],[Analysis],[ParaCharOffset],[VerseRefStart],[VerseRefEnd])
	values (@id, @stuForm, @rgbVernFmt, @hvoWfiWordform, @nOffset, @VerseRefStart, @VerseRefEnd)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to TxtWordformInContext: ID=%d', 16, 1, @id) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err

GO