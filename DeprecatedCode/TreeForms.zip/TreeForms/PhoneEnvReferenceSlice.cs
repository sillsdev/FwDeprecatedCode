// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: PhoneEnvReferenceSlice.cs
// Responsibility: RandyR
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Xml;

using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.Common.RootSites;
using SIL.FieldWorks.Common.Controls;
using SIL.Utils;
using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for PhoneEnvReferenceSlice.
	/// </summary>
	public class PhoneEnvReferenceSlice : ReferenceSlice
	{
		public PhoneEnvReferenceSlice(FdoCache cache, CmObject obj, int flid,
			XmlNode configurationNode, IPersistenceProvider persistenceProvider,
			StringTable stringTbl)
			: base(cache, obj, flid,configurationNode, persistenceProvider, stringTbl)
		{
			Debug.Assert(obj is MoAffixAllomorph || obj is MoStemAllomorph);
		}

		/// <summary>
		/// Override method to add the Sets up the PhoneEnvReferenceView control.
		/// </summary>
		protected override void SetupControls(IPersistenceProvider persistenceProvider,
			StringTable stringTbl)
		{
			Debug.Assert(m_obj != null);

			PhoneEnvReferenceLauncher rl = new PhoneEnvReferenceLauncher();
			rl.Initialize(m_cache, m_obj, m_flid, m_fieldName, persistenceProvider, null);
			rl.ConfigurationNode = ConfigurationNode;
			this.Control = rl;
			rl.ViewSizeChanged += new FwViewSizeChangedEventHandler(this.OnViewSizeChanged);
			PhoneEnvReferenceView view = (PhoneEnvReferenceView)rl.MainControl;
			view.ViewSizeChanged += new FwViewSizeChangedEventHandler(this.OnViewSizeChanged);
		}

		/// <summary>
		/// Set the width of the item, perform any internal layout inside the item, and return its height
		/// (as in the Height property). ViewItem overrides to set the view width.
		/// </summary>
		public override int SetWidthAndGetHeight(int dxpWidth)
		{
			ReferenceLauncher rl = (ReferenceLauncher)this.Control;
			rl.Width = dxpWidth;
			RootSite rs = (RootSite)rl.MainControl;
			rs.PerformLayout();
			if (rs.RootBox != null)
			{
				// Allow it to be the height it wants + fluff to get rid of scroll bar.
				rl.Height = rs.RootBox.get_Height() + 8;
			}
			AdjustTreeNodeSize();
			return Height;
		}

		
		public override void RegisterWithContextHelper ()
		{
			string caption = XmlUtils.GetOptionalAttributeValue(ConfigurationNode, "label", "");

			PhoneEnvReferenceLauncher launcher = (PhoneEnvReferenceLauncher)this.Control;
			Mediator.SendMessage("RegisterHelpTargetWithId", new object[]{launcher.Controls[1], caption, HelpId});
			Mediator.SendMessage("RegisterHelpTargetWithId", new object[]{launcher.Controls[0], caption, HelpId, "Button"});
		}

		/// <summary>
		/// Handle changes in the size of the underlying view.
		/// </summary>
		protected void OnViewSizeChanged(object sender, FwViewSizeEventArgs e)
		{
			// For now, just handle changes in the height.
			PhoneEnvReferenceLauncher rl = (PhoneEnvReferenceLauncher)this.Control;
			PhoneEnvReferenceView view = (PhoneEnvReferenceView)rl.MainControl;
			int hMin = m_containingDataTree.Diagram.GetMinFieldHeight();
			int h1 = view.RootBox.get_Height();
			Debug.Assert(e.Height == h1);
			int hOld = m_treeNode.Height;
			int hNew = Math.Max(h1, hMin) + 3;
			if (hNew != hOld)
			{
				m_treeNode.Height = hNew;
				rl.Height = hNew - 1;
				view.Height = hNew - 1;
			}
		}
	}
}
