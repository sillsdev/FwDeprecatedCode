using System;
using System.Collections;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Uses a Hashtable to implement a simple set.
	/// </summary>
	public class Set
	{
		Hashtable m_table;
		public Set()
		{
			m_table = new Hashtable();
		}
		/// <summary>
		/// In contrast to the Add methods on many collections, this one does not complain if the
		/// key is already present.
		/// </summary>
		/// <param name="obj"></param>
		public void Add(object obj)
		{
			m_table[obj] = 1;
		}
		public void Remove(object obj)
		{
			m_table.Remove(obj);
		}
		public bool Contains(object obj)
		{
			return m_table[obj] != null;
		}
	}

	public class Pair
	{
		object m_first;
		object m_second;
		public Pair(object first, object second)
		{
			m_first = first;
			m_second = second;
		}

		public override bool Equals(object obj)
		{
			if (! (obj is Pair))
				return false;
			Pair p = (Pair) obj;
			return p.m_first == m_first && p.m_second == m_second;
		}
		public override int GetHashCode()
		{
			return m_first.GetHashCode() + m_second.GetHashCode();
		}
	}
	/// <summary>
	/// Doesn't seem to work to use a pair of ints...I think because the int has to be
	/// wrapped to store in an object variable, and two wrappers are not == even if the
	/// wrapped integers are.
	/// </summary>
	public class IntPair
	{
		int m_first;
		int m_second;
		public IntPair(int first, int second)
		{
			m_first = first;
			m_second = second;
		}

		public override bool Equals(object obj)
		{
			if (! (obj is IntPair))
				return false;
			IntPair p = (IntPair) obj;
			return p.m_first == m_first && p.m_second == m_second;
		}
		public override int GetHashCode()
		{
			return m_first + m_second;
		}
	}

}
