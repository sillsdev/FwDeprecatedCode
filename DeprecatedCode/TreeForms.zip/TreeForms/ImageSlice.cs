// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ImageSlice.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// Implements a simple Image XDE editor.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;


namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for ImageSlice.
	/// </summary>
	public class ImageSlice : Slice
	{
		/// <summary> Constructor.</summary>
		/// <remarks>Will throw an exception if the image is not found.</remarks>
		/// 
		
		/// <summary>
		/// instructor
		/// </summary>
		/// <param name="distFilesPath">the path to the distfiles Directory</param>
		/// <param name="relativeImagePath">they path to the image, relative to the distfiles Directory</param>
		public ImageSlice(string distFilesPath, string relativeImagePath) : base(new PictureBox())
		{
			((PictureBox)this.Control).Image =   Image.FromFile(System.IO.Path.Combine(distFilesPath, relativeImagePath));
			((PictureBox)this.Control).Height = ((PictureBox)this.Control).Image.Height;
		}

		/// <summary>
		/// This is passed the color that the XDE specified, if any, otherwise null.
		/// Images are not editable, so use the inactive color.
		/// </summary>
		/// <param name="clr"></param>
		public override void OverrideBackColor(String backColorName)
		{
			if (this.Control == null)
				return;
			if (backColorName != null)
				this.Control.BackColor = Color.FromName(backColorName);
			else
				this.Control.BackColor = System.Drawing.SystemColors.ControlLight;
		}

		
	}
}
