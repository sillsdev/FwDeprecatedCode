using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Runtime.Serialization;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.COMInterfaces;
using System.Xml;
using System.Diagnostics;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for SliceTreeNode.
	/// </summary>
	public class SliceTreeNode : System.Windows.Forms.UserControl
	{
		#region constants
		// Constants used in drawing tree diagram.
		// This is the width around the tree border where the mouse turns to a drag icon.
		internal const int kdxpActiveTreeBorder = 3;
		internal const int kdxpMinTreeWidth = 3; // Minimum size for tree view.
		internal const int kdxpMinDataWidth = 120; // Minimum size for data view.
		internal const int kdxpRtTreeGap = 3; // Gap between text and the right tree border.
		internal const int kdxpIconWid = 5; // Width of the minus or plus sign.
		internal const int kdzpIconGap = 1; // Width/height of gap between icon and box.
		internal const int kdypIconHeight = kdxpIconWid; // Height of plus sign.
		internal const int kdxpBoxWid = kdxpIconWid + 2 * kdzpIconGap + 2; // Width of the control box.
		internal const int kdypBoxHeight = kdxpBoxWid; // Try making the box square.
		internal const int kdxpTextGap = 2; // From line to label text.
		internal const int kdxpShortLineLen = 7; // Length of line from box to text.
		internal const int kdxpIndDist = kdxpBoxWid + kdxpShortLineLen + kdxpTextGap;
		internal const int kdypBoxCtr = kdypBoxHeight / 2; // Location for horizontal line of minus/plus/line
		internal const int kdxpBoxCtr = kdxpBoxWid / 2; // Location of vertical line of plus/line
		internal const int kdxpLongLineLen = kdxpBoxCtr + kdxpShortLineLen; // Horz. line to text w/o box.
		internal const int kdxpLeftMargin = 2; // Gap at the far left of everything.
		#endregion

		protected Slice m_slice;
		//test
		//	protected ComboBox m_comboMenu = null;
		protected bool m_inMenuButton = false;
		//end test

		protected ArrayList m_rgcpiCreateOptions; // array of ClassAndPropInfo corresponding to things we can create.
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Slice Slice
		{
			get
			{
				return m_slice;
			}
		}

		public SliceTreeNode(Slice sc)
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			m_slice = sc;
			this.Paint += new PaintEventHandler(this.HandlePaint);
			//this.MouseDown += new MouseEventHandler(this.HandleMouseDown);
			this.SizeChanged += new EventHandler(this.HandleSizeChanged);
			// Among other possible benefits, this suppresses a really nasty Heisenbug:
			// On collapsing a summary, the expansion box for the next summary was being
			// drawn without either plus or minus. This did not happen while stepping through
			// the OnPaint method, only when the program ran at full speed.
			this.SetStyle(ControlStyles.DoubleBuffer, true);
			this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
			this.SetStyle(ControlStyles.UserPaint, true);

			if (m_slice.Label != null)
				this.AccessibleName = m_slice.Label;
		}

		public void HandleSizeChanged(object sender, EventArgs ea)
		{
			int iSlice = m_slice.Container.Slices.IndexOf(m_slice);
		}

		// Things can (potentially) be dropped on this control.
		public override bool AllowDrop
		{
			get
			{
				return true;
			}
		}

		protected override void OnDragEnter(DragEventArgs drgevent)
		{
			base.OnDragEnter(drgevent);
			int hvoDstOwner; // dummies, we just want to set the Effect property of drgevent.
			int flidDst;
			int ihvoDstStart;
			ObjectDragInfo odi = TestDropEffects(drgevent, out hvoDstOwner, out flidDst, out ihvoDstStart);
		}

		protected override void OnDragDrop(DragEventArgs drgevent)
		{
			base.OnDragDrop(drgevent);
			int hvoDstOwner;
			int flidDst;
			int ihvoDstStart;
			ObjectDragInfo odi = TestDropEffects(drgevent, out hvoDstOwner, out flidDst, out ihvoDstStart);
			if (drgevent.Effect == DragDropEffects.None)
				return;
			// Todo JohnT: verify that m_slice is the last slice in the representation of flid.
			m_slice.Container.Cache.MoveOwningSequence(odi.HvoSrcOwner, odi.FlidSrc, odi.IhvoSrcStart,
				odi.IhvoSrcEnd, hvoDstOwner, flidDst, ihvoDstStart);
		}

		/// <summary>
		/// Test whether we can drop the information indicated by the drgevent onto this.
		/// Currently this is possible if
		///		1. The drag event's data is an ObjectDragInfo
		///		2. It is valid for those objects to be moved to a position just after the object of which
		///		the destination slice is a part, in the lowest level sequence of which it is a part.
		///	drgevent.Effect is set to Move or None to indicate the result. If successful, returns an ObjectDragInfo
		///	and the place to put the new objects.
		///	(Note: the ihvoDstStart returned is meaningless if the property is a collection.)
		///	
		///	Move is valid under the following conditions:
		///		1. Must not violate signature. Signature is checked if destination property is different from source.
		///		2. Must not create circularity of ownership. This is checked if destination object is different from source.
		///		3. Must result in actual movement. This is checked if destination and source object and flid are the same.
		///		This case always fails if the property is a collection, also if it is a sequence and nothing would change.
		/// </summary>
		/// <param name="drgevent">Passed so Effect can be set.</param>
		/// <param name="hvoDstOwner">Object to move things to</param>
		/// <param name="flidDst">Property to move to.</param>
		/// <param name="ihvoDstStart">Place to put them (if sequence).</param>
		/// <returns></returns>
		private ObjectDragInfo TestDropEffects(DragEventArgs drgevent, out int hvoDstOwner, out int flidDst, out int ihvoDstStart)
		{
			ObjectDragInfo odi = (ObjectDragInfo) drgevent.Data.GetData(typeof(ObjectDragInfo));
			drgevent.Effect = DragDropEffects.None; // default
			hvoDstOwner = 0; // not used unless we get to GetSeqContext call, but compiler demands we set them.
			flidDst = 0;
			ihvoDstStart = 0;
			if (odi != null)
			{
				// Enhance JohnT: options to allow dragging onto this object, putting the dragged object into
				// one of its owning properties.
				// Try to drag the object after 'this' in the relevant property.
				if (m_slice.GetSeqContext(out hvoDstOwner, out flidDst, out ihvoDstStart))
				{
					ihvoDstStart++; // Insert after the present object (if a sequence).
					if (OkToMove(hvoDstOwner, flidDst, ihvoDstStart, odi))
					{
						drgevent.Effect = DragDropEffects.Move;
						return odi;
					}
				}
				// See if the first child is a sequence we could insert at the start of.
				XmlNode firstChild = m_slice.ConfigurationNode.FirstChild;
				if (firstChild != null && firstChild.Name == "seq")
				{
					hvoDstOwner = m_slice.Object.Hvo;
					flidDst = (int)m_slice.Container.Cache.MetaDataCacheAccessor.GetFieldId2((uint)m_slice.Object.ClassID, firstChild.Attributes["attr"].Value, true);
					ihvoDstStart = 0;
					if (OkToMove(hvoDstOwner, flidDst, ihvoDstStart, odi))
					{
						drgevent.Effect = DragDropEffects.Move;
						return odi;
					}
				}
			}
			return odi;
		}

		/// <summary>
		/// Return whether it is OK to move the objects indicated by odi to the specified destination.
		/// </summary>
		/// <param name="hvoDstOwner"></param>
		/// <param name="flidDst"></param>
		/// <param name="ihvoDstStart"></param>
		/// <param name="odi"></param>
		/// <returns></returns>
		public bool OkToMove(int hvoDstOwner, int flidDst, int ihvoDstStart, ObjectDragInfo odi)
		{
			FDO.FdoCache cache = m_slice.Container.Cache;
			IFwMetaDataCache mdc = cache.MetaDataCacheAccessor;
			if (flidDst == odi.FlidSrc)
			{
				// Verify that it is not a no-operation.
				if (hvoDstOwner == odi.HvoSrcOwner)
				{
					// Same property of same object. If it's a collection, disable.
					int fieldType;
					mdc.GetFieldType((uint)flidDst, out fieldType);
					// We can't drag it to the position it's already at; that's no change. We also can't drag it
					// to the position one greater: that amounts to trying to place it after itself, which (after
					// removing it from before itself) amounts to a no-operation.
					if (fieldType == (int)FieldType.kcptOwningSequence && ihvoDstStart != odi.IhvoSrcStart &&
						ihvoDstStart != odi.IhvoSrcStart + 1)
					{
						// It's a sequence and the target and source positions are different, so we can do it.
						return true;
					}
				}
				else
				{
					// Different objects; need to verify no circular ownership involved.
					for (int ihvo = odi.IhvoSrcStart; ihvo <= odi.IhvoSrcEnd; ihvo++)
					{
						int hvo = cache.GetVectorItem(odi.HvoSrcOwner, odi.FlidSrc, ihvo);
						// See if hvoDstOwner is owned by hvo
						int hvo2 = hvoDstOwner;
						// loop from hvo2 to root owner of hvo2. If hvo2 or any of its owners is hvo,
						// we have a problem.
						while (hvo2 != 0)
						{
							if (hvo == hvo2)
								return false; // circular ownership, can't drop.
							hvo2 = cache.GetOwnerOfObject(hvo2);
						}
					}
					return true;
				}
			}
			else
			{
				// Different property, check signature.
				uint luclid;
				mdc.GetDstClsId((uint) flidDst, out luclid);
				for (int ihvo = odi.IhvoSrcStart; ihvo <= odi.IhvoSrcEnd; ihvo++)
				{
					int hvo = cache.GetVectorItem(odi.HvoSrcOwner, odi.FlidSrc, ihvo);
					uint cls = (uint) cache.GetClassOfObject(hvo);
					while (cls != 0 && cls != luclid)
					{
						mdc.GetBaseClsId(cls, out cls);
					}
					if (cls == 0)
						return false; // wrong signature, can't drop.
				}
				// All sigs OK, allow drop.
				return true;
			}
			// If none of those cases is OK, can't do it.
			return false;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		void HandlePaint(object sender, PaintEventArgs pea)
		{
			// Do nothing if invisible. Don't know why the framework even
			// calls us if invisible, but it does, and if we call NextFieldAtIndent
			// that generates more slices, which get drawn invisibly in turn, and 
			// laziness is defeated completely.
			if (pea.ClipRectangle.Height == 0 || pea.ClipRectangle.Width == 0)
				return;
			Graphics gr = pea.Graphics;

			Color lineColor = Color.FromKnownColor(KnownColor.ControlDark);
			Pen linePen = new Pen(lineColor, 1);
			linePen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
			Pen boxLinePen = new Pen(lineColor, 1);
			Brush backgroundBrush = new SolidBrush(m_slice.Diagram.BackColor);
			Brush lineBrush = new SolidBrush(lineColor);

			int nIndent = m_slice.Indent;
			DataTree.TreeItemState tis = m_slice.Expansion;
			// Drawing within a control that covers the tree node portion of this slice, we always
			// draw relative to a top-of-slice that is 0. I'm keeping the variable just in case
			// we ever go back to drawing in the parent window.
			int ypTopOfSlice = 0;
			int ypTopOfNextSlice = this.Height;
			int iSlice = m_slice.Container.Slices.IndexOf(m_slice);
			// Go through the indents, drawing the correct tree structure at each level.
			for (int nInd = 0; nInd <= nIndent; ++nInd)
			{
				int ypTreeTop = ypTopOfSlice;
				int xpBoxLeft = kdxpLeftMargin + nInd * kdxpIndDist;
				int xpBoxCtr = xpBoxLeft + kdxpBoxCtr;
				// Enhance JohnT: 2nd argument of max should be label height.
				int dypBranchHeight = m_slice.GetBranchHeight();
				int dypLeftOver = Math.Max(kdypBoxHeight / 2, dypBranchHeight) - kdypBoxHeight / 2;
				int ypBoxTop = ypTopOfSlice + dypLeftOver;
				int ypBoxCtr = ypBoxTop + kdypBoxHeight / 2;
				int xpRtLineEnd = xpBoxCtr + kdxpLongLineLen;

				// There are two possible locations for the start and stop points for the
				// vertical line. That will produce three different results which I have
				// attempted to illustrate below. In case that's unclear they are:
				// an L - shaped right angle, a T - shape rotated counter-clockwise by
				// 90 degrees and an inverted L shape (i.e. flipped vertically).
				//
				// |_  > ypStart = top of field, ypStop = center point of +/- box.
				// |-  > ypStart = top of field, ypStop = bottom of field.
				// |  > ypStart = center point of +/- box, ypStop = bottom of field.
				//
				// Draw the vertical line.
				bool fMoreFieldsAtLevel = (m_slice.Diagram.NextFieldAtIndent(nInd, iSlice) != 0);
				
				// We get a vertical line at all if this is the level of the node, or if
				// there is a following node at the level we are processing.
				if (nInd == nIndent || fMoreFieldsAtLevel)
				{
					int ypStop = ypBoxCtr + 1;
					if (fMoreFieldsAtLevel)
					{
						// If there are more fields at this level, the line goes right through the
						// field; otherwise (as set above) it stops half way.
						ypStop = ypTopOfNextSlice;
					}
					int ypStart = ypTreeTop; // usually start line at top of field
					if (iSlice == 0 && fMoreFieldsAtLevel)
						ypStart = ypBoxCtr;
					gr.DrawLine(linePen, xpBoxCtr, ypStart, xpBoxCtr, ypStop);
				}

				// Draw the line to the right of the box.
				if (nInd == nIndent)
					gr.DrawLine(linePen,xpBoxCtr + 2, ypBoxCtr, xpRtLineEnd, ypBoxCtr);

				// Process a terminal level with a box.
				if (nInd == nIndent && tis != DataTree.TreeItemState.ktisFixed)
				{
					// Draw the box.
					Rectangle rcBox = new Rectangle(xpBoxLeft, ypBoxTop, kdxpBoxWid, kdypBoxHeight);
					gr.FillRectangle(lineBrush, rcBox);
					// Erase the inside of the box as we may have drawn dotted lines there.
					rcBox.Inflate(-1, -1);
					gr.FillRectangle(backgroundBrush, rcBox);

					if (tis != DataTree.TreeItemState.ktisCollapsedEmpty)
					{
						// Draw the minus sign.
						int xpLeftMinus = xpBoxLeft + 1 + kdzpIconGap;
						gr.DrawLine(boxLinePen, xpLeftMinus, ypBoxCtr, xpLeftMinus + kdxpIconWid - 1, ypBoxCtr);

						if (tis == DataTree.TreeItemState.ktisCollapsed)
						{
							// Draw the vertical part of the plus, if we are collapsed.
							int ypTopPlus = ypBoxTop + 1 + kdzpIconGap;
							gr.DrawLine(boxLinePen, xpBoxCtr, ypTopPlus, xpBoxCtr, ypTopPlus + kdypIconHeight - 1);
						}
					}
				}
			}

			// If the height of the slice is greater then one line (1.5 * LabelHeight) and
			// the slice has a child, then we need to draw a line to that child. (fixes a
			// gap that appears otherwise)
			int left = kdxpLeftMargin + (nIndent + 1) * kdxpIndDist;
			int center = left + kdxpBoxCtr;
			bool fHasChildren = (m_slice.Diagram.NextFieldAtIndent(nIndent + 1, iSlice) != 0);
			if (fHasChildren && Height > m_slice.LabelHeight * 1.5)
			{
				gr.DrawLine(linePen, center, ypTopOfSlice + m_slice.LabelHeight, 
					center, ypTopOfNextSlice);
			}

			m_slice.DrawLabel(ypTopOfSlice, gr, pea.ClipRectangle.Width);
		}


		/// <summary>
		/// Double-click causes expand/contract wherever it is.
		/// </summary>
		/// <param name="e"></param>
		protected override void OnDoubleClick(EventArgs e)
		{
			base.OnDoubleClick (e);
			if (m_slice.Expansion != DataTree.TreeItemState.ktisFixed)
			{
				int iSlice = m_slice.Container.Slices.IndexOf(m_slice);
				ToggleExpansionAndScroll(iSlice);
			}
		}


		/// <summary>
		/// Preliminary version of mouse down handles expansion and contraction.
		/// Todo:
		///		- Scroll appropriately to show as much as possible of what was expanded.
		///		- drag and drop effects.
		///		- double-click on label also toggles expansion.
		/// </summary>
		protected override void OnMouseDown(MouseEventArgs meArgs)
		{
			//in light of what JT says below, we need to explicitly tell the slice that
			//we were clicked on, because we cannot count on a normal Click event
			//which we would normally just subscribe to, as we do with the slice editor controls.
			this.Slice.OnTreeNodeClick(this, meArgs);

			// The documentation says we should call the base class. Not doing so means that
			// mouse down handlers can't be attached to this class by delegation.
			// However, the base class implementation has a catastrophic side effect: it causes
			// this control to be selected, in a sense that causes it to be scrolled into
			// view every time a lazy slice is expanded into a real one. This is the first
			// successful way I (JT) found to defeat this behavior, and I tried many.
			//base.OnMouseDown(meArgs);
			if (meArgs.Button.Equals(MouseButtons.Right))
			{
				//begin test (JDH)
				Point p = new Point(meArgs.X,meArgs.Y);
				if (m_slice.HandleMouseDown(p))
				{
					return;
				}
				//end test
				
				//				// Setup the context menu every time, because it contains information about
				//				// item positions that can be invalidated by inserting items, etc.
				//		SetupContextMenu();
				//				return;
			}


			int xp = meArgs.X;
			// xpText is the left side of the tree label.
			int xpText = kdxpLeftMargin + kdxpIndDist + m_slice.Indent * kdxpIndDist;
			// If we are over the +/- box...
			if (xp < xpText && xp >= xpText - kdxpIndDist)
			{
				// Handle label expansion and contraction.
				if (m_slice.Expansion != DataTree.TreeItemState.ktisFixed)
				{
					int iSlice = m_slice.Container.Slices.IndexOf(m_slice);
					ToggleExpansionAndScroll(iSlice);
				}
			}
			else
			{
				// Enhance JohnT: Could we find a better label that shows more clearly what is being moved?
				int hvoSrcOwner;
				int flidSrc;
				int ihvoSrcStart;
				if (!m_slice.GetSeqContext(out hvoSrcOwner, out flidSrc, out ihvoSrcStart))
					return; // If we can't identify an object to move, don't do a drag.
				ObjectDragInfo objinfo = new ObjectDragInfo(hvoSrcOwner, flidSrc, ihvoSrcStart, ihvoSrcStart, m_slice.Label);
				DataObject dataobj = new DataObject(objinfo);
				// Initiate a drag/drop operation. Currently we only support move.
				// Enhance JohnT: Also support Copy.
				DoDragDrop(dataobj, DragDropEffects.Move);
			}
		}

	

		/// <summary>
		/// Toggle the expansion state of the slice at iSlice. May presume it is already in existence.
		/// Todo: attempt to scroll so new children are visible
		/// </summary>
		/// <param name="iSlice"></param>
		public void ToggleExpansionAndScroll(int iSlice)
		{
			ToggleExpansion(iSlice);
		}

		/// <summary>
		/// Toggle the expansion state of the slice at iSlice. May presume it is already in existence.
		/// (If it is in the collapsedEmpty or fixed states, do nothing.)
		/// </summary>
		/// <param name="iSlice"></param>
		public void ToggleExpansion(int iSlice)
		{
			if (m_slice.Expansion == DataTree.TreeItemState.ktisCollapsed)
			{
				// expand it
				m_slice.Expand(iSlice);
			}
			else if (m_slice.Expansion == DataTree.TreeItemState.ktisExpanded)
			{
				// collapse it
				m_slice.Collapse(iSlice);
			}
			else
			{
				// Either collapsedEmpty, or the user happened to click in the area
				// that the box would occupy in a fixed node...in either case, nothing to do.
			}
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// SliceTreeNode
			// 
			this.Name = "SliceTreeNode";
			this.Size = new System.Drawing.Size(150, 70);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SliceTreeNode_KeyPress);
			this.MouseEnter += new System.EventHandler(this.SliceTreeNode_MouseEnter);
			this.MouseHover += new System.EventHandler(this.SliceTreeNode_MouseHover);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SliceTreeNode_KeyDown);
			this.MouseLeave += new System.EventHandler(this.SliceTreeNode_MouseLeave);

		}
		#endregion

		private void SliceTreeNode_MouseHover(object sender, System.EventArgs e)
		{
			m_slice.Highlighted = true;
		}

		private void SliceTreeNode_MouseEnter(object sender, System.EventArgs e)
		{
			m_slice.Highlighted = true;		
		}


		private void SliceTreeNode_MouseLeave(object sender, System.EventArgs e)
		{			
			m_slice.Highlighted = false;	
		}

		//!!!this is never called  (arrrgggghhh)
		private void SliceTreeNode_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Debug.WriteLine("TreeNode key press");
		}

		//!!!this is never called  (arrrgggghhh)
		private void SliceTreeNode_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			Debug.WriteLine("TreeNode key down");
		
		}

		//		protected override bool ProcessKeyEventArgs(ref Message m)
		//		{
		//			return true;
		//		}
	}

	[Serializable()] 
	public class ObjectDragInfo : ISerializable
	{
		int m_hvoSrcOwner;
		int m_flidSrc;
		int m_ihvoSrcStart;
		int m_ihvoSrcEnd;
		string m_label; // The label to display during dragging.

		public ObjectDragInfo(int hvoSrcOwner, int flidSrc, int ihvoSrcStart, int ihvoSrcEnd, string label)
		{
			m_hvoSrcOwner = hvoSrcOwner;
			m_flidSrc = flidSrc;
			m_ihvoSrcStart = ihvoSrcStart;
			m_ihvoSrcEnd = ihvoSrcEnd;
			m_label = label;
		}

		public override string ToString()
		{
			return m_label;
		}

		//Deserialization constructor.
		public ObjectDragInfo (SerializationInfo info, StreamingContext context) 
		{
			m_hvoSrcOwner = (int)info.GetValue("SrcOwner", typeof(int));
			m_flidSrc = (int)info.GetValue("FlidSrc", typeof(int));
			m_ihvoSrcStart = (int)info.GetValue("IhvoSrcStart", typeof(int));
			m_ihvoSrcEnd = (int)info.GetValue("IhvoSrcEnd", typeof(int));
			m_label = (String)info.GetValue("label", typeof(string));
		}

		//Serialization function.
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("SrcOwner", m_hvoSrcOwner);
			info.AddValue("FlidSrc", m_flidSrc);
			info.AddValue("IhvoSrcStart", m_ihvoSrcStart);
			info.AddValue("IhvoSrcEnd", m_ihvoSrcEnd);
			info.AddValue("label", m_label);
		}

		public int HvoSrcOwner
		{
			get
			{
				return m_hvoSrcOwner;
			}
		}
		public int FlidSrc
		{
			get
			{
				return m_flidSrc;
			}
		}
		public int IhvoSrcStart
		{
			get
			{
				return m_ihvoSrcStart;
			}
		}
		public int IhvoSrcEnd
		{
			get
			{
				return m_ihvoSrcEnd;
			}
		}
	}
}
