using System;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;

using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.RootSites;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.LangProj.Generated;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;
using SIL.FieldWorks.FDO.Ling;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for ViewPropertyItem.
	/// </summary>
	public class MultiStringSlice : ViewPropertySlice
	{
		public class MultiStringSliceVc: VwBaseVc
		{
			int m_flid;
			LgWritingSystem [] m_rgws; // writing systems to display
			ITsTextProps m_ttpLabel; // Props to use for ws name labels
			int m_wsUI;		// ws to use to display UI stuff, such as WS name labels.


			public MultiStringSliceVc(int flid, LgWritingSystem[] rgws, int wsUser)
			{
				m_flid = flid;
				m_rgws = rgws;
				m_wsUI = wsUser;
				m_ttpLabel = LgWritingSystem.AbbreviationTextProperties;
				// Here's the C++ code which does the same thing using styles.
//				StrUni stuLangCodeStyle(L"Language Code");
//				ITsPropsFactoryPtr qtpf;
//				qtpf.CreateInstance(CLSID_TsPropsFactory);
//				StrUni stu;
//				ITsStringPtr qtss;
//				ITsStrFactoryPtr qtsf;
//				qtsf.CreateInstance(CLSID_TsStrFactory);
//				// Get the properties of the "Language Code" style for the writing system
//				// which corresponds to the user's environment.
//				qtpf->MakeProps(stuLangCodeStyle.Bstr(), ???->UserWs(), 0, &qttp);
			}


			ITsString NameOfWs(ITsStrFactory tsf, int i)
			{
				return tsf.MakeString(m_rgws[i].Abbreviation, m_wsUI);
			}


			public override void Display(IVwEnv vwenv, int hvo, int frag)
			{
				if (m_rgws.Length == 1)
				{
					// Single option...don't bother with labels.
					vwenv.AddStringAltMember(m_flid, m_rgws[0].Hvo, this);
					return;
				}
				ITsStrFactory tsf = (ITsStrFactory)new FwKernelLib.TsStrFactoryClass();
				// We use a table to display
				// encodings in column one and the strings in column two.
				// The table uses 100% of the available width.
				FwViews.VwLength vlTable;
				vlTable.nVal = 10000;
				vlTable.unit = FwViews.VwUnit.kunPercent100;

				// The width of the writing system column is determined from the width of the
				// longest one which will be displayed.
				int dxs;	// Width of displayed string.
				int dys;	// Height of displayed string (not used here).
				int dxsMax = 0;	// Max width required.
				for (int i = 0; i < m_rgws.Length; ++i)
				{
					// Set qtss to a string representing the writing system.
					vwenv.get_StringWidth(NameOfWs(tsf, i),
						m_ttpLabel, out dxs, out dys);
					dxsMax = Math.Max(dxsMax, dxs);
				}
				FwViews.VwLength vlColWs; // 5-pt space plus max label width.
				vlColWs.nVal = dxsMax + 5000;
				vlColWs.unit = FwViews.VwUnit.kunPoint1000;

				// Enhance JohnT: possibly allow for right-to-left UI by reversing columns?

				// The Main column is relative and uses the rest of the space.
				FwViews.VwLength vlColMain;
				vlColMain.nVal = 1;
				vlColMain.unit = FwViews.VwUnit.kunRelative;

				vwenv.OpenTable(2, // Two columns.
					ref vlTable, // Table uses 100% of available width.
					0, // Border thickness.
					FwViews.VwAlignment.kvaLeft, // Default alignment.
					FwViews.VwFramePosition.kvfpVoid, // No border.
					FwViews.VwRule.kvrlNone, // No rules between cells.
					0, // No forced space between cells.
					0); // No padding inside cells.
				// Specify column widths. The first argument is the number of columns,
				// not a column index. The writing system column only occurs at all if its
				// width is non-zero.
				vwenv.MakeColumns(1, vlColWs);
				vwenv.MakeColumns(1, vlColMain);

				vwenv.OpenTableBody();

				// Add a row for each writing system.
				for (int i = 0; i < m_rgws.Length; ++i)
				{
					vwenv.OpenTableRow();

					// First cell has writing system abbreviation displayed using m_ttpLabel.
					vwenv.set_Props(m_ttpLabel);
					vwenv.OpenTableCell(1,1);
					vwenv.AddString(NameOfWs(tsf, i));
					vwenv.CloseTableCell();

					// Second cell has the string contents for the alternative.
					// DN version has some property setting, including trailing margin and
					// RTL.
					vwenv.OpenTableCell(1,1);
					vwenv.AddStringAltMember(m_flid, m_rgws[i].Hvo, this);
					vwenv.CloseTableCell();

					vwenv.CloseTableRow();
				}
				vwenv.CloseTableBody();

				vwenv.CloseTable();
			}
		}

		class MultiStringSliceView : RootSiteControl
		{
			int m_hvoObj;
			int m_flid;
			int m_wsMagic;
			LgWritingSystem[] m_rgws;
			IVwViewConstructor m_vc = null;
			
			public MultiStringSliceView(int hvo, int flid, int wsMagic)
			{
				m_hvoObj = hvo;
				m_flid = flid;
				m_wsMagic = wsMagic;
			}

			/// <summary>
			/// Return an array of writing systems given an array of their HVOs.
			/// </summary>
			/// <returns></returns>
			public LgWritingSystem[] WssFromHvos(int[] hvos)
			{
				LgWritingSystem [] result = new LgWritingSystem[hvos.Length];
				for (int i = 0; i < hvos.Length; i++)
				{
					result[i] = new LgWritingSystem(m_fdoCache, hvos[i]);
				}
				return result;
			}
			public LgWritingSystem[] AnalysisWritingSystems()
			{
				return WssFromHvos(m_fdoCache.LanguageProject.CurrentAnalysisWritingSystemsRS.HvoArray);
			}
			public LgWritingSystem[] VernacularWritingSystems()
			{
				return WssFromHvos(m_fdoCache.LanguageProject.CurrentVernacularWritingSystemsRS.HvoArray);
			}
			/// <summary>
			/// Make an array which contains all the members of first() plus those of second() that
			/// are not included in first.
			/// </summary>
			/// <param name="first"></param>
			/// <param name="second"></param>
			/// <returns></returns>
			public int[] MergeTwoArrays(int[] first, int[] second)
			{
				ArrayList al = new ArrayList();
				al.AddRange(first);
				foreach (int hvo in second)
				{
					if (al.IndexOf(hvo) < 0)
						al.Add(hvo);
				}
				int[] list = new int[al.Count];
				for(int i = 0; i < al.Count; i++)
					list[i] = (int) al[i];
				return list;
			}
			public LgWritingSystem[] VernacularAnalysisWss()
			{
				return WssFromHvos(MergeTwoArrays(m_fdoCache.LanguageProject.CurrentVernacularWritingSystemsRS.HvoArray,
					m_fdoCache.LanguageProject.CurrentAnalysisWritingSystemsRS.HvoArray));
			}
			public LgWritingSystem[] AnalysisVernacularWss()
			{
				return WssFromHvos(MergeTwoArrays(m_fdoCache.LanguageProject.CurrentAnalysisWritingSystemsRS.HvoArray,
					m_fdoCache.LanguageProject.CurrentVernacularWritingSystemsRS.HvoArray));
			}

			public override void MakeRoot()
			{
				m_rootb = null;
				base.MakeRoot();

				if (m_fdoCache == null || DesignMode)
					return;

				switch(m_wsMagic)
				{
					case LanguageProject.kwsAnals:
						m_rgws = AnalysisWritingSystems();
						break;
					case LanguageProject.kwsVerns:
						m_rgws = VernacularWritingSystems();
						break;
					case LanguageProject.kwsAnalVerns:
						m_rgws = AnalysisVernacularWss();
						break;
					case LanguageProject.kwsVernAnals:
						m_rgws = VernacularAnalysisWss();
						break;
					default: // for now some sort of default.
						m_rgws = AnalysisWritingSystems();
						break;
				}

				// A crude way of making sure the property we want is loaded into the cache.
				FDO.CmObject.CreateFromDBObject(m_fdoCache, m_hvoObj);

				int wsUser = m_fdoCache.LanguageWritingSystemFactoryAccessor.get_UserWs();
				m_vc = new MultiStringSliceVc(m_flid, m_rgws, wsUser);

				// Review JohnT: why doesn't the base class do this??
				m_rootb = (IVwRootBox)new FwViews.VwRootBoxClass();
				m_rootb.SetSite(this);

				// And maybe this too, at least by default?
				m_rootb.set_DataAccess(m_fdoCache.MainCacheAccessor);

				// arg3 is a meaningless initial fragment, since this VC only displays one thing.
				// arg4 could be used to supply a stylesheet.
				m_rootb.SetRootObject(m_hvoObj, m_vc, 1, m_styleSheet);
			}
		}
		public MultiStringSlice(int hvoObj, int flid, int ws) : base(new MultiStringSliceView(hvoObj, flid, ws), hvoObj, flid)
		{
		}
	}
}
