// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2004, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2004' company='SIL International'>
//		Copyright (c) 2004, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: SliceFactory.cs
// Responsibility: WordWorks
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Xml;
using System.Diagnostics;
using System.IO;

using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Utils;
using SIL.FieldWorks.Common.Controls;
using SIL.Utils;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for SliceFactory.
	/// </summary>
	public class SliceFactory
	{
		public SliceFactory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Look for a simple writing system spec as part of a node...currently either 'analysis' or 'vernacular'.
		/// If not found, answer 0.
		/// If found, answer the ID of the appropriate writing system, or throw exception if not valid.
		/// </summary>
		/// <param name="cache"></param>
		/// <param name="node"></param>
		/// <returns></returns>
		static int GetWs(FdoCache cache, XmlNode node)
		{
			string wsSpec = XmlUtils.GetOptionalAttributeValue(node, "ws");
			if (wsSpec != null)
			{
				int ws = 0;
				if (wsSpec == "vernacular")
					ws = cache.LanguageProject.DefaultVernacularWritingSystem;
				else if (wsSpec == "analysis")
					ws = cache.LanguageProject.DefaultAnalysisWritingSystem;
				else
					throw new ApplicationException("ws must be 'vernacular' or 'analysis'" + " it said '" + wsSpec + "'.");
				return ws;
			}
			else
				return 0;
		}

		

		public static Slice Create(FdoCache cache, string editor, int flid, XmlNode node, FDO.CmObject obj, StringTable stringTbl, IPersistenceProvider persistenceProvider)
		{
			Slice slice = null;
			switch(editor)
			{
				case "string":
				{
					if (flid == 0)
						throw new ApplicationException("attr attribute required for basic properties " + node.OuterXml);
					int ws = GetWs(cache, node);
					if (ws != 0)
						slice = new StringSlice(obj.Hvo, flid, ws);
					else
						slice = new StringSlice(obj.Hvo, flid);
					break;
				}
				case "multistring":
				{
					if (flid == 0)
						throw new ApplicationException("attr attribute required for multistring " + node.OuterXml);
					string wsSpec = XmlUtils.GetOptionalAttributeValue(node, "ws");
					int wsMagic;
					switch(wsSpec)
					{
						case "all vernacular":
							wsMagic = LanguageProject.kwsVerns;
							break;
						case "all analysis":
							wsMagic = LanguageProject.kwsAnals;
							break;
						case "analysis vernacular":
							wsMagic = LanguageProject.kwsAnalVerns;
							break;
						case "vernacular analysis":
							wsMagic = LanguageProject.kwsVernAnals;
							break;
						default:
							throw new ApplicationException(
								"ws must be 'all vernacular', 'all analysis', 'analysis vernacular', or 'vernacular analysis'"
								+ " it said '" + wsSpec + "'.");
					}
					slice = new MultiStringSlice(obj.Hvo, flid, wsMagic);
					break;
				}
				case "jtview":
				{
					slice = new ViewSlice(new XmlView(obj.Hvo, node["deParams"], stringTbl));
					break;
				}
				case "enumcombobox":
				{
					slice = new EnumComboSlice(cache, obj, flid, stringTbl, node["deParams"]);
					break;
				}
				case "referencecombobox":
				{
					slice = new ReferenceComboBoxSlice(cache, obj, flid, persistenceProvider);
					break;
				}
				case "msareferencecombobox":
				{
					slice = new MSAReferenceComboBoxSlice(cache, obj, flid,persistenceProvider);
					break;
				}
				case "message":
				{
					slice = new MessageSlice(XmlUtils.GetManditoryAttributeValue(node, "param1"));
					break;
				}
				case "image":
				{
					try
					{
						slice = new ImageSlice(DirectoryFinder.FWInstallDirectory, XmlUtils.GetManditoryAttributeValue(node, "param1"));
					}
					catch (Exception error)
					{
						slice = new MessageSlice("Could not create the ImageSlice. " + error.Message);
					}
					break;
				}
				case "checkbox":
				{
					slice = new CheckboxSlice(cache, obj, flid);
					break;
				}
				case "time":
				{
					slice = new DateSlice(cache, obj, flid);
					break;
				}
				case "integer":
				{
					slice = new IntegerSlice(cache, obj, flid);
					break;
				}
			
				case "defaultatomicreference":
				{
					slice = new AtomicReferenceSlice(cache, obj, flid, node, persistenceProvider, stringTbl);
					break;
				}
			
				case "derivmsareference":
				{
					slice = new DerivMSAReferenceSlice(cache, obj, flid, node, persistenceProvider, stringTbl);
					break;
				}
			
				case "inflmsareference":
				{
					slice = new InflMSAReferenceSlice(cache, obj, flid, node, persistenceProvider, stringTbl);
					break;
				}
							
				case "defaultvectorreference":
				{
					slice = new ReferenceVectorSlice(cache, obj, flid, node, persistenceProvider, stringTbl);
					break;
				}

				case "phoneenvreference":
				{
					slice = new PhoneEnvReferenceSlice(cache, obj, flid, node, persistenceProvider, stringTbl);
					break;
				}

				case "sttext":
				{
					slice = new StTextSlice(obj.Hvo, flid, GetWs(cache, node));
					break;
				}

				case "custom":
				{
					slice = (Slice)DynamicLoader.CreateObject(node);
					break;
				}
				
				case "customwithparams":
				{
					slice = (Slice)DynamicLoader.CreateObject(node, 
						new object[]{cache, editor, flid, node, obj, stringTbl, 
										persistenceProvider, GetWs(cache, node)});
					break;
				}

				case "command":
				{
					slice = new CommandSlice(node["deParams"]);
					break;
				}

				case null:	//grouping nodes do not necessarily have any editor
					{
						slice = new Slice();
						break;
					}		

				default:
				{
					//Since the editor has not been implemented yet,
					//is there a bitmap file that we can show for this editor?
					//Such bitmaps belong in the distFiles xde directory
					string fwInstallDir = DirectoryFinder.FWInstallDirectory;
					string editorBitmapRelativePath = @"xde\" + editor + ".bmp";
					if(System.IO.File.Exists(Path.Combine(fwInstallDir, editorBitmapRelativePath)))
						slice = new ImageSlice(fwInstallDir, editorBitmapRelativePath);
					else
						slice = new MessageSlice("Editor type '" + editor + "' not implemented.");
					break;
				}
			}
			return slice;
		}
	}
}
