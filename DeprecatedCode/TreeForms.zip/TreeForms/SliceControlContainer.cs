using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for SliceControlContainer.
	/// </summary>
	public class SliceControlContainer : System.Windows.Forms.UserControl, IContainerControl
	{
		private DataTree m_dataTree;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SliceControlContainer()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}

		public SliceControlContainer(DataTree tree)
		{
			Debug.Assert(tree != null);
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			m_dataTree = tree;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
				m_dataTree = null;
			}
			base.Dispose( disposing );
		}

		new public Control ActiveControl
		{
			get { return base.ActiveControl; }
			set
			{
				Debug.Assert(m_dataTree != null);
				base.ActiveControl = value;
				foreach (Slice slice in m_dataTree.Slices)
					if (slice.Control == value && m_dataTree.CurrentSlice != slice)
						m_dataTree.CurrentSlice = slice;
			}
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion
	}
}
