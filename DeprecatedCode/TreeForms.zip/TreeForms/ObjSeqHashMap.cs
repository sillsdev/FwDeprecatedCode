using System;
using System.Collections;


namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// An object sequence hash map represents a mapping from sequences of objects to sequences of objects.
	/// The key may be anything that implements IList. The value is also a list.
	/// It is expected that very commonly only one value will be stored for a given key.
	/// The implementation is optimized for this by storing the object directly rather than a sequence
	/// holding the one object. Two objects are typically stored as an array, three or more as an ArrayList.
	/// (This means lists of lists don't work.)
	/// </summary>
	public class ObjSeqHashMap
	{
		Hashtable m_table;
		public ObjSeqHashMap()
		{
			m_table = new Hashtable(new ListHashCodeProvider(), new ListComparer());
		}
		public IList this[IList keyList]
		{
			get
			{
				object result = m_table[keyList];
				if (result == null)
					return new object[0];
				else return (IList) result;
			}
		}
		/// <summary>
		/// Add the item to the list associated with this key.
		/// </summary>
		/// <param name="keyList"></param>
		/// <param name="obj"></param>
		public void Add(IList keyList, object obj)
		{
			ArrayList list = (ArrayList)(m_table[keyList]);
			if (list == null)
			{
				list = new ArrayList(1);
				m_table[keyList] = list;
			}
			list.Add(obj);
		}
		/// <summary>
		/// Remove the argument object from the indicated collection.
		/// Currently it is not considered an error if the object is not found, just nothing happens.
		/// </summary>
		/// <param name="keyList"></param>
		/// <param name="obj"></param>
		public void Remove(IList keyList, object obj)
		{
			ArrayList list = (ArrayList)(m_table[keyList]);
			if (list == null)
				return;
			list.Remove(obj);
		}
	}

	/// <summary>
	/// This comparer is only suitable for hash tables; it doesn't provide a valid (commutative) ordering of items.
	/// Returns -1 for any non-equal items.
	/// Note that in general, boxed values are not equal, even if the unboxed values would be. The current code makes
	/// a special case for ints, which behave as expected.
	/// </summary>
	public class ListComparer : IComparer
	{
		public int Compare(object xArg, object yArg)
		{
			IList listX = (IList) xArg;
			IList listY = (IList) yArg;
			if (listX.Count != listY.Count)
				return -1;
			for (int i = 0; i < listX.Count; i++)
			{
				object x = listX[i];
				object y = listY[i];
				if (x!= y && !(x is int && y is int && ((int)x) == ((int)y)))
					return -1;
			}
			return 0; // equal.
		}
	}
	public class ListHashCodeProvider : IHashCodeProvider
	{
		public int GetHashCode(object objList)
		{
			IList list = (IList) objList;
			int hash = 0;
			foreach (object obj in list)
			{
				// This ensures that two sequences containing the same boxed integer produce the same hash value.
				if (obj is int)
					hash += (int) obj;
				else
					hash += obj.GetHashCode();
			}
			return hash;
		}
	}
	// Alternative implementation tries to be smart about storing singletons and pairs efficiently.
//	public class ObjSeqHashMap
//	{
//		Hashtable m_table;
//		public ObjSeqHashMap()
//		{
//			m_table = new Hashtable(new ListHashCodeProvider(), new ListComparer());
//		}
//		public IList this[IList keyList]
//		{
//			get
//			{
//				object result = m_table[keyList];
//				if (result == null)
//					return new object[0];
//				else if (result is IList)
//					return (IList) result;
//				else return new object[] {result};
//			}
//			set
//			{
//				m_table[keyList] = value; // works if value is null, single object, array, or list.
//			}
//		}
//		/// <summary>
//		/// Add the item to the list associated with this key.
//		/// </summary>
//		/// <param name="keyList"></param>
//		/// <param name="obj"></param>
//		public void Add(IList keyList, object obj)
//		{
//			object current = m_table[keyList];
//			if (current == null)
//				m_table[keyList] = obj; // put it in as a singleton
//			else if (current is object[])
//			{
//				ArrayList newVal = new ArrayList((object[])current);
//				newVal.Add(obj);
//				m_table[keyList] = newVal;
//			}
//			else if (current is IList)
//				((IList)current).Add(obj);
//			else
//				m_table[keyList] = new object[] {current, obj};
//		}
//		/// <summary>
//		/// Remove the argument object from the indicated collection.
//		/// Currently it is not considered an error if the object is not found, just nothing happens.
//		/// </summary>
//		/// <param name="keyList"></param>
//		/// <param name="obj"></param>
//		public void Remove(IList keyList, object obj)
//		{
//			object current = m_table[keyList];
//			if (current == obj)
//				m_table.Remove(keyList);
//			if (current is IList)
//			{
//				IList currentList = (IList) current;
//				int index = currentList.IndexOf(obj);
//				if (index < 0)
//					return;
//				if (currentList.Count == 1)
//				{
//					m_table.Remove(keyList);
//					return;
//				}
//				if (currentList.Count == 2)
//				{
//					object survivor = currentList[0];
//					if (index == 0)
//						survivor = currentList[1];
//					m_table[keyList] = survivor;
//					return;
//				}
//				if (!(current is ArrayList))
//				{
//					currentList = new ArrayList(currentList);
//					m_table[keyList] = currentList;
//				}
//				currentList.RemoveAt(index);
//			}
//			// otherwise it isn't there, do nothing.
//		}
//	}

}
