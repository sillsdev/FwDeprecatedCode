// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2005, SIL International. All Rights Reserved.   
// <copyright from='2005' to='2005' company='SIL International'>
//		Copyright (c) 2005, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: InflMSAReferenceSlice.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Xml;


using SIL.FieldWorks.Common.Controls;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.Utils;
using SIL.FieldWorks.Common.Utils;


namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// This class is used to manage handling of the PartOfSpeech property of a MoInflectionalAffixMsa.
	/// Depending on the value of that property, the Slot property needs to be kept valid.
	/// </summary>
	public class InflMSAReferenceSlice : AtomicReferenceSlice
	{
		public InflMSAReferenceSlice()
		{
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="AtomicReferenceSlice"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public InflMSAReferenceSlice(FdoCache cache, CmObject obj, int flid, 
			XmlNode configurationNode, SIL.Utils.IPersistenceProvider persistenceProvider,
			StringTable stringTbl)
			: base(cache, obj, flid, configurationNode, persistenceProvider, stringTbl)
		{
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="persistenceProvider"></param>
		/// <param name="stringTbl"></param>
		protected override void SetupControls(IPersistenceProvider persistenceProvider,
			StringTable stringTbl)
		{
			base.SetupControls(persistenceProvider, stringTbl);
			AtomicReferenceLauncher arl = Control as AtomicReferenceLauncher;
			arl.ReferenceChanged += new FwSelectionChangedEventHandler(OnReferenceChanged);
		}

		#region Event handlers

		/// <summary>
		/// Handle interaction between POS and Slot ptoeprties for a inflectional affix MSA.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// <remarks>
		/// If the new value is zero, then set the Slot prop to zero.
		/// If the new value is not zero, then make sure the Slot prop is valid.
		///		If the current slot is not legal for the new POS value, then set it to zero.
		///		Otherwise leave the slot value alone.
		/// </remarks>
		protected void OnReferenceChanged(object sender, SIL.FieldWorks.Common.Utils.FwObjectSelectionEventArgs e)
		{
			Debug.Assert(sender is AtomicReferenceLauncher);
			AtomicReferenceLauncher source = (AtomicReferenceLauncher)sender;
			Debug.Assert(Control == source);
			Debug.Assert(Object is MoInflectionalAffixMsa);

			SliceCollection col = m_containingDataTree.Slices;
			int idxSender = col.IndexOf(this);

			int otherFlid = (int)MoInflectionalAffixMsa.MoInflectionalAffixMsaTags.kflidSlot;
			Slice otherSlice = null;
			int idxOther;

			// Try to get the Slot slice.
			// Check for slices before this one.
			if (idxSender > 0)
			{
				idxOther = idxSender - 1;
				while (idxOther >= 0
					&& (otherSlice == null
						|| (otherSlice.Indent == Indent && idxOther > 0 && otherSlice.Object == Object)))
				{
					otherSlice = col[idxOther--];
					if (otherSlice is AtomicReferenceSlice && (otherSlice as AtomicReferenceSlice).Flid == otherFlid)
						break;
					otherSlice = null;
				}
			}

			// Check for following slices, if we didn't get one earlier.
			if (otherSlice == null && idxSender < col.Count)
			{
				idxOther = idxSender + 1;
				while (idxOther < col.Count
					&& (otherSlice == null
						|| (otherSlice.Indent == Indent && idxOther > 0 && otherSlice.Object == Object)))
				{
					otherSlice = col[idxOther++];
					if (otherSlice is AtomicReferenceSlice && (otherSlice as AtomicReferenceSlice).Flid == otherFlid)
						break;
					otherSlice = null;
				}
			}

			AtomicReferenceLauncher otherControl = null;
			if (otherSlice != null)
			{
				Debug.Assert((otherSlice as AtomicReferenceSlice).Flid == otherFlid);
				Debug.Assert(otherSlice.Object == Object);
				otherControl = otherSlice.Control as AtomicReferenceLauncher;
				Debug.Assert(otherControl != null);
			}

			MoInflectionalAffixMsa msa = Object as MoInflectionalAffixMsa;
			int slotHvo = msa.SlotRAHvo;
			if (e.Hvo == 0 || slotHvo > 0)
			{
				PartOfSpeech pos = msa.PartOfSpeechRA;
				ArrayList slotIDs = new ArrayList();
				if (pos != null)
					slotIDs = pos.AllAffixSlotIDs;
				bool clearSlot = e.Hvo == 0
					|| !slotIDs.Contains(slotHvo);
				if (clearSlot)
				{
					if (otherControl == null)
						msa.SlotRAHvo = 0; // The slot slice is not showing, so directly set the object's Slot property.
					else
						otherControl.AddItem(0); // Reset it using the other slice, so it gets refreshed.
				}
			}
		}

		#endregion Event handlers
	}
}
