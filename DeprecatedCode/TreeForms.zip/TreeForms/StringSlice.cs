using System;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;

using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.RootSites;
using SIL.FieldWorks.FDO;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for ViewPropertyItem.
	/// </summary>
	public class StringSlice : ViewPropertySlice
	{
		int m_ws = -1;
		public StringSlice(int hvoObj, int flid) : base(new StringSliceView(hvoObj, flid, -1), hvoObj, flid)
		{
		}

		public StringSlice(int hvoObj, int flid, int ws) : base(new StringSliceView(hvoObj, flid, ws), hvoObj, flid)
		{
			m_ws = ws;
		}

		/// <summary>
		/// This constructor is mainly intended for subclasses in other DLLs created using the 'custom' element.
		/// Such subclasses must set the ContextObject, the FieldId, and if relevant the Ws, and then call
		/// CreateView(), typically from an override of FinishInit().
		/// </summary>
		public StringSlice()
		{
		}

		/// <summary>
		/// See comments on no-arg constructor. Call only if using that constructor.
		/// </summary>
		public void CreateView()
		{
			Control = new StringSliceView(m_hvoContext, m_flid, m_ws);
		}

		/// <summary>
		/// Get/set the writing system ID. If -1, signifies a non-multilingual property.
		/// </summary>
		public int WritingSystemId
		{
			get { return m_ws; }
			set { m_ws = -1; }
		}


		#region View Constructors

		public class StringSliceVc: VwBaseVc
		{
			int m_flid;
			int m_ws = -1; // -1 signifies not a multilingual property
			public StringSliceVc(int flid, int ws)
			{
				m_flid = flid;
				m_ws = ws;
			}
			public override void Display(IVwEnv vwenv, int hvo, int frag)
			{
				if (m_ws == -1)
					vwenv.AddStringProp(m_flid, this);
				else
					vwenv.AddStringAltMember(m_flid, m_ws, this);
			}
		}

		public class UnicodeStringSliceVc: VwBaseVc
		{
			int m_flid;
			int m_ws;
			public UnicodeStringSliceVc(int flid, int ws, FdoCache fdoCache)
			{
				m_flid = flid;
				if (ws == -1)
				{
					// not specified, use the user interface ws.
					m_ws = fdoCache.LanguageWritingSystemFactoryAccessor.get_UserWs();
				}
				else
				{
					m_ws = ws;
				}
			}

			public override void Display(IVwEnv vwenv, int hvo, int frag)
			{
				vwenv.AddUnicodeProp(m_flid, m_ws, this);
			}
		}
		#endregion // View Constructors

		#region RootSite implementation
		class StringSliceView : RootSiteControl
		{
			CmObject m_obj;
			int m_hvoObj;
			int m_flid;
			int m_ws = -1; // -1 signifies not a multilingual property
			IVwViewConstructor m_vc = null;
			
			public StringSliceView(int hvo, int flid, int ws)
			{
				m_hvoObj = hvo;
				m_flid = flid;
				m_ws = ws;
			}

			protected override void OnLostFocus(EventArgs e)
			{
				// This may be called in the process of deleting the object after the object
				// has been partially cleared out and thus would certainly fail the constraint
				// check, then try to instantiate an error annotation which wouldn't have an
				// owner, causing bad things to happen.
				if (m_obj != null && m_obj.IsValidObject())
				{
					ConstraintFailure failure;
					m_obj.CheckConstraints(out failure);
				}
				base.OnLostFocus(e);
			}

// JohnT: This does no good at all; it never gets called. And you can't override a
// static method. So why do they talk about some subclasses having a different one?
//			/// <summary>
//			/// Causes StringSliceViews to be editable by default.
//			/// </summary>
//			public static new Color DefaultBackColor 
//			{
//				get
//				{
//					return System.Drawing.SystemColors.Window;
//				}
//			}

			public override void MakeRoot()
			{
				base.MakeRoot();

				if (m_fdoCache == null || DesignMode)
					return;

				// A crude way of making sure the property we want is loaded into the cache.
				m_obj = FDO.CmObject.CreateFromDBObject(m_fdoCache, m_hvoObj);
				
				int type;
				m_fdoCache.MetaDataCacheAccessor.GetFieldType((uint) m_flid, out type);
				if (type == (int)FwCellar.CellarModuleDefns.kcptUnicode
						|| type == (int)FwCellar.CellarModuleDefns.kcptBigUnicode)
					m_vc = new UnicodeStringSliceVc(m_flid, m_ws, m_fdoCache);
				else
					m_vc = new StringSliceVc(m_flid, m_ws);

				// Review JohnT: why doesn't the base class do this??
				m_rootb = (IVwRootBox)new FwViews.VwRootBoxClass();
				m_rootb.SetSite(this);

				// And maybe this too, at least by default?
				m_rootb.set_DataAccess(m_fdoCache.MainCacheAccessor);

				// arg3 is a meaningless initial fragment, since this VC only displays one thing.
				// arg4 could be used to supply a stylesheet.
				m_rootb.SetRootObject(m_hvoObj, m_vc, 1, m_styleSheet);
			}
		}

		#endregion // RootSite implementation
	}
}
