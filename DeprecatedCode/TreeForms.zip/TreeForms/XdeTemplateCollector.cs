// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: XdeTemplateCollector.cs
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Xml; 
using System.Diagnostics;
using System.IO;
using Microsoft.Win32;
using System.Collections.Specialized;

using SIL.FieldWorks.Common.Utils;
using SIL.Utils;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Loads XDE templates from the proper places in the distfiles directory.
	/// </summary>
	public class XdeTemplateCollector
	{
		/// <summary>
		/// This does not represent any physical file on the desk,
		/// it is an in memory only document.
		/// </summary>
		protected XmlDocument m_xdeDoc;
		/// <summary>
		/// Collection of template paths.
		/// </summary>
		protected StringCollection m_templatePaths;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="XdeTemplateCollector"/> class.
		/// </summary>
		/// <param name="customTemplatePath">A path to custom XDE files,
		/// or null, if defaults are fine.</param>
		/// -----------------------------------------------------------------------------------
		public XdeTemplateCollector(string customTemplatePath)
		{
			m_templatePaths = new StringCollection();
			m_templatePaths.Add(DirectoryFinder.GetFWInstallSubDirectory(@"Xde"));
			if (customTemplatePath != null)
				m_templatePaths.Add(DirectoryFinder.GetFWInstallSubDirectory(customTemplatePath));
			LoadXdeTemplates();
		}

		/// <summary>
		/// Get the templates.
		/// </summary>
		public XmlNode Templates
		{
			get
			{
				Debug.Assert(m_xdeDoc != null);
				return m_xdeDoc["xde"];
			}
		}

		/// <summary>
		/// Load the templates again. Useful when you are working on template writing,
		/// and don't want to have to restart the application to test something you have done.
		/// </summary>
		public void Reload()
		{
			LoadXdeTemplates();
		}

		/// <summary>
		/// Get all of the templates in the given file.
		/// </summary>
		/// <param name="xdeFilePath">Path to one XDE template file.</param>
		/// <returns>A list of elements which should be template elements.</returns>
		protected XmlNodeList LoadOneXdeTemplateFile(string xdeFilePath)
		{
			XmlDocument xdoc = new XmlDocument();
			try
			{
				xdoc.Load(xdeFilePath);
			}
			catch(Exception error)
			{
				string x = string.Format("There was an error while reading in the XML file: {0}.", xdeFilePath);
				throw new ApplicationException(x, error);

			}
			return xdoc.SelectNodes("/xde/*");
		}
	
		/// <summary>
		/// Collect all of the templates up from an array of files.
		/// </summary>
		/// <param name="filePaths">Array of pathnames to individual XDE template files.</param>
		protected void AddXdeTemplatesFromFiles(string[] filePaths)
		{
			Debug.Assert(filePaths != null);
			Debug.Assert(m_xdeDoc != null);
			XmlNode root = m_xdeDoc["xde"];

			foreach(string path in filePaths)
			{
				foreach(XmlNode srcTemplate in LoadOneXdeTemplateFile(path))
				{
					if (srcTemplate.Name == "template")
					{
						XmlNode newTemplate = m_xdeDoc.ImportNode(srcTemplate, true);
						string mode = XmlUtils.GetOptionalAttributeValue(newTemplate, "mode");
						string modeXPath = " and ";
						if (mode == null || mode.Length == 0)
							modeXPath += "not(@mode)";
						else
							modeXPath += "@mode='" + mode + "'";
						string xpath = "template["
							+ "@class='" + newTemplate.Attributes["class"].InnerText + "'"
							+ modeXPath
							+ "]";
						XmlNode extantTemplate = root.SelectSingleNode(xpath);
						if (extantTemplate == null)
							root.AppendChild(newTemplate);
						else
							root.ReplaceChild(newTemplate, extantTemplate);
					}
				}
			}
		}

		/// <summary>
		/// Collect all of the templates from wherever they come from.
		/// </summary>
		/// <returns>
		/// An XmlNode (an element) with name "xde",
		/// which contains templates as its children
		/// </returns>
		protected void LoadXdeTemplates()
		{
			// If this is called more than once,
			// it will throw away the old xmlDocument here.
			m_xdeDoc = new XmlDocument();
			m_xdeDoc.AppendChild(m_xdeDoc.CreateElement("xde"));
			foreach(string templatePath in m_templatePaths)
			{
				//jdh added dec 2003
				string p = DirectoryFinder.GetFWInstallSubDirectory(templatePath);
				
				if (Directory.Exists(p))
					AddXdeTemplatesFromFiles(Directory.GetFiles(p, "*Xde.xml"));
			}
		}
	}
}
