using System;
using System.Windows.Forms;
using System.Drawing;
using System.Xml;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using System.IO;

using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.Utils;
using SIL.Utils;
using XCore;
using SIL.FieldWorks.FdoUi;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// A Slice is essentially one row of a tree this. It is not itself a control.
	/// It contains both a SliceTreeNode on the left of the splitter line, and a 
	/// (optional) subclass of control on the right.
	/// </summary>
	/// <remarks>obsolete?:{This is a very preliminary version of Slice. Eventually, these items will
	/// know about drawing labels, measuring height, dealing with drag operations
	/// within the tree for this item, knowing whether the item can be expanded,
	/// and optionally drawing the part of the tree that is opposite the item, and
	/// many other things.}
	/// 
	/// obsolete?:{Currently a Slice must contain a this. Review JohnT: should we make this
	/// optional, as in AppCore? There may be some cases where it would be a significant
	/// saving of memory.}
	///</remarks>
	public class Slice : IxCoreColleague
	{
		#region Data members

		//subscribe to this event if you want to provide a Context menu for this slice
		public event  TreeNodeEventHandler ShowContextMenu;

		// These two variables allow us to save the parameters passed in IxCoreColleage.Init
		// so we can pass them on when our control is set.
		XCore.Mediator m_mediator;
		System.Xml.XmlNode m_configurationParameters;

		//test
		//		protected MenuController m_menuController= null;
		protected ImageCollection m_smallImages= null;
		//end test

		//force subclasses to use the Control property
		private System.Windows.Forms.Control m_control;

		protected DataTree m_containingDataTree;
		protected int m_indent = 0;
		protected DataTree.TreeItemState m_expansion = DataTree.TreeItemState.ktisFixed; // Default is not expandable.
		protected string m_strLabel;
		protected bool m_isHighlighted = false;
		protected Font m_fontLabel = new Font("Arial", 10);
		protected XmlNode m_configurationNode; // If this slice was generated from an XmlNode, store it here.
		protected Point m_location;
		protected CmObject m_obj; // The object that will be the context if our children are expanded, or for figuring
		// what things can be inserted here.
		protected SliceTreeNode m_treeNode; // the node that draws our label and stuff around it.
		protected object[] m_key; // Key indicates path of nodes and objects used to construct this.
		protected FdoCache m_cache;
		protected SIL.Utils.StringTable m_stringTable;

		#endregion Data members

		#region Properties

		public object[] Key
		{
			get
			{
				return m_key;
			}
			set
			{
				m_key = value;
			}
		}
		public virtual XCore.Mediator Mediator
		{
			get
			{
				return m_mediator;
			}
			set
			{
				m_mediator = value;
				SIL.FieldWorks.Common.RootSites.SimpleRootSite rs = 
					this.Control as SIL.FieldWorks.Common.RootSites.SimpleRootSite;
				if (rs != null)
				{
					rs.Init(this.Mediator, m_configurationNode); // Init it as xCoreColleague.
				}
				else if (this.Control != null && this.Control.Controls != null)
				{
					// If not a SimpleRootSite, maybe it owns one. Init that as xCoreColleague.
					for (int i = 0; i < this.Control.Controls.Count; ++i)
					{
						rs = this.Control.Controls[i] as 
							SIL.FieldWorks.Common.RootSites.SimpleRootSite;
						if (rs != null)
							rs.Init(this.Mediator, m_configurationNode);
					}
				}
			}
		}
		public DataTree Container
		{
			get
			{
				return m_containingDataTree;
			}
		}

		public DataTreeDiagram Diagram
		{
			get
			{
				return m_containingDataTree.Diagram;
			}
		}

		public SliceTreeNode TreeNode
		{
			get
			{
				return m_treeNode;
			}
		}

		public FDO.FdoCache Cache
		{
			get { return m_cache; }
			set
			{
				m_cache = value;
			}
		}

		public FDO.CmObject Object
		{
			get
			{
				return m_obj;
			}
			set
			{
				m_obj = value;
			}
		}

		/// <summary>
		/// the XmlNode that was used to construct this slice
		/// </summary>
		public XmlNode ConfigurationNode
		{
			get
			{
				return m_configurationNode;
			}
			set
			{
				m_configurationNode = value;
			}
		}

		// Review JohnT: or just make it public? Or make more delegation methods?
		virtual public System.Windows.Forms.Control Control
		{
			get { return m_control; }
			set 
			{ 
				m_control = value;
				if (m_control != null)
				{
					// mediator was set first; pass it to colleague.
					if (m_mediator != null && m_control is IxCoreColleague)
						(m_control as IxCoreColleague).Init(m_mediator, m_configurationParameters);
				}
				if (this.Label != null && this.Label.Length > 0)
					m_control.AccessibilityObject.Name = this.Label;
			}
		}

		/// <summary>
		/// this tells whether the slice should be treated as a handle on the owned atomic object which it
		/// refers to, for the purposes of deletion, copy, etc. For example, the Pronunciation field of
		/// LexVariant owns a LexPronunciation, so the Pronunciation field should have this attribute set.
		/// </summary>
		/// <example>MoEndocentricCompound has a "linker" slice which actually just wraps the attributes of a
		/// MoForm that is owned in the linker attribute. so when the user opens the context menu on this slice
		/// he really wants to be operating on the linker, not be owning MoEndocentricCompound.
		/// Another example. LexVariant owns an atomic LexPronunciation in a Pronunciation field. If we set
		/// wrapsAtomic for the Pronunciation field, then this returns true, allowing an Insert Pronunciation
		/// menu to activate.</example>
		public bool WrapsAtomic
		{
			get
			{
				return XmlUtils.GetOptionalBooleanAttributeValue(m_configurationNode,"wrapsAtomic",false);
			}
		}	

		/// <summary>
		/// is this node representing a property which is an (ordered) sequence?
		/// </summary>
		public bool IsSequenceNode
		{
			get
			{
				XmlNode node=ConfigurationNode.SelectSingleNode("seq");
				if(node== null)
					return false;

				string field = XmlUtils.GetOptionalAttributeValue(node, "attr");
				if (field == null || field.Length== 0)
					return false;

				Debug.Assert(m_obj!= null, "JH Made a false assumption!");
				uint flid = GetFlid(field);
				Debug.Assert(flid != 0); // current field should have ID!
				//at this point we are not even thinking about showing reference sequences in the DataTree
				//so I have not dealt with that
				return (GetFieldType(flid) == (int)FDO.FieldType.kcptOwningSequence);
			}
		}

		/// <summary>
		/// is this node representing a property which is an (unordered) collection?
		/// </summary>
		public bool IsCollectionNode
		{
			get
			{
				return ConfigurationNode.SelectSingleNode("seq")!= null && !IsSequenceNode;
			}
		}
		
		/// <summary>
		/// whether the label should be highlighted or not
		/// </summary>
		public bool Highlighted
		{
			set 
			{
				bool current = m_isHighlighted;
				m_isHighlighted = value;
				if(current != m_isHighlighted)
					TreeNode.Refresh();
			}
		}

		public ImageCollection SmallImages
		{
			get
			{
				return null; //no tree icons
				//return m_smallImages;
			}
			set
			{
				m_smallImages = value;
			}
		}

		/// <summary>
		/// a look up table for getting the correct version of strings that the user will see.
		/// </summary>
		public StringTable StringTbl
		{
			get
			{
				return m_stringTable;
			}
			set
			{
				m_stringTable = value;
			}
		}

		#endregion Properties

		#region Construction and initialization

		public Slice()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public Slice(System.Windows.Forms.Control ctrlT)
		{
			Control = ctrlT;
			if (this.Label != null && this.Label.Length > 0)
				m_control.AccessibilityObject.Name = this.Label;
		}

		/// <summary>
		/// This method should be called once the various properties of the slice have been set,
		/// particularly the Cache, Object, Key, and Spec. The slice may create its Control in
		/// this method, so don't assume it exists before this is called. It should be called
		/// before installing the slice.
		/// </summary>
		public virtual void FinishInit()
		{
			// The default does nothing.
		}

		#endregion Construction and initialization

		#region Miscellaneous UI methods

		public virtual void RegisterWithContextHelper ()
		{
			if (this.Control != null)//grouping nodes do not have a control
			{
				string caption = XmlUtils.GetOptionalAttributeValue(ConfigurationNode, "label", "");
				//It's OK to send null as an id
				m_mediator.SendMessage("RegisterHelpTargetWithId", new object[]{this.Control, caption, HelpId});
			}
		}


		protected virtual string HelpId
		{
			get
			{
				string id=XmlUtils.GetAttributeValue(ConfigurationNode ,"id");

				//if the idea has not been added, try using the "attr" attribute as the key
				if (null==id)
					id=XmlUtils.GetAttributeValue(ConfigurationNode,"attr");
		
				return id;
			}
		}

		/// <summary>
		/// This is passed the color that the XDE specified, if any, otherwise null.
		/// The default is to use the normal window color for editable text.
		/// Subclasses which know they should have a different default should
		/// override this method, but normally should use the specified color if not
		/// null.
		/// </summary>
		/// <param name="clr"></param>
		public virtual void OverrideBackColor(String backColorName)
		{
			if (this.Control == null)
				return;
			if (backColorName != null)
			{
				if(backColorName == "Control")
					this.Control.BackColor = Color.FromKnownColor(KnownColor.ControlLight);
				else
					this.Control.BackColor = Color.FromName(backColorName);
			}
			else
				this.Control.BackColor = System.Drawing.SystemColors.Window;
		}

		/// <summary>
		/// Set the width of the item, perform any internal layout inside the item, and return its height
		/// (as in the Height property).
		/// Side effect: set height and width of SliceTreeNode.
		/// Overrides must call base method or AdjustTreeNodeSize (after adjusting this.Height).
		/// </summary>
		public virtual int SetWidthAndGetHeight(int dxpWidth)
		{
			if (this.Control != null)
				this.Control.Width = dxpWidth;
			AdjustTreeNodeSize();
			if (this.Control != null && this.Label != null && this.Label.Length > 0)
				m_control.AccessibilityObject.Name = this.Label;
			return Height;
		}

		#endregion Miscellaneous UI methods
		
		#region events, clicking, etc.


		public void OnTreeNodeClick(object sender, EventArgs args)
		{
			TakeFocus();
		}

		/// <summary>
		/// </summary>
		/// <returns>true if it took the focus.</returns>
		public void TakeFocus()
		{
			TakeFocus(true);
		}

		/// <summary>
		/// The slice should become the focus slice (and return true).
		/// If the fOkToFocusTreeNode argument is true, this should happen iff it has a control which
		/// is appropriate to focus.
		/// </summary>
		/// <param name="fOkToFocusTreeNode"></param>
		/// <returns></returns>
		public bool TakeFocus(bool fOkToFocusTreeNode)
		{
			if (this.Control != null && this.Control.CanFocus && Control.TabStop)
				this.Control.Focus();
			else if (fOkToFocusTreeNode)
			{
				this.TreeNode.Focus();
			}
			else
				return false;

			//this is a bit of a hack, because focus and OnEnter our related but not equivalent...
			//some slices  never get an on enter, but  claim to be focus-able.
			if(this.Container.CurrentSlice != this)
				m_containingDataTree.CurrentSlice = this;
			return true;
		}

		#endregion events, clicking, etc.

		#region Tree management

		/// <summary>
		/// In some contexts we insert into the slice array a 'dummy' slice
		/// which can handle some queries directly (e.g., it may know
		/// its indentation level) but needs to 'BecomeReal' if it becomes
		/// fully visible. The purpose is laziness...often we insert the
		/// same dummy slice into many locations, and they are progressively
		/// replaced with real ones.
		/// </summary>
		/// <returns></returns>
		public virtual bool IsRealSlice
		{
			get {return true;}
		}

	
		/// <summary>
		/// In some contexts we insert into the slice array
		/// </summary>
		/// <returns></returns>
		public virtual Slice BecomeReal(int index)
		{
			return this;
		}

		public virtual void Install(DataTree tc)
		{
			m_containingDataTree = tc;
			if (Control != null)
			{
				tc.SliceControlContainer.Controls.Add(Control);
				/*
				if (Control.Parent != null)
					Debug.WriteLine("Slice Control's Parent: " + Control.Parent.Name);
				if (Control.FindForm() != null)
					Debug.WriteLine("Slice Control's Form: " + Control.FindForm().ToString());
				*/
				if (this.Label != null && this.Label.Length > 0)
					m_control.AccessibilityObject.Name = this.Label;
			}
			// If client has not already made us an stn, make a standard one now.
			if (m_treeNode == null)
			{
				m_treeNode = new SliceTreeNode(this);
			}
				/*
			else
			{
				// When does this happen? (JH asks)
				// We'll find out now with this assert! (says Randy)
				//Debug.Assert(false, "Setting tc to tc in Slice Install method.");
				// ANSWER (says Randy): When you open the paragraph contents in a text using the ZPI data set.
				// It seems as though the dummy slices that are used to provide laziness for long sequences
				// use the same exact slice, so m_treeNode has already been set.
				tc = tc;
			}
			*/

			m_treeNode.Width = Diagram.Width;
			tc.Diagram.Controls.Add(m_treeNode);

		}

		/// <summary>
		/// Uninstall this control. Validation should already have been performed, if it is the active one.
		/// Default just removes from container.
		/// NOT responsible to remove from slices array of DataTree. Caller should do this.
		/// </summary>
		public virtual void Uninstall()
		{
			// In some unknown contexts, the control may have already been removed,
			// so trying to remove it again will cause a crash.
			if (Control != null && m_containingDataTree.SliceControlContainer.Contains(Control))
				m_containingDataTree.SliceControlContainer.Controls.Remove(Control);
			if (m_treeNode != null && m_containingDataTree.Diagram.Controls.Contains(m_treeNode))
				m_containingDataTree.Diagram.Controls.Remove(m_treeNode);
		}

		#endregion Tree management

		#region Tree Display

		// Delegation methods (mainly or entirely duplicate similar methods on embedded control).
		public virtual Point Location
		{
			get
			{
				return m_location;
			}
			set
			{
				if (m_location == value)
					return;
				m_location = value;
				if (this.Control != null)
					this.Control.Location = value;
				if (m_treeNode != null)
					m_treeNode.Location = new Point(0, value.Y);
			}
		}
		public virtual int LabelHeight
		{
			get
			{
				return Convert.ToInt32(m_fontLabel.GetHeight());
			}
		}
		/// <summary>
		/// Return the overall height of the item, including any required padding and the line at the bottom.
		/// </summary>
		public virtual int Height
		{
			get
			{
				// The 1 is added to allow a little padding and space for the line drawn between slices.
				if (this.Control != null)
					return Math.Max(LabelHeight, this.Control.Height) + 1;
				else
					return LabelHeight + 1;
			}
		}

		protected virtual void AdjustTreeNodeSize()
		{
			m_treeNode.Width = Diagram.Width;
			m_treeNode.Height = Height;
		}
		/// <summary>
		/// Determines how deeply indented this item is in the tree diagram. 0 means no indent.
		/// </summary>
		public int Indent
		{
			get
			{	return m_indent;}
			set
			{	m_indent = value;}
		}
		// Return the expansion state of tree nodes.
		// This must be overwritten for editors that can expand.
		// @return A tree state enum.
		public DataTree.TreeItemState Expansion
		{
			get
			{return m_expansion;}
			set
			{m_expansion = value;} // Todo JohnT: real version may not have setter.
		}

		/// <summary>
		/// Gets and sets the label used to identify the item in the tree diagram.
		/// May need to override if not using the standard variable to draw a simple label
		/// </summary>
		public virtual string Label
		{
			get
			{
				return m_strLabel;
			}
			set
			{
				m_strLabel = value;
//				this.Control.AccessibleName = m_strLabel;
//				this.Control.AccessibilityObject.Value = m_strLabel;
			}
		}

		public virtual void DrawLabel(int x, int y, Graphics gr, int clipWidth)
		{
			if(SmallImages!= null) 
			{
				Image image =null;
				if(IsSequenceNode)
				{
					image = SmallImages.GetImage("sequence");
				}
				else if (IsCollectionNode)
				{
					image = SmallImages.GetImage("collection");
				}
				else if (IsObjectNode || WrapsAtomic)
				{
					image = SmallImages.GetImage("atomic");
				}
				if (image != null)
				{
					((Bitmap)image).MakeTransparent(System.Drawing.Color.Fuchsia);
					gr.DrawImage(image,x,y);
					x+=image.Width;
				}
			}
			PointF p = new PointF(x , y);
			Brush brush = new SolidBrush(Color.Black);
			if (Container.CurrentSlice == this)
				brush = new SolidBrush(Color.Blue);
			gr.DrawString(m_strLabel, m_fontLabel, brush, p);
			//			if(m_menuController != null)
			//				m_menuController.DrawAffordance(m_isHighlighted, x,y,gr,clipWidth);

		}
		/// <summary>
		/// Returns the height, from the top of the item, at which to draw the line across towards it.
		/// Typically this is the center of where DrawLabel will draw the label, but it might not be (e.g.,
		/// if DrawLabel actually draws two labels and a bit of tree diagram).
		/// </summary>
		public virtual int GetBranchHeight()
		{
			return Convert.ToInt32((m_fontLabel.GetHeight() + 1.0)/ 2.0);
		}

		public void Expand()
		{
			Expand(this.IndexInContainer);
		}

		public int IndexInContainer
		{
			get
			{
				return this.Container.Slices.IndexOf(this);
			}
		}

		/// <summary>
		/// Expand this node, which is at position iSlice in its parent.
		/// </summary>
		/// <remarks> I (JH) don't know why this was written to take the index of the slice.  
		/// It's just as easy for this class to find its own index.</remarks>
		/// <param name="iSlice"></param>
		public virtual void Expand(int iSlice)
		{
			try
			{
				Debug.Assert(Expansion != DataTree.TreeItemState.ktisFixed);
				m_containingDataTree.DeepSuspendLayout();
				m_containingDataTree.ApplyTemplate(m_obj, m_configurationNode, Indent + 1, iSlice + 1, new ArrayList(Key), new ObjSeqHashMap());
				Expansion = DataTree.TreeItemState.ktisExpanded;
				// A crude way to force the +/- icon to be redrawn.
				// If this gets flashy, we could figure a smaller region to invalidate.
				m_containingDataTree.Invalidate(true);  // Invalidates both children.
			}
			finally
			{
				m_containingDataTree.DeepResumeLayout();
			}
		}

		/// <summary>
		/// Collapse this node, which is at position iSlice in its parent.
		/// </summary>
		/// <param name="iSlice"></param>
		public virtual void Collapse(int iSlice)
		{
			int iNextSliceNotChild = iSlice + 1;
			while (iNextSliceNotChild < m_containingDataTree.Slices.Count && m_containingDataTree.FieldOrDummyAt(iNextSliceNotChild).Indent > this.Indent)
				iNextSliceNotChild++;
			int count = iNextSliceNotChild - iSlice - 1;
			if (count > 0)
				m_containingDataTree.Slices.RemoveRange(iSlice + 1, count);
			Expansion = DataTree.TreeItemState.ktisCollapsed;
			m_containingDataTree.Diagram.PerformLayout();
			m_containingDataTree.Diagram.Invalidate(true);
			m_containingDataTree.Invalidate(true);  // Invalidates all children.
		}

		
		public bool HandleMouseDown(Point p)
		{
			if (ShowContextMenu!= null)// m_btnRectangle.Contains(p))
			{
				ShowContextMenu(this, new TreeNodeEventArgs(TreeNode, this, p));
				return true;
			}
			else
				return false;
		}

		public int LabelIndent()
		{
			return SliceTreeNode.kdxpLeftMargin +
				(Indent + 1) * SliceTreeNode.kdxpIndDist;
		}



		/// <summary>
		/// Draws the label in the containing SilTreeControl's Graphics object at the specified position.
		/// Override if you have a more complex type of label, e.g., if the field contains interlinear
		/// data and you want to label each line.
		/// </summary>
		public virtual void DrawLabel(int y, Graphics gr, int clipWidth)
		{
			DrawLabel(LabelIndent(), y, gr, clipWidth);
		}

		public bool IsObjectNode
		{
			get
			{
				string sClassName = Cache.GetClassName((uint)Object.ClassID);
				return 
					( ConfigurationNode.SelectSingleNode("node")!= null  ||
					("PhCode" == sClassName) || // This is a hack to get one case to work that should be handled by the todo in the next comment (hab 2004.01.16 )
					false)	// todo: this should tell if the attr (not the nested one) is to a basic type or a cmobject
					&&
					ConfigurationNode.SelectSingleNode("seq")== null &&
					//MoAllomorphAdhocCoProhibition.adjacency is the top-level node, but it's not really an object that you should be able to delete
					this.Object.Hvo != this.Container.RootObjectHvo;
			}
		}

		#endregion Tree Display

		#region Miscellaneous data methods

		/// <summary>
		/// Get the context for this slice considered as a member of a sequence.
		/// That is, if the current node is, at some level, a member of an owning sequence,
		/// find the most local such sequence, and return information indicating the position
		/// of the object this slice is part of, as well as the object and property that owns
		/// it.
		/// </summary>
		/// <param name="hvoOwner">Owner of the object this slice is part of.</param>
		/// <param name="flid">Owning sequence property this is part of.</param>
		/// <param name="ihvoPosition">Position of this object in owning sequence;
		/// or current position in cache, if a collection.</param>
		/// <returns>true if this slice is part of an owning sequence property.</returns>
		public bool GetSeqContext(out int hvoOwner, out int flid, out int ihvoPosition)
		{
			hvoOwner = 0; // compiler insists it be assigned.
			flid = 0;
			ihvoPosition = 0;

			if (m_key == null)
				return false;

			for (int inode = m_key.Length; --inode >= 0; )
			{
				object objNode = m_key[inode];
				if (objNode is XmlNode)
				{
					XmlNode node = (XmlNode) objNode;
					if (node.Name == "seq")
					{
						// got it!
						// The next thing we push into key right after the "seq" node is always the
						// HVO of the particular item we're editing.
						int hvoItem = (int) (m_key[inode + 1]);
						string attrName = node.Attributes["attr"].Value;
						FDO.FdoCache cache = Container.Cache;
						IFwMetaDataCache mdc = cache.MetaDataCacheAccessor;
						FDO.CmObject obj = FDO.CmObject.CreateFromDBObject(cache, hvoItem);
						hvoOwner = obj.OwnerHVO;
						int clsid = cache.GetClassOfObject(hvoOwner);
						flid = (int)mdc.GetFieldId2((uint) clsid, attrName, true);
						if (flid == 0)
							return false;
						ihvoPosition = cache.GetObjIndex(hvoOwner, flid, hvoItem);
						return true;
					}
				}
			}
			return false;
		}


		/// <summary>
		/// Get the context for this slice considered as part of an owning atomic attr.
		/// That is, if the current node is, at some level, a member of an owning atomic attr,
		/// find the most local such attr, and return information indicating the object
		/// and property that owns it.
		/// </summary>
		/// <param name="hvoOwner">Owner of the object this slice is part of.</param>
		/// <param name="flid">Owning atomic property this is part of.</param>
		/// <returns>true if this slice is part of an owning atomic property.</returns>
		public bool GetAtomicContext(out int hvoOwner, out int flid)
		{
			// Compiler requires values to be set, but these are meaningless.
			hvoOwner = 0;
			flid = 0;
			if (m_key == null)
				return false;

			for (int inode = m_key.Length; --inode >= 0; )
			{
				object objNode = m_key[inode];
				if (objNode is XmlNode)
				{
					XmlNode node = (XmlNode) objNode;
					if (node.Name == "atomic")
					{
						// got it!
						// The next thing we push into key right after the "atomic" node is always the
						// HVO of the particular item we're editing.
						int hvoItem = (int) (m_key[inode + 1]);
						string attrName = node.Attributes["attr"].Value;
						FDO.FdoCache cache = Container.Cache;
						IFwMetaDataCache mdc = cache.MetaDataCacheAccessor;
						FDO.CmObject objOwner = FDO.CmObject.CreateFromDBObject(cache, hvoItem);
						hvoOwner = objOwner.OwnerHVO;
						int clsid = cache.GetClassOfObject(hvoOwner);
						flid = (int)mdc.GetFieldId2((uint) clsid, attrName, true);
						return true;
					}
				}
			}
			return false;
		}



		/// <summary>
		/// Get the flid for the specified field name of this slice's object. May return zero if
		/// the object does not have that field.
		/// </summary>
		/// <param name="fieldName"></param>
		/// <returns></returns>
		protected uint GetFlid(string fieldName)
		{
			uint flid= m_cache.MetaDataCacheAccessor.GetFieldId2((uint)this.m_obj.ClassID, fieldName,true);
			//Debug.Assert( flid !=0);
			return flid;
		}

		protected int GetFieldType(uint flid)
		{
			int type;
			m_cache.MetaDataCacheAccessor.GetFieldType(flid, out type);
			return type;
		}

		#endregion Miscellaneous data methods

		#region Menu Command Handlers

		/// <summary>
		/// do an insertion
		/// </summary>
		/// <remarks> called by the containing environment in response to a user command.</remarks>
		public virtual void HandleInsertCommand(string fieldName, string className)
		{
			HandleInsertCommand(fieldName, className, null);
		}

		/// <summary>
		/// Answer whether clidTest is, or is a subclass of, clidSig.
		/// That is, either clidTest is the same as clidSig, or one of the base classes of clidTest is clidSig.
		/// As a special case, if clidSig is 0, all classes are considered to match
		/// </summary>
		/// <param name="clidTest"></param>
		/// <param name="clidSig"></param>
		/// <returns></returns>
		bool IsOrInheritsFrom(uint clidTest, uint clidSig)
		{
			if (clidSig == 0)
				return true;
			IFwMetaDataCache mdc = Cache.MetaDataCacheAccessor;
			for (uint clidBase = clidTest; clidBase != 0; mdc.GetBaseClsId(clidTest, out clidBase))
			{
				if (clidBase == clidSig)
					return true;
				clidTest = clidBase;
			}
			return false;
		}

		/// <summary>
		/// do an insertion
		/// </summary>
		/// <remarks> called by the containing environment in response to a user command.</remarks>
		/// <param name="fieldName">name of field to create in</param>
		/// <param name="className">class of object to create</param>
		/// <param name="ownerClassName">class of expected owner. If the current slice's object is not
		/// this class (or a subclass), look for a containing object that is.</param>
		public virtual void HandleInsertCommand(string fieldName, string className, string ownerClassName)
		{
			uint newObjectClassId = m_cache.MetaDataCacheAccessor.GetClassId(className);
			if (newObjectClassId== 0)
				throw new ArgumentException("There does not appear to be a database class named '"+className+"'.");

			uint ownerClassId = 0;
			if (ownerClassName != null && ownerClassName != "")
			{
				ownerClassId = Cache.MetaDataCacheAccessor.GetClassId(ownerClassName);
				if (ownerClassId == 0)
					throw new ArgumentException("There does not appear to be a database class named '"+ownerClassName+"'.");
			}
			// Loop through all slices until we find a slice whose object is of the right class
			// and that has the specified field.
			foreach (Slice slice in Container.Slices)
			{
				if ((ownerClassId > 0 && IsOrInheritsFrom((uint)(slice.Object.ClassID), ownerClassId)) // For adding senses using the simple edit mode, no matter where the cursor is.
					|| slice.Object == Object) // Other cases.
				{
					// The slice's object has an acceptable type provided it implements the required field.
					uint flid = slice.GetFlid(fieldName);
					if (flid != 0)
					{
						slice.InsertObject(flid, newObjectClassId);
						break;
					}
				}
			}
		}

		/// <summary>
		/// Insert a new object of the specified class into the specified property of your object.
		/// </summary>
		/// <param name="flid"></param>
		/// <param name="newObjectClassId"></param>
		void InsertObject(uint flid, uint newObjectClassId)
		{
			// OK, we can add to property flid of the object of slice slice.
			int insertionPosition = 0;//leave it at 0 if it does not matter
			int hvoOwner = Object.Hvo;
			int type = GetFieldType(flid);
			if (type == (int)FDO.FieldType.kcptOwningSequence)
			{
				//to do (for sequences): this just always puts the new at the end
				insertionPosition = Cache.GetVectorSize(hvoOwner, (int)flid);
			}
			m_cache.BeginUndoTask("Undo Insert", "Redo Insert");
			int hvoNew = Cache.CreateObject((int)newObjectClassId, hvoOwner, (int)flid, insertionPosition);
			m_cache.EndUndoTask();
			Cache.MainCacheAccessor.PropChanged(null, (int)FwViews.PropChangeType.kpctNotifyAll, hvoOwner, (int)flid, insertionPosition, 1, 0);

			//			if (ihvoPosition == ClassAndPropInfo.kposNotSet && cpi.fieldType == DataTree.kcptOwningSequence)
			//			{
			//				// insert at end of sequence.
			//				ihvoPosition = cache.GetVectorSize(hvoOwner, (int)cpi.flid);
			//			} // otherwise we already worked out the position or it doesn't matter
			//			// Note: ihvoPosition ignored if sequence(?) or atomic.
			//			int hvoNew = cache.CreateObject((int)(cpi.signatureClsid), hvoOwner, (int)(cpi.flid), ihvoPosition);
			//			cache.MainCacheAccessor.PropChanged(null, (int)FwViews.PropChangeType.kpctNotifyAll, hvoOwner, (int)(cpi.flid), ihvoPosition, 1, 0);
			if (hvoOwner == Object.Hvo && Expansion == DataTree.TreeItemState.ktisCollapsed)
			{
				// We added something to the object of the current slice...almost certainly it
				// will be something that will display under this node...if it is still collapsed,
				// expand it to show the thing inserted.
				TreeNode.ToggleExpansion(IndexInContainer);
			}
			Slice child = ExpandSubItem(hvoNew);
			if (child != null)
				child.FocusSliceOrChild();
		}

		/// <summary>
		/// Find a slice nested below this one whose object is hvo and expand it if it is collapsed.
		/// </summary>
		/// <param name="hvo"></param>
		/// <returns>Slice for subitem, or null</returns>
		public Slice ExpandSubItem(int hvo)
		{
			int cslice = Container.Slices.Count;
			for (int islice = IndexInContainer + 1; islice < cslice; ++islice)
			{
				Slice slice = Container.Slices[islice];
				if (slice.Object.Hvo == hvo)
				{
					if (slice.Expansion == DataTree.TreeItemState.ktisCollapsed)
						slice.TreeNode.ToggleExpansion(islice);
					return slice;
				}
				// Stop if we get past the children of the current object.
				if (slice.Indent <= this.Indent)
					break;
			}
			return null;
		}

		/// <summary>
		/// Focus the specified slice (or the first of its children that can accept focus).
		/// </summary>
		/// <param name="islice"></param>
		public Slice FocusSliceOrChild()
		{
			int cslice = Container.Slices.Count;
			for (int islice = IndexInContainer; islice < cslice; ++islice)
			{
				Slice slice = Container.Slices[islice];
				if (slice.TakeFocus(false))
					return slice;
				// Stop if we get past the children of the current object.
				if (slice.Indent >= this.Indent)
					break;
				break;
			}
			return null;
		}

		public virtual void HandleDeleteCommand()
		{
			int hvo = GetObjectHvoForMenusToOperateOn();
			if(hvo<=0)
				throw new ConfigurationException("Slice:GetObjectHvoForMenusToOperateOn is either messed up or should not have been called, because it could not find the object to be deleted.", m_configurationNode);
			else
			{
				CmObjectUi ui = CmObjectUi.MakeUi(m_cache, hvo);
				ui.Mediator = m_mediator;
				ui.DeleteUnderlyingObject();
			}
		}

		/// <summary>
		/// gives the object hvo hat should be the target of Delete, copy, etc. for menus operating on this slice label.
		/// </summary>
		/// <returns>return 0 if this slice is supposed to operate on an atomic field which is currently empty.</returns>
		public int GetObjectHvoForMenusToOperateOn()
		{
			if(WrapsAtomic)
			{
				XmlNodeList nodes=m_configurationNode.SelectNodes("atomic");
				if(nodes.Count  != 1)
					throw new ConfigurationException ("Expected to find a single <atomic> element in here", m_configurationNode);
				string field =XmlUtils.GetManditoryAttributeValue(nodes[0],"attr");
				uint flid = GetFlid(field);
				Debug.Assert(flid != 0);
				return m_cache.GetObjProperty(m_obj.Hvo ,(int)flid);
			}
			else
				return m_obj.Hvo;
		}

		/// <summary>
		/// is it possible to do an insertion menu command on this slice right now?
		/// </summary>
		/// <returns></returns>
		public bool GetCanInsertNow()
		{
			if(WrapsAtomic && GetObjectHvoForMenusToOperateOn() > 0)
				return false;
			else	// don't allow insertion if this field is atomic but not empty
				return (GetObjectHvoForMenusToOperateOn() == 0) || IsCollectionNode || IsSequenceNode;
		}

		/// <summary>
		/// is it possible to do a deletion menu command on this slice right now?
		/// </summary>
		/// <returns></returns>
		public bool GetCanDeleteNow()
		{
			int hvo = GetObjectHvoForMenusToOperateOn();
			if(hvo <= 0)
			{
				return false;
			}
			else
			{
			}

			CmObject owner = CmObject.CreateFromDBObject(Cache, m_cache.GetOwnerOfObject(hvo));
			int flid = m_cache.GetOwningFlidOfObject(hvo);
			if(!owner.IsFieldRequired(flid))
				return true;

			//now, if the field is required, then we do not allow this to be deleted if it is atomic
			//futureTodo: this prevents the user from the deleting something in order to create something 
			//of a different class, or to paste in other object in this field.
			if (!Cache.IsVectorProperty(flid))
				return false;
			else	//still OK to delete so long as it is not the last item.
				return Cache.GetVectorSize(owner.Hvo, flid) > 1;
		}

		/// <summary>
		/// Is it possible to do a merge menu command on this slice right now?
		/// </summary>
		/// <returns></returns>
		public bool GetCanMergeNow()
		{
			int hvo = GetObjectHvoForMenusToOperateOn();
			int clsid = Cache.GetClassOfObject(hvo);
			if(hvo <= 0)
				return false;

			CmObject owner = CmObject.CreateFromDBObject(Cache, m_cache.GetOwnerOfObject(hvo));
			int flid = m_cache.GetOwningFlidOfObject(hvo);
			// No support yet for atomic properties.
			if (!Cache.IsVectorProperty(flid))
				return false;

			int vectorSize = Cache.GetVectorSize(owner.Hvo, flid);
			if(owner.IsFieldRequired(flid)
				&& vectorSize < 2)
				return false;

			// Check now to see if there are any other objects of the same class in the flid,
			// since only objects of the same class can be merged.
			foreach (int hvoInner in Cache.GetVectorProperty(owner.Hvo, flid, true))
			{
				if (hvoInner != hvo
					&& clsid == Cache.GetClassOfObject(hvoInner))
				{
					return true;
				}
			}

			return false;
		}

		public virtual void HandleMergeCommand()
		{
			int hvo = GetObjectHvoForMenusToOperateOn();
			if(hvo <= 0)
				throw new ConfigurationException("Slice:GetObjectHvoForMenusToOperateOn is either messed up or should not have been called, because it could not find the object to be merged.", m_configurationNode);

			CmObjectUi ui = CmObjectUi.MakeUi(m_cache, hvo);
			ui.Mediator = m_mediator;
			ui.MergeUnderlyingObject();
		}

		#endregion Menu Command Handlers

		#region IxCoreColleague implementation

		public virtual void Init(XCore.Mediator mediator, System.Xml.XmlNode configurationParameters)
		{
			m_mediator = mediator;
			m_configurationParameters = configurationParameters;
			if (m_control != null && m_control is IxCoreColleague)
			{
				(m_control as IxCoreColleague).Init(mediator, configurationParameters);
////				m_control.AccessibilityObject.Name = this.Label;
			}
		}

		public virtual XCore.IxCoreColleague[] GetMessageTargets()
		{
			if (m_control is IxCoreColleague)
				return new XCore.IxCoreColleague[] {m_control as IxCoreColleague, this};
			else
				return new XCore.IxCoreColleague[] {this};
		}

		#endregion IxCoreColleague implementation
	}
}
