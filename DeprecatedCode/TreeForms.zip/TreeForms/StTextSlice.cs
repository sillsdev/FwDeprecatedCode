using System;
using SIL.FieldWorks.Common.Framework;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.RootSites;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.Cellar.Generated;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// An StTextSlice implements the sttext editor type for atomic attributes whose value is an StText.
	/// The resulting view allows the editing of the text, including creating and destroying (and splitting
	/// and merging) of the paragraphs using the usual keyboard actions.
	/// </summary>
	public class StTextSlice : ViewSlice
	{
		public StTextSlice(int hvoOwner, int flid, int ws) : base(new StTextView(hvoOwner, flid, ws))
		{
			((StTextView)Control).Slice = this;
		}
	}

	public class StTextView : RootSite
	{
		StVc m_vc;
		int m_hvoStText;
		int m_hvoOwner;
		int m_flid; // of atomic attr that holds StText.
		int m_ws; // default ws for new StTexts, or 0 for default, which is analysis.
		StTextSlice m_slice;
		public StTextView(int hvoOwner, int flid, int ws) : base()
		{
			m_hvoOwner = hvoOwner;
			m_flid = flid;
			m_ws = ws;
		}

		public StTextSlice Slice
		{
			get { return m_slice; }
			set { m_slice = value; }
		}

		public override void MakeRoot()
		{
			if (m_fdoCache == null || DesignMode)
				return;

			m_rootb = (IVwRootBox)new FwViews.VwRootBoxClass();
			m_rootb.SetSite(this);
			if (m_ws == 0)
				m_ws = m_fdoCache.DefaultAnalWs;

			m_hvoStText = m_fdoCache.GetObjProperty(m_hvoOwner, m_flid);
			// If we don't already have an StText in this field, make one now.
			if (m_hvoStText == 0)
			{
				ISilDataAccess sda = m_fdoCache.MainCacheAccessor;
				// Create one and initialize it. Don't use the FdoCache method, because it's important NOT to notify
				// our own data tree of the change...if we do, it could start a new regenerate in the middle of an
				// existing one with bad consequences.
				m_hvoStText = sda.MakeNewObject(StText.kclsidStText, m_hvoOwner, m_flid, -2);
				int hvoStTxtPara = sda.MakeNewObject(StTxtPara.kclsidStTxtPara, m_hvoStText, (int)StText.StTextTags.kflidParagraphs, 0);
				ITsStrFactory tsf = (ITsStrFactory) new FwKernelLib.TsStrFactoryClass();
				sda.SetString(hvoStTxtPara, (int) StTxtPara.StTxtParaTags.kflidContents, tsf.MakeString("", m_ws));
				// Notify change on the main property. The other properties we changed are part of the new object, and nothing
				// can know their previous state and need to see the change.
				sda.PropChanged(m_slice.Container, (int)FwViews.PropChangeType.kpctNotifyAllButMe, m_hvoOwner, m_flid, 0, 1, 0);
			}

			m_vc = new StVc("Normal", m_ws);
			m_vc.Cache = m_fdoCache;
			m_vc.Editable = true;

			m_rootb.set_DataAccess(m_fdoCache.MainCacheAccessor);

			m_rootb.SetRootObject(m_hvoStText, m_vc, (int)StTextFrags.kfrText,
				m_styleSheet);

			m_fRootboxMade = true;
			m_dxdLayoutWidth = -50000; // Don't try to draw until we get OnSize and do layout.

			//TODO: 
			//ptmw->RegisterRootBox(qrootb);
		}
	}
}
