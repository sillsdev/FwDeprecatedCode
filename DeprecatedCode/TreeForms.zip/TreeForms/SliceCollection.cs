using System;
using System.Collections;
using System.Windows.Forms;
using System.Diagnostics;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// A type safe collection for Slice objects.
	/// </summary>
	public class SliceCollection : CollectionBase
	{
		/// <summary>
		/// Main control
		/// </summary>
		private DataTree m_dataTree;
		private DataTreeDiagram m_treeControl;

		public SliceCollection(DataTree datatree, DataTreeDiagram treeControl)
		{
			Debug.Assert(datatree != null);
			Debug.Assert(treeControl != null);
			m_dataTree = datatree;
			m_treeControl = treeControl;
		}

		public void StatusReportAfterShow()
		{
				foreach (Slice slice in List)
				{
					if (slice.IsRealSlice && slice.Control != null)
						StatusReport(slice.Control, "");
				}
		}

		private void StatusReport(Control ctrl, string leadingContent)
		{
			Debug.WriteLine(leadingContent + "Control type name: " + ctrl.GetType().Name);
			Debug.WriteLine(leadingContent + "Control TabStop: " + ctrl.TabStop.ToString());
			Debug.WriteLine(leadingContent + "Control TabIndex : " + ctrl.TabIndex.ToString());
			Debug.WriteLine(leadingContent + "Control CanFocus: " + ctrl.CanFocus.ToString());
			Debug.WriteLine(leadingContent + "Control CanSelect: " + ctrl.CanSelect.ToString());
			Debug.WriteLine(leadingContent + "Control Visible: " + ctrl.Visible.ToString());
			Debug.WriteLine(leadingContent + "Control Enabled: " + ctrl.Enabled.ToString());

			if (ctrl.IsHandleCreated)
				Debug.WriteLine(leadingContent + "Control Handle: " + ctrl.Handle.ToString());
			else
				Debug.WriteLine(leadingContent + "No handle.");

			if (ctrl.FindForm() != null)
				Debug.WriteLine(leadingContent + "Control Form: " + ctrl.FindForm().ToString());
			else
				Debug.WriteLine(leadingContent + "No Form.");

			if (ctrl.Parent != null)
			{
				Debug.WriteLine(leadingContent + "Parent info.");
				StatusReport(ctrl.Parent, leadingContent += "\t");
			}
			else
				Debug.WriteLine(leadingContent + "No Parent.");
		}

		private void SetTabIndex(int index)
		{
			Slice slice = this[index];
#if false
			//if (slice == null)
			//{
			//	Debug.WriteLine("slice: null");
			//}
			//else
			//{
				if (slice.IsRealSlice)
				{
					//Debug.WriteLine("Real slice: " + slice.GetType().Name);
					Control ctrl = slice.Control;
					//if (ctrl == null)
					//	Debug.WriteLine("\tSlice control: null");
					//else
					//{
						//StatusReport(ctrl, "\t");
						ctrl.TabIndex = index;
					//}
				}
				//else
				//	Debug.WriteLine("Not real slice:" + slice.GetType().Name);
			//}
#else
			if (slice != null && slice.IsRealSlice & slice.Control != null)
				slice.Control.TabIndex = index;
#endif
		}

		/// <summary>
		/// Resets the TabIndex for all slices that are located at, or above, the <c>startingIndex</c>.
		/// </summary>
		/// <param name="startingIndex">The index to start renumbering the TabIndex.</param>
		private void ResetTabIndices(int startingIndex)
		{
			for (int i = startingIndex; i < List.Count; ++i)
				SetTabIndex(i);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Slices, dices, and juliennes until it finds a slice for the given hvo
		/// </summary>
		/// <param name="hvo">HVO of the thing</param>
		/// <returns></returns>
		/// ------------------------------------------------------------------------------------
		public Slice GetSliceFromHvo(int hvo)
		{
			foreach (Slice slice in List)
			{
				if (slice.Object.Hvo == hvo)
					return slice;
			}
			return null;
		}

		public ObjSeqHashMap PreviousSlices
		{
			get
			{
				ObjSeqHashMap previousSlices = new ObjSeqHashMap();
				foreach (Slice slice in List)
				{
					if (slice.Key != null) // dummy slices may not have keys and shouldn't be reused.
						previousSlices.Add(slice.Key, slice);
				}
				Clear();
				return previousSlices;
			}
		}

		/// <summary>
		/// Gets or sets the Slice at the specified index.
		/// </summary>
		public Slice this[int index]
		{
			get
			{
				// Review JohnT: Should this invoke the code to create nonexistent items? Probably.
				return (Slice)List[index];
			}
			set
			{
				Slice oldValue = this[index];
				if (oldValue != null)
					oldValue.Uninstall();
				List[index] = value;
				value.Install(m_dataTree);
				SetTabIndex(index);
			}
		}

		/// <summary>
		/// Add a Slice to the collection, and install it.
		/// </summary>
		/// <param name="slice">Slice to add and install.</param>
		/// <returns>Index of where it was added in the collection.</returns>
		public int Add(Slice slice)
		{
			int index = List.Add(slice);
			slice.Install(m_dataTree);
			SetTabIndex(index);
			return index;
		}

		/// <summary>
		/// Add an array of Slice objects, and install them.
		/// </summary>
		/// <param name="slices">Array of Slice objects to add and install.</param>
		public void AddRange(Slice[] slices)
		{
			foreach(Slice slice in slices)
				Add(slice);
		}

		public int IndexOf(Slice slice)
		{
			return List.IndexOf(slice);
		}

		/// <summary>
		/// Insert the given Slice at the specified position, and install it.
		/// </summary>
		/// <param name="index">Zero-based index to insert the given Slice.</param>
		/// <param name="slice">The Slice to insert.</param>
		public void Insert(int index, Slice slice)
		{
			List.Insert(index, slice);
			slice.Install(m_dataTree);
			ResetTabIndices(index);
		}

		/// <summary>
		/// Insert and install an array of Slice objects at the given position.
		/// </summary>
		/// <param name="insertPosition">Zero-based index to insert the Slice objects.</param>
		/// <param name="slices">Array of Slice objects to insert and initialize.</param>
		public void InsertRange(int insertPosition, Slice[] slices)
		{
			for (int i = slices.Length - 1; i >= 0; --i)
			{
				Slice slice = slices[i];
				List.Insert(insertPosition, slice);
				slice.Install(m_dataTree);
			}
			ResetTabIndices(insertPosition);
		}

		/// <summary>
		/// Remove and uninstall a Slice.
		/// </summary>
		/// <param name="slice"></param>
		public void Remove(Slice slice)
		{
			int index = List.IndexOf(slice);
			List.Remove(slice);
			slice.Uninstall();
			ResetTabIndices(index);
		}

		public void RemoveRange(int startIndex, int count)
		{
			if (count == 0)
				return; // They didn't really want to remove any.
			for (int idx = 0; idx < count; ++idx)
			{
				Slice slice = this[startIndex];
				List.Remove(slice);
				slice.Uninstall();
			}
			ResetTabIndices(startIndex);
		}

		new public void Clear()
		{
			foreach (Slice slice in List)
				slice.Uninstall();
			base.Clear();
		}

		public bool Contains(Slice slice)
		{
			return List.Contains(slice);
		}

	}
}
