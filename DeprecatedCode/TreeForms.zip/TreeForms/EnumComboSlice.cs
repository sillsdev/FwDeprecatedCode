// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: EnumComboSlice.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// Implements the an XDE editor which displays a combobox of labels, but underlyingly based on integers.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.  Xml;
using SIL.FieldWorks.FDO;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Displays a combobox of labels, but underlyingly based on integers.
	/// </summary>
	public class EnumComboSlice : FieldSlice
	{
		protected ComboBox m_combo;
		protected Hashtable m_labels;

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="obj">CmObject that is being displayed.</param>
		/// <param name="flid">The field identifier for the attribute we are displaying.</param>
		public EnumComboSlice(FdoCache cache, CmObject obj, int flid, SIL.Utils.StringTable stringTable, XmlNode parameters) 
			: base(new ComboBox(), cache, obj, flid)
		{
			m_combo = (ComboBox)this.Control;
			m_combo.DropDownStyle = ComboBoxStyle.DropDownList;
			//note: no exception is thrown if it can't find it.
			m_combo.Font = new System.Drawing.Font("Arial Unicode MS", 10); 
			m_combo.SelectedValueChanged += new EventHandler(this.SelectionChanged);
			m_combo.GotFocus +=new EventHandler(GotFocus);
			StringTbl = stringTable;
			PopulateCombo(parameters);
		}

		protected void PopulateCombo(XmlNode parameters)
		{
			Debug.Assert(StringTbl != null, "A StrigTable must be provided for the enum combo slice.");
			m_combo.Items.Clear();
			XmlNode node =  parameters.SelectSingleNode("stringList");
			if (node== null)
				throw new ApplicationException ("The Enum editor requires a <stringList> element in the <deParams>");

			string[] labels = StringTbl.GetStringsFromStringListNode(node);
			foreach(string label in labels)
			{
				m_combo.Items.Add(label);
			}
		}

		protected override void UpdateDisplayFromDatabase()
		{
			int currentValue = m_cache.GetIntProperty(Object.Hvo, m_flid);
			
			//nb: we are assuming that a enumerations start with 0
			m_combo.SelectedIndex=currentValue;
		}

		/// <summary>
		/// Event handler for selection changed in combo box.
		/// </summary>
		/// <param name="sender">Source control</param>
		/// <param name="e"></param>
		protected void SelectionChanged(object sender, EventArgs e)
		{
			Debug.Assert(m_combo != null);
			m_cache.BeginUndoTask("Undo edit " + m_fieldName, "Redo set " +  m_fieldName);
			m_cache.SetIntProperty(Object.Hvo, m_flid, m_combo.SelectedIndex);
			m_cache.EndUndoTask();
		}

		private void GotFocus(object sender, EventArgs e)
		{
			Container.CurrentSlice = this;
		}
	}
}
