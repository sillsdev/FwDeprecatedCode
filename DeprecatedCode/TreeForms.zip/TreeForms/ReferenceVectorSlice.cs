// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ReferenceCollectionSlice.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
//	These slices are useful for collections andsequences.  No re-ordering is not supported
//	for sequences. Also, adding the same element multiple times is not allowed for collections,
//	but it is for sequences.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Xml;

using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Controls;
using SIL.Utils;
using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for ReferenceVectorSlice.
	/// </summary>
	public class ReferenceVectorSlice : ReferenceSlice
	{
		/// <summary>
		/// Default Constructor.
		/// </summary>
		public ReferenceVectorSlice() : base()
		{
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ReferenceCollectionSlice"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public ReferenceVectorSlice(FdoCache cache, CmObject obj, int flid,
			XmlNode configurationNode, SIL.Utils.IPersistenceProvider persistenceProvider,
			StringTable stringTbl) 
		: base(cache, obj, flid, configurationNode, persistenceProvider, stringTbl)
		{
		}

		protected override void SetupControls(IPersistenceProvider persistenceProvider,
			StringTable stringTbl)
		{
			VectorReferenceLauncher vrl = new VectorReferenceLauncher();
			vrl.Initialize(m_cache, m_obj, m_flid, m_fieldName, persistenceProvider,
				DisplayNameProperty);
			vrl.ConfigurationNode = ConfigurationNode;
			this.Control = vrl;
			vrl.ViewSizeChanged += new FwViewSizeChangedEventHandler(this.OnViewSizeChanged);
			VectorReferenceView view = (VectorReferenceView)vrl.MainControl;
			view.ViewSizeChanged += new FwViewSizeChangedEventHandler(this.OnViewSizeChanged);
			// We don't want to be visible until later, since otherwise we get a temporary
			// display in the wrong place with the wrong size that serves only to annoy the
			// user.  See LT-1518 "The drawing of the DataTree for Lexicon/Advanced Edit draws
			// some initial invalid controls."  Becoming visible when we set the width and
			// height seems to delay things enough to avoid this visual clutter.
			vrl.Visible = false;
		}

		/// <summary>
		/// Set the width of the item, perform any internal layout inside the item,
		/// and return its height (as in the Height property).
		/// Side effect: set height and width of SliceTreeNode.
		/// </summary>
		public override int SetWidthAndGetHeight(int width)
		{
			VectorReferenceLauncher vrl = (VectorReferenceLauncher)this.Control;
			VectorReferenceView view = (VectorReferenceView)vrl.MainControl;
			int hMin = m_containingDataTree.Diagram.GetMinFieldHeight();
			int h1 = view.RootBox.get_Height();
			int h2 =  base.SetWidthAndGetHeight(width);
			int hOld = m_treeNode.Height;
			int hNew = Math.Max(h1, hMin) + 3;
			if (hNew != hOld)
			{
				m_treeNode.Height = hNew;
				vrl.Height = hNew - 1;
				view.Height = hNew - 1;
			}
			// Delaying visibility until this point avoids visual stuttering -- see the comment
			// above where we set Visible to false.
			vrl.Visible = true;
			return hNew;
		}

		/// <summary>
		/// Handle changes in the size of the underlying view.
		/// </summary>
		protected void OnViewSizeChanged(object sender, FwViewSizeEventArgs e)
		{
			// For now, just handle changes in the height.
			VectorReferenceLauncher vrl = (VectorReferenceLauncher)this.Control;
			VectorReferenceView view = (VectorReferenceView)vrl.MainControl;
			int hMin = m_containingDataTree.Diagram.GetMinFieldHeight();
			int h1 = view.RootBox.get_Height();
			Debug.Assert(e.Height == h1);
			int hOld = m_treeNode.Height;
			int hNew = Math.Max(h1, hMin) + 3;
			if (hNew != hOld)
			{
				m_treeNode.Height = hNew;
				vrl.Height = hNew - 1;
				view.Height = hNew - 1;
			}
		}

		/// <summary>
		/// This is passed the color that the XDE specified, if any, otherwise null.
		/// The default is to use the normal window color for editable text.
		/// Subclasses which know they should have a different default should
		/// override this method, but normally should use the specified color if not
		/// null.
		/// </summary>
		/// <param name="clr"></param>
		public override void OverrideBackColor(String backColorName)
		{
			if (this.Control == null)
				return;
			VectorReferenceLauncher vrl = (VectorReferenceLauncher)this.Control;
			vrl.BackColor = System.Drawing.SystemColors.Control;
		}

		public override void RegisterWithContextHelper ()
		{
			if (this.Control != null)
			{
				string caption = XmlUtils.GetOptionalAttributeValue(ConfigurationNode, "label",
					"");

				VectorReferenceLauncher vrl = (VectorReferenceLauncher)this.Control;
				Mediator.SendMessage("RegisterHelpTargetWithId",
					new object[]{vrl.Controls[1], caption, HelpId});
				Mediator.SendMessage("RegisterHelpTargetWithId",
					new object[]{vrl.Controls[0], caption, HelpId, "Button"});
			}
		}
	}
}

