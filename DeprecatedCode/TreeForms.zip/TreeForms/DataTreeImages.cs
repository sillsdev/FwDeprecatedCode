using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for DataTreeImages.
	/// </summary>
	public class DataTreeImages : System.Windows.Forms.UserControl
	{
		public System.Windows.Forms.ImageList nodeImages;
		private System.ComponentModel.IContainer components;

		public DataTreeImages()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(DataTreeImages));
			this.nodeImages = new System.Windows.Forms.ImageList(this.components);
			// 
			// nodeImages
			// 
			this.nodeImages.ImageSize = new System.Drawing.Size(16, 16);
			this.nodeImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("nodeImages.ImageStream")));
			this.nodeImages.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// DataTreeImages
			// 
			this.Name = "DataTreeImages";

		}
		#endregion
	}
}
