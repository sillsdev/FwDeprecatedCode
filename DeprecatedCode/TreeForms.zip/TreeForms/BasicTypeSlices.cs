// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: BasicTypeSlice.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;

using SIL.FieldWorks.FDO;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for Checkbox.
	/// </summary>
	public class CheckboxSlice : FieldSlice
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="CheckboxSlice"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		private CheckBox m_cb;
		public CheckboxSlice(FdoCache cache, CmObject obj, int flid)
			: base(new CheckBox(), cache, obj, flid)
		{
			m_cb = ((CheckBox)this.Control);
		}

		protected override void UpdateDisplayFromDatabase()
		{
			m_cb.CheckedChanged -= new EventHandler(OnChanged);
			m_cb.Checked = m_cache.GetBoolProperty(Object.Hvo, m_flid);
			m_cb.CheckedChanged += new EventHandler(OnChanged);
			m_cb.GotFocus +=new EventHandler(GotFocus);
		}

		public void OnChanged(Object obj, System.EventArgs args)
		{
			m_cache.BeginUndoTask("Undo change " + m_fieldName, "Redo change " +  m_fieldName);
			m_cache.SetBoolProperty(Object.Hvo, m_flid, ((CheckBox)obj).Checked);
			m_cache.EndUndoTask();
		}

		/// <summary>
		/// This is passed the color that the XDE specified, if any, otherwise null.
		/// The default is to use the normal window color for editable text.
		/// Subclasses which know they should have a different default should
		/// override this method, but normally should use the specified color if not
		/// null.
		/// </summary>
		/// <param name="clr"></param>
		public override void OverrideBackColor(String backColorName)
		{
			if (this.Control == null)
				return;
			this.Control.BackColor = System.Drawing.SystemColors.Control;
		}

		private void GotFocus(object sender, EventArgs e)
		{
			Container.CurrentSlice = this;
		}
	}

	/// <summary>
	/// Summary description for DateSlice.
	/// </summary>
	public class DateSlice : FieldSlice
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="DateSlice"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public DateSlice(FdoCache cache, CmObject obj, int flid)
			: base(new RichTextBox(), cache, obj, flid)
		{
			Control.Enabled = false;
			Control.BackColor = System.Drawing.Color.FromKnownColor(System.Drawing.KnownColor.ControlLight);
			Control.ForeColor = System.Drawing.SystemColors.ControlText;
			Control.TabStop = false;
			Control.Size = new System.Drawing.Size(128, 16);
			((RichTextBox)Control).BorderStyle = System.Windows.Forms.BorderStyle.None;
			((RichTextBox)Control).ReadOnly = true;
			Control.GotFocus +=new EventHandler(GotFocus);
		}

		protected override void UpdateDisplayFromDatabase()
		{
			RichTextBox rtb = ((RichTextBox)this.Control);
			try
			{
				DateTime dt = m_cache.GetTimeProperty(Object.Hvo, m_flid);
				rtb.Text = dt.ToLongDateString() + " " + dt.ToShortTimeString();
			}
			catch (Exception error)
			{
				rtb.Text = error.Message;
				//this is probably not worth scaring the user about,
				//but I do want to throw the exception for debugging purposes.
//enable once the SP gets fixed.
//#if DEBUG
//				throw error;
//#endif
			}
		}

		private void GotFocus(object sender, EventArgs e)
		{
			Container.CurrentSlice = this;
		}
	}

	/// <summary>
	/// Summary description for IntegerSlice.
	/// </summary>
	public class IntegerSlice : FieldSlice
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="IntegerSlice"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		TextBox m_tb;
		int m_previousValue;
		public IntegerSlice(FdoCache cache, CmObject obj, int flid)
			: base(new TextBox(), cache, obj, flid)
		{
			m_tb = ((TextBox)this.Control);
			m_tb.LostFocus += new EventHandler(LostFocus);
			m_tb.GotFocus +=new EventHandler(GotFocus);
			m_tb.BorderStyle = System.Windows.Forms.BorderStyle.None;
		}

		protected override void UpdateDisplayFromDatabase()
		{
			m_previousValue = m_cache.GetIntProperty(Object.Hvo, m_flid);
			m_tb.Text = m_previousValue.ToString();
		}

		public void LostFocus(Object obj, System.EventArgs args)
		{
			try
			{
				int i = Convert.ToInt32(m_tb.Text);
				if(i == m_previousValue) 
					return;
				m_previousValue = i;
				m_cache.BeginUndoTask("Undo change to " + m_fieldName, "Redo change to " +
					m_fieldName);
				m_cache.SetIntProperty(Object.Hvo, m_flid, i);
				m_cache.EndUndoTask();
			}
			catch(FormatException error)
			{
				error.ToString(); // JohnT added because compiler complains not used.
				MessageBox.Show("Please enter a whole number");
			}
			catch(Exception error)
			{
				error.ToString(); // JohnT added because compiler complains not used.
				MessageBox.Show("Couldn't set the field to that value (too large?).");
			}		
		}

		private void GotFocus(object sender, EventArgs e)
		{
			Container.CurrentSlice = this;
		}
	}
}
