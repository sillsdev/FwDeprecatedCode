// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FieldSlice.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.  Collections;

using SIL.FieldWorks.FDO;


namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	public abstract class FieldSlice : Slice
	{
		/// <summary>
		/// The field identifier for the attribute we are displaying.
		/// </summary>
		protected int m_flid;

		protected string m_fieldName;

		/// <summary>
		/// Get the flid.
		/// </summary>
		public int Flid
		{
			get { return m_flid; }
		}

		/// <summary>
		/// Default Constructor.
		/// </summary>
		public FieldSlice() : base()
		{
		}
		
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="obj">CmObject that is being displayed.</param>
		/// <param name="flid">The field identifier for the attribute we are displaying.</param>
		public FieldSlice(System.Windows.Forms.Control ctrlT, FdoCache cache, CmObject obj, int flid) : base(ctrlT)
		{
			Debug.Assert(cache != null);
			Debug.Assert(obj != null);
			m_cache = cache;
			Object = obj;
			m_flid = flid;

			m_cache.MetaDataCacheAccessor.GetFieldName((uint)m_flid, out m_fieldName);

		}

	
		protected abstract void UpdateDisplayFromDatabase();

		/// <summary>
		/// Called when the slice is first created, but also when it is 
		/// "reused" (e.g. refresh or new target object)
		/// </summary>
		/// <param name="tc"></param>
		public override void Install(DataTree tc)
		{
			base.Install(tc);
			UpdateDisplayFromDatabase();
			//tc.AccessibilityObject.Name = this.Label;
			this.Control.AccessibilityObject.Name = this.Label;
		}
	}
}