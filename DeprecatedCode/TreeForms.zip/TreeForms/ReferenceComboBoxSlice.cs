// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ReferenceComboBoxSlice.cs
// Responsibility: RandyR
// Last reviewed: 
// 
// <remarks>
// Implements the "referenceComboBox" XDE editor.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Runtime.InteropServices; // needed for Marshal

using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Linguistics.Common;
using SIL.FieldWorks.Common.Controls;
using SIL.FieldWorks.Common.Widgets;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.FdoUi;
using SIL.Utils;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for ReferenceComboBoxSlice.
	/// </summary>
	public class ReferenceComboBoxSlice : FieldSlice
	{
		private const string kEmpty = "<Empty>";

		protected bool m_processSelectionEvent = true;
		protected int m_currentSelectedIndex;

		protected FwComboBox m_combo;
		protected  IPersistenceProvider m_persistProvider;

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="obj">CmObject that is being displayed.</param>
		/// <param name="flid">The field identifier for the attribute we are displaying.</param>
		public ReferenceComboBoxSlice(FdoCache cache, CmObject obj, int flid,
			SIL.Utils.IPersistenceProvider persistenceProvider)
		: base(new FwComboBox(), cache, obj, flid)
		{
			m_persistProvider= persistenceProvider;
			m_combo = (FwComboBox)this.Control;
			m_combo.WritingSystemFactory = cache.LanguageWritingSystemFactoryAccessor;
			m_combo.DropDownStyle = ComboBoxStyle.DropDownList;
			m_combo.Font = new System.Drawing.Font(
				cache.LanguageProject.DefaultVernacularWritingSystemFont, 10);
			m_combo.FwBorderStyle = System.Windows.Forms.BorderStyle.None;
			//m_combo.Dock = System.Windows.Forms.DockStyle.Left;

			m_combo.SelectedIndexChanged += new EventHandler(SelectionChanged);
		}

		/// <summary>
		/// Set the width of the item, perform any internal layout inside the item, and return
		/// its height (as in the Height property).
		/// Side effect: set height and width of SliceTreeNode.
		/// Overrides must call base method or AdjustTreeNodeSize (after adjusting this.Height).
		/// </summary>
		public override int SetWidthAndGetHeight(int dxpWidth)
		{
			this.Control.Width = 200;
			AdjustTreeNodeSize();
			return Height;
		}

		protected void UpdateDisplayFromDatabase(string displayNameProperty)
		{
			DoUpdateDisplayFromDatabase(displayNameProperty);
		}
		protected override void UpdateDisplayFromDatabase()
		{
			DoUpdateDisplayFromDatabase(null);
		}
		private void DoUpdateDisplayFromDatabase(string displayNameProperty)
		{
			m_processSelectionEvent = false;
			m_currentSelectedIndex = 0;
			m_combo.Items.Clear();
			ArrayList candidates = this.Object.ReferenceTargetCandidates(m_flid);
			ObjectLabelCollection labels = new ObjectLabelCollection(m_cache, candidates,
				displayNameProperty);
			int currentValue = m_cache.GetObjProperty(Object.Hvo, m_flid);
			int idx = 0;
			foreach(ObjectLabel ol in labels)
			{
				m_combo.Items.Add(ol);
				if (ol.Hvo == currentValue)
				{
					m_combo.SelectedItem = ol;
					m_currentSelectedIndex = idx;
				}
				idx++;
			}
			idx = m_combo.Items.Add(kEmpty);
			if (currentValue == 0)
			{
				m_combo.SelectedIndex = idx;
				m_currentSelectedIndex = idx;
			}
			m_processSelectionEvent = true;
		}

		/// <summary>
		/// Event handler for selection changed in combo box.
		/// </summary>
		/// <param name="sender">Source control</param>
		/// <param name="e"></param>
		protected virtual void SelectionChanged(object sender, EventArgs e)
		{
			Debug.Assert(m_combo != null);

			if (!m_processSelectionEvent)
				return;

			int newValue;
			if (m_combo.SelectedItem.ToString() == kEmpty)
				newValue = 0;
			else
				newValue = ((ObjectLabel)m_combo.SelectedItem).Hvo;

			m_cache.BeginUndoTask("Undo edit " + m_fieldName, "Redo set " +  m_fieldName);
			m_cache.SetObjProperty(Object.Hvo, m_flid, newValue);
			m_cache.EndUndoTask();
		}
		public override void RegisterWithContextHelper ()
		{
			if (this.Control != null)
			{
				string caption = XmlUtils.GetOptionalAttributeValue(ConfigurationNode, "label",
					"");

				FwComboBox launcher = (FwComboBox)this.Control;
				Mediator.SendMessage("RegisterHelpTargetWithId",
					new object[]{launcher.Controls[0], caption, HelpId});
				//balloon was making it hard to actually click this
				//Mediator.SendMessage("RegisterHelpTargetWithId",
				//	new object[]{launcher.Controls[1], caption, HelpId, "Button"});
			}
		}

	}

	public class MSAReferenceComboBoxSlice : ReferenceComboBoxSlice
	{
		private const string kAddNewAnalysis = "Other...";
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="cache">FDO cache.</param>
		/// <param name="obj">CmObject that is being displayed.</param>
		/// <param name="flid">The field identifier for the attribute we are displaying.</param>
		public MSAReferenceComboBoxSlice(FdoCache cache, CmObject obj, int flid,
			IPersistenceProvider persistenceProvider)
		: base(cache, obj, flid,persistenceProvider)
		{
		}

		protected override void UpdateDisplayFromDatabase()
		{
			// use special form (slot name) for this
			base.UpdateDisplayFromDatabase("InterlinearName");
			m_combo.Items.Add(kAddNewAnalysis);
		}

		/// <summary>
		/// Event handler for selection changed in combo box.
		/// </summary>
		/// <param name="sender">Source control</param>
		/// <param name="e"></param>
		protected override void SelectionChanged(object sender, EventArgs e)
		{
			if (!m_processSelectionEvent)
				return;

			if (m_combo.SelectedItem.ToString() != kAddNewAnalysis)
			{
				base.SelectionChanged(sender, e);
				// Remember what we just selected.
				m_currentSelectedIndex = m_combo.SelectedIndex;
				return;
			}

			// User selected "Other".
			LexSense sense = (LexSense)m_obj;
			LexEntry entry = sense.Entry;
			int morphType = entry.MorphType;
			MsaType msaType = MsaType.kNotSet;
			// Get current MSAs, and check which kind they are.
			// We are interested in knowing if they are the same kind or a mixed bag.
			// We show very different UI, depending on what we dig up here.
			foreach (MoMorphoSyntaxAnalysis msa in entry.MorphoSyntaxAnalysesOC)
			{
				string msaTypeName = msa.GetType().Name;
				switch (msaTypeName)
				{
					case "MoStemMsa":
					{
						if (msaType == MsaType.kNotSet)
							msaType = MsaType.kStem;
						else if (msaType != MsaType.kStem)
						{
							msaType = MsaType.kMixed;
						morphType = MoMorphType.kmtMixed;
					}
						break;
				}
					case "MoUnclassifiedAffixMsa":
				{
						if (msaType == MsaType.kNotSet)
							msaType = MsaType.kUnclassified;
						else if (msaType != MsaType.kUnclassified)
					{
							msaType = MsaType.kMixed;
							morphType = MoMorphType.kmtMixed;
						}
						break;
					}
					case "MoInflectionalAffixMsa":
					{
						if (msaType == MsaType.kNotSet)
							msaType = MsaType.kInfl;
						else if (msaType != MsaType.kInfl)
						{
							msaType = MsaType.kMixed;
							morphType = MoMorphType.kmtMixed;
						}
						break;
					}
					case "MoDerivationalAffixMsa":
				{
						if (msaType == MsaType.kNotSet)
							msaType = MsaType.kDeriv;
						else if (msaType != MsaType.kDeriv)
					{
							msaType = MsaType.kMixed;
						morphType = MoMorphType.kmtMixed;
					}
						break;
				}
			}
			}
			if (msaType == MsaType.kUnclassified || msaType == MsaType.kNotSet)
				morphType = MoMorphType.kmtUnknown;

			DummyGenericMSA dummyMSA = new DummyGenericMSA();
			switch (morphType)
			{
				default:
				{
					Debug.Assert(false, "Invalid morph type.");
					break;
				}
				case MoMorphType.kmtMixed:
				{
					using (MsaCreatorDlg dlg = new MsaCreatorDlg())
					{
						dlg.SetDlgInfo(m_cache, m_persistProvider, null, (LexSense)m_obj);
						if (dlg.ShowDialog(Control.FindForm()) == DialogResult.OK)
					{
							Container.RefreshList();
					}
					else
							ResetToOldSelection();
					}
						return;
					}
				case MoMorphType.kmtRoot: // Fall through.
				case MoMorphType.kmtStem: // Fall through.
				case MoMorphType.kmtBoundRoot: // Fall through.
				case MoMorphType.kmtBoundStem: // Fall through.
				case MoMorphType.kmtParticle: // Fall through.
				case MoMorphType.kmtEnclitic: // Fall through.
				case MoMorphType.kmtProclitic: //All of these get a Stem MSA.
				{
					msaType = MsaType.kStem;
					goto case MoMorphType.kmtCircumfix;
				}
				case MoMorphType.kmtUnknown: // Fall through.
				case MoMorphType.kmtInfixingInterfix: // Fall through.
				case MoMorphType.kmtPrefixingInterfix: // Fall through.
				case MoMorphType.kmtSuffixingInterfix: // Fall through.
				case MoMorphType.kmtSuprafix: // Fall through.
				case MoMorphType.kmtSuffix: // Fall through.
				case MoMorphType.kmtSimulfix: // Fall through.
				case MoMorphType.kmtPrefix: // Fall through.
				case MoMorphType.kmtInfix: // Fall through.
				case MoMorphType.kmtCircumfix: // Some sort of affix.
				{
					switch (msaType)
					{
						default:
							Debug.Assert(false);
							break;
						case MsaType.kStem:
						{
							dummyMSA.MsaType = MsaType.kStem;
							ObjectLabel ol = LaunchSimpleListChooser("Category", "posEdit");
							if (ol == null)
							{
								ResetToOldSelection();
								return;
							}
							dummyMSA.MainPOS = ol.Hvo;
							break;
						}
						case MsaType.kUnclassified:
						{
							dummyMSA.MsaType = MsaType.kUnclassified;
							ObjectLabel ol = LaunchSimpleListChooser("Category", "posEdit");
							if (ol == null)
							{
								ResetToOldSelection();
								return;
							}
							dummyMSA.MainPOS = ol.Hvo;
							break;
						}
						case MsaType.kInfl:
						{
							dummyMSA.MsaType = MsaType.kInfl;
							ObjectLabel ol = LaunchSimpleListChooser("Category", "posEdit");
							if (ol == null)
							{
								ResetToOldSelection();
									return;
								}
							dummyMSA.MainPOS = ol.Hvo;

							ArrayList candidates = null;
							if (dummyMSA.MainPOS > 0)
								{
								PartOfSpeech pos = PartOfSpeech.CreateFromDBObject(m_cache, dummyMSA.MainPOS);
								candidates = pos.AllAffixSlotIDs;
							}
							else
								candidates = new ArrayList();
							ObjectLabelCollection labels =
								new ObjectLabelCollection(m_cache, candidates, null);
							SimpleListChooser chooser = new SimpleListChooser(m_persistProvider, labels, m_fieldName);
							chooser.ShowDialog();
							// It's optional.
							if (chooser.ChosenOne != null)
								dummyMSA.Slot = chooser.ChosenOne.Hvo;
							break;
						}
						case MsaType.kDeriv:
						{
							dummyMSA.MsaType = MsaType.kDeriv;
							ObjectLabel ol = LaunchSimpleListChooser("From Category", "posEdit");
							if (ol == null)
							{
								ResetToOldSelection();
								return;
							}
							dummyMSA.MainPOS = ol.Hvo;
							ol = LaunchSimpleListChooser("To Category", "posEdit");
							if (ol == null)
							{
								ResetToOldSelection();
								return;
							}
							dummyMSA.SecondaryPOS = ol.Hvo;
							break;
						}
					}
					break;
				}
			}
			sense.DummyMSA = dummyMSA;
			Container.RefreshList();
		}

		/// <summary>
		/// Reset to the old selected item.
		/// </summary>
		private void ResetToOldSelection()
		{
			m_processSelectionEvent = false;
			m_combo.SelectedIndex = m_currentSelectedIndex;
			m_processSelectionEvent = true;
		}

		/// <summary>
		/// Launch the simple list chooser with the given label.
		/// </summary>
		/// <param name="label">The label to append to the window title.</param>
		/// <returns>An ObjectLabel for the selected itme, or null, if none were selected.
		/// </returns>
		private ObjectLabel LaunchSimpleListChooser(string label, string tool)
		{
			ArrayList candidates = new ArrayList(
				m_cache.LanguageProject.PartsOfSpeechOA.PossibilitiesOS.HvoArray);
			ObjectLabelCollection labels = new ObjectLabelCollection(m_cache, candidates, null);
			SimpleListChooser chooser = new SimpleListChooser(
				m_containingDataTree.PersistenceProvder, labels, label);
			chooser.InstructionalText =
				"The following Categories have been specified in this project.";
			FwLink link = FwLink.Create(tool, Guid.Empty, m_cache.ServerName,
				m_cache.DatabaseName);
			chooser.AddLink("Edit Categories", SimpleListChooser.LinkType.kGotoLink, link);
			//chooser.AddLink("Add Category", SimpleListChooser.LinkType.kDialogLink, null);
			chooser.ShowDialog();
			// Possible enhancement: requires change to SimpleChooserDialog to mimic OK instead of Cancel,
			// and explicitly returning null from this method if a jump is taken.
			//link.TargetGuid = guidfromhvo(chooser.ChosenOne.Hvo);
			chooser.HandleAnyJump(Mediator);
			return chooser.ChosenOne;
		}
	}
}
