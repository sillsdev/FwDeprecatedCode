// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: ReferenceSlice.cs
// Responsibility: RandyR
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Xml;

using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Controls;
using SIL.Utils;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for ReferenceSlice.
	/// </summary>
	public abstract class ReferenceSlice : FieldSlice
	{
		/// <summary>
		/// Default Constructor.
		/// </summary>
		public ReferenceSlice() : base()
		{
		}
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ReferenceSlice"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public ReferenceSlice(FdoCache cache, CmObject obj, int flid,
			XmlNode configurationNode, SIL.Utils.IPersistenceProvider persistenceProvider, StringTable stringTbl) 
				: base(null, cache, obj, flid)
		{
			ConfigurationNode = configurationNode;//todo: remove this when FieldSlice gets the node as part of its constructor
			// have chooser title use the same text as the label
			m_fieldName = XmlUtils.GetOptionalAttributeValue(configurationNode, "label", m_fieldName);
			SetupControls(persistenceProvider, stringTbl);
		}

		/// <summary>
		/// Sets up the ChooserLauncher control.
		/// </summary>
		/// <remarks>
		/// Subclasses should override this to create the m_leftControl.
		/// </remarks>
		protected abstract void SetupControls(IPersistenceProvider persistenceProvider, StringTable stringTbl);

		protected override void UpdateDisplayFromDatabase()
		{
			((ReferenceLauncher)this.Control).UpdateDisplayFromDatabase();
		}

		protected string DisplayNameProperty
		{
			get
			{
				XmlNode parameters = ConfigurationNode.SelectSingleNode("deParams");
				if (parameters == null)
					return "";
				else
					return XmlUtils.GetOptionalAttributeValue(parameters, "displayProperty", "");
			}
		}
	}
}
