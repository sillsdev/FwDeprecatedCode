// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: TreeFormsMainWnd.cs
// Responsibility: RegnierR
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;

using NUnit.Framework;

using SIL.FieldWorks.Common.RootSites;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.LangProj.Generated;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	#region Main window
	/// <summary>
	/// Summary description for TreeFormsMainWnd.
	/// </summary>
	public class TreeFormsMainWnd : System.Windows.Forms.Form, IFwMainWnd
	{
		private FdoCache m_cache;
		private DataTree m_dataEntryForm;
		private XdeTemplateCollector m_templates;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="TreeFormsMainWnd"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public TreeFormsMainWnd()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			m_cache = FdoCache.Create("TestLangProj");
			m_templates = new XdeTemplateCollector(null);
			InitAndShowClient();
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged 
		/// resources; <c>false</c> to release only unmanaged resources. 
		/// </param>
		/// -----------------------------------------------------------------------------------
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (m_dataEntryForm != null)
				{
					Controls.Remove(m_dataEntryForm);
					m_dataEntryForm.Dispose();
					m_dataEntryForm = null;
				}
				if (m_cache != null)
				{
					m_cache.Dispose();
					m_cache = null;
				}
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		public void ShowObject()
		{
			m_dataEntryForm.ShowObject(m_cache.LanguageProject.Hvo, m_templates.Templates);
		}

		#region Windows Form Designer generated code
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		private void InitializeComponent()
		{
			// 
			// TreeFormsMainWnd
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(504, 422);
			this.Name = "TreeFormsMainWnd";
			this.Text = "TreeFormsMainWnd";

		}
		#endregion

		#region IFwMainWnd implementation
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Gets the currently active view (client window).
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public virtual IRootSite ActiveView
		{
			get
			{
				// TODO WW team: implement this if needed (see FwMainWnd.ActiveView for example)
				return null;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called when a window is finished being created and completely initialized.
		/// </summary>
		/// <returns>True if successful; false otherwise</returns>
		/// ------------------------------------------------------------------------------------
		public bool OnFinishedInit()
		{
			return true;
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public string ApplicationName
		{
			get {return string.Empty;}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Gets or sets the data objects cache.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public FdoCache Cache
		{
			get { return m_cache; }
			set
			{
				Debug.Assert(value != null);
				if (m_cache != null)
					m_cache.Dispose();
				m_cache = value;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Create the client windows and add correspnding stuff to the sidebar, View menu,
		/// etc. Subclasses must override this.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public void InitAndShowClient()
		{
			m_dataEntryForm = new DataTree();
			SuspendLayout();
			m_dataEntryForm.Initialize(m_cache, true);
			m_dataEntryForm.Dock = System.Windows.Forms.DockStyle.Fill;
			Controls.Add(m_dataEntryForm);
			ResumeLayout(false);
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Returns the NormalStateDesktopBounds property from the persistence object.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public Rectangle NormalStateDesktopBounds
		{
			get
			{
				return new Rectangle(Location, Size);
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Enable or disable this window.
		/// </summary>
		/// <param name="fEnable">Enable (true) or disable (false).</param>
		/// ------------------------------------------------------------------------------------
		public void EnableWindow(bool fEnable)
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Save all data in this window.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public void SaveData()
		{
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called just before a window syncronizes it's views with DB changes (e.g. when an
		/// undo or redo command is issued).
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public bool PreSynchronize(SyncInfo sync)
		{
			return true;
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called when a window syncronizes it's views with DB changes (e.g. when an undo or
		/// redo command is issued).
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public bool Synchronize(SyncInfo sync)
		{
			return true;
		}
		#endregion
	}
	#endregion // Main window

	#region Tests

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Tests for the Datatree control.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	//[TestFixture]
	public class DataTreeTests
	{
		TreeFormsMainWnd m_mainWnd;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="DataTreeTests"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public DataTreeTests()
		{
		}

		#region Setup, Teardown

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Set up an initial transaction and undo item.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[SetUp]
		public void SetUp()
		{
			m_mainWnd = new TreeFormsMainWnd();
			m_mainWnd.Show();
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Undo all DB changes
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[TearDown]
		public void TearDown()
		{
			m_mainWnd.Hide();
			m_mainWnd.Dispose();
		}
		#endregion


		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Check how many templates are in the default system.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		// Note: It appears to only fire the assert, when the GUI for NUnit is used, but
		// not while testing from NAnt.
		//[Ignore("This causes an assert to fire down in 'TsTextProps::~TsTextProps'.")]
		//[Ignore("SteveMc: This causes an assert in VwPropertyStore::put_IntProperty() due to an invalied ws value (1)")]
		public void ShowWindow()
		{
			m_mainWnd.ShowObject();
		}
	}

	#endregion // Tests
}
