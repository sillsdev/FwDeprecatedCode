// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: XdeTemplateCollectorTests.cs
// Responsibility: RegnierR
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Xml;
using System.IO;
using NUnit.Framework;

using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Summary description for XdeTemplateCollectorTests.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public class XdeTemplateCollectorTests
	{
		private XmlDocument m_xdeDoc;
		private XdeTemplateCollector m_defaultTemplates;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="XdeTemplateCollectorTests"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public XdeTemplateCollectorTests()
		{
		}

		private void CheckSize(int expectedCount, XdeTemplateCollector col)
		{
			Assert.AreEqual(expectedCount,
				col.Templates.ChildNodes.Count,
				"Wrong number of templates.");
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Instantiate a XdeTemplateCollectorTests object.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[TestFixtureSetUp]
		public void FixtureSetUp()
		{
			m_xdeDoc = new XmlDocument();
			m_xdeDoc.Load(DirectoryFinder.GetFWInstallSubDirectory(@"\XDE") + @"\allXde.xml");
			m_defaultTemplates = new XdeTemplateCollector(null);
		}


		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Check how many templates are in the default system.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void CheckDefaultTemplatesSize()
		{
			CheckSize(m_xdeDoc.DocumentElement.ChildNodes.Count, m_defaultTemplates);
		}


		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Check how many templates are in the default system.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[Test]
		public void LoadCustomTemplates()
		{
			string path = Path.Combine(DirectoryFinder.FWInstallDirectory,
					@"..\Src\Common\Controls\TreeForms\TreeFormsTests");
			XdeTemplateCollector customCol = new XdeTemplateCollector(path);
			CheckSize(m_xdeDoc.DocumentElement.ChildNodes.Count + 1, customCol);

			XmlNode customTemplate = customCol.Templates.SelectSingleNode("template[@class='MoCompoundRule']");
			Assert.AreEqual(2, customTemplate.ChildNodes.Count, "Wrong number of custom fields.");
			Assert.AreEqual("Name", customTemplate.FirstChild.Attributes["attr"].InnerText, "Wrong value for 'attr' attribute.");

			XmlNodeList nodes = customCol.Templates.SelectNodes("template[@class='PartOfSpeech']");
			Assert.AreEqual(2, nodes.Count, "Wrong number of PartOfSpeech templates.");
			XmlNode withoutMode = customCol.Templates.SelectSingleNode("template[@class='PartOfSpeech' and not(@mode)]");
			Assert.IsNotNull(withoutMode);
			Assert.AreEqual(7, withoutMode.ChildNodes.Count, "Wrong number of child nodes in custom PartOfSpeech without mode.");
			XmlNode withMode = customCol.Templates.SelectSingleNode("template[@class='PartOfSpeech' and @mode='nested']");
			Assert.IsNotNull(withMode);
			Assert.AreEqual(1, withMode.ChildNodes.Count, "Wrong number of child nodes in custom PartOfSpeech for 'nested' mode.");
		}
	}
}
