using System;
using System.Windows.Forms;
using System.Drawing;

using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.RootSites;
using SIL.Utils;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// A tree control item where the embedded form is a View (specifically
	/// SIL.FieldWorks.Common.Framework.RootSite).
	/// </summary>
	public class ViewSlice: Slice
	{
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public ViewSlice()
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// <param name="ctrlT"></param>
		/// ------------------------------------------------------------------------------------
		public ViewSlice(SimpleRootSite ctrlT): base(ctrlT)
		{
			// Base uses the virtual Control property to set the control, so this should get done by our
			// override.
//			ctrlT.AutoScroll = false;
//			ctrlT.LayoutSizeChanged += new EventHandler(this.HandleLayoutSizeChanged);
			ctrlT.Enter +=new EventHandler(ViewSlice_Enter);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public override Control Control
		{
			get	{return base.Control;}
			set
			{
				base.Control = value;
				SimpleRootSite rs = value as SimpleRootSite;
				// Embedded forms should not do their own scrolling. Rather we resize them as needed, and scroll the whole
				// DE view.
				rs.AutoScroll = false;
				rs.LayoutSizeChanged += new EventHandler(this.HandleLayoutSizeChanged);


				// This is usually done by the DataTree method that creates and initializes slices.
				// However, for most view slices doing it before the control is set does no good.
				// On the other hand, we don't want to do it during the constructor, and have it done again
				// unnecessarily by this method (which the constructor calls).
				// In any case we can't do it until our node is set.
				// So, do it only if the node is known.
				if (ConfigurationNode != null)
					OverrideBackColor(XmlUtils.GetOptionalAttributeValue(ConfigurationNode, "backColor"));
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// This is passed the color that the XDE specified, if any, otherwise null.
		/// The default is to use the normal window color for editable text.
		/// Subclasses which know they should have a different default should
		/// override this method, but normally should use the specified color if not
		/// null.
		/// </summary>
		/// <param name="clr"></param>
		/// ------------------------------------------------------------------------------------
		public override void OverrideBackColor(String backColorName)
		{
			base.OverrideBackColor(backColorName);
			if (Control != null && backColorName != null)
				Control.TabStop = (backColorName != "Control");
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public RootSite RootSite
		{
			get {return (RootSite) this.Control;}
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="ea"></param>
		/// ------------------------------------------------------------------------------------
		public void HandleLayoutSizeChanged(object sender, EventArgs ea)
		{
			Diagram.PerformLayout();
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// <param name="tc"></param>
		/// ------------------------------------------------------------------------------------
		public override void Install(DataTree tc)
		{
			// Sometimes we get a spurious "out of memory" error while trying to create a handle for the
			// RootSite if its cache isn't set before we add it to its parent.
			((RootSite) this.Control).Cache = tc.Cache;
			// JT: seems to actually cause a problem if we replace it with itself. RootSite probably needs a fix.
			if (((RootSite) this.Control).StyleSheet != tc.StyleSheet)
				((RootSite) this.Control).StyleSheet = tc.StyleSheet;
			base.Install(tc);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Set the width of the item, perform any internal layout inside the item, and return its height
		/// (as in the Height property). ViewItem overrides to set the view width.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public override int SetWidthAndGetHeight(int dxpWidth)
		{
			RootSite rs = this.RootSite;
			rs.Width = dxpWidth;
			rs.PerformLayout();
			if (rs.RootBox != null)
			{
				int rootHeight = rs.RootBox.get_Height();
				rs.Height = rootHeight;  // Allow it to be the height it wants.
			}
			AdjustTreeNodeSize();
			rs.SetAccessibleName(this.Label);
			return Height;
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// ------------------------------------------------------------------------------------
		private void ViewSlice_Enter(object sender, System.EventArgs e)
		{
			Control.Focus();
			if (m_containingDataTree.SliceControlContainer is SliceControlContainer)
			{
				SliceControlContainer uc = 
					(SliceControlContainer)m_containingDataTree.SliceControlContainer;
				uc.ActiveControl = Control;
			}
		}
	}
}
