// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2004, SIL International. All Rights Reserved.   
// <copyright from='2004' to='2004' company='SIL International'>
//		Copyright (c) 2004, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Command.cs
// Authorship History: Randy Regnier
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Xml;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using System.IO;

using SIL.FieldWorks.Common.Utils;
using SIL.Utils;
using XCore;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Class that shows a button (or hyperlink someday) that
	/// runs some arbitrary XCore command, based on its ID.
	/// </summary>
	public class CommandSlice : Slice
	{
		/// <summary>
		/// Store the Command object that knows what to do.
		/// </summary>
		private Command m_command;
		private XmlNode m_cmdNode;

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="node">The "deParams" node in some XDE file.</param>
		public CommandSlice(XmlNode node)
		{
			Debug.Assert(node != null);
			XmlNode cmdNode = node["command"];
			Debug.Assert(cmdNode != null);
			m_cmdNode = cmdNode;
			Button btn = new Button();

			btn.FlatStyle = FlatStyle.Popup;
			btn.Click += new EventHandler(btn_Click);
			Control = btn;
		}

		/// <summary>
		/// Override to set it to the Control color.
		/// </summary>
		/// <param name="clr"></param>
		public override void OverrideBackColor(String backColorName)
		{
			if (this.Control == null)
				return;
			this.Control.BackColor = System.Drawing.SystemColors.Control;
		}

		public override void RegisterWithContextHelper()
		{
			if (Control != null)//grouping nodes do not have a control
			{
				Mediator.SendMessage("RegisterHelpTargetWithId",
					new object[]{Control,
									ConfigurationNode.Attributes["label"].Value,
									HelpId});
			}
		}


		/// <summary>
		/// Set the width of the item, perform any internal layout inside the item, and return its height
		/// (as in the Height property).
		/// Side effect: set height and width of SliceTreeNode.
		/// Overrides must call base method or AdjustTreeNodeSize (after adjusting this.Height).
		/// </summary>
		public override int SetWidthAndGetHeight(int dxpWidth)
		{
			//this.Control.Width = dxpWidth;
			AdjustTreeNodeSize();
			return Height;
		}

		protected override string HelpId
		{
			get { return m_command.Id; }
		}

		/// <summary>
		/// Override, so we can get the command object.
		/// </summary>
		public override XCore.Mediator Mediator
		{
			get
			{
				return base.Mediator;
			}
			set
			{
				base.Mediator = value;
				m_command = (Command)value.CommandSet[m_cmdNode.Attributes["cmdID"].Value];
				Debug.Assert(m_command != null);
				Control.Text = m_command.Label.Replace("_", null);
				Button b = (Button)Control;
				
				b.Width = 130;
			}
		}

		/// <summary>
		/// Handle click event on the button.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btn_Click(object sender, EventArgs e)
		{
			m_command.InvokeCommand();
		}
	}
}
