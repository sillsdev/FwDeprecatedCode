using System;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;
using System.IO;
using System.Xml;
using System.Diagnostics;
using System.Runtime.InteropServices;

using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.LangProj.Generated;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.Common.Framework;
using SIL.FieldWorks.Common.Utils;
using SIL.FieldWorks.Common.Controls;
using SIL.Utils;
using SIL.FieldWorks.Common.RootSites;
using XCore;

namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// A DataTree displays a tree diagram alongside a collection of controls. Each control is
	/// represented as a Slice, and typically contains and actual .NET control of some
	/// sort (most often, in FieldWorks, a subclass of SIL.FieldWorks.Common.Framework.RootSite).
	/// The controls are arranged vertically, one under the other, and the tree diagram is
	/// aligned with the controls.
	/// 
	/// The creator of a DataTree is responsible to add items to it, though DataTree
	/// provide helpful methods for adding
	/// certain commonly useful controls. Additional items may be added as a result of user
	/// actions, typically expanding and contracting nodes.
	/// 
	/// Much of the standard behavior of the DataTree is achieved by delegating it to virtual
	/// methods of Slice, which can be subclassed to specialize this behavior.
	/// 
	/// Review JohnT: do I have the right superclass? This choice allows the window to have
	/// a scroll bar and to contain other controls, and seems to be the intended superclass
	/// for stuff developed by application programmers.
	/// </summary>
	/// Possible superclasses for DataTree:
	/// System.Windows.Forms.Panel
	/// System.Windows.Forms.ContainerControl
	/// System.Windows.Forms.UserControl
	public class DataTree : System.Windows.Forms.Panel, SIL.FieldWorks.Common.COMInterfaces.IVwNotifyChange
	{
		//use SetContextMenuHandler() to subscribe to this event (if you want to provide a Context menu for this DataTree),
		protected event  TreeNodeEventHandler ShowContextMenu;
		protected AutoDataTreeMenuHandler m_autoHandler;
		protected SliceCollection m_slices;
		protected int m_hvoRoot; // Typically the object we are editing.
		protected IFwMetaDataCache m_mdc; // allows us to interpret class and field names and trace superclasses.
		protected FDO.FdoCache m_cache;
		protected FDO.CmObject m_root;
		protected Slice m_currentSlice= null;
		protected ImageCollection m_smallImages= null;

		/// <summary>
		/// This XML document object holds the nodes that we create on-the-fly to represent custom fields.
		/// </summary>
		private XmlDocument m_autoCustomFieldNodesDocument;
		private XmlNode m_autoCustomFieldNodesDocRoot;

		protected XmlNode m_allTemplates; // top-level specification of view; children are <template> nodes.
		protected DataTreeDiagram m_diagram;
		protected internal bool m_fHasSplitter;
		protected internal Splitter m_splitter;
		protected internal SliceControlContainer m_rightPane;
		protected SliceFilter m_sliceFilter;

		protected internal string m_rootMode = null; // Mode to apply to root object.
		protected Set m_monitoredProps = new Set(); // Set of (hvo, flid) IntPairs, properties for which we must refresh if altered.
		// Number of times DeepSuspendLayout has been called without matching DeepResumeLayout.
		protected int m_cDeepSuspendLayoutCount; 
		protected SIL.Utils.StringTable m_stringTable;
		protected IPersistenceProvider m_persistenceProvider=null;
		protected FwStyleSheet m_styleSheet;
		public enum TreeItemState: byte
		{
			ktisCollapsed,
			ktisExpanded,
			ktisFixed, // not able to expand or contract
			// Normally capable of expansion, this node has no current children, typically because it
			// expands to show a sequence and the sequence is empty. We treat it like 'collapsed'
			// in that, if an object is added to the sequence, we show it. But, it is drawn as an empty
			// box, and clicking has no effect.
			ktisCollapsedEmpty 
		}
		// to allow slices to handle events (e.g. InflAffixTemplateSlice)
		XCore.Mediator m_mediator;

		protected string m_classNameRCH = null;
		protected System.Type m_typeRCH = null;
		protected object m_rch = null;		// IRecordChangeHandler object.

		#region Slice collection manipulation methods

		public SliceCollection Slices
		{
			get { return m_slices; }
		}

		/// <summary>
		/// Use with care...if it's a real slice, or a real one being replaced, there are
		/// other things to do like adding to or removing from container. This is mainly for messing
		/// with dummy slices.
		/// </summary>
		/// <param name="i"></param>
		/// <param name="slice"></param>
		internal void RawSetSlice(int i, Slice slice)
		{
			m_slices[i] = slice;
		}
		#endregion Slice collection manipulation methods

		public DataTree()
		{
			m_autoCustomFieldNodesDocument = new XmlDocument();
			m_autoCustomFieldNodesDocRoot = m_autoCustomFieldNodesDocument.CreateElement("root");
			m_autoCustomFieldNodesDocument.AppendChild(m_autoCustomFieldNodesDocRoot);
			m_diagram = new DataTreeDiagram(this);
			m_slices = new SliceCollection(this, m_diagram);
		}

		/// <summary>
		/// Get/Set a stylesheet suitable for use in views.
		/// Ideally, there should be just one for the whole application, so if the app has
		/// more than one datatree, do something to ensure this.
		/// Also, something external should set it if the default stylesheet (the styles
		/// stored in LanguageProject.Styles) is not to be used.
		/// Otherwise, the datatree will automatically load it when first requested
		/// (provided it has a cache by that time).
		/// </summary>
		public FwStyleSheet StyleSheet
		{
			get
			{
				if (m_styleSheet == null && m_cache != null)
				{
					m_styleSheet = new FwStyleSheet();
					m_styleSheet.Init(m_cache, m_cache.LanguageProject.Hvo,
						(int)BaseLanguageProject.LanguageProjectTags.kflidStyles);
				}
				return m_styleSheet;
			}

			set {m_styleSheet = value;}

		}

		void IVwNotifyChange.PropChanged(int hvo, int tag, int ivMin, int cvIns, int cvDel)
		{
			IntPair p = new IntPair(hvo, tag);
			if (m_monitoredProps.Contains(p))
				RefreshList();
			if (tag == (int)FDO.Ling.LexEntry.LexEntryTags.kflidCitationForm)
			{
				// Check for changing homograph numbers.
			}
		}

		public XCore.Mediator Mediator
		{
			get
			{
				return m_mediator;
			}
			set
			{
				m_mediator = value;
			}
		}
		/// <summary>
		/// return the slice which should receive commands. 
		/// </summary>
		/// <remarks> originally, I had called this FocusSlice, but that was misleading because
		/// some slices do not have any control, or have one but it cannot be focused upon.
		/// currently, you get to be the current slice if
		/// 1) your control receives focus
		/// 2) the user clicks on your tree control
		/// </remarks>
		public Slice CurrentSlice
		{
			get
			{				 
				return m_currentSlice;
			}
			set
			{
				m_currentSlice = value;
				this.Refresh();
			}
		}

		protected internal DataTreeDiagram Diagram
		{
			get
			{
				return m_diagram;
			}
		}

		public CmObject Root
		{
			get { return m_root; }
		}

		public ImageCollection SmallImages
		{
			get
			{
				return m_smallImages;
			}
			set
			{
				m_smallImages = value;
			}
		}

		/// <summary>
		/// Allows control of the mode used to search for the root template.
		/// </summary>
		public string RootMode
		{
			get {return m_rootMode;}
			set {m_rootMode = value;}
		}

		public Color DiagramColor
		{
			get
			{
				return m_diagram.BackColor;
			}
			set
			{
				m_diagram.BackColor = value;
			}	
		}

		/// <summary>
		/// a look up table for getting the correct version of strings that the user will see.
		/// </summary>
		public SliceFilter SliceFilter
		{
			get
			{
				return m_sliceFilter;
			}
			set
			{
				m_sliceFilter = value;
			}
		}

		public StringTable StringTbl
		{
			get
			{
				return m_stringTable;
			}
			set
			{
				m_stringTable = value;
			}
		}

		public IPersistenceProvider PersistenceProvder
		{
			set
			{
				m_persistenceProvider= value;
			}
			get
			{
				return m_persistenceProvider;
			}
		}

		public DataTree(FDO.FdoCache cache, int hvoRoot, XmlNode allTemplates)
		{
			Initialize(cache, hvoRoot, allTemplates, true);
		}

		public DataTree(FDO.FdoCache cache, int hvoRoot, XmlNode allTemplates, bool fHasSplitter)
		{
			Initialize(cache, hvoRoot, allTemplates, fHasSplitter);
		}

		/// <summary>Invoke the Fixup() method of the ChangeRecordHandler object.</summary>
		private void HandleRecordChanges(bool fRefresh)
		{
			Debug.Assert(m_rch != null);
			Debug.Assert(m_classNameRCH != null);
			Debug.Assert(m_typeRCH != null);
			try
			{
				System.Reflection.MethodInfo mi = m_typeRCH.GetMethod("Fixup");
				object[] parameters = new object[1];
				parameters[0] = (object)fRefresh;
				mi.Invoke(m_rch, parameters);
			}
			catch (Exception error)
			{
				throw new RuntimeConfigurationException(
					"DataTree could not invoke the Fixup method of the class " + 
					m_classNameRCH, error);
			}
			m_rch = null;
		}

		public void ShowObject(int hvoRoot, XmlNode allTemplates)
		{
			Debug.Assert(m_cache!=null, "You need to call Initialize() first.");

			m_allTemplates = allTemplates;
			if (m_hvoRoot != hvoRoot)
			{
				// A reasonably assumption is that no slice will be reusable for a different
				// object, and the 'path' that is used to figure whether a slice IS reusable
				// doesn't include the root, so if we attempt reuseMap, we will get spurious
				// matches. So discard all slices.
				m_slices.Clear();

				if (m_rch != null)
				{
					// We need to refresh the record list if homograph numbers change.
					HandleRecordChanges(true);
				}
				m_hvoRoot = hvoRoot;
				m_root = FDO.CmObject.CreateFromDBObject(m_cache, m_hvoRoot);
			}

			RefreshList();
		}

		public int RootObjectHvo
		{
			get
			{
				return m_hvoRoot;
			}
		}
		
		public void Initialize(FDO.FdoCache cache, int hvoRoot, XmlNode allTemplates,
			bool fHasSplitter)
		{
			Initialize(cache, fHasSplitter);

			// This has to be created before we start adding slices, so they can be put into it.
			// (Otherwise we would normally do this in initializeComponent.)
			m_allTemplates = allTemplates;
			m_hvoRoot = hvoRoot;
			// Now use the XML to create some editors.
			m_root = FDO.CmObject.CreateFromDBObject(m_cache, m_hvoRoot);
			InitializeComponent();	
		}

		/// <summary>
		/// Suspend the layout of this window and its immediate children.
		/// This version also maintains a count, and does not resume until the number of
		/// resume calls balances the number of suspend calls.
		/// </summary>
		public void DeepSuspendLayout()
		{
			Debug.Assert(m_cDeepSuspendLayoutCount >= 0);
			if (m_cDeepSuspendLayoutCount == 0)
			{
				SuspendLayout();
				Diagram.SuspendLayout();
				if (m_rightPane != null)
					m_rightPane.SuspendLayout();
			}
			m_cDeepSuspendLayoutCount++;
		}
		/// <summary>
		/// Resume the layout of this window and its immediate children.
		/// This version also maintains a count, and does not resume until the number of
		/// resume calls balances the number of suspend calls.
		/// </summary>
		public void DeepResumeLayout()
		{
			Debug.Assert(m_cDeepSuspendLayoutCount > 0);
			m_cDeepSuspendLayoutCount--;
			if (m_cDeepSuspendLayoutCount == 0)
			{
				ResumeLayout();
				Diagram.ResumeLayout();
				if (m_rightPane != null)
					m_rightPane.ResumeLayout();
			}
		}

		/// <summary>
		/// initialization for when you don't actually know what you want to show yet
		/// </summary>
		/// <param name="cache"></param>
		/// <param name="fHasSplitter"></param>
		public void InitializeBasic(FDO.FdoCache cache, bool fHasSplitter)
		{
			//in a normal user application, this auto menu handler will not be used.
			//instead, the client of this control will call SetContextMenuHandler()
			//with a customized handler.
			m_autoHandler = new AutoDataTreeMenuHandler(this);
			SetContextMenuHandler(new TreeNodeEventHandler(m_autoHandler.ShowSliceContextMenu));

			// This has to be created before we start adding slices, so they can be put into it.
			// (Otherwise we would normally do this in initializeComponent.)
			m_fHasSplitter = fHasSplitter;
			m_mdc = cache.MetaDataCacheAccessor;
			m_cache = cache;
		}
		public void Initialize(FDO.FdoCache cache, bool fHasSplitter)
		{
			InitializeBasic(cache, fHasSplitter);
			// Calling it twice causes an assert to fire in VwCacheDa::AddNotification,
			// because it tries to add 'this' twice.
			InitializeComponent();
		}
		
		//		public void Initialize(FDO.FdoCache cache, int hvoRoot, XmlNode allTemplates, bool fHasSplitter)
		//		{
		//			// This has to be created before we start adding slices, so they can be put into it.
		//			// (Otherwise we would normally do this in initializeComponent.)
		//			m_allTemplates = allTemplates;
		//			m_fHasSplitter = fHasSplitter;
		//			m_hvoRoot = hvoRoot;
		//			m_mdc = cache.MetaDataCacheAccessor;
		//			m_cache = cache;
		//			// Now use the XML to create some editors.
		//			m_root = FDO.CmObject.CreateFromDBObject(m_cache, m_hvoRoot);
		//			InitializeComponent();
		//			
		//		}
		
		protected void InitializeComponentBasic()
		{
			// Set up property change notification.
			m_cache.MainCacheAccessor.AddNotification(this);
			m_diagram = new DataTreeDiagram(this);
			m_diagram.AccessibilityObject.Name = "DataTreeDiagram";
			this.BorderStyle = BorderStyle.FixedSingle;
			if (m_fHasSplitter)
			{
				m_diagram.Dock = DockStyle.Left;
				m_diagram.BackColor = Color.FromKnownColor(KnownColor.ControlLightLight);//.Control);

				m_splitter = new Splitter();
				m_splitter.SplitterMoved +=new SplitterEventHandler(OnSplitterMoved);
				m_splitter.MinExtra =0; // min size of right pane
				m_splitter.MinSize = 40; // min size of left pane.
				m_splitter.Dock = DockStyle.Left;
				m_splitter.Visible = true;
				//m_splitter.BorderStyle = BorderStyle.FixedSingle;
				m_splitter.BackColor = Color.LightGray;
				m_splitter.AccessibilityObject.Name = "Splitter";	// set accessibility object name

				m_rightPane = new SliceControlContainer(this);
				m_rightPane.Dock = DockStyle.Fill;
				m_rightPane.Name = "DataTree:RightPane";
				m_rightPane.AccessibilityObject.Name = "DataTree:RightPane";
				// If the RIGHT pane needs layout, the DIAGRAM pane's layout method needs to be called; it has
				// all the smarts.
				m_rightPane.Layout += new LayoutEventHandler(m_diagram.HandleLayout);

				this.Controls.AddRange(new Control[] {m_rightPane, m_splitter, m_diagram});
			}
			else
			{
				m_diagram.Dock = DockStyle.Fill;
				this.Controls.Add(m_diagram);
			}
			this.SliceControlContainer.Paint += new PaintEventHandler(this.HandlePaintLinesBetweenSlices);
		}

		public void OnSplitterMoved(object sender,	SplitterEventArgs e	)
		{
			PersistPreferences();
		}

		

		/// <summary>
		/// 
		/// </summary>
		protected virtual void InitializeComponent()
		{
			InitializeComponentBasic();
			try
			{
				DeepSuspendLayout();
				if (m_root != null)
					CreateSlicesFor(m_root, null, 0, 0, new ArrayList(20), new ObjSeqHashMap());
			}
			finally
			{
				DeepResumeLayout();
			}
			if(PersistenceProvder !=null)
				RestorePreferences();
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged 
		/// resources; <c>false</c> to release only unmanaged resources. 
		/// </param>
		/// -----------------------------------------------------------------------------------
		protected override void Dispose(bool disposing)
		{
			if (m_rch != null)
				HandleRecordChanges(false);		// no need to refresh record list on shutdown.
			// Added the test for main cache accessor null 3/12/04 (JT) as was observing crash
			// when it is null. Not sure why this suddenly started occurring.
			if (disposing && m_cache.MainCacheAccessor != null)
			{
				m_cache.MainCacheAccessor.RemoveNotification(this);
			}
			base.Dispose(disposing);
		}

		public void PersistPreferences()
		{
			if (PersistenceProvder != null)
				PersistenceProvder.SetInfoObject("Splitter", m_splitter.SplitPosition);
		}
		private void RestorePreferences()
		{
			//TODO: for some reason, this can be set to only a maximum of 177. should have a minimum, not a maximum.
			m_splitter.SplitPosition = (int)PersistenceProvder.GetInfoObject("Splitter", m_splitter.SplitPosition);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Refresh your contents. We try to re-use as many slices as possible, both to improve performance,
		/// and so as to preserve expansion state as much as possible.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public virtual void RefreshList()
		{
			try
			{
				DeepSuspendLayout();
				// Make a new root object...just in case it changed class.
				m_root = FDO.CmObject.CreateFromDBObject(m_root.Cache, m_root.Hvo);
				CreateSlicesFor(m_root, m_rootMode, 0, 0, new ArrayList(20), m_slices.PreviousSlices);
				m_diagram.PerformLayout();
				this.Invalidate(true); // forces all children to invalidate also
			}
			finally
			{
				DeepResumeLayout();
			}
		}

		/// <summary>
		/// This actually handles Paint for the contained control that has the slice controls in it.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="pea"></param>
		void HandlePaintLinesBetweenSlices(object sender, PaintEventArgs pea)
		{
			Graphics gr = pea.Graphics;
			UserControl uc = SliceControlContainer; // Where we're drawing.
			int width = uc.Width;
			foreach (Slice slice in m_slices)
			{
				if(slice == null)
					continue;  // shouldn't be visible
				Pen blackPen = new Pen(Color.LightGray, 1);
				Point loc = slice.Location;
				int yPos = loc.Y + slice.Height - 1;
				gr.DrawLine(blackPen, loc.X, yPos, width, yPos);
			}
		}
		/// <summary>
		/// Return the container control to which nested controls belonging to slices should be added.
		/// This is the main DataTreeDiagram if not using a splitter, and the extra right-
		/// hand pane if using one.
		/// </summary>
		public UserControl SliceControlContainer
		{
			get
			{
				if (m_fHasSplitter)
					return m_rightPane;
				else
					return m_diagram;
			}
		}
		public FDO.FdoCache Cache
		{
			get
			{
				return m_cache;
			}
		}

		/// <summary>
		/// Create slices for the specified object by finding a relevant template in the spec.
		/// </summary>
		/// <param name="obj"> The object to make slices for.</param>
		/// <param name="mode">If not null, use only templates having this mode.</param>
		/// <param name="level">level at which to put the new top-level slices</param>
		/// <param name="preceding">index after which to insert the new slice(s) in slices array.</param>
		/// <param name="path">sequence of nodes and HVOs inside which this is nested</param>
		/// <param name="reuseMap">map of key/slice combinations from a DataTree being refreshed. Exact matches may be
		/// reused, and also, the expansion state of exact matches is preserved.</param>
		/// <returns> updated insertPosition for next item after the ones inserted.</returns>
		public virtual int CreateSlicesFor(FDO.CmObject obj, string mode, int indent, int insertPosition, ArrayList path, ObjSeqHashMap reuseMap)
		{
			uint classId = (uint)obj.ClassID;
			string classname;
			XmlNodeList nodes = null;
			for( ; ; )
			{
				m_mdc.GetClassName(classId, out classname);
				if (mode != null)
				{
					nodes = m_allTemplates.SelectNodes("template[@class='" + classname + "' and @mode='" + mode + "']");
				}
				else
				{
					// Review JohnH: will this correctly allow mode to be missing as well as empty?
					nodes = m_allTemplates.SelectNodes("template[@class='" + classname + "' and @mode='']");
					if (nodes.Count == 0)
						nodes = m_allTemplates.SelectNodes("template[@class='" + classname + "' and not(@mode)]");
				}
				if (nodes.Count > 0)
					break;
				// Otherwise try superclass.
				m_mdc.GetBaseClsId(classId, out classId);
				if (classId == 0)
					throw new ApplicationException("No matching template found for class " + classname);
			}
			Debug.Assert(nodes != null
				&& nodes.Count == 1, "Loop should have found one or thrown exception, and we don't allow more than one.");
			XmlNode template = nodes[0];
			path.Add(template);
			insertPosition = ApplyTemplate(obj, template, indent, insertPosition, path, reuseMap);
			path.RemoveAt(path.Count - 1);
			return insertPosition;
		}



		/// <summary>
		/// A rather inefficient way of finding the ID of the class that has a particular name.
		/// IFwMetaDataCache should be enhanced to provide this efficiently.
		/// </summary>
		/// <param name="mdc"></param>
		/// <param name="stClassName"></param>
		/// <returns>ClassId, or 0 if not found.</returns>
		public static int GetClassId(IFwMetaDataCache mdc, string stClassName)
		{
			return (int) mdc.GetClassId(stClassName);
			//			int cClasses = mdc.get_ClassCount();
			//			ArrayPtr rgclid = new ArrayPtr(cClasses * Marshal.SizeOf(typeof(uint)));
			//			mdc.GetClassIds(cClasses, rgclid);
			//			System.Array classes = MarshalEx.NativeToArray(rgclid, cClasses, typeof(uint));
			//			foreach (uint clsid in classes)
			//			{
			//				string stClassNameT;
			//				mdc.GetClassName(clsid, out stClassNameT);
			//				if (stClassNameT == stClassName)
			//					return (int) clsid;
			//			}
			//			return 0;
		}

		/// <summary>
		/// Look for a reusable slice that matches the current path. If found, remove from map and return;
		/// otherwise, return null.
		/// </summary>
		protected Slice GetMatchingSlice(ArrayList path, ObjSeqHashMap reuseMap)
		{
			IList list = reuseMap[(IList)path];
			if (list.Count > 0)
			{
				Slice slice = (Slice) list[0];
				reuseMap.Remove(path, slice);
				return slice;
			}
			return null;
		}
		public enum NodeTestResult : int
		{
			kntrSomething, // really something here we could expand
			kntrPossible, // nothing here, but there could be
			kntrNothing // nothing could possibly be here, don't show collapsed OR expanded.
		}
		
		/// <summary>
		/// 
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="template"></param>
		/// <param name="indent"></param>
		/// <param name="insertPosition"></param>
		/// <param name="path">sequence of nodes and HVOs inside which this is nested</param>
		/// <param name="reuseMap">map of key/slice combinations from a DataTree being refreshed. Exact matches may be
		/// reused, and also, the expansion state of exact matches is preserved.</param>
		/// <returns> updated insertPosition for next item after the ones inserted.</returns>
		public int ApplyTemplate(FDO.CmObject obj, XmlNode template, int indent, int insertPosition, ArrayList path, ObjSeqHashMap reuseMap)
		{
			NodeTestResult ntr;
			return ApplyTemplate(obj, template, indent, insertPosition, path, reuseMap, false, out ntr);
		}

		/// <summary>
		/// This is the guts of ApplyTemplate, but it has extra arguments to allow it to be used both to actually produce
		/// slices, and just to query whether any slices will be produced. 
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="template"></param>
		/// <param name="indent"></param>
		/// <param name="insertPosition"></param>
		/// <param name="path"></param>
		/// <param name="reuseMap"></param>
		/// <param name="fTestOnly"></param>
		/// <param name="fGotAnything"></param>
		/// <returns></returns>
		protected virtual int ApplyTemplate(FDO.CmObject obj, XmlNode template, int indent, int insertPosition, ArrayList path, ObjSeqHashMap reuseMap,
			bool isTestOnly, out NodeTestResult testResult)
		{
			int insPos = insertPosition;
			testResult = NodeTestResult.kntrNothing;

			foreach (XmlNode node in template.ChildNodes)
			{
				if (node.GetType() == typeof(XmlComment))
					continue;
				testResult = ProcessTemplateNode(node, path, reuseMap, obj, indent, ref insPos,
					isTestOnly);
				//if we're just looking to see if there would be any slices, and there was,
				//then don't bother thinking about any more slices.
				if (isTestOnly && testResult != NodeTestResult.kntrNothing)
					return insertPosition;
			}

			//TODO: currently, we are making a custom fields show up all over the place... i.e.,
			//	the initial algorithm here (show the custom fields for a class whenever we are applying a template of that class)
			//		has turned out to be too simplistic, since apparently we and templates of a given class multiple times
			//		to show different parts of the class.
			if(template.Name == "template")
				testResult = AddCustomFields(obj, template, indent, ref insPos, path, reuseMap,isTestOnly);

			return insPos;
		}


		/// <summary>
		/// Automatically insert slices for the custom fields of this class
		/// </summary>
		private NodeTestResult AddCustomFields(FDO.CmObject obj, XmlNode template, int indent, ref int insertPosition, ArrayList path, ObjSeqHashMap reuseMap,
			bool isTestOnly)
		{
			NodeTestResult testResult=NodeTestResult.kntrNothing;

			//TODO: we should cache this list of fields;that is easy enough, the trick is, how do we know to reload it
			//after the user has added/changed a custom field?

			ArrayList fields = FDO.FieldDescription.FieldDescriptors(m_cache);

			//for each custom field, we need to construct or reuse the kind of XmlNode that would normally be found in the XDE file
			foreach (FDO.FieldDescription field in fields)
			{
				if (field.IsCustomField)
				{
					if (field.Class == obj.ClassID) //TODO: we should show it if the custom field is on a superclass, as well.
					{
						//Here we look in the document to see if we have already added a matching node,
						//we want to reuse it if we can, not just because of space, but also so that
						//slices can be reused, since their reuse is based in part on the identity of the node.

						//TODO: is this caching really working? That is, when we do a "view:refresh",
						//	are we ever finding the correct node in this document already?

						//TODO:the XPATH here will need to match not only the attribute, but, eventually,
						//also make sure that any fields that the user could change after creating the custom field.
						//Until we do that, if the user makes a change to one of these fields (e.g. user label),
						//the change will not be reflected in the dataTree.
						XmlNode node = m_autoCustomFieldNodesDocRoot.SelectSingleNode("node[@classId='"+obj.ClassID.ToString() +"' and @attr='"+field+ "']");
						if (node == null)
							node = m_autoCustomFieldNodesDocRoot.AppendChild(MakeCustomFieldNode(m_autoCustomFieldNodesDocument, field));

						testResult = ProcessTemplateNode(node, path, reuseMap, obj, indent, ref insertPosition,
							isTestOnly);
						//if we're just looking to see if there would be any slices, and there was,
						//then don't bother thinking about any more slices.
						if (isTestOnly && testResult != NodeTestResult.kntrNothing)
							return testResult;
					}
				}
			}
			return testResult;
		}

		private XmlNode MakeCustomFieldNode(XmlDocument document, FDO.FieldDescription field)
		{
			XmlNode node = document.CreateElement("node");
			AddAttribute(node, "attr", field.Name);//e.g. "custom", "custom1", "custom2"
			AddAttribute(node, "classId", field.Class.ToString());
			AddAttribute(node, "label", field.Userlabel);

			string strWs = "";
			string strEditor = "";
			switch(field.WsSelector)
			{
				case LanguageProject.kwsAnal:
					strWs = "analysis";
					strEditor = "string";
					break;
				case LanguageProject.kwsVern:
					strWs = "vernacular";
					strEditor = "string";
					break;
				case LanguageProject.kwsVerns:
					strWs = "all vernacular";
					strEditor = "multistring";
					break;
				case LanguageProject.kwsAnals:
					strWs = "all analysis";
					strEditor = "multistring";
					break;
				case LanguageProject.kwsAnalVerns:
					strWs = "analysis vernacular";
					strEditor = "multistring";
					break;
				case LanguageProject.kwsVernAnals:
					strWs = "vernacular analysis";
					strEditor = "multistring";
					break;
			}
			AddAttribute(node, "editor", strEditor);
			AddAttribute(node, "ws", strWs);
			return node;
		}

		private void AddAttribute(XmlNode node, string name, string value)
		{
			XmlAttribute attribute= node.OwnerDocument.CreateAttribute(name);
			attribute.Value=value;
			node.Attributes.Append(attribute);
		}

		/// <summary>
		/// Handle one (non-comment) child node of a template (or other node) being used to create slices.
		/// Update insertPosition to indicate how many were added (it also specifies where to add).
		/// If fTestOnly is true, do not update insertPosition, just return true if any slices would be
		/// created.
		/// </summary>
		/// <param name="node"></param>
		/// <param name="path"></param>
		/// <param name="reuseMap"></param>
		/// <param name="obj"></param>
		/// <param name="indent"></param>
		/// <param name="insertPosition"></param>
		/// <param name="fTestOnly"></param>
		/// <returns></returns>
		private NodeTestResult ProcessTemplateNode(XmlNode node, ArrayList path, ObjSeqHashMap reuseMap,
			FDO.CmObject obj, int indent, ref int insertPosition, bool fTestOnly)
		{
			string editor = XmlUtils.GetOptionalAttributeValue(node, "editor");

			try
			{
				if(editor != null)
					editor = editor.ToLower();
				string attrName = XmlUtils.GetOptionalAttributeValue(node, "attr");
				int flid = 0;
				if (attrName != null)
				{
					flid = (int)m_mdc.GetFieldId2((uint)obj.ClassID, attrName, true);
					if (flid == 0)
						throw new ApplicationException("DataTree could not find the flid for attribute '" + attrName+"' of class '"+obj.ClassID+"'.");
				}

				if ((m_sliceFilter != null) && !m_sliceFilter.IncludeSlice(node, obj, flid))
					return NodeTestResult.kntrNothing;

				switch (node.Name)
				{
					default:
						break; // Nothing to do for unrecognized one, such as deParams.
					case "node":
					{
						return AddSimpleNode(path, node, reuseMap, editor, flid, obj, indent, ref insertPosition, fTestOnly);
					}
					case "seq":
					{
						return AddSeqNode(path, node, reuseMap, editor, flid, obj, indent, ref insertPosition, fTestOnly);
					}
//					case "backseq":
//					{
//						return AddBackSeqNode(path, node, reuseMap, editor, obj, indent, ref insertPosition, fTestOnly);
//					}
					case "atomic": 
					{
						return AddAtomicNode(path, node, reuseMap, editor, flid, obj, indent, ref insertPosition, fTestOnly);
					}
					case "if":
					{
						if (XmlVc.ConditionPasses(node, obj.Hvo, m_cache))
						{
							NodeTestResult ntr;
							insertPosition = ApplyTemplate(obj, node, indent, insertPosition, path, reuseMap, fTestOnly, out ntr);
							if (fTestOnly && ntr != NodeTestResult.kntrNothing)
								return ntr;
						}
						break;
					}
					case "choice":
					{
						foreach (XmlNode clause in node.ChildNodes)
						{
							if (clause.Name == "where")
							{
								if (XmlVc.ConditionPasses(clause, obj.Hvo, m_cache))
								{
									NodeTestResult ntr;
									insertPosition = ApplyTemplate(obj, clause, indent, insertPosition, path, reuseMap, true, out ntr);
									if (fTestOnly && ntr != NodeTestResult.kntrNothing)
										return ntr;
								}
								break;
							}
							else if (clause.Name == "otherwise")
							{
								// enhance: verify last node?
								NodeTestResult ntr;
								insertPosition = ApplyTemplate(obj, clause, indent, insertPosition, path, reuseMap, true, out ntr);
								if (fTestOnly && ntr != NodeTestResult.kntrNothing)
									return ntr;
								break;
							}
							else
							{
								throw new Exception("elements in choice must be 'where' or 'otherwise'.");
							}
						}
						break;
					}
					case "RecordChangeHandler":
					{
						string assemblyPath = XmlUtils.GetManditoryAttributeValue(node,
							"assemblyPath");
						System.Reflection.Assembly assembly = null;
						try
						{
							string baseDir = Path.GetDirectoryName(System.Reflection.Assembly.
								GetExecutingAssembly().CodeBase).Substring(6);
							assembly = System.Reflection.Assembly.LoadFrom(
								Path.Combine(baseDir, assemblyPath));
						}
						catch (Exception error)
						{
							throw new RuntimeConfigurationException(
								"DataTree could not find the DLL at " + assemblyPath,
								error);
						}
						m_classNameRCH = XmlUtils.GetManditoryAttributeValue(node, "class");
						m_typeRCH = null;
						try
						{
							m_typeRCH = assembly.GetType(m_classNameRCH);
						}
						catch (Exception error)
						{
							throw new RuntimeConfigurationException(
								"DataTree could not find the class called " + m_classNameRCH,
								error);
						}
						try
						{
							System.Type[] types = new System.Type[0];
							System.Reflection.ConstructorInfo ci = m_typeRCH.GetConstructor(
								types);
							object[] parameters = new object[0];
							m_rch = ci.Invoke(parameters);
						}
						catch (Exception error)
						{
							throw new RuntimeConfigurationException(
								"DataTree could not create an object of the class " +
								m_classNameRCH, error);
						}
						Debug.Assert(m_rch != null);
						try
						{
							string listName = XmlUtils.GetOptionalAttributeValue(node,
								"listName");
							IRecordListUpdater rlu = null;
							if (listName != null)
							{
								// Find the first parent IRecordListOwner object (if any) that
								// owns an IRecordListUpdater.
								IRecordListOwner rlo = null;
								Control par = this.Parent as Control;
								while (par != null)
								{
									rlo = par as IRecordListOwner;
									if (rlo != null)
									{
										rlu = rlo.FindRecordListUpdater(listName);
										if (rlu != null)
											break;
									}
									par = par.Parent as Control;
								}
							}
							System.Reflection.MethodInfo mi = m_typeRCH.GetMethod("Setup");
							object[] parameters = new object[2];
							parameters[0] = obj;
							parameters[1] = rlu;
							mi.Invoke(m_rch, parameters);
						}
						catch (Exception error)
						{
							throw new RuntimeConfigurationException(
								"DataTree could not invoke the Setup method of the class " + 
								m_classNameRCH, error);
						}
						return NodeTestResult.kntrNothing;
					}
				}
			}
			catch (Exception error)
			{
				string s = "FieldWorks ran into a problem trying to display this object";

				s += " in DataTree::ApplyTemplate: " + error.Message;
				s += "\r\nThe object id was " + obj.Hvo.ToString() + ".";
				if (editor != null)
					s += " The editor was '" + editor + "'.\r\n";
				s += " The text of the current node was " + node.OuterXml;

				//now send it on
				throw new ApplicationException(s, error);
			}
			return NodeTestResult.kntrNothing; // other types of child nodes, for example, parameters for jtview, don't even have the potential for expansion.
		}

		private NodeTestResult AddAtomicNode(ArrayList path, XmlNode node, ObjSeqHashMap reuseMap, string editor, int flid, FDO.CmObject obj, int indent, ref int insertPosition, bool fTestOnly)
		{
			// Facilitate insertion of an expandable tree node representing an owned or ref'd object.
			if (flid == 0)
				throw new ApplicationException("attr attribute required for atomic properties " + node.OuterXml);
			CmObject innerObj = obj.GetObjectInAtomicField(flid);
			m_monitoredProps.Add(new IntPair(obj.Hvo, flid));
			if (fTestOnly)
				return innerObj != null ?  NodeTestResult.kntrSomething : NodeTestResult.kntrPossible; // Review JohnT: is it possible for CreateFromDBObject to produce no slices?
			path.Add(node);
			string mode = XmlUtils.GetOptionalAttributeValue(node, "mode");
			if(innerObj != null)
			{
				path.Add(innerObj.Hvo);
				insertPosition = CreateSlicesFor(FDO.CmObject.CreateFromDBObject(m_cache, innerObj.Hvo),
					mode, indent, insertPosition, path, reuseMap);
				path.RemoveAt(path.Count - 1);
			}
			path.RemoveAt(path.Count - 1);
			return NodeTestResult.kntrNothing; 
		}
//
//		/// ------------------------------------------------------------------------------------
//		/// <summary>
//		/// Adds a node that accesses the back reference of an object.
//		/// </summary>
//		/// <param name="path"></param>
//		/// <param name="node"></param>
//		/// <param name="reuseMap"></param>
//		/// <param name="editor"></param>
//		/// <param name="dstObj"></param>
//		/// <param name="indent"></param>
//		/// <param name="insertPosition"></param>
//		/// <param name="fTestOnly"></param>
//		/// <returns></returns>
//		/// ------------------------------------------------------------------------------------
//		private NodeTestResult AddBackSeqNode(ArrayList path, XmlNode node, ObjSeqHashMap reuseMap, 
//			string editor, CmObject dstObj, int indent, ref int insertPosition, bool fTestOnly)
//		{
//			BackRefSeqVirtualHandler handler = new BackRefSeqVirtualHandler(node, m_cache);
//			handler.ClassName = "CmAnnotation";
//			handler.FieldName = "SubAnnotations";
//			m_cache.InstallVirtualProperty(handler);
//			int flid = handler.Tag;
//
//			int cobj = m_cache.GetVectorSize(dstObj.Hvo, flid);
//			// monitor it even if we're testing: result may change.
//			m_monitoredProps.Add(new IntPair(dstObj.Hvo, flid));
//			if (fTestOnly)
//				return cobj > 0 ? NodeTestResult.kntrSomething : NodeTestResult.kntrPossible;
//			path.Add(node);
//			string mode = XmlUtils.GetOptionalAttributeValue(node, "mode");
//			if (cobj < 15)
//			{
//				//Create slices immediately
//				foreach (int hvo in m_cache.GetVectorProperty(dstObj.Hvo, flid))
//				{
//					path.Add(hvo);
//					insertPosition = CreateSlicesFor(CmObject.CreateFromDBObject(m_cache, hvo), mode, indent, insertPosition, path, reuseMap);
//					path.RemoveAt(path.Count - 1);
//				}
//			}
//			else
//			{
//				// Create a dummy...this has the effect of making it lazy. For now it also means
//				// that slices within the sequence won't get reused, and therefore manual opening
//				// of subtrees won't be remembered, within a sequence.
//				DummyObjectSlice dos = new DummyObjectSlice(this, indent, node, (ArrayList)(path.Clone()),
//					dstObj, flid, 0);
//				dos.Cache = m_cache;
//				int chvo = m_cache.GetVectorSize(dstObj.Hvo, flid);
//				DummyObjectSlice[] dummyslices = new DummyObjectSlice[chvo];
//				for (int i = 0; i < chvo; i++)
//					dummyslices[i] = dos;
//				m_slices.InsertRange(insertPosition, dummyslices);
//				insertPosition += chvo;
//			}
//			path.RemoveAt(path.Count - 1);
//			return NodeTestResult.kntrNothing; 
//		}

		private NodeTestResult AddSeqNode(ArrayList path, XmlNode node, ObjSeqHashMap reuseMap, string editor, int flid, FDO.CmObject obj, int indent, ref int insertPosition, bool fTestOnly)
		{
			if (flid == 0)
				throw new ApplicationException("attr attribute required for seq properties " + node.OuterXml);
			int cobj = m_cache.GetVectorSize(obj.Hvo, flid);
			// monitor it even if we're testing: result may change.
			m_monitoredProps.Add(new IntPair(obj.Hvo, flid));
			if (fTestOnly)
				return cobj > 0 ? NodeTestResult.kntrSomething : NodeTestResult.kntrPossible;
			path.Add(node);
			string mode = XmlUtils.GetOptionalAttributeValue(node, "mode");
			if (cobj < 15)
			{
				//Create slices immediately
				foreach (int hvo in m_cache.GetVectorProperty(obj.Hvo, flid))
				{
					path.Add(hvo);
					insertPosition = CreateSlicesFor(FDO.CmObject.CreateFromDBObject(m_cache, hvo), mode, indent, insertPosition, path, reuseMap);
					path.RemoveAt(path.Count - 1);
				}
			}
			else
			{
				// Create a dummy...this has the effect of making it lazy. For now it also means
				// that slices within the sequence won't get reused, and therefore manual opening
				// of subtrees won't be remembered, within a sequence.
				DummyObjectSlice dos = new DummyObjectSlice(this, indent, node, (ArrayList)(path.Clone()),
					obj, flid, 0);
				dos.Cache = m_cache;
				int chvo = m_cache.GetVectorSize(obj.Hvo, flid);
				DummyObjectSlice[] dummyslices = new DummyObjectSlice[chvo];
				for (int i = 0; i < chvo; i++)
					dummyslices[i] = dos;
				m_slices.InsertRange(insertPosition, dummyslices);
				insertPosition += chvo;
			}
			path.RemoveAt(path.Count - 1);
			return NodeTestResult.kntrNothing; 
		}

		private NodeTestResult AddSimpleNode(ArrayList path, XmlNode node, ObjSeqHashMap reuseMap, string editor, int flid, FDO.CmObject obj, int indent, ref int insertPosition, bool fTestOnly)
		{
			if (fTestOnly)
				return NodeTestResult.kntrSomething; // nodes always produce something.
			
			path.Add(node);
			Slice slice = GetMatchingSlice(path, reuseMap);
			if (slice == null)
			{
				slice = SliceFactory.Create(m_cache, editor, flid, node, obj, StringTbl, PersistenceProvder);
				Debug.Assert(slice != null);
				// Set the label
				slice.Label = XmlUtils.GetOptionalAttributeValue(node, "label");
				// Install new item at appropriate position and level.
				slice.Indent = indent;
				slice.Object = obj;
				slice.Cache = m_cache;
				slice.Mediator = m_mediator;


				// We need a copy since we continue to modify path, so make it as compact as possible.
				slice.Key = path.ToArray();
				slice.ConfigurationNode = node;
				slice.OverrideBackColor(XmlUtils.GetOptionalAttributeValue(node, "backColor"));

				slice.ShowContextMenu += new TreeNodeEventHandler(this.ShowSliceContextMenu);
				slice.SmallImages = SmallImages;
				slice.FinishInit();

				RegisterWithContextHelp(slice, node);
			}
			m_slices.Insert(insertPosition, slice);
			insertPosition++;
			// If node has children, figure what to do with them...
			XmlNodeList children = node.ChildNodes;
			if (children.Count > 0)
			{
				// A newly created slice is always in state ktisFixed, but that is not appropriate if it
				// has children. However, a node which notionally has children may in fact have nothing to
				// show, perhaps because a sequence is empty. First evaluate this, and if true, set it
				// to ktisCollapsedEmpty.
				NodeTestResult ntr;
				ApplyTemplate(obj, node, indent + 1, insertPosition, path, reuseMap, true, out ntr);
				if (ntr == NodeTestResult.kntrNothing)
					slice.Expansion = DataTree.TreeItemState.ktisFixed; // probably redundant, but play safe
				else if (ntr == NodeTestResult.kntrPossible)
				{
					// It could have children but currently can't: we always show this as collapsedEmpty.
					slice.Expansion = DataTree.TreeItemState.ktisCollapsedEmpty;
				}
					// Remaining branches are for a node that really has children.
				else if (slice.Expansion == DataTree.TreeItemState.ktisCollapsed)
				{
					// Reusing a node that was collapsed (and it has something to expand):
					// leave it that way (whatever the spec says).
				}
				else if (slice.Expansion == DataTree.TreeItemState.ktisExpanded
					|| XmlUtils.GetOptionalAttributeValue(node, "expansion") == "expanded"
					|| slice.Expansion == DataTree.TreeItemState.ktisCollapsedEmpty)
				{
					// Either re-using a node that was expanded, or the spec says to auto-expand,
					// or a node that was previously empty now has real children, probably a first object
					// that was just added that the user wants to see:
					// fill in the children.
					slice.Expansion = DataTree.TreeItemState.ktisExpanded;
					insertPosition = ApplyTemplate(obj, node, indent + 1, insertPosition, path, reuseMap);
				}
				else 
				{
					// Either a new node or one previously collapsedEmpty. But it now definitely has children,
					// so neither of those states is appropriate. And we've covered all the cases where it
					// ought to be expanded. So show it as collapsed.
					slice.Expansion = DataTree.TreeItemState.ktisCollapsed;
				}
			} // else can't have children, leave in default ktisFixed state.
			path.RemoveAt(path.Count - 1);
			
			return NodeTestResult.kntrNothing; 
		}

		private void RegisterWithContextHelp(Slice slice, XmlNode configuration)
		{
			slice.RegisterWithContextHelper();
			//			if (slice.Control != null)//grouping nodes do not have a control
			//			{
			//				string id=XmlUtils.GetAttributeValue(configuration,"id");
			//
			//				//if the idea has not been added, try using the "attr" attribute as the key
			//				if (null==id)
			//					id=XmlUtils.GetAttributeValue(configuration,"attr");
			//				//It's OK to send null as an id
			//				m_mediator.SendMessage("RegisterHelpTargetWithId", new object[]{slice.Control, id});
			//			}
		}

		/// <summary>
		/// Invoked by a slice when the user does something to bring up a context menu
		/// </summary>
		public void ShowSliceContextMenu(object sender, TreeNodeEventArgs e)
		{
			//just pass this onto, for example, the XWorks View that owns us,
			//assuming that it has subscribed to this event on this object.
			//If it has not, then this will still point to the "auto menu handler"
			Debug.Assert(ShowContextMenu!= null, "this should always be set to something");
			ShowContextMenu(sender, e);
		}

		/// <summary>
		/// this is called by a client which normally provides its own custom menu, in order to allow it to
		/// fall back on an auto menu during development, before the custom menu has been defined.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void InvokeAutoMenu (object sender, SIL.FieldWorks.Common.Framework.TreeForms.TreeNodeEventArgs e)
		{
			m_autoHandler.ShowSliceContextMenu(sender, e);
		}

		/// <summary>
		/// Set the handler which will be invoked when the user right-clicks on the
		/// TreeNode portion of a slice, or in some other way invokes the context menu.
		/// </summary>
		/// <param name="handler"></param>
		public void SetContextMenuHandler(TreeNodeEventHandler handler)
		{
			//note the = instead of += we do not want more than 1 handler trying to open the context menu!
			//you could try changing this if we wanted to have a fall back handler, and if there
			//was some way to get the first handler to be able to say "don't pass on this message" 
			//when it handled the menu display itself.
			ShowContextMenu = handler;
		}


		/// <summary>
		/// Calls ApplyTemplate for each child of the argument node.
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="template"></param>
		/// <param name="indent"></param>
		/// <param name="insertPosition"></param>
		/// <param name="path"></param>
		/// <param name="reuseMap"></param>
		/// <returns></returns>
		public int ApplyChildren(FDO.CmObject obj, XmlNode template, int indent, int insertPosition, ArrayList path, ObjSeqHashMap reuseMap)
		{
			int insertPos = insertPosition;
			foreach (XmlNode node in template.ChildNodes)
			{
				if (node.Name == "ChangeRecordHandler")
					continue;	// Handle only at the top level (at least for now).
				insertPos = ApplyTemplate(obj, node, indent, insertPos, path, reuseMap);
			}
			return insertPos;
		}

		/// <summary>
		/// See diagram method for details.
		/// </summary>
		/// <param name="nInd"></param>
		/// <param name="iStart"></param>
		/// <returns></returns>
		public int NextFieldAtIndent(int nInd, int iStart)
		{
			return m_diagram.NextFieldAtIndent(nInd, iStart);
		}	

		public int PrevFieldAtIndent(int nInd, int iStart)
		{
			return m_diagram.PrevFieldAtIndent(nInd, iStart);
		}
		// Must be overridden if nulls will be inserted into items; when real item is needed,
		// this is called to create it.
		public virtual Slice MakeEditorAt(int i)
		{
			return null; // todo JohnT: return false;
		}
		// Get or create the real slice at index i.
		public Slice FieldAt(int i)
		{
			Slice slice = FieldOrDummyAt(i);
			// Keep trying until we get a real slice. It's possible, for example, that the first object
			// in a sequence expands into an embedded lazy sequence, which in turn needs to have its
			// first item made real.
			while (!slice.IsRealSlice)
			{
				m_diagram.AboutToCreateField();
				slice.BecomeReal(i);
				if (i >= m_slices.Count)
				{
					// BecomeReal produced nothing; range has decreased!
					return null;
				}
				// Make sure something changed; otherwise, we have an infinite loop here.
				Debug.Assert(slice != m_slices[i]);
				slice = (Slice)(m_slices[i]);
			}
			return slice;
		}
		/// <summary>
		/// This version expands nulls but not dummy slices. Dummy slices
		/// should know their indent.
		/// </summary>
		/// <param name="i"></param>
		/// <returns></returns>
		public Slice FieldOrDummyAt(int i)
		{
			Slice slice = Slices[i];
			if (slice == null)
			{
				m_diagram.AboutToCreateField();
				slice = MakeEditorAt(i);
				m_slices[i] = slice;
			}
			return slice;
		}


		#region automated tree navigation

		/// <summary>
		/// Moves the focus to the first visible slice in the tree
		/// </summary>
		public void GotoFirstSlice()
		{
			GotoNextSliceAfterIndex(-1);
		}

		public Slice LastSlice
		{
			get
			{
				if (m_slices.Count == 0)
					return null;
				return (Slice)m_slices[m_slices.Count-1];
			}
		}

		/// <summary>
		/// Moves the focus to the next visible slice in the tree
		/// </summary>
		public void GotoNextSlice()
		{
			GotoNextSliceAfterIndex(m_slices.IndexOf(CurrentSlice));
		}

		private void GotoNextSliceAfterIndex(int index)
		{
			++index;
			if(index >= m_slices.Count)
				return;
			((Slice)m_slices[index]).TakeFocus();
			//			while ((m_slices.Count-1) >= index)
			//			{
			//				if(((Slice)m_slices[index]).TakeFocus())
			//					break;
			//				++index;
			//			}
		}
		
		/// <summary>
		/// Moves the focus to the previous visible slice in the tree
		/// </summary>
		public void GotoPreviousSlice()
		{
			int index = m_slices.IndexOf(CurrentSlice) -1;
			if(index < 0)
				return;
			((Slice)m_slices[index]).TakeFocus();
			//			while (index >= 0)
			//			{
			//				if(((Slice)m_slices[index]).TakeFocus())
			//					break;
			//				--index;
			//			}
		}	
		#endregion

	}

	/// <summary>
	/// DataTreeDiagram represents the left half (tree diagram) of a DataTree.
	/// </summary>
	public class DataTreeDiagram : System.Windows.Forms.UserControl
	{
		protected DataTree m_parent;
		protected int m_dxpLastRightPaneWidth = -1;  // width of right pane (if any) the last time we did a layout.
		public enum PaintStates : byte
		{
			kpsNotInPaint, // OnPaint is not executing
			kpsChecking, // OnPaint is checking that all slices are visible.
			kpsLayoutSuspended, // Had to create a new field and suspend layout during paint.
		}
		PaintStates m_ps = PaintStates.kpsNotInPaint;
		public DataTreeDiagram(DataTree parent)
		{
			m_parent = parent;
			this.Layout += new LayoutEventHandler(this.HandleLayout);
		}
		public Slice this [int index]   // indexer declaration
		{
			get 
			{
				return m_parent.Slices[index];
			}
		}



		/// <summary>
		/// Intended to be called by Datatree.FieldAt just before it creates a new slice.
		/// </summary>
		internal void AboutToCreateField()
		{
			if (m_ps == PaintStates.kpsChecking)
			{
				SuspendLayout();
				m_ps = PaintStates.kpsLayoutSuspended;
			}
		}

		protected internal void HandleLayout(object sender, LayoutEventArgs ea)
		{
			// We need to force a layout if the width of the right pane changes, because the automatic
			// code assumes this pane is not affected, and it is (e.g., if the nested forms are a
			// different height after being laid out). However, if the user changes the vertical size
			// of the main window, we will get two layout events, one produced automatically for
			// our own size changing, and one because the rigth pane changed. This check may allow us
			// to avoid performing the layout twice in that situation.
			UserControl rightPane = this.m_parent.m_rightPane;
			if (rightPane != null)
			{
				if (sender == rightPane && rightPane.Width == this.m_dxpLastRightPaneWidth)
					return;
				m_dxpLastRightPaneWidth = rightPane.Width;
			}
			int dypOldHeight = m_parent.AutoScrollMinSize.Height;

			Rectangle clipRect = m_parent.ClientRectangle;
			clipRect.Offset(-m_parent.AutoScrollPosition.X, -m_parent.AutoScrollPosition.Y);
			int yTop = HandleLayout1(true, clipRect);
			if (yTop != m_parent.AutoScrollMinSize.Height)
			{
				this.m_parent.AutoScrollMinSize = new Size(0, yTop);
				// If we don't do this, the system thinks only the previously hidden part of the
				// right pane was affected, whereas all of it may have been if control heights
				// changed.
				// (I suppose there could be a pathological case where two slices changed heigtht
				// by opposite amounts and we need this redraw even though the height did not change,
				// but it seems very unlikely.)
				if (rightPane != null)
					rightPane.Invalidate();
			}
			return;
		}

		/// <summary>
		/// Used both by main layout routine and also by OnPaint to make sure all
		/// visible slices are real. For full layout, clipRect is meaningless.
		/// </summary>
		/// <param name="clipRect"></param>
		/// <returns></returns>
		protected internal int HandleLayout1(bool fFull, Rectangle clipRect)
		{
			int yTop = 0;
			// For now arbitrary fixed position for children; Enhance JohnT: make each child position/width
			// dependent on indent if no splitter.
			int xLeft = 0; // used if slice controls are in own pane and can take its full width.
			int dxpItemWidth = 0; // never used but make compiler happy.
			if (m_parent.m_fHasSplitter)
				dxpItemWidth = m_parent.m_rightPane.Width; // ditto
			int minHeight = GetMinFieldHeight();
			Point oldPos = m_parent.AutoScrollPosition;
			for (int i = 0; i < m_parent.Slices.Count; i++)
			{
				// Don't care about items below bottom of clip, if one is specified.
				if ((!fFull) && yTop >= clipRect.Bottom)
				{
					return yTop; // not very meaningful in this case, but a result is required.
				}
				Slice tci;
				if (fFull || yTop + minHeight <= clipRect.Top)
					// We can allow slice to be null; either we don't have a clip rect,
					// or this slice (if null) would be above the top of it.
					tci = m_parent.Slices[i];
				else
				{
					// We must make sure it's a real slice; it's visible.
					tci = m_parent.FieldAt(i);
				}
				if (tci == null)
				{
					yTop += minHeight;
				}
				else
				{
					if (!m_parent.m_fHasSplitter)
					{
						// align the left of the control to match the tree diagram.
						xLeft = tci.LabelIndent();
						dxpItemWidth = this.Width - xLeft;
					}
					tci.Location = new Point(xLeft, yTop);
					yTop += tci.SetWidthAndGetHeight(dxpItemWidth);
				}
			}
			// If making phony slices real somehow altered the scroll position, for example as the
			// silly Panel tries to make the selected control visible, put it back!
			if (m_parent.AutoScrollPosition != oldPos)
				m_parent.AutoScrollPosition = new Point(-oldPos.X, -oldPos.Y);
			return yTop;
		}

		public int GetMinFieldHeight()
		{
			return 18; // Enhance Johnt: base on default font height
		}
		//
		//	Return the next field index that is at the specified indent level, or zero if there are no
		//	fields following this one that are at the specified level in the tree (at least not before one
		//  at a higher level). This is normally
		//	used to find the beginning of the next subrecord when we have a sequence of subrecords,
		//	and possibly sub-subrecords, with some being expanded and others not.
		//	@param nInd The indent level we want.
		//	@param idfe An index to the current field. We start looking at the next field.
		//	@return The index of the next field or 0 if none.
		public int NextFieldAtIndent(int nInd, int iStart)
		{
			int cItem = m_parent.Slices.Count;

			// Start at the next editor and work down, skipping more nested editors.
			for (int i =iStart + 1; i < cItem; ++i)
			{
				int nIndCur = m_parent.FieldOrDummyAt(i).Indent;
				if (nIndCur == nInd) // We found another item at this level, so return it.
					return i;
				if (nIndCur < nInd) // We came out to a higher level, so return zero.
					return 0;
			}
			return 0; // Reached the end without finding one at the specified level.
		}
		//
		//	Return the previous field index that is at the specified indent level, or zero if there are no
		//	fields preceding this one that are at the specified level in the tree (at least not before one
		//  at a higher level). This is normally used to find a parent record; some of the intermediate
		//	records may not be expanded.
		//	@param nInd The indent level we want.
		//	@param idfe An index to the current field. We start looking at the previous field.
		//	@return The index of the desired field or 0 if none.
		public int PrevFieldAtIndent(int nInd, int iStart)
		{
			// Start at the next editor and work down, skipping more nested editors.
			for (int i =iStart - 1; i >= 0; --i)
			{
				int nIndCur = m_parent.FieldOrDummyAt(i).Indent;
				if (nIndCur == nInd) // We found another item at this level, so return it.
					return i;
				if (nIndCur < nInd) // We came out to a higher level, so return zero.
					return 0;
			}
			return 0; // Reached the start without finding one at the specified level.
		}
		
		/// <summary>
		/// Answer the height that the slice at index ind is considered to have.
		/// If it is null return the default size.
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
		int HeightOfSliceOrNullAt(int iSlice)
		{
			Slice tc = m_parent.Slices[iSlice];
			int dypFieldHeight = GetMinFieldHeight();
			if (tc != null)
			{
				dypFieldHeight = Math.Max(dypFieldHeight, tc.Height);
			}	
			return dypFieldHeight;
		}

		/// <summary>
		/// Return the index of the slice which contains the given y position.
		/// </summary>
		/// <param name="yp">Measured from top of whole area scrolled over.</param>
		/// <returns>Index of requested slice (or -1 if after last slice)</returns>
		public int IndexOfSliceAtY(int yp)
		{
			int ypTopOfNextField = 0;
			for (int iSlice = 0; iSlice < m_parent.Slices.Count; iSlice++)
			{

				int dypFieldHeight = HeightOfSliceOrNullAt(iSlice);
				ypTopOfNextField += dypFieldHeight;
				if (ypTopOfNextField > yp)
				{
					return iSlice;
				}
			}
			return -1;
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			// Optimize JohnT: Could we do a binary search for the
			// slice at the top? But the chop point slices may not be real...
			m_ps = PaintStates.kpsChecking;
			HandleLayout1(false, e.ClipRectangle);
			bool fNeedResume = (m_ps == PaintStates.kpsLayoutSuspended);
			m_ps = PaintStates.kpsNotInPaint;
			if (fNeedResume)
			{
				Point oldPos = m_parent.AutoScrollPosition;
				ResumeLayout(); // will cause another paint (and may cause unwanted scroll of parent!)
				if (m_parent.AutoScrollPosition != oldPos)
					m_parent.AutoScrollPosition = new Point(-oldPos.X, -oldPos.Y);
			}
			else
				base.OnPaint(e);
		}
	}


	class DummyObjectSlice : Slice
	{
		XmlNode m_node; // Node with name="seq" that controls the sequence we're a dummy for
		ArrayList m_path; // Path of parent slice info up to and including m_node.
		int m_flid; // sequence field we're a dummy for
		int m_ihvoMin; // index in sequence of first object we stand for.

		public override int SetWidthAndGetHeight(int dxpWidth)
		{
			// Can't do anything sensible, just return minimum.
			return Container.Diagram.GetMinFieldHeight();
		}
		/// <summary>
		/// Create a slice. Note that callers that will further modify path should pass a Clone.
		/// </summary>
		/// <param name="dt"></param>
		/// <param name="indent"></param>
		/// <param name="node"></param>
		/// <param name="path"></param>
		/// <param name="obj"></param>
		/// <param name="flid"></param>
		/// <param name="ihvoMin"></param>
		public DummyObjectSlice(DataTree dt, int indent, XmlNode node, ArrayList path, CmObject obj, int flid,
			int ihvoMin)
		{
			m_indent = indent;
			m_containingDataTree = dt;
			m_node = node;
			m_path = path;
			m_obj = obj;
			m_flid = flid;
			m_ihvoMin = ihvoMin;
		}

		public override bool IsRealSlice
		{
			get {return false;}
		}

		/// <summary>
		/// Turn this dummy slice into whatever it stands for, replacing itself in the data tree's
		/// slices (where it occupies slot index) with whatever is appropriate.
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
		public override Slice BecomeReal(int index)
		{
			// We stand for slice index, and that is to be replaced. But we might stand for earlier
			// slices too: how many indicates what we have to add to m_ihvoMin.
			int ihvo = m_ihvoMin;
			for (int islice = index - 1; islice >= 0 && m_containingDataTree.Slices[islice] == this; islice--)
				ihvo++;
			string mode = XmlUtils.GetOptionalAttributeValue(m_node, "mode");
			int hvo = m_cache.GetVectorItem(m_obj.Hvo, m_flid, ihvo);
			if (ihvo == m_ihvoMin)
			{
				// made the first element real. Increment start ihvo: the first thing we are a
				// dummy for got one greater
				m_ihvoMin++;
			}
			else if (index < m_containingDataTree.Slices.Count && m_containingDataTree.Slices[index + 1] == this)
			{
				// Any occurrences after index get replaced by a new one with suitable ihvoMin.
				// Note this must be done before we insert an unknown number of extra slices
				// by calling CreateSlicesFor.
				DummyObjectSlice dosRep = new DummyObjectSlice(m_containingDataTree, m_indent, m_node, m_path,
					m_obj, m_flid, ihvo + 1);
				dosRep.Cache = this.Cache;
				for (int islice = index + 1;
					islice < m_containingDataTree.Slices.Count && m_containingDataTree.Slices[islice] == this;
					islice++)
				{
					m_containingDataTree.RawSetSlice(islice, dosRep);
				}
			}
			m_containingDataTree.Slices.RemoveRange(index, 1);

			m_path.Add(hvo);
			CmObject objItem = FDO.CmObject.CreateFromDBObject(m_containingDataTree.Cache, hvo);
			Point oldPos = m_containingDataTree.AutoScrollPosition;
			int insertPosition = m_containingDataTree.CreateSlicesFor(objItem, mode, m_indent, index, m_path,
				new ObjSeqHashMap());
			// If inserting slices somehow altered the scroll position, for example as the
			// silly Panel tries to make the selected control visible, put it back!
			if (m_containingDataTree.AutoScrollPosition != oldPos)
				m_containingDataTree.AutoScrollPosition = new Point(-oldPos.X, -oldPos.Y);
			m_path.RemoveAt(m_path.Count - 1);
			if (m_containingDataTree.Slices.Count > index)
				return m_containingDataTree.Slices[index];
			else
				return null;
		}


	}


	/// <summary>Helper class for handling automatic homograph numbering when the citation
	/// form changes.</summary>
	/// <remarks>This class is placed here instead of in SIL.FieldWorks.FDO.Ling so that we
	/// don't entangle FDO with xWorks.  This namespace was already entangled with both FDO and
	/// xWorks.</remarks>
	public class LexEntryChangeHandler : IRecordChangeHandler
	{
		/// <summary>lex entry being monitored for changes</summary>
		protected LexEntry m_le = null;
		/// <summary>original citation form</summary>
		protected string m_sOrigCitation = null;
		/// <summary>original morph type HVO</summary>
		protected int m_hvoType = 0;
		/// <summary></summary>
		protected IRecordListUpdater m_rlu = null;

		/// <summary>Default constructor, needed for reflection</summary>
		public LexEntryChangeHandler()
		{
		}

		/// <summary>Return the database id of the entry's morph type, or zero if the entry
		/// either has no allomorphs or conflicting morph types.</summary>
		private int MorphTypeHvo()
		{
			ISilDataAccess sda = m_le.Cache.MainCacheAccessor;
			int cAllo = sda.get_VecSize(m_le.Hvo, (int)LexEntry.LexEntryTags.kflidAllomorphs);
			if (cAllo == 0)
				return 0;
			int hvoAllo = sda.get_VecItem(m_le.Hvo,
				(int)LexEntry.LexEntryTags.kflidAllomorphs, 0);
			int hvoType = sda.get_ObjectProp(hvoAllo,
				(int)MoForm.MoFormTags.kflidMorphType);
			for (int i = 1; i < cAllo; ++i)
			{
				hvoAllo = sda.get_VecItem(m_le.Hvo,
					(int)LexEntry.LexEntryTags.kflidAllomorphs, i);
				int hvoType2 = sda.get_ObjectProp(hvoAllo,
					(int)MoForm.MoFormTags.kflidMorphType);
				if (hvoType2 != hvoType)
					return 0;				// conflicting types.
			}
			return hvoType;
		}
		
		/// <summary></summary>
		public void Setup(object o, IRecordListUpdater rlu)
		{
			m_le = o as LexEntry;
			Debug.Assert(m_le != null);
			m_sOrigCitation = m_le.CitationForm.VernacularDefaultWritingSystem;
			m_hvoType = MorphTypeHvo();
			m_rlu = rlu;
			if (m_rlu != null)
				m_rlu.RecordChangeHandler = this;
		}

		/// <summary>Handle possible homograph number changes:
		/// 1. Possibly remove homograph from original citation form.
		/// 2. Possibly add homograph for new citation form.
		/// </summary>
		public void Fixup(bool fRefreshList)
		{
			Debug.Assert(m_le != null);
			if (m_le.IsValidObject())
			{
				if (m_le.CitationForm.VernacularDefaultWritingSystem == m_sOrigCitation &&
					MorphTypeHvo() == m_hvoType)
				{
					return;
				}
				// We have work to do!
				// Reset any homograph numbers associated with the old citation form.
				System.Collections.ArrayList rgHomographs = m_le.CollectHomographs(m_sOrigCitation,
					0);
				LexEntry le;
				if (rgHomographs.Count == 1)
				{
					IEnumerator ieHomo = rgHomographs.GetEnumerator();
					ieHomo.MoveNext();
					le = ieHomo.Current as LexEntry;
					le.HomographNumber = 0;
				}
				else if (rgHomographs.Count > 1)
				{
					LexEntry.ValidateExistingHomographs(rgHomographs);
				}
				// Set any homograph numbers associated with the new citation form.
				rgHomographs = m_le.CollectHomographs();
				if (rgHomographs.Count != 0)
				{
					LexEntry.ValidateExistingHomographs(rgHomographs);
					m_le.HomographNumber = rgHomographs.Count + 1;
				}
				else
				{
					m_le.HomographNumber = 0;
				}
				// Fix it so that another call will do the right thing.
				m_sOrigCitation = m_le.CitationForm.VernacularDefaultWritingSystem;
				m_hvoType = MorphTypeHvo();
			}
			if (fRefreshList && m_rlu != null)
				m_rlu.UpdateList(false);
		}
	}
}
