// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: MessageSlice.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// Implements a simple Message XDE editor.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;


namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for MessageSlice.
	/// </summary>
	public class MessageSlice : Slice
	{
		/// <summary> Constructor.</summary>
		public MessageSlice(string message) : base(new Label())
		{
		 	this.Control.Text = message;
			this.Control.BackColor = System.Drawing.SystemColors.ControlLight;
		}
		/// <summary>
		/// This is passed the color that the XDE specified, if any, otherwise null.
		/// The default is to use the normal window color for editable text.
		/// Messages have a default already set in the constructor, so ignore
		/// if null.
		/// </summary>
		/// <param name="clr"></param>
		public override void OverrideBackColor(String backColorName)
		{
			if (this.Control == null)
				return;
			if (backColorName != null)
				this.Control.BackColor = Color.FromName(backColorName);
		}

		public override void Install(DataTree tc)
		{
			base.Install(tc);

			if (this.Control != null)
			{
//				this.Control.AccessibilityObject.Name = this.Label;
				this.Control.AccessibilityObject.Value = this.Control.Text;
			}
		}


		//TODO: how to figure out the correct height for this message, so that we can 
		// implement the SetWidthAndGetHeight()?
	}
}
