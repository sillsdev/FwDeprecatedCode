// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: AtomicReferenceSlice.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Xml;


using SIL.FieldWorks.Common.Controls;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.Utils;
using SIL.FieldWorks.Common.Utils;


namespace SIL.FieldWorks.Common.Framework.TreeForms
{
	/// <summary>
	/// Summary description for AtomicReferenceSlice.
	/// </summary>
	public class AtomicReferenceSlice : ReferenceSlice
	{
		/// <summary>
		/// Default Constructor.
		/// </summary>
		public AtomicReferenceSlice() : base()
		{
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="AtomicReferenceSlice"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public AtomicReferenceSlice(FdoCache cache, CmObject obj, int flid, 
			XmlNode configurationNode, SIL.Utils.IPersistenceProvider persistenceProvider,
			StringTable stringTbl)
			: base(cache, obj, flid, configurationNode, persistenceProvider, stringTbl)
		{
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="persistenceProvider"></param>
		/// <param name="stringTbl"></param>
		protected override void SetupControls(IPersistenceProvider persistenceProvider,
			StringTable stringTbl)
		{
			AtomicReferenceLauncher arl = new AtomicReferenceLauncher();
			arl.Initialize(m_cache, m_obj, m_flid, m_fieldName, persistenceProvider,
				DisplayNameProperty);
			arl.ConfigurationNode = ConfigurationNode;

			// We don't want to be visible until later, since otherwise we get a temporary
			// display in the wrong place with the wrong size that serves only to annoy the
			// user.  See LT-1518 "The drawing of the DataTree for Lexicon/Advanced Edit draws
			// some initial invalid controls."  Becoming visible when we set the width and
			// height seems to delay things enough to avoid this visual clutter.
			arl.Visible = false;
			this.Control = arl;
			arl.ViewSizeChanged += new FwViewSizeChangedEventHandler(this.OnViewSizeChanged);
			AtomicReferenceView view = (AtomicReferenceView)arl.MainControl;
			view.ViewSizeChanged += new FwViewSizeChangedEventHandler(this.OnViewSizeChanged);
		}

		/// <summary>
		/// Set the width of the item, perform any internal layout inside the item, and return
		/// its height (as in the Height property).
		/// Side effect: set height and width of SliceTreeNode.
		/// Overrides must call base method or AdjustTreeNodeSize (after adjusting this.Height).
		/// </summary>
		public override int SetWidthAndGetHeight(int dxpWidth)
		{
			//this.Control.Width = dxpWidth;
			AdjustTreeNodeSize();
			// Delaying visibility until this point avoids visual stuttering -- see the comment
			// above where we set Visible to false.
			this.Control.Visible = true;
			return Height;
		}

		/// <summary>
		/// Handle changes in the size of the underlying view.
		/// </summary>
		protected void OnViewSizeChanged(object sender, FwViewSizeEventArgs e)
		{
			// For now, just handle changes in the height.
			AtomicReferenceLauncher arl = (AtomicReferenceLauncher)this.Control;
			AtomicReferenceView view = (AtomicReferenceView)arl.MainControl;
			int hMin = m_containingDataTree.Diagram.GetMinFieldHeight();
			int h1 = view.RootBox.get_Height();
			Debug.Assert(e.Height == h1);
			int hOld = m_treeNode.Height;
			int hNew = Math.Max(h1, hMin) + 3;
			if (hNew != hOld)
			{
				m_treeNode.Height = hNew;
				arl.Height = hNew - 1;
				view.Height = hNew - 1;
			}
		}

		protected override void UpdateDisplayFromDatabase()
		{
			AtomicReferenceLauncher arl = (AtomicReferenceLauncher)this.Control;
			arl.UpdateDisplayFromDatabase();
		}
		public override void RegisterWithContextHelper()
		{
			if (this.Control != null)
			{
				string caption = XmlUtils.GetOptionalAttributeValue(ConfigurationNode, "label", "");

				AtomicReferenceLauncher launcher = (AtomicReferenceLauncher)this.Control;

				//NB: which is 0 and which is 1 is sensitive to the front-back order of these widgets in the launcher
				Mediator.SendMessage("RegisterHelpTargetWithId", new object[]{launcher.Controls[1], caption, HelpId});
				Mediator.SendMessage("RegisterHelpTargetWithId", new object[]{launcher.Controls[0], caption, HelpId, "Button"});
			}
		}
	}
}
