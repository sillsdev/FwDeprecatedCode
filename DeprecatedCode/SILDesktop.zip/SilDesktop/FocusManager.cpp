/*---------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: FocusManager.cpp
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the implementation for the focus manager, which registers and unregisters
	focusable objects, keeps track of the different focus groups, and manages the
	configure dialog.
----------------------------------------------------------------------------------------------*/

/***********************************************************************************************
Include files
***********************************************************************************************/
#include "main.h"
#pragma hdrstop
// any other headers (not precompiled)

#undef THIS_FILE
DEFINE_THIS_FILE

/***********************************************************************************************
    Forward declarations
***********************************************************************************************/

/***********************************************************************************************
    Local Constants and static variables
***********************************************************************************************/


/***********************************************************************************************
    Generic factory stuff to allow creating an instance with CoCreateInstance.
***********************************************************************************************/
static GenericFactory g_fact(
	"SIL.SilDesktop.FocusManager",
	&CLSID_FocusManager,
	"SIL Focus Manager",
	"Both",
	&FocusManager::CreateCom);

// There's a single global instance of the IFocusManager.
FocusManager FocusManager::g_fman;


/*----------------------------------------------------------------------------------------------
	Called by the GenericFactory to "create" an ILgWritingSystemFactory. It just returns the global
	one.
----------------------------------------------------------------------------------------------*/
void FocusManager::CreateCom(IUnknown *punkCtl, REFIID iid, void ** ppv)
{
	AssertPtr(ppv);
	Assert(!*ppv);
	if (punkCtl)
		ThrowHr(WarnHr(CLASS_E_NOAGGREGATION));

	CheckHr(g_fman.QueryInterface(iid, ppv));
}

/***********************************************************************************************
    IUnknown Methods
***********************************************************************************************/
STDMETHODIMP FocusManager::QueryInterface(REFIID riid, void **ppv)
{
	if (!ppv)
		return E_POINTER;
	AssertPtr(ppv);
	*ppv = NULL;
	if (riid == IID_IUnknown)
		*ppv = static_cast<IUnknown *>(static_cast<IFocusManager *>(this));
	else if (riid == IID_IFocusManager)
		*ppv = static_cast<IFocusManager *>(this);
	else
		return E_NOINTERFACE;

	reinterpret_cast<IUnknown *>(*ppv)->AddRef();
	return S_OK;
}

/***********************************************************************************************
	Constructors and Destructor
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Initializes global pointer to the focus manager and sets the configure hwnd to NULL.
----------------------------------------------------------------------------------------------*/
FocusManager::FocusManager()
{
	m_hwndConfigure = NULL;
}

/*----------------------------------------------------------------------------------------------
	Destructor
----------------------------------------------------------------------------------------------*/
FocusManager::~FocusManager()
{
	if (m_hwndConfigure)
	{
		::DestroyWindow(m_hwndConfigure);
		m_hwndConfigure = NULL;
	}
}

/***********************************************************************************************
	IFocusManager Methods
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Adds a focusable object to the vector of registered objects.
	@param pfobj The focusable object to be added.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP FocusManager::RegisterFocusableObject(IFocusableObject * pfobj)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pfobj);

	HRESULT hr;

	// if the default focus group is NULL, create an instance of it.
	if (0 == m_vpfgrp.Size())
	{
		ComSmartPtr<FocusGroup> qfgrp;
		qfgrp.Attach(NewObj FocusGroup());
		m_vpfgrp.Push(qfgrp.Ptr());
	}

	// add focusable object to the vector of registered objects
	if (0 <= FindInRegistered(pfobj))
		return E_FAIL;
	m_vpfobjRegistered.Push(pfobj);

	// if the send or receive focus options are set, add the focusable object to a group
	int grfops;
	pfobj->get_FocusOptions(&grfops);
	if (kfopsNil != grfops)
		AddToFocusGroup(pfobj, NULL);
	return hr;

	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusManager);
}

/*----------------------------------------------------------------------------------------------
	Removes a focusable object from the vector of registered objects.
	@param pfobj The focusable object to be removed.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP FocusManager::UnregisterFocusableObject(IFocusableObject * pfobj)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pfobj);

	if (0 > m_vpfobjRegistered.Size())
		return E_FAIL;

	// remove the focusable object from the Registered vector
	int ipfobj = FindInRegistered(pfobj);
	if (0 > ipfobj)
		return E_FAIL;
	m_vpfobjRegistered.Delete(ipfobj);

	// return if any focus groups contain focusable objects
	for (int ipfgrp = 0; ipfgrp < m_vpfgrp.Size(); ++ipfgrp)
		if (0 < m_vpfgrp[ipfgrp]->Size())
			return S_OK;

	// all focus groups are empty, so delete them
	while (m_vpfgrp.Size() > 0)
	{
		ComSmartPtr<FocusGroup> qfgrp;
		m_vpfgrp.Pop(&qfgrp);
		qfgrp->Close();
	}

	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusManager);
}

/*----------------------------------------------------------------------------------------------
	Adds a focusable object (client) to the focus group whose name is specified by bstrGroup
	If bstrGroup is NULL, add it to the default focus group.
	If no group with a name of bstrGroup exists, create a new focus group and add the
		focusable object to the newly created group.
	If the focusable object is currently in a group, remove it from its current focus
		group and add it to the group designated by bstrGroup.
	@param pfobj The focusable object to be added.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP FocusManager::AddToFocusGroup(IFocusableObject *pfobj, BSTR bstrGroup)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pfobj);
	ChkComBstrArgN(bstrGroup);

	HRESULT hr;
	// Review JohnT: have I really got the ref counts straight here?
	pfobj->AddRef();

	// the focusable object is already part of a focus group, so remove it from the
	//		previous group if different
	ComSmartPtr<IFocusGroup> qfgrpOld;
	pfobj->get_FocusGroup(&qfgrpOld);
	if (NULL != qfgrpOld.Ptr())
	{
		SmartBstr sbstrOld;
		qfgrpOld->get_Name(&sbstrOld);
		if (sbstrOld == bstrGroup)
			return S_OK;

		// remove it from the previous group
		RemoveFromFocusGroup(pfobj);
		pfobj->putref_FocusGroup(NULL);
	}

	// remove pfobj from m_vpfobjRegistered
	int ipfobj = FindInRegistered(pfobj);
	ComSmartPtr<IFocusableObject> qfobj = pfobj; // prevent object being really deleted
	m_vpfobjRegistered.Delete(ipfobj);

	// add this focusable object to dialog if dialog exists
	if (NULL != m_hwndConfigure)
		AddItem(pfobj);

	// if group name is null, add to default focus group
	if (0 == bstrGroup)
	{
		// add pfobj to the default focus group
		hr = m_vpfgrp[DEFAULT]->AddFocusableObject(pfobj);
		return S_OK;
	}

	// search the vector of focus groups for one whose name is bstrGroup
	for (int ipfgrp = 1; ipfgrp < m_vpfgrp.Size(); ++ipfgrp)
	{
		SmartBstr sbstr;
		m_vpfgrp[ipfgrp]->get_Name(&sbstr);

		// the focus group exists, add pfobj to it
		if (*bstrGroup == *sbstr.Bstr())
		{
			hr = m_vpfgrp[ipfgrp]->AddFocusableObject(pfobj);
			return S_OK;
		}
	}

	// the specified focus group does not exist, so create a new group with that name,
	//		add pfobj to it
	ComSmartPtr<FocusGroup> pfgrp;
	pfgrp.Attach(NewObj FocusGroup());
	pfgrp->AssignName(bstrGroup);
	m_vpfgrp.Push(pfgrp);
	hr = pfgrp->AddFocusableObject(pfobj);

	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusManager);
}


/*----------------------------------------------------------------------------------------------
	Removes a focusable object from its focus group.
	Argument:
		pfobj		the focusable object to be removed.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP FocusManager::RemoveFromFocusGroup(IFocusableObject * pfobj)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pfobj);

	HRESULT hr;

	IFocusGroup * pfgrp;
	pfobj->get_FocusGroup(&pfgrp);

	// return since the focusable object does not belong to a focus group
	if (NULL == pfgrp)
		return S_OK;

	// remove the focusable object from dialog if dialog exists
	if (NULL != m_hwndConfigure)
		DeleteItem(pfobj);

	// remove the focusable object from its focus group
	static_cast<FocusGroup *>(pfgrp)->DelFocusableObject(pfobj);


	// put fobj back into vector of registered objects
	if (0 > FindInRegistered(pfobj))
		m_vpfobjRegistered.Push(pfobj);

	ReleaseObj(pfgrp);

	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusManager);
}

/*----------------------------------------------------------------------------------------------
	Remembers which focusable object launches the configure dialog and resets the
		timer so that the idle loop will be called right away.
	Argument:
		pfobj		the focusable object that wants to launch the configure dialog
----------------------------------------------------------------------------------------------*/
STDMETHODIMP FocusManager::LaunchFocusDialog(IFocusableObject * pfobj)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pfobj);

	m_qfobjLaunch = pfobj;
	::KillTimer(NULL, g_uTimer);
	g_uTimer = ::SetTimer(NULL, 0, 1, NULL);
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusManager);
}

/*-----------------------------------------------------------------------------------------
	Creates a word focus object for the client to initialize.
	Argument:
		ppfwri		the newly created word focus object
-----------------------------------------------------------------------------------------*/
STDMETHODIMP FocusManager::CreateWordFocus(IWordFocusInit ** ppfwri)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(ppfwri);

	HRESULT hr;
	ComSmartPtr<WordFocusInit> pfwri;
	if (FAILED(hr = ComSmartPtr<WordFocusInit>::CreateInstance(&pfwri)))
		return hr;
	AddRefObj(pfwri);
	hr = pfwri->QueryInterface(IID_IWordFocusInit, (void **)ppfwri);
	ReleaseObj(pfwri);
	return hr;

	END_COM_METHOD(g_fact, IID_IFocusManager);
}

/*-----------------------------------------------------------------------------------------
	Creates a scripture reference focus object for the client to initialize.
	Argument:
		ppfsci		the newly created scripture reference focus object
-----------------------------------------------------------------------------------------*/
STDMETHODIMP FocusManager::CreateScriptureReferenceFocus(IScriptureReferenceFocusInit **
	ppfsci)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(ppfsci);

	HRESULT hr;
	ComSmartPtr<ScriptureReferenceFocusInit> * pfsci;
	if (FAILED(hr = ComSmartPtr<ScriptureReferenceFocusInit>::CreateInstance(&pfsci)))
		return hr;
	AddRefObj(pfsci);
	hr = pfsci->QueryInterface(IID_IScriptureReferenceFocusInit, (void **)ppfsci);
	ReleaseObj(pfsci);
	return hr;

	END_COM_METHOD(g_fact, IID_IFocusManager);
}

/***********************************************************************************************
	Other Public Methods
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Destroys the configure dialog box before it is closed.
----------------------------------------------------------------------------------------------*/
void FocusManager::CloseDialog(void)
{
	if (m_hwndConfigure)
	{
		::DestroyWindow(m_hwndConfigure);
		m_hwndConfigure = NULL;
	}
}

/*----------------------------------------------------------------------------------------------
	Handles launching the dialog, and calling the idle routine of the focus	groups.
----------------------------------------------------------------------------------------------*/
void FocusManager::Idle(void)
{

	// call function to launch dialog
	if (g_fman.m_qfobjLaunch)
		g_fman.DoDialog();

	// call each focus group's idle routine to broadcast the current focus
	if (g_fman.m_vpfgrp.Size())
	{
		for (int ipfgrp = 0; ipfgrp < g_fman.m_vpfgrp.Size(); ++ipfgrp)
			g_fman.m_vpfgrp[ipfgrp]->Idle();
	}
}


/*----------------------------------------------------------------------------------------------
	Handles the messages for the Configure dialog.
----------------------------------------------------------------------------------------------*/
BOOL CALLBACK DialogProc(HWND  hwndDlg, UINT uMsg, WPARAM wParam, LPARAM  lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		return TRUE; // indicate we did not set focus to the control
	case WM_COMMAND:
		switch (HIWORD(wParam))
		{
		case LBN_SELCHANGE:
			FocusManager::DialogSelChange();
			return TRUE;
		}
		switch (LOWORD(wParam))
		{
		case IDC_CLOSE:
			FocusManager::DialogClose();
			return TRUE;
		case IDC_CHECK_RCVFOCUS:
			FocusManager::DialogCheckReceive();
			return TRUE;
		case IDC_CHECK_SNDFOCUS:
			FocusManager::DialogCheckSend();
			return TRUE;
		case IDC_LIST_APPS:
			FocusManager::DialogSelChange();
			return TRUE;
		}
		return FALSE;
	default: return FALSE;
	};
}

/***********************************************************************************************
	Protected Static Methods
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Updates the focus options when a different item in the list box is selected.
----------------------------------------------------------------------------------------------*/
HRESULT FocusManager::DialogSelChange()
{
	return g_fman.UpdateOptions();
}

/*----------------------------------------------------------------------------------------------
	Clears the list of its strings and data as the dialog is closed.
----------------------------------------------------------------------------------------------*/
void FocusManager::DialogClose()
{
	g_fman.Clear();
	g_fman.CloseDialog();
}


/*----------------------------------------------------------------------------------------------
	Updates the checkbox and focusable object's focus options when receive focus is
	clicked.
----------------------------------------------------------------------------------------------*/
HRESULT FocusManager::DialogCheckReceive()
{

	// get the selected item and the corresponding focusable object
	int iList = ::SendDlgItemMessage(g_fman.m_hwndConfigure, IDC_LIST_APPS,
		LB_GETCURSEL, 0, 0);
	if (LB_ERR == iList)
		return E_FAIL;
	IFocusableObject * pfobj = (IFocusableObject *)::SendDlgItemMessage(
		g_fman.m_hwndConfigure, IDC_LIST_APPS, LB_GETITEMDATA, (WPARAM)iList, 0);

	// set new focus options of this focusable object
	int grfops;

	HRESULT hr;
	if (FAILED (hr = pfobj->get_FocusOptions(&grfops)))
		return hr;

	UINT fChecked = ::IsDlgButtonChecked(g_fman.m_hwndConfigure, IDC_CHECK_RCVFOCUS);
	if (fChecked)
		grfops |= kfopsReceive;
	else
		grfops &= ~kfopsReceive;
	::CheckDlgButton(g_fman.m_hwndConfigure, IDC_CHECK_SNDFOCUS, grfops & kfopsSend);

	if (FAILED (hr = pfobj->put_FocusOptions(grfops)))
		return hr;

	return S_OK;
}

/*----------------------------------------------------------------------------------------------
	Updates the checkbox and focusable object's focus options when send focus is clicked.
----------------------------------------------------------------------------------------------*/
HRESULT FocusManager::DialogCheckSend()
{
	// get the selected item and the corresponding focusable object
	int iList = ::SendDlgItemMessage(g_fman.m_hwndConfigure, IDC_LIST_APPS,
		LB_GETCURSEL, 0, 0);
	if (LB_ERR == iList)
		return E_FAIL;
	IFocusableObject * pfobj = (IFocusableObject *)::SendDlgItemMessage(
		g_fman.m_hwndConfigure, IDC_LIST_APPS, LB_GETITEMDATA, (WPARAM)iList, 0);

	// set new focus options of this focusable object
	int grfops;
	HRESULT hr;

	if (FAILED (hr = pfobj->get_FocusOptions(&grfops)))
		return hr;

	UINT fChecked = ::IsDlgButtonChecked(g_fman.m_hwndConfigure, IDC_CHECK_SNDFOCUS);
	if (fChecked)
		grfops |= kfopsSend;
	else
		grfops &= ~kfopsSend;
	::CheckDlgButton(g_fman.m_hwndConfigure, IDC_CHECK_RCVFOCUS, grfops & kfopsReceive);

	if (FAILED (hr = pfobj->put_FocusOptions(grfops)))
		return hr;

	return S_OK;
}

/***********************************************************************************************
	Other Protected Methods
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Given an IUnknown interface pointer, finds the object in the vector and returns the
		index if the object is found. Otherwise, returns -1.
	Argument:
		punk		the interface pointer to the object to be found
----------------------------------------------------------------------------------------------*/
int FocusManager::FindInRegistered(IUnknown * punk)
{
	AssertPtrN(punk);

	HRESULT hr;
	IUnknown * punkT;
	IUnknown * punkT2;
	int ipfobj;

	// First just do a normal binary compare.
	for (ipfobj = m_vpfobjRegistered.Size(); ipfobj > 0; )
	{
		if (punk == m_vpfobjRegistered[--ipfobj])
		{
			IFocusableObject * test = m_vpfobjRegistered[ipfobj];
			return ipfobj;
		}
	}
	if (NULL == punk)
		return -1;

	// Now do IUnknown compares.
	hr = punk->QueryInterface(IID_IUnknown, (void **)&punkT);
	if (SUCCEEDED(hr))
	{
		punkT->Release();
		punk = punkT;
	}

	for (ipfobj = m_vpfobjRegistered.Size(); ipfobj > 0; )
	{
		punkT = m_vpfobjRegistered[--ipfobj];
		if (NULL == punkT)
			continue;
		hr = punkT->QueryInterface(IID_IUnknown, (void **)&punkT2);
		if (FAILED(hr))
			continue;
		AssertPtr(punkT2);
		punkT2->Release();
		if (punkT2 == punk)
			return ipfobj;
	}

	return -1;
}

/***********************************************************************************************
	Other Private Methods
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Fill dialog with focusable objects in the focus groups.
----------------------------------------------------------------------------------------------*/
void FocusManager::PopulateList(void)
{
	ComSmartPtr<IFocusableObject> qfobj;

	for (int ipfgrp=0; ipfgrp < m_vpfgrp.Size(); ++ipfgrp)
	{
		// get pointer to vector of focusable objects
		Vector<IFocusableObject *> * pvpfobj;
		m_vpfgrp[ipfgrp]->GetMyVector(&pvpfobj);

		for (int i=0; i<pvpfobj->Size(); ++i)
		{
			qfobj = pvpfobj->Get(i);
			AddItem(qfobj);
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Launch the configure dialog only if one has not been launched.
----------------------------------------------------------------------------------------------*/
void FocusManager::DoDialog(void)
{
	ComSmartPtr<IFocusableObject> qfobj = m_qfobjLaunch;
	m_qfobjLaunch.Release();

	AssertPtr(qfobj.p);
		// Select m_qfobjLaunch.
	if (NULL != m_hwndConfigure)
	{
		SelectItem(qfobj);
		return;
	}

	// create the dialog
	if (FAILED(CreateConfigure()))
		return;

	// fill and show dialog
	PopulateList();
	SelectItem(qfobj);
	ShowWindow(m_hwndConfigure, SW_SHOWNORMAL);

	// brings the dialog to the foreground
	SetForegroundWindow(m_hwndConfigure);
}

/*----------------------------------------------------------------------------------------------
	Creates the Configure dialog.
----------------------------------------------------------------------------------------------*/
HRESULT FocusManager::CreateConfigure()
{
	if (m_hwndConfigure)
		::DestroyWindow(m_hwndConfigure);
	m_hwndConfigure = ::CreateDialog(g_hInstance, MAKEINTRESOURCE(IDD_CONFIGURATION),
		0, (DLGPROC)DialogProc);
	if (m_hwndConfigure)
		return S_OK;
	return E_FAIL;
}


/*----------------------------------------------------------------------------------------------
	Returns the zero-based index of an IFocusableObject, or -1 if not found.
	Argument:
		pfobj		the focusable object to be found in the list box
----------------------------------------------------------------------------------------------*/
int FocusManager::FindIndex(IFocusableObject * pfobj)
{
	AssertPtr(pfobj);
	IFocusableObject * pfobjTmp;

	// find item
	int nSize = ::SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_GETCOUNT, 0, 0);
	for (int iList = 0; iList < nSize; iList++)
	{
		pfobjTmp = (IFocusableObject *)::SendDlgItemMessage(m_hwndConfigure,
			IDC_LIST_APPS, LB_GETITEMDATA, (WPARAM) iList, 0);
		if (FEqualObjects(pfobj, pfobjTmp))
			return iList;
	}
	return -1;
}

/*----------------------------------------------------------------------------------------------
	Selects a string in the list.
	Argument:
		pfobj		the focusable object to be selected in the list box
----------------------------------------------------------------------------------------------*/
HRESULT FocusManager::SelectItem(IFocusableObject * pfobj)
{
	AssertPtr(pfobj);

	// find index of item
	int iList = FindIndex(pfobj);
	if (0 > iList)
		return E_FAIL;

	// Select item by index.
	::SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_SETCURSEL, (WPARAM)iList,
		(LPARAM)0);

	return UpdateOptions();
}

/*----------------------------------------------------------------------------------------------
	Adds a string to list.
	Argument:
		pfobj		the focusable object whose name is to be added to the list box
----------------------------------------------------------------------------------------------*/
HRESULT FocusManager::AddItem(IFocusableObject * pfobj)
{
	AssertPtr(pfobj);
	USES_CONVERSION;
	BSTR bstr;

	HRESULT hr;
	if (FAILED (hr = pfobj->get_Name(&bstr)))
		return hr;

	// ENHANCE: what if 2+ apps are registered using the same user string?

	// add string
	int iList = ::SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_ADDSTRING, 0,
		(LPARAM)W2T(bstr));
	SysFreeString(bstr);
	if (0 > iList)
		return E_FAIL;

	// set pfobj as item data
	Assert(iList >= 0);
	pfobj->AddRef();
	::SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_SETITEMDATA, (WPARAM)iList,
		(LPARAM)pfobj);

	return UpdateOptions();
}

/*----------------------------------------------------------------------------------------------
	Deletes a string and data from the list.
	Argument:
		pfobj		the focusable object whose name is to be deleted from the list box
----------------------------------------------------------------------------------------------*/
HRESULT FocusManager::DeleteItem(IFocusableObject * pfobj)
{
	AssertPtr(pfobj);
	USES_CONVERSION;
	int iList = FindIndex(pfobj);
	if (0 > iList)
		return S_OK;

	// delete string and data
	::SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_SETITEMDATA, (WPARAM)iList, 0);
	ReleaseObj(pfobj);
	::SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_DELETESTRING, (WPARAM)iList, 0);

	return UpdateOptions();
}

/*----------------------------------------------------------------------------------------------
	Deletes all strings and data from the list.
----------------------------------------------------------------------------------------------*/
HRESULT FocusManager::Clear()
{
	// get number of items in list
	int nCount = ::SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_GETCOUNT, 0, 0);

	// delete from end of list
	for (int iList = nCount; iList-- > 0; )
	{
		IFocusableObject * pfobj = (IFocusableObject *)::SendDlgItemMessage(
			m_hwndConfigure, IDC_LIST_APPS, LB_GETITEMDATA, (WPARAM)iList, 0);
		SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_SETITEMDATA, (WPARAM)iList, (LPARAM)0);
		ReleaseObj(pfobj);
		SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_DELETESTRING, (WPARAM)iList, 0);
	}
	// clear and disable checkboxes
	return UpdateOptions();
}

/*----------------------------------------------------------------------------------------------
	Updates the dialog checkboxes to reflect the correct focus options.
----------------------------------------------------------------------------------------------*/
HRESULT FocusManager::UpdateOptions()
{
	int iList = SendDlgItemMessage(m_hwndConfigure, IDC_LIST_APPS, LB_GETCURSEL, 0, 0);
	if (LB_ERR == iList)
	{
		// disable check boxes.
		::CheckDlgButton(m_hwndConfigure, IDC_CHECK_RCVFOCUS, false);
		::CheckDlgButton(m_hwndConfigure, IDC_CHECK_SNDFOCUS, false);
		HWND hwndRcv = GetDlgItem(m_hwndConfigure, IDC_CHECK_RCVFOCUS);
		HWND hwndSnd = GetDlgItem(m_hwndConfigure, IDC_CHECK_SNDFOCUS);
		::EnableWindow(hwndRcv, false);
		::EnableWindow(hwndSnd, false);
		return E_FAIL;
	}

	// enable checkboxes
	HWND hwndRcv = GetDlgItem(m_hwndConfigure, IDC_CHECK_RCVFOCUS);
	HWND hwndSnd = GetDlgItem(m_hwndConfigure, IDC_CHECK_SNDFOCUS);
	::EnableWindow(hwndRcv, true);
	::EnableWindow(hwndSnd, true);

	IFocusableObject * pfobj = (IFocusableObject *)SendDlgItemMessage(
		m_hwndConfigure, IDC_LIST_APPS, LB_GETITEMDATA, (WPARAM)iList, 0);
	int grfops;

	if (FAILED(pfobj->get_FocusOptions(&grfops)))
	{
		// disable checkboxes if retrieving focus options fails
		::EnableWindow(hwndRcv, false);
		::EnableWindow(hwndSnd, false);
		return E_FAIL;
	}

	CheckDlgButton(m_hwndConfigure, IDC_CHECK_RCVFOCUS, grfops & kfopsReceive);
	CheckDlgButton(m_hwndConfigure, IDC_CHECK_SNDFOCUS, grfops & kfopsSend);

	return S_OK;
}