/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: Main.h
Responsibility: Felise Wu
Last reviewed: Not yet.

Description:
	Main header file for the focus sharing component.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef SILDESKTOP_H
#define SILDESKTOP_H 1

#define NO_EXCEPTIONS 1
#include "Common.h"


/*************************************************************************************
	Forward declarations
*************************************************************************************/
extern UINT g_uTimer;
extern HINSTANCE g_hInstance;

/*************************************************************************************
	Classes we have to include before we can do typedefs
*************************************************************************************/
#include "Vector.h"


/*************************************************************************************
	Interfaces.
*************************************************************************************/
#include "SilDesktopTlb.h"
#include "FocusGroup.h"
#include "FocusManager.h"

#endif //!SILDESKTOP_H




