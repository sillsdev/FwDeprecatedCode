/*-----------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: FocusManager.h
Responsibility: Felise Wu
Last reviewed: never.

Description:
	Defines the interface for the focus manager.
-----------------------------------------------------------------------------------------*/

#pragma once
#ifndef FOCUSMANAGER_INCLUDED
#define FOCUSMANAGER_INCLUDED

#define DEFAULT 0

/*-----------------------------------------------------------------------------------------
Class: FocusManager
Description: Keeps track of the different focus groups and the objects yet to be added to
	to a focus group, implements the dialog which lists all objects sharing focus, and
	allows the send and receive options to be configured for each object.
Hungarian: fman
-----------------------------------------------------------------------------------------*/
class FocusManager : public IFocusManager
{
public:
	// Static methods
	static void CreateCom(IUnknown *punkOuter, REFIID iid, void ** ppv);


	// IUnknown methods.
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppv);

	// Since this is a singleton, just addref the module.
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return ModuleEntry::ModuleAddRef();
	}

	// Since this is a singleton, just release the module.
	STDMETHOD_(ULONG, Release)(void)
	{
		return ModuleEntry::ModuleRelease();
	}

	// IFocusManager Methods
	STDMETHOD(RegisterFocusableObject)(IFocusableObject * pfobj);
	STDMETHOD(UnregisterFocusableObject)(IFocusableObject * pfobj);
	STDMETHOD(AddToFocusGroup)(IFocusableObject * pfobj, BSTR bstrGroup);
	STDMETHOD(RemoveFromFocusGroup)(IFocusableObject * pfobj);
	STDMETHOD(LaunchFocusDialog)(IFocusableObject * pfobj);
	STDMETHOD(CreateWordFocus)(IWordFocusInit ** ppfwri);
	STDMETHOD(CreateScriptureReferenceFocus)(IScriptureReferenceFocusInit ** ppfsci);


	// Member variable access

	// Other public methods
	void CloseDialog(void);
	static void Idle(void);

	int Size(void)
	{
		return m_vpfobjRegistered.Size();
	}

protected:
	FocusManager();
	~FocusManager();

	// Member variables
	ComVector<IFocusableObject> m_vpfobjRegistered;
	ComVector<FocusGroup> m_vpfgrp;
	ComSmartPtr<IFocusableObject> m_qfobjLaunch;
	HWND m_hwndConfigure;
	static FocusManager g_fman;

	// Static methods
	static HRESULT DialogSelChange();
	static void DialogClose();
	static HRESULT DialogCheckReceive();
	static HRESULT DialogCheckSend();

	// Constructors/destructors/etc.

	// Other protected methods
	int FindInRegistered(IUnknown * punk);

private:
	// Member variables

	// Static methods

	// Other private methods
	void PopulateList(void);
	void DoDialog(void);

	// Configure dialog
	HRESULT CreateConfigure();
	int FindIndex(IFocusableObject * pfobj);
	HRESULT SelectItem(IFocusableObject * pfobj);
	HRESULT AddItem(IFocusableObject * pfobj);
	HRESULT DeleteItem(IFocusableObject * pfobj);
	HRESULT Clear();
	HRESULT UpdateOptions();

};

DEFINE_COM_PTR(FocusManager);

#endif  //FOCUSMANAGER_INCLUDED
