/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: WordFocusInit.cpp
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the implementation of the helper class which creates and initializes a word 
	focus object with the sender, the type of focus, the word in focus, and the writing system.
-----------------------------------------------------------------------------------------*/

/******************************************************************************************
Include files
******************************************************************************************/
#include "main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

/***********************************************************************************************
    Forward declarations
***********************************************************************************************/

/***********************************************************************************************
    Constructors and Destructor
***********************************************************************************************/
WordFocusInit::WordFocusInit()
{
	m_cref = 1;
	ModuleEntry::ModuleAddRef();
}

WordFocusInit::~WordFocusInit()
{
	ModuleEntry::ModuleRelease();
}

/***********************************************************************************************
    Generic factory stuff to allow creating an instance with CoCreateInstance.
***********************************************************************************************/
static GenericFactory g_fact(
	"SIL.SilDesktop.WordFocusInit",	
	&CLSID_WordFocusInit,	
	"SIL Word Focus Init",
	"Both",
	&WordFocusInit::CreateCom);

/*----------------------------------------------------------------------------------------------
	Called by the GenericFactory to "create" an IFocusGroup.It just returns the global one.
----------------------------------------------------------------------------------------------*/
void WordFocusInit::CreateCom(IUnknown *punkCtl, REFIID iid, void ** ppv)
{
	AssertPtr(ppv);
	Assert(!*ppv);
	if (punkCtl)
		ThrowHr(WarnHr(CLASS_E_NOAGGREGATION));

	ComSmartPtr<WordFocusInit> qfwfi;
	qfwfi.Attach(NewObj WordFocusInit());		// ref count initially 1
	CheckHr(qfwfi->QueryInterface(riid, ppv));
}

/***********************************************************************************************
    IUnknown Methods
***********************************************************************************************/
STDMETHODIMP WordFocusInit::QueryInterface(REFIID riid, void **ppv)
{
	if (!ppv)
		return E_POINTER;
	AssertPtr(ppv);
	*ppv = NULL;
	if (riid == IID_IUnknown)
		*ppv = static_cast<IUnknown *>(static_cast<IWordFocusInit *>(this));
	else if (riid == IID_IIWordFocusInit)
		*ppv = static_cast<IWordFocusInit *>(this);
	else
		return E_NOINTERFACE;

	reinterpret_cast<IUnknown *>(*ppv)->AddRef();
	return S_OK;
}

/******************************************************************************************
	IFocus Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Used by the focus group to avoid sending the focus changed notification to the 
	focusable object which sent the focus.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::get_Sender(IFocusableObject ** ppfobj)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(ppfobj);

	if (NULL == ppfobj)
		return E_POINTER;
	AssertPtr(ppfobj);
	*ppfobj = m_qfobjSender;
	AddRefObj(*ppfobj);
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocus);
}

/*-----------------------------------------------------------------------------------------
	Retrieves the number of the types of focus this focus object handles.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::get_CountTypes(int * pcft)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pcft);

	*pcft = 1;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocus);
}

/*-----------------------------------------------------------------------------------------
	Given an index, retrieves the corresponding type of focus handled.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::get_Type(int ift, int * pft)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pft);
	if (ift != 0)
		return E_INVALIDARG;

	*pft = kftWord;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocus);
}

/******************************************************************************************
	IWordFocus Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	The host app retrieves the word in focus and responds to display that word.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::get_Word(BSTR * pbstrWord)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pbstrWord);

	return SetBstr(pbstrWord, m_qbstrWord);

	END_COM_METHOD(g_fact, IID_IWordFocus);
}

/*-----------------------------------------------------------------------------------------
	Retrieves the writing system of the word in focus.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::get_WritingSystem(int * pnEncoding)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pnEncoding);

	*pnEncoding = m_nEncoding;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IWordFocus);
}

/*-----------------------------------------------------------------------------------------
	Retrieves the current word focus information at once, the word in focus and its 
	writing system.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::WordInfo(BSTR * pbstrWord, int * pnEncoding)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pbstrWord);
	ChkComOutPtr(pnEncoding);

	SetBstr(pbstrWord, m_qbstrWord);
	*pnEncoding = m_nEncoding;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IWordFocus);
}

/******************************************************************************************
	IWordFocusInit Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Initializes the word focus object with the sender, word in focus, and writing system
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::Init(IFocusableObject * pfobj, BSTR bstrWord, int nEncoding)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pfobj);
	ChkComBstrArgN(bstrWord);

	HRESULT hr;

	// If we've already been Init'ed don't allow being changed.
	if (NULL != m_qfobjSender.p)
		return E_FAIL;

	if (FAILED(hr = SetBstrLen(&m_qbstrWord, bstrWord)))
		return hr;

	m_nEncoding = nEncoding;

	m_qfobjSender = pfobj;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IWordFocusInit);
}

/*-----------------------------------------------------------------------------------------
	Initializes the word focus object with the sender, word in focus, and writing system,
	where the word is stored using widechars
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::InitWide(IFocusableObject * pfobj, LPCOLESTR pszWord, 
	int nEncoding)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pfobj);
	ChkComArgPtr(pszWord);

	HRESULT hr;

	// If we've already been Init'ed don't allow being changed.
	if (NULL != m_qfobjSender.p)
		return E_FAIL;

	if (FAILED(hr = SetBstr(&m_qbstrWord, pszWord)))
		return hr;

	m_nEncoding = nEncoding;

	m_qfobjSender = pfobj;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IWordFocusInit);
}

/*-----------------------------------------------------------------------------------------
	Initializes the word focus object with the sender, word in focus, and writing system,
	where the word is stored as multibyte strings
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::InitMultiByte(IFocusableObject * pfobj, LPCSTR pszWord, 
	int nEncoding)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pfobj);
	ChkComArgPtr(pszWord);

	HRESULT hr;

	// If we've already been Init'ed don't allow being changed.
	if (NULL != m_qfobjSender.p)
		return E_FAIL;

	if (FAILED(hr = SetBstr(&m_qbstrWord, pszWord)))
		return hr;

	m_nEncoding = nEncoding;

	m_qfobjSender = pfobj;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IWordFocusInit);
}

/*-----------------------------------------------------------------------------------------
	Releases the sender object
-----------------------------------------------------------------------------------------*/
STDMETHODIMP WordFocusInit::Close(void)
{
	BEGIN_COM_METHOD;

	m_qfobjSender.Release();
	return S_OK;

	END_COM_METHOD(g_fact, IID_IWordFocusInit);
}
