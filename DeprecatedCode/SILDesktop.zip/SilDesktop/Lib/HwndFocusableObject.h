/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: HwndFocusableObject.h
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the focusable object interface for an application that communicates through
	message passing.
-----------------------------------------------------------------------------------------*/

#pragma once
#ifndef HWNDFOCUSABLEOBJECT_INCLUDED
#define HWNDFOCUSABLEOBJECT_INCLUDED

#include "resource.h"       // main symbols

/*-----------------------------------------------------------------------------------------
Class CHwndFocusableObject
Description: Implements the focusable object used to communicate with application using
	windows messages.
Hungarian: fobh
-----------------------------------------------------------------------------------------*/
class CHwndFocusableObject : public IFocusableObjectInitHwnd,
{
public:
	//ENHANCE: do we need a CreateCom?

	//ENHANCE: what to do with the constructor
	// Constructor
	CHwndFocusableObject() :
		IDispatchImplNonDual<IFocusableObjectInitHwnd,
			&IID_IFocusableObjectInitHwnd>(static_cast<IFocusableObjectInitHwnd *>(this))
	{
		m_hwnd = NULL;
	}

	// IUnknown methods.
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppv);
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return InterlockedIncrement(&m_cref);
	}
	STDMETHOD_(ULONG, Release)(void)
	{
		long cref = InterlockedDecrement(&m_cref);
		if (cref == 0) {
			m_cref = 1;
			delete this;
		}
		return cref;
	}

	// IFocusableObject methods.
	STDMETHOD(get_FocusGroup)(IFocusGroup ** ppfgrp);
	STDMETHOD(putref_FocusGroup)(IFocusGroup * pfgrp);
	STDMETHOD(FocusChanged)();
	STDMETHOD(get_FocusOptions)(int * pgrfops);
	STDMETHOD(put_FocusOptions)(int grfops);
	STDMETHOD(get_FocusCapabilities)(int * pgrfops);
	STDMETHOD(get_Name)(BSTR * pbstr);

	// IFocusableObjectInitHwnd methods.
	STDMETHOD(Init)(long hwnd, long wm, long wp, long lp, int grfopsCap, BSTR bstrName);
	STDMETHOD(Close)(void);

protected:
	// Member variables
	ComSmartPtr<IFocusGroup> m_qfgrp;
	CComBSTR m_qbstrName;
	int m_grfops;
	int m_grfopsCap;
	long m_hwnd;
	UINT m_wm;
	WPARAM m_wp;
	LPARAM m_lp;
};

DEFINE_COM_PTR(CHwndFocusableObject);

#endif //HWNDFOCUSABLEOBJECT_INCLUDED
