/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: DispFocusableObject.cpp
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the implementation for focusable object using an IDispatch interface.
-----------------------------------------------------------------------------------------*/

/******************************************************************************************
Include files
******************************************************************************************/
#include "main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

//ENHANCE: do we need a constructor & destructor that has 'ModuleAddRef()' and 'ModuleRelease()'???

static DummyFactory g_fact("SIL.Desktop.CDispFocusableObject");

STDMETHODIMP CDispFocusableObject::QueryInterface(REFIID riid, void **ppv)
{
	if (!ppv)
		return E_POINTER;
	AssertPtr(ppv);
	*ppv = NULL;
	if (riid == IID_IUnknown)
		*ppv = static_cast<IUnknown *>(this);
	else if (riid == IID_IFocusableObjectInitDisp)
		*ppv = static_cast<IFocusableObjectInitDisp *>(this);
	else
		return E_NOINTERFACE;
	AddRef();
	return NOERROR;
}

/******************************************************************************************
	IFocusableObject Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Retrieves the focusable object's focus group, which can be sed to add or remove the 
	object from its focus group.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CDispFocusableObject::get_FocusGroup(IFocusGroup ** ppfgrp)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(ppfgrp);

	HRESULT hr;
	CComVariant var;

	if (FAILED(hr = Get(L"GetFocusGroup", &var)))
		return hr;
	if (var.vt != VT_DISPATCH && var.vt != VT_UNKNOWN)
		return E_FAIL;
	if (NULL == var.punkVal)
		return S_OK;
	return var.punkVal->QueryInterface(IID_IFocusGroup, (void **)ppfgrp);

	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Confirms that the focusable object has been added to a focus group by giving it a 
	pointer to its focus group.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CDispFocusableObject::putref_FocusGroup(IFocusGroup * pfgrp)
{
	BEGIN_COM_METHOD;
	ChkComArgPtrN(pfgrp);

	CComVariant var;
	IDispatch * pdisp = NULL;

	if (NULL == pfgrp)
		var = (IDispatch *)NULL;
	else if (FAILED(pfgrp->QueryInterface(IID_IDispatch, (void **)&pdisp)))
		var = (IUnknown *)pfgrp;
	else
	{
		var = pdisp;
		ReleaseObj(pdisp);
	}
	return Put(L"PutFocusGroup", &var);

	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Called by IFocusGroup as a notification of a change in focus.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CDispFocusableObject::FocusChanged()
{
	BEGIN_COM_METHOD;
	return Get(L"FocusChanged", NULL);
	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Retrieves focus options to be kfopsSend and/or kfopsReceive, or kfopsNil.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CDispFocusableObject::get_FocusOptions(int * pgrfops)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pgrfops);
	return GetLong(L"GetFocusOptions", (long *)pgrfops);
	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Sets focus options to be kfopsSend and/or kfopsReceive, or kfopsNil.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CDispFocusableObject::put_FocusOptions(int grfops)
{
	BEGIN_COM_METHOD;
	CComVariant var(grfops);
	return Put(L"PutFocusOptions", &var);
	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Retrieves the focus options this focusable object is capable of having, kfopsSend 
	and/or kfopsReceive, or kfopsNil.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CDispFocusableObject::get_FocusCapabilities(int * pgrfops)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pgrfops);
	return GetLong(L"GetFocusCapabilities", (long *)pgrfops);
	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Retrieves the string used to identify the focusable object.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CDispFocusableObject::get_Name(BSTR * pbstr)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pbstr);
	return GetString(L"GetName", pbstr);
	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/******************************************************************************************
	IFocusableObjectInitDisp Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Initializes the focusable object for communicating with the host application through 
	an IDispatch interface.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CDispFocusableObject::Init(IDispatch * pdisp)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pdisp);
	if (NULL != m_qdisp.p)
		return E_FAIL;
	m_qdisp = pdisp;
	return S_OK;
	END_COM_METHOD(g_fact, IID_IFocusableObjectInitDisp);
}

/*-----------------------------------------------------------------------------------------
	Calls Release() on the IDispatch interface.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CDispFocusableObject::Close(void)
{
	BEGIN_COM_METHOD;
	m_qdisp.Release();
	return S_OK;
	END_COM_METHOD(g_fact, IID_IFocusableObjectInitDisp);
}

/*-----------------------------------------------------------------------------------------
	Retrieves the DispId of a method mapped to a given name.
	Argument:
		pid:		the DispId mapped to a name
		psz:		the name
-----------------------------------------------------------------------------------------*/
HRESULT CDispFocusableObject::GetId(DISPID * pid, LPCOLESTR psz)
{
	if (NULL == m_qdisp.p)
		return E_FAIL;
	return m_qdisp->GetIDsOfNames(IID_NULL, (OLECHAR **) &psz, 1, 
		LOCALE_SYSTEM_DEFAULT, pid);
}

/*-----------------------------------------------------------------------------------------
	Retrieves a result from an IDispatch object's method specified by a string.
-----------------------------------------------------------------------------------------*/
HRESULT CDispFocusableObject::Get(LPCOLESTR pszName, VARIANT * pvar)
{
	HRESULT hr;
	DISPID id;
	DISPPARAMS dp = { NULL, NULL, 0, 0 };

	if (FAILED(hr = GetId(&id, pszName)))
		return hr;
	return m_qdisp->Invoke(id, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD,
		&dp, pvar, NULL, NULL);
}

/*-----------------------------------------------------------------------------------------
	Passes parameters to an IDispatch object's method specified by a string.
-----------------------------------------------------------------------------------------*/
HRESULT CDispFocusableObject::Put(LPCOLESTR pszName, VARIANT * pvar)
{
	HRESULT hr;
	DISPID id;
	DISPPARAMS dp = { pvar, NULL, 1, 0 };

	if (FAILED(hr = GetId(&id, pszName)))
		return hr;
	return m_qdisp->Invoke(id, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD,
		&dp, NULL, NULL, NULL);
}

/*-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------*/
HRESULT CDispFocusableObject::GetLong(LPCOLESTR pszName, long * plw)
{
	if (NULL == plw)
		return E_POINTER;
	*plw = 0;

	HRESULT hr;
	CComVariant var;

	if (FAILED(hr = Get(pszName, &var)) || FAILED(hr = var.ChangeType(VT_I4)))
		return hr;
	*plw = var.lVal;
	return S_OK;
}

/*-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------*/
HRESULT CDispFocusableObject::GetString(LPCOLESTR pszName, BSTR * pbstr)
{
	if (NULL == pbstr)
		return E_POINTER;
	*pbstr = NULL;

	HRESULT hr;
	CComVariant var;

	if (FAILED(hr = Get(pszName, &var)) || FAILED(hr = var.ChangeType(VT_BSTR)))
		return hr;
	*pbstr = var.bstrVal;
	var.bstrVal = NULL;
	return S_OK;
}