/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: DispFocusableObject.h
Responsibility: Felise Wu
Last reviewed: not yet.

Description: 
	Defines the focusable object interface for an object with an IDispatch interface.
-----------------------------------------------------------------------------------------*/

#pragma once
#ifndef DISPFOCUSABLEOBJECT_INCLUDED
#define DISPFOCUSABLEOBJECT_INCLUDED

#include "resource.h"       // main symbols

/*-----------------------------------------------------------------------------------------
Class: CDispFocusableObject
Description: Implements the focusable object used to communicate with objects using an 
	IDispatch interface.
Hungarian: fobd
-----------------------------------------------------------------------------------------*/
class CDispFocusableObject : public IFocusableObjectInitDisp
{
public:
	//ENHANCE: do we need a CreateCom?

	//ENHANCE: what to do with the constructor
	// Constructor
	CDispFocusableObject() :
		IDispatchImplNonDual<IFocusableObjectInitDisp,
			&IID_IFocusableObjectInitDisp>(static_cast<IFocusableObjectInitDisp *>(this))
	{
	}

	// IUnknown methods.
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppv);
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return InterlockedIncrement(&m_cref);
	}
	STDMETHOD_(ULONG, Release)(void)
	{
		long cref = InterlockedDecrement(&m_cref);
		if (cref == 0) {
			m_cref = 1;
			delete this;
		}
		return cref;
	}

	// IFocusableObject methods.
	STDMETHOD(get_FocusGroup)(IFocusGroup ** ppfgrp);
	STDMETHOD(putref_FocusGroup)(IFocusGroup * pfgrp);
	STDMETHOD(FocusChanged)();
	STDMETHOD(get_FocusOptions)(int * pgrfops);
	STDMETHOD(put_FocusOptions)(int grfops);
	STDMETHOD(get_FocusCapabilities)(int * pgrfops);
	STDMETHOD(get_Name)(BSTR * pbstr);

	// IFocusableObjectInitDisp methods.
	STDMETHOD(Init)(IDispatch * pdisp);
	STDMETHOD(Close)(void);

protected:
	// Member variables
	ComSmartPtr<IDispatch> m_qdisp;

	// Methods
	HRESULT GetId(DISPID * pid, LPCOLESTR psz);
	HRESULT Get(LPCOLESTR pszName, VARIANT * pvar);
	HRESULT Put(LPCOLESTR pszName, VARIANT * pvar);
	HRESULT GetLong(LPCOLESTR pszName, long * plw);
	HRESULT GetString(LPCOLESTR pszName, BSTR * pbstr);
};

DEFINE_COM_PTR(CDispFocusableObject);

#endif //DISPFOCUSABLEOBJECT_INCLUDED
