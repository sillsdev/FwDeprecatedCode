/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: CFocusTemplate.h
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	ATL-based templates for integrating FocusManager support.

	To use this:
	* Include this header file and embed an instance of FocusableObjectStub in client code.
	* Client code will generally call only methods on FocusableObjectStub defined
		below.
-----------------------------------------------------------------------------------------*/

#pragma once
#ifndef CFOCUSTEMPLATE_INCLUDED
#define CFOCUSTEMPLATE_INCLUDED


#include "SILDesktop.h"

#ifndef NO_STD_INLINES

#define Assert(exp) assert(exp)
#define AssertPtr(ptr) Assert(!::IsBadReadPtr((ptr), sizeof(ptr)))
#define AssertPtrN(ptr) Assert(NULL == ptr || !::IsBadReadPtr((ptr), sizeof(ptr)))

/******************************************************************************************
Global template functions
******************************************************************************************/

template<class T>
inline void ReleaseObj(T * &pobj)
{
	AssertPtrN(pobj);
	if (NULL != pobj)
	{
		pobj->Release();
		pobj = NULL;
	}
}


template<class T>
inline void AddRefObj(T * pobj)
{
	AssertPtrN(pobj);
	if (NULL != pobj)
		pobj->AddRef();
}


template<class T>
inline void SetObj(T ** ppobj, T * pobj)
{
	AddRefObj(pobj);
	ReleaseObj(*ppobj);
	*ppobj = pobj;
}


inline BOOL FEqualObjects(IUnknown * punk1, IUnknown * punk2)
{
	if (punk1 == punk2)
		return TRUE;
	if (NULL == punk1 || NULL == punk2)
		return FALSE;
	IUnknown * punkCtl2;
	if (FAILED(punk2->QueryInterface(IID_IUnknown, (void **)&punkCtl2)))
		return FALSE;
	AssertPtr(punkCtl2);
	punkCtl2->Release();
	if (punk1 == punkCtl2)
		return TRUE;
	IUnknown * punkCtl1;
	if (FAILED(punk1->QueryInterface(IID_IUnknown, (void **)&punkCtl1)))
		return FALSE;
	AssertPtr(punkCtl1);
	punkCtl1->Release();
	return punkCtl1 == punkCtl2;
}


inline void ReleaseBstr(BSTR &bstr)
{
	if (NULL != bstr)
	{
		SysFreeString(bstr);
		bstr = NULL;
	}
}


inline long BstrLen(BSTR bstr)
{
	if (NULL == bstr)
		return 0;
	return ((long *)bstr)[-1] / sizeof(OLECHAR);
}


inline HRESULT SetBstrLen(BSTR * pbstr, BSTR bstr)
{
	AssertPtr(pbstr);
	AssertPtrN(*pbstr);

	ReleaseBstr(*pbstr);
	*pbstr = SysAllocStringLen(bstr, BstrLen(bstr));
	if (NULL == *pbstr && 0 != BstrLen(bstr))
		return E_OUTOFMEMORY;
	return S_OK;
}


inline HRESULT SetBstr(BSTR * pbstr, LPCOLESTR psz)
{
	AssertPtr(pbstr);
	AssertPtrN(*pbstr);

	ReleaseBstr(*pbstr);
	*pbstr = SysAllocString(psz);
	if (NULL == *pbstr && NULL != psz)
		return E_OUTOFMEMORY;
	return S_OK;
}


inline HRESULT SetBstr(BSTR * pbstr, LPCSTR psz)
{
	AssertPtr(pbstr);
	AssertPtrN(*pbstr);
	AssertPtrN(psz);

	ReleaseBstr(*pbstr);
	if (NULL == psz || 0 == psz[0])
		return S_OK;

	int cch = MultiByteToWideChar(CP_ACP, 0, psz, -1, NULL, 0);
	if (cch == 0)
		return E_FAIL;

	*pbstr = SysAllocStringLen(NULL, cch - 1);
	if (NULL == *pbstr)
		return E_OUTOFMEMORY;

	MultiByteToWideChar(CP_ACP, 0, psz, -1, *pbstr, cch);
	return S_OK;
}
#endif //!NO_STD_INLINES

/******************************************************************************************
Forward declarations
******************************************************************************************/
template<class T>
class CFocusableObjectStub;

/*-----------------------------------------------------------------------------------------
Class CFocusableObject
Description: Implements the focusable object which communicates with the focus manager.
Hungarian: fobj
-----------------------------------------------------------------------------------------*/

template <class T>
class CFocusableObject : public IFocusableObject
{
public:
	// Static methods
	static HRESULT Create(T * phost, LPCTSTR pszUser, LPCTSTR pszGuid, long fopsInit,
		CFocusableObject<T> ** ppfobj)
	{
		AssertPtr(ppfobj);
		HRESULT hr;

		*ppfobj = new CFocusableObject<T>();
		if (NULL == *ppfobj)
			return E_OUTOFMEMORY;
		if (FAILED(hr = (*ppfobj)->Init(phost, pszUser, pszGuid, fopsInit)))
		{
			ReleaseObj(*ppfobj);
			return hr;
		}
		return S_OK;
	}

	// Methods
	// IUnknown methods.
	STDMETHOD(QueryInterface)(REFIID riid, void ** ppv)
	{
		if (NULL == ppv)
			return E_POINTER;
		*ppv = NULL;
		if (IID_IUnknown == riid || IID_IFocusableObject == riid)
			*ppv = static_cast<IFocusableObject *>(this);
		else
			return E_NOINTERFACE;
		AddRef();
		return S_OK;
	}
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return InterlockedIncrement(&m_cref);
	}
	STDMETHOD_(ULONG, Release)(void)
	{
		long lw = InterlockedDecrement(&m_cref);
		if (0 == lw)
			delete this;
		return S_OK;
	}

	// IFocusableObject methods.
	STDMETHOD(FocusChanged)(void)
	{
		if (NULL !=m_phost != NULL && (m_fops & kfoReceive))
			m_phost->FocusChanged();
		return S_OK;
	}

	STDMETHOD(get_FocusGroup)(IFocusGroup ** ppfgrp)
	{
		if (NULL == ppfgrp)
			return E_POINTER;
		*ppfgrp = m_pfgrp;
		AddRefObj(*ppfgrp);
		return S_OK;
	}

	STDMETHOD(putref_FocusGroup)(IFocusGroup * pfgrp)
	{
		if (NULL == m_phost)
			return E_FAIL;
		SetObj(&m_pfgrp, pfgrp);
		if (NULL != m_pfgrp)
			FocusChanged();
		return S_OK;
	}

	STDMETHOD(get_FocusOptions)(long * pfops)
	{
		if (NULL == pfops)
			return E_POINTER;
		*pfops = m_fops;
		return S_OK;
	}

	STDMETHOD(put_FocusOptions)(long fops)
	{
		if (NULL == m_phost)
			return E_FAIL;
		if (m_fops == (fops & m_fopsCap))
			return S_OK;
		m_fops = fops & m_fopsCap;
		m_phost->FocusOptionsChanged(fops);
		return S_OK;
	}

	STDMETHOD(get_FocusCapabilities)(long * pfops)
	{
		if (NULL == pfops)
			return E_POINTER;
		*pfops = m_fopsCap;
		return S_OK;
	}

	STDMETHOD(get_UserString)(BSTR * pbstr)
	{
		if (NULL == pbstr)
			return E_POINTER;
		*pbstr = NULL;
		return SetBstr(pbstr, m_bstrUser);
	}

	STDMETHOD(get_GlobalUniqueId)(BSTR * pbstr)
	{
		if (NULL == pbstr)
			return E_POINTER;
		*pbstr = NULL;
		return SetBstr(pbstr, m_bstrGuid);
	}

protected:
	// Member variables
	friend class CFocusableObjectStub<T>;
	long m_cref;
	IFocusGroup * m_pfgrp;
	IFocusManager * m_pfman;
	T * m_phost;
	long m_fops;
	long m_fopsCap;
	BSTR m_bstrUser;
	BSTR m_bstrGuid;

	// Constructor/Destructor
	CFocusableObject(void)
	{
		m_cref = 1;
		m_pfgrp = NULL;
		m_pfman = NULL;
		m_phost = NULL;
		m_fops = kfoSend | kfoReceive;
		m_fopsCap = kfoSend | kfoReceive;
		m_bstrUser = NULL;
		m_bstrGuid = NULL;
	}

	virtual ~CFocusableObject(void)
	{
		AddRef();
		Close();
	}

	// Protected methods
	virtual void Close(void)
	{
		AddRef();
		if (NULL != m_pfman)
		{
			m_pfman->UnregisterFocusableObject(static_cast<IFocusableObject *>(this));
			ReleaseObj(m_pfman);
		}
		ReleaseObj(m_pfgrp);
		ReleaseBstr(m_bstrUser);
		ReleaseBstr(m_bstrGuid);
		m_phost = NULL;
		Release();
	}

	HRESULT SetHost(T * phost)
	{
		HRESULT hr;
		CLSID clsid;

		if (NULL == phost)
		{
			Close();
			return S_OK;
		}

		if (NULL != m_phost)
			return E_FAIL;
		if (FAILED(hr = CLSIDFromProgID(L"SILDesktop.FocusManager.1", &clsid)))
			return hr;
		if (FAILED(hr = CoCreateInstance(clsid, NULL, CLSCTX_ALL, IID_IFocusManager, (void **)&m_pfman)))
			return hr;
		m_phost = phost;
		if (FAILED(hr = m_pfman->RegisterFocusableObject(static_cast<IFocusableObject *>(this))))
		{
			m_phost = NULL;
			return hr;
		}
		return NOERROR;
	}

	HRESULT Init(T * phost, LPCTSTR pszUser, LPCTSTR pszGuid, long fopsInit)
	{
		HRESULT hr;

		m_fops = fopsInit;
		m_fopsCap |= fopsInit;
		if (NULL == phost)
			return E_POINTER;
		if (FAILED(hr = SetBstr(&m_bstrUser, pszUser)))
			return hr;
		if (FAILED(hr = SetBstr(&m_bstrGuid, pszGuid)))
			return hr;
		if (FAILED(hr = SetHost(phost)))
			return hr;
		return S_OK;
	}
};

/*-----------------------------------------------------------------------------------------
Class CFocusableObjectStub
Description: Implements the stub which encapsulates the focusable object and is embedded
	in other classes for communicating between the class and the focus manager
Hungarian: fobj
-----------------------------------------------------------------------------------------*/
template<class T>
class CFocusableObjectStub
{
public:
	// Constructor/Destructor
	CFocusableObjectStub(void)
	{
		m_pfobj = NULL;
	}
	~CFocusableObjectStub(void)
	{
		Close();
	}

	// Methods
	HRESULT Init(T * phost, LPCTSTR pszUser, LPCTSTR pszGuid, long fopsInit)
	{
		if (NULL != m_pfobj)
			return E_FAIL;
		return CFocusableObject<T>::Create(phost, pszUser, pszGuid, fopsInit, &m_pfobj);
	}

	void Close(void)
	{
		if (NULL != m_pfobj)
		{
			m_pfobj->SetHost(NULL);
			ReleaseObj(m_pfobj);
		}
	}

	void LaunchFocusDialog(void)
	{
		if (NULL != m_pfobj && NULL != m_pfobj->m_pfman)
			m_pfobj->m_pfman->LaunchFocusDialog(static_cast<IFocusableObject *>(m_pfobj));
	}

	HRESULT GetWordFocusInformation(TCHAR * prgchWord, int cchMaxWord,
		TCHAR * prgchWritingSystem, int cchMaxWritingSystem)
	{
		IFocus * pfocs;
		IWordFocus * pfwrd;
		BSTR bstr;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfgrp->get_Focus(&pfocs)))
			return hr;
		if (NULL == pfocs)
			return E_FAIL;
		hr = pfocs->QueryInterface(IID_IWordFocus, (void **)&pfwrd);
		ReleaseObj(pfocs);
		if (FAILED(hr))
			return hr;
		if (NULL != prgchWord && cchMaxWord > 1)
		{
			if (FAILED(hr = pfwrd->get_Word(&bstr)) || NULL == bstr)
				prgchWord[0] = 0;
			else
			{
#ifdef _UNICODE
				int cch = min(cchMaxWord - 1, BstrLen(bstr));
				memcpy(prgchWord, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchWord, cchMaxWord - 1, NULL, NULL);
#endif
				prgchWord[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		if (NULL != prgchWritingSystem && cchMaxWritingSystem > 1)
		{
			if (FAILED(hr = pfwrd->get_WritingSystem(&bstr)) || NULL == bstr)
				prgchWritingSystem[0] = 0;
			else
			{
#ifdef _UNICODE
				int cch = min(cchMaxWritingSystem - 1, BstrLen(bstr));
				memcpy(prgchWritingSystem, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchWritingSystem, cchMaxWritingSystem - 1, NULL, NULL);
#endif
				prgchWritingSystem[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		ReleaseObj(pfwrd);
		return S_OK;
	}

	HRESULT SetWordFocus(LPCTSTR pszWord, LPCTSTR pszWritingSystem)
	{
		IWordFocusInit * pfwri;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp || NULL == m_pfobj->m_pfman)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfman->CreateWordFocus(&pfwri)))
			return hr;
#ifdef _UNICODE
		if (FAILED(hr = pfwri->InitWide(static_cast<IFocusableObject *>(m_pfobj),
				pszWord, pszWritingSystem)))
		{
			ReleaseObj(pfwri);
			return hr;
		}
#else
		if (FAILED(hr = pfwri->InitMultiByte(static_cast<IFocusableObject *>(m_pfobj),
				pszWord, pszWritingSystem)))
		{
			ReleaseObj(pfwri);
			return hr;
		}
#endif
		hr = m_pfobj->m_pfgrp->putref_Focus(pfwri);
		ReleaseObj(pfwri);
		return hr;
	}

	HRESULT GetScriptureReferenceFocusInformation(TCHAR *prgchScriptureReference, int cchMaxScriptureReference)
	{
		IFocus *pfocs;
		IScriptureReferenceFocus *pfscr;
		BSTR bstr;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfgrp->get_Focus(&pfocs)))
			return hr;
		if (NULL == pfocs)
			return E_FAIL;
		hr = pfocs->QueryInterface(IID_IScriptureReferenceFocus, (void **)&pfscr);
		ReleaseObj(pfocs);
		if (FAILED(hr))
			return hr;
		if (NULL != prgchScriptureReference && cchMaxScriptureReference > 1) {
			if (FAILED(hr = pfscr->get_ScriptureReference(&bstr)) || NULL == bstr)
				prgchScriptureReference[0] = 0;
			else {
#ifdef _UNICODE
				int cch = min(cchMaxScriptureReference - 1, BstrLen(bstr));
				memcpy(prgchScriptureReference, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchScriptureReference, cchMaxScriptureReference - 1, NULL, NULL);
#endif
				prgchScriptureReference[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		ReleaseObj(pfscr);
		return S_OK;
	}

	HRESULT SetScriptureReferenceFocus(LPCTSTR pszScriptureReference)
	{
		IScriptureReferenceFocusInit *pfscr;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp || NULL == m_pfobj->m_pfman)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfman->CreateScriptureReferenceFocus(&pfscr)))
			return hr;
#ifdef _UNICODE
		if (FAILED(hr = pfscr->InitWide(static_cast<IFocusableObject *>(m_pfobj),
				pszScriptureReference)))
		{
			ReleaseObj(pfscr);
			return hr;
		}
#else
		if (FAILED(hr = pfscr->InitMultiByte(static_cast<IFocusableObject *>(m_pfobj),
				pszScriptureReference)))
		{
			ReleaseObj(pfscr);
			return hr;
		}
#endif
		hr = m_pfobj->m_pfgrp->putref_Focus(pfscr);
		ReleaseObj(pfscr);
		return hr;
	}

	HRESULT GetSenderInformation(TCHAR * prgchSender, int cchMaxSender,
		TCHAR * prgchGuid, int cchMaxGuid)
	{
		IFocus * pfocs;
		IFocusableObject * pfobj;
		BSTR bstr;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfgrp->get_Focus(&pfocs)))
			return hr;
		if (NULL == pfocs)
			return E_FAIL;
		hr = pfocs->get_Sender(&pfobj);
		ReleaseObj(pfocs);
		if (FAILED(hr))
			return hr;
		if (NULL != prgchSender && cchMaxSender > 1)
		{
			if (FAILED(hr = pfobj->get_UserString(&bstr)) || NULL == bstr)
				prgchSender[0] = 0;
			else
			{
#ifdef _UNICODE
				int cch = min(cchMaxSender - 1, BstrLen(bstr));
				memcpy(prgchSender, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchSender, cchMaxSender - 1, NULL, NULL);
#endif
				prgchSender[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		if (NULL != prgchGuid && cchMaxGuid > 1)
		{
			if (FAILED(hr = pfobj->get_GlobalUniqueId(&bstr)) || NULL == bstr)
				prgchGuid[0] = 0;
			else
			{
#ifdef _UNICODE
				int cch = min(cchMaxGuid - 1, BstrLen(bstr));
				memcpy(prgchGuid, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchGuid, cchMaxGuid - 1, NULL, NULL);
#endif
				prgchGuid[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		ReleaseObj(pfobj);
		return S_OK;
	}

	void SetCaps(long fopsCap)
	{
		if (NULL != m_pfobj)
		{
			m_pfobj->m_fopsCap = fopsCap;
			m_pfobj->put_FocusOptions(m_pfobj->m_fops);
		}
	}

	long GetOptions(void)
	{
		if (NULL == m_pfobj)
			return 0;
		return m_pfobj->m_fops;
	}

protected:
	// Member variables
	CFocusableObject<T> * m_pfobj;
};

#endif //CFOCUSTEMPLATE_INCLUDED
