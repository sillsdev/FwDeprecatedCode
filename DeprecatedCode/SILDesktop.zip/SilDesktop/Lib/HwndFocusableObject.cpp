/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: HwndFocusableObject.cpp
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the implementation for focusable object using message passing.
-----------------------------------------------------------------------------------------*/

/******************************************************************************************
Include files
******************************************************************************************/

#include "main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

//ENHANCE: do we need a constructor & destructor that has 'ModuleAddRef()' and 'ModuleRelease()'???

static DummyFactory g_fact("SIL.Desktop.CHwndFocusableObject");

STDMETHODIMP CHwndFocusableObject::QueryInterface(REFIID riid, void **ppv)
{
	if (!ppv)
		return E_POINTER;
	AssertPtr(ppv);
	*ppv = NULL;
	if (riid == IID_IUnknown)
		*ppv = static_cast<IUnknown *>(this);
	else if (riid == IID_IFocusableObjectInitHwnd)
		*ppv = static_cast<IFocusableObjectInitHwnd *>(this);
	else
		return E_NOINTERFACE;
	AddRef();
	return NOERROR;
}

/******************************************************************************************
	IFocusableObject Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Retrieves the focusable object's focus group, which can be sed to add or remove the 
	object from its focus group
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CHwndFocusableObject::get_FocusGroup(IFocusGroup ** ppfgrp)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(ppfgrp);

	*ppfgrp = m_qfgrp;
	AddRefObj(*ppfgrp);
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Confirms that the focusable object has been added to a focus group by giving it a
	pointer	to its focus group
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CHwndFocusableObject::putref_FocusGroup(IFocusGroup * pfgrp)
{
	BEGIN_COM_METHOD;
	ChkComArgPtrN(pfgrp);

	m_qfgrp = pfgrp;
	if (NULL != m_qfgrp.p)
		FocusChanged();
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Called by IFocusGroup as a notification of a change in focus
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CHwndFocusableObject::FocusChanged()
{
	BEGIN_COM_METHOD;

	if (0 != (m_grfops & kfopsReceive) && NULL != m_hwnd)
	{
		// Make sure we didn't set the focus.
		IFocus * pfocs;
		IFocusableObject * pfobj;
		HRESULT hr;

		if (FAILED(hr = m_qfgrp->get_Focus(&pfocs)))
			return hr;
		if (NULL == pfocs)
			return S_OK;
		hr = pfocs->get_Sender(&pfobj);
		ReleaseObj(pfocs);
		if (FAILED(hr))
			return hr;
		if (FEqualObjects(pfobj, static_cast<IFocusableObject *>(this)))
		{
			ReleaseObj(pfobj);
			return S_OK;
		}
		ReleaseObj(pfobj);
		::PostMessage((HWND)m_hwnd, m_wm, m_wp, m_lp);
	}
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Retrieves focus options to be kfopsSend and/or kfopsReceive, or kfopsNil
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CHwndFocusableObject::get_FocusOptions(int * pgrfops)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pgrfops);

	*pgrfops = m_grfops;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Sets focus options to be kfopsSend and/or kfopsReceive, or kfopsNil
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CHwndFocusableObject::put_FocusOptions(int grfops)
{
	BEGIN_COM_METHOD;
	m_grfops = grfops & m_grfopsCap;
	return S_OK;
	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Retrieves the focus options this focusable object is capable of having, kfopsSend 
	and/or kfopsReceive, or kfopsNil
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CHwndFocusableObject::get_FocusCapabilities(int * pgrfops)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pgrfops);

	*pgrfops = m_grfopsCap;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/*-----------------------------------------------------------------------------------------
	Retrieves the string used to identify the focusable object
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CHwndFocusableObject::get_Name(BSTR * pbstr)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pbstr);

	if (NULL == pbstr)
		return E_POINTER;
	AssertPtr(pbstr);
	return SetBstr(pbstr, m_qbstrName);

	END_COM_METHOD(g_fact, IID_IFocusableObject);
}

/******************************************************************************************
	IFocusableObjectInitHwnd Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Initializes the focusable object for communicating with the host application using
	windows messaging.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CHwndFocusableObject::Init(long hwnd, long wm, long wp, long lp, 
	int grfopsCap, BSTR bstrName)
{
	BEGIN_COM_METHOD;
	ChkComBstrArgN(bstrName);

	HRESULT hr;

	if (NULL == hwnd)
		return E_FAIL;
	if (NULL != m_hwnd)
		return E_FAIL;

	if (FAILED(hr = SetBstr(&m_qbstrName, bstrName)))
		return hr;
	m_wm = (UINT)wm;
	m_wp = (WPARAM)wp;
	m_lp = (LPARAM)lp;
	m_grfopsCap = grfopsCap;
	m_grfops = grfopsCap & kfopsReceive;
	m_hwnd = hwnd;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusableObjectInitHwnd);
}

/*-----------------------------------------------------------------------------------------
	Sets the handle to the window to NULL.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP CHwndFocusableObject::Close(void)
{
	BEGIN_COM_METHOD;
	m_hwnd = NULL;
	return S_OK;
	END_COM_METHOD(g_fact, IID_IFocusableObjectInitHwnd);
}