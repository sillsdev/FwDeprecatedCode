/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: FocusTemplate.h
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Templates for integrating FocusManager support.
	
	To use this:
	* Include this header file and embed an instance of FocusableObjectStub in client code.
	* Client code will generally call only methods on FocusableObjectStub defined
		below.
-----------------------------------------------------------------------------------------*/

#pragma once
#ifndef FOCUSTEMPLATE_INCLUDED
#define FOCUSTEMPLATE_INCLUDED


#include "Common.h"

/******************************************************************************************
Forward declarations
******************************************************************************************/
template<class T>
class FocusableObjectStub;

/*-----------------------------------------------------------------------------------------
Class FocusableObject
Description: Implements the focusable object which communicates with the focus manager.
Hungarian: fobj
-----------------------------------------------------------------------------------------*/

template <class T>
class FocusableObject : public IFocusableObject
{
public:
	// Static methods
	static HRESULT Create(T * phost, LPCTSTR pszUser, LPCTSTR pszGuid, long fopsInit,
		FocusableObject<T> ** ppfobj)
	{
		AssertPtr(ppfobj);
		HRESULT hr;

		*ppfobj = new FocusableObject<T>();
		if (NULL == *ppfobj)
			return E_OUTOFMEMORY;
		if (FAILED(hr = (*ppfobj)->Init(phost, pszUser, pszGuid, fopsInit)))
		{
			ReleaseObj(*ppfobj);
			return hr;
		}
		return S_OK;
	}

/******************************************************************************************
	IUnknown Methods
******************************************************************************************/

	STDMETHOD(QueryInterface)(REFIID riid, void ** ppv)
	{
		if (!ppv)
			return E_POINTER;
		*ppv = NULL;
		if (riid == IID_IUnknown)
			*ppv = static_cast<IUnknown *>(static_cast<IFocusManager *>(this));
		else if (riid == IID_IFocusManager)
			*ppv = static_cast<IFocusManager *>(this);
		else
			return E_NOINTERFACE;
		reinterpret_cast<IUnknown *>(*ppv)->AddRef();
		return S_OK;
	}
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return ModuleEntry::ModuleAddRef();
	}
	STDMETHOD_(ULONG, Release)(void)
	{
		return ModuleEntry::ModuleRelease();
	}

/******************************************************************************************
	IFocusableObject Methods
******************************************************************************************/

	STDMETHOD(FocusChanged)(void)
	{
		if (NULL !=m_phost != NULL && (m_fops & kfoReceive))
			m_phost->FocusChanged();
		return S_OK;
	}

	STDMETHOD(get_FocusGroup)(IFocusGroup ** ppfgrp)
	{
		if (NULL == ppfgrp)
			return E_POINTER;
		*ppfgrp = m_pfgrp;
		AddRefObj(*ppfgrp);
		return S_OK;
	}

	STDMETHOD(putref_FocusGroup)(IFocusGroup * pfgrp)
	{
		if (NULL == m_phost)
			return E_FAIL;
		SetObj(&m_pfgrp, pfgrp);
		if (NULL != m_pfgrp)
			FocusChanged();
		return S_OK;
	}

	STDMETHOD(get_FocusOptions)(long * pfops)
	{
		if (NULL == pfops)
			return E_POINTER;
		*pfops = m_fops;
		return S_OK;
	}

	STDMETHOD(put_FocusOptions)(long fops)
	{
		if (NULL == m_phost)
			return E_FAIL;
		if (m_fops == (fops & m_fopsCap))
			return S_OK;
		m_fops = fops & m_fopsCap;
		m_phost->FocusOptionsChanged(fops);
		return S_OK;
	}

	STDMETHOD(get_FocusCapabilities)(long * pfops)
	{
		if (NULL == pfops)
			return E_POINTER;
		*pfops = m_fopsCap;
		return S_OK;
	}

	STDMETHOD(get_UserString)(BSTR * pbstr)
	{
		if (NULL == pbstr)
			return E_POINTER;
		*pbstr = NULL;
		return SetBstr(pbstr, m_bstrUser);
	}

	STDMETHOD(get_GlobalUniqueId)(BSTR * pbstr)
	{
		if (NULL == pbstr)
			return E_POINTER;
		*pbstr = NULL;
		return SetBstr(pbstr, m_bstrGuid);
	}

protected:
	// Member variables
	friend class FocusableObjectStub<T>;
	long m_cref;
	IFocusGroup * m_pfgrp;
	IFocusManager * m_pfman;
	T * m_phost;
	long m_fops;
	long m_fopsCap;
	BSTR m_bstrUser;
	BSTR m_bstrGuid;

	// Constructor/Destructor
	FocusableObject(void)
	{
		m_cref = 1;
		m_pfgrp = NULL;
		m_pfman = NULL;
		m_phost = NULL;
		m_fops = kfoSend | kfoReceive;
		m_fopsCap = kfoSend | kfoReceive;
		m_bstrUser = NULL;
		m_bstrGuid = NULL;
	}

	virtual ~FocusableObject(void)
	{
		AddRef();
		Close();
	}

	// Protected methods
	virtual void Close(void)
	{
		AddRef();
		if (NULL != m_pfman)
		{
			m_pfman->UnregisterFocusableObject(static_cast<IFocusableObject *>(this));
			ReleaseObj(m_pfman);
		}
		ReleaseObj(m_pfgrp);
		ReleaseBstr(m_bstrUser);
		ReleaseBstr(m_bstrGuid);
		m_phost = NULL;
		Release();
	}

	HRESULT SetHost(T * phost)
	{
		HRESULT hr;
		CLSID clsid;

		if (NULL == phost)
		{
			Close();
			return S_OK;
		}

		if (NULL != m_phost)
			return E_FAIL;
		if (FAILED(hr = CLSIDFromProgID(L"SilDesktop.FocusManager.1", &clsid)))
			return hr;
		if (FAILED(hr = CoCreateInstance(clsid, NULL, CLSCTX_ALL, IID_IFocusManager,
			(void **)&m_pfman)))
			return hr;
		m_phost = phost;
		if (FAILED(hr = m_pfman->RegisterFocusableObject(static_cast<IFocusableObject *>
			(this))))
		{
			m_phost = NULL;
			return hr;
		}
		return NOERROR;
	}

	HRESULT Init(T * phost, LPCTSTR pszUser, LPCTSTR pszGuid, long fopsInit)
	{
		HRESULT hr;

		m_fops = fopsInit;
		m_fopsCap |= fopsInit;
		if (NULL == phost)
			return E_POINTER;
		if (FAILED(hr = SetBstr(&m_bstrUser, pszUser)))
			return hr;
		if (FAILED(hr = SetBstr(&m_bstrGuid, pszGuid)))
			return hr;
		if (FAILED(hr = SetHost(phost)))
			return hr;
		return S_OK;
	}
};

/*-----------------------------------------------------------------------------------------
Class FocusableObjectStub
Description: Implements the stub which encapsulates the focusable object and is embedded
	in other classes for communicating between the class and the focus manager
Hungarian: fobj
-----------------------------------------------------------------------------------------*/
template<class T>
class FocusableObjectStub
{
public:
	// Constructor/Destructor
	FocusableObjectStub(void)
	{
		m_pfobj = NULL;
	}
	~FocusableObjectStub(void)
	{
		Close();
	}

/******************************************************************************************
	Methods
******************************************************************************************/

	HRESULT Init(T * phost, LPCTSTR pszUser, LPCTSTR pszGuid, long fopsInit)
	{
		if (NULL != m_pfobj)
			return E_FAIL;
		return FocusableObject<T>::Create(phost, pszUser, pszGuid, fopsInit, &m_pfobj);
	}

	void Close(void)
	{
		if (NULL != m_pfobj)
		{
			m_pfobj->SetHost(NULL);
			ReleaseObj(m_pfobj);
		}
	}

	void LaunchFocusDialog(void)
	{
		if (NULL != m_pfobj && NULL != m_pfobj->m_pfman)
			m_pfobj->m_pfman->LaunchFocusDialog(static_cast<IFocusableObject *>(m_pfobj));
	}

	HRESULT GetWordFocusInformation(TCHAR * prgchWord, int cchMaxWord,
		TCHAR * prgchWritingSystem, int cchMaxWritingSystem)
	{
		IFocus * pfocs;
		IWordFocus * pfwrd;
		BSTR bstr;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfgrp->get_Focus(&pfocs)))
			return hr;
		if (NULL == pfocs)
			return E_FAIL;
		hr = pfocs->QueryInterface(IID_IWordFocus, (void **)&pfwrd);
		ReleaseObj(pfocs);
		if (FAILED(hr))
			return hr;
		if (NULL != prgchWord && cchMaxWord > 1)
		{
			if (FAILED(hr = pfwrd->get_Word(&bstr)) || NULL == bstr)
				prgchWord[0] = 0;
			else
			{
#ifdef _UNICODE
				int cch = min(cchMaxWord - 1, BstrLen(bstr));
				memcpy(prgchWord, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchWord, cchMaxWord - 1, NULL, NULL);
#endif
				prgchWord[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		if (NULL != prgchWritingSystem && cchMaxWritingSystem > 1)
		{
			if (FAILED(hr = pfwrd->get_WritingSystem(&bstr)) || NULL == bstr)
				prgchWritingSystem[0] = 0;
			else
			{
#ifdef _UNICODE
				int cch = min(cchMaxWritingSystem - 1, BstrLen(bstr));
				memcpy(prgchWritingSystem, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchWritingSystem, cchMaxWritingSystem - 1, NULL, NULL);
#endif
				prgchWritingSystem[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		ReleaseObj(pfwrd);
		return S_OK;
	}

	HRESULT SetWordFocus(LPCTSTR pszWord, LPCTSTR pszWritingSystem)
	{
		IWordFocusInit * pfwri;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp || NULL == m_pfobj->m_pfman)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfman->CreateWordFocus(&pfwri)))
			return hr;
#ifdef _UNICODE
		if (FAILED(hr = pfwri->InitWide(static_cast<IFocusableObject *>(m_pfobj),
				pszWord, pszWritingSystem)))
		{
			ReleaseObj(pfwri);
			return hr;
		}
#else
		if (FAILED(hr = pfwri->InitMultiByte(static_cast<IFocusableObject *>(m_pfobj),
				pszWord, pszWritingSystem)))
		{
			ReleaseObj(pfwri);
			return hr;
		}
#endif
		hr = m_pfobj->m_pfgrp->putref_Focus(pfwri);
		ReleaseObj(pfwri);
		return hr;
	}

	HRESULT GetScriptureReferenceFocusInformation(TCHAR *prgchScriptureReference, int cchMaxScriptureReference)
	{
		IFocus *pfocs;
		IScriptureReferenceFocus *pfscr;
		BSTR bstr;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfgrp->get_Focus(&pfocs)))
			return hr;
		if (NULL == pfocs)
			return E_FAIL;
		hr = pfocs->QueryInterface(IID_IScriptureReferenceFocus, (void **)&pfscr);
		ReleaseObj(pfocs);
		if (FAILED(hr))
			return hr;
		if (NULL != prgchScriptureReference && cchMaxScriptureReference > 1) {
			if (FAILED(hr = pfscr->get_ScriptureReference(&bstr)) || NULL == bstr)
				prgchScriptureReference[0] = 0;
			else {
#ifdef _UNICODE
				int cch = min(cchMaxScriptureReference - 1, BstrLen(bstr));
				memcpy(prgchScriptureReference, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchScriptureReference, cchMaxScriptureReference - 1, NULL, NULL);
#endif
				prgchScriptureReference[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		ReleaseObj(pfscr);
		return S_OK;
	}

	HRESULT SetScriptureReferenceFocus(LPCTSTR pszScriptureReference)
	{
		IScriptureReferenceFocusInit *pfscr;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp || NULL == m_pfobj->m_pfman)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfman->CreateScriptureReferenceFocus(&pfscr)))
			return hr;
#ifdef _UNICODE
		if (FAILED(hr = pfscr->InitWide(static_cast<IFocusableObject *>(m_pfobj),
				pszScriptureReference)))
		{
			ReleaseObj(pfscr);
			return hr;
		}
#else
		if (FAILED(hr = pfscr->InitMultiByte(static_cast<IFocusableObject *>(m_pfobj),
				pszScriptureReference)))
		{
			ReleaseObj(pfscr);
			return hr;
		}
#endif
		hr = m_pfobj->m_pfgrp->putref_Focus(pfscr);
		ReleaseObj(pfscr);
		return hr;
	}

	HRESULT GetSenderInformation(TCHAR * prgchSender, int cchMaxSender,
		TCHAR * prgchGuid, int cchMaxGuid)
	{
		IFocus * pfocs;
		IFocusableObject * pfobj;
		BSTR bstr;
		HRESULT hr;

		if (NULL == m_pfobj || NULL == m_pfobj->m_pfgrp)
			return E_FAIL;
		if (FAILED(hr = m_pfobj->m_pfgrp->get_Focus(&pfocs)))
			return hr;
		if (NULL == pfocs)
			return E_FAIL;
		hr = pfocs->get_Sender(&pfobj);
		ReleaseObj(pfocs);
		if (FAILED(hr))
			return hr;
		if (NULL != prgchSender && cchMaxSender > 1)
		{
			if (FAILED(hr = pfobj->get_UserString(&bstr)) || NULL == bstr)
				prgchSender[0] = 0;
			else
			{
#ifdef _UNICODE
				int cch = min(cchMaxSender - 1, BstrLen(bstr));
				memcpy(prgchSender, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchSender, cchMaxSender - 1, NULL, NULL);
#endif
				prgchSender[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		if (NULL != prgchGuid && cchMaxGuid > 1)
		{
			if (FAILED(hr = pfobj->get_GlobalUniqueId(&bstr)) || NULL == bstr)
				prgchGuid[0] = 0;
			else
			{
#ifdef _UNICODE
				int cch = min(cchMaxGuid - 1, BstrLen(bstr));
				memcpy(prgchGuid, bstr, cch * sizeof(OLECHAR));
#else
				int cch = WideCharToMultiByte(CP_ACP, 0, bstr, BstrLen(bstr),
					prgchGuid, cchMaxGuid - 1, NULL, NULL);
#endif
				prgchGuid[cch] = 0;
				ReleaseBstr(bstr);
			}
		}
		ReleaseObj(pfobj);
		return S_OK;
	}

	void SetCaps(long fopsCap)
	{
		if (NULL != m_pfobj)
		{
			m_pfobj->m_fopsCap = fopsCap;
			m_pfobj->put_FocusOptions(m_pfobj->m_fops);
		}
	}

	long GetOptions(void)
	{
		if (NULL == m_pfobj)
			return 0;
		return m_pfobj->m_fops;
	}

protected:
	// Member variables
	FocusableObject<T> * m_pfobj;
};

#endif //FOCUSTEMPLATE_INCLUDED
