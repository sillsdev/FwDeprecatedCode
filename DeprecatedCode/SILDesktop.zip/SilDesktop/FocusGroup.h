/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: FocusGroup.h
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the interface for the focus group.
----------------------------------------------------------------------------------------------*/

#pragma once
#ifndef FOCUSGROUP_INCLUDED
#define FOCUSGROUP_INCLUDED

/*----------------------------------------------------------------------------------------------
Class: FocusGroup
Description: Implements the focus group, identified by a string, stores all objects as
	members of this focus group, and notifies the objects when focus changes.
Hungarian: fgrp
----------------------------------------------------------------------------------------------*/
class FocusGroup : public IFocusGroup
{
public:
	// Static methods
	static void CreateCom(IUnknown *punkOuter, REFIID iid, void ** ppv);


	// IUnknown methods.
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppv);

	STDMETHOD_(ULONG, AddRef)(void)
	{
		return InterlockedIncrement(&m_cref);
	}
	STDMETHOD_(ULONG, Release)(void)
	{
		long cref = InterlockedDecrement(&m_cref);
		if (cref == 0) {
			m_cref = 1;
			delete this;
		}
		return cref;
	}

	// IFocusGroup
	STDMETHOD(get_Focus)( IFocus ** ppfocs);
	STDMETHOD(putref_Focus)(IFocus * pfocs);
	STDMETHOD(get_Name)(BSTR *pbstr);

	// Member variable access

	// Other public methods
	void FinalRelease()
	{
		Close();
	}

	int Size(void)
	{
		return m_vpfobj.Size();
	}

	HRESULT Close(void);
	HRESULT AddFocusableObject(IFocusableObject * pfobj);
	HRESULT DelFocusableObject(IFocusableObject * pfobj);

	HRESULT AssignName(BSTR bstrName);
	void GetMyVector(Vector<IFocusableObject *> ** ppvpfobj);

	void Idle(void);
	// Constructors/destructor
	FocusGroup();
	~FocusGroup();

protected:

	// Member variables
	long m_cref;
	Vector<IFocusableObject *> m_vpfobj;
	ComSmartPtr<IFocus> m_qfocs;
	SmartBstr m_sbstrGroup;
	ComSmartPtr<IFocusableObject> m_qfobjOwner;
	int m_ipfobjCur;	// Current object we're broadcasting to.
	bool m_fFocusChanged;

	// Static methods


	// Other protected methods
	int FindObject(IUnknown * punk);
};

DEFINE_COM_PTR(FocusGroup);

#endif //FOCUSGROUP_INCLUDED
