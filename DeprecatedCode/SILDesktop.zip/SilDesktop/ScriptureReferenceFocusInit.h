/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: ScriptureReferenceFocusInit.h
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the interface for the helper class which creates and initializes a scripture 
	reference focus object, containing a scripture reference defined by a Book, Chapter,
	Verse, and Versification scheme.
-----------------------------------------------------------------------------------------*/

#pragma once
#ifndef SCRIPTUREREFERENCEFOCUSINIT_INCLUDED
#define SCRIPTUREREFERENCEFOCUSINIT_INCLUDED

#include "resource.h"       // main symbols

/*-----------------------------------------------------------------------------------------
Class: ScriptureReferenceFocusInit
Description: Implements the focus object which stores a scripture reference.
Hungarian: fsci
-----------------------------------------------------------------------------------------*/
class ScriptureReferenceFocusInit : public IScriptureReferenceFocusInit
{
public:
	// Static methods
	static void CreateCom(IUnknown *punkOuter, REFIID iid, void ** ppv);

	// IUnknown methods.
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppv);
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return InterlockedIncrement(&m_cref);
	}
	STDMETHOD_(ULONG, Release)(void)
	{
		long cref = InterlockedDecrement(&m_cref);
		if (cref == 0) {
			m_cref = 1;
			delete this;
		}
		return cref;
	}


	// Methods
	void FinalRelease()
	{
	}


	// IFocus
	STDMETHOD(get_Sender)(IFocusableObject ** ppfobj);
	STDMETHOD(get_CountTypes)(int * pcft);
	STDMETHOD(get_Type)(int ift, int * pft);

	// IScriptureReferenceFocus
	STDMETHOD(get_Book)(int * pnBook);
	STDMETHOD(get_Chapter)(int * pnChapter);
	STDMETHOD(get_Verse)(int * pnVerse);
	STDMETHOD(get_Versification)(int * pnVersification);
	STDMETHOD(ScriptureReferenceInfo)(int *pnBook, int * pnChapter,
		int * pnVerse, int * pnVersification);

	// IScriptureReferenceFocusInit
	STDMETHOD(Init)(IFocusableObject * pfobj, int nBook,
		int nChapter, int nVerse, int nVersification);
	STDMETHOD(Close)(void);

protected:
	// Constructors/destructor
	ScriptureReferenceFocusInit();
	~ScriptureReferenceFocusInit();

	// Member variables
	long m_cref;
	ComSmartPtr<IFocusableObject> m_qfobjSender;
	int m_nBook;
	int m_nChapter;
	int m_nVerse;
	int m_nVersification;
};

DEFINE_COM_PTR(ScriptureReferenceFocusInit);

#endif //SCRIPTUREREFERENCEFOCUSINIT_INCLUDED
