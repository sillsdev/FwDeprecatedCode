//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SILDesktop.rc
//
#define IDS_PROJNAME								  100
#define IDR_SILDesktop								  100
#define IDR_FOCUSMANAGER							  101
//#define IDR_WORDFOCUSINIT							  102
//#define IDR_HWNDFOCUSABLEOBJECT						  103
//#define IDR_DISPFOCUSABLEOBJECT						  104
#define IDD_CONFIGURATION							  105
//#define IDR_SCRIPTUREREFERENCEFOCUSINIT               106
#define IDC_LIST_APPS                   204
#define IDC_CHECK_SNDFOCUS              205
#define IDC_CHECK_RCVFOCUS              206
#define IDC_CLOSE						207

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         208
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
