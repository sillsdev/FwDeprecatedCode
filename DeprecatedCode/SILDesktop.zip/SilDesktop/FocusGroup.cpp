/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: FocusGroup.cpp
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the implementation for the focus group, which keeps track of all focusable
	objects and broadcasts focus to them when the focus changes.
-----------------------------------------------------------------------------------------*/

/******************************************************************************************
Include files
******************************************************************************************/
#include "main.h"
#pragma hdrstop
// any other headers (not precompiled)

#undef THIS_FILE
DEFINE_THIS_FILE

/***********************************************************************************************
    Forward declarations
***********************************************************************************************/

/***********************************************************************************************
    Constructors and Destructor
***********************************************************************************************/
FocusGroup::FocusGroup()
{
	m_cref = 1;
	ModuleEntry::ModuleAddRef();
	m_ipfobjCur = 0;
	m_fFocusChanged = false;
}

FocusGroup::~FocusGroup()
{
	ModuleEntry::ModuleRelease();
}

/***********************************************************************************************
    Generic factory stuff to allow creating an instance with CoCreateInstance.
***********************************************************************************************/
static GenericFactory g_fact(
	"SIL.SilDesktop.FocusGroup",	
	&CLSID_FocusGroup,	
	"SIL Focus Group",
	"Both",
	&FocusGroup::CreateCom);

/*----------------------------------------------------------------------------------------------
	Called by the GenericFactory to "create" an IFocusGroup.It just returns the global one.
----------------------------------------------------------------------------------------------*/
void FocusGroup::CreateCom(IUnknown *punkCtl, REFIID iid, void ** ppv)
{
	AssertPtr(ppv);
	Assert(!*ppv);
	if (punkCtl)
		ThrowHr(WarnHr(CLASS_E_NOAGGREGATION));

	ComSmartPtr<FocusGroup> qfgrp;
	qfgrp.Attach(NewObj FocusGroup());		// ref count initially 1
	CheckHr(qfgrp->QueryInterface(riid, ppv));
}

/***********************************************************************************************
    IUnknown Methods
***********************************************************************************************/
STDMETHODIMP FocusGroup::QueryInterface(REFIID riid, void **ppv)
{
	if (!ppv)
		return E_POINTER;
	AssertPtr(ppv);
	*ppv = NULL;
	if (riid == IID_IUnknown)
		*ppv = static_cast<IUnknown *>(static_cast<IFocusGroup *>(this));
	else if (riid == IID_IFocusGroup)
		*ppv = static_cast<IFocusGroup *>(this);
	else
		return E_NOINTERFACE;

	reinterpret_cast<IUnknown *>(*ppv)->AddRef();
	return S_OK;
}

/******************************************************************************************
	IFocusGroup Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Returns the current focus object.
	Argument:
		ppfocs		pointer to a pointer to the current focus object
-----------------------------------------------------------------------------------------*/
STDMETHODIMP FocusGroup::get_Focus(IFocus ** ppfocs)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(ppfocs);

	*ppfocs = m_qfocs;
	AddRefObj(*ppfocs);
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusGroup);
}

/*-----------------------------------------------------------------------------------------
	Assigns a new focus object and broadcasts it to the focusable objects.
	Argument:
		pfocs		pointer to the new focus object
-----------------------------------------------------------------------------------------*/
STDMETHODIMP FocusGroup::putref_Focus(IFocus * pfocs)
{
	BEGIN_COM_METHOD;
	ChkComArgPtrN(pfocs);

	ComSmartPtr<IFocusableObject> qfobjOwner;
	ComSmartPtr<IFocusableObject> qfobj;
	ComSmartPtr<IFocus> qfocs(pfocs);
	HRESULT hr;

	if (NULL != qfocs.p && FAILED(hr = qfocs->get_Sender(&qfobjOwner)))
		return E_FAIL;
	m_qfocs = qfocs;
	m_qfobjOwner = qfobjOwner;

	if (NULL == m_qfocs.p)
	{
		m_ipfobjCur = 0;
		return S_OK;
	}

	// If we're already broadcasting the focus, just restart the loop that's
	// lower on the call stack.
	// REVIEW: Is this the right thing to do or should putref_Focus fail if
	// we're currently broadcasting?
	if (0 < m_ipfobjCur)
	{
		m_ipfobjCur = m_vpfobj.Size();
		return S_OK;
	}

	m_fFocusChanged = true;
	// may have to kill timer first
	::KillTimer(NULL, g_uTimer);
	g_uTimer = ::SetTimer(NULL, 0, 1, NULL);

	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusGroup);
}

/*-----------------------------------------------------------------------------------------
	A focus group is identified by its name.
	Argument:
		pbstr		a pointer to the name of the focus group
-----------------------------------------------------------------------------------------*/
STDMETHODIMP FocusGroup::get_Name(BSTR * pbstr)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pbstr);

	m_sbstrGroup.Copy(pbstr);

	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocusGroup);
}

/******************************************************************************************
	Other Public Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Resets variables and calls Release for objects in the focus group.
-----------------------------------------------------------------------------------------*/
HRESULT FocusGroup::Close(void)
{
	IFocusableObject * pfobj;

	m_ipfobjCur = 0;
	m_qfocs.Release();
	m_qfobjOwner.Release();

	while (SUCCEEDED(m_vpfobj.Pop(&pfobj)))
	{
		pfobj->putref_FocusGroup(NULL);
		pfobj->Release();
	}

	return S_OK;
}

/*-----------------------------------------------------------------------------------------
	Adds a focusable object to the vector in the focus group.
	Argument:
		pfobj		the focusable object to be added to the focus group
-----------------------------------------------------------------------------------------*/
HRESULT FocusGroup::AddFocusableObject(IFocusableObject * pfobj)
{
	AssertPtr(pfobj);

	HRESULT hr;

	if (NULL == pfobj)
		return E_POINTER;
	if (0 <= FindObject(pfobj))
		return E_FAIL;
	hr = m_vpfobj.Push(pfobj);
	if (FAILED(hr))
		return hr;
	pfobj->AddRef();
	hr = pfobj->putref_FocusGroup(static_cast<IFocusGroup *>(this));

	if (FAILED(hr))
	{
		// Most likely, pfobj is the last element, but not necessarily.
		for (int ipfobj = m_vpfobj.Size(); ipfobj > 0; )
		{
			if (pfobj == m_vpfobj[--ipfobj])
			{
				m_vpfobj.Delete(ipfobj);
				pfobj->Release();
				break;
			}
		}
		return hr;
	}

	return S_OK;
}

/*-----------------------------------------------------------------------------------------
	Deletes a focusable object from the vector in the focus group.
	Argument:
		pfobj		the focusable object to be deleted from the focus group
-----------------------------------------------------------------------------------------*/
HRESULT FocusGroup::DelFocusableObject(IFocusableObject * pfobj)
{
	AssertPtrN(pfobj);

	if (NULL == pfobj)
		return E_POINTER;
	int ipfobj = FindObject(pfobj);
	if (0 > ipfobj)
		return E_FAIL;

	static_cast<IFocusGroup *>(this)->AddRef();

	IFocusableObject * pfobjOld = m_vpfobj[ipfobj];
	pfobjOld->putref_FocusGroup(NULL);
	m_vpfobj.Delete(ipfobj);

	// If we're currently broadcasting adjust the current index.
	if (ipfobj < m_ipfobjCur)
		m_ipfobjCur--;

	if (FEqualObjects(m_qfobjOwner, pfobjOld))
	{
		putref_Focus(NULL);
		Assert(NULL == m_qfobjOwner.p);
		Assert(0 == m_ipfobjCur);
	}
	ReleaseObj(pfobjOld);

	static_cast<IFocusGroup *>(this)->Release();
	return S_OK;
}

/*-----------------------------------------------------------------------------------------
	Assigns a focus group its name.
	Argument:
		bstrName	the name of the focus group
-----------------------------------------------------------------------------------------*/
HRESULT FocusGroup::AssignName(BSTR bstrName)
{
	if (NULL == bstrName)
		return E_POINTER;
	try
	{
		m_sbstrGroup = bstrName;
	}
	catch (Throwable & thr)
	{
		return thr.Error();
	}
	catch (...)
	{
		return WarnHr(E_FAIL);
	}
	return S_OK;
}

/*-----------------------------------------------------------------------------------------
	Returns a pointer to the vector of focusable objects.
	Argument:
		ppvpfobj		contains the focusable objects in this focus group
-----------------------------------------------------------------------------------------*/
void FocusGroup::GetMyVector(Vector<IFocusableObject *> ** ppvpfobj)
{
	*ppvpfobj = &m_vpfobj;
}

/*-----------------------------------------------------------------------------------------
	If the focus has changed, broadcasts the current focus to the focusable objects.
-----------------------------------------------------------------------------------------*/
void FocusGroup::Idle(void)
{
	if (!m_fFocusChanged)
		return;

	// broadcast only if focus has changed
	m_fFocusChanged = false;
	if (!m_qfocs)
		return;

	ComSmartPtr<IFocusableObject> qfobj;
	//broadcast loop
	for (m_ipfobjCur = m_vpfobj.Size(); m_ipfobjCur > 0; )
	{
		qfobj = m_vpfobj[--m_ipfobjCur];
		// only call FocusChanged() if the object is not the sender
		if (!FEqualObjects(qfobj, m_qfobjOwner))
			qfobj->FocusChanged();
	}
}

/******************************************************************************************
	Other Protected Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Given an IUnknown interface pointer, finds the object in the vector and returns the 
		index if the object is found. Otherwise, returns -1.
	Argument:
		punk		the focusable object to be found in the focus group
-----------------------------------------------------------------------------------------*/
int FocusGroup::FindObject(IUnknown * punk)
{
	AssertPtrN(punk);

	HRESULT hr;
	IUnknown * punkT;
	IUnknown * punkT2;
	int ipfobj;

	// First just do a normal binary compare.
	for (ipfobj = m_vpfobj.Size(); ipfobj > 0; )
	{
		if (punk == m_vpfobj[--ipfobj])
			return ipfobj;
	}
	if (NULL == punk)
		return -1;

	// Now do IUnknown compares.
	hr = punk->QueryInterface(IID_IUnknown, (void **)&punkT);
	if (SUCCEEDED(hr))
	{
		punkT->Release();
		punk = punkT;
	}

	for (ipfobj = m_vpfobj.Size(); ipfobj > 0; )
	{
		punkT = m_vpfobj[--ipfobj];
		if (NULL == punkT)
			continue;
		hr = punkT->QueryInterface(IID_IUnknown, (void **)&punkT2);
		if (FAILED(hr))
			continue;
		AssertPtr(punkT2);
		punkT2->Release();
		if (punkT2 == punk)
			return ipfobj;
	}

	return -1;
}

