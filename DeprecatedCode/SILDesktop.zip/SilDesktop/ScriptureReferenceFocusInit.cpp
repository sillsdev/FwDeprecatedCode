/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: ScriptureReferenceFocusInit.cpp
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the implementation of the helper class which creates and initializes a scripture
	reference focus object with the sender, the type of focus, the Book, Chapter, Verse, and
	Versification scheme.
-----------------------------------------------------------------------------------------*/

/******************************************************************************************
Include files
******************************************************************************************/
#include "main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

/***********************************************************************************************
    Forward declarations
***********************************************************************************************/

/***********************************************************************************************
    Constructors and Destructor
***********************************************************************************************/
ScriptureReferenceFocusInit::ScriptureReferenceFocusInit()
{
	m_cref = 1;
	ModuleEntry::ModuleAddRef();
}

ScriptureReferenceFocusInit::~ScriptureReferenceFocusInit()
{
	ModuleEntry::ModuleRelease();
}
/***********************************************************************************************
    Generic factory stuff to allow creating an instance with CoCreateInstance.
***********************************************************************************************/
static GenericFactory g_fact(
	"SIL.SilDesktop.ScriptureReferenceFocusInit",	
	&CLSID_ScriptureReferenceFocusInit,	
	"SIL Scripture Reference Focus Init",
	"Both",
	&ScriptureReferenceFocusInit::CreateCom);

/*----------------------------------------------------------------------------------------------
	Called by the GenericFactory to "create" an IFocusGroup.It just returns the global one.
----------------------------------------------------------------------------------------------*/
void ScriptureReferenceFocusInit::CreateCom(IUnknown *punkCtl, REFIID iid, void ** ppv)
{
	AssertPtr(ppv);
	Assert(!*ppv);
	if (punkCtl)
		ThrowHr(WarnHr(CLASS_E_NOAGGREGATION));

	ComSmartPtr<ScriptureReferenceFocusInit> qfsci;
	qfsci.Attach(NewObj ScriptureReferenceFocusInit());		// ref count initially 1
	CheckHr(qfsci->QueryInterface(riid, ppv));
}

/***********************************************************************************************
    IUnknown Methods
***********************************************************************************************/
STDMETHODIMP ScriptureReferenceFocusInit::QueryInterface(REFIID riid, void **ppv)
{
	if (!ppv)
		return E_POINTER;
	AssertPtr(ppv);
	*ppv = NULL;
	if (riid == IID_IUnknown)
		*ppv = static_cast<IUnknown *>(static_cast<IScriptureReferenceFocusInit *>(this));
	else if (riid == IID_IScriptureReferenceFocusInit)
		*ppv = static_cast<IScriptureReferenceFocusInit *>(this);
	else
		return E_NOINTERFACE;

	reinterpret_cast<IUnknown *>(*ppv)->AddRef();
	return S_OK;

}

/******************************************************************************************
	IFocus Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Used by the focus group to avoid sending the focus changed notification to the 
	focusable object which sent the focus.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::get_Sender(IFocusableObject ** ppfobj)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(ppfobj);

	*ppfobj = m_qfobjSender;
	AddRefObj(*ppfobj);
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocus);
}

/*-----------------------------------------------------------------------------------------
	Retrieves the number of the types of focus this focus object handles.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::get_CountTypes(int * pcft)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pcft);

	*pcft = 1;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocus);
}

/*-----------------------------------------------------------------------------------------
	Given an index, retrieves the corresponding type of focus handled.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::get_Type(int ift, int * pft)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pft);
	if (0 != ift)
		return E_INVALIDARG;

	*pft = kftScriptureReference;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IFocus);
}

/******************************************************************************************
	IScriptureReferenceFocus Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Retrieves a number which corresponds to the books of the OT, NT, and Apocrypha.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::get_Book(int * pnBook)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pnBook);

	*pnBook = m_nBook;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IScriptureReferenceFocus);
}

/*-----------------------------------------------------------------------------------------
	Retrieves a number specifying the chapter in focus.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::get_Chapter(int * pnChapter)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pnChapter);

	*pnChapter = m_nChapter;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IScriptureReferenceFocus);
}

/*-----------------------------------------------------------------------------------------
	Retrieves a number specifying the verse in focus.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::get_Verse(int * pnVerse)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pnVerse);

	*pnVerse = m_nVerse;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IScriptureReferenceFocus);
}

/*-----------------------------------------------------------------------------------------
	Retrieves an enumerated value specifying the versification scheme the scripture 
	reference is stored in.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::get_Versification(int * pnVersification)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pnVersification);

	*pnVersification = m_nVersification;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IScriptureReferenceFocus);
}

/*-----------------------------------------------------------------------------------------
	Retrieves all the current scripture reference focus information at once, the book,
	chapter, verse, and versification scheme.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::ScriptureReferenceInfo(int * pnBook, 
	int * pnChapter, int * pnVerse, int * pnVersification)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pnBook);
	ChkComOutPtr(pnChapter);
	ChkComOutPtr(pnVerse);
	ChkComOutPtr(pnVersification);

	*pnBook = m_nBook;
	*pnChapter = m_nChapter;
	*pnVerse = m_nVerse;
	*pnVersification = m_nVersification;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IScriptureReferenceFocus);
}

/******************************************************************************************
	IScriptureReferenceFocusInit Methods
******************************************************************************************/

/*-----------------------------------------------------------------------------------------
	Initializes the scripture reference focus object with the sender and scripture 
	reference in focus
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::Init(IFocusableObject * pfobj, int nBook,
	int nChapter, int nVerse, int nVersification)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pfobj);

	// If we've already been Init'ed don't allow being changed.
	if (NULL != m_qfobjSender.p)
		return E_FAIL;

	m_nBook = nBook;
	m_nChapter = nChapter;
	m_nVerse = nVerse;
	m_nVersification = nVersification;

	m_qfobjSender = pfobj;
	return S_OK;

	END_COM_METHOD(g_fact, IID_IScriptureReferenceFocusInit);
}

/*-----------------------------------------------------------------------------------------
	Calls Release() on the sender.
-----------------------------------------------------------------------------------------*/
STDMETHODIMP ScriptureReferenceFocusInit::Close(void)
{
	BEGIN_COM_METHOD;

	m_qfobjSender.Release();
	return S_OK;

	END_COM_METHOD(g_fact, IID_IScriptureReferenceFocusInit);
}