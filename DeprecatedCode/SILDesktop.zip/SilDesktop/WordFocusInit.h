/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: WordFocusInit.h
Responsibility: Felise Wu
Last reviewed: not yet.

Description:
	Defines the interface for the helper class which creates and initializes a word focus
	object, containing the word in focus and its writing system.
-----------------------------------------------------------------------------------------*/

#pragma once
#ifndef WORDFOCUSINIT_INCLUDED
#define WORDFOCUSINIT_INCLUDED

/*-----------------------------------------------------------------------------------------
Class WordFocusInit
Description: Implements the focus object which stores a word and its writing system.
Hungarian: fwri
-----------------------------------------------------------------------------------------*/
class WordFocusInit : public IWordFocusInit
{
public:
	// Static methods
	static void CreateCom(IUnknown *punkOuter, REFIID iid, void ** ppv);


	// IUnknown methods.
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppv);
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return InterlockedIncrement(&m_cref);
	}
	STDMETHOD_(ULONG, Release)(void)
	{
		long cref = InterlockedDecrement(&m_cref);
		if (cref == 0) {
			m_cref = 1;
			delete this;
		}
		return cref;
	}


	// Methods
	void FinalRelease()
	{
	}

	// IFocus
	STDMETHOD(get_Sender)(IFocusableObject ** ppfobj);
	STDMETHOD(get_CountTypes)(int * pcft);
	STDMETHOD(get_Type)(int ift, int * pft);

	// IWordFocus
	STDMETHOD(get_Word)(BSTR * pbstrWord);
	STDMETHOD(get_WritingSystem)(int * pnEncoding);
	STDMETHOD(WordInfo)(BSTR * pbstrWord, int * pnEncoding);

	// IWordFocusInit
	STDMETHOD(Init)(IFocusableObject * pfobj, BSTR bstrWord, int nEncoding);
	STDMETHOD(InitWide)(IFocusableObject * pfobj, LPCOLESTR pszWord, int nEncoding);
	STDMETHOD(InitMultiByte)(IFocusableObject * pfobj, LPCSTR pszWord, int nEncoding);
	STDMETHOD(Close)(void);

protected:
	// Constructors/destructor
	WordFocusInit();
	~WordFocusInit();


	// Member variables
	long m_cref;
	ComSmartPtr<IFocusableObject> m_qfobjSender;
	CComBSTR m_qbstrWord;
	int m_nEncoding;
};

DEFINE_COM_PTR(WordFocusInit);

#endif //WORDFOCUSINIT_INCLUDED
