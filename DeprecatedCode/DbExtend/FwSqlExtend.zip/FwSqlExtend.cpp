// FwSqlExtend.cpp : Defines the entry point for the dll application.

#include "main.h"

BOOL APIENTRY DllMain(HANDLE hModule, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		// Initialize the ICU data directory.  This has to be done before using any calls to
		// any ICU functions.
		
		StrUtil::InitIcuDataDir();
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		// Let ICU data free so files such as icudt26l_uprops.icu can be deleted
		// once this DLL is unloaded by DBCC FwSqlExtend (FREE)
		StrUtil::IcuCleanup();	// u_cleanup();
	}

    return TRUE;
}


// The following is needed to resolve various external symbols in linking with Generic.lib.
// Don't ask why -- i don't really know!

HMODULE ModuleEntry::s_hmod;
long ModuleEntry::s_crefModule;
ModuleEntry * ModuleEntry::s_pmeFirst;
StrAppBufPath ModuleEntry::s_strbpPath;
ulong ModuleEntry::s_tid;			// Stays zero for non-EXE modules.

ModuleEntry::ModuleEntry(void) :
	LLBase<ModuleEntry>(&s_pmeFirst)
{
}

long ModuleEntry::ModuleRelease(void)
{
	return 0;
}

const achar * ModuleEntry::GetModulePathName(void)
{
	return NULL;
}
