// stdafx.h : include file for standard system include files, or project specific include files
// that are used frequently, but are changed infrequently.

#pragma once
#ifndef DBEXTEND_STDAFX_H
#define DBEXTEND_STDAFX_H

// Insert your headers here
#include <stdio.h>
#include <stdlib.h>
#include "common.h"
//#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>

//Include ODS headers
#ifdef __cplusplus
extern "C" {
#endif 

#include <Srv.h>		// Main header file that includes all other header files

#ifdef __cplusplus
}
#endif 

#endif /*DBEXTEND_STDAFX_H*/
