/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: WFI.h
Responsibility: John Hatton
Last reviewed: never

Description:
	Contains the declaration of the class WFI, which implents IWFI.
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef WFI_INCLUDED
#define WFI_INCLUDED


/*----------------------------------------------------------------------------------------------
@h3{Hungarian: }
----------------------------------------------------------------------------------------------*/
class WFI : public IWFI, ISupportErrorInfo
{
public:
	//:> Static methods
	static void CreateCom(IUnknown *punkOuter, REFIID iid, void ** ppv);

	//:> Constructors/destructors/etc.
	WFI();
	virtual ~WFI();

//:>********************************************************************************************
//:>	   IUnknown Methods
//:>********************************************************************************************
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppv);
	/*------------------------------------------------------------------------------------------
		Add a reference to the object.

		@return The new reference count.
	------------------------------------------------------------------------------------------*/
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return InterlockedIncrement(&m_cref);
	}
	/*------------------------------------------------------------------------------------------
		Release a reference to the object, and perhaps delete it.

		@return The new reference count.
	------------------------------------------------------------------------------------------*/
	STDMETHOD_(ULONG, Release)(void)
	{
		long cref = InterlockedDecrement(&m_cref);
		if (cref == 0) {
			m_cref = 1;
			delete this;
		}
		return cref;
	}

//:>********************************************************************************************
//:>	   IWFI Methods
//:>********************************************************************************************
	STDMETHOD(Init)(BSTR bstrServer, BSTR bstrDatabase,
			BSTR bstrLangProj, BSTR bstrUser, BSTR bstrPassword);

	STDMETHOD(ProcessParse)(BSTR bstrFormat, BSTR bstrParse);

	STDMETHOD(DeleteWordform) (long lId);
	STDMETHOD(FindOrCreateWordform) (BSTR bstrWordform, long lWs, /*out*/long *lpId);
	STDMETHOD(FindWordform) (BSTR bstrWordform, long lWs, /*out*/long *lpId);

//:>********************************************************************************************
//:>	   ISupportErrorInfo Methods
//:>********************************************************************************************
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		return (riid == IID_IWFI) ? S_OK : S_FALSE;
	}	

protected:
	//for testing:

	/*------------------------------------------------------------------------------------------
		Clear out the data members.
	------------------------------------------------------------------------------------------*/
	void ResetMembers()
	{
		m_qode = NULL;
		m_iLpId = 0;
		m_iLDBId = 0;
		m_iWfiId = 0;
		m_iAnalWs = 0;
		m_iVernWs = 0;
	}


	/*------------------------------------------------------------------------------------------
		Reference count to this object.
	------------------------------------------------------------------------------------------*/
	long m_cref;
	/*------------------------------------------------------------------------------------------
		Database access object.
	------------------------------------------------------------------------------------------*/
	IOleDbEncapPtr m_qode;
	/*------------------------------------------------------------------------------------------
		Language Project database ID.
	------------------------------------------------------------------------------------------*/
	int m_iLpId;
	/*------------------------------------------------------------------------------------------
		Lexical DB database ID.
	------------------------------------------------------------------------------------------*/
	int m_iLDBId;
	/*------------------------------------------------------------------------------------------
		Wfi database ID.
	------------------------------------------------------------------------------------------*/
	int m_iWfiId;
	/*------------------------------------------------------------------------------------------
		Default analysis writing system.
	------------------------------------------------------------------------------------------*/
	int m_iAnalWs;
	/*------------------------------------------------------------------------------------------
		Default vernacular writing system.
	------------------------------------------------------------------------------------------*/
	int m_iVernWs;
};
DEFINE_COM_PTR(WFI);

#endif  // WFI_INCLUDED
