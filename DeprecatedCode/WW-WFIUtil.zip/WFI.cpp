/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: WFI.cpp
Responsibility: John Hatton
Last reviewed: never

Description:
	Implementation of an IWFI interface in the class WFI.
-------------------------------------------------------------------------------*//*:End Ignore*/


// temp till it can be moved into comutil.h

#define END_COM_METHOD_CU(factory, iid, CleanUp) \
	}\
	catch (Throwable & thr) \
	{ \
		CleanUp; \
		return HandleThrowable(thr, iid, &factory); \
	} \
	catch (...) \
	{ \
		CleanUp; \
		return HandleDefaultException(iid, &factory); \
	} \
	return S_OK; \


//:>********************************************************************************************
//:>	   Include files
//:>********************************************************************************************

//#define MAKE_REPORT_LOG  // for use with timing and unit tests

#include "main.h"
#pragma hdrstop
#include "SAXErrorHandlerImpl.h"

#ifdef MAKE_REPORT_LOG
#include "reporter.h"
#endif

#undef THIS_FILE
DEFINE_THIS_FILE

//:>********************************************************************************************
//:>	   Forward declarations
//:>********************************************************************************************

//:>********************************************************************************************
//:>	   Local Constants and static variables
//:>********************************************************************************************


#ifdef MAKE_REPORT_LOG
	FileReporter *g_pReporter;
#endif

//:>********************************************************************************************
//:>	   Generic factory stuff to allow creating an instance with CoCreateInstance.
//:>********************************************************************************************
static GenericFactory g_fact(
	"SIL.Samples.WFI",	
	&CLSID_WFI,	
	"SIL Sample",
	"Apartment",
	&WFI::CreateCom);

//:>********************************************************************************************
//:>	Global error message storing StrUni, which is used, since we use a COM interface
//:>	that doesn't support errors. This global is a good place to put sensible messages.
//:>	that will be returned if some thing bad happnes.
//:>********************************************************************************************
StrUni g_stuMsg;
int g_iHvoOfWordformInCaseOfError;

//:>********************************************************************************************
//:>	   WFI Methods
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor
----------------------------------------------------------------------------------------------*/
WFI::WFI()
{
	ResetMembers();
	m_cref = 1;
	ModuleEntry::ModuleAddRef();
}

/*----------------------------------------------------------------------------------------------
	Destructor
----------------------------------------------------------------------------------------------*/
WFI::~WFI()
{
	#ifdef MAKE_REPORT_LOG
	if(g_pReporter) 
		delete g_pReporter;
	#endif
	ModuleEntry::ModuleRelease();
}

void WFI::CreateCom(IUnknown *punkCtl, REFIID riid, void ** ppv)
{
	AssertPtr(ppv);
	Assert(!*ppv);
	if (punkCtl)
		ThrowHr(WarnHr(CLASS_E_NOAGGREGATION));

	ComSmartPtr<WFI> qxsi;
	qxsi.Attach(NewObj WFI());		// ref count initially 1
	CheckHr(qxsi->QueryInterface(riid, ppv));
}

STDMETHODIMP WFI::QueryInterface(REFIID riid, void **ppv)
{
	if (!ppv)
		return E_POINTER;
	AssertPtr(ppv);
	*ppv = NULL;
	if (riid == IID_IUnknown)
		*ppv = static_cast<IUnknown *>(static_cast<IWFI *>(this));
	else if (riid == IID_IWFI)
		*ppv = static_cast<IWFI *>(this);
	else if (riid == IID_ISupportErrorInfo)
	{
		*ppv = NewObj CSupportErrorInfo(
			static_cast<IUnknown *>(static_cast<IWFI *>(this)), IID_IWFI);
		return S_OK;
	}
	else
		return E_NOINTERFACE;

	AddRef();
	return NOERROR;
}

//:>********************************************************************************************
//:>	   IWFI Methods
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Initialize the object. This must be called before any other method.

	@param bstrServer SQL Server.
	@param bstrDatabase SQL database name.
	@param bstrLangProj Language project name in the database.
	@param bstrUser SQL user. [Not used yet.]
	@param bstrServer SQL password. [Not used yet.]
	@return S_OK if successful, otherwise one of several other HRESULTs.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP WFI::Init(BSTR bstrServer, BSTR bstrDatabase, BSTR bstrLangProj,
					   BSTR bstrUser, BSTR bstrPassword)
{
	BEGIN_COM_METHOD
	ChkComBstrArgN(bstrServer);
	ChkComBstrArgN(bstrDatabase);
	ChkComBstrArgN(bstrLangProj);
	ChkComBstrArgN(bstrUser);
	ChkComBstrArgN(bstrPassword);

	IOleDbCommandPtr qodc;
	StrUni stuLPName;
	StrUni stuSqlStmt;
	ComBool fIsNull;
	ComBool fMoreRows;
	ULONG cbSpaceTaken;

	// It's fine to call this method more than once, but reset everything first.
	// If it already has DB access, close it down.
	ResetMembers();

	m_qode.CreateInstance(CLSID_OleDbEncap);
	if (!m_qode)
		ThrowHr(E_FAIL);	// Couldn't make an IOleDbEncap.

	// Set up the DB accessor.
	CheckHr(m_qode->Init(bstrServer, bstrDatabase, NULL, koltMsgBox, 0));

	// Cache the LP id.
	stuLPName = bstrLangProj;
	stuSqlStmt.Format(
		L"select lp.Id "
		L"from LanguageProject lp (readuncommitted) "
		L"left outer join CmProject_Name pn (readuncommitted) "
			L"on pn.Obj = lp.Id "
		L"where pn.Txt = '%s'", stuLPName.Chars());
	m_qode->CreateCommand(&qodc);
	qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
	qodc->GetRowset(0);
	qodc->NextRow(&fMoreRows);
	if (!fMoreRows)
		ThrowHr(E_INVALIDARG, L"Unknown or invalid language project name");
	CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_iLpId),
		isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	Assert(m_iLpId);

	// Get the LDB and Wfi database Ids.
	stuSqlStmt.Format(
		L"select ldb.dst ldb, wfi.dst wfi "
		L"from LanguageProject lp (readuncommitted) "
		L"left outer join LanguageProject_LexicalDatabase ldb (readuncommitted) "
			L"on ldb.Src = lp.Id "
		L"left outer join LanguageProject_WordformInventory wfi (readuncommitted) "
			L"on wfi.Src = lp.Id "
		L"where lp.Id = %d",
		m_iLpId);
	m_qode->CreateCommand(&qodc);
	qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
	qodc->GetRowset(0);
	qodc->NextRow(&fMoreRows);
	if (fMoreRows)
	{
		CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_iLDBId),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));
		CheckHr(qodc->GetColValue(2, reinterpret_cast<ULONG *>(&m_iWfiId),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	}
	else ThrowHr(E_FAIL, L"The LDB or WFI (or both) doesn't exist");

	// Get the writing system for the first analysis language.
	stuSqlStmt.Format(
		L"select le.Code "
		L"from LanguageProject_AnalysisWritingSystems ae (readuncommitted) "
		L"left outer join LgWritingSystem le (readuncommitted) "
			L"on ae.Dst = le.Id "
		L"where ae.Src = %d", m_iLpId);
	m_qode->CreateCommand(&qodc);
	qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
	qodc->GetRowset(0);
	qodc->NextRow(&fMoreRows);
	if (fMoreRows)
	{
		CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_iAnalWs),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	}
	else ThrowHr(E_FAIL, L"There aren't any analysis encodings.");


		// Get the vern writing system for the first ?? language.
	stuSqlStmt.Format(
		L"select le.Code "
		L"from LanguageProject_VernacularWritingSystems ae (readuncommitted) "
		L"left outer join LgWritingSystem le (readuncommitted) "
			L"on ae.Dst = le.Id "
		L"where ae.Src = %d", m_iLpId);
	m_qode->CreateCommand(&qodc);
	qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
	qodc->GetRowset(0);
	qodc->NextRow(&fMoreRows);
	if (fMoreRows)
	{
		CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_iVernWs),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	}
	else ThrowHr(E_FAIL, L"There aren't any vernacular encodings.");

	qodc.Clear();	// Other users of IOleDbEncap will need it to be cleared.

	END_COM_METHOD_CU(g_fact, IID_IWFI, ResetMembers());
} 

/*----------------------------------------------------------------------------------------------
	Read pbstrParse and update the WFI accordingly (i.e., find/creates  analyses,
		find/creates analyzing agents, and hooks them together).

	@param pbstrFormat Pointer to a BSTR that tells what format pbstrParse is to be in. Only "FWParse" is implemented.
	@param pbstrParse Pointer to a BSTR that contains the FWParse XML to be processed.
	@return S_OK if successful, otherwise one of several other HRESULTs.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP WFI::ProcessParse(BSTR bstrFormat, BSTR bstrParse)
{
	// Must be before BEGIN_COM_METHOD, since it needs to be available in END_COM_METHOD_CU.
	ComBool fHaveTransaction = false;

	BEGIN_COM_METHOD
	ChkComBstrArgN(bstrFormat);
	ChkComBstrArgN(bstrParse);

		#ifdef MAKE_REPORT_LOG
			char pszTempPath[MAX_PATH+1];
			::GetEnvironmentVariable("TEMP", pszTempPath, MAX_PATH);
			g_pReporter = new FileReporter(::strcat(pszTempPath, "\\wfiUtilLog.txt"));
		#endif

		TASK_START(pp, "process parse");

		if (!m_qode)
			ThrowHr(E_UNEXPECTED, L"Must call Init() before ProcessParse().");

		g_stuMsg.Clear();

		TASK_START(cs, "Create SAXXMLReader")
			ISAXXMLReaderPtr qRdr; 
			qRdr.CreateInstance(__uuidof(SAXXMLReader));	    
		TASK_END(cs)					
					
		// Note: Other (future) supported formats get added here,
		// and have their own if (xxx == bstrFmtIn) {} code.
		_bstr_t bstrFWParse = L"FWParse";	// XAmple data.
		_bstr_t bstrFmtIn = bstrFormat;


		if (bstrFWParse == bstrFmtIn)
		{
			TASK_START(xfp, "Create XFPReader & Error Handler")

			XFPReader fpr(m_qode, m_iLpId, m_iLDBId, m_iWfiId, m_iAnalWs);
			if (FAILED(qRdr->putContentHandler(&fpr)))
				ThrowHr(E_FAIL, L"Could not add content handler to SAX reader.");


			SAXErrorHandlerImpl * pEc = new SAXErrorHandlerImpl();
			if (FAILED(qRdr->putErrorHandler(pEc)))
					ThrowHr(E_FAIL, L"Could not add error handler to SAX reader.");

			TASK_END(xfp)	

		// Cast our xml as a VARIANT
			VARIANT v;
			VariantInit(&v);
			v.vt = VT_BSTR;
			v.bstrVal = bstrParse;

			CheckHr(m_qode->IsTransactionOpen(&fHaveTransaction));
			if (!fHaveTransaction)
				CheckHr(m_qode->BeginTrans());
			fHaveTransaction = true;

			{
				#ifdef MAKE_REPORT_LOG
					SubTask t(g_pReporter, "Parse");
				#endif

				if (FAILED(qRdr->parse(v)))
				{
					if (g_stuMsg.Length() == 0)
					{
						g_stuMsg = L"Bad XML data.";
						
					}
					else
					{
						OutputDebugString("ERROR\n");
						_bstr_t x = g_stuMsg.Bstr();
						x+="\n\n";
						OutputDebugString(x);
						char s[100];
						sprintf(s, "Wordform Id=%d", g_iHvoOfWordformInCaseOfError);
						OutputDebugString( s);
					}
					ThrowHr(E_FAIL, g_stuMsg.Chars());
				}
			} // end subtask

			TASK_START(com, "Commit transaction");

			if (fHaveTransaction)
				CheckHr(m_qode->CommitTrans());

			TASK_END(com)
		}
		else ThrowHr(E_INVALIDARG, L"Data format not recognized");

	TASK_END(pp)

	#ifdef MAKE_REPORT_LOG	//I was having trouble properly reading the final this generates from the nunit tests
		delete g_pReporter;
		g_pReporter=0; 
	#endif

	END_COM_METHOD_CU(g_fact, IID_IWFI, {if (fHaveTransaction) m_qode->RollbackTrans();});
}

/*----------------------------------------------------------------------------------------------
	tries to find a Wordform matching the given string and writing system.
	@param plId  on output, will contain the ID of the matching Wordform, or zero if not found.
  ----------------------------------------------------------------------------------------------*/

STDMETHODIMP WFI::FindWordform(BSTR bstrWordform, long lWs, /*out*/ long *plId)
{
	BEGIN_COM_METHOD
	ChkComBstrArgN(bstrWordform);

	ComBool fIsNull = true;

	*plId = 0;
	
	if (lWs == 0) 
		lWs = static_cast<LONG>(m_iVernWs);

	if (!m_qode)
		ThrowHr(E_UNEXPECTED, L"Must call Init() before FindWordform().");

	IOleDbCommandPtr qodc;
	StrUni stuSqlStmt;
	ComBool fMoreRows;

	try
	{
		stuSqlStmt.Format(
			L"select Obj from  WfiWordform_form wff(readuncommitted) "
			L"join  wfiwordform_ wf on wf.Id = wff.Obj "
			L"where Txt='%s' and Ws = %d ", bstrWordform, lWs );

		m_qode->CreateCommand(&qodc);
		CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));
		if(fMoreRows)
		{
			ULONG cbSpaceTaken=0;
			ComBool fIsNull;

			CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(plId),
					isizeof(int), &cbSpaceTaken, &fIsNull, 0));
		}
	}
	catch (...)
	{
		ThrowHr(E_FAIL, L"Problem querying Database in WFI::FindWordform().");	// ENHANCE( pass on a COM exception detailing what went wrong)
	}

	qodc.Clear();	// Other users of IOleDbEncap will need it to be cleared.
	END_COM_METHOD(g_fact, IID_IWFI);
}

/*----------------------------------------------------------------------------------------------
	Find a Wordform with the given form and writing system.  If it cannot be found, create it.

	Review Randy (JohnH): what are we going to do for the situation where the word does
	already exist but in a different encoding?  Maybe we need another function, something like
	AddFormToWordform() for cases where the application knows which Wordform we are adding to?
  ----------------------------------------------------------------------------------------------*/
STDMETHODIMP WFI::FindOrCreateWordform(BSTR bstrWordform, long lWs, /*out*/long *plId)
{
	BEGIN_COM_METHOD
	ChkComBstrArgN(bstrWordform);

/* todo John: change to using the following from the scripture guys, since it uses a stored proc
		that both finds and creates.
		
		  *plId = 0;
	if (!m_qode)
		ThrowHr(E_UNEXPECTED, L"Must call Init() before FindWordform().");

	if (lWs == 0) 
		lWs = static_cast<LONG>(m_iVernWs);

		// This word we do not have loaded in memory. Add it or retrieve its HVO from DB.
		// Form the SQL query, set the parameters, and execute the command.
		stuSql.Format(L"exec CreateObj_WfiWordForm %d, '%s', %d, ? output, ? output",
			m_hvoWfi, stuWord.Chars(), m_vwsVern[0]);
		qodc->SetParameter(1, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
			(ULONG *)&hvoWfiWordform,	sizeof(HVO));
		int nSpellingStatus = 0;
		qodc->SetParameter(2, DBPARAMFLAGS_ISOUTPUT | DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_UI1,
			(ULONG *)&nSpellingStatus,	sizeof(int));

		// Actually execute the command.
#ifdef DEBUG
		time(&startMakeWordforms);
#endif
		CheckHr(qodc->ExecCommand(stuSql.Bstr(), knSqlStmtNoResults));
		ComBool fIsNull;
		qodc->GetParameter(1, reinterpret_cast<ULONG *>(&hvoWfiWordform), sizeof(HVO), &fIsNull);
		// REVIEW JohnT (TomB): what should we do if we don't get a valid HVO?
		if (!hvoWfiWordform)
			throw;
		qodc->GetParameter(2, reinterpret_cast<ULONG *>(&nSpellingStatus), sizeof(int), &fIsNull);
*/
	CheckHr(FindWordform(bstrWordform, lWs, plId));


	if(*plId == 0)	// if it is not already in the database
	{
		ComBool fMoreRows;
		IOleDbCommandPtr qodc;
		StrUni stuSqlStmt;
		ComBool fIsNull;
		ULONG cbSpaceTaken;

		// Create a new one.
		stuSqlStmt.Format(
			L"declare @uid uniqueidentifier "
			L"exec CreateOwnedObject$ "
			L"%d, null, null, %d, %d, %d, null, 1, 1, @uid output; "
			L"exec CleanObjListTbl$ @uid",
			kclidWfiWordform, // class
			m_iWfiId, // owner
			kflidWordformInventory_Wordforms,//owning field
			kcptOwningCollection); // field type

		CheckHr(m_qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtStoredProcedure));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));

		// get the id of the newly created wordform
		CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(plId),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));
		Assert(*plId > 0);

		// Set other attributes.
		stuSqlStmt.Format(L"exec SetMultiTxt$ %d, %d, %d, '%s'; ",
			kflidWfiWordform_Form, *plId, lWs, bstrWordform);

		m_qode->CreateCommand(&qodc);
		qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtNoResults);
		qodc.Clear();
	}


	
	END_COM_METHOD(g_fact, IID_IWFI);
}

STDMETHODIMP WFI::DeleteWordform(long lId)	//TODO : Implement this
{
	return E_NOTIMPL;	//TODO : Implement this
}
