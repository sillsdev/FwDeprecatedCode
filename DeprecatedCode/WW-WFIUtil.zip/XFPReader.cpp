/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: XFPReader.cpp
Responsibility: John Hatton / Randy Regnier (sql statements)
Last reviewed: Never

	Content handler for reading XFP (Xml Fieldworks Parse) XML files which 
	updates the WordformInventory appropriately.
-------------------------------------------------------------------------------*//*:End Ignore*/

#include "Main.h"
#pragma hdrstop

#include "XFPReader.h"
#include "Vector_i.cpp"
#include "HashMap_i.cpp"

//#define VERBOSE_DEBUG
#define MAKE_REPORT_LOG  // for use with timing and unit tests
#ifdef MAKE_REPORT_LOG
	#include "reporter.h"
	extern FileReporter *g_pReporter;
#endif
//:>******************if**************************************************************************
//:>	   Global error message storing StrUni.
//:>********************************************************************************************
extern StrUni g_stuMsg;
extern int g_iHvoOfWordformInCaseOfError;

//:>********************************************************************************************
//:>	   XFPReader Methods
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.

	@param pode Pointer to DB accessor.
	@param iLpId Database ID for the language project.
	@param iLDBId Database ID for the lexical database.
	@param iWfiId Database ID for the wordform inventory.
----------------------------------------------------------------------------------------------*/
XFPReader::XFPReader(IOleDbEncap * pode, int iLpId, int iLDBId, int iWfiId, int iAnalEnc)
{
	AssertPtr(pode);
	m_qode = pode;
	m_iLpId = iLpId;
	m_iLDBId = iLDBId;
	m_iWfiId = iWfiId;
	m_iAnalEnc = iAnalEnc;
	m_iAnalAgentId = 0;
	m_iCurrentWordformId = 0;
	m_iCurrentAnalysisId = 0;
}

/*----------------------------------------------------------------------------------------------
	Destructor
----------------------------------------------------------------------------------------------*/
XFPReader::~XFPReader()
{ /* Let superclass fret about this. */ }

HRESULT STDMETHODCALLTYPE XFPReader::startDocument()
{
	if (!m_qode)
		return E_FAIL;

    return S_OK;
}

HRESULT STDMETHODCALLTYPE XFPReader::startElement( 
            /* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri,
            /* [in] */ int cchNamespaceUri,
            /* [in] */ wchar_t __RPC_FAR *pwchLocalName,
            /* [in] */ int cchLocalName,
            /* [in] */ wchar_t __RPC_FAR *pwchRawName,
            /* [in] */ int cchRawName,
            /* [in] */ ISAXAttributes __RPC_FAR *pAttributes)
{
	if (!m_qode)
	{
		g_stuMsg = L"No database connection.";
		return E_FAIL;
	}

	HRESULT hr = S_OK;
	int l;
	wchar_t * ln;
	int lnlen;
	int i;
	int iDbId;
	static wchar_t wcTemp[1000];
	StrAnsi staLocalName = pwchLocalName;
#ifdef VERBOSE_DEBUG
	StrAnsi staOutStrDbgr;
	staOutStrDbgr.Format("Found start tag: %s\n", staLocalName.Chars());
	OutputDebugString(staOutStrDbgr.Chars());
#endif
	StrAnsi staAttributeLocalName;
	StrAnsi staAttributeValue;

	pAttributes->getLength(&l);
	for (i=0; i<l; i++)
	{
		// The only attribute we really care about is "DbRef",
		// and we will hang onto its value for now.
		iDbId = 0;
		pAttributes->getLocalName(i,&ln,&lnlen);
		ZeroMemory(wcTemp, 1000);
		wcsncpy(wcTemp, ln, lnlen);
		staAttributeLocalName = wcTemp;
		if (staAttributeLocalName == "DbRef")
		{
			pAttributes->getValue(i,&ln,&lnlen);
			ZeroMemory(wcTemp, 1000);
			wcsncpy(wcTemp, ln, lnlen);
			staAttributeValue = wcTemp;
#ifdef VERBOSE_DEBUG
			staOutStrDbgr.Format("\tFound ID: %s\n", staAttributeValue.Chars());
			OutputDebugString(staOutStrDbgr.Chars());
#endif
			iDbId = atoi(staAttributeValue.Chars());
			break;
		}
	}

	if (staLocalName =="MoForm")
	{
		if (iDbId == 0)
		{
			g_stuMsg = L"No ID for form.";
			ResetMembers();
			return E_FAIL;	//  No DB id, so quit..
		}
		m_viFormIds.Push(iDbId);	// Cache the MoForm id.
		iDbId = 0;
	}
	else if (staLocalName =="MSA")
	{
		if (iDbId == 0)
		{
			g_stuMsg = L"No ID for MSA.";
			ResetMembers();
			return E_FAIL;	//  No DB id, so quit.
		}
		m_viMsaIds.Push(iDbId);		// Cache the MSA id.
		iDbId = 0;
	}
	else if (staLocalName =="WfiAnalysis")
	{
		if ((m_viFormIds.Size() > 0)
			|| (m_viMsaIds.Size() > 0))
		{
			// Can only get here, if we have found form or MSA tags,
			// but no WfiAnalysis end tag, which would have cleared both vectors.
			g_stuMsg = L"No end tag for 'WfiAnalysis'.";
			ResetMembers();
			return E_FAIL;
		}
		// Starting a WfiAnalysis, so clear old id.
		m_iCurrentAnalysisId = 0;
	}
	else if (staLocalName == "Wordform")
	{
		if ((m_viFormIds.Size() > 0)
			|| (m_viMsaIds.Size() > 0)
			|| (m_iCurrentAnalysisId > 0))
		{
			// Can only get here, if we have found form or MSA tags,
			// but no WfiAnalysis end tag, which would have cleared both vectors.
			// The end tag for WordForm would also have set m_iCurrentAnalysisId to 0.
			g_stuMsg = L"Missing 'WfiAnalysis' or 'WordForm' end tag.";
			ResetMembers();
			return E_FAIL;
		}

		m_iCurrentWordformId = iDbId;	// Cache id.
		g_iHvoOfWordformInCaseOfError = iDbId;

		// Check to see if wordform is in DB.
		if (!ExistsWordsform())
		{
			g_stuMsg.Format(L"Wordform '%d' not found in this LanguageProject.", m_iCurrentWordformId);
			ResetMembers();
			return E_FAIL;	//  Not found in DB, so bail out.
		}
	}
	else if (staLocalName == "AnalyzingAgent")
	{
		if (m_iAnalAgentId > 0)
		{
			g_stuMsg = L"Found another 'AnalyzingAgent' tag.";
			return E_FAIL;	// Second time we found this tag, which is bad.
		}
		// Get information from attributes.
		StrUni stuName;
		StrUni stuVersion;
		ComBool fHuman = false;
		for (i=0; i<l; i++)
		{
			pAttributes->getLocalName(i,&ln,&lnlen);
			ZeroMemory(wcTemp, 1000);
			wcsncpy(wcTemp, ln, lnlen);
			staAttributeLocalName = wcTemp;

			pAttributes->getValue(i,&ln,&lnlen);
			ZeroMemory(wcTemp, 1000);
			wcsncpy(wcTemp, ln, lnlen);
			staAttributeValue = wcTemp;

			if (staAttributeLocalName == "name")
			{
				stuName = wcTemp;
			}
			else if (staAttributeLocalName == "human")
			{
				fHuman = (staAttributeValue == "true");
			}
			else if (staAttributeLocalName == "version")
			{
				stuVersion = wcTemp;
			}
		}
		// Find the agent, and cache its id.
		if (!GetAnalyzingAgent(&stuName, fHuman, &stuVersion))
		{
			g_stuMsg = L"Could not find (or create) the analyzing agent.";
			return E_FAIL;	// Couldn't get the agent, so quit.
		}
	}
	else if ((staLocalName == "Morphs")
		|| (staLocalName == "Morph")
		|| (staLocalName == "WordSet")
		|| (staLocalName == "AnalyzingAgentResults")
		|| (staLocalName == "StateInformation"))
	{
		// Ignore all of these tags.
		// But don't be as rude as the next guy.
#ifdef VERBOSE_DEBUG
		OutputDebugString("Ignoring tag: ");
		OutputDebugString(staLocalName.Chars());
		OutputDebugString("\n");
#endif
	}
	else
	{
		// Unrecognized tag.
		g_stuMsg.Format(L"Found unrecognized tag: '%s'.", staLocalName.Chars());
		return E_FAIL;
	}

    return hr;
}

HRESULT STDMETHODCALLTYPE XFPReader::endElement( 
            /* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri,
            /* [in] */ int cchNamespaceUri,
            /* [in] */ wchar_t __RPC_FAR *pwchLocalName,
            /* [in] */ int cchLocalName,
            /* [in] */ wchar_t __RPC_FAR *pwchRawName,
            /* [in] */ int cchRawName)
{
	if (!m_qode)
	{
		g_stuMsg = L"No database connection.";
		return E_FAIL;
	}

	StrAnsi staLocalName = pwchLocalName;
#ifdef VERBOSE_DEBUG
	StrAnsi staOutStrDbgr;
	staOutStrDbgr.Format("Found end tag: %s\n", staLocalName.Chars());
	OutputDebugString(staOutStrDbgr.Chars());
#endif
	if (staLocalName == "WfiAnalysis")
	{
		// Found the end of an analysis.
		// Do some validity checking, before processing morphs.
		if ((m_iCurrentWordformId == 0)
			|| (m_iAnalAgentId == 0)
			|| (m_iCurrentAnalysisId > 0)
			|| !(m_viFormIds.Size() == m_viMsaIds.Size()))
		{
			g_stuMsg = L"Found 'WfiAnalysis' end tag, which is in wrong order.";
			ResetMembers();
			return E_FAIL;	// Preconditions for processing have not been met.
		}

		// Handle analysis.
		if (!ProcessAnalysis())
		{
			ResetMembers();
			return E_FAIL;	// Message has been set by ProcessAnalysis.
		}

		// Clear out vectors, so they are ready for another analysis
		// of a wordform. It could be the same wordform or a different wordform.
		m_viFormIds.Clear();
		m_viMsaIds.Clear();

		// Cache the analysis id, for use by RemoveOldAnalyses.
		m_viAnalIds.Push(m_iCurrentAnalysisId);
	}
	else if (staLocalName == "Wordform")
	{
		// Zap unloved analyses this agent used to care about, but no longer does.
		if (!RemoveOldAnalyses())
		{
			ResetMembers();
			return E_FAIL;	// Message has been set by RemoveOldAnalyses.
		}
		m_viAnalIds.Clear();
		m_iCurrentAnalysisId = 0;
	}

	return S_OK;
}

/*----------------------------------------------------------------------------------------------
	Find (create, if not found) the analyzing agent in the database.

	@param pstuName Pointer to the agent's name.
	@param fHuman True if human is the agent, otherwise false.
	@param pstuVersion Pointer to the agent's version.
	@return True if successful, false otherwise.
----------------------------------------------------------------------------------------------*/
bool XFPReader::GetAnalyzingAgent(StrUni * pstuName, bool fHuman, StrUni * pstuVersion)
{
	TASK_START(pp, "GetAnalyzingAgent");

	Assert(m_qode);	// Got to have the connection.
	AssertPtr(pstuName);
	AssertPtr(pstuVersion);
	Assert(m_iAnalAgentId == 0);	// Shouldn't call this method more than once.

	IOleDbCommandPtr qodc;
	StrUni stuSqlStmt;
	ComBool fIsNull;
	ComBool fMoreRows;
	ULONG cbSpaceTaken;
	bool bRet = true;

	try
	{
		stuSqlStmt.Format(
			L"select aa.Id from CmAgent_ aa (readuncommitted) "
			L"left outer join CmAgent_Name aan (readuncommitted) "
				L"on aan.Obj = aa.Id and aan.Txt='%s' "
			L"where aa.Owner$ = %d and aa.Human=%d and aa.Version='%s'",
			pstuName->Chars(), m_iLpId, fHuman, pstuVersion->Chars());
		m_qode->CreateCommand(&qodc);
		qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
		qodc->GetRowset(0);
		qodc->NextRow(&fMoreRows);
		if(fMoreRows)
		{
			// Cache id of extant agent.
			CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_iAnalAgentId),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			Assert(m_iAnalAgentId > 0);
		}
		else
		{
			// Create a new one.
			stuSqlStmt.Format(
				L"declare @uid uniqueidentifier "
				L"exec CreateOwnedObject$ "
				L"%d, null, null, %d, %d, %d, null, 1, 1, @uid output; "
				L"exec CleanObjListTbl$ @uid",
				kclidCmAgent, m_iLpId,
				kflidLanguageProject_AnalyzingAgents, kcptOwningCollection);
			CheckHr(m_qode->CreateCommand(&qodc));
			CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtStoredProcedure));
			CheckHr(qodc->GetRowset(0));
			CheckHr(qodc->NextRow(&fMoreRows));
			// Cache its id.
			CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_iAnalAgentId),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			Assert(m_iAnalAgentId > 0);
			// Set other attributes.
			stuSqlStmt.Format(L"exec SetMultiTxt$ %d, %d, %d, '%s'; ",
				kflidCmAgent_Name, m_iAnalAgentId, m_iAnalEnc, pstuName->Chars());
			stuSqlStmt.FormatAppend(L"UPDATE CmAgent SET Human=%d, Version='%s'"
					L"WHERE Id=%d",
				fHuman, pstuVersion->Chars(), m_iAnalAgentId);
			m_qode->CreateCommand(&qodc);
			qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtNoResults);
		}
		qodc.Clear();
	}
	catch (...)
	{
		bRet = false;	// Something bad happened.
	}
	return bRet;
}

/*----------------------------------------------------------------------------------------------
	Check to see if the wordform is in the inventory.

	@return True if successful, false on missing inventory, missing wordform,
		or exception thrown.
----------------------------------------------------------------------------------------------*/
bool XFPReader::ExistsWordsform()
{
	TASK_START(pp, "ExistsWordsform");

	Assert(m_qode);	// Got to have the connection.
	Assert(m_iCurrentWordformId > 0);

	IOleDbCommandPtr qodc;
	StrUni stuSqlStmt;
	ComBool fMoreRows;

	try
	{
		stuSqlStmt.Format(
			L"select * from WordformInventory_Wordforms (readuncommitted) "
			L"where Src = %d and Dst = %d", m_iWfiId, m_iCurrentWordformId);
		m_qode->CreateCommand(&qodc);
		qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
		qodc->GetRowset(0);
		qodc->NextRow(&fMoreRows);
		qodc.Clear();
	}
	catch (...)
	{
		fMoreRows = false;	// Something bad happened.
	}
	return fMoreRows;
}




/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
bool XFPReader::FindOrCreateAnalysis (StrUni stuXMLAnalysis)
{
	TASK_START(fa, "FindOrCreateWfiAnalysis() method");
	bool bRet = true;
	
	StrUni stuSqlStmt;
	ComBool fMoreRows;
	IOleDbCommandPtr qodc;

	ComBool fIsNull = false;
	ULONG cbSpaceTaken;
	
	stuSqlStmt.Format(L"declare @retval int, @AnalId int "
			L"exec @retval=FindOrCreateWfiAnalysis %d, \'%s\', @AnalId output "
			L"select @retval, @AnalId", m_iCurrentWordformId, stuXMLAnalysis.Chars());
	AssertPtr(m_qode);
	CheckHr(m_qode->CreateCommand(&qodc));
	TASK_START(efc, "Executing FindOrCreateWfiAnalysis stored procedure");
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset));
	TASK_END(efc);
	CheckHr(qodc->GetRowset(0));
	CheckHr(qodc->NextRow(&fMoreRows));
	int retval;
	if (!fMoreRows)		// outer fMoreRows check
	{
		// FindOrCreateWfiAnalysis didn't return @retval.
		g_stuMsg = L"Database access problem (No @retval).";
		bRet = false;
		goto LExit;
	}
	CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&retval),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	switch (retval)
	{
	case 0:	// Success.
		break;
	case 1:
		g_stuMsg = L"sp_xml_preparedocument error.";
		bRet = false;
		goto LExit;
		break;
	case 2:
		g_stuMsg = L"Form or MSA have no owner.";
		bRet = false;
		goto LExit;
		break;
	case 3:
		g_stuMsg = L"Form and MSA have different owners.";
		bRet = false;
		goto LExit;
		break;
	case 4:
		g_stuMsg = L"sp_xml_removedocument error.";
		bRet = false;
		goto LExit;
		break;
	case 5:
		g_stuMsg = L"CreateOwnedObject error.";
		bRet = false;
		goto LExit;
		break;
	case 6:
		g_stuMsg = L"Could not insert form data.";
		bRet = false;
		goto LExit;
		break;
	case 7:
		g_stuMsg = L"Could not insert MSA data.";
		bRet = false;
		goto LExit;
		break;
	default:
		g_stuMsg = L"Unspecified FindOrCreateWfiAnalysis stored procedure problem.";
		bRet = false;
		goto LExit;
		break;
	}
	CheckHr(qodc->GetColValue(2, reinterpret_cast<ULONG *>(&m_iCurrentAnalysisId),
		isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	if (!m_iCurrentAnalysisId)
	{
		g_stuMsg = L"No analysis ID.";
		bRet = false;
		goto LExit;
	}

LExit:
	qodc.Clear();
	TASK_END(fa);
	return bRet;
}

/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
bool XFPReader::SetAgent()
{
	// Set agent to analysis, if not already connected.
	TASK_START(sa, "Set agent");
	StrUni stuSqlStmt;
	ComBool fMoreRows;
	IOleDbCommandPtr qodc;
	
	stuSqlStmt.Format(
		L"select * from WfiAnalysis_ValidatingSources (readuncommitted) "
			L"where Src=%d and Dst=%d",
		m_iCurrentAnalysisId, m_iAnalAgentId);
	AssertPtr(m_qode);
	CheckHr(m_qode->CreateCommand(&qodc));
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset));
	CheckHr(qodc->GetRowset(0));
	CheckHr(qodc->NextRow(&fMoreRows));
	if (!fMoreRows)
	{
		// Add agent.
		stuSqlStmt.Format(
			L"INSERT into WfiAnalysis_ValidatingSources  (Src, Dst) "
				L"VALUES (%d, %d);%n",
			m_iCurrentAnalysisId, m_iAnalAgentId);
		CheckHr(m_qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtNoResults));
	}

	qodc.Clear();
	TASK_END(sa);
	return true;
}

/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
StrUni XFPReader:: MakeXMLForAnalysisParameter ()
{
		// <Pair MsaId="492" FormId="494" Ord="1"/>

		StrUni stuXML = L"<root>";
		for (int i = 0; i < m_viMsaIds.Size(); ++i)
		{
			stuXML.FormatAppend(L"<Pair MsaId=\"%d\" FormId=\"%d\" Ord=\"%d\"/>",
				m_viMsaIds[i], m_viFormIds[i], i);
		}
		stuXML.Append(L"</root>");
		return stuXML;
}

/*----------------------------------------------------------------------------------------------
	Process an analysis, as represented by database ids of forms and MSAs. This includes:@end
		1. Find (or create) the analysis in the DB,
			An analysis is 'found', if its MoForm ids and MSA ids match what we have.
			They must match in: quantity, identity, and order.@end
		2. Set agent to analysis, if not already connected.

	@return True if successful, false otherwise.
----------------------------------------------------------------------------------------------*/
bool XFPReader::ProcessAnalysis()
{
	TASK_START(pp, "ProcessAnalysis");

	bool bRet = ((m_iCurrentAnalysisId == 0)
			&& (m_iAnalAgentId > 0)
			&& (m_iLDBId > 0)
			&& (m_iCurrentWordformId > 0)
			&& (m_viFormIds.Size() == m_viMsaIds.Size()));	// Sizes must be the same.

	if (!bRet)
	{
		g_stuMsg = L"Missing some required IDs or mis-matched form-MSA sizes.";
		return bRet;
	}

	try
	{
		if(!FindOrCreateAnalysis(MakeXMLForAnalysisParameter()))
			goto LExit;
		
		if (!SetAgent())
			goto LExit;
	}
	catch (...)
	{
		g_stuMsg = L"Database access problem.";
		bRet = false;
	}


LExit:
	return bRet;
}

/*----------------------------------------------------------------------------------------------
	Remove analyses the current agent used to validate, and which have no other agents.

	@return True if successful, false on missing inventory, missing wordform,
		or exception thrown.
----------------------------------------------------------------------------------------------*/
bool XFPReader::RemoveOldAnalyses()
{
	TASK_START(pp, "RemoveOldAnalyses");

	bool bRet = true;
	bool fIsMatch;
	IOleDbCommandPtr qodc;
	StrUni stuSqlStmt;
	ComBool fIsNull;
	ComBool fMoreRows;
	ULONG cbSpaceTaken;
	int iId;
	Vector<int> viAnalIds;
	int iAS;
	int nErr;

	if (!m_qode || (m_iCurrentWordformId == 0))
	{
		g_stuMsg = L"No connection or wordform ID.";
		bRet = false;
		goto LExit;
	}

	try
	{
		// Step 1: Cache all WfiAnalysis ids that are owned by current wordform,
		// and that have the current agent.
		stuSqlStmt.Format(
			L"select wa.Dst from WfiWordform_Analyses wa (readuncommitted) "
			// By not doing 'left outer join', we don't select agents that are null,
			// which is good in this case.
			L"join WfiAnalysis_ValidatingSources vs (readuncommitted) "
				L"on wa.Dst=vs.Src and vs.Dst=%d "
			L"where wa.Src=%d",
			m_iAnalAgentId, m_iCurrentWordformId);
		m_qode->CreateCommand(&qodc);
		qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
		qodc->GetRowset(0);
		qodc->NextRow(&fMoreRows);
		while (fMoreRows)
		{
			CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&iId),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			Assert(iId);
			viAnalIds.Push(iId);
			CheckHr(qodc->NextRow(&fMoreRows));
		}
		iAS = viAnalIds.Size();
	

		// Step 2: Loop through all ids, and handle the old ones used by the agent.
		for (int i = 0; i < iAS; i++)
		{
			fIsMatch = false;
			iId = viAnalIds[i];
			for (int j = 0; j < m_viAnalIds.Size(); j++)
			{
				// Skip ones that match, since they have been returned by current parser.
				if (iId == m_viAnalIds[j])
				{
					fIsMatch = true;
					break;
				}
			}

			if (fIsMatch)
				continue;	// Go on to the next one, since we like this one.

			// Step 2a: Remove current agent (whether it exists or not).
			stuSqlStmt.Format(
				L"DELETE WfiAnalysis_ValidatingSources "
				L"where Src=%d and Dst=%d",
				iId, m_iAnalAgentId);
			m_qode->CreateCommand(&qodc);
			qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtNoResults);

			// Step 2b: Check for other validating agents.
			// If there are any, then we leave the analysis alone.
			stuSqlStmt.Format(
				L"select * from WfiAnalysis_ValidatingSources (readuncommitted) "
				L"where Src=%d", iId);
			m_qode->CreateCommand(&qodc);
			qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
			qodc->GetRowset(0);
			qodc->NextRow(&fMoreRows);
			if (fMoreRows)
				continue;	// Do nothing to this analysis.

			// Step 2c: Check for invalidating agents.
			// If there are any, then we leave the analysis alone.
			stuSqlStmt.Format(
				L"select * from WfiAnalysis_InvalidatingSources (readuncommitted) "
				L"where Src=%d", iId);
			m_qode->CreateCommand(&qodc);
			qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset);
			qodc->GetRowset(0);
			qodc->NextRow(&fMoreRows);
			if (fMoreRows)
				continue;	// Do nothing to this analysis.

			// Step 2d: Move any text pointers up to wordform.
				// ENHANCE RandyR: Implement this someday.

			// Step 2e: Remove analysis.
			stuSqlStmt.Format(L"declare @retval int; %n"
				L"exec @retval = DeleteObject$ NULL, %d; %n"
				L"select @retval;%n", iId);
			CheckHr(m_qode->CreateCommand(&qodc));
			CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset));
			CheckHr(qodc->GetRowset(0));
			CheckHr(qodc->NextRow(&fMoreRows));
			if (!fMoreRows)
			{
				// DeleteObject$ didn't return @retval.
				g_stuMsg = L"Database access problem (No @retval).";
				bRet = false;
				goto LExit;
			}
			nErr = -1;
			CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&nErr),
					isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			if (nErr)
			{
				// DeleteObject$ returned an error.
				g_stuMsg = L"DeleteObject$ stored procedure problem.";
				bRet = false;
				goto LExit;
			}
		}

		qodc.Clear();
	}
	catch (...)
	{
		g_stuMsg = L"Database access problem.";
		bRet = false;
	}

LExit:
	return bRet;
}
