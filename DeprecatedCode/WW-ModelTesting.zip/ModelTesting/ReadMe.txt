
                 ENVIRONMENT FOR TESTING THE M3 MODEL

   Including: M3 test data as an XML document
              Generating an XAMPLE description from the M3 XML
              Parsing text with the XAMPLE version of the M3 description
              Generating a human-readable morphology sketch from the M3 XML

Developed by: Andy Black and Gary Simons
Last revised: 24 January 2002
	9 April 2002 Randy Regnier - Use %fwroot%\Bin\ for location of msxsl.exe.


To build your own M3 data set, construct an XML file that conforms to
M3ModelTestingXml.dtd (in fw/ww/ModelTesting/code in Perforce).

To set up your computer for testing the data set with XAMPLE and
generating a human-readable morphology sketch, follow the installation
instructions below.  If you use Perforce and have the WordWorks file 
structure installed on your client, then skip to the second set of 
instructions below.


Installing from the test package zip file:
------------------------------------------

 1. Create a subdirectory (e.g. WordWorksTest) for your testing work.

 2. Unzip the test package into that directory. 

 3. Find the XXX subdirectory inside the code subdirectory and Copy.

 4. Return to your testing directory and Paste.

 5. Rename the new copy of the XXX directory to the Ethnologue three-letter
    code (e.g. zpu) for your language data.

 6. Put your M3 XML data file in that directory with the name xxxData.xml,
    where xxx is your three-letter code.

 7. Put the text file you want to parse as test data into the same
    directory. Be sure that it has a .txt extension. 

 8. Rename xxx.cmd and xxxIntx.ctl by replacing XXX with your 3 letter code.

 9. Edit the contents of the XXX.cmd and XXXIntx.ctl files as needed 
    for your data.

10. Edit the contents of parse.bat and describe.bat to substitute your
    three-letter code and the name of the text file you want to parse.
   
11. To parse the text with your M3 description, execute: parse.bat
    View text.log to see the parse log
    View text.pa  to see the printana form of the text analysis
    View text.itx to see the interlinearized form of the results

12. To generate a human-readable morphology sketch, execute: describe.bat
    View xxxMorphologySketch.htm with your web browser to see the result.



Testing from a Perforce installation:
-------------------------------------

1. fw\ww\ModelTesting will be the subdirectory for your testing work.
   Be sure you have synced the latest version of that and its contents.

2. Ensure that msxsl.exe is in the %fwroot%\Bin\ folder, where the environment
   variable "fwroot" has been set to the FieldWorks root folder (e.g., c:\fw).

3. Add the needed executables to the code subdirectory (but don't add
   them to a changelist!):

      xample32.exe, intergen32.exe, printana32.exe

   (Conversely, if they are accessible via your DOS path, you can modify
   go.bat to remove the ..\code\ in front of the program names.)

4. Follow steps 3 and following above.

Handling Special Characters
---------------------------
The xml data should be encoded using UTF-8.  That is, the very first line should be:
	  <?xml version="1.0" encoding="UTF-8" ?> 

By using UTF-8, any special characters (such as acute accented vowels) will be given according to their Unicode values, but in the special UTF-8 format.  Depending on the character, this may be two, three or four bytes long for a given character.

In order to get XAMPLE to properly recognize these character sequences as word formation characters, you will need to add them in the proper field in your xxxIntx.ctl file.  If the character is part of an upper-lower case pair (such as acute-a and acute-A), then you'll need to put the correct UTF-8 codes in the \luwfcs field.  If the character is caseless, then you will need to put the correct UTF-8 codes in the \wfcs field.


