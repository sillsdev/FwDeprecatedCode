/***********************************************************************************************
Copyright 1999, SIL International. All rights reserved.

File: Main.h
Responsibility: Darrell Zook
Last reviewed:

Description:
	Contains the declaration of the SilSeqStream class.
***********************************************************************************************/

#ifndef _RUNTEST_H_
#define _RUNTEST_H_

#include <stdio.h>	 // For wprintf
#include <crtdbg.h>  // For memory leaks
#include <conio.h>
#include "common.h"  // COM stuff, etc.
#include "TestHarnessTlb.h"

class SilSeqStream : public ISequentialStream
{
public:
	// Static methods
	static HRESULT Create(FILE * pfile, ISequentialStream ** ppsqst);

	// IUnknown methods
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppv);
	STDMETHOD_(ULONG, AddRef)(void);
	STDMETHOD_(ULONG, Release)(void);

    STDMETHOD(Read)(void * pv, ULONG cb, ULONG * pcbRead);
    STDMETHOD(Write)(void const * pv, ULONG cb, ULONG * pcbWritten);

protected:
	// Member variables
	long m_cref;
	FILE * m_pfile;
};

#endif // !_RUNTEST_H_