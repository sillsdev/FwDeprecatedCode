/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: Main.cpp
Responsibility: Darrell Zook
Last reviewed: Not yet.

Description:
	Provides a command line connection to the test harness.

	Command line arguments:

		RunTest LogFile [ProgID] [Test]

			LogFile		->	Name of the output log file. This file will be stored in the
							FieldWorks\TestLog\Log directory.
			ProgID		->	Specifies the dll containing the test(s) that will be run. If
							this parameter is not included, all tests in all registered
							dlls will be run.
			Test		->	Specifies the 0-based index of the test to be run in the dll
							given by ProgID. If this parameter is not included, all the
							tests in the dll given by ProgID will be run. If the ProgID
							parameter is not included, this parameter is ignored.

	Examples:
		To perform an unattended run of all the tests, use the following:
			runtest log.txt
		To debug one specific test, use the followimg command line in the debugger:
			runtest log.txt SIL.Cellar.Test 0

	The return code of RunTest indicates the number of errors that occurred.
----------------------------------------------------------------------------------------------*/
#include "main.h"

/***********************************************************************************************
	SilTestHarnessSite
/**********************************************************************************************/

class SilTestHarnessSite : public ISilTestHarnessSite
{
protected:
	SilTestHarnessSite()
	{
		m_cFailures = 0;
		m_cTests = 0;
		m_cTime = 0;
		m_cref = 1;
	}

	~SilTestHarnessSite()
	{
		m_cFailures = 0;
	}

public:
	static Create(ISilTestHarness * pqtsth, SilTestHarnessSite ** pptsthsi)
	{
		if (!pqtsth || !pptsthsi)
			return WarnHr(E_POINTER);
		*pptsthsi = NULL;
		SilTestHarnessSite * ptsthsi = NewObj SilTestHarnessSite();
		if (!ptsthsi)
			return WarnHr(E_OUTOFMEMORY);
		ptsthsi->m_qtsth = pqtsth;
		HRESULT hr = ptsthsi->QueryInterface(IID_ISilTestHarnessSite, (void **)pptsthsi);
		ptsthsi->Release();
		return hr;
	}

	// ISilTestHarnessSite
	STDMETHOD(TestResult)(int itstb, int cFailures, int nFlags, int cMs, int * pfCancel)
	{
		m_cFailures += cFailures;
		m_cTime += cMs;
		m_cTests++;

		SmartBstr sbstr;
		m_qtsth->get_TestName(itstb, &sbstr);
		StrAnsi staName = sbstr.Bstr();
		if (staName.Error())
			printf("| %4d  %-44s %6d   %8d  |\n", itstb, "(Unknown)", cFailures, cMs);
		else
			printf("| %4d  %-44s %6d   %8d  |\n", itstb, staName.Chars(), cFailures, cMs);

		if (pfCancel)
			*pfCancel = FALSE;
		return S_OK;
	}

	STDMETHOD(QueryCancel)(int itstb, int * pfCancel)
	{
		if (pfCancel)
			*pfCancel = FALSE;
		return S_OK;
	}

	// IUnknown
	STDMETHOD(QueryInterface)(REFIID riid, void ** ppv)
	{
		if (!ppv)
			return E_POINTER;
		AssertPtr(ppv);
		*ppv = NULL;
		if (riid == IID_IUnknown)
			*ppv = static_cast<IUnknown *>(this);
		else if (riid == IID_ISilTestHarnessSite)
			*ppv = static_cast<ISilTestHarnessSite *>(this);
		else
			return E_NOINTERFACE;
		AddRef();
		return S_OK;
	}
	STDMETHOD_(ULONG, AddRef)(void)
	{
		return InterlockedIncrement(&m_cref);
	}
	STDMETHOD_(ULONG, Release)(void)
	{
		long cref = InterlockedDecrement(&m_cref);
		if (cref == 0)
		{
			m_cref = 1;
			delete this;
		}
		return cref;
	}

	// Additional methods
	void ResetSite()
	{
		m_cFailures = 0;
		m_cTests = 0;
		m_cTime = 0;
	}

	int GetFailureCount()
		{ return m_cFailures; }

	int GetTestCount()
		{ return m_cTests; }

	int GetTime()
		{ return m_cTime; }

protected:
	long m_cref;

	int m_cFailures;
	int m_cTests;
	int m_cTime;
	ISilTestHarnessPtr m_qtsth;
};

int Error(char * pszMsg)
{
	printf("***** Error: ");
	printf(pszMsg);
	return 1;
}

int main(int argc, char * argv[])
{
	// Check for memory leaks
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	if(argc > 4 || argc < 2)
	{
		printf("\nUsage: RunTest LogFile [ProgId] [TestNum]\n\n");
		printf("  If TestNum is not given, all tests in the dll given by ProgID\n");
		printf("    will be run.\n");
		printf("  If ProgID is not given, Test is ignored and all tests in all\n");
		printf("    dlls will be run.\n");
		exit(1);
	}

	int itstb = -1;
	StrUni stuLogFile = argv[1];
	if (stuLogFile.Error())
		return Error("Out of memory.\n");
	StrUni stuProgId;
	if (argc > 2)
	{
		stuProgId = argv[2];
		if (stuProgId.Error())
			return Error("Out of memory.\n");
	}
	if(argc > 3)
		itstb = atoi(argv[3]);

	// Initialize COM libraries
	HRESULT hr;
	hr = CoInitialize(NULL);
	if (FAILED(hr))
		return Error("Could not initialize COM.\n");

	// Create an ISilTestHarness
	ISilTestHarnessPtr qtsth;
	hr = qtsth.CreateInstance(CLSID_SilTestHarness);
	if (FAILED(hr))
		return Error("Could not create the test harness.\n");

	// Create an ISilTestHarnessSite
	SilTestHarnessSite * ptsthsi;
	hr = SilTestHarnessSite::Create(qtsth, &ptsthsi);
	if (FAILED(hr))
		return Error("Could not create the test harness site.\n");

	// Initialize the SilTestHarness and get the number of tests
	int ctst;
	hr = qtsth->Initialize();
	if (FAILED(hr))
		return Error("Could not initialize the test harness.\n");
	hr = qtsth->get_TestCount(&ctst);
	if (FAILED(hr))
		return Error("Could not retrieve the number of registered tests.\n");

	printf("\n -----------------------------------------------------------------------\n");
	printf("| Index Test Name                                    Failures Time (ms) |\n");
	printf("| ----- -------------------------------------------- -------- --------- |\n");

	if (stuProgId)
	{
		// If itstb is -1, this will run all the tests within the given dll.
		// Otherwise, this will run the given test within the given dll.
		hr = qtsth->RunSingle(stuProgId.Bstr(), itstb, stuLogFile.Bstr(), ptsthsi);
	}
	else
	{
		int * prgitst = NewObj int[ctst];
		if (!prgitst)
			return Error("Out of memory.\n");
		for (int itst = 0; itst < ctst; itst++)
			prgitst[itst] = itst;

		// Run all tests in all dlls
		hr = qtsth->RunTests(prgitst, ctst, stuLogFile.Bstr(), ptsthsi);
	}
	if (FAILED(hr))
		return Error("There was a failure while running the tests.\n");

	int cFailures = ptsthsi->GetFailureCount();
	printf(" -----------------------------------------------------------------------\n\n");
	printf("Result: %d test(s) were completed with %d errors in %d ms.\n\n",
		ptsthsi->GetTestCount(), cFailures, ptsthsi->GetTime());

	ptsthsi->Release();
	qtsth = NULL;

	// Must be called after smart pointers have been released
	CoUninitialize();

	return cFailures;
}

