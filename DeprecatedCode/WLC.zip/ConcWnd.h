/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 1999-2002, SIL International. All rights reserved.

File: ConcWnd.h
Responsibility: John Thomson
Last reviewed: Not yet.

Description:
	Implements a simple concordance window.	
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef CONCWND_INCLUDED
#define CONCWND_INCLUDED

// forward declarations
class ConcClientWnd;
class ConcHeaderWnd;
class ConcSplitterWnd;
class ConcTextHeaderWnd;
class ConcWnd;
class ConcFieldEditor;
class ConcFieldEditorWnd;
class ConcVc;
class ConcTextWnd;
class ConcCaptionBar;

typedef GenSmartPtr<ConcClientWnd> ConcClientWndPtr;
typedef GenSmartPtr<ConcHeaderWnd> ConcHeaderWndPtr;
typedef GenSmartPtr<ConcSplitterWnd> ConcSplitterWndPtr;
typedef GenSmartPtr<ConcWnd> ConcWndPtr;
typedef GenSmartPtr<ConcFieldEditor> ConcFieldEditorPtr;
typedef GenSmartPtr<ConcFieldEditorWnd> ConcFieldEditorWndPtr;
typedef GenSmartPtr<ConcVc> ConcVcPtr;
typedef GenSmartPtr<ConcTextWnd> ConcTextWndPtr;
typedef GenSmartPtr<ConcTextHeaderWnd> ConcTextHeaderWndPtr;
typedef GenSmartPtr<ConcCaptionBar> ConcCaptionBarPtr;

// Height of caption bar for the concordance's draft window.
const int kdypcthwCaptionBarHeight = 25;

enum ConcWndFrags
{
	kfrGroup = 100, // debug is easier if different range from tags
	kfrScrRef,
	kfrDetailLine,
	kfrRefPara,
	kfrScripture,
	kfrBook,
	kfrSection,
	kfrContext,
	kfrCount,
};

// Available tags for the Concordance view column headings
enum ConcColTags
{
	ktagHeadword,
	ktagStatus,
	ktagCount,
	ktagReference,
};

// Available tags for what type of references will be displayed in Concordance view
enum ConcReferenceTags
{
	ktagSIL,	// SIL 3-letter code
	ktagName = kflidScrBook_Name,	// Language name
	ktagAbbrev = kflidScrBook_Abbrev,	// Abbrev of language name
};

const PropTag ktagScrBookRef_TitleCaseBookId = 3004999; // Tag to hold Title Case of BookId
const PropTag ktagWfiWordform_TwficCount = 5062999; // Tag to hold count of occurrences

struct ConcColInfo
{
	ConcColTags tag;
	int dxpCurrentWidth;	// Current width of column in pixels
};

// Setting that tells how references will be displayed
struct ConcReferenceInfo
{
	ConcReferenceTags tag;
	int ws;	// Specifies which language writing system will be used (for Name or Abbrev)
};

typedef Vector<ConcColInfo> ConcColVec; //Hungarian vcci

/*----------------------------------------------------------------------------------------------
	The WfiChangeWatcher class receives notifications of new (and eventually deleted) wordforms
	and implements the desired side effects of adding/removing field editors in the concordance
	view.
	Hungarian: wfichgw
----------------------------------------------------------------------------------------------*/

class WfiChangeWatcher : public AfChangeWatcher
{
	typedef AfChangeWatcher SuperClass;

public:
	void Init(ISilDataAccess * psda, ConcWnd * pconw); 

protected:
	//these are the member variables needed to carry out the side effects we desire
	//note: Because this class will be registered in the CustViewDa by AfChangeWatcher
	// and tracked there by a smart pointer, 
	// use regular pointers in this class so that it won't be deadlocked when Da is going away.
	ConcWnd * m_pconw;

	// we define this pure virtual function to do the effects we desire
	void DoEffectsOfPropChange(HVO hvoPara, int ivMin, int cvIns, int cvDel);
};

DEFINE_COM_PTR(WfiChangeWatcher);


/*----------------------------------------------------------------------------------------------
	Constructs a view of a word group as top-level object, either as a list
	of object IDs (if not expanded) or as a table of context + ID pairs.
	@h3{Hungarian: cvc}
----------------------------------------------------------------------------------------------*/
class ConcVc : public VwBaseVc
{
public:
	ConcVc(int encVern, ConcHeaderWnd * pchw, ConcFieldEditor * pcfeOwner);
	STDMETHOD(UpdateProp)(ISilDataAccess * psda, HVO hvo, int tag, int frag,
								ITsString * ptssVal, ITsString ** pptssRepVal);
	STDMETHOD(Display)(IVwEnv* pvwenv, HVO vwobj, int frag);
	STDMETHOD(EstimateHeight)(HVO hvo, int frag, int dxAvailWidth, int * pdyHeight);
	STDMETHOD(LoadDataFor)(IVwEnv * pvwenv, HVO * prghvo, int chvo, HVO hvoParent,
		int tag, int frag, int ihvoMin);
#ifdef NEED_DISPLAY_VEC
	STDMETHOD(DisplayVec)(IVwEnv * pvwenv, HVO hvo, int tag, int frag);
#endif
	void SetExpansion(DeTreeState dts)
	{
		m_dtsExpanded = dts;
	}
	// Border thickness about a pixel. This function returns pixels.
	static int GetDetailBorderWidth() { return 1; }
	// Indent detail row by .1 inch. This function returns millipoints.
	static int GetDetailLineIndent() { return (kdzmpInch / 10); }
	// ENHANCE RonM(TomB): Instead of hard-coding 3/4 of an inch, calculate a reasonable
	// value based on the kind of reference being displayed.
	// This function returns millipoints.
	static int GetRefColWidth() { return (kdzmpInch * 3 / 4); }

protected:
	void GetBookAsString(ISilDataAccessPtr qsda, HVO hvoTwfic, SmartBstr &sbstrBook);
	DeTreeState m_dtsExpanded; // The current state of the tree node.
	ConcHeaderWnd * m_pchw;
	ConcFieldEditor * m_pcfeOwner;
	int m_wsVern; // Vernacular writing system to display where needed.
	ITsStrFactoryPtr m_qtsf;
};

/*----------------------------------------------------------------------------------------------
	Implements one main word in the window.
	@h3{Hungarian: cfe}
----------------------------------------------------------------------------------------------*/
class ConcFieldEditor : public AfDeFeVw
{
private:
	typedef AfDeFeVw SuperClass;

public:

	ConcFieldEditor(HVO hvoGroup, CustViewDa * pcvd, ConcHeaderWnd * pchw);
	virtual ~ConcFieldEditor();

	DeTreeState GetExpansion()
	{
		return m_dtsExpanded;
	}

	void SetExpansion(DeTreeState dts)
	{
		Assert(dts == kdtsExpanded || dts == kdtsCollapsed);
		m_dtsExpanded = dts;
	}
	void ToggleExpansion();
	void ConcFieldEditor::Expand();
	void ConcFieldEditor::Collapse();
	void MakeRoot(IVwGraphics * pvg, ILgWritingSystemFactory * pwsf, IVwRootBox ** pprootb);
	int SetHeightAt(int dxpWidth);
	virtual void OnReleasePtr();
    void SetTableColWidths(VwLength *prgvlen, int cvlen);
	int GetBranchWidth();
	void SetSelected(bool fSelected = true, bool fUpdateProps = true);
	virtual bool IsSelected() {return m_fSelected;}
	bool IsHvoSelected(HVO hvo);
	// This field can be made editable
	virtual bool IsEditable()
	{
		return true;
	}
	bool HeadwordChanged(StrUni &stuOrig, StrUni &stuNew);
	virtual bool IsOkToClose();

	// Saves changes, destroys the window, and sets m_hwnd to 0.
	// If it is possible to have bad data, the user should call IsOkToClose() first.
	virtual void EndEdit(bool fForce = false);

	HVO GetHvoGroup() { return m_hvoGroup; }
	virtual AfDeVwWnd * CreateEditWnd(HWND hwndParent, Rect & rcBounds);
	ConcHeaderWnd * GetConcHeaderWnd() {return m_pchw;}
	// This function returns pixels.
	static int GetDetailRefColRightMarginPos()
	{
		HDC hdc = ::GetDC(NULL);
		int xMillipointsPerPixel = kdzmpInch / ::GetDeviceCaps(hdc, LOGPIXELSX);
		::ReleaseDC(NULL, hdc);
		return (s_nBranchWidth + ConcVc::GetDetailBorderWidth() +
			(ConcVc::GetDetailLineIndent() + ConcVc::GetRefColWidth()) / xMillipointsPerPixel);
	}
protected:
	DeTreeState m_dtsExpanded; // The current state of the tree node.
	HVO m_hvoGroup; // The object id for the word group.
	ConcHeaderWnd * m_pchw;
	ConcVcPtr m_qcvc;
	CustViewDaPtr m_qcvd;
	bool m_fSelected;
	bool m_fTwficDataLoaded;
	static const int s_nBranchWidth = kdxpLeftMargin + kdxpBoxWid + kdxpRtTreeGap;
};

/*----------------------------------------------------------------------------------------------
	The main class that implements the concordance window.
	@h3{Hungarian: cfe}
----------------------------------------------------------------------------------------------*/
class ConcFieldEditorWnd : public AfDeVwWnd
{
private:
	typedef AfDeVwWnd SuperClass;

public:
	ConcFieldEditorWnd(ConcFieldEditor * pcfe) : SuperClass(pcfe)
	{
		m_pcfe = pcfe;
	};
	
	virtual bool OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	virtual bool OnLButtonDown(uint grfmk, int xp, int yp);
	virtual bool OnKillFocus(HWND hwndNew);

protected:
	ConcFieldEditor * m_pcfe;

	// For (dis)enabling the state of the toolbar buttons.
	virtual bool CmsCharFmt(CmdState & cms);
};

/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
class ConcCaptionBar : public AfCaptionBar
{
	typedef AfCaptionBar SuperClass;

public:
	ConcCaptionBar();
	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);
};

// Identifier for timer.
const int kidWaitForDBLCLK = 777;
const int kidFocusClickDelay = 778;

/*----------------------------------------------------------------------------------------------
	The main class that implements the concordance window.
	@h3{Hungarian: conw}
----------------------------------------------------------------------------------------------*/
class ConcWnd : public AfLazyDeWnd
{
	friend class ConcFieldEditor;
	friend class ConcFieldEditorWnd;

private:
	typedef AfLazyDeWnd SuperClass;

public:
	ConcWnd(ConcHeaderWnd * pchw);
	void ToggleExpansion(int idfe);
	void Init(CustViewDa * pcvd);
	virtual void PostAttach(void);
	void InsertWordform(int i);
	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);
	virtual bool OnContextMenu(HWND hwnd, Point pt);
	virtual bool OpenNextEditor(int dxpCursor = 0);
	virtual bool OpenPreviousEditor(int dxpCursor = 0, bool fTopCursor = true);
	virtual bool OpenEditor(int idfe, bool fSearch);
	virtual bool OnKeyDown(WPARAM wp, LPARAM lp);
	virtual void OnLButtonDownInEditor(int idfe, AfDeFieldEditor * pdfe, int dypFieldTop,
		uint grfmk, int xp, int yp);
	virtual bool OnLButtonDblClk(uint grfmk, int xp, int yp);
	virtual bool ProcessLClick(uint grfmk, int xp, int yp);
	virtual void EditData(int xp, int yp);

	virtual const COLORREF GetSeparatorLineColor();
	virtual const int GetSeparatorLineDotSpacing() {return 2;}
	virtual int GetBranchWidth(AfDeFieldEditor * pdfe);

	// On menu command and On menu update functions for spelling status.
	bool CmdChangeSpellingStatus(Cmd * pcmd);
	bool CmsUpdateSpellingStatusPopup(CmdState & cms);
	
	// if editors might be open, do not override fCloseEditors
	void ResetVdfeSize(bool fCloseEditors = true);
	void ReDrawColumns();
	virtual void OnReleasePtr();
	virtual AfDeFieldEditor * MakeEditorAt(int idfe);
	bool EndEdit(HWND hwndNew = 0);
	void GetPrevLineInfo(HVO hvoRelative, int icfeRelative, HVO * phvoNew, int * picfeNew);
	void GetNextLineInfo(HVO hvoRelative, int icfeRelative,	HVO * phvoNew, int * picfeNew);

	HVO HvoCurrent() {return m_hvoCurrent;}
	bool HasFocus() {return m_fHasFocus;}

protected:
	ConcHeaderWnd * m_pchw;
	CustViewDaPtr m_qcvd;
	HVO m_hvoWordformInventory;
	ITsStringPtr m_qtssLabel;
	WfiChangeWatcherPtr m_qwfichgw; // watches for wordform inventory changes
	int m_lpLBUTTONDOWNSaved;

    // TLB 2001-04-11: Added function override to make tree pane have same
    // background color as the rest of the client area
    virtual const COLORREF GetTreeBackgroundColor()
    {
        return ::GetSysColor(COLOR_WINDOW);
    }

	int m_icfeCurrent;// Current (selected) field editor
	HVO m_hvoCurrent; // Current data item (headword or detail line)
	
	// Indicates whether this window (or one of its field editors has focus).
	bool m_fHasFocus;

	// Indicates whether a double clikc is being processes
	bool m_fDblClkInProgress;

	bool m_fIgnoreLButtonDown;
	bool m_fIgnoreLButtonUp;

	bool IgnoreLButtonDown() {return m_fIgnoreLButtonDown;}
	void SetIgnoreLButtonDown(bool fIgnoreLButtonDown)
		{ m_fIgnoreLButtonDown = fIgnoreLButtonDown;}

	bool IgnoreLButtonUp() {return m_fIgnoreLButtonUp;}
	void SetIgnoreLButtonUp(bool fIgnoreLButtonUp)
		{ m_fIgnoreLButtonUp = fIgnoreLButtonUp;}

	void SetCurrentLine(HVO hvo, int icfe = -1, bool fMakeVisible = true);
	void MakeCurrentVisible();
	
	CMD_MAP_DEC(ConcWnd);

public: // this a bit of a kludge
	int m_nProgress; // steps each time a field editor is laid out.
	int m_nWords;
};

/*----------------------------------------------------------------------------------------------
	This forms the main body of the Concordance. It supports a horizontal splitter bar. The
	superclass does most of the work; we just have to know how to create a child window.
	@h3{Hungarian: ccw}
----------------------------------------------------------------------------------------------*/
class ConcClientWnd : public AfClientWnd
{
	friend class ConcSplitterWnd;
	friend class ConcTextHeaderWnd;
	friend class ConcTextWnd;

	typedef AfClientWnd SuperClass;

public:
	ConcClientWnd() {}
	
	void LoadConcWindowPosition(const achar * pszRoot);
	void SaveConcWindowPosition(const achar * pszRoot);

	virtual void SaveSettings(const achar * pszRoot, bool fRecursive = true);
	virtual void OnReleasePtr();
	virtual void PostAttach(void);
	virtual bool OnSize(int wst, int dxp, int dyp);
	virtual bool OnChildEvent(int ceid, AfWnd * pAfWnd, void * lpInfo = NULL);
	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);
	virtual void RefreshDisplay();
	ConcHeaderWnd * GetConcHeaderWnd() {return m_qchw;}
	ConcTextHeaderWnd * GetTextHeaderWindow() {return m_qcthw;}
	CustViewDa * GetCustViewDa() {return m_qcvd;}
	HWND GetChildWithFocus() {return m_hChildWithFocus;}
	void SetChildWithFocus(HWND hwnd) {m_hChildWithFocus = hwnd;}
	ISilDataAccessPtr GetSilDa() {return (ISilDataAccessPtr)m_qcvd;}
	inline IVwStylesheet * GetStyleSheet()
	{
		return m_qsty;
	}

protected:
	HVO m_hvoScripture;				// root object to concord
	CustViewDaPtr m_qcvd;			// contains data to concord
	IVwStylesheet * m_qsty;			// Stylesheet to be used for Scripture
	ConcHeaderWndPtr m_qchw;		// Header window for concordance.
	ConcTextHeaderWndPtr m_qcthw;	// Header window for draft window (below concordance).
	Rect m_rccthwCoords;			// Keeps track of window coordinates for draft window.
	
	// Keeps track of which of ConcClientWnd's sub windows currently has or last had
	// focus. The possibilties are one of two ConcWnd (possibly two if window is split)
	// or the concordance's draft window (i.e. ConcTextWnd).
	HWND m_hChildWithFocus;
};

/*----------------------------------------------------------------------------------------------
	This forms the main body of the Concordance. It supports a column heading bar.
	The superclass does most of the work; we need to create the child window and deal
	with the columns.
	@h3{Hungarian: chw}
----------------------------------------------------------------------------------------------*/
class ConcHeaderWnd : public AfHeaderWnd
{
//	friend class ConcSplitterWnd;
	typedef AfHeaderWnd SuperClass;
public:
	ConcHeaderWnd(ConcClientWnd * pccw)
	{
		m_pccw = pccw;
	}

	const ConcColVec& vcci() const {return m_vcci;}
	const ConcReferenceInfo& cri() const {return m_cri;}
	void ChangeColWidth(int icwi, int dxpNew);
	void RefreshConc(void);
	virtual void OnReleasePtr(void);
	virtual void PostAttach(void);
	virtual void ReDrawColumns(void);
	virtual void LoadSettings(const achar * pszRoot, bool fRecursive = true);
	virtual void SaveSettings(const achar * pszRoot, bool fRecursive = true);
	virtual bool OnSize(int wst, int dxp, int dyp);
	ConcClientWnd * GetClientWindow() {return m_pccw;}
	ConcSplitterWnd * GetSplitterWindow() {return m_qcsw;}
	int GetConcDetailLineHeight() { return m_dypConcDetailLineHeight;}

protected:
	ConcColVec m_vcci;
	ConcSplitterWndPtr m_qcsw;
	ConcClientWnd * m_pccw;
	ConcReferenceInfo m_cri;
	HWND m_hwndCurrentPane;
	int m_dypConcDetailLineHeight;
};

/*----------------------------------------------------------------------------------------------
	This is a split frame subclass that exists solely to implement ConcClientWnd.

	@h3{Hungarian: csw}
----------------------------------------------------------------------------------------------*/
class ConcSplitterWnd : public AfSplitFrame
{
	friend class ConcClientWnd;
	friend class ConcHeaderWnd;
	typedef AfSplitFrame SuperClass;

public:
	virtual void CreateChild(AfSplitChild * psplcCopy, AfSplitChild ** psplcNew);
	void RefreshConc(void);
	virtual void ReDrawColumns(void);

protected:
	ConcClientWnd * m_pccw;
	
	// Protected constructor prevents anyone not a friend from making one.
	ConcSplitterWnd(ConcClientWnd * ccw)
	{
		m_pccw = ccw;
	}
};

// Caption Bar's border width for the concordance's draft window.
const int kdzscthwCaptionBorderWidth = 3;

/*----------------------------------------------------------------------------------------------
	This forms the main body of the Concordance. It supports a column heading bar.
	The superclass does most of the work; we need to create the child window and deal
	with the columns.
	@h3{Hungarian: cthw}
----------------------------------------------------------------------------------------------*/
class ConcTextHeaderWnd : public AfHeaderWnd
{
	friend class ConcTextWnd;

private:
	typedef AfHeaderWnd SuperClass;

public:
	ConcTextHeaderWnd(ConcClientWnd * pccw)
	{
		m_pccw = pccw;
	}

	virtual void OnReleasePtr();
	virtual void PostAttach(void);
	void Refresh(void);
	ConcTextWnd * TextWindow() {return m_qctw;}

protected:
	virtual bool OnSize(int wst, int dxp, int dyp);
	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);

	ConcTextWndPtr m_qctw;
	ConcClientWnd * m_pccw;
};


/*----------------------------------------------------------------------------------------------
	The main class that implements the text window.
	@h3{Hungarian: ctw}
----------------------------------------------------------------------------------------------*/
class ConcTextWnd : public AfVwScrollWnd
{
	friend class ConcClientWnd;
	friend class ConcTextHeaderWnd;

private:
	typedef AfVwScrollWnd SuperClass;

public:
	void Init(CustViewDa * pcvd, HVO hvoScripture);
	void MakeRoot(IVwGraphics * pvg, ILgWritingSystemFactory * pwsf, IVwRootBox ** pprootb);
	virtual void OnReleasePtr();
	void SelectTwfic(HVO hvoTwfic);

protected:
	virtual bool OnSetFocus(HWND hwndOld, bool fTbControl = false);
	virtual bool OnKillFocus(HWND hwndNew);
	virtual void HandleSelectionChange(IVwSelection * pvwsel);
	void Refresh(void);

	HVO m_hvoScripture;
	CustViewDaPtr m_qcvd;
	DraftTextVcPtr m_qdvc;
	ConcTextHeaderWnd * m_pcthwParent; // Don't use a smart pointer, it would make a cycle.
	RecordSpecPtr m_qrsp;
	
	// For (dis)enabling the state of the toolbar buttons.
	virtual bool CmsCharFmt(CmdState & cms);
	// For displaying TE specific Styles Dialog
	virtual bool OpenFormatStylesDialog(HWND hwnd, bool fCanDoRtl, bool fOuterRtl,
		IVwStylesheet * past, TtpVec & vqttpPara, TtpVec & vqttpChar, bool fCanFormatChar,
		StrUni * pstuStyleName, bool & fStylesChanged, bool & fApply, bool & fReloadDb);
};


#endif //!CONCWND_INCLUDED
