/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2002 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TeStyleDlg.h
Responsibility: Eberhard Beilharz
Last reviewed: never

Description:
	Definition of TE specific Styles Dialog. This dialog overrides the general Style Dialog
	and adds some additional controls.
		
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef TESTYLEDLG_INCLUDED
#define TESTYLEDLG_INCLUDED 1

/*----------------------------------------------------------------------------------------------
	A style can be non-published or published, and the third possibility is that we want to have
	all styles.
	@h3{Hungarian: testt}
----------------------------------------------------------------------------------------------*/
enum StyleTextTypes
{
	ksttNonpublished = 0,
	ksttPublished = 1,
	ksttAll,
	ksttLim
};

/*----------------------------------------------------------------------------------------------
	TE specific Format Styles dialog shell class.
		
	@h3{Hungarian: tesd}
----------------------------------------------------------------------------------------------*/
class TeStylesDlg: public AfStylesDlg
{
private:
	typedef AfStylesDlg SuperClass;

	friend class TeFmtGenDlg;

public:
	// C'tor
	// @param fShowAll - if true show all styles in listview instead of selecting according 
	//		to text type of style
	TeStylesDlg(bool fShowAll = false)
		: m_hwndList(NULL), m_fShowAll(fShowAll)
	{
		m_rid = kridTeStyleDlg;
	}

	//:>****************************************************************************************
	//:>	Use these additional methods to set StyleInfo member variables whenever the m_fDirty 
	//:>	variable needs to be set.
	//:>****************************************************************************************

	// Set the text type of this paragraph style to be fPublished and return true; 
	// set m_fDirty to true.
	bool SetPublished(StyleInfo & styi, bool fPublished);
	// Set the Usage for this paragraph style to be stuNewUsage and return true; 
	// set m_fDirty to true.
	bool SetUsage(StyleInfo & styi, const StrUni & stuNewUsage);

protected:
	// The app framework calls this to initialize the dialog controls prior to displaying the
	// dialog.
	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	// create the sub dialogs
	virtual void SetupTabs();
	// Process notifications from the user.
	virtual bool OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet);
	// Returns true if style should not be shown in dialog
	// The default implementation always returns false and so shows all styles.
	virtual bool SkipStyle(int iStyle) const;
	// Set initial values for the dialog controls, prior to displaying the dialog.
	virtual void SetDialogValues();
	// Create a new style
	virtual bool MakeNewStyi(const StyleType stype, StyleInfo * pstyi);
	// Copy a style to a new one
	virtual bool CopyStyi(const StyleInfo & styiSrc, StyleInfo & styiDest);
	// Delete the selected style in response to the Delete button being pressed.
	virtual bool CmdDel();

	HWND m_hwndList; // Handle to the list combo box
	bool m_fShowAll; // if true initially show all styles instead of selecting from text type
};

/*----------------------------------------------------------------------------------------------
	This class provides the functionality particular to the General tab for the
	TE Format/Styles Dialog.

	@h3{Hungarian: tefgen}
----------------------------------------------------------------------------------------------*/
class TeFmtGenDlg : public FmtGenDlg
{
private:
	typedef FmtGenDlg SuperClass;

public:
	/*------------------------------------------------------------------------------------------
		Constructor for creating the General tab for the given AfStylesDlg.
	------------------------------------------------------------------------------------------*/
	TeFmtGenDlg(AfStylesDlg * pafsd)
		: FmtGenDlg(pafsd), m_hwndUsage(NULL)
	{
		m_rid = kridTeFmtGenDlg;
		m_pszHelpUrl = _T("TEDialogStyleGeneralTab.htm");
	}

	// Set initial values for the dialog controls, prior to displaying the dialog.
	virtual void SetDialogValues(StyleInfo & styi, Vector<int> & vwsProj);
	// Get the final values for the dialog controls, and set fBasedOnChanged to say whether
	// "Based On" was changed.
	virtual void GetDialogValues(StyleInfo & styi, bool & fBasedOnChanged);

protected:
	// The app framework calls this to initialize the dialog controls prior to displaying the
	// dialog.
	bool OnInitDlg(HWND hwndCtrl, LPARAM lp);

	HWND m_hwndUsage; // Window handle for the Usage edit control.
};

/*----------------------------------------------------------------------------------------------
	Dialog which allows the user to select the text type for a new/copied style
		
	@h3{Hungarian: tettd}
----------------------------------------------------------------------------------------------*/
class TeTextTypeDlg: public AfDialog
{
private:
	typedef AfDialog SuperClass;

public:
	// c'tor
	TeTextTypeDlg()
		: m_fNonPubText(false)
	{
		m_rid = kridTeSelectTextType;
		m_pszHelpUrl = _T("SelectTextTypeDlg.htm");
	}
	// called before DoModal() set the variables
	void SetDialogValues(bool fPublished = true)
	{
		m_fNonPubText = !fPublished;
	}
	// called after DoModal() to get the text type the user selected
	void GetDialogValues(bool & fPublished)
	{
		fPublished = !m_fNonPubText;
	}

protected:
	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	virtual void DoDataExchange(AfDataExchange * padx);

	bool m_fNonPubText;	// true: non-published text; false: published text
};

#endif // TESTYLEDLG_INCLUDED

