/*----------------------------------------------------------------------------------------------
Copyright 2000-2002, SIL International. All rights reserved.

File: TeImport.h
Responsibility: Bryan Wussow
Last reviewed: never

Description:
	This file contains the classes for Scripture Import.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef TEIMPORT_INCLUDED
#define TEIMPORT_INCLUDED 1


enum ImportTagType	// special tag info needed for import
{
	kittGeneral,
	kittStartOfBook,
	kittStartOfChapter,
	kittVerseNumber, // also treat this a verse text
	kittTitleText,
	kittSectionHeadText,
	kittVerseText,
	kittStartOfFootnote,
	kittFootnoteAddlPara, 
	kittEndMarker, // proxy represents an end marker, not a style
	kittLim
};


/*----------------------------------------------------------------------------------------------
	ImportStyleProxy
	Objects of this class represent a style (real or potential) that is mapped to
	an import tag. A hash map (eg m_hmstuisy) owns these proxies and provides the mapping.

	Note on implementation of end markers:
	For proxies that represent a char style or a footnote start, an end marker may optionally 
	be saved in the proxy's member variables. In addition, another proxy is created for the 
	end marker itself, for the only purpose of identifying the marker as a kittEndMarker.
----------------------------------------------------------------------------------------------*/
class ImportStyleProxy : public GenRefObj	// hungarian: isy
{
public:
	typedef GenRefObj SuperClass;

	 // Constructor
	ImportStyleProxy(StrUni stuStyleName, int nStyleType, int ws,
		ImportTagType ittTagType = kittGeneral);
	//virtual ~ImportStyleProxy();

	// Get the unknown mapping flag
	bool IsUnknownMapping()
	{return m_fUnknownMapping;}

	// Set the format vars for this potential style
	// used when this is an undefined mapping, to prepare for possibly adding a real style
	void SetFormat(ITsTextProps * pttpFormat, ComBool fIsScriptureStyle);

	// Set the end marker of current proxy
	// used optionally if this is a char style or a footnote start
	void SetEndMarker(SmartBstr & sbstrEndMarker);

	// Map this proxy (defined or undefined mapping) to the given style name
	// used when user edits the mapping table (chooses from list, or types a stylename)
	void MapToStyle(StrUni stuStyleName);
	void MapToStyle(StrUni stuStyleName, int ws); //how can user select encoding???

	// Get the text property vars for this proxy. Used during import processing
	// if this proxy is an undefined mapping, create the new style and map to it
	void GetTextProps(ITsTextProps ** ppttp, StrAnsi & staParaProps);

	// Return simple properties
	int StyleType()
		{ return m_nStyleType;}

	ImportTagType TagType()
		{ return m_ittTagType; }

	StrUni EndMarker()
		{ return m_stuEndMarker; }

private:

	// Set the text property vars for this proxy, from the name, type, & ws
	// Used by constructor
	void SetTextProps();

	// Add a new real style in the stylesheet for this proxy.
	void AddStyleToStylesheet();

// member variables
	StrUni m_stuStyleName; // style proxy name (real or potential style name)
	int m_nStyleType; //style type kstParagraph, kstCharacter
	int m_ws; // writing system and old writing system
	ImportTagType m_ittTagType; // special tag info needed for import
	StrUni m_stuEndMarker; // end marker for this, if char style or footnote start

	// If m_fUnknownMapping is true, this proxy is a potential style, not yet in the stylesheet
    // If/when it is really needed during import, we add it to the stylesheet
	// immediately and set m_fUnknownMapping to false.
	bool m_fUnknownMapping; 

	// Text property vars for the text to be tagged with this style
	ITsTextPropsPtr m_qttpForTss; // textprops for tsstring
		// (for char style, contains ws & char style name; for para style contains ws only)
	StrAnsi m_staParaProps; // serialized bytes for textprops for paragraph 
		// (for char style, empty; for para style contains para style name)

	// If style name is not yet in stylesheet, we hold type & formatting info here 
	// for if/when the style must be added
	ITsTextPropsPtr m_qttpFormat; // formatting properties
	ComBool m_fIsScriptureStyle;

// static stuff
public:
	// must call SetStylesheet before you construct ImportStyleProxy(s)
	static void SetStylesheet (IVwStylesheet * psts);
private:
	static IVwStylesheet * s_psts;
	// bool s_fNewMarkers; // some new tags have no mapping, present mapping dialog to user
	// bool s_fTypeOverride;

}; //end of class ImportStyleProxy

DEFINE_COM_PTR(ImportStyleProxy);

typedef ComHashMapStrUni<ImportStyleProxy> ISProxyMap; // Hungarian: hmstuisy


/*----------------------------------------------------------------------------------------------
	This class exists purely to implement the ImportScripture method. It allows us to break
	up the logic and allow the various sub-methods to share access to state data.
	TODO RonM(TomB): Implement incremental loading.
----------------------------------------------------------------------------------------------*/
const kcbFmtBufMax = 1024;
//#define kcchRunBufLen 5000 // if we buffer runs of text in a fixed buffer
class ScriptureImporter
{

public:
	// Constructor
	ScriptureImporter(StrUni stuSettingsFile, StrUni stuStartRef, StrUni stuEndRef,
		SeMainWnd * ptmw);

	// Initialize the scripture importer
	void Initialize();

	// Main loop to get and process each scripture text segement
	void MainLoop();

	void Finalize();


protected:
	// Load the import mappings from the database
	void LoadImportMappings();

	// Process this scripture text segment 
	void ProcessSegment();

	// Get the verse part of the reference from current Scripture segment into m_stuVerseRef
	// and set ref status variables if needed
	void GetVerseRef();

	// Add the given text & props to the current paragraph
	void AddTextToPara(SmartBstr & sbstrText, ITsTextProps * pttpProps); 
	void AddTextToPara(StrUni stuText, ITsTextProps * pttpProps); 
	void AddTextToPara(const OLECHAR* rgchText, int cchText, ITsTextProps * pttpProps); 
	// When finished calling AddTextToPara for current para, call this to trim/flush
	void AddTextToParaTrimFlush(); 

	// Begin a footnote
	void BeginFootnote(StrAnsi staParaProps);
	// someday handle additional paragraphs in a footnote
	//void ScriptureImporter::AddParaToFootnote(StrAnsi staParaProps)
	// Add the given text & props to the current footnote
	void AddTextToFootnote(SmartBstr & sbstrText, ITsTextProps * pttpProps);
	// When finished calling AddTextToFootnote for current note, call this to process & save
	void EndFootnote(); 

	// This method must be called before we create the new section (i.e., m_hvoSection still
	// has to be set for the section we just finished parsing).
	void SetRefsForSection();

	// Makes a section.
	void MakeSection();

	// MakeBook() deletes an existing book (if any) and creates a new one having the
	// "canonical" book number m_nBookNumber. The hvo of the new book is stored in
	// m_hvoBook. It also creates a title object for the book and puts the hvo of the
	// title in m_hvoTitle.
	void MakeBook();

	// Append (save) the new paragraph in m_qtssPara to the database.
#ifndef JR_PERFORMANCE_TEST
	void AppendParaToDb(HVO hvoOwner, int ord, byte *rgbParaFmt, int cbParaFmtSize, 
		HVO &hvoPara);
#else
	void AppendParaToDb(HVO hvoOwner, HVO &hvoParaPrev, byte *rgbParaFmt, int cbParaFmtSize,
		HVO &hvoPara);
#endif

	// If we have any pending text make a TsString out of it (in m_qtssPara).
	// Add it to the current section (or make one if we don't have one).
	// If we don't already have a current book make that also.
	void MakeParagraph();


	// Member Variables.

	StrUni m_stuSettingsFile; // Meta-file containing Scripture project info
	StrUni m_stuStartRef; // first reference we want to import
	StrUni m_stuEndRef; // last verse (inclusive) we want to import.
	SeMainWnd * m_ptmwMainWnd; // main window doing the importing

	SeLpInfo * m_pwlpi; // Lang Proj info for that main window (into which we import)
	CustViewDaPtr m_qcda; // Data access object that will handle updates to the database
	IOleDbEncapPtr m_qode;
	HVO m_hvoScripture; // Scripture object we are importing into
	TeStylesheet * m_ptsts; //Stylesheet we are using
	int m_wsVern; // The writing system we use for all vernacular text.
	int m_wsAnal; // The writing system we use for all non-vernacular text.

	// the Paratext scripture object
	ComSmartPtr<ISCScriptureText> m_qsso;
	ComSmartPtr<ISCTextEnum> m_qsteTextEnum; // and the TextEnum which will give us the data

	// Text segment, gets advanced through the text.
	ISCTextSegment * m_psctsTextSeg;
	SmartBstr m_sbstrSegmentText; //the text contents of the current segment

	// Tag, provides property info for each text segment the ScriptureObject gives us
	ComSmartPtr<ISCTag> m_qsctTag;
	SmartBstr m_sbstrMarker;
	SCTextProperties m_sctpTextProps;
	SCStyleType m_scstStyleType;
	SCTextType m_scttTextType;

	// Hashmap of StrUni (import marker/tag) to import style proxy
	ISProxyMap m_hmstuisy; 

	// serialized bytes for textprops (para style) for special types of paragraphs
	StrAnsi m_staBookTitleParaProps; 
	StrAnsi m_staSectionHeadParaProps; 
	StrAnsi m_staDefaultParaProps;

	ITsStrFactoryPtr m_qtsf; // Factory for whenever we want to create TsStrings.
	// We will use this string builder to construct paragraph strings.
	ITsStrBldrPtr m_qtsbPara;
	int m_cchTsbPara; // index of the next available character in m_qtsbPara
	// Contents of the current paragraph, produced by builder.
	ITsStringPtr m_qtssPara; 

	OLECHAR m_chParaFinalChar; //the current final character sent to the Para builder
		// if we define BUFFERSBSTR
		// We buffer the most recent run of text for the current paragraph in these
		//SmartBstr m_sbstrRunText;
		//ITsTextPropsPtr m_qttpRunProps;

	// We build these special TsTextProps
	ITsTextPropsPtr m_qttpVern;
	ITsTextPropsPtr m_qttpAnal;
#define oldtitlestuff
#ifdef oldtitlestuff
	// eliminate these when title processing gets updated
	ITsTextPropsPtr m_qttpTitleSecondaryText;
	int m_cbBookTitleFmtSize;
	byte m_rgbBookTitleFmt[kcbFmtBufMax];
#endif

	// REVIEW JohnW (TomB): Confirm that there are no situations where we want to retain
	// empty paragraphs. Are there situations where empty paragraphs should be treated as
	// space-before, space-after, etc.?
#ifdef ALLOW_SOME_EMPTY_PARAGRAPHS
	bool m_fSuppressEmptyPara;
#endif

	// status information as segements are imported
	StrAnsi m_staCurrentParaProps; // serialized bytes for textprops for current paragraph 
	bool m_fInSectionHeading;
	bool m_fInCharStyleWEnd; // in a char style that has an end marker
	StrUni m_stuCharStyleEndMarker;
	bool m_fInFootnote;
	StrUni m_stuFootnoteEndMarker;
	bool m_fVersePara; // Does current paragraph contain verse text?
	bool m_fVerseNumFoundInPara; // Has a verse num been encountered in current paragraph yet?
	StrUni m_stuVerseRef; // "2-6a"
	// ParaRefStartFirst and ParaRefStartLast together represent the starting reference for
	// the paragraph. Usually they will be the same, but if the paragraph starts with a
	// verse bridge, then they will be different.
	int m_nParaStartRefFirst, m_nParaStartRefLast;
	int m_nPrevVerseFirst, m_nPrevVerseLast;
	short m_nBookNumber;
	short m_nChapter;

	HVO m_hvoBook; // Book we are currently adding to.
	HVO m_hvoSection; // Section we are adding to
	HVO m_hvoTitle;
	int m_iSection; // index of next section to insert.
//#define JR_PERFORMANCE_TEST
#ifndef JR_PERFORMANCE_TEST
  	int m_iPara; // index of next regular paragraph to insert.
  	int m_iTitlePara; // index of next title paragraph to insert
#else
	HVO m_hvoParaPrev; // HVO of previous regular paragraph.
	HVO m_hvoTitleParaPrev; // HVO of previous  title paragraph.
#endif
	int m_nSectionStartRef; // Starting reference for a section

	SmartBstr m_sbstrTitle; // Vernacular title of book
	HVO m_hvoSectionHeading;
	HVO m_hvoSectionContent;

	StrUni m_stuSql; // use whenever we want to construct an SQL command

}; //end of class ScriptureImporter

#endif // TEIMPORT_INCLUDED

