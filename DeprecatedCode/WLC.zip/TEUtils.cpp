/*----------------------------------------------------------------------------------------------
Copyright 2000-2002, SIL International. All rights reserved.

File: WLC.cpp
Responsibility: Ron McGarvey
Last reviewed: never

Description:
	This file contains andy little utility functions for Translation Editor.
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop

#include "Vector_i.cpp"

#undef THIS_FILE
DEFINE_THIS_FILE

/*----------------------------------------------------------------------------------------------
	Handy little utility function for getting Book, Chapter, and Verse from a BBCCCVVV integer.
----------------------------------------------------------------------------------------------*/
void GetBCV(int nVerseRef, int &nBook, int &nChap, int &nVerse)
{
	int nT = nVerseRef / 1000;
	nVerse = nVerseRef - (nT * 1000);
	nBook = nT / 1000;
	nChap = nT - (nBook * 1000);
}

/*----------------------------------------------------------------------------------------------
	Handy little utility function for making a Reference string.
----------------------------------------------------------------------------------------------*/
void MakeReferenceString(ITsStringPtr qtssBookName, int nBbCccVvvStart, int nBbCccVvvEnd, 
	StrUni &stuReference)
{
	int nBook, nChapterStart, nChapterEnd, nVerseStart, nVerseEnd;
	const OLECHAR * pchBookName;
	int cch;
	CheckHr(qtssBookName->LockText(&pchBookName, &cch));
	stuReference.Assign(const_cast<OLECHAR *>(pchBookName), cch);
	CheckHr(qtssBookName->UnlockText(pchBookName));

	GetBCV(nBbCccVvvStart, nBook, nChapterStart, nVerseStart);
	GetBCV(nBbCccVvvEnd, nBook, nChapterEnd, nVerseEnd);

	if (nChapterStart != nChapterEnd)
	{
		stuReference.FormatAppend(L" %d%s%d%s%d%s%d", nChapterStart,
			g_app.m_stuChapterVerseSepr.Chars(), nVerseStart, g_app.m_stuBridge.Chars(),
			nChapterEnd, g_app.m_stuChapterVerseSepr.Chars(), nVerseEnd);
	}
	else if (nVerseStart != nVerseEnd)
	{
		stuReference.FormatAppend(L" %d%s%d%s%d", nChapterStart,
			g_app.m_stuChapterVerseSepr.Chars(), nVerseStart, g_app.m_stuBridge.Chars(),
			nVerseEnd);
	}
	else if (nVerseStart != 0)
	{
		stuReference.FormatAppend(L" %d%s%d", nChapterStart,
			g_app.m_stuChapterVerseSepr.Chars(), nVerseStart);
	}
}

/*----------------------------------------------------------------------------------------------
	Set the text in a Draft window's caption bar based on the selection.
----------------------------------------------------------------------------------------------*/
void SetDraftCaptionBarForSelection(IVwSelection * pvwsel, CustViewDa * pcvd,
	AfCaptionBar * pcpbr)
{
	bool fGotIt = false;
	StrUni stuEditRef; // Title/reference/etc of text being edited in the draft pane
	//ENHANCE RonM: This should come from a Tools/Options setting
	int ws = pcvd->GetLpInfo()->VernWs();

	if (pvwsel)
	{
		HVO hvoSel, hvoT;
		int nBbCccVvvStart, nBbCccVvvEnd;
		StrUni stuBookName, stuReference;
		for (int ilev = 0; !fGotIt; ilev++)
		{
			PropTag tag;
			int ihvo, cpropPrev;
			IVwPropertyStorePtr qvps;
			if (FAILED(pvwsel->PropInfo(false, ilev, &hvoSel, &tag, &ihvo, &cpropPrev, &qvps)))
				break;

			switch (tag)
			{
			case kflidScrSection_Heading:
			case kflidScrSection_Content:
				{
					fGotIt = true;
					CheckHr(pcvd->get_ObjectProp(hvoSel, kflidCmObject_Owner, &hvoT));
					// ENHANCE RonM: What happens if there is no name in the desired writing system,
					// should we default to English or get anything we can or punt?
					ITsStringPtr qtssBookName;
					CheckHr(pcvd->get_MultiStringAlt(hvoT, kflidScrBook_Name, ws,
						&qtssBookName));

					CheckHr(pcvd->get_IntProp(hvoSel, kflidScrSection_VerseRefStart,
						&nBbCccVvvStart));
					CheckHr(pcvd->get_IntProp(hvoSel, kflidScrSection_VerseRefEnd,
						&nBbCccVvvEnd));
					MakeReferenceString(qtssBookName, nBbCccVvvStart, nBbCccVvvEnd, stuEditRef);
					break;
				}
			case kflidScrBook_Title:
				{
					fGotIt = true;
					ITsStringPtr qtssBookName;
					CheckHr(pcvd->get_MultiStringAlt(hvoSel, kflidScrBook_Name, ws,
						&qtssBookName));
					const OLECHAR * pchBookName;
					int cch;
					CheckHr(qtssBookName->LockText(&pchBookName, &cch));
					stuEditRef.Assign(const_cast<OLECHAR *>(pchBookName), cch);
					CheckHr(qtssBookName->UnlockText(pchBookName));
				}
				break;
			default:
				break;
			}
		}
	}
	StrApp strCaption;
	if (fGotIt && stuEditRef.Length())
	{
		strCaption.Load(kstidDraftCaptWithRef);
#ifdef UNICODE
		// REVIEW RonM(TomB): Never tested.
		strCaption.Append(stuEditRef);
#else
		// Copied & adapted from AfVwRootSite::SetKeyboardForSelection (we're not proud of this,
		// but since it didn't seem to be really solid code, we didn't want to nail it down).
		ILgWritingSystemFactoryPtr qwsf;
		pcvd->get_WritingSystemFactory(&qwsf);
//-		ILgWritingSystemFactoryPtr qwsf = pcvd->GetLpInfo()->GetDbInfo()->GetWritingSystemFactory();
		ILgWritingSystemPtr qws;
		CheckHr(qwsf->get_EngineOrNull(ws, &qws));
		if (!qws)
		{
			// punt
			strCaption.Load(kstidDraftViewCaption);
		}
		else
		{
			int nLangId;
			int nLocale;
			// REVIEW SteveMc, SharonC, KenZ, JohnT: nail down where the locale/langid belongs,
			// in the writing system or in the old writing system.
			CheckHr(qws->get_Locale(&nLocale));
			nLangId = LANGIDFROMLCID(nLocale);
			if (!nLangId)
			{
				// punt
				strCaption.Load(kstidDraftViewCaption);
			}
			else
			{
				StrApp strRef;
				StrApp::AssignViaCodePage(stuEditRef, strRef, GetCodePageForLangId(nLangId));
				strCaption.Append(strRef);
			}
		}
#endif		
	}
	else
	{
		strCaption.Load(kstidDraftViewCaption);
	}
	pcpbr->SetCaptionText(strCaption.Chars());
}
