/*----------------------------------------------------------------------------------------------
Copyright 2000-2002, SIL International. All rights reserved.

File: TeUtils.h
Responsibility: Ron McGarvey
Last reviewed: never

Description:
	This file contains andy little utility functions for Translation Editor.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef TEUTILS_INCLUDED
#define TEUTILS_INCLUDED 1

void GetBCV(int nVerseRef, int &nBook, int &nChap, int &nVerse);
void MakeReferenceString(ITsStringPtr qtssBookName, int nBbCccVvvStart, int nBbCccVvvEnd, 
	StrUni &stuReference);
void SetDraftCaptionBarForSelection(IVwSelection * pvwsel, CustViewDa * pcvd,
	AfCaptionBar * pcpbr);

#endif // TEUTILS_INCLUDED