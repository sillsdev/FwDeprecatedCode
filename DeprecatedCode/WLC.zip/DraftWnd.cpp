/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: DraftWnd.cpp
Responsibility: John Thomson
Last reviewed: Not yet.

Description:
	A simple concordance
-------------------------------------------------------------------------------*//*:End Ignore*/

//:>********************************************************************************************
//:>	   Include files
//:>********************************************************************************************
#include "main.h"
#pragma hdrstop
// any other headers (not precompiled)

/***********************************************************************************************
	SeDraftClientWnd stuff.
***********************************************************************************************/

static DummyFactory g_fact(_T("SIL.SE.DraftTextVc"));

/*----------------------------------------------------------------------------------------------
	Release all COM pointers, to break cycles.
----------------------------------------------------------------------------------------------*/
void SeDraftClientWnd::OnReleasePtr()
{
	m_qcvd.Clear();
	m_qsty.Clear();
	SuperClass::OnReleasePtr();
}

/*----------------------------------------------------------------------------------------------
	Create a draft window to hold the view.
----------------------------------------------------------------------------------------------*/
void SeDraftClientWnd::CreateChild(AfSplitChild * psplcCopy, AfSplitChild ** psplcNew)
{
	WndCreateStruct wcs;

	wcs.InitChild(_T("AfVwWnd"), SplitterHwnd(), 0);
	wcs.style |=  WS_VISIBLE;
	SeDraftWndPtr qsdw;

 	qsdw.Attach(NewObj SeDraftWnd);
	qsdw->m_pdcwParent = this;
	// Before CreateHwnd! Must be in the slot.
	*psplcNew = qsdw;
	SeDraftWnd * psdwFirst = dynamic_cast<SeDraftWnd *>(psplcCopy);
	if (psdwFirst)
		psdwFirst->CopyRootTo(qsdw);
	qsdw->CreateHwnd(wcs);

	AddRefObj(*psplcNew);

	// Get the name of the view to be used for the caption bar text.
	StrApp str(kstidDraftViewCaption);
	SetViewName(str);
}

#ifdef NEED_CREATE_METHOD
/*----------------------------------------------------------------------------------------------
	Create the main Scripture Drafting client window.
----------------------------------------------------------------------------------------------*/
void SeDraftClientWnd::Create()
{
	static bool s_fIsRegistered = false;
	if (!s_fIsRegistered)
	{
		s_fIsRegistered = true;
		AfWnd::RegisterClass("SeDraftClientWnd", 0, (int)IDC_ARROW, 0, COLOR_3DFACE);
	}

	WndCreateStruct wcs;
	wcs.style = WS_THICKFRAME | WS_SYSMENU | WS_CLIPCHILDREN | WS_CAPTION | WS_POPUP;
	wcs.dwExStyle = WS_EX_TOOLWINDOW | WS_EX_CONTEXTHELP;
	wcs.lpszClass = "SeDraftClientWnd";
	wcs.hwndParent = hwndPar; // consider this an independent window

	CreateHwnd(wcs);
}
#endif

/*----------------------------------------------------------------------------------------------
	Refresh the Draft window.
----------------------------------------------------------------------------------------------*/
void SeDraftClientWnd::RefreshDisplay()
{
	SeDraftWnd * ptdw = dynamic_cast<SeDraftWnd *>(this->GetPane(0));
	ptdw->RefreshDisplay();
}

/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
DraftTextVc::DraftTextVc() :
	m_qstbr(NULL)
{
	m_qstvc.Attach(NewObj StVc());
}  

/*----------------------------------------------------------------------------------------------
	This is the main interesting method of displaying objects and fragments of them.
	A Scripture is displayed by displaying its Books;
	and a Book is displayed by displaying its Title and Sections;
	and a Section is diplayed by displaying its Heading and Content;
	which are displayed by using the standard view constructor for StText.	
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DraftTextVc::Display(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pvwenv);

	switch(frag)
	{
	case kfrScripture:
		{
			CheckHr(pvwenv->AddLazyVecItems(kflidScripture_ScriptureBooks, this, kfrBook));
		}
		break;
	case kfrBook:
		{
			CheckHr(pvwenv->AddObjProp(kflidScrBook_Title, m_qstvc, kfrText));
			CheckHr(pvwenv->AddLazyVecItems(kflidScrBook_Sections, this, kfrSection));
		}
		break;
	case kfrSection:
		{
			CheckHr(pvwenv->AddObjProp(kflidScrSection_Heading, m_qstvc, kfrText));
			CheckHr(pvwenv->AddObjProp(kflidScrSection_Content, m_qstvc, kfrText));
		}
		break;
	default:
		Assert(false);
		break;
	}
	END_COM_METHOD(g_fact, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	This routine is used to estimate the height of an item. The item will be one of
	those you have added to the environment using AddLazyItems. Note that the calling code
	does NOT ensure that data for displaying the item in question has been loaded.
	The first three arguments are as for Display, that is, you are being asked to estimate
	how much vertical space is needed to display this item in the available width.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DraftTextVc::EstimateHeight(HVO hvo, int frag, int dxAvailWidth, int * pdyHeight)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pdyHeight);

	switch(frag)
	{
	case kfrBook:
		*pdyHeight = 2000;
		break;
	case kfrSection:
		*pdyHeight = 2000;
		break;
	default:
		Assert(false);
		break;
	}
	END_COM_METHOD(g_fact, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	Load data needed to display the specified objects using the specified fragment.
	This is called before attempting to Display an item that has been listed for lazy display
	using AddLazyItems. It may be used to load the necessary data into the DataAccess object.
	Since we pre-load all the data, it trivially succeeds (i.e., without doing anything).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DraftTextVc::LoadDataFor(IVwEnv * pvwenv, HVO * prghvo, int chvo, HVO hvoParent,
	int tag, int frag, int ihvoMin)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pvwenv);
	ChkComArrayArg(prghvo, chvo);

	// ENHANCE TomB: Implement progress bar
	bool fStartProgressBar = false; // m_qstbr && !m_qstbr->IsProgressBarActive();
	int ihvo;

	switch(frag)
	{
	case kfrBook:
		{
			HvoVec vhvoNeedLoad; // vector of objects we need to load data about.
			for (HVO * phvo = prghvo; phvo < prghvo + chvo; phvo++)
			{
				HVO hvoTitle;
				m_qcda->get_ObjectProp(*phvo, kflidScrBook_Title, &hvoTitle);
				if (!hvoTitle)
					vhvoNeedLoad.Push(*phvo);
			}
			// If none of the immediately wanted objects need loading we are done.
			if (vhvoNeedLoad.Size() == 0)
				return S_OK;

			// ENHANCE TomB: If/when CustViewDa::LoadData is modified to be able to load
			// exactly 1 level of an owned sequence or collection property, we can use it
			// instead of having this custom bit of SQL code
			// Load the Book sections
			// REVIEW JohnT(TomB): Is there a better way to do this?
			IDbColSpecPtr qdcs;
			qdcs.CreateInstance(CLSID_DbColSpec);
			// Set up column specs for loading book titles
			qdcs->Clear();
			// ENHANCE JohnT(TomB): I think we should have another koct value for atomic
			// properties so that the owner can be set automatically in the Load method
			// without having to pass a duplicate column.
			qdcs->Push(koctObj, 0, kflidScrBook_Title, 0);
			qdcs->Push(koctMltAlt, 0, kflidScrBook_Name, m_qcda->GetLpInfo()->VernWs());
			qdcs->Push(koctMltAlt, 0, kflidScrBook_Abbrev, m_qcda->GetLpInfo()->VernWs());
			qdcs->Push(koctObj, 1, kflidCmObject_Owner, 0);
//			qdcs->Push(koctObjVec, 1, kflidStText_Paragraphs, 0);
//			qdcs->Push(koctObj, 3, kflidCmObject_Owner, 0);
//			qdcs->Push(koctString, 3, kflidStTxtPara_Contents, 0);
//			qdcs->Push(koctFmt, 3, kflidStTxtPara_Contents, 0);
			StrUni stuQuery;
			stuQuery.Format(L"select Owner$, [id], Owner$, OwnFlid$ from ScrSection_ "
				L"(readuncommitted) where OwnFlid$ = %d and Owner$ in (%d",
				kflidScrBook_Sections, vhvoNeedLoad[0]);
			HvoClsidVec vhcNeedLoad;
			HvoClsid hc;
			hc.clsid = kclidStText;
			for (ihvo = 0; ihvo < vhvoNeedLoad.Size(); ihvo++)
			{
				StrUni stuQ2;
				stuQ2.Format(L"Select t.dst, n.[Txt], a.[Txt], t.src from ScrBook_Title t "
					L"(readuncommitted) left outer join ScrBook_Name n (readuncommitted) on "
					L"n.[Obj] = t.[Src] and n.[Ws] = %d left outer join ScrBook_Abbrev a "
					L"(readuncommitted) on a.[Obj] = t.[Src] and a.[Ws] = %d where t.[src] = "
					L"%d", m_qcda->GetLpInfo()->VernWs(), m_qcda->GetLpInfo()->VernWs(),
					vhvoNeedLoad[ihvo]);
				// ENHANCE TomB: Add pointer to status bar.
				m_qcda->Load(stuQ2.Bstr(), qdcs, vhvoNeedLoad[ihvo], 0, NULL /*m_qstbr*/,
					false);
				HVO hvoTitleText;
				m_qcda->get_ObjectProp(vhvoNeedLoad[ihvo], kflidScrBook_Title, &hvoTitleText);
				Assert(hvoTitleText);

				hc.hvo = hvoTitleText;
				vhcNeedLoad.Push(hc);

				// If we have access to a status bar but nothing is in progress, start up a
				// progress indicator, using arbitrary range just so something is seen to happen.
				if (fStartProgressBar)
				{
					StrApp strMsg(kstidStBar_LoadingData);
					m_qstbr->StartProgressBar(strMsg.Chars(), 0, 1000, 50);
				}
				// Load the paragraph(s) of the Title Text recursively.
				m_qcda->LoadData(vhcNeedLoad, m_quvs, NULL, true);

				if (ihvo > 0)
					stuQuery.FormatAppend(L",%d", vhvoNeedLoad[ihvo]);
			}
			stuQuery.Append(L") order by Owner$, [OwnOrd$]");

			// Set up column specs for loading sections of book(s)
			qdcs->Clear();
			qdcs->Push(koctBaseId, 0, kflidScripture_ScriptureBooks, 0);
			qdcs->Push(koctObjVec, 1, kflidScrBook_Sections, 0);
			// ENHANCE JohnT(TomB): I think we should have another koct value for atomic
			// properties so that the owner can be set automatically in the Load method
			// without having to pass a duplicate column.
			qdcs->Push(koctObj, 2, kflidCmObject_Owner, 0);
			qdcs->Push(koctInt, 2, kflidCmObject_OwnFlid, 0);

			// ENHANCE TomB: Add pointer to status bar.
			m_qcda->Load(stuQuery.Bstr(), qdcs, 0, 0, NULL /*m_qstbr*/, false);

			// Load Book Titles recursively
			m_qcda->LoadData(vhcNeedLoad, m_quvs, NULL, true);
		}
		break;
	case kfrSection:
		{
			HvoClsidVec vhcNeedLoad;
			HvoClsid hc;
			hc.clsid = kclidScrSection;
			HVO hvoContent;
			for (HVO * phvo = prghvo; phvo < prghvo + chvo; phvo++)
			{
				m_qcda->get_ObjectProp(*phvo, kflidScrSection_Content, &hvoContent);
				if (!hvoContent)
				{
					hc.hvo = *phvo;
					vhcNeedLoad.Push(hc);
				}
			}
			// If none of the immediately wanted objects need loading we are done.
			if (vhcNeedLoad.Size() == 0)
				return S_OK;

			// If we have access to a status bar but nothing is in progress, start up a
			// progress indicator, using arbitrary range just so something is seen to happen.
			if (fStartProgressBar)
			{
				StrApp strMsg(kstidStBar_LoadingData);
				m_qstbr->StartProgressBar(strMsg.Chars(), 0, 1000, 50);
			}

			// For sections, broaden the list a bit. This is to reduce the number of load calls.
			// We arbitrarily load up to three sections before and after the ones we know we want.
			int ihvoMinLoad = max(0, ihvoMin - 3);
			int chvoProp;
			CheckHr(m_qcda->get_VecSize(hvoParent, tag, &chvoProp));
			int ihvoMaxLoad = min(chvoProp, ihvoMin + chvo + 3);
			for (ihvo = ihvoMinLoad; ihvo < ihvoMaxLoad; ihvo++)
			{
				if (ihvo == ihvoMin)
				{
					// skip the ones we already got from prghvo
					ihvo += chvo - 1;
					continue;
				}
				HVO hvoItem;
				CheckHr(m_qcda->get_VecItem(hvoParent, tag, ihvo, &hvoItem));
				m_qcda->get_ObjectProp(hvoItem, kflidScrSection_Content, &hvoContent);
				if (!hvoContent)
				{
					hc.hvo = hvoItem;
					vhcNeedLoad.Push(hc);
				}
			}

			m_qcda->LoadData(vhcNeedLoad, m_quvs, NULL, true);
		}
		break;
	default:
		Assert(false);
		break;
	}

	// If we had to start a progress bar, return things to normal.
	if (fStartProgressBar)
	{
		m_qstbr->EndProgressBar();
	}

	END_COM_METHOD(g_fact, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	Initialize the Scripture Drafting window.
----------------------------------------------------------------------------------------------*/
void SeDraftWnd::PostAttach(void)
{
	SuperClass::PostAttach();
	
	SeMainWnd * ptmwMainWnd = dynamic_cast<SeMainWnd *>(MainWindow());
	Assert(ptmwMainWnd);
	m_qcvd = ptmwMainWnd->GetCustViewDa();
	m_hvoScripture = ptmwMainWnd->GetSeLpInfo()->GetHvoScripture();
	m_qsty = ptmwMainWnd->GetStyleSheet();	
}

/*----------------------------------------------------------------------------------------------
	Make the root box.

	@param pvg (Not used here)
	@param pprootb Out The RootBox to be returned.
----------------------------------------------------------------------------------------------*/
void SeDraftWnd::MakeRoot(IVwGraphics * pvg, ILgWritingSystemFactory * pwsf, IVwRootBox ** pprootb)
{
	AssertPtrN(pwsf);
	*pprootb = NULL;

	// Make sure we are attached. If not, don't make the root box. PostAttach tries again.
	SeMainWnd * ptmw = dynamic_cast<SeMainWnd *>(m_pdcwParent->MainWindow());
	if (!ptmw)
		return;

	AfLpInfo * plpi = dynamic_cast<AfLpInfo *>(ptmw->GetLpInfo());
	AssertPtr(plpi);

	// Check the database connection.
	IOleDbEncapPtr qode;
	plpi->GetDbInfo()->GetDbAccess(&qode);
	if (!qode)
		// Review JohnT: should we return E_FAIL or S_FALSE?
		return;	 // No current session, can't make root box.

	IVwRootBoxPtr qrootb;
	qrootb.CreateInstance(CLSID_VwRootBox);
	CheckHr(qrootb->SetSite(this));
	qrootb->put_DefaultTextType(kttpPublishedText);

	// Set hvo to the ID of the dummy vector that stores the root objects that have been
	// filtered and sorted.
	int wid = m_pdcwParent->GetWindowId();
	AfMdiClientWnd * pmdic = dynamic_cast<AfMdiClientWnd *>(m_pdcwParent->Parent());
	AssertPtr(pmdic);
	int iview;
	iview = pmdic->GetChildIndexFromWid(wid);
	UserViewSpecVec & vuvs = plpi->GetDbInfo()->GetUserViewSpecs();
	ClsLevel clevKey(kclidScripture, 0);
	vuvs[iview]->m_hmclevrsp.Retrieve(clevKey, m_qrsp);

	// Set up a new view constructor.
	m_qdvc.Attach(NewObj DraftTextVc());

	AfStatusBarPtr qstbr = ptmw->GetStatusBarWnd();
	Assert(qstbr);
	qstbr->StepProgressBar();

	m_qdvc->SetDa(m_qcvd, qstbr, vuvs[iview]);

	if (pwsf)
		CheckHr(m_qcvd->putref_WritingSystemFactory(pwsf));
	CheckHr(qrootb->putref_DataAccess(m_qcvd));
	CheckHr(qrootb->SetRootObject(m_hvoScripture, m_qdvc, kfrScripture, m_qsty));

	// Added this to keep from Asserting if the user tries to scroll the draft window
	// before clicking into it to place the insertion point.
	HRESULT hr = qrootb->MakeSimpleSel(true, true, false, true, NULL);

	// We ignore E_FAIL since the text window may be empty, in which case making a
	// selection is impossible.
	if (hr != E_FAIL)
		CheckHr(hr);

	ptmw->RegisterRootBox(qrootb);
	*pprootb = qrootb.Detach();
}

/*----------------------------------------------------------------------------------------------
	Refresh the Draft window by regenerating the root.
----------------------------------------------------------------------------------------------*/
void SeDraftWnd::RefreshDisplay()
{
	m_qrootb->Reconstruct();
	// Added this to keep from Asserting if the user tries to scroll the draft window
	// before clicking into it to place the insertion point.
	HRESULT hr = m_qrootb->MakeSimpleSel(true, true, false, true, NULL);
	// We ignore E_FAIL since the text window may be empty, in which case making a
	// selection is impossible.
	if (hr != E_FAIL)
		CheckHr(hr);
}

/*----------------------------------------------------------------------------------------------
	Change the reference in the title bar when the selection changes in the draft pane. 
----------------------------------------------------------------------------------------------*/
void SeDraftWnd::HandleSelectionChange(IVwSelection * pvwselNew)
{
	SuperClass::HandleSelectionChange(pvwselNew);
	AfMdiClientWnd * pmdic = dynamic_cast<AfMdiClientWnd *>(m_pdcwParent->Parent());
	if (pmdic)
		SetDraftCaptionBarForSelection(pvwselNew, m_qcvd, pmdic->GetCaptionBar());
}

/*----------------------------------------------------------------------------------------------
	Release smart pointers.
----------------------------------------------------------------------------------------------*/
void SeDraftWnd::OnReleasePtr()
{
	m_qcvd.Clear();
	m_qsty.Clear();
	m_qdvc.Clear();
	m_qrsp.Clear();
	SuperClass::OnReleasePtr();
}

/*----------------------------------------------------------------------------------------------
	Disable direct formatting toolbar buttons except styles & old writing systems comboboxes.
----------------------------------------------------------------------------------------------*/
bool SeDraftWnd::CmsCharFmt(CmdState & cms)
{
	// Disable all direct formatting toolbar buttons.
	// Keep styles & old writing systems comboboxes enabled.
	if (cms.Cid() == kcidFmttbStyle || cms.Cid() == kcidFmttbWrtgSys)
	{
		return SuperClass::CmsCharFmt(cms);
	}
	else
	{
		cms.Enable(false);
		return true;
	}
}

/*----------------------------------------------------------------------------------------------
	Open TE specific Styles Dialog. 
----------------------------------------------------------------------------------------------*/
bool SeDraftWnd::OpenFormatStylesDialog(HWND hwnd, bool fCanDoRtl, bool fOuterRtl,
	IVwStylesheet * past, TtpVec & vqttpPara, TtpVec & vqttpChar, bool fCanFormatChar,
	StrUni * pstuStyleName, bool & fStylesChanged, bool & fApply, bool & fReloadDb)
{
	TeStylesDlg tesd;
	return tesd.AdjustTsTextProps(hwnd, fCanDoRtl, fOuterRtl, false, past,
		vqttpPara, vqttpChar, fCanFormatChar, pstuStyleName,
		fStylesChanged, fApply, fReloadDb);
}

