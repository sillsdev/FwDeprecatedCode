/*----------------------------------------------------------------------------------------------
Copyright 2000-2002, SIL International. All rights reserved.

File: WLC.cpp
Responsibility: Bryan Wussow
Last reviewed: never

Description:
	This file contains the base classes for Scripture Editor.
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop

#include "Vector_i.cpp"

#undef THIS_FILE
DEFINE_THIS_FILE

// Create one global instance. It has to exist before WinMain is called.
SeApp g_app;
extern const char * kpszWndPositionValue;

BEGIN_CMD_MAP(SeApp)
	ON_CID_ALL(kcidFileImpt, &SeApp::CmdFileImport, NULL)
	ON_CID_ALL(kcidFileExit, &SeApp::CmdFileExit, NULL)
	ON_CID_ALL(kcidHelpAbout, &SeApp::CmdHelpAbout, NULL)
	ON_CID_ALL(kcidWndCascad, &SeApp::CmdWndCascade, NULL)
	ON_CID_ALL(kcidWndTile, &SeApp::CmdWndTileHoriz, NULL)
	ON_CID_ALL(kcidWndSideBy, &SeApp::CmdWndTileVert, NULL)
END_CMD_MAP_NIL()

BEGIN_CMD_MAP(SeMainWnd)
	ON_CID_ME(kcidHelpWhatsThis, &SeMainWnd::CmdHelpMode, NULL)
	ON_CID_ALL(kcidEditUndo, &SeMainWnd::CmdEditUndo, &SeMainWnd::CmsEditUndo)
	ON_CID_ALL(kcidEditRedo, &SeMainWnd::CmdEditRedo, &SeMainWnd::CmsEditRedo)
	ON_CID_ME(kcidWndNew, &RecMainWnd::CmdWndNew, NULL)
	ON_CID_ALL(kcidFmtStyles, &SeMainWnd::CmdFmtStyles, NULL) // &AfVwSplitChild::CmsFmtStyles)
END_CMD_MAP_NIL()


/***********************************************************************************************
	SeApp methods.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
SeApp::SeApp()
{
	s_fws.SetRoot(_T("Scripture Editor")); //"Software\\SIL\\FieldWorks\\Scripture Editor";

	// Initialize separating characters for Scripture references - will need to be Localized.
	m_stuBookSepr = L";";
	m_stuChapterSepr = L";";
	m_stuVerseSepr = L",";
	m_stuChapterVerseSepr = L":";
	m_stuBridge = L"-";
}


/*----------------------------------------------------------------------------------------------
	Initialize the application.
----------------------------------------------------------------------------------------------*/
void SeApp::Init(void)
{
	// Call init before any other database activity.
	SuperClass::Init();

	AfWnd::RegisterClass(_T("SeMainWnd"), 0, 0, 0, COLOR_3DFACE, (int)kridSEIcon);
	AfWnd::RegisterClass(_T("ConcWnd"), kfwcsHorzRedraw | kfwcsVertRedraw, (int)IDC_ARROW, 0,
		COLOR_WINDOW);

	StrUni stuProjTableName(L"LanguageProject");
	HashMapStrUni<StrUni> hmsustuOptions;
	HVO hvoLpId;
	HVO hvoScripture;
	bool fContinueLoop = true;
	bool fUseOptions = true;

	while (fContinueLoop)
	{
		OptionsReturnValue orv = ProcessDBOptions(kclidScripture, NULL,
			kclidLanguageProject, &stuProjTableName,
			&hmsustuOptions, hvoLpId, hvoScripture,
			fUseOptions);
		switch (ProcessOptRetVal(orv, &hmsustuOptions))
		{
		case IDOK:
			fContinueLoop = false;
			break;
		case IDRETRY:
			// fUseOptions = false;
			break;
		case IDCANCEL:	// Fall through.
		default:
			AfApp::Papp()->Quit(true);
			return;
		}
	}
	Assert(hvoLpId);
	// Fish the server and database names from the map.
	StrUni stuKey;
	StrUni stuServer;
	StrUni stuDatabase;
	stuKey = L"server";
	hmsustuOptions.Retrieve(stuKey, &stuServer);
	stuKey = L"database";
	hmsustuOptions.Retrieve(stuKey, &stuDatabase);

	// REVIEW DarrellZ: What should we do if this throws an exception (in AfDbInfo::Init)?
	AfDbApp * pdapp = dynamic_cast<AfDbApp *>(AfApp::Papp());
	Assert(pdapp);
	if (!pdapp->CheckDbVerCompatibility(stuServer.Chars(), stuDatabase.Chars()))
	{
		m_qsplSplashWnd->RequestShutDown();
		AfApp::Papp()->Quit(true);
		return;
	}

	// Open initial window
	WndCreateStruct wcs;
	wcs.InitMain(_T("SeMainWnd"));
	SeMainWndPtr qwnd;
    qwnd.Attach(NewObj SeMainWnd);
	AfDbInfo * pdbi = GetDbInfo(stuDatabase.Chars(), stuServer.Chars());
	SeLpInfo * ptlpi = dynamic_cast<SeLpInfo *>(pdbi->GetLpInfo(hvoLpId));
	AssertPtr(ptlpi);
	ptlpi->InitScriptureItems(hvoScripture);
	qwnd->Init(ptlpi);
	// qwnd.Create(); ?? Does this do anything we need? Should it be after CreateHwnd
    // or instead?
	qwnd->CreateHwnd(wcs);
	qwnd->Show(m_nShow);

	// REVIEW ?? (PaulP): This is a kludge to commit changes made to the various "settings"
	// tables during application startup.  Doing this allows other applications to read those
	// tables and not block.  Generally speaking, one should NOT call the CommitTrans on the
	// OleDbEncap object directly but rather the Commit method on the ActionHandler object
	// should be called.
	// Commented these three lines out at JohnT's recommendation because it causes
	// an error when the CommitTrans method is called.
	//IOleDbEncapPtr qode;
	//pdbi->GetDbAccess(&qode);
	//qode->CommitTrans();

	// Main window is now visible; thus we're now done with splash screen
	m_qsplSplashWnd->RequestShutDown();
}

/*----------------------------------------------------------------------------------------------
	Check the return value from ProcessDBOptions. If no Scripture is present in DB, prompt to
	create one.

	@param orv The value returned by ProcessDBOptions.
	@param phmsustuOptions Pointer to a map that has part of the results of
		calling ProcessDBOptions.

	@return IDOK if orv is korvSuccess, IDCANCEL if user wants to quit,
		IDRETRY if user wants to try again to start app using the default startup values.
----------------------------------------------------------------------------------------------*/
int SeApp::ProcessOptRetVal(OptionsReturnValue orv,
							  HashMapStrUni<StrUni> * phmsustuOptions)
{
	Assert(phmsustuOptions);
	Assert((orv >= korvSuccess) && (orv < korvLim));

	//if (orv == korvInvalidObject)
	//{
	//	StrUni stuKey = L"project";
	//	StrUni stuProj;
	//	phmsustuOptions->Retrieve(stuKey, &stuProj);
	//	StrApp strProj(stuProj);

	//	StrApp strMsg;
	//	strMsg.Format(_T("Project \'%s\' does not contain a Scripture translation. An empty one")
	//		_T(" will now be created for you."), strProj.Chars());
	//	StrApp strAppTitle(kstidAppName);
	//	return ::MessageBox(NULL, strMsg.Chars(), strAppTitle.Chars(),
	//						MB_OKCANCEL | MB_ICONEXCLAMATION);
	//}
	return SuperClass::ProcessOptRetVal(orv, phmsustuOptions);
}

/*----------------------------------------------------------------------------------------------
	Return the matching AfDbInfo. If it is not already loaded, create it now.

    @param pszDbName Db name
    @param pszSvrName Server name

    @return pointer to Db Info object
----------------------------------------------------------------------------------------------*/
AfDbInfo * SeApp::GetDbInfo(const OLECHAR * pszDbName, const OLECHAR * pszSvrName)
{
	SetSplashLoadingMessage(pszDbName);

	int cdbi = m_vdbi.Size();
	for (int idbi = 0; idbi < cdbi; idbi++)
	{
		if (wcscmp(pszDbName, m_vdbi[idbi]->DbName()) == 0 &&
			wcscmp(pszSvrName, m_vdbi[idbi]->ServerName()) == 0)
		{
			return m_vdbi[idbi];
		}
	}

	// We didn't find it in the cache, so load it now.
	SeDbInfoPtr qdbi;
	qdbi.Create();
	qdbi->Init(pszSvrName, pszDbName, m_qfistLog);
	m_vdbi.Push(qdbi.Ptr());
	return qdbi;
}

/*----------------------------------------------------------------------------------------------
	Handle the File/Import command.
	TODO RonM: This needs to be revisited when JohnW gives us a spec for the File Import dialog.
----------------------------------------------------------------------------------------------*/
bool SeApp::CmdFileImport(Cmd * pcmd)
{
	SeMainWnd * pwmw = dynamic_cast<SeMainWnd *>(m_qafwCur.Ptr());
	AssertPtr(pwmw);

	// Get starting and ending books from user
	ScriptRefDlgPtr qsrd;
	qsrd.Create();
	qsrd->SetInitRef(L"Mat", L"Mat");
	if (qsrd->DoModal(pwmw->Hwnd()) != kctidOk)
	{
		return false;
	}

	// TODO RonM (TomB): At this point, strings are book names only. When the spec for this is
	// done, we'll probably need to handle chapter-level and maybe even verse-level imports.
	StrUni stuStartRef(qsrd->StartRefStr());
	StrUni stuEndRef(qsrd->EndRefStr());
	StrUni stuScriptureProj(L"TEV");
	pwmw->ImportScripture(stuScriptureProj, stuStartRef, stuEndRef);
	return true;
}

#ifdef DEBUG
// debug code: static vars for testing performance
static time_t startParseStTxtPara, finishParseStTxtPara,
			  startImportScripture, finishImportScripture,
			  startMakeWordforms, finishMakeWordforms,
			  startMakeTxtWfInContext, finishMakeTxtWfInContext;
static double elapsedParseStTxtPara, elapsedImportScripture,
			  elapsedMakeWordforms, elapsedMakeTxtWfInContext;
#endif


/***********************************************************************************************
	TeStylesheet methods.
***********************************************************************************************/

static DummyFactory g_fact(_T("SIL.WLC.TeStyleSheet"));

/*----------------------------------------------------------------------------------------------
	Return true if the given style is one that is protected within the TeStylesheet.
	This overrides the default implementation in AfStylesheet.

	@param bstrName style to be checked.
	@param pfProtected pointer to the flag to be set.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP TeStylesheet::get_IsStyleProtected(BSTR bstrName, ComBool * pfProtected)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(bstrName);
	ChkComOutPtr(pfProtected);

// TODO ToddJ: Use style GUID's and localizable name from resource when JohnT has a plan

	*pfProtected = false;
	StrUni stuStyleName;

	for (int i = 0; i < kiProtStyleNameLim; i++)
	{
		stuStyleName = GetProtStyleName((ProtectedStyleId)i);
		if (!wcscmp(bstrName, stuStyleName))
			*pfProtected = true;
	}

	END_COM_METHOD(g_fact, IID_IVwStylesheet);
}

/*----------------------------------------------------------------------------------------------
	Check over the scripture stylesheet.
----------------------------------------------------------------------------------------------*/
void TeStylesheet::CkReqdStyles()
{
		// If Normal style was not loaded from the db
		ITsTextPropsPtr qttp;
		StrUni stuStyleName(g_pszwStyleNormal);
		CheckHr(GetStyleRgch(stuStyleName.Length(),
			const_cast<OLECHAR *>(stuStyleName.Chars()), &qttp));
		if (!qttp)
		{
			// Create the Normal style with given (default) properties
			HVO hvoStyle;
			CheckHr(GetNewStyleHVO(&hvoStyle));
			ITsPropsBldrPtr qtpb;
			qtpb.CreateInstance(CLSID_TsPropsBldr);
			CheckHr(qtpb->GetTextProps(&qttp));

			// PutStyleRgch() adds the style to m_vhcStyles as well as the cache and db
			// "Normal" style is non-published, built-in and not (yet) modified by user
			CheckHr(PutStyleRgch(stuStyleName.Length(),
				const_cast<OLECHAR *>(stuStyleName.Chars()),
				hvoStyle, 0, hvoStyle, kstParagraph, false, true, false, qttp));
		}
}


/***********************************************************************************************
	SeChangeWatcher methods.
	The SeChangeWatcher class receives notifications of paragraph edits and implements the
	desired side effects of re-parsing the paragraph for wordforms.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Initialize the object.
	@param pcda  Ptr to CustViewDa that we will be registered to
	@param pwlpi  Ptr to Language Project Info
----------------------------------------------------------------------------------------------*/
void SeChangeWatcher::Init(ISilDataAccess * psda, SeLpInfo * pwlpi)
{
	//init the AfChangeWatcher to check for Paragraph changes
	SuperClass::Init(psda, kflidStTxtPara_Contents);

	// init member vars for DoEffectsOfPropChange()
	AssertPtr(pwlpi);
	m_pwlpi = pwlpi;
}

/*----------------------------------------------------------------------------------------------
	Do the side effects.
	We define this pure virtual function to do the effects we desire.
	DoEffectsOfPropChange() is called by AfChangeWatcher when a change is detected.
	@param hvo  the viewable object that was changed
	@param ivMin the starting character index where the change occurred.
	@param cvIns the number of characters inserted.
	@param cvDel the number of characters deleted.
----------------------------------------------------------------------------------------------*/
void SeChangeWatcher::DoEffectsOfPropChange(HVO hvoPara, int ivMin, int cvIns, int cvDel)
{
	// ENHANCE (BryanW): check that the owner of the paragraph is Scripture, if our CustViewDa
	// is ever used to modify non-scripture paragraphs

	m_pwlpi->ParseStTxtPara(hvoPara, ivMin, cvIns, cvDel);

//more to do here
}




/***********************************************************************************************
	SeMainWnd methods.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Initialize the class. ENHANCE JohnT: why doesn't the superclass method set m_qlpi??

	@param pdbi Ptr to DataBase Info
	@param plpi Ptr to Language Project Info
----------------------------------------------------------------------------------------------*/
void SeMainWnd::Init(AfLpInfo * plpi)
{
	AssertPtr(plpi);
	Assert(!m_qlpi); // Only call this once.
    SuperClass::Init(plpi);
	m_qlpi = dynamic_cast<SeLpInfo *>(plpi);
	if (!m_qlpi)
		ThrowHr(E_FAIL);

	PrepareSpellingStatusBitmaps();
}

/*----------------------------------------------------------------------------------------------
	Enter What's This help mode.

	@param pcmd menu command

	@return true
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::CmdHelpMode(Cmd * pcmd)
{
     ToggleHelpMode();
     return true;
}

/*----------------------------------------------------------------------------------------------
	The hwnd has been attached.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::PostAttach(void)
{
	AssertPtr(m_qlpi);

    StrAppBuf strbT; // Holds temp string

	// Set the default caption text.
	strbT.Load(kstidAppName);
	::SendMessage(m_hwnd, WM_SETTEXT, 0, (LPARAM)strbT.Chars());

	// This creates the main frame window and sets it as the current window. It also
	// creates the rebar and status bar.
	SuperClass::PostAttach();

	// Create and load the data source.
	if (!m_qcda)
	{
		SeLpInfo * pwlpi = GetSeLpInfo(); // was dynamic_cast<SeLpInfo *>(GetLpInfo());
		AssertPtr(pwlpi);
		pwlpi->GetDataAccess(&m_qcda);
	}
	LoadData();

	// Create the Change Watcher
	m_qsechgw.Attach(NewObj SeChangeWatcher);
	m_qsechgw->Init(m_qcda, GetSeLpInfo());

	// Create the toolbars.
	const int rgrid[] =
	{
		kridTBarStd,
		kridTBarFmtg,
//		kridTBarData,
//		kridTBarView,
//		kridTBarIns,
//		kridTBarTools,
		kridTBarWnd,
//		kridTBarInvisible,  //Leave this for menu icons (for icon storage only)
		kridTBarSpelling,
	};

	GetMenuMgr()->LoadToolBars(rgrid, SizeOfArray(rgrid));

	GetMenuMgr()->LoadAccelTable(kridAccelStd, 0, m_hwnd);

    // Create the menu bar.
    AfMenuBarPtr qmnbr;
	qmnbr.Create();
	strbT.Load(kstidMenu);
	qmnbr->Initialize(m_hwnd, kridAppMenu, kridAppMenu, strbT.Chars());
	m_vqtlbr.Push(qmnbr.Ptr());

	// Create the tool bars.
	AfToolBarPtr qtlbr;

	qtlbr.Create();
	strbT.Load(kstidTBarStd); //"Standard"
	qtlbr->Initialize(kridTBarStd, kridTBarStd, strbT.Chars());
	m_vqtlbr.Push(qtlbr);

	qtlbr.Create();
	strbT.Load(kstidTBarFmtg); //"Formatting"
	qtlbr->Initialize(kridTBarFmtg, kridTBarFmtg, strbT.Chars());
	m_vqtlbr.Push(qtlbr);

	qtlbr.Create(); //"Window"
	strbT.Load(kstidTBarWnd);
	qtlbr->Initialize(kridTBarWnd, kridTBarWnd, strbT.Chars());
	m_vqtlbr.Push(qtlbr);


	// Insert the list of views into the viewbar.
	strbT.Load(kstidViews);
	AfListBarPtr qlb;
	qlb.Create();
	m_qvwbrs->AddList(strbT.Chars(), m_rghiml[0], m_rghiml[1], false, qlb);
	int cv = m_qmdic->GetChildCount();
	for (int iv = 0; iv < cv; iv++)
	{
		AfClientWnd * pafcw = m_qmdic->GetChildFromIndex(iv);
		AssertPtr(pafcw);
		m_qvwbrs->AddListItem(kiViewsList, pafcw->GetViewName(), pafcw->GetImageIndex());
	}

	// Load window settings.
	LoadSettings(NULL, false);

	g_app.AddCmdHandler(this, 1);
	//set splash msg  finishing
	m_qstbr->RestoreStatusText();

	// Update the icons for the formatting toolbar drop-down buttons.
	UpdateToolBarIcon(kridTBarFmtg, kcidFmttbApplyBgrndColor, m_clrBack);
	UpdateToolBarIcon(kridTBarFmtg, kcidFmttbApplyFgrndColor, m_clrFore);
	UpdateToolBarIcon(kridTBarFmtg, kcidFmttbApplyBdr, (COLORREF) m_bpBorderPos);
}

/*----------------------------------------------------------------------------------------------
	Handle the undo command.

	@param pcmd menu command
	@return true if successful.
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::CmdEditUndo(Cmd * pcmd)
{
	IActionHandlerPtr qacth;
	CheckHr(m_qcda->GetActionHandler(&qacth));
	if (!qacth)
		return false;

	HRESULT hr;
	ComBool fCanUndo;
	hr = qacth->CanUndo(&fCanUndo);
	if (fCanUndo)
	{
		hr = qacth->Undo();
		if (FAILED(hr))
		{
			return false;
		}
#if 0 // code from Data Notebook version of this method. Do we need something similar here?
		// Reload the Id list.
		CustViewDaPtr qcvd;
		m_qlpi->GetDataAccess(&qcvd);
		HVO hvoRnId = dynamic_cast<RnLpInfo *>(m_qlpi.Ptr())->GetRnId();
		qcvd->SetTags(kflidRnResearchNotebook_Records, kflidRnGenericRecord_DateCreated);
		m_vhcRecords.Clear();
		qcvd->LoadMainItems(hvoRnId, m_vhcRecords);
		m_vhcFilteredRecords = m_vhcRecords;

		// Refresh the current window in case the undo deleted the current record.
		AfClientRecWndPtr qafcrw = dynamic_cast<AfClientRecWnd *>(m_qmdic->GetCurChild());
		AssertPtr(qafcrw);
		qafcrw->ReloadRootObjects();
#endif
	}
	return true;
}


/*----------------------------------------------------------------------------------------------
	Handle the redo command.

	@param pcmd menu command
	@return true if successful.
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::CmdEditRedo(Cmd * pcmd)
{
	IActionHandlerPtr qacth;
	CheckHr(m_qcda->GetActionHandler(&qacth));
	if (!qacth)
		return false;

	HRESULT hr;
	ComBool fCanRedo;
	hr = qacth->CanRedo(&fCanRedo);
	if (fCanRedo)
	{
		hr = qacth->Redo();
		if (FAILED(hr))
		{
			return false;
		}

		// REVIEW JohnT(TomB): What do we need to do here?
		// Refresh the current window in case the redo deleted the current record.
		//AfClientRecWndPtr qafcrw = dynamic_cast<AfClientRecWnd *>(m_qmdic->GetCurChild());
		//AssertPtr(qafcrw);
		//qafcrw->ReloadRootObjects();
	}
	return true;
}

/*----------------------------------------------------------------------------------------------
	Enable/disable the undo menu item.

	@param cms menu command state
	@return true if successful.
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::CmsEditUndo(CmdState & cms)
{
	// TODO: add the following lines to make the Undo item in the Menu be labeled
	// appropriately:
//	StrApp staLabel = UndoRedoText(false);
//	cms.SetText(staLabel, staLabel.Length());

	IActionHandlerPtr qacth;
	CheckHr(m_qcda->GetActionHandler(&qacth));

	ComBool fCanUndo = false;

	if (!qacth)
		return true;

	HRESULT hr;
	hr = qacth->CanUndo(&fCanUndo);
	cms.Enable(fCanUndo);
	if (FAILED(hr))
	{
		return false;
	}
	return true;
}

/*----------------------------------------------------------------------------------------------
	Enable/disable the redo menu item.

	@param cms menu command state
	@return true if successful.
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::CmsEditRedo(CmdState & cms)
{
	// TODO: add the following lines to make the Redo item in the Menu be labeled
	// appropriately:
//	StrApp staLabel = UndoRedoText(true);
//	cms.SetText(staLabel, staLabel.Length());

	IActionHandlerPtr qacth;
	CheckHr(m_qcda->GetActionHandler(&qacth));

	ComBool fCanRedo = false;
	if (!qacth)
		return true;
	HRESULT hr;
	hr = qacth->CanRedo(&fCanRedo);
	cms.Enable(fCanRedo);
	if (FAILED(hr))
	{
		return false;
	}
	return true;
}

/*----------------------------------------------------------------------------------------------
	Bring up the format styles dialog.
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::CmdFmtStyles(Cmd * pcmd)
{
	AssertObj(pcmd);

	TeStylesDlg tesd(true);
	StrUni stuStyleName;
	bool fStylesChanged;
	bool fApply;
	TtpVec vqttpPara;
	TtpVec vqttpChar;
	IVwStylesheetPtr qasts = GetStyleSheet();

	StrUni stuUndo, stuRedo;
	StrUtil::MakeUndoRedoLabels(kstidUndoStyleChanges, &stuUndo, &stuRedo);
	CheckHr(m_qcda->BeginUndoTask(stuUndo.Bstr(), stuRedo.Bstr()));

	bool fReloadDb;		// returned as true when style names have been changed, so data must be
						// reloaded; TODO (SharonC): respond appropriately
	tesd.AdjustTsTextProps(m_hwnd, false, false, false, qasts,
		vqttpPara, vqttpChar, false, &stuStyleName, fStylesChanged, fApply, fReloadDb);

	CheckHr(m_qcda->EndUndoTask());

	return true;
}

/*----------------------------------------------------------------------------------------------
	This handles events sent from any ConcClientWnd's children. At this point, the only event
	being handled is the user dragging the top border of the ConcTextHeaderWnd's caption bar.

	@param ceid The child's event ID.
	@param pChildWnd A pointer to the child window object.
	@param lpInfo Pointer to any extra information that might be necessary. In this case it
			is a pointer to a tagMSG structure.
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::OnChildEvent(int ceid, AfWnd *pChildWnd, void *lpInfo)
{
	bool fRet = SuperClass::OnChildEvent(ceid, pChildWnd, lpInfo);

	// Do nothing for messages we don't care about from a children we don't care about. :)
	if (ceid != kfcbcNotifyParentOnClick ||
		(AfCaptionBar *)pChildWnd != m_qmdic->GetCaptionBar())
		return fRet;

	// We're here because the user clicked on the concordance's caption bar. Therefore,
	// send the focus to the concordance window if the message is a left button click.
	if (((PMSG)lpInfo)->message == WM_LBUTTONDOWN)
	{
		::SetFocus(GetMdiClientWnd()->GetCurChild()->Hwnd());
	}

	return fRet;
}

/*----------------------------------------------------------------------------------------------
	Create the client windows and attach them to the MDI client.  Initialize the image lists.
	Create and attach our caption bar.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::InitMdiClient(void)
{
	// Initialize the image lists
	ClearViewBarImageLists();

	m_rghiml[0] = ::ImageList_Create(32, 32, ILC_COLORDDB | ILC_MASK, 0, 0);
	if (!m_rghiml[0])
		ThrowHr(WarnHr(E_FAIL));
	HBITMAP hbmp = ::LoadBitmap(ModuleEntry::GetModuleHandle(),
		MAKEINTRESOURCE(kridVBarLarge));
	if (!hbmp)
		ThrowHr(WarnHr(E_FAIL));
	::ImageList_AddMasked(m_rghiml[0], hbmp, kclrPink);
	::DeleteObject(hbmp);

	m_rghiml[1] = ::ImageList_Create(16, 16, ILC_COLORDDB | ILC_MASK, 0, 0);
	if (!m_rghiml[1])
		ThrowHr(WarnHr(E_FAIL));
	hbmp = ::LoadBitmap(ModuleEntry::GetModuleHandle(), MAKEINTRESOURCE(kridVBarSmall));
	if (!hbmp)
		ThrowHr(WarnHr(E_FAIL));
	::ImageList_AddMasked(m_rghiml[1], hbmp, kclrPink);
	::DeleteObject(hbmp);

	// Create and attach our caption bar.
	ConcCaptionBarPtr qcpbr;
	qcpbr.Attach(NewObj ConcCaptionBar);
	m_qmdic->SetCaptionBar(qcpbr, kfcbcNotifyParentOnClick);

	// Create the client child window.
	AfClientWndPtr qafcw;

	//setup "vuvs" which holds all user view specs
	UserViewSpecVec & vuvs = m_qlpi->GetDbInfo()->GetUserViewSpecs();

	if (vuvs.Size() == 0)
	{
		// Load user views from the database. If we fail, create new ones and save them so
		// we can keep going.
		if (!LoadUserViews())
		{
			// Create New Views
			UserViewSpecPtr quvs;

			quvs.Create();
			MakeNewView(kvwtConc, m_qlpi, quvs);
			quvs->Save(m_qlpi->GetDbInfo(), true);
			vuvs.Push(quvs);

			quvs.Create();
			MakeNewView(kvwtDraft, m_qlpi, quvs);
			quvs->Save(m_qlpi->GetDbInfo(), true);
			vuvs.Push(quvs);
		}

		// Save vuvs in app.
		m_qlpi->GetDbInfo()->SetUserViewSpecs(&vuvs);
	}

	StrApp str;
	const OLECHAR * pwrgch;
	int cch;
	int iuvs;

	int wid = kwidChildBase;
	for (iuvs = 0; iuvs < vuvs.Size(); ++iuvs, ++wid)
	{
		vuvs[iuvs]->m_qtssName->LockText(&pwrgch, &cch);
		str.Assign(pwrgch, cch);
		vuvs[iuvs]->m_qtssName->UnlockText(pwrgch);
		switch (vuvs[iuvs]->m_vwt)
		{
		default:
			// we should never get here.
			Assert(false);
			break;

		case kvwtConc:
			qafcw.Attach(NewObj ConcClientWnd);
			qafcw->Create(str.Chars(), kimagBrowse, wid);
			break;

		case kvwtDraft:
			qafcw.Attach(NewObj SeDraftClientWnd);
			qafcw->Create(str.Chars(), kimagDataEntry, wid);
			break;

#if 0 // TODO RonM (TomB): reinstate when we add a doc view.
		case kvwtDoc:
			qafcw.Attach(NewObj SeDocWnd);
			qafcw->Create(str.Chars(), kimagDocument, wid);
			break;
#endif
		}
		m_qmdic->AddChild(qafcw);
		vuvs[iuvs]->m_iwndClient = iuvs;
	}
	m_qmdic->SetClientIndexLim(wid);
}

/*----------------------------------------------------------------------------------------------
	The user has selected a different item in the view bar.
	For Views:  Clear the active rootbox.  Save the current changes (if any) to the database.
		Switch to the selected view.  Update the caption bar.
	For Filters, Sort order, or Overlays:
		Switch to the selected filter, sort order, or overlay, then update the caption bar.

	@param ilist viewbar vector index
	@param siselOld the viewbar index of what was selected earlier
	@param siselNew the viewbar index of what is now selected

	@return true
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::OnViewBarChange(int ilist, Set<int> & siselOld, Set<int> & siselNew)
{
	bool fStatusHidden = !::IsWindowVisible(m_qstbr->Hwnd());
	switch (ilist)
	{

	case kiViewsList: // Views
		{
			::SetFocus(NULL);

			// Clear out the active rootbox.
			SetActiveRootBox(NULL);

			Assert(siselNew.Size() == 1);
			int iview = *siselNew.Begin();
			WaitCursor wc;
			if (fStatusHidden)
			{
				::ShowWindow(m_qstbr->Hwnd(), SW_SHOW);
				::SendMessage(m_hwnd, WM_SIZE, kwstRestored, 0);
			}
			StrApp strMsg;
			UserViewSpecVec & vuvs = m_qlpi->GetDbInfo()->GetUserViewSpecs();
			Assert((uint)iview < (uint)vuvs.Size());

			// Review JohnT (Tom and Dave): Is this really what we want to do here?
			switch (vuvs[iview]->m_vwt)
			{
			case kvwtConc:
				strMsg.Load(kstidStBar_CreatingConcordanceView);
				break;
			case kvwtDraft:
				strMsg.Load(kstidStBar_CreatingDraftView);
				break;
			default:
				Assert(false);
				break;
			}
			m_vwt = vuvs[iview]->m_vwt;
			m_qstbr->StartProgressBar(strMsg.Chars(), 0, 1000, 50);

			// Save the current changes (if any) to the database.
			m_qcda->Save();
			m_qstbr->StepProgressBar();

			if (m_qmdic->SetCurChildFromIndex(iview))
			{
				// ENHANCE: We could do something to set our initial position here.
			}
			else
			{
				// Force the focus to go back to the current view window if this is the
				// current top-level window.
				if (AfApp::Papp()->GetCurMainWnd() == this)
					::SetFocus(m_hwnd);
			}

			// Update the caption bar.
			UpdateCaptionBar();

			m_qstbr->EndProgressBar();
			if (fStatusHidden)
			{
				::ShowWindow(m_qstbr->Hwnd(), SW_HIDE);
				::SendMessage(m_hwnd, WM_SIZE, kwstRestored, 0);
			}
		}

		UpdateStatusBar();
		break;

	default:
		Assert(false);
		break;
	}

	return true;
}


/*----------------------------------------------------------------------------------------------
	Make all client windows give up their connection to the database and close project saving
	settings to registry. If this is the final window open on the database, remove the DbInfo
	to release the database connection.
	@return false to close the window, true to abort.
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::OnClose()
{
	if (!IsOkToChange())
		return true; // Don't close the window if there are problems.

	// Save the current changes (if any) to the database.
	m_qcda->Save();
	// Make all client windows give up their connection to the database.
	int crncw = GetMdiClientWnd()->GetChildCount();
	int irncw;
	for (irncw = 0; irncw < crncw; irncw++)
	{
		AfClientWnd * pafcw = GetMdiClientWnd()->GetChildFromIndex(irncw);
		AfClientRecWndPtr qafcrw = dynamic_cast<AfClientRecWnd *>(pafcw);
		if (qafcrw)
			qafcrw->CloseProj();
	}

	// Determine how many windows are open using this database.
 	AfDbInfo * pdbi = GetLpInfo()->GetDbInfo();
 	AssertPtr(pdbi);
 	int cMainWnds = 0;
	Vector<AfMainWndPtr> & vqafw = AfApp::Papp()->GetMainWindows();
 	int cqafw = vqafw.Size();
 	for (int iqafw = 0; iqafw < cqafw; ++iqafw)
 	{
 		RecMainWndPtr qammw = dynamic_cast<RecMainWnd *>(vqafw[iqafw].Ptr());
 		AssertObj(qammw);

		if (qammw->GetLpInfo()->GetDbInfo() == pdbi)
		{
			cMainWnds++;
		}
	}

	// This saves all settings, etc. Do this before closing DbInfo.
	bool freturn = SuperClass::OnClose();

	// If this is the final window on this database, remove DbInfo to clear DB connection.
	// This is required for AfDbApp::CloseDbAndWindows to work properly.
	AfDbApp * pdapp = dynamic_cast<AfDbApp *>(AfApp::Papp());
	Assert(pdapp);
	if (cMainWnds == 1)
	{
		pdbi->CleanUp();
		pdapp->DelDbInfo(pdbi);
	}

	return freturn;
}


/*----------------------------------------------------------------------------------------------
	Update the caption bar display.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::UpdateCaptionBar()
{
	AfClientWnd * pafcw = m_qmdic->GetCurChild();
	if (!pafcw) // This is not always present at startup.
		return;

	// Draft window needs to try to diplay a caption that includes the reference based on the
	// current selection.
	SeDraftClientWnd * pdcw = dynamic_cast<SeDraftClientWnd *>(pafcw);
	if (pdcw)
	{
		// TODO RonM(TomB): Replace these three lines with a new function call on
		// SeDraftClientWnd to set the caption bar based on the current selection in
		// SeDraftWnd. You should be able to pass in the m_qmdic if you want. Ultimately,
		// you'll need to call
		// SetDraftCaptionBarForSelection(pvwsel, m_qcda, m_qmdic->GetCaptionBar());
		// but the first job is to get the selection from the root box of the SeDraftWnd
		// which is active (because it can be split).
		AfCaptionBar * pcpbr = m_qmdic->GetCaptionBar();
		AssertPtr(pcpbr);
		pcpbr->SetCaptionText(pafcw->GetViewName());
	}
	else
	{
		AfCaptionBar * pcpbr = m_qmdic->GetCaptionBar();
		AssertPtr(pcpbr);
		pcpbr->SetCaptionText(pafcw->GetViewName());
	}
}

/*----------------------------------------------------------------------------------------------
	Create RecordSpecs for a default UserViewSpec for the Concordance window.

	@param vwt view type (e.g., kvwtConc, kvwtDraft)
	@param plpi Ptr to language project info object
	@param puvs Out Ptr to a newly created UserViewSpec that we want to populate.
	@param pvuvs This shold normally be NULL. vuvs value is only used when called from TlsOptView
----------------------------------------------------------------------------------------------*/
void SeMainWnd::MakeNewView(UserViewType vwt, AfLpInfo * plpi, UserViewSpec * puvs,
		UserViewSpecVec * pvuvs)
{
	// Only two views are supported now.
	Assert((vwt == kvwtConc) || (vwt == kvwtDraft));
	AssertPtr(plpi);

	RecordSpecPtr qrsp;
	// For a real Data entry view we would load a different label (what appears next to the
	// plus sign) and help string (what appears if you use the ? in the tool bar) for each
	// block spec. But here we are just using it to specify what data to load, so it doesn't
	// matter what we use, so just get something to pass where the arguments are required.
	int stidLH = kstidParaContentsName;	// This is slightly naughty, since help is the same.
	AfDbInfoPtr qdbi = plpi->GetDbInfo();
	AssertPtr(qdbi);

	puvs->m_vwt = vwt;
	puvs->m_fv = true;
	puvs->m_ws = AfApp::UserWs();
	puvs->m_guid = CLSID_ScriptureEditor;

	// All the properties we want to load are on paragraphs, which are embedded objects

  	// For now load both Scripture Data and WFI for both views.
	// This will probably get more exciting later.
	qrsp.Create();
	qrsp->Init(puvs, kclidScripture, 0, vwt);
	// Scripture Books
	qrsp->AddHierField(true, stidLH, kflidScripture_ScriptureBooks,
		0, stidLH, konsNone, false, kFTVisAlways, kFTReqReq);
	// Finish it off
	qrsp->SetMetaNames(qdbi);

	qrsp.Create();
	qrsp->Init(puvs, kclidScrBook, 0, vwt);
	// Name of the book
	qrsp->AddField(true, stidLH, kflidScrBook_Name,
		kftMsa, GetSeLpInfo()->VernWss()[0], stidLH, kFTVisAlways, kFTReqReq);
	// Abbreviation of the book
	qrsp->AddField(true, stidLH, kflidScrBook_Abbrev,
		kftMsa, GetSeLpInfo()->VernWss()[0], stidLH, kFTVisAlways, kFTReqReq);
	// BookId
	qrsp->AddField(true, stidLH, kflidScrBook_BookId,
		kftObjRefAtomic, 0, stidLH, kFTVisAlways, kFTReqReq);
	// Finish it off
	qrsp->SetMetaNames(qdbi);

	qrsp.Create();
	qrsp->Init(puvs, kclidScrSection, 0, vwt);
	// Starting reference of the section.
	qrsp->AddField(true, stidLH, kflidScrSection_VerseRefStart,
		kftInteger, 0, stidLH, kFTVisAlways, kFTReqReq);
	// Ending reference of the section.
	qrsp->AddField(true, stidLH, kflidScrSection_VerseRefEnd,
		kftInteger, 0, stidLH, kFTVisAlways, kFTReqReq);
	// Finish it off
	qrsp->SetMetaNames(qdbi);

	qrsp.Create();
	qrsp->Init(puvs, kclidScrBookRef, 0, vwt);
	// BookId
	qrsp->AddField(true, stidLH, kflidScrBookRef_BookId,
		kftUnicode, 0, stidLH, kFTVisAlways, kFTReqReq);
	// OwnOrd$
	qrsp->AddField(true, stidLH, kflidCmObject_OwnOrd,
		kftInteger, 0, stidLH, kFTVisAlways, kFTReqReq);
	// Finish it off
	qrsp->SetMetaNames(qdbi);
}

#define BOOK_ID_LEN 3

/*----------------------------------------------------------------------------------------------
	Load the data into the main cache.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::LoadData()
{
	SeLpInfo * pwlpi = GetSeLpInfo();

	// This vector is the argument to LoadData to tell it what objects to load data about.
	HvoClsidVec vhcItems;
	HvoClsid hc;
	UserViewSpecVec & vuvs = m_qlpi->GetDbInfo()->GetUserViewSpecs();

	HVO hvoScrRefSystem = pwlpi->GetHvoScrRefSystem();

	// Load the ScrRefSystem data (it's small, so we don't need laziness; load it recursively)
	hc.hvo = hvoScrRefSystem;
	hc.clsid = kclidScrRefSystem;
	vhcItems.Push(hc);
	m_qcda->LoadData(vhcItems, vuvs[0], NULL, true);

	// Load the Scripture Books
	// ENHANCE TomB(JohnT): Add pointer to status bar if needed.
	LoadScrBooks(NULL /*pointer to status bar*/);

	// Load the Wordforms
	StrUni stuQuery;
	stuQuery.Format(L"exec GetScrConcWordforms %d", pwlpi->VernWss()[0]);

	// Set up column specs in qdcs
	IDbColSpecPtr qdcs;
	qdcs.CreateInstance(CLSID_DbColSpec);
	qdcs->Clear();
	qdcs->Push(koctObjVec, 0, kflidWordformInventory_Wordforms, 0); // HVOs of Wordforms
	qdcs->Push(koctMltAlt, 1, kflidWfiWordform_Form, pwlpi->VernWss()[0]);
	qdcs->Push(koctInt, 1, kflidWfiWordform_SpellingStatus, 0);
	qdcs->Push(koctInt, 1, ktagWfiWordform_TwficCount, 0);

	// ENHANCE TomB(JohnT): Add pointer to status bar if needed.
	m_qcda->Load(stuQuery.Bstr(), qdcs, pwlpi->GetHvoWordformInv(), 0,
		NULL /*pointer to status bar*/, FALSE);

	// Generate dummy property: store Title-case versions of SIL codes for display purposes.
	int chvoScrBookRefs;
	HVO hvoScrBookRef;
	CheckHr(m_qcda->get_VecSize(hvoScrRefSystem, kflidScrRefSystem_Books,
		&chvoScrBookRefs));

	OLECHAR rgchBookId[BOOK_ID_LEN+1]; // need space for trailing 0!
	for (int ihvo = 0; ihvo < chvoScrBookRefs; ihvo++)
	{
		CheckHr(m_qcda->get_VecItem(hvoScrRefSystem, kflidScrRefSystem_Books,
			ihvo, &hvoScrBookRef));
		BSTR bstrBookId;
		StrUni stuBookId;
		CheckHr(m_qcda->get_UnicodeProp(hvoScrBookRef, kflidScrBookRef_BookId, &bstrBookId));
		stuBookId.Assign(bstrBookId);

		Assert(stuBookId.Length() == BOOK_ID_LEN);
		for(int i=0; i<= BOOK_ID_LEN; i++)
			rgchBookId[i] = stuBookId[i];

		if(IsCharAlphaW(stuBookId[0]))
			CharLowerW(&rgchBookId[1]);

		CharLowerW(&rgchBookId[2]);

		CheckHr(m_qcda->CacheUnicodeProp(hvoScrBookRef, ktagScrBookRef_TitleCaseBookId,
			(OLECHAR *)rgchBookId, BOOK_ID_LEN));
	}
}

/*----------------------------------------------------------------------------------------------
	Load the HVOs of the Scripture books into the main cache.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::LoadScrBooks(AfStatusBarPtr qstbr)
{
	SeLpInfo * pwlpi = GetSeLpInfo();
	HVO hvoScripture = pwlpi->GetHvoScripture();

	// Load the Scripture Books
	// REVIEW JohnT(TomB): Is there a better way to do this?
	StrUni stuQuery;
	stuQuery.Format(L"exec GetScrBookInfo %d", hvoScripture);

	// Set up column specs in qdcs
	IDbColSpecPtr qdcs;
	qdcs.CreateInstance(CLSID_DbColSpec);
	qdcs->Clear();
	qdcs->Push(koctObjVec, 0, kflidScripture_ScriptureBooks, 0); // HVOs of Scripture Books
	qdcs->Push(koctObj, 1, kflidScrBook_BookId, 0);
	qdcs->Push(koctMlaAlt, 1, 0, 0);
	qdcs->Push(koctFlid, 1, 0, 0);
	qdcs->Push(koctEnc, 1, 0, 0);
	qdcs->Push(koctFmt, 1, 0, 0);

	// ENHANCE TomB(JohnT): Add pointer to status bar if needed.
	m_qcda->Load(stuQuery.Bstr(), qdcs, hvoScripture, 0, qstbr, FALSE);
}

/*----------------------------------------------------------------------------------------------
     Load the concordance data for a specific word.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::LoadWord(HVO hvoWord)
{
	// Stored procedure to load the Context data for this wordform
	StrUni stuQuery;
	stuQuery.Format(L"exec GetScrConcWordformInContext %d", hvoWord);

	// Set up column specs in qdcs
	IDbColSpecPtr qdcs;
	qdcs.CreateInstance(CLSID_DbColSpec);
	qdcs->Clear();
	qdcs->Push(koctObjVec, 0, kflidTxtWordformInContext_Analysis, 0);
	qdcs->Push(koctString, 1, kflidTxtWordformInContext_Form, 0);
	qdcs->Push(koctFmt, 1, kflidTxtWordformInContext_Form, 0);
	qdcs->Push(koctInt, 1, kflidTxtWordformInContext_ParaCharOffset, 0);
	qdcs->Push(koctInt, 1, kflidTxtWordformInContext_VerseRefStart, 0);
	qdcs->Push(koctInt, 1, kflidTxtWordformInContext_VerseRefEnd, 0);
	qdcs->Push(koctObj, 1, kflidTxtWordformInContext_Analysis, 0);
	// ENHANCE JohnT(TomB): I think we should have another koct value for atomic
	// properties so that the owner can be set automatically in the Load method
	// without having to pass a duplicate column.
	qdcs->Push(koctObj, 1, kflidCmObject_Owner, 0);
	qdcs->Push(koctString, 8, kflidStTxtPara_Contents, 0);
	qdcs->Push(koctFmt, 8, kflidStTxtPara_Contents, 0);

	// ENHANCE TomB(JohnT): Add pointer to status bar if needed.
	m_qcda->Load(stuQuery.Bstr(), qdcs, hvoWord, 0,	NULL /*pointer to status bar*/, FALSE);
}

/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
void CreateBitmap(HIMAGELIST himl, int iimage, COLORREF clrBkg, IPicture ** ppict)
{
	int kdxpImage;
	int kdypImage;

	// First, get the width and height of the bitmap image so a memory bitmap
	// can be created.
	::ImageList_GetIconSize(himl, &kdxpImage, &kdypImage);

	HDC hdc = ::GetDC(0);
	HDC hdcMem = ::CreateCompatibleDC(hdc);
	HBITMAP hbmpImage = ::CreateCompatibleBitmap(hdc, kdxpImage, kdypImage);
	::ReleaseDC(0, hdc);

	{ // Block: spal must go out of scope before ::DeleteDc()
		SmartPalette spal(hdcMem);

		HBITMAP hbmpOld = (HBITMAP)::SelectObject(hdcMem, hbmpImage);

		// If clrBkg is non negative, it means the caller wants to use it as the background
		// color and draw the bitmap transparently. (It's up to the caller to have given himl
		// a mask color for drawing transparently.) If clrImgBkg is negative, it means the
		// caller wants to draw the bitmap normally (i.e. without any transparent areas).
		if (clrBkg >= 0)
		{
			RECT rc = {0, 0, kdxpImage, kdypImage};
			::FillRect(hdcMem, &rc, (HBRUSH)clrBkg);
			::ImageList_Draw(himl, iimage, hdcMem, 0, 0, ILD_TRANSPARENT);
		}
		else
			::ImageList_Draw(himl, iimage, hdcMem, 0, 0, ILD_NORMAL);

		::SelectObject(hdcMem, hbmpOld);
	}

	::DeleteDC(hdcMem);

	PICTDESC pictd = {sizeof(PICTDESC), PICTYPE_BITMAP};
	pictd.bmp.hbitmap = hbmpImage;
	pictd.bmp.hpal = 0;
	CheckHr(OleCreatePictureIndirect(&pictd, IID_IPicture, true, (void **) ppict));
}

/*----------------------------------------------------------------------------------------------
	This function loads the spelling status bitmaps into member variables.
	ENHANCE DavidO: Call this routine when the application gets a system color changed message.
	Then the concordance will have to be redisplayed.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::PrepareSpellingStatusBitmaps()
{
	HBITMAP hbmp = ::LoadBitmap(ModuleEntry::GetModuleHandle(),
		MAKEINTRESOURCE(kridTBarSpelling));

	if (!hbmp)
		ThrowHr(WarnHr(E_FAIL));

	// Get the bitmaps width and height in order to tell the image list how big to make
	// each image in its list.
	BITMAP bmpInfo;
	if (::GetObject(hbmp, sizeof(BITMAP), &bmpInfo) == 0)
		return;

	// Dividing the bitmap's width by the number of images expected will give us the
	// width of each image.
	int kdxpImage = bmpInfo.bmWidth / kspellLim;
	int	kdypImage = bmpInfo.bmHeight;

	// Load an image list from a resource
	HIMAGELIST himl = ::ImageList_Create(kdxpImage, kdypImage, ILC_COLORDDB | ILC_MASK, 0, 0);
	if (!himl)
		ThrowHr(WarnHr(E_FAIL));

	// Add the bitmap with a mask so it can be drawn transparently.
	::ImageList_AddMasked(himl, hbmp, kclrPink);
	::DeleteObject(hbmp);

	// Create two versions of each spelling status icon. One for selected rows (where
	// the highlight background color shows through) and one for unselected rows (where
	// the window background color shows through).
	for (int i = 0; i < kspellLim; i++)
	{
		CreateBitmap(himl, i, COLOR_WINDOW + 1, &m_qpicSpellStatus[i]);
		CreateBitmap(himl, i, COLOR_HIGHLIGHT + 1, &m_qpicSelSpellStatus[i]);
		CreateBitmap(himl, i, COLOR_3DFACE + 1, &m_qpicSelNoFocusSpellStatus[i]);
	}
}

/*----------------------------------------------------------------------------------------------
	This function returns a bitmap picture for a specified spelling status. Spelling statuses
	are used for the concordance feature. The bitmaps are stored in the main window object to
	be available throughout the application in menus, status bar, etc. as well as in the word
	concordance.
----------------------------------------------------------------------------------------------*/
IPicturePtr SeMainWnd::GetSpellingStatusPic(int nStatus, bool fSelected, bool fHasFocus)
{
	// Make sure nStatus is in range.
	if (nStatus >= kspellLim || nStatus < 0)
		nStatus = kspellUndecided;

	if (fSelected && fHasFocus)
		return m_qpicSelSpellStatus[nStatus];
	else if (fSelected)
		return m_qpicSelNoFocusSpellStatus[nStatus];
	else
		return m_qpicSpellStatus[nStatus];
}


/*----------------------------------------------------------------------------------------------
	Import the data into the database. As side effects,
		- set m_qcda
		- set the HvoScripture of the current language project and of this window.
	Parameters:
		- stuSettingsFile (L"c:\\SFE\\Settings\\TEV.ssf")
		- stuRefStart (L"Mat 1:1")
		- stuRefEnd (L"Rev 22:21")
----------------------------------------------------------------------------------------------*/
void SeMainWnd::ImportScripture(StrUni & stuSettingsFile, StrUni & stuRefStart,
	StrUni & stuRefEnd)
{
	// start hour glass
	WaitCursor wc;

	// TODO BryanW: When we know how to do custom undo/redo commands insert
	// "Import Scripture" Undo/Redo
	StrUni stuUndo, stuRedo;
	StrUtil::MakeUndoRedoLabels(kstidImport, &stuUndo, &stuRedo);
	CheckHr(m_qcda->BeginUndoTask(stuUndo.Bstr(), stuRedo.Bstr()));

	// Save value of Undo/Redo action handler to prevent creation of sub-task undo items.
	IActionHandlerPtr qacthTemp;
	CheckHr(m_qcda->GetActionHandler(&qacthTemp));

	// Set to NULL while importing. Undo/Redo will be reset when Import is complete
	CheckHr(m_qcda->SetActionHandler(NULL));

	try
	{

#ifdef DEBUG
		time(&startImportScripture);
		elapsedParseStTxtPara = elapsedMakeWordforms = elapsedMakeTxtWfInContext = 0;
#endif
		ScriptureImporter scimp(stuSettingsFile, stuRefStart, stuRefEnd, this);
		scimp.Initialize();
		scimp.MainLoop();
		scimp.Finalize();
	}
	catch (...)
	{
		// Restore Undo/Redo
		CheckHr(m_qcda->SetActionHandler(qacthTemp));
		// stop hour glass
		wc.RestoreCursor();
		// REVIEW JohnT (TomB): Do we need to do an explicit rollback here?
		throw;
	}

	// Restore Undo/Redo
	CheckHr(m_qcda->SetActionHandler(qacthTemp));
	CheckHr(m_qcda->EndUndoTask());

	// stop hour glass
	wc.RestoreCursor();

#ifdef DEBUG
	time(&finishImportScripture);
	elapsedImportScripture = difftime(finishImportScripture, startImportScripture);
	achar psz[250];
	_stprintf(psz, _T("Time importing: %3.0f s.\rTime parsing StTxtPara's and creating")
		_T(" concordance objects: %3.0f s.\rTime making Wordforms: %3.0f s.\rTime making")
		_T(" TxtWordformInContext's: %3.0f s."), elapsedImportScripture, elapsedParseStTxtPara,
		elapsedMakeWordforms, elapsedMakeTxtWfInContext);
	MessageBox(m_hwnd, psz, _T("Stats"), MB_OK);
#endif
}


/*----------------------------------------------------------------------------------------------
	As it finally goes away, make doubly sure all pointers get cleared. This helps break cycles.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::OnReleasePtr()
{
	m_qsechgw.Clear();
	m_qcda.Clear();
	if (AfApp::Papp()->GetMainWndCount() == 0)	// Last one already removed.
	{
		// Write any modified or new encodings to the database.
		ILgWritingSystemFactoryPtr qwsf;
		if (m_qcda)
		{
			m_qcda->get_WritingSystemFactory(&qwsf);
			if (qwsf)
				qwsf->Shutdown();
		}
		////////////////////////////////////////////////////////////////////////////////////////
		// The following will be needed when (if?) the program deals with the values in the
		// tables LanguageProject_CurrentVernacularWritingSystems, LanguageProject_CurrentAnalysisWritingSystems,
		// LanguageProject_VernacularWritingSystems, or LanguageProject_AnalysisWritingSystems.
		////////////////////////////////////////////////////////////////////////////////////////
		// This must follow the preceding Shutdown method, so that all encodings have been
		// added to the database.
		//GetSeLpInfo()->SaveWritingSystems();
	}
	g_app.RemoveCmdHandler(this, 1);
	SuperClass::OnReleasePtr();
}

/*----------------------------------------------------------------------------------------------
	Load settings specific to this window from the registry. Load the viewbar, treebar,
	status bar, and tool bars settings.  Get the last data record that was showing. Load the
	window position.  Set the last overlay, filter, sort order, and the last view according to
	the registry.

	@param pszRoot The string that is used for this app as the root for all registry entries.
	@param fRecursive 	If true, then every child window will load their settings.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::LoadSettings(const achar * pszRoot, bool fRecursive)
{
	AssertPszN(pszRoot);

	SuperClass::LoadSettings(pszRoot, fRecursive);

	FwSettings * pfws = AfApp::GetSettings();
	DWORD dwT;

	// Read the viewbar settings. If the settings aren't there, use default values.
	DWORD dwViewbarFlags;
	if (!pfws->GetDword(pszRoot, _T("Viewbar Flags"), &dwViewbarFlags))
	{
		dwViewbarFlags = kmskShowLargeViewIcons
			| kmskShowLargeFilterIcons
			| kmskShowLargeSortIcons
			| kmskShowLargeOverlayIcons
			| kmskShowViewBar;
	}

	//m_qvwbrs->ChangeIconSize(kiViewsList, dwViewbarFlags & kmskShowLargeViewIcons);
//	m_qvwbrs->ChangeIconSize(kiFilterList, dwViewbarFlags & kmskShowLargeFilterIcons);
//	m_qvwbrs->ChangeIconSize(kiSortList, dwViewbarFlags & kmskShowLargeSortIcons);

	if (!pfws->GetDword(pszRoot, _T("LastViewBarGroup"), &dwT))
		dwT = kiViewsList;
	m_qvwbrs->SetCurrentList(Min((uint)dwT, (uint)(kiListMax)));

	m_qvwbrs->ShowViewBar(dwViewbarFlags & kmskShowViewBar);

	::ShowWindow(m_hwnd, SW_SHOW);
	OnIdle();
	::UpdateWindow(m_hwnd);

	Set<int> sisel;

	// NOTE: Make sure this is done after the filter is selected, or else none of the entries
	// will be shown in document or browse view.
	// Select the view that was last open.
	if (!pfws->GetDword(pszRoot, _T("LastView"), &dwT))
		dwT = 0;
	AssertObj(m_qvwbrs);
	AssertObj(m_qvwbrs->GetViewBar());
	AssertObj(dynamic_cast<AfWnd *>(m_qvwbrs->GetViewBar()->GetList(kiViewsList)));
	int iview = Min((uint)dwT, (uint)(m_qvwbrs->GetViewBar()->GetList(kiViewsList)->GetSize() - 1));
	sisel.Clear();
	sisel.Insert(iview);
	m_qvwbrs->SetSelection(kiViewsList, sisel);
	m_qvwbrs->ShowViewBar(dwViewbarFlags & kmskShowViewBar);
}

/*----------------------------------------------------------------------------------------------
	Get the application specific flags for the viewbar, which will be used in SaveSettings..

	@return The view bar flags for this class.
----------------------------------------------------------------------------------------------*/
DWORD SeMainWnd::GetViewbarSaveFlags()
{
	AssertObj(m_qvwbrs);
	DWORD dwViewbarFlags = 0;
	if (m_qvwbrs->IsShowingLargeIcons(kiViewsList))
		dwViewbarFlags |= kmskShowLargeViewIcons;
	if (::IsWindowVisible(m_qvwbrs->Hwnd()))
		dwViewbarFlags |= kmskShowViewBar;
	return dwViewbarFlags;
}


/*----------------------------------------------------------------------------------------------
	Save settings specific to this window to the registry. Save the viewbar, treebar,
	status bar, and tool bars settings.  Save the last data record that was showing. Save the
	window position.  Save the last overlay, filter, sort order, and the last view to the
	registry.

	@param pszRoot The string that is used for this app as the root for all registry entries.
	@param fRecursive 	If true, then every child window will be asked to save their settings.
----------------------------------------------------------------------------------------------*/
void SeMainWnd::SaveSettings(const achar * pszRoot, bool fRecursive)
{
	AssertPszN(pszRoot);

	SuperClass::SaveSettings(pszRoot, fRecursive);

	FwSettings * pfws = AfApp::GetSettings();

	// Store settings for three command line options, plus database name.
	SeLpInfo * plpi = dynamic_cast<SeLpInfo*>(m_qcda->GetLpInfo());
	AfDbInfo * pdbi = plpi->GetDbInfo();
	StrApp str;
	str = pdbi->ServerName();
	pfws->SetString(pszRoot, _T("LatestDatabaseServer"), str);
	str = plpi->PrjName();
	pfws->SetString(pszRoot, _T("LatestProjectName"), str);
	str = plpi->GetScriptureName();
	pfws->SetString(pszRoot, _T("LatestRootObjectName"), str);
	str = pdbi->DbName();
	pfws->SetString(pszRoot, _T("LatestDatabaseName"), str);

	// NOTE from RandyR: One could move the rest of this code up to a higher class,
	// but then a suitable way to get at the proper indces would need to be added.
	// Currently, each app declares its own version of an enum, and kiViewsList (and the others)
	// is different for each class. For instance, CLE has another item in the index ahead
	// of all the others, so its kiViewsList is 1, while all others have it as 0.

	// Store the view that is currently visible.
	Set<int> sisel;
	m_qvwbrs->GetSelection(kiViewsList, sisel);
	Assert(sisel.Size() == 1);
	pfws->SetDword(pszRoot, _T("LastView"), *sisel.Begin());
}

/*----------------------------------------------------------------------------------------------
	Handle window notification messages. Overriden so that we can show style usage as tooltip
----------------------------------------------------------------------------------------------*/
bool SeMainWnd::OnNotifyChild(int id, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	bool fRet = SuperClass::OnNotifyChild(id, pnmh, lnRet);

	switch (pnmh->code)
	{
	case TTN_GETDISPINFO:
		{
			if (id == kcidFmttbStyle)
			{
				// display style usage as tooltip
				NMTTDISPINFO * pnmtdi = (NMTTDISPINFO *)pnmh;
				AfWnd * pwnd = AfWnd::GetAfWnd(pnmh->hwndFrom);
				AssertPtr(pwnd);
				TssComboEx * ptce = dynamic_cast<TssComboEx *>(pwnd->Parent());
				AssertPtr(ptce);
				if (!ptce)
					break;
				ITsStringPtr qtss;
				ptce->GetText(&qtss);
				SmartBstr sbstr;
				CheckHr(qtss->get_Text(&sbstr));

				AfStylesheet * pasts;
				pasts = GetStylesheet();
				if (!pasts)
					break;

				// TODO EberhardB: Get usage field for current style
				// pasts->GetUsage(sbstr, &strHelp);
				StrApp strHelp(sbstr.Chars());	// dummy

				StrApp strAccel;
				GetMenuMgr()->FFindAccelKeyName(pnmtdi->hdr.idFrom, strAccel);
				if (strAccel.Length() > 0)
					strHelp.FormatAppend(_T(" (%s)"), strAccel.Chars());
				_tcsncpy(pnmtdi->szText, strHelp.Chars(), isizeof(pnmtdi->szText));
			}
			break;
		}
	default:
		break;
	}

	return fRet;
}

//:>********************************************************************************************
//:>	SeDbInfo methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
SeDbInfo::SeDbInfo()
{
}


/*----------------------------------------------------------------------------------------------
	Return the AfLpInfo from the cache corresponding to the language project ID passed in. If
	it has not been created yet, create it now.

	@param hvoLp language project ID

	@return language project info
----------------------------------------------------------------------------------------------*/
AfLpInfo * SeDbInfo::GetLpInfo(HVO hvoLp)
{
	int clpi = m_vlpi.Size();
	for (int ilpi = 0; ilpi < clpi; ilpi++)
	{
		if (hvoLp == m_vlpi[ilpi]->GetLpId())
			return m_vlpi[ilpi];
	}

	// We didn't find it in the cache, so create it now.
	SeLpInfoPtr qlpi;
	qlpi.Create();
	qlpi->Init(this, hvoLp);
	qlpi->OpenProject();
	m_vlpi.Push((AfLpInfo *)qlpi.Ptr());
	return qlpi;
}


//:>********************************************************************************************
//:>	SeLpInfo methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
SeLpInfo::SeLpInfo()
{
	m_hvoScripture = 0;
	m_qtsf.CreateInstance(CLSID_TsStrFactory);
}


/*----------------------------------------------------------------------------------------------
	Open a language project for this scripture app. Get several key items from the db
	and initialize other items.
	@return true if successful
----------------------------------------------------------------------------------------------*/
bool SeLpInfo::OpenProject()
{
	if (!LoadWritingSystems())
		return false;

	// Load the project ids and names.
	if (!LoadProjBasics())
		return false;

	//ENHANCE BryanW: enable this code if we need the LP's stylesheet separate from scripture
	// Create the stylesheet for this language project.
	//m_qdsts.Attach(NewObj AfDbStylesheet);
	//m_qdsts->Init(this, m_hvoLp);

	//  Create a bogus vernacular string and copy its format into the byte array m_rgbVernFmt.
	ITsStringPtr qtssT; // temporary vernacular string
	StrUni stuT(L" ");
	CheckHr(m_qtsf->MakeString(stuT.Bstr(), VernWss()[0], &qtssT));
	int cbFmtBufSize = kcbFmtBufMax;
	m_rgbVernFmt = NewObj byte[kcbFmtBufMax];
	HRESULT hr;
	hr = qtssT->SerializeFmtRgb(m_rgbVernFmt, cbFmtBufSize, &m_cbVernFmt);
	if (hr != S_OK)
	{
		if (hr == S_FALSE)
		{
			// If the supplied buffer (cbFmtBufSize) is too small, try it again with
			// the value that m_cbVernFmt was set to. If this fails, throw error.
			delete[] m_rgbVernFmt;
			m_rgbVernFmt = NewObj byte[m_cbVernFmt];
			cbFmtBufSize = m_cbVernFmt;
			CheckHr(qtssT->SerializeFmtRgb(m_rgbVernFmt, cbFmtBufSize, &m_cbVernFmt));
		}
		else
		{
			ThrowHr(WarnHr(E_UNEXPECTED));
		}
	}
	if (!m_cbVernFmt)
	{
		delete[] m_rgbVernFmt;
		m_rgbVernFmt = NULL;
	}

	// Get a default character property engine.
	// TODO TomB: We need to get the cpe for the primary vernacular writing system.
	ILgWritingSystemFactoryPtr qwsf;
	m_qdbi->GetLgWritingSystemFactory(&qwsf);
	AssertPtr(qwsf);
	qwsf->get_UnicodeCharProps(&m_qcpeVern);

	return true;
}


/*----------------------------------------------------------------------------------------------
	Load basic information for the project (ids, names).
	@return true if successful
----------------------------------------------------------------------------------------------*/
bool SeLpInfo::LoadProjBasics()
{
	IOleDbEncapPtr qode;
	IOleDbCommandPtr qodc;
	StrUni stu;
	ComBool fIsNull;
	ComBool fMoreRows;
	ULONG cbSpaceTaken;
	OLECHAR rgchProjName[MAX_PATH];
	m_vhvoPsslIds.Clear(); // Clear any old values.

	//  Obtain pointer to IOleDbEncap interface and execute the given SQL select command.
	AssertPtr(m_qdbi);
	m_qdbi->GetDbAccess(&qode);

	// If we don't already have the HVO of the Word Form Inventory (which we most likely
	// don't), get it.
	if (m_hvoWfi == 0)
	{
		try
		{
			stu.Format(L"SELECT dst FROM LanguageProject_WordformInventory lps (readuncommitted) "
                L"where lps.src = %d", m_hvoLp);
			CheckHr(qode->CreateCommand(&qodc));
			CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtSelectWithOneRowset));
			CheckHr(qodc->GetRowset(0));
			CheckHr(qodc->NextRow(&fMoreRows));
			if (fMoreRows)
			{
				CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_hvoWfi),
					isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			}
			else
			{
				// If we don't have any rows, this language project doesn't have a Word Form
                // Inventory.
				// TODO BryanW: Should we make one?
			}
		}
		catch (...)
		{
			return false;
		}
	}

	// If we don't already have the HVO of the ScrRefSystem (which we most likely
	// don't), get it.
	if (m_hvoScrRefSystem == 0)
	{
		try
		{
			stu.Format(L"SELECT id FROM ScrRefSystem (readuncommitted)");
			CheckHr(qode->CreateCommand(&qodc));
			CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtSelectWithOneRowset));
			CheckHr(qodc->GetRowset(0));
			CheckHr(qodc->NextRow(&fMoreRows));
			if (fMoreRows)
			{
				CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_hvoScrRefSystem),
					isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			}
			else
			{
				// If we don't have any rows, there is no ScrRefSystem
				Assert(false);
			}
		}
		catch (...)
		{
			return false;
		}
	}

	/*----------------------------------------------------------------------------------------*/
#ifdef DEBUG
	try
	{
		ULONG nDepth = 0;
		int cRow = 0;
		stu.Format(L"SELECT [Depth] FROM ClassPar$ WHERE [Src] in (5058, 5062) and [Dst] = 0");
		CheckHr(qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));
		while (fMoreRows)
		{
			CheckHr(qodc->GetColValue(1, &nDepth, isizeof(ULONG), &cbSpaceTaken, &fIsNull, 0));
			// Note: If either of these assertions fire, the model has changed. If we get a
			// null value, then ClassPar$ is probably corrupt. If the depth is greater than 1
			// for either class, the procedure CreateObj_TxtWordFormInContext and/or
			// CreateObj_WfiWordForm need to be changed to create twfics and/or wordforms
			// that are not direct descendents of the CMObject class (see CreateObject$).
			Assert(!fIsNull);
			Assert(nDepth == 1);
			CheckHr(qodc->NextRow(&fMoreRows));
			cRow++;
		}
		// If we don't get exactly 2 rows, then one (or more) of these classes has been deleted:
		// * 5058 (TxtWordformInContext)
		// * 5062 (WfiWordForm)
		Assert(cRow == 2);
	}
	catch (...)
	{
		return false;
	}
#endif

	/*----------------------------------------------------------------------------------------*/

	try
	{
		stu.Format(L"SELECT Txt FROM CmProject_Name (readuncommitted) "
			L"where obj = %d", m_hvoLp);
//		stu.Format(L"SELECT lp.People, n.Txt FROM LanguageProject lp (readuncommitted) "
//			L"JOIN CmProject_Name n (readuncommitted) ON n.Obj = lp.id "
//			L"where lp.id = %d", m_hvoLp);
		CheckHr(qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));
		if (fMoreRows)
		{
			CheckHr(qodc->GetColValue(1, reinterpret_cast <ULONG *>(rgchProjName),
				isizeof(rgchProjName), &cbSpaceTaken, &fIsNull, 2));
		}
		else
		{
			// If we don't have any rows, we used a wrong language project id (idlgpr),
			// so return and let the user open a project from the Debug menu (for now).
			return false;
		}
		m_stuPrjName = rgchProjName;
	}
	catch (...)
	{
		return false;
	}
	return true;
}


/*----------------------------------------------------------------------------------------------
	Initialize the scripture and scripture stylesheet objects.

	@param hvo  The hvo of the existing scripture (or zero if none).  Caller should have
				gotten this from the LanguageProject.TranslatedScripture property in the DB.
----------------------------------------------------------------------------------------------*/
void SeLpInfo::InitScriptureItems(HVO hvoScripture)
{
	if (hvoScripture)
	{
		// Set up for existing scripture in the db
	    m_hvoScripture = hvoScripture;
		CacheScriptureName();
	}
	else
	{
		// Make new scripture object in the db
		CheckHr(m_qcvd->MakeNewObject(kclidScripture, // Type of the new object
			m_hvoLp, // Owned by the current language project
			kflidLanguageProject_TranslatedScripture,
			-2, // reserved value for atomic property
			&m_hvoScripture));
		// and set up its name
		StrUni stuName(kstidDefaultNewScriptureName);
		ITsStringPtr qtssName;
		CheckHr(m_qtsf->MakeString(stuName.Bstr(), AnalWs(), &qtssName));
		CheckHr(m_qcvd->SetMultiStringAlt(m_hvoScripture, kflidCmMajorObject_Name, AnalWs(),
			qtssName));
		m_stuScriptureName = stuName;
	}

	// Create the scripture stylesheet in memory
	// The scripture style sheet will utilize m_qdsts rather than a new m_qtsts.
	// m_qdsts is cleaned up by AfLpInfo::CleanUp()
	m_qdsts.Attach(NewObj TeStylesheet);

	// Load scripture styles from the db
	m_qdsts->Init(this, m_hvoScripture, kflidScripture_Styles);
	GetScriptureStylesheet()->CkReqdStyles();

}

/*----------------------------------------------------------------------------------------------
	Cache the Scripture object name, so it can be put in the Registry
	later on app shutdown.
----------------------------------------------------------------------------------------------*/
void SeLpInfo::CacheScriptureName()
{
	IOleDbEncapPtr qode;
	IOleDbCommandPtr qodc;
	StrUni stu;
	ComBool fIsNull;
	ComBool fMoreRows;
	ULONG cbSpaceTaken;
	OLECHAR rgchScripName[MAX_PATH];

	//  Obtain pointer to IOleDbEncap interface and execute the given SQL select command.
	AssertPtr(m_qdbi);
	m_qdbi->GetDbAccess(&qode);

	// Cache the Scripture object name stored in the db, so it can be put in the Registry
	// later on app shutdown.
	try
	{
		stu.Format(L"SELECT Txt FROM CmMajorObject_Name (readuncommitted) "
			L"where obj = %d", m_hvoScripture);
		CheckHr(qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(stu.Bstr(), knSqlStmtSelectWithOneRowset));
		CheckHr(qodc->GetRowset(0));
		CheckHr(qodc->NextRow(&fMoreRows));
		if (fMoreRows)
		{
			CheckHr(qodc->GetColValue(1, reinterpret_cast <ULONG *>(rgchScripName),
				isizeof(rgchScripName), &cbSpaceTaken, &fIsNull, 2));
		}
		else
		{
			// If we don't have any rows, we used a wrong id (m_hvoScripture),
			// or there was no such string.
			return;
		}
		m_stuScriptureName = rgchScripName;
	}
	catch (...)
	{
		return; // We won't get all worked up over this error.
	}
}

/*----------------------------------------------------------------------------------------------
	This is a helper function to get a starting and ending verse number from a Unicode string
	which may or may not represent a verse bridge.
	@param stuVerseNum the string representing the verse number(s).
	@param nVerseStart the starting verse number in stuVerseNum.
	@param nVerseEnd the ending verse number in stuVerseNum (will be different from
		nVerseStart if a bridge).
----------------------------------------------------------------------------------------------*/
void SeLpInfo::ExtractVerseNums(StrUni stuVerseNum, int &nVerseStart, int &nVerseEnd)
{
	int nFactor = 1;
	int nVerseT = 0;
	int nVerseFirst = nVerseT; // The left-most (or right-most if R2L) non-zero number found.
	bool fVerseBridge = false;
	// REVIEW JohnW (TomB): For robustness, our initial implementation will assume
	// that the first set of contiguous numbers is the starting verse number and
	// the last set of contiguous numbers is the ending verse number. This way, we
	// don't have to know what all the legal possibilities of bridge markers and
	// sub-verse segment indicators are.
	for (int i = stuVerseNum.Length() - 1; i >= 0; i--)
	{
		int nv;
		HRESULT hr = m_qcpeVern->get_NumericValue(stuVerseNum[i], &nv);
		if (hr != S_OK && hr != E_FAIL)
			CheckHr(hr);
		if (hr == S_OK && nv >= 0 && nv <= 9)
		{
			if (nFactor > 100) // verse number greater than 999
			{
				// REVIEW JohnW (TomB): Need to decide how we want to display this.
				nVerseT = 999;
			}
			else
			{
				nVerseT += nFactor * nv;
				nFactor *= 10;
			}
			nVerseFirst = nVerseT;
		}
		else if (nVerseT > 0)
		{
			if (!fVerseBridge)
			{
				fVerseBridge = true;
				nVerseFirst = nVerseEnd = nVerseT;
			}
			nVerseT = 0;
			nFactor = 1;
		}
	}
	nVerseStart = nVerseFirst;
	if (!fVerseBridge)
	{
		nVerseEnd = nVerseFirst;
	}
	// Don't want to use an assertion for this because it could happen due to bad input data.
	// If this causes problems, just pick one ref and use it for both or something.
	// TODO TomB: Later, we need to catch this and flag it as an error.
	//Assert(nVerseStart <= nVerseEnd);
}

/*----------------------------------------------------------------------------------------------
	This is a helper function to get a chapter number from a Unicode string.
	@param stuVerseNum the string representing the verse number(s).
	@param nVerseStart the starting verse number in stuVerseNum.
	@param nVerseEnd the ending verse number in stuVerseNum (will be different from
		nVerseStart if a bridge).
----------------------------------------------------------------------------------------------*/
void SeLpInfo::ExtractChapterNum(StrUni stuChapterNum, int &nChapter)
{
	int nFactor = 1;
	nChapter = 0;

	for (int i = stuChapterNum.Length() - 1; i >= 0; i--)
	{
		int nv;
		HRESULT hr = m_qcpeVern->get_NumericValue(stuChapterNum[i], &nv);
		if (hr != S_OK && hr != E_FAIL)
			CheckHr(hr);
		if (hr == S_OK && nv >= 0 && nv <= 9)
		{
			if (nFactor > 100) // chapter number greater than 999
			{
				// REVIEW JohnW (TomB): Need to decide how we want to display this.
				nChapter = 999;
			}
			else
			{
				nChapter += nFactor * nv;
				nFactor *= 10;
			}
		}
		else
		{
			nChapter = 0;
			nFactor = 1;
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Check to make sure our map of wordforms is up-to-date. If it's not, update it.
----------------------------------------------------------------------------------------------*/
void SeLpInfo::GetUpdatedWordforms()
{
	int chvoWords;
	HVO hvoWfiWordform;
	CheckHr(m_qcvd->get_VecSize(m_hvoWfi, kflidWordformInventory_Wordforms,
		&chvoWords));
	if (m_hmstuhvoWordforms.Size() != chvoWords)
	{
		m_hmstuhvoWordforms.Clear();
		for (int ihvoWords = 0; ihvoWords < chvoWords; ihvoWords++)
		{
			CheckHr(m_qcvd->get_VecItem(m_hvoWfi, kflidWordformInventory_Wordforms,
				ihvoWords, &hvoWfiWordform));
			ITsStringPtr qtssWord;
			StrUni stuWord;
			int cch;
			const OLECHAR * pchWord;
			CheckHr(m_qcvd->get_MultiStringAlt(hvoWfiWordform, kflidWfiWordform_Form,
				VernWss()[0], &qtssWord));
			CheckHr(qtssWord->LockText(&pchWord, &cch));
			stuWord.Assign(const_cast<OLECHAR *>(pchWord), cch);
			CheckHr(qtssWord->UnlockText(pchWord));
			// Review Waxhaw team (JohnT): the following line will throw an exception if the key
			// is already in use. Can we guarantee that no two wordforms will have the same form?
			// (Even two with missing or empty forms will cause a problem).
			// If not we should do something else. Passing true as an additional third argument
			// will allow overwriting and cause the last occurrence of a particular WF to win.
			m_hmstuhvoWordforms.Insert(stuWord, hvoWfiWordform);
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Parse a new StTxtPara: identify the words and insert character offsets and references into
	the StTxtPara_AnalyzedTextObjects table.
	@param hvoPara the paragraph whose contents have been changed.
	@param nStartRefPrev BBCCCVVV-style verse reference immediately preceeding this paragraph.
	@param nEndRefPrev BBCCCVVV-style verse reference immediately preceeding this paragraph.
	If the preceeding verse is a bridge, then nStartRefPrev will be the first verse in bridge
	and nEndRefPrev will be the last verse in the bridge.
----------------------------------------------------------------------------------------------*/
void SeLpInfo::ParseNewStTxtPara(HVO hvoPara, ITsStringPtr qtssPara, int nStartRefPrev,
	int nEndRefPrev)
{
#ifdef DEBUG
	time(&startParseStTxtPara);
#endif

	// Make sure this method is not being called on a previously existing paragraph.
	int chvoTwfic;
	CheckHr(m_qcvd->get_VecSize(hvoPara, kflidStTxtPara_AnalyzedTextObjects, &chvoTwfic));
	Assert(!chvoTwfic);

	// Check to make sure our map of wordforms is up-to-date. Specifically, it will not be if:
	// a) This is the first time we're using it (size will be 0)
	// b) Something bad has happened (size will be something weird)
	GetUpdatedWordforms();

	// Lock down the paragraph contents to prepare for parsing
	const OLECHAR * pchStart; // beginning of the paragraph contents
	int cch;
	CheckHr(qtssPara->LockText(&pchStart, &cch));

	bool fImporting = true;
	ParseParaAux(hvoPara, qtssPara, pchStart, 0, cch, nStartRefPrev, nEndRefPrev, fImporting);

	// TODO TomB: When we're done parsing, if ending ref > section ending ref, we need to
	// increase section ending ref. In general, we need to do all kinds of stuff to make sure
	// the paragraph contents and section ref are in synch. It makes my head hurt just
	// thinking about it.

	CheckHr(qtssPara->UnlockText(pchStart));

#ifdef DEBUG
	time(&finishParseStTxtPara);
	elapsedParseStTxtPara += difftime(finishParseStTxtPara, startParseStTxtPara);
#endif
}

/*----------------------------------------------------------------------------------------------
	Parse a StTxtPara: identify the words and insert character offsets and references into the
	StTxtPara_AnalyzedTextObjects table.
	@param hvoPara the paragraph whose contents have been changed.
	@param ivMin the starting character index where the change occurred.
	@param cvIns the number of characters inserted.
	@param cvDel the number of characters deleted.
----------------------------------------------------------------------------------------------*/
void SeLpInfo::ParseStTxtPara(HVO hvoPara, int ivMin, int cvIns, int cvDel)
{
#ifdef DEBUG
	time(&startParseStTxtPara);
#endif

	// REVIEW JohnT (TomB): Is there any reason why this could happen? Should we do anything if
	// it does?
	if (ivMin == 0 && cvIns == 0 && cvDel == 0)
		return;

	// Remove any existing StTxtPara_AnalyzedTextObjects relationships for the edited portion
	// of this paragraph.
	int chvoTwfic;
	CheckHr(m_qcvd->get_VecSize(hvoPara, kflidStTxtPara_AnalyzedTextObjects, &chvoTwfic));

	// Lock down the paragraph contents to prepare for parsing
	ITsStringPtr qtssPara; // paragraph contents
	CheckHr(m_qcvd->get_StringProp(hvoPara, kflidStTxtPara_Contents, &qtssPara));
	const OLECHAR * pchStart; // beginning of the paragraph contents
	int cch;
	CheckHr(qtssPara->LockText(&pchStart, &cch));
	const OLECHAR * pchLim = pchStart + cch;

	// set ihvoMin and ihvoLim to bracket the changed portion of the paragraph, so we can
	// delete now bogus TWFICs
	int ihvoMin;
	int ihvoLim;
	int ihvo;

	// First step is to determine whether the edit is a boundary condition. If so, we
	// tweak the values we pass to the GetRgChangedTwfics stored procedure.
	// 1) If the character right before the edited text is not word-forming, then we don't need
	// to delete the TWFIC right before the edited text.
	int ichMin = ivMin;
	int cchDel = cvDel;
	TsRunInfo tsi;
	ITsTextPropsPtr qttpRun;

	// Next step is to form the SQL query, set the parameters, and execute the command to get
	// the affected range of TWFICs to delete.
	IOleDbEncapPtr qode	= m_qcvd->GetOleDbEncap();
	IOleDbCommandPtr qodc;
	StrUni stuSql;
	CheckHr(qode->CreateCommand(&qodc));
	stuSql.Format(L"exec GetRgChangedTwfics %d, %d, %d, ? output, ? output", hvoPara, ichMin,
		cchDel);

	qodc->SetParameter(1, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
		(ULONG *)&ihvoMin, sizeof(int));

	qodc->SetParameter(2, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
		(ULONG *)&ihvoLim,	sizeof(int));

	// Actually execute the command.
	CheckHr(qodc->ExecCommand(stuSql.Bstr(), knSqlStmtNoResults));
	ComBool fIsNull1, fIsNull2;
	qodc->GetParameter(1, reinterpret_cast<ULONG *>(&ihvoMin), sizeof(int), &fIsNull1);
	qodc->GetParameter(2, reinterpret_cast<ULONG *>(&ihvoLim), sizeof(int), &fIsNull2);
	// REVIEW JohnT (TomB): what should we do if we don't get a valid HVO?
	if (fIsNull1 || fIsNull2 || ihvoMin < 0 || ihvoLim < ihvoMin)
	{
		// Something odd has happened, so discard all twfics and reparse entire paragraph.
		ihvoMin = 0;
		ihvoLim = chvoTwfic;
		ivMin = 0;
		cvIns = cch;
	}
	else if (cvIns != cvDel && ihvoLim < chvoTwfic)
	{
		// Adjust the paragraph offsets of all the Twfics after the edited portion
		int cchAdj = cvIns - cvDel;
		CheckHr(qode->CreateCommand(&qodc));
		stuSql.Format(L"exec AdjustTwficOffsets %d, %d, %d", hvoPara, ichMin + cchDel,
			cchAdj);

		// Actually execute the command.
		CheckHr(qodc->ExecCommand(stuSql.Bstr(), knSqlStmtNoResults));

		// Now fix the cached values.
		for (ihvo = ihvoLim; ihvo < chvoTwfic; ihvo++)
		{
			HVO hvoTwfic;
			int ichParaOffset;
			CheckHr(m_qcvd->get_VecItem(hvoPara, kflidStTxtPara_AnalyzedTextObjects, ihvo,
				&hvoTwfic));
			if (CheckHr(m_qcvd->get_IntProp(hvoTwfic, kflidTxtWordformInContext_ParaCharOffset,
					&ichParaOffset)) == S_OK) // returns S_FALSE if property not loaded.
			{
				CheckHr(m_qcvd->CacheIntProp(hvoTwfic, kflidTxtWordformInContext_ParaCharOffset,
					ichParaOffset + cchAdj));
				CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, hvoTwfic,
					kflidTxtWordformInContext_ParaCharOffset, 0, 0, 0));
			}
		}
	}
	// now remove the range
	for (ihvo = ihvoMin; ihvo < ihvoLim; ihvo++)
	{
		HVO hvoTwfic;
		HVO hvoWordform;
		// We're deleting from the beginning, so just keep deleting the Min hvo.
		CheckHr(m_qcvd->get_VecItem(hvoPara, kflidStTxtPara_AnalyzedTextObjects, ihvoMin,
			&hvoTwfic));
		CheckHr(m_qcvd->get_ObjectProp(hvoTwfic, kflidTxtWordformInContext_Analysis,
			&hvoWordform));
		if (!hvoWordform)
		{
			// Load the Wordform
			StrUni stuQuery;
			CheckHr(qode->CreateCommand(&qodc));
			stuQuery.Format(L"select analysis from txtwordformincontext (readuncommitted) where id = %d", hvoTwfic);
			CheckHr(qodc->ExecCommand(stuQuery.Bstr(), knSqlStmtSelectWithOneRowset));
			CheckHr(qodc->GetRowset(0));
			ComBool fMoreRows;
			CheckHr(qodc->NextRow(&fMoreRows));
			if (fMoreRows)
			{
				ULONG cbSpaceTaken;
				ComBool fIsNull;
				CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&hvoWordform),
					isizeof(int), &cbSpaceTaken, &fIsNull, 0));
			}
		}
		CheckHr(m_qcvd->DeleteObjOwner(hvoPara, hvoTwfic, kflidStTxtPara_AnalyzedTextObjects,
			ihvoMin));

		// Delete from the cache the back-reference for the TxtWordformInContext object we
		// just blew away.
		int chvoTwficForWordform;
		HVO hvoT;
		CheckHr(m_qcvd->get_VecSize(hvoWordform, kflidTxtWordformInContext_Analysis,
			&chvoTwficForWordform));
		for (int ihvoTwfic = 0; ihvoTwfic < chvoTwficForWordform; ihvoTwfic++)
		{
			CheckHr(m_qcvd->get_VecItem(hvoWordform, kflidTxtWordformInContext_Analysis,
				ihvoTwfic, &hvoT));
			if (hvoTwfic == hvoT)
			{
				CheckHr(m_qcvd->CacheReplace(hvoWordform, kflidTxtWordformInContext_Analysis,
					ihvoTwfic, ihvoTwfic + 1, // Delete from sequence at this position.
					NULL,
					0));
				CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, hvoWordform,
					kflidTxtWordformInContext_Analysis, ihvoTwfic, 0, 1));
				break;
			}
		}
		// Decrement the twfic count in the cache for the wordform.
		//
		// I don't think this should ever happen, but if it does, it's probably
		// no big deal. If it does, try to figure out why. If there's a real
		// problem, fix it. Otherwise, remove this ASSERT and add a condition here to
		// not attempt to decrement the twfic count if hvoWordform == 0.
		Assert(hvoWordform);
		CheckHr(m_qcvd->get_IntProp(hvoWordform, ktagWfiWordform_TwficCount,
			&chvoTwficForWordform));
		if (chvoTwficForWordform)
		{
			chvoTwficForWordform--;
			CheckHr(m_qcvd->CacheIntProp(hvoWordform, ktagWfiWordform_TwficCount,
				chvoTwficForWordform));
			CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, hvoWordform,
				ktagWfiWordform_TwficCount, 0, 0, 0));
		}
	}

	// Check to make sure our map of wordforms is up-to-date. Specifically, it will not be if:
	// a) This is the first time we're using it (size will be 0)
	// b) Something bad has happened (size will be something weird)
	GetUpdatedWordforms();

	// Now get the starting reference for the edited text.
	// Start by getting the start and end references from the section.
	int nBbCccVvvStart, nBbCccVvvEnd;
	HVO hvoStTxt;
	int nFlid;
	CheckHr(m_qcvd->get_ObjectProp(hvoPara, kflidCmObject_Owner, &hvoStTxt));
	CheckHr(m_qcvd->get_IntProp(hvoStTxt, kflidCmObject_OwnFlid, &nFlid));
	switch (nFlid)
	{
	case kflidScrSection_Content:
	case kflidScrSection_Heading:
		{
			HVO hvoScrSection;
			CheckHr(m_qcvd->get_ObjectProp(hvoStTxt, kflidCmObject_Owner, &hvoScrSection));
			CheckHr(m_qcvd->get_IntProp(hvoScrSection, kflidScrSection_VerseRefStart,
				&nBbCccVvvStart));
			CheckHr(m_qcvd->get_IntProp(hvoScrSection, kflidScrSection_VerseRefEnd,
				&nBbCccVvvEnd));

			// Must have a non-zero book and chapter number and the end ref must not be less
			// than the start ref.
			Assert(nBbCccVvvStart >= 1001000 && nBbCccVvvStart <= nBbCccVvvEnd);
		}
		break;
	case kflidScrBook_Title:
		{
			HVO hvoScrBook, hvoScrBookRef;
			int nBook;
			CheckHr(m_qcvd->get_ObjectProp(hvoStTxt, kflidCmObject_Owner, &hvoScrBook));
			CheckHr(m_qcvd->get_ObjectProp(hvoScrBook, kflidScrBook_BookId, &hvoScrBookRef));
			CheckHr(m_qcvd->get_IntProp(hvoScrBookRef, kflidCmObject_OwnOrd, &nBook));
			nBbCccVvvStart = nBbCccVvvEnd = nBook * 1000000 + 1000;
		}
		break;
	default:
		Assert(false); // Unexpected owning field for StText
		nBbCccVvvStart = nBbCccVvvEnd = 0;
		break;
	}

	// If we are in the Content of a section, we have the starting and ending BCV's for the
	// section, but we need to find the starting chapter and verse for the changed portion of
	// this paragraph.
	// To find verse and chapter numbers, start at the place
	// in this paragraph where the editing starts and look backward toward the start of the
	// paragraph. If it isn't found in this paragraph, keep searching backward through
	// preceeding paragraphs until it's found.
	if (nFlid == kflidScrSection_Content)
	{
		int nBook, nVerseStart, nVerseEnd;
		nBook = nBbCccVvvStart / 1000000;
		HVO hvoParaT = hvoPara;
		const OLECHAR * pchStartT = pchStart; // beginning of the paragraph contents
		const OLECHAR * pch = pchStartT + ivMin - 1; // pointer to step thru para contents
		ITsStringPtr qtssParaT = qtssPara; // paragraph contents
		bool fGotVerse = false;
		bool fGotChapter = false;
		int chvoParas = 0;
		int ihvoP = 0;
		while (!fGotVerse || !fGotChapter)
		{
			for (; pch >= pchStartT; pch--)
			{
				// Get props of current run.
				CheckHr(qtssParaT->FetchRunInfoAt(pch - pchStartT, &tsi, &qttpRun));
				// See if it is our verse number style.
				if (IfVerseNumberStyle(qttpRun) && !fGotVerse)
				{
					// The whole run is the verse number.
					StrUni stuVerseNum(pchStartT + tsi.ichMin, tsi.ichLim - tsi.ichMin);
					ExtractVerseNums(stuVerseNum, nVerseStart, nVerseEnd);
					fGotVerse = true;
				}
				else if (IfChapterNumberStyle(qttpRun)) // See if it is our chapter number style.
				{
					// Assume the whole run is the chapter number
					StrUni stuChapterNum(pchStartT + tsi.ichMin, tsi.ichLim - tsi.ichMin);
					int nChapterT;
					ExtractChapterNum(stuChapterNum, nChapterT);
					// REVIEW TomB: What if we get nChapterT == 0? For now, let's pretend
					// we didn't see a chapter number style at all and just keep looking.
					if (nChapterT)
					{
						if (!fGotVerse)
						{
							// Found a chapter number but no verse number, so assume the
							// edited text is in verse 1 of the chapter.
							nBbCccVvvStart = nBbCccVvvEnd = nBook * 1000000 +
								nChapterT * 1000 + 1;
							fGotVerse = fGotChapter = true;
						}
						else
						{
							// Found a chapter number to go with the verse number we
							// already found, so build the full reference using this
							// chapter with the previously found verse.
							fGotChapter = true;
							nBbCccVvvStart = nBook * 1000000 + nChapterT * 1000 +
								nVerseStart;
							nBbCccVvvEnd = nBook * 1000000 + nChapterT * 1000 + nVerseEnd;
						}
						break;
					}
				}
				else
				{
					// Try to get the reference from a TWFIC in this run.
					CheckHr(qode->CreateCommand(&qodc));
					int ichLimT = tsi.ichLim;
					// If we're in the run that was edited, we can't consider any twfics
					// beyond the start of the edit because a verse number may have been
					// deleted, which would leave later TWFICS in this run with an old
					// reference (which we are about to try to replace with the new one).
					if (qtssParaT == qtssPara && ivMin < tsi.ichLim)
					{
						ichLimT = ivMin;
					}
					stuSql.Format(L"exec GetScrRefsForRun %d, %d, %d, ? output, ? output",
						hvoParaT, tsi.ichMin, ichLimT);

					int nScrRefStartT, nScrRefEndT;
					qodc->SetParameter(1, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
						(ULONG *)&nScrRefStartT, sizeof(int));

					qodc->SetParameter(2, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
						(ULONG *)&nScrRefEndT,	sizeof(int));

					// Actually execute the command.
					CheckHr(qodc->ExecCommand(stuSql.Bstr(), knSqlStmtNoResults));
					qodc->GetParameter(1, reinterpret_cast<ULONG *>(&nScrRefStartT),
						sizeof(int), &fIsNull1);
					qodc->GetParameter(2, reinterpret_cast<ULONG *>(&nScrRefEndT),
						sizeof(int), &fIsNull2);
					if (fIsNull1 || fIsNull2)
					{
						// No TWFICS found in run, so keep looking backward.
						continue;
					}
					else if (nScrRefStartT < 1001000 ||
						(nScrRefStartT / 1000) != (nScrRefEndT / 1000))
					{
						// Something bad has happened, but keep looking backward.
						Assert(false);
					}
					else if (fGotVerse)
					{
						// Use the reference we just got to get the chapter number only.
						int nChapterT, nVerseDummy;
						GetBCV(nScrRefStartT, nBook, nChapterT, nVerseDummy);
						nBbCccVvvStart = nBook * 1000000 + nChapterT * 1000 + nVerseStart;
						nBbCccVvvEnd = nBook * 1000000 + nChapterT * 1000 + nVerseEnd;
						fGotChapter = true;
						break;
					}
					else
					{
						// Use the references we just got.
						nBbCccVvvStart = nScrRefStartT;
						nBbCccVvvEnd = nScrRefEndT;
						fGotVerse = fGotChapter = true;
						break;
					}
				}
				pch = pchStartT + tsi.ichMin;
			}
			if (fGotVerse && fGotChapter)
				break;
			// We got to the beginning of the paragraph being edited and still haven't
			// found a decent reference for our edited text, so keep looking back to
			// get it from a previous paragraph.
			// ENHANCE TomB: If we load ord numbers for paragraphs, we can avoid this loop.
			if (chvoParas == 0)
			{
				CheckHr(m_qcvd->get_VecSize(hvoStTxt, kflidStText_Paragraphs,
					&chvoParas));
				// Go forward through vector of paragraphs to find the one being parsed
				for (; ihvoP < chvoParas; ihvoP++)
				{
					CheckHr(m_qcvd->get_VecItem(hvoStTxt, kflidStText_Paragraphs,
						ihvoP, &hvoParaT));
					if (hvoParaT == hvoPara)
						break;
				}
			}
			ihvoP--;
			if (ihvoP < 0)
			{
				// At the beginning of the section. We can't look back any further.
				// ENHANCE TomB: If we search all the way through to the beginning of the
				// section and never get a valid reference, this section begins in the
				// middle of a verse or chapter (unlikely in the case of a verse, but
				// quite likely in the case of a chapter). OR (most likely) this edit happened
				// at the very beginning of the section, and when we start parsing, the first
				// thing we'll get is a decent reference.
				if (fGotVerse)
				{
					// Use the verse we got previously, along with the first chapter for
					// the section.
					int nChapterT, nVerseT;
					GetBCV(nBbCccVvvStart, nBook, nChapterT, nVerseT);
					nBbCccVvvStart = nBook * 1000000 + nChapterT * 1000 + nVerseStart;
					nBbCccVvvEnd = nBook * 1000000 + nChapterT * 1000 + nVerseEnd;
				}
				else
				{
					// For now, we're just using the first verse for the section, but this
					// could be wrong if the section begins in the middle of a verse bridge
					// or misleading if the section just doesn't yet have verse numbers marked.
					nBbCccVvvEnd = nBbCccVvvStart;
				}
				fGotVerse = fGotChapter = true;
			}
			else
			{
				if (qtssParaT != qtssPara)
				{
					CheckHr(qtssParaT->UnlockText(pchStartT));
				}
				CheckHr(m_qcvd->get_VecItem(hvoStTxt, kflidStText_Paragraphs, ihvoP,
					&hvoParaT));
				// get the contents.
				CheckHr(m_qcvd->get_StringProp(hvoParaT, kflidStTxtPara_Contents,
					&qtssParaT));
				CheckHr(qtssParaT->LockText(&pchStartT, &cch));
				pch = pchStartT + cch - 1;
			}
		}
		if (qtssParaT != qtssPara)
		{
			CheckHr(qtssParaT->UnlockText(pchStartT));
		}
	}

	bool fImporting = false;
	ParseParaAux(hvoPara, qtssPara, pchStart, ivMin, cvIns, nBbCccVvvStart,
		nBbCccVvvEnd, fImporting, cvDel, ihvoMin);
	// If we are in the Content of a section, update references for any Twfics following edited
	// portion of paragraph (this could include twfics in subsequemt paragraphs as well).
	if (nFlid == kflidScrSection_Content)
	{
		int nBook, nChapterStartStamp, nChapterEndStamp, nVerseStartStamp, nVerseEndStamp;
		GetBCV(nBbCccVvvStart, nBook, nChapterStartStamp, nVerseStartStamp);
		GetBCV(nBbCccVvvEnd, nBook, nChapterEndStamp, nVerseEndStamp);

		// Try to get the next TWFIC in this text. If none, we're all done.
		CheckHr(qode->CreateCommand(&qodc));
		stuSql.Format(L"exec GetNextScrTwficInText %d, %d, %d, ? output, ? output, ? output, "
			L"? output", hvoStTxt, hvoPara, ivMin + cvIns);

		HVO hvoParaForNextTwfic;
		int ichParaCharOffset;
		int nScrRefStartTwfic, nScrRefEndTwfic, nChapterStartTwfic, nChapterEndTwfic,
			nVerseStartTwfic, nVerseEndTwfic;
		ComBool fIsNull3, fIsNull4;

		qodc->SetParameter(1, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
			(ULONG *)&hvoParaForNextTwfic, sizeof(int));

		qodc->SetParameter(2, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
			(ULONG *)&ichParaCharOffset, sizeof(int));

		qodc->SetParameter(3, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
			(ULONG *)&nScrRefStartTwfic, sizeof(int));

		qodc->SetParameter(4, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
			(ULONG *)&nScrRefEndTwfic,	sizeof(int));

		// Actually execute the command.
		CheckHr(qodc->ExecCommand(stuSql.Bstr(), knSqlStmtNoResults));
		qodc->GetParameter(1, reinterpret_cast<ULONG *>(&hvoParaForNextTwfic),
			sizeof(int), &fIsNull1);
		qodc->GetParameter(2, reinterpret_cast<ULONG *>(&ichParaCharOffset),
			sizeof(int), &fIsNull2);
		qodc->GetParameter(3, reinterpret_cast<ULONG *>(&nScrRefStartTwfic),
			sizeof(int), &fIsNull3);
		qodc->GetParameter(4, reinterpret_cast<ULONG *>(&nScrRefEndTwfic),
			sizeof(int), &fIsNull4);
		if (!fIsNull1 && !fIsNull2 && !fIsNull3 && !fIsNull4)
		{
			GetBCV(nScrRefStartTwfic, nBook, nChapterStartTwfic, nVerseStartTwfic);
			GetBCV(nScrRefEndTwfic, nBook, nChapterEndTwfic, nVerseEndTwfic);

			HVO hvoParaT = hvoPara;
			// These two variables remember where to stop doing verse AND chapter stamping.
			HVO hvoParaEndOfVerseStamping;
			int ichLimEndOfVerseStamping;
			// Pointer to step through paragraph contents is initialized to beginning of the text
			// after the edited stuff.
			const OLECHAR * pchStartT = pchStart;
			const OLECHAR * pch = pchStart + ivMin + cvIns;
			ITsStringPtr qtssParaT = qtssPara; // paragraph contents
			int chvoParas = 0; // ENHANCE TomB: Could try to reuse data calculated up above.
			int ihvoP = 0;
			bool fDone = false; // Done searching; Don't need to stamp
			bool fStartStamping = false; // Done searching. Need to stamp some twfics
			bool fDoVerseAndChapterStamping = true; // Stamp some twfics new verse AND chapter
			bool fChapterNumsOnly = false; // Stamp some twfics using the new chapter # only
			bool fFoundTwfic = false; // We've gotten to the run containing the twfic, but need
				// to keep looking to find the ending spot.
			while (!fDone && !fStartStamping)
			{
				while (pch < pchLim)
				{
					// Get props of current run.
					CheckHr(qtssParaT->FetchRunInfoAt(pch - pchStartT, &tsi, &qttpRun));
					if (!fFoundTwfic && hvoParaT == hvoParaForNextTwfic &&
						tsi.ichLim > ichParaCharOffset)
					{
						fFoundTwfic = true;
					}
					else if (IfVerseNumberStyle(qttpRun))
					{
						// If pch is not at the start of the run, we've already accounted for
						// this verse number (in PPAux), so skip it and keep looking.
						if (pch == pchStartT + tsi.ichMin)
						{
							if (!fFoundTwfic)
							{
								// This is the case where we find a new verse number BEFORE we
								// get to the first post-edit TWFIC.

								// The whole run is the verse number.
								StrUni stuVerseNum(pchStartT + tsi.ichMin,
									tsi.ichLim - tsi.ichMin);
								ExtractVerseNums(stuVerseNum, nVerseStartStamp, nVerseEndStamp);
								if (nVerseStartStamp == nVerseStartTwfic &&
									nVerseEndStamp == nVerseEndTwfic)
								{
									// If the start/end chapter of the next TWFIC in the text
									// already matches the start/end "stamp" chapter, we're done.
									if (nChapterStartTwfic == nChapterStartStamp &&
										nChapterEndTwfic == nChapterEndStamp)
									{
										fDone = true;
										break;
									}
									else
									{
										// For stamping, we'll use the new chapter number, but
										// the existing TWFIC verse numbers. We aren't done,
										// because there could yet be a chapter number change
										// before we get to the TWFIC, in which case we
										// wouldn't want to stamp at all.
										fDoVerseAndChapterStamping = false;
										fChapterNumsOnly = true;
									}
								}
								nBbCccVvvStart = nBook * 1000000 + nChapterStartStamp * 1000 + nVerseStartStamp;
								nBbCccVvvEnd = nBook * 1000000 + nChapterEndStamp * 1000 + nVerseEndStamp;
							}
							else
							{
								// This is a verse number AFTER we've passed the first
								// post-edit TWFIC.
								// If the start/end chapter of the first post-edit TWFIC in the
								// text matched the start/end "stamp" chapter, we're done
								// searching, and can begin stamping twfics with new verse
								// and chapter numbers.
								if (!fChapterNumsOnly)
								{
									hvoParaEndOfVerseStamping = hvoParaT;
									ichLimEndOfVerseStamping = tsi.ichMin;
								}
								if (nChapterStartTwfic == nChapterStartStamp &&
									nChapterEndTwfic == nChapterEndStamp)
								{
									fStartStamping = true;
									break;
								}
								else
								{
									// For stamping, we'll use chapter AND verse numbers for
									// all TWFICS up to this point, but only the new chapter
									// number for TWFICS AFTER this point (until we hit a
									// chapter change).
									fChapterNumsOnly = true;
								}
							}
						}
					}
					// See if it is our chapter number style.
					else if (IfChapterNumberStyle(qttpRun))
					{
						// If pch is not at the start of the run, we've already accounted for
						// this chapter number (in PPAux), so skip it and keep looking.
						if (pch == pchStartT + tsi.ichMin)
						{
							if (!fFoundTwfic)
							{
								// This is the case where we find a new chapter number BEFORE
								// we get to the first post-edit TWFIC.
								fDone = true;
							}
							else
							{
								fStartStamping = true;
							}
							break;
						}
					}
					pch = pchStartT + tsi.ichLim;
				}
				if (fDone || fStartStamping)
					break;

				// We got to the end of the current paragraph and still haven't figured out the
				// the extent of the twfics that need stamping, so get the next paragraph.
				// ENHANCE TomB: If we load ord numbers for paragraphs, we can avoid this loop.
				if (chvoParas == 0)
				{
					CheckHr(m_qcvd->get_VecSize(hvoStTxt, kflidStText_Paragraphs,
						&chvoParas));
					// Go forward through vector of paragraphs to find the one being parsed
					for (; ihvoP < chvoParas; ihvoP++)
					{
						CheckHr(m_qcvd->get_VecItem(hvoStTxt, kflidStText_Paragraphs,
							ihvoP, &hvoParaT));
						if (hvoParaT == hvoPara)
							break;
					}
				}
				ihvoP++;
				if (ihvoP >= chvoParas)
				{
					// We've dealt with all the paragraphs in this text.
					// ENHANCE TomB: If we search all the way through to the end of the section and
					// don't find a valid stopping place, something may need to be done to "push"
					// the ending reference forward into the next section and/or we may want to
					// reset the ending reference for this section.
					if (fFoundTwfic)
					{
						if (fChapterNumsOnly)
						{
							// tsi.ichMin is expected to be the beginning of the first run that
							// does NOT get stamped, so fast-forward it.
							tsi.ichMin = tsi.ichLim;
						}
						else
						{
							hvoParaEndOfVerseStamping = hvoParaT;
							ichLimEndOfVerseStamping = tsi.ichLim;
						}
						fStartStamping = true;
					}
					else
					{
						Assert(fFoundTwfic);
						fDone = true;
					}
					break;
				}
				CheckHr(m_qcvd->get_VecItem(hvoStTxt, kflidStText_Paragraphs, ihvoP,
					&hvoParaT));
				if (qtssParaT != qtssPara)
				{
					CheckHr(qtssParaT->UnlockText(pchStartT));
				}
				CheckHr(m_qcvd->get_StringProp(hvoParaT, kflidStTxtPara_Contents,
					&qtssParaT));
				CheckHr(qtssParaT->LockText(&pchStartT, &cch));
				pch = pchStartT;
				pchLim = pchStartT + cch;
			}
			if (qtssParaT != qtssPara)
			{
				CheckHr(qtssParaT->UnlockText(pchStartT));
			}
			if (fStartStamping)
			{
				// We'd better be set up to do one or both kinds of stamping.
				Assert(fDoVerseAndChapterStamping || fChapterNumsOnly);
				// Call S'proc to stamp TWFICs
				CheckHr(qode->CreateCommand(&qodc));
				stuSql.Format(L"exec UpdateTwficScrRefs %d, %d, %d, %d, %d, %d, %d, %d",
					// References to use for stamping
					nBbCccVvvStart, nBbCccVvvEnd,
					// Paragraph and character offset where stamping should begin
					hvoParaForNextTwfic, ichParaCharOffset,
					// Paragraph (if any) and offset where V & C stamping should end
					fDoVerseAndChapterStamping? hvoParaEndOfVerseStamping : 0,
					ichLimEndOfVerseStamping,
					// Paragraph (if any) and offset where C-only stamping should end
					fChapterNumsOnly? hvoParaT : 0, tsi.ichMin);
				CheckHr(qodc->ExecCommand(stuSql.Bstr(), knSqlStmtStoredProcedure));
				CheckHr(qodc->GetRowset(0));
				ComBool fMoreRows;
				ULONG cbSpaceTaken;
				CheckHr(qodc->NextRow(&fMoreRows));
				HVO hvoTwficCur;
				int nT;
				// Process results to update cache.
				while (fMoreRows)
				{
					CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&hvoTwficCur),
						isizeof(HVO), &cbSpaceTaken, &fIsNull1, 0));
					Assert(hvoTwficCur);
					// Check to see if this TWFIC is loaded in the cache. This returns S_FALSE
					// if the property is not loaded.
					if (CheckHr(m_qcvd->get_IntProp(hvoTwficCur,
						kflidTxtWordformInContext_VerseRefStart, &nT)) == S_OK)
					{
						// If this TWFIC is in the cache, update it and notify all views.
						CheckHr(qodc->GetColValue(2, reinterpret_cast<ULONG *>(&nBbCccVvvStart),
							isizeof(int), &cbSpaceTaken, &fIsNull1, 0));
						// TODO TomB: Use 1001 instead of 1000 when we figure out how to mark
						// references for non-Scripture text.
						Assert(nBbCccVvvStart >= nBook * 1000000 + 1000);
						CheckHr(qodc->GetColValue(3, reinterpret_cast<ULONG *>(&nBbCccVvvEnd),
							isizeof(int), &cbSpaceTaken, &fIsNull1, 0));
						Assert(nBbCccVvvEnd >= nBook * 1000000 + 1000);
						CheckHr(m_qcvd->CacheIntProp(hvoTwficCur,
							kflidTxtWordformInContext_VerseRefStart, nBbCccVvvStart));
						CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, hvoTwficCur,
							kflidTxtWordformInContext_VerseRefStart, 0, 0, 0));
						CheckHr(m_qcvd->CacheIntProp(hvoTwficCur,
							kflidTxtWordformInContext_VerseRefEnd, nBbCccVvvEnd));
						CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, hvoTwficCur,
							kflidTxtWordformInContext_VerseRefEnd, 0, 0, 0));
					}
					CheckHr(qodc->NextRow(&fMoreRows));
				}
			}
		}
	}

	CheckHr(qtssPara->UnlockText(pchStart));
	// TODO TomB: Eventually, when the section focus changes, we'll have to alert the
	// user if any twfics are out of range based on the stored section reference. That
	// will NOT be done here, but I'm putting the TODO here anyway.

#ifdef DEBUG
	time(&finishParseStTxtPara);
	elapsedParseStTxtPara += difftime(finishParseStTxtPara, startParseStTxtPara);
#endif
}


/*----------------------------------------------------------------------------------------------
	This is the main routine for actually parsing an StTxtPara: identify the words and insert
	character offsets and references into the TxtWordformInContext table. This is a
	protected method intended for use by ParseNewStTxtPara and ParseStTxtPara.
	@param hvoPara HVO of paragraph to be parsed
	@param qtssPara paragraph contents
	@param pchStart pointer to first character in locked paragraph buffer.
	@param ichMin index of first inserted character. If this is in the middle of a word, parsing
		has to take this into account.
	@param cchParse number of characters inserted. This is the minimum number of characters to
		parse. Once we hit pchStart + ichMin + cchParse, we have to keep going until we hit the
		end of the current word.
	@param nBbCccVvvStart Start verse reference to be used for any text up to the first chapter/
		verse change.
	@param nBbCccVvvEnd End verse reference to be used for any text up to the first chapter/
		verse change.
	@param fImporting Optional hint to improve performance. Pass false if cache does
		not need to be updated with twfic information and PropChanged notifications should not
		be sent.
	@param cchDel number of characters deleted.
	@param ihvoTwfic 0-based index of first TextWordformIncontext to be inserted (we will
		increment this every time we add a new relationship in the parsing loop)
----------------------------------------------------------------------------------------------*/
void SeLpInfo::ParseParaAux(HVO hvoPara, ITsStringPtr qtssPara, const OLECHAR * pchStart,
							int ichMin, int cchParse, int &nBbCccVvvStart, int &nBbCccVvvEnd,
							bool fImporting, int ichDel, int ihvoTwfic)
{
	const OLECHAR * pchLim = pchStart + ichMin + cchParse;
	const OLECHAR * pchStartParse = pchStart;
	TsRunInfo tsi;
	ITsTextPropsPtr qttpRun;

	if (ichMin)
	{
		// When parsing only part of a paragraph, we can skip ahead to the beginning of the run
		// that contains the first inserted character (or the first character after the deleted
		// text, if no characters were inserted).
		CheckHr(qtssPara->FetchRunInfoAt(ichMin, &tsi, &qttpRun));
		// But if this is the very beginning of a run and characters were deleted, then we
		// need to back up to the previous run because characters may have been deleted there.
//		if (ichMin == tsi.ichMin && ichDel > 0)
		if (ichMin == tsi.ichMin)
		{
			CheckHr(qtssPara->FetchRunInfoAt(ichMin - 1, &tsi, &qttpRun));
		}
		pchStartParse += tsi.ichMin;
	}

	// Now we will look for sequences of word-forming characters.
	// TODO TomB: We need to limit the concordance to text in a particular writing system
	const OLECHAR * pchStartWord = pchStartParse;
	bool fPrevCharInWord = false; // 1st char in run is potentially the start of a word
	tsi.ichLim = -1; // Force initial read of props for first char

	// Make an entry in TxtWordformInContext for each word in paragraph
	for (const OLECHAR * pch = pchStartParse; pch <= pchLim || fPrevCharInWord; pch++)
	{
		// If we're at the start of a run of text, get its properties. If it's a "special" run,
		// we will process it as a single element, and we may come back around. If it's normal
		// text, we'll fall out of this loop and let the outside for loop handle character-by-
		// character processing.
		while (pch - pchStart >= tsi.ichLim)
		{
			// Get props of current run.
			CheckHr(qtssPara->FetchRunInfoAt(pch - pchStart, &tsi, &qttpRun));
			// TODO TomB: Finish this if-statement to determine if the new run can legitimately
			// continue a word in a previous run. If the language changes, we have to regard it
			// as a word break (and add a twfic for previous word if needed -- though normally
			// we would expect whitespace). Potentially, some style changes may be able to
			// occur mid-word; we'll have to see...
			if (fPrevCharInWord /* && this run-break amounts to a word-break */ )
			{
				// Now add this word to the WFI if needed, and also create Twfic.
				StrUni stuWord(pchStartWord, pch - pchStartWord);
				AddWordformInContext(stuWord, hvoPara,
					pchStartWord - pchStart /* offset */, nBbCccVvvStart, nBbCccVvvEnd,
					ihvoTwfic++ /* ord */, (ichMin == 0)? true : false /* at para end */,
					fImporting);
				fPrevCharInWord = false; // 1st char in run is potentially the start of a word
			}
			// See if it is our verse number style.
			if (IfVerseNumberStyle(qttpRun))
			{
				// Assume the whole run is the verse number
				StrUni stuVerseNum(pch, tsi.ichLim - tsi.ichMin);
				int nVerseStart, nVerseEnd;
				ExtractVerseNums(stuVerseNum, nVerseStart, nVerseEnd);
				nBbCccVvvStart = ((nBbCccVvvStart / 1000) * 1000) + nVerseStart;
				nBbCccVvvEnd = ((nBbCccVvvEnd / 1000) * 1000) + nVerseEnd;
				pch += stuVerseNum.Length();
				// Check for unusual case where paragraph ends with a verse number (this should
				// not happen with finished Scriptures, but it can happen with work in
				// progress).
				if (pch > pchLim || *pch == 0)
					return;
			}
			else if (IfChapterNumberStyle(qttpRun)) // See if it is our chapter number style.
			{
				// Assume the whole run is the chapter number
				StrUni stuChapterNum(pch, tsi.ichLim - tsi.ichMin);
				int nBook, nChapterT, nVerseStart, nVerseEnd;
				GetBCV(nBbCccVvvStart, nBook, nChapterT, nVerseStart);
				GetBCV(nBbCccVvvEnd, nBook, nChapterT, nVerseEnd);
				ExtractChapterNum(stuChapterNum, nChapterT);
				// REVIEW TomB: What if we get nChapterT == 0? For now, let's pretend
				// we didn't see a chapter number style at all and just keep looking.
				if (nChapterT)
				{
					// The '1' is the first verse following a chapter number
					nBbCccVvvStart = nBook * 1000000 + nChapterT * 1000 + 1;
					nBbCccVvvEnd = nBook * 1000000 + nChapterT * 1000 + 1;
				}
				pch += stuChapterNum.Length();
				// Check for unusual case where paragraph ends with a chapter number (this
				// should not happen with finished Scriptures, but it can happen with work in
				// progress).
				if (pch > pchLim || *pch == 0)
					return;
			}
			else
				break;
		}
		ComBool fWordForming;
		CheckHr(m_qcpeVern->get_IsLetter(*pch, &fWordForming));
		if (fWordForming)
		{
			if (!fPrevCharInWord)
			{
				pchStartWord = pch;
				fPrevCharInWord = true;
			}
		}
		else
		{
			if (fPrevCharInWord)
			{
				// We have a Word! It is from pchStartWord to pch. Length is: pch - pchStartWord
				// If its end is before the beginning of the edited portion, do nothing.
				if (pch >= pchStart + ichMin)
				{
					// Now add this word to the WFI if needed, and also create Twfic.
					StrUni stuWord(pchStartWord, pch - pchStartWord);
					AddWordformInContext(stuWord, hvoPara,
						pchStartWord - pchStart /* offset */, nBbCccVvvStart, nBbCccVvvEnd,
						ihvoTwfic++ /* ord */, (ichMin == 0)? true : false /* at para end */,
						fImporting);
				}
				fPrevCharInWord = false;
			}
		}
	}

	// If paragraph ends in a word (not followed by spaces or punctuation), add it
	if (fPrevCharInWord)
	{
		StrUni stuWord(pchStartWord, pch - pchStartWord);
		AddWordformInContext(stuWord, hvoPara, pchStartWord - pchStart /* offset */,
			nBbCccVvvStart, nBbCccVvvEnd, ihvoTwfic /* ord */,
			(ichMin == 0)? true : false /* at para end */, fImporting);
	}
}

/*----------------------------------------------------------------------------------------------
	Add WordformInContext to DB.
	@param stuWord parsed word
	@param hvoPara HVO of paragraph being parsed
	@param iOffset character offset where word occurs in paragraph
	@param nVerseRefStart Starting verse reference for this occurrence of this word.
	@param nVerseRefEnd Ending verse reference for this occurrence of this word (will be
		different from starting ref if it occurs in a bridge or section head section body that
		has not been broken into verses.
	@param iOrd 0-based index of where this word fits in the sequence of words in paragraph. To
		insert at the end of the paragraph, pass the Lim for the vector of twfics for this para.
	@param fAtParaEnd Optional hint to improve performance. Pass true if caller can guarantee
		that insertion is at end of paragraph (i.e., iOrd = Lim).
	@param fImporting Optional hint to improve performance. Pass false if cache does
		not need to be updated with twfic information and PropChanged notifications should not
		be sent.
----------------------------------------------------------------------------------------------*/
void SeLpInfo::AddWordformInContext(StrUni stuWord, HVO hvoPara, int iOffset,
	int nVerseRefStart, int nVerseRefEnd, int iOrd, bool fAtParaEnd, bool fImporting)
{
	HVO hvoWfiWordform;

	ITsStringPtr qtssWord;
	CheckHr(m_qtsf->MakeString(stuWord.Bstr(), m_vwsVern[0], &qtssWord));

	IOleDbEncapPtr qode	= m_qcvd->GetOleDbEncap();
	IOleDbCommandPtr qodc;
	StrUni stuSql;
	CheckHr(qode->CreateCommand(&qodc));

	// TODO: This logic needs to take into consideration the rules for dealing with case.
	// For now, we're just storing each different casing as a separate wordform.
	if (m_hmstuhvoWordforms.Retrieve(stuWord, &hvoWfiWordform))
	{
		int cTwfic;
		CheckHr(m_qcvd->get_IntProp(hvoWfiWordform, ktagWfiWordform_TwficCount, &cTwfic));
		CheckHr(m_qcvd->CacheIntProp(hvoWfiWordform, ktagWfiWordform_TwficCount, cTwfic + 1));
	}
	else
	{
		// This word we do not have loaded in memory. Add it or retrieve its HVO from DB.
		// Form the SQL query, set the parameters, and execute the command.
		stuSql.Format(L"exec CreateObj_WfiWordForm %d, '%s', %d, ? output, ? output",
			m_hvoWfi, stuWord.Chars(), m_vwsVern[0]);
		qodc->SetParameter(1, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
			(ULONG *)&hvoWfiWordform,	sizeof(HVO));
		int nSpellingStatus = 0;
		qodc->SetParameter(2, DBPARAMFLAGS_ISOUTPUT | DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_UI1,
			(ULONG *)&nSpellingStatus,	sizeof(int));

		// Actually execute the command.
#ifdef DEBUG
		time(&startMakeWordforms);
#endif
		CheckHr(qodc->ExecCommand(stuSql.Bstr(), knSqlStmtNoResults));
		ComBool fIsNull;
		qodc->GetParameter(1, reinterpret_cast<ULONG *>(&hvoWfiWordform), sizeof(HVO), &fIsNull);
		// REVIEW JohnT (TomB): what should we do if we don't get a valid HVO?
		if (!hvoWfiWordform)
			throw;
		qodc->GetParameter(2, reinterpret_cast<ULONG *>(&nSpellingStatus), sizeof(int), &fIsNull);

		CheckHr(m_qcvd->CacheReplace(m_hvoWfi, kflidWordformInventory_Wordforms, 0, 0,
			&hvoWfiWordform, 1)); // Make this appear to be an array (of one hvo).
		CheckHr(m_qcvd->CacheStringAlt(hvoWfiWordform, kflidWfiWordform_Form, m_vwsVern[0],
			qtssWord));
		CheckHr(m_qcvd->CacheIntProp(hvoWfiWordform, ktagWfiWordform_TwficCount, 1));
		CheckHr(m_qcvd->CacheIntProp(hvoWfiWordform, kflidWfiWordform_SpellingStatus,
			nSpellingStatus));

		// TODO BryanW: when sorted, the PropChanged needs to indicate the correct position.
		if (!fImporting)
		{
			CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, m_hvoWfi,
				kflidWordformInventory_Wordforms, 0, 1, 0));
		}
#ifdef DEBUG
		time(&finishMakeWordforms);
		elapsedMakeWordforms += difftime(finishMakeWordforms, startMakeWordforms);
#endif
		// Also add it to our map (StrUni->HVO)
		m_hmstuhvoWordforms.Insert(stuWord, hvoWfiWordform);
	}

	// Now add the relationship between StTxtPara and AnalyzedTextObjects
	// with the character offset and Scripture reference.
#ifdef DEBUG
	time(&startMakeTxtWfInContext);
#endif
	HVO hvoTWfic;

	// Form the SQL query, set the parameters, and execute the command.
	stuSql.Format(L"exec CreateObj_TxtWordFormInContext %d, %d, '%s', ?, %d, %d, %d, %d, ? output",
		hvoPara, hvoWfiWordform, stuWord.Chars(), iOffset, nVerseRefStart, nVerseRefEnd, iOrd + 1);
	// When importing, we always parse from beginning to end of paragraph, so we're always inserting at
	// the end of sequence of twfics. So we can pass an optional flag to tell the stored procedure not
	// to bother to look for trailing twfics whose Ord numbers might need to be incremented.
	if (fAtParaEnd)
		stuSql.Append(L", 1");
	qodc->SetParameter(1, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_BYTES,
			reinterpret_cast<ULONG *>(m_rgbVernFmt), m_cbVernFmt);
	qodc->SetParameter(2, DBPARAMFLAGS_ISOUTPUT, NULL, DBTYPE_I4,
		(ULONG *)&hvoTWfic,	sizeof(HVO));

	// Actually execute the command.
	CheckHr(qodc->ExecCommand(stuSql.Bstr(), knSqlStmtNoResults));
	ComBool fIsNull;
	qodc->GetParameter(2, reinterpret_cast<ULONG *>(&hvoTWfic), sizeof(HVO), &fIsNull);
	// REVIEW JohnT (TomB): what should we do if we don't get a valid HVO?
	if (!hvoTWfic)
		throw;

	if (!fImporting)
	{
		CheckHr(m_qcvd->CacheReplace(hvoPara, kflidStTxtPara_AnalyzedTextObjects,
			iOrd, iOrd, // Insert into sequence at this position.
			&hvoTWfic, // Make this appear to be an array (of one hvo).
			1));
		CheckHr(m_qcvd->CacheStringProp(hvoTWfic, kflidTxtWordformInContext_Form, qtssWord));
		CheckHr(m_qcvd->CacheObjProp(hvoTWfic, kflidTxtWordformInContext_Analysis,
			hvoWfiWordform));
		CheckHr(m_qcvd->CacheIntProp(hvoTWfic, kflidTxtWordformInContext_ParaCharOffset, iOffset));
		CheckHr(m_qcvd->CacheIntProp(hvoTWfic, kflidTxtWordformInContext_VerseRefStart,
			nVerseRefStart));
		CheckHr(m_qcvd->CacheIntProp(hvoTWfic, kflidTxtWordformInContext_VerseRefEnd,
			nVerseRefEnd));

		// ENHANCE TomB (JohnT): we might make a somewhat more automatic way to get the back-ref
		// updated.
		CheckHr(m_qcvd->CacheReplace(hvoWfiWordform, kflidTxtWordformInContext_Analysis,
			0, 0, // Insert into sequence at this position.
			&hvoTWfic, // Make this appear to be an array (of one hvo).
			1));
		CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, hvoWfiWordform, kflidTxtWordformInContext_Analysis, 0, 1, 0));
		CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, hvoWfiWordform, ktagWfiWordform_TwficCount, 0, 0, 0));
	}


#ifdef DEBUG
	time(&finishMakeTxtWfInContext);
	elapsedMakeTxtWfInContext += difftime(finishMakeTxtWfInContext, startMakeTxtWfInContext);
#endif

}

/*----------------------------------------------------------------------------------------------
	Return true if the given text props use the verse number named style
----------------------------------------------------------------------------------------------*/
bool SeLpInfo::IfVerseNumberStyle(ITsTextProps * pttp)
{
	SmartBstr sbstrStyle;
	CheckHr(pttp->GetStrPropValue(kspNamedStyle, &sbstrStyle));
	if (!wcscmp(sbstrStyle.Chars(), GetVerseNumberStyleName()))
		return true;
	return false;
}

/*----------------------------------------------------------------------------------------------
	Return true if the given text props use the chapter number named style
----------------------------------------------------------------------------------------------*/
bool SeLpInfo::IfChapterNumberStyle(ITsTextProps * pttp)
{
	SmartBstr sbstrStyle;
	CheckHr(pttp->GetStrPropValue(kspNamedStyle, &sbstrStyle));
	if (!wcscmp(sbstrStyle.Chars(), GetChapterNumberStyleName()))
		return true;
	return false;
}


/***********************************************************************************************
	ScriptRefDlg methods.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Handle a WM_NOTIFY message.

	@param id Identifies the control sending the message.
	@param pnmh Pointer to the notification message data.
	@param lnRet Reference to a long integer return value used by some messages.

	@return True if the message is handled successfully; otherwise, false.
----------------------------------------------------------------------------------------------*/
bool ScriptRefDlg::OnNotifyChild(int id, NMHDR * pnmh, long & lnRet)
{
	if (pnmh->code == EN_CHANGE)
	{
		achar rgch[100];
		memset(rgch, 0, 100 * sizeof(achar));
		::GetDlgItemText(m_hwnd, pnmh->idFrom, rgch, 100);
		StrAnsi sta(rgch);
		switch( pnmh->idFrom)
		{
		case kctidScriptStartRef:
			m_strStartRef = sta;
			break;
		case kctidScriptEndRef:
			m_strEndRef = sta;
			break;
		}
	}
	return SuperClass::OnNotifyChild(id, pnmh, lnRet);
}

void ScriptRefDlg::SetInitRef(StrApp strStartRef, StrApp strEndRef)
{
	m_strStartRef = strStartRef;
	m_strEndRef = strEndRef;
}

/*----------------------------------------------------------------------------------------------
    Called by the framework to initialize the dialog. All one-time initialization should be
    done here (that is, all controls have been created and have valid hwnd's, but they
    need initial values.)

	See ${AfDialog#FWndProc}
	@param hwndCtrl (not used)
	@param lp (not used)
	@return true
----------------------------------------------------------------------------------------------*/
bool ScriptRefDlg::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	::SetDlgItemText(m_hwnd, kctidScriptStartRef, m_strStartRef.Chars());
	::SetDlgItemText(m_hwnd, kctidScriptEndRef, m_strEndRef.Chars());
	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

// Explicit instantiation
#include <HashMap_i.cpp>
template HashMapStrUni<HVO>; // MapStrHvo; // Hungarian: hmstuhvo
template Vector<ITsTextPropsPtr>;



/*----------------------------------------------------------------------------------------------
	Creates a new window of this type (called by the CmdWndNew command.)

	@return pointer to the new window
----------------------------------------------------------------------------------------------*/
void SeMainWnd::NewWindow(RecMainWnd ** ppmwnd)
{
	WndCreateStruct wcs;
	wcs.InitMain(_T("SeMainWnd"));
    SeMainWndPtr qwnd;
	qwnd.Create();
	qwnd->Init(m_qlpi);
	qwnd->CreateHwnd(wcs);
	*ppmwnd = qwnd.Detach();
}
