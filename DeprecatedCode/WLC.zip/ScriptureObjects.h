/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Sep 03 10:42:10 2002
 */
/* Compiler settings for ScriptureObjects.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ScriptureObjects_h__
#define __ScriptureObjects_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ISCReference_FWD_DEFINED__
#define __ISCReference_FWD_DEFINED__
typedef interface ISCReference ISCReference;
#endif 	/* __ISCReference_FWD_DEFINED__ */


#ifndef __ISCReferenceCollection_FWD_DEFINED__
#define __ISCReferenceCollection_FWD_DEFINED__
typedef interface ISCReferenceCollection ISCReferenceCollection;
#endif 	/* __ISCReferenceCollection_FWD_DEFINED__ */


#ifndef __ISCTag_FWD_DEFINED__
#define __ISCTag_FWD_DEFINED__
typedef interface ISCTag ISCTag;
#endif 	/* __ISCTag_FWD_DEFINED__ */


#ifndef __ISCTextSegment_FWD_DEFINED__
#define __ISCTextSegment_FWD_DEFINED__
typedef interface ISCTextSegment ISCTextSegment;
#endif 	/* __ISCTextSegment_FWD_DEFINED__ */


#ifndef __ISCTextEnum_FWD_DEFINED__
#define __ISCTextEnum_FWD_DEFINED__
typedef interface ISCTextEnum ISCTextEnum;
#endif 	/* __ISCTextEnum_FWD_DEFINED__ */


#ifndef __ISCScriptureText_FWD_DEFINED__
#define __ISCScriptureText_FWD_DEFINED__
typedef interface ISCScriptureText ISCScriptureText;
#endif 	/* __ISCScriptureText_FWD_DEFINED__ */


#ifndef __ISCScriptureText2_FWD_DEFINED__
#define __ISCScriptureText2_FWD_DEFINED__
typedef interface ISCScriptureText2 ISCScriptureText2;
#endif 	/* __ISCScriptureText2_FWD_DEFINED__ */


#ifndef __SCReferenceCollection_FWD_DEFINED__
#define __SCReferenceCollection_FWD_DEFINED__

#ifdef __cplusplus
typedef class SCReferenceCollection SCReferenceCollection;
#else
typedef struct SCReferenceCollection SCReferenceCollection;
#endif /* __cplusplus */

#endif 	/* __SCReferenceCollection_FWD_DEFINED__ */


#ifndef __SCReference_FWD_DEFINED__
#define __SCReference_FWD_DEFINED__

#ifdef __cplusplus
typedef class SCReference SCReference;
#else
typedef struct SCReference SCReference;
#endif /* __cplusplus */

#endif 	/* __SCReference_FWD_DEFINED__ */


#ifndef __SCTag_FWD_DEFINED__
#define __SCTag_FWD_DEFINED__

#ifdef __cplusplus
typedef class SCTag SCTag;
#else
typedef struct SCTag SCTag;
#endif /* __cplusplus */

#endif 	/* __SCTag_FWD_DEFINED__ */


#ifndef __SCTextSegment_FWD_DEFINED__
#define __SCTextSegment_FWD_DEFINED__

#ifdef __cplusplus
typedef class SCTextSegment SCTextSegment;
#else
typedef struct SCTextSegment SCTextSegment;
#endif /* __cplusplus */

#endif 	/* __SCTextSegment_FWD_DEFINED__ */


#ifndef __SCTextEnum_FWD_DEFINED__
#define __SCTextEnum_FWD_DEFINED__

#ifdef __cplusplus
typedef class SCTextEnum SCTextEnum;
#else
typedef struct SCTextEnum SCTextEnum;
#endif /* __cplusplus */

#endif 	/* __SCTextEnum_FWD_DEFINED__ */


#ifndef __SCScriptureText_FWD_DEFINED__
#define __SCScriptureText_FWD_DEFINED__

#ifdef __cplusplus
typedef class SCScriptureText SCScriptureText;
#else
typedef struct SCScriptureText SCScriptureText;
#endif /* __cplusplus */

#endif 	/* __SCScriptureText_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_ScriptureObjects_0000 */
/* [local] */ 


typedef /* [public][public][public][public][public][public][uuid] */ 
enum __MIDL___MIDL_itf_ScriptureObjects_0000_0001
    {	scUnknown	= 0,
	scOriginal	= 1,
	scSeptuagint	= 2,
	scVulgate	= 3,
	scEnglish	= 4,
	scCustom	= 5
    }	SCVersification;

typedef /* [public][public][public][public][public][public][uuid] */ 
enum __MIDL___MIDL_itf_ScriptureObjects_0000_0002
    {	scTitle	= 1,
	scSection	= 2,
	scVerseText	= 4,
	scNoteText	= 8,
	scOther	= 16,
	scBackTranslation	= 32,
	scTranslationNote	= 64
    }	SCTextType;

typedef /* [public][public][public][public][public][public][uuid] */ 
enum __MIDL___MIDL_itf_ScriptureObjects_0000_0003
    {	scVerse	= 1,
	scChapter	= 2,
	scParagraph	= 4,
	scPublishable	= 8,
	scVernacular	= 16,
	scPoetic	= 32,
	scOtherTextBegin	= 64,
	scOtherTextEnd	= 128,
	scLevel_1	= 256,
	scLevel_2	= 512,
	scLevel_3	= 1024,
	scLevel_4	= 2048,
	scLevel_5	= 4096,
	scCrossReference	= 8192,
	scNonpublishable	= 16384,
	scNonvernacular	= 32768,
	scBook	= 2 * 32768,
	scNote	= 4 * 32768
    }	SCTextProperties;

typedef /* [public][public][public][uuid] */ 
enum __MIDL___MIDL_itf_ScriptureObjects_0000_0004
    {	scUnknownStyle	= 0,
	scCharacterStyle	= 1,
	scNoteStyle	= 2,
	scParagraphStyle	= 3,
	scEndStyle	= 4
    }	SCStyleType;

typedef /* [public][public][public][uuid] */ 
enum __MIDL___MIDL_itf_ScriptureObjects_0000_0005
    {	scLeft	= 1,
	scCenter	= 2,
	scRight	= 3,
	scBoth	= 4
    }	SCJustificationType;



extern RPC_IF_HANDLE __MIDL_itf_ScriptureObjects_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_ScriptureObjects_0000_v0_0_s_ifspec;

#ifndef __ISCReference_INTERFACE_DEFINED__
#define __ISCReference_INTERFACE_DEFINED__

/* interface ISCReference */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISCReference;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F916A2F0-D58C-11D2-A1CE-00C0DFEC0B1A")
    ISCReference : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Book( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Book( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Chapter( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Chapter( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Verse( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Verse( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Segment( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Segment( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_LastBook( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_LastChapter( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_LastVerse( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Parse( 
            /* [in] */ BSTR val) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NextVerse( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE PreviousVerse( void) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_AsString( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_VersificationsPresent( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Versification( 
            /* [retval][out] */ SCVersification __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Versification( 
            /* [in] */ SCVersification newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Valid( 
            /* [retval][out] */ BOOL __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ChangeVersification( 
            /* [in] */ SCVersification NewVersification) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_BBCCCVVV( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetToEnd( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISCReferenceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISCReference __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISCReference __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISCReference __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Book )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Book )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Chapter )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Chapter )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Verse )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Verse )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Segment )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Segment )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LastBook )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LastChapter )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LastVerse )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Parse )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ BSTR val);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NextVerse )( 
            ISCReference __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PreviousVerse )( 
            ISCReference __RPC_FAR * This);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AsString )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_VersificationsPresent )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Versification )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ SCVersification __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Versification )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ SCVersification newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Valid )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ChangeVersification )( 
            ISCReference __RPC_FAR * This,
            /* [in] */ SCVersification NewVersification);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BBCCCVVV )( 
            ISCReference __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetToEnd )( 
            ISCReference __RPC_FAR * This);
        
        END_INTERFACE
    } ISCReferenceVtbl;

    interface ISCReference
    {
        CONST_VTBL struct ISCReferenceVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISCReference_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISCReference_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISCReference_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISCReference_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISCReference_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISCReference_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISCReference_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISCReference_get_Book(This,pVal)	\
    (This)->lpVtbl -> get_Book(This,pVal)

#define ISCReference_put_Book(This,newVal)	\
    (This)->lpVtbl -> put_Book(This,newVal)

#define ISCReference_get_Chapter(This,pVal)	\
    (This)->lpVtbl -> get_Chapter(This,pVal)

#define ISCReference_put_Chapter(This,newVal)	\
    (This)->lpVtbl -> put_Chapter(This,newVal)

#define ISCReference_get_Verse(This,pVal)	\
    (This)->lpVtbl -> get_Verse(This,pVal)

#define ISCReference_put_Verse(This,newVal)	\
    (This)->lpVtbl -> put_Verse(This,newVal)

#define ISCReference_get_Segment(This,pVal)	\
    (This)->lpVtbl -> get_Segment(This,pVal)

#define ISCReference_put_Segment(This,newVal)	\
    (This)->lpVtbl -> put_Segment(This,newVal)

#define ISCReference_get_LastBook(This,pVal)	\
    (This)->lpVtbl -> get_LastBook(This,pVal)

#define ISCReference_get_LastChapter(This,pVal)	\
    (This)->lpVtbl -> get_LastChapter(This,pVal)

#define ISCReference_get_LastVerse(This,pVal)	\
    (This)->lpVtbl -> get_LastVerse(This,pVal)

#define ISCReference_Parse(This,val)	\
    (This)->lpVtbl -> Parse(This,val)

#define ISCReference_NextVerse(This)	\
    (This)->lpVtbl -> NextVerse(This)

#define ISCReference_PreviousVerse(This)	\
    (This)->lpVtbl -> PreviousVerse(This)

#define ISCReference_get_AsString(This,pVal)	\
    (This)->lpVtbl -> get_AsString(This,pVal)

#define ISCReference_get_VersificationsPresent(This,pVal)	\
    (This)->lpVtbl -> get_VersificationsPresent(This,pVal)

#define ISCReference_get_Versification(This,pVal)	\
    (This)->lpVtbl -> get_Versification(This,pVal)

#define ISCReference_put_Versification(This,newVal)	\
    (This)->lpVtbl -> put_Versification(This,newVal)

#define ISCReference_get_Valid(This,pVal)	\
    (This)->lpVtbl -> get_Valid(This,pVal)

#define ISCReference_ChangeVersification(This,NewVersification)	\
    (This)->lpVtbl -> ChangeVersification(This,NewVersification)

#define ISCReference_get_BBCCCVVV(This,pVal)	\
    (This)->lpVtbl -> get_BBCCCVVV(This,pVal)

#define ISCReference_SetToEnd(This)	\
    (This)->lpVtbl -> SetToEnd(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_Book_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_Book_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCReference_put_Book_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB ISCReference_put_Book_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_Chapter_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_Chapter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCReference_put_Chapter_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB ISCReference_put_Chapter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_Verse_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_Verse_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCReference_put_Verse_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB ISCReference_put_Verse_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_Segment_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_Segment_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCReference_put_Segment_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB ISCReference_put_Segment_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_LastBook_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_LastBook_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_LastChapter_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_LastChapter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_LastVerse_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_LastVerse_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReference_Parse_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [in] */ BSTR val);


void __RPC_STUB ISCReference_Parse_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReference_NextVerse_Proxy( 
    ISCReference __RPC_FAR * This);


void __RPC_STUB ISCReference_NextVerse_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReference_PreviousVerse_Proxy( 
    ISCReference __RPC_FAR * This);


void __RPC_STUB ISCReference_PreviousVerse_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_AsString_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_AsString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_VersificationsPresent_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_VersificationsPresent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_Versification_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ SCVersification __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_Versification_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCReference_put_Versification_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [in] */ SCVersification newVal);


void __RPC_STUB ISCReference_put_Versification_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_Valid_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_Valid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReference_ChangeVersification_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [in] */ SCVersification NewVersification);


void __RPC_STUB ISCReference_ChangeVersification_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReference_get_BBCCCVVV_Proxy( 
    ISCReference __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ISCReference_get_BBCCCVVV_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReference_SetToEnd_Proxy( 
    ISCReference __RPC_FAR * This);


void __RPC_STUB ISCReference_SetToEnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISCReference_INTERFACE_DEFINED__ */


#ifndef __ISCReferenceCollection_INTERFACE_DEFINED__
#define __ISCReferenceCollection_INTERFACE_DEFINED__

/* interface ISCReferenceCollection */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISCReferenceCollection;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("37A896E1-D56F-11D2-A1CE-00C0DFEC0B1A")
    ISCReferenceCollection : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Item( 
            /* [in] */ long index,
            /* [retval][out] */ LPVARIANT pItem) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Parse( 
            /* [in] */ BSTR bstrReferences,
            /* [in] */ BSTR bstrCommentCharacter) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_AsString( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Add( 
            /* [in] */ ISCReference __RPC_FAR *pSCReference) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Insert( 
            /* [in] */ ISCReference __RPC_FAR *pSCReference) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Remove( 
            /* [in] */ long index) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Includes( 
            /* [in] */ ISCReference __RPC_FAR *pSCReference,
            /* [retval][out] */ BOOL __RPC_FAR *fVal) = 0;
        
        virtual /* [restricted][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ LPUNKNOWN __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISCReferenceCollectionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISCReferenceCollection __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISCReferenceCollection __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Count )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Item )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ long index,
            /* [retval][out] */ LPVARIANT pItem);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Parse )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ BSTR bstrReferences,
            /* [in] */ BSTR bstrCommentCharacter);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AsString )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Add )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReference);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Insert )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReference);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Remove )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ long index);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Includes )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReference,
            /* [retval][out] */ BOOL __RPC_FAR *fVal);
        
        /* [restricted][helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get__NewEnum )( 
            ISCReferenceCollection __RPC_FAR * This,
            /* [retval][out] */ LPUNKNOWN __RPC_FAR *pVal);
        
        END_INTERFACE
    } ISCReferenceCollectionVtbl;

    interface ISCReferenceCollection
    {
        CONST_VTBL struct ISCReferenceCollectionVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISCReferenceCollection_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISCReferenceCollection_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISCReferenceCollection_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISCReferenceCollection_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISCReferenceCollection_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISCReferenceCollection_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISCReferenceCollection_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISCReferenceCollection_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define ISCReferenceCollection_Item(This,index,pItem)	\
    (This)->lpVtbl -> Item(This,index,pItem)

#define ISCReferenceCollection_Parse(This,bstrReferences,bstrCommentCharacter)	\
    (This)->lpVtbl -> Parse(This,bstrReferences,bstrCommentCharacter)

#define ISCReferenceCollection_get_AsString(This,pVal)	\
    (This)->lpVtbl -> get_AsString(This,pVal)

#define ISCReferenceCollection_Add(This,pSCReference)	\
    (This)->lpVtbl -> Add(This,pSCReference)

#define ISCReferenceCollection_Insert(This,pSCReference)	\
    (This)->lpVtbl -> Insert(This,pSCReference)

#define ISCReferenceCollection_Remove(This,index)	\
    (This)->lpVtbl -> Remove(This,index)

#define ISCReferenceCollection_Includes(This,pSCReference,fVal)	\
    (This)->lpVtbl -> Includes(This,pSCReference,fVal)

#define ISCReferenceCollection_get__NewEnum(This,pVal)	\
    (This)->lpVtbl -> get__NewEnum(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReferenceCollection_get_Count_Proxy( 
    ISCReferenceCollection __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ISCReferenceCollection_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReferenceCollection_Item_Proxy( 
    ISCReferenceCollection __RPC_FAR * This,
    /* [in] */ long index,
    /* [retval][out] */ LPVARIANT pItem);


void __RPC_STUB ISCReferenceCollection_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReferenceCollection_Parse_Proxy( 
    ISCReferenceCollection __RPC_FAR * This,
    /* [in] */ BSTR bstrReferences,
    /* [in] */ BSTR bstrCommentCharacter);


void __RPC_STUB ISCReferenceCollection_Parse_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCReferenceCollection_get_AsString_Proxy( 
    ISCReferenceCollection __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ISCReferenceCollection_get_AsString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReferenceCollection_Add_Proxy( 
    ISCReferenceCollection __RPC_FAR * This,
    /* [in] */ ISCReference __RPC_FAR *pSCReference);


void __RPC_STUB ISCReferenceCollection_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReferenceCollection_Insert_Proxy( 
    ISCReferenceCollection __RPC_FAR * This,
    /* [in] */ ISCReference __RPC_FAR *pSCReference);


void __RPC_STUB ISCReferenceCollection_Insert_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReferenceCollection_Remove_Proxy( 
    ISCReferenceCollection __RPC_FAR * This,
    /* [in] */ long index);


void __RPC_STUB ISCReferenceCollection_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCReferenceCollection_Includes_Proxy( 
    ISCReferenceCollection __RPC_FAR * This,
    /* [in] */ ISCReference __RPC_FAR *pSCReference,
    /* [retval][out] */ BOOL __RPC_FAR *fVal);


void __RPC_STUB ISCReferenceCollection_Includes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [restricted][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISCReferenceCollection_get__NewEnum_Proxy( 
    ISCReferenceCollection __RPC_FAR * This,
    /* [retval][out] */ LPUNKNOWN __RPC_FAR *pVal);


void __RPC_STUB ISCReferenceCollection_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISCReferenceCollection_INTERFACE_DEFINED__ */


#ifndef __ISCTag_INTERFACE_DEFINED__
#define __ISCTag_INTERFACE_DEFINED__

/* interface ISCTag */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISCTag;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("20AA6890-F664-11D2-A1CF-00C0DFEC0B1A")
    ISCTag : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Bold( 
            /* [retval][out] */ BOOL __RPC_FAR *pfVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Bold( 
            /* [in] */ BOOL fVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Color( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Color( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Description( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Description( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Endmarker( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Endmarker( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FirstLineIndent( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FirstLineIndent( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Fontname( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Fontname( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FontSize( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FontSize( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Italic( 
            /* [retval][out] */ BOOL __RPC_FAR *pfVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Italic( 
            /* [in] */ BOOL fVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_JustificationType( 
            /* [retval][out] */ SCJustificationType __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_JustificationType( 
            /* [in] */ SCJustificationType newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_LeftMargin( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_LeftMargin( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_LineSpacing( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_LineSpacing( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Marker( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Marker( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Name( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_NotRepeatable( 
            /* [retval][out] */ BOOL __RPC_FAR *pfVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_NotRepeatable( 
            /* [in] */ BOOL fVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_OccursUnder( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_OccursUnder( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Rank( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Rank( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_RightMargin( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_RightMargin( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_SpaceAfter( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_SpaceAfter( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_SpaceBefore( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_SpaceBefore( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_StyleType( 
            /* [retval][out] */ SCStyleType __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_StyleType( 
            /* [in] */ SCStyleType newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Superscript( 
            /* [retval][out] */ BOOL __RPC_FAR *pfVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Superscript( 
            /* [in] */ BOOL fVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_TextProperties( 
            /* [retval][out] */ SCTextProperties __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_TextProperties( 
            /* [in] */ SCTextProperties newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_TextType( 
            /* [retval][out] */ SCTextType __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_TextType( 
            /* [in] */ SCTextType newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Underline( 
            /* [retval][out] */ BOOL __RPC_FAR *pfVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Underline( 
            /* [in] */ BOOL fVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_XMLTag( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_XMLTag( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_WritingSystem( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_WritingSystem( 
            /* [in] */ BSTR bstr) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISCTagVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISCTag __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISCTag __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISCTag __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Bold )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pfVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Bold )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BOOL fVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Color )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Color )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Description )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Description )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Endmarker )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Endmarker )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FirstLineIndent )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FirstLineIndent )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Fontname )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Fontname )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontSize )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontSize )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Italic )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pfVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Italic )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BOOL fVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_JustificationType )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ SCJustificationType __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_JustificationType )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ SCJustificationType newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LeftMargin )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_LeftMargin )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LineSpacing )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_LineSpacing )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Marker )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Marker )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Name )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Name )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NotRepeatable )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pfVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_NotRepeatable )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BOOL fVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_OccursUnder )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_OccursUnder )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Rank )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Rank )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RightMargin )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_RightMargin )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SpaceAfter )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SpaceAfter )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SpaceBefore )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SpaceBefore )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_StyleType )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ SCStyleType __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_StyleType )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ SCStyleType newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Superscript )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pfVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Superscript )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BOOL fVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TextProperties )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ SCTextProperties __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TextProperties )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ SCTextProperties newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TextType )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ SCTextType __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TextType )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ SCTextType newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Underline )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pfVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Underline )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BOOL fVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_XMLTag )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_XMLTag )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_WritingSystem )( 
            ISCTag __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_WritingSystem )( 
            ISCTag __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        END_INTERFACE
    } ISCTagVtbl;

    interface ISCTag
    {
        CONST_VTBL struct ISCTagVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISCTag_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISCTag_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISCTag_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISCTag_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISCTag_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISCTag_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISCTag_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISCTag_get_Bold(This,pfVal)	\
    (This)->lpVtbl -> get_Bold(This,pfVal)

#define ISCTag_put_Bold(This,fVal)	\
    (This)->lpVtbl -> put_Bold(This,fVal)

#define ISCTag_get_Color(This,piVal)	\
    (This)->lpVtbl -> get_Color(This,piVal)

#define ISCTag_put_Color(This,iVal)	\
    (This)->lpVtbl -> put_Color(This,iVal)

#define ISCTag_get_Description(This,pbstr)	\
    (This)->lpVtbl -> get_Description(This,pbstr)

#define ISCTag_put_Description(This,bstr)	\
    (This)->lpVtbl -> put_Description(This,bstr)

#define ISCTag_get_Endmarker(This,pbstr)	\
    (This)->lpVtbl -> get_Endmarker(This,pbstr)

#define ISCTag_put_Endmarker(This,bstr)	\
    (This)->lpVtbl -> put_Endmarker(This,bstr)

#define ISCTag_get_FirstLineIndent(This,piVal)	\
    (This)->lpVtbl -> get_FirstLineIndent(This,piVal)

#define ISCTag_put_FirstLineIndent(This,iVal)	\
    (This)->lpVtbl -> put_FirstLineIndent(This,iVal)

#define ISCTag_get_Fontname(This,pbstr)	\
    (This)->lpVtbl -> get_Fontname(This,pbstr)

#define ISCTag_put_Fontname(This,bstr)	\
    (This)->lpVtbl -> put_Fontname(This,bstr)

#define ISCTag_get_FontSize(This,piVal)	\
    (This)->lpVtbl -> get_FontSize(This,piVal)

#define ISCTag_put_FontSize(This,iVal)	\
    (This)->lpVtbl -> put_FontSize(This,iVal)

#define ISCTag_get_Italic(This,pfVal)	\
    (This)->lpVtbl -> get_Italic(This,pfVal)

#define ISCTag_put_Italic(This,fVal)	\
    (This)->lpVtbl -> put_Italic(This,fVal)

#define ISCTag_get_JustificationType(This,pVal)	\
    (This)->lpVtbl -> get_JustificationType(This,pVal)

#define ISCTag_put_JustificationType(This,newVal)	\
    (This)->lpVtbl -> put_JustificationType(This,newVal)

#define ISCTag_get_LeftMargin(This,piVal)	\
    (This)->lpVtbl -> get_LeftMargin(This,piVal)

#define ISCTag_put_LeftMargin(This,iVal)	\
    (This)->lpVtbl -> put_LeftMargin(This,iVal)

#define ISCTag_get_LineSpacing(This,piVal)	\
    (This)->lpVtbl -> get_LineSpacing(This,piVal)

#define ISCTag_put_LineSpacing(This,iVal)	\
    (This)->lpVtbl -> put_LineSpacing(This,iVal)

#define ISCTag_get_Marker(This,pbstr)	\
    (This)->lpVtbl -> get_Marker(This,pbstr)

#define ISCTag_put_Marker(This,bstr)	\
    (This)->lpVtbl -> put_Marker(This,bstr)

#define ISCTag_get_Name(This,pbstr)	\
    (This)->lpVtbl -> get_Name(This,pbstr)

#define ISCTag_put_Name(This,bstr)	\
    (This)->lpVtbl -> put_Name(This,bstr)

#define ISCTag_get_NotRepeatable(This,pfVal)	\
    (This)->lpVtbl -> get_NotRepeatable(This,pfVal)

#define ISCTag_put_NotRepeatable(This,fVal)	\
    (This)->lpVtbl -> put_NotRepeatable(This,fVal)

#define ISCTag_get_OccursUnder(This,pbstr)	\
    (This)->lpVtbl -> get_OccursUnder(This,pbstr)

#define ISCTag_put_OccursUnder(This,bstr)	\
    (This)->lpVtbl -> put_OccursUnder(This,bstr)

#define ISCTag_get_Rank(This,piVal)	\
    (This)->lpVtbl -> get_Rank(This,piVal)

#define ISCTag_put_Rank(This,iVal)	\
    (This)->lpVtbl -> put_Rank(This,iVal)

#define ISCTag_get_RightMargin(This,piVal)	\
    (This)->lpVtbl -> get_RightMargin(This,piVal)

#define ISCTag_put_RightMargin(This,iVal)	\
    (This)->lpVtbl -> put_RightMargin(This,iVal)

#define ISCTag_get_SpaceAfter(This,piVal)	\
    (This)->lpVtbl -> get_SpaceAfter(This,piVal)

#define ISCTag_put_SpaceAfter(This,iVal)	\
    (This)->lpVtbl -> put_SpaceAfter(This,iVal)

#define ISCTag_get_SpaceBefore(This,piVal)	\
    (This)->lpVtbl -> get_SpaceBefore(This,piVal)

#define ISCTag_put_SpaceBefore(This,iVal)	\
    (This)->lpVtbl -> put_SpaceBefore(This,iVal)

#define ISCTag_get_StyleType(This,pVal)	\
    (This)->lpVtbl -> get_StyleType(This,pVal)

#define ISCTag_put_StyleType(This,newVal)	\
    (This)->lpVtbl -> put_StyleType(This,newVal)

#define ISCTag_get_Superscript(This,pfVal)	\
    (This)->lpVtbl -> get_Superscript(This,pfVal)

#define ISCTag_put_Superscript(This,fVal)	\
    (This)->lpVtbl -> put_Superscript(This,fVal)

#define ISCTag_get_TextProperties(This,pVal)	\
    (This)->lpVtbl -> get_TextProperties(This,pVal)

#define ISCTag_put_TextProperties(This,newVal)	\
    (This)->lpVtbl -> put_TextProperties(This,newVal)

#define ISCTag_get_TextType(This,pVal)	\
    (This)->lpVtbl -> get_TextType(This,pVal)

#define ISCTag_put_TextType(This,newVal)	\
    (This)->lpVtbl -> put_TextType(This,newVal)

#define ISCTag_get_Underline(This,pfVal)	\
    (This)->lpVtbl -> get_Underline(This,pfVal)

#define ISCTag_put_Underline(This,fVal)	\
    (This)->lpVtbl -> put_Underline(This,fVal)

#define ISCTag_get_XMLTag(This,pbstr)	\
    (This)->lpVtbl -> get_XMLTag(This,pbstr)

#define ISCTag_put_XMLTag(This,bstr)	\
    (This)->lpVtbl -> put_XMLTag(This,bstr)

#define ISCTag_get_WritingSystem(This,pbstr)	\
    (This)->lpVtbl -> get_WritingSystem(This,pbstr)

#define ISCTag_put_WritingSystem(This,bstr)	\
    (This)->lpVtbl -> put_WritingSystem(This,bstr)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Bold_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pfVal);


void __RPC_STUB ISCTag_get_Bold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Bold_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BOOL fVal);


void __RPC_STUB ISCTag_put_Bold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Color_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCTag_get_Color_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Color_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCTag_put_Color_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Description_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCTag_get_Description_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Description_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCTag_put_Description_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Endmarker_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCTag_get_Endmarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Endmarker_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCTag_put_Endmarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_FirstLineIndent_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCTag_get_FirstLineIndent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_FirstLineIndent_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCTag_put_FirstLineIndent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Fontname_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCTag_get_Fontname_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Fontname_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCTag_put_Fontname_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_FontSize_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCTag_get_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_FontSize_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCTag_put_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Italic_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pfVal);


void __RPC_STUB ISCTag_get_Italic_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Italic_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BOOL fVal);


void __RPC_STUB ISCTag_put_Italic_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_JustificationType_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ SCJustificationType __RPC_FAR *pVal);


void __RPC_STUB ISCTag_get_JustificationType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_JustificationType_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ SCJustificationType newVal);


void __RPC_STUB ISCTag_put_JustificationType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_LeftMargin_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCTag_get_LeftMargin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_LeftMargin_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCTag_put_LeftMargin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_LineSpacing_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCTag_get_LineSpacing_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_LineSpacing_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCTag_put_LineSpacing_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Marker_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCTag_get_Marker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Marker_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCTag_put_Marker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Name_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCTag_get_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Name_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCTag_put_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_NotRepeatable_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pfVal);


void __RPC_STUB ISCTag_get_NotRepeatable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_NotRepeatable_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BOOL fVal);


void __RPC_STUB ISCTag_put_NotRepeatable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_OccursUnder_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCTag_get_OccursUnder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_OccursUnder_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCTag_put_OccursUnder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Rank_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCTag_get_Rank_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Rank_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCTag_put_Rank_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_RightMargin_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCTag_get_RightMargin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_RightMargin_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCTag_put_RightMargin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_SpaceAfter_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCTag_get_SpaceAfter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_SpaceAfter_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCTag_put_SpaceAfter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_SpaceBefore_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCTag_get_SpaceBefore_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_SpaceBefore_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCTag_put_SpaceBefore_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_StyleType_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ SCStyleType __RPC_FAR *pVal);


void __RPC_STUB ISCTag_get_StyleType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_StyleType_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ SCStyleType newVal);


void __RPC_STUB ISCTag_put_StyleType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Superscript_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pfVal);


void __RPC_STUB ISCTag_get_Superscript_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Superscript_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BOOL fVal);


void __RPC_STUB ISCTag_put_Superscript_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_TextProperties_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ SCTextProperties __RPC_FAR *pVal);


void __RPC_STUB ISCTag_get_TextProperties_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_TextProperties_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ SCTextProperties newVal);


void __RPC_STUB ISCTag_put_TextProperties_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_TextType_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ SCTextType __RPC_FAR *pVal);


void __RPC_STUB ISCTag_get_TextType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_TextType_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ SCTextType newVal);


void __RPC_STUB ISCTag_put_TextType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_Underline_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pfVal);


void __RPC_STUB ISCTag_get_Underline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_Underline_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BOOL fVal);


void __RPC_STUB ISCTag_put_Underline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_XMLTag_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCTag_get_XMLTag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_XMLTag_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCTag_put_XMLTag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTag_get_WritingSystem_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCTag_get_WritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTag_put_WritingSystem_Proxy( 
    ISCTag __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCTag_put_WritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISCTag_INTERFACE_DEFINED__ */


#ifndef __ISCTextSegment_INTERFACE_DEFINED__
#define __ISCTextSegment_INTERFACE_DEFINED__

/* interface ISCTextSegment */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISCTextSegment;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("20AA6890-F664-11D2-A1D7-00C0DFEC0B1A")
    ISCTextSegment : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FirstReference( 
            /* [retval][out] */ ISCReference __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FirstReference( 
            /* [in] */ ISCReference __RPC_FAR *newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_LastReference( 
            /* [retval][out] */ ISCReference __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_LastReference( 
            /* [in] */ ISCReference __RPC_FAR *newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Text( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Text( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_TextType( 
            /* [retval][out] */ SCTextType __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_TextType( 
            /* [in] */ SCTextType newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_TextProperties( 
            /* [retval][out] */ SCTextProperties __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_TextProperties( 
            /* [in] */ SCTextProperties newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Tag( 
            /* [retval][out] */ ISCTag __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Tag( 
            /* [in] */ ISCTag __RPC_FAR *newVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Clone( 
            /* [retval][out] */ ISCTextSegment __RPC_FAR *__RPC_FAR *ppTextSegment) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISCTextSegmentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISCTextSegment __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISCTextSegment __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISCTextSegment __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FirstReference )( 
            ISCTextSegment __RPC_FAR * This,
            /* [retval][out] */ ISCReference __RPC_FAR *__RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FirstReference )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LastReference )( 
            ISCTextSegment __RPC_FAR * This,
            /* [retval][out] */ ISCReference __RPC_FAR *__RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_LastReference )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Text )( 
            ISCTextSegment __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Text )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TextType )( 
            ISCTextSegment __RPC_FAR * This,
            /* [retval][out] */ SCTextType __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TextType )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ SCTextType newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TextProperties )( 
            ISCTextSegment __RPC_FAR * This,
            /* [retval][out] */ SCTextProperties __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TextProperties )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ SCTextProperties newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Tag )( 
            ISCTextSegment __RPC_FAR * This,
            /* [retval][out] */ ISCTag __RPC_FAR *__RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Tag )( 
            ISCTextSegment __RPC_FAR * This,
            /* [in] */ ISCTag __RPC_FAR *newVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clone )( 
            ISCTextSegment __RPC_FAR * This,
            /* [retval][out] */ ISCTextSegment __RPC_FAR *__RPC_FAR *ppTextSegment);
        
        END_INTERFACE
    } ISCTextSegmentVtbl;

    interface ISCTextSegment
    {
        CONST_VTBL struct ISCTextSegmentVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISCTextSegment_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISCTextSegment_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISCTextSegment_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISCTextSegment_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISCTextSegment_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISCTextSegment_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISCTextSegment_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISCTextSegment_get_FirstReference(This,pVal)	\
    (This)->lpVtbl -> get_FirstReference(This,pVal)

#define ISCTextSegment_put_FirstReference(This,newVal)	\
    (This)->lpVtbl -> put_FirstReference(This,newVal)

#define ISCTextSegment_get_LastReference(This,pVal)	\
    (This)->lpVtbl -> get_LastReference(This,pVal)

#define ISCTextSegment_put_LastReference(This,newVal)	\
    (This)->lpVtbl -> put_LastReference(This,newVal)

#define ISCTextSegment_get_Text(This,pVal)	\
    (This)->lpVtbl -> get_Text(This,pVal)

#define ISCTextSegment_put_Text(This,newVal)	\
    (This)->lpVtbl -> put_Text(This,newVal)

#define ISCTextSegment_get_TextType(This,pVal)	\
    (This)->lpVtbl -> get_TextType(This,pVal)

#define ISCTextSegment_put_TextType(This,newVal)	\
    (This)->lpVtbl -> put_TextType(This,newVal)

#define ISCTextSegment_get_TextProperties(This,pVal)	\
    (This)->lpVtbl -> get_TextProperties(This,pVal)

#define ISCTextSegment_put_TextProperties(This,newVal)	\
    (This)->lpVtbl -> put_TextProperties(This,newVal)

#define ISCTextSegment_get_Tag(This,pVal)	\
    (This)->lpVtbl -> get_Tag(This,pVal)

#define ISCTextSegment_put_Tag(This,newVal)	\
    (This)->lpVtbl -> put_Tag(This,newVal)

#define ISCTextSegment_Clone(This,ppTextSegment)	\
    (This)->lpVtbl -> Clone(This,ppTextSegment)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_get_FirstReference_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [retval][out] */ ISCReference __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB ISCTextSegment_get_FirstReference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_put_FirstReference_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [in] */ ISCReference __RPC_FAR *newVal);


void __RPC_STUB ISCTextSegment_put_FirstReference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_get_LastReference_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [retval][out] */ ISCReference __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB ISCTextSegment_get_LastReference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_put_LastReference_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [in] */ ISCReference __RPC_FAR *newVal);


void __RPC_STUB ISCTextSegment_put_LastReference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_get_Text_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ISCTextSegment_get_Text_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_put_Text_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISCTextSegment_put_Text_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_get_TextType_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [retval][out] */ SCTextType __RPC_FAR *pVal);


void __RPC_STUB ISCTextSegment_get_TextType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_put_TextType_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [in] */ SCTextType newVal);


void __RPC_STUB ISCTextSegment_put_TextType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_get_TextProperties_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [retval][out] */ SCTextProperties __RPC_FAR *pVal);


void __RPC_STUB ISCTextSegment_get_TextProperties_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_put_TextProperties_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [in] */ SCTextProperties newVal);


void __RPC_STUB ISCTextSegment_put_TextProperties_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_get_Tag_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [retval][out] */ ISCTag __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB ISCTextSegment_get_Tag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCTextSegment_put_Tag_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [in] */ ISCTag __RPC_FAR *newVal);


void __RPC_STUB ISCTextSegment_put_Tag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCTextSegment_Clone_Proxy( 
    ISCTextSegment __RPC_FAR * This,
    /* [retval][out] */ ISCTextSegment __RPC_FAR *__RPC_FAR *ppTextSegment);


void __RPC_STUB ISCTextSegment_Clone_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISCTextSegment_INTERFACE_DEFINED__ */


#ifndef __ISCTextEnum_INTERFACE_DEFINED__
#define __ISCTextEnum_INTERFACE_DEFINED__

/* interface ISCTextEnum */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISCTextEnum;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("20AA6892-F664-11D2-A1D7-00C0DFEC0B1A")
    ISCTextEnum : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE NextToken( 
            /* [out] */ int __RPC_FAR *piTagIndex,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Next( 
            /* [out][in] */ ISCTextSegment __RPC_FAR *__RPC_FAR *pVal,
            /* [retval][out] */ BOOL __RPC_FAR *fVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Update( 
            /* [in] */ ISCTextSegment __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetText( 
            /* [in] */ BSTR bstrText,
            /* [in] */ ISCScriptureText __RPC_FAR *pscr,
            /* [in] */ BSTR bstrComment) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISCTextEnumVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISCTextEnum __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISCTextEnum __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISCTextEnum __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISCTextEnum __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISCTextEnum __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISCTextEnum __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISCTextEnum __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NextToken )( 
            ISCTextEnum __RPC_FAR * This,
            /* [out] */ int __RPC_FAR *piTagIndex,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Next )( 
            ISCTextEnum __RPC_FAR * This,
            /* [out][in] */ ISCTextSegment __RPC_FAR *__RPC_FAR *pVal,
            /* [retval][out] */ BOOL __RPC_FAR *fVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Update )( 
            ISCTextEnum __RPC_FAR * This,
            /* [in] */ ISCTextSegment __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetText )( 
            ISCTextEnum __RPC_FAR * This,
            /* [in] */ BSTR bstrText,
            /* [in] */ ISCScriptureText __RPC_FAR *pscr,
            /* [in] */ BSTR bstrComment);
        
        END_INTERFACE
    } ISCTextEnumVtbl;

    interface ISCTextEnum
    {
        CONST_VTBL struct ISCTextEnumVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISCTextEnum_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISCTextEnum_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISCTextEnum_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISCTextEnum_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISCTextEnum_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISCTextEnum_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISCTextEnum_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISCTextEnum_NextToken(This,piTagIndex,pbstr)	\
    (This)->lpVtbl -> NextToken(This,piTagIndex,pbstr)

#define ISCTextEnum_Next(This,pVal,fVal)	\
    (This)->lpVtbl -> Next(This,pVal,fVal)

#define ISCTextEnum_Update(This,pVal)	\
    (This)->lpVtbl -> Update(This,pVal)

#define ISCTextEnum_SetText(This,bstrText,pscr,bstrComment)	\
    (This)->lpVtbl -> SetText(This,bstrText,pscr,bstrComment)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISCTextEnum_NextToken_Proxy( 
    ISCTextEnum __RPC_FAR * This,
    /* [out] */ int __RPC_FAR *piTagIndex,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCTextEnum_NextToken_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCTextEnum_Next_Proxy( 
    ISCTextEnum __RPC_FAR * This,
    /* [out][in] */ ISCTextSegment __RPC_FAR *__RPC_FAR *pVal,
    /* [retval][out] */ BOOL __RPC_FAR *fVal);


void __RPC_STUB ISCTextEnum_Next_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCTextEnum_Update_Proxy( 
    ISCTextEnum __RPC_FAR * This,
    /* [in] */ ISCTextSegment __RPC_FAR *pVal);


void __RPC_STUB ISCTextEnum_Update_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCTextEnum_SetText_Proxy( 
    ISCTextEnum __RPC_FAR * This,
    /* [in] */ BSTR bstrText,
    /* [in] */ ISCScriptureText __RPC_FAR *pscr,
    /* [in] */ BSTR bstrComment);


void __RPC_STUB ISCTextEnum_SetText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISCTextEnum_INTERFACE_DEFINED__ */


#ifndef __ISCScriptureText_INTERFACE_DEFINED__
#define __ISCScriptureText_INTERFACE_DEFINED__

/* interface ISCScriptureText */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISCScriptureText;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("20AA6894-F664-11D2-A1D7-00C0DFEC0B1A")
    ISCScriptureText : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_TextsPresent( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Load( 
            BSTR bstrFileName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Save( 
            BSTR bstrFileName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TextEnum( 
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
            /* [in] */ SCTextType sttFilter,
            /* [in] */ SCTextProperties stpSmushing,
            /* [retval][out] */ ISCTextEnum __RPC_FAR *__RPC_FAR *ppTextEnum) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetText( 
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirstChapter,
            /* [in] */ BOOL fSingleChapter,
            /* [in] */ BOOL fDoMapin,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrText) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE PutText( 
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirstChapter,
            /* [in] */ BOOL fSingleChapter,
            /* [in] */ BOOL fDoMapout,
            /* [in] */ BSTR bstrText) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE FileName( 
            /* [in] */ ISCReference __RPC_FAR *pSCReference,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
            /* [in] */ BOOL fAlwaysReturnName,
            /* [retval][out] */ BSTR __RPC_FAR *bstrFileName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NthFileName( 
            /* [in] */ int iFileNumber,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
            /* [retval][out] */ BSTR __RPC_FAR *bstrFileName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NthTag( 
            /* [in] */ int iTagNumber,
            /* [retval][out] */ ISCTag __RPC_FAR *__RPC_FAR *ppTag) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TagIndex( 
            /* [in] */ BSTR bstrTagName,
            /* [retval][out] */ int __RPC_FAR *piNth) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CharToWChar( 
            /* [in] */ unsigned char __RPC_FAR *pszIn,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetParameterValue( 
            /* [in] */ BSTR bstrName,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrValue) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetParameterValue( 
            /* [in] */ BSTR bstrName,
            /* [in] */ BSTR bstrValue) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_BooksPresent( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_BooksPresent( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_CodePage( 
            /* [retval][out] */ int __RPC_FAR *piCodePage) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_CodePage( 
            /* [in] */ int iCodePage) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultFont( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultFont( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultFontSize( 
            /* [retval][out] */ int __RPC_FAR *piVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultFontSize( 
            /* [in] */ int iVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Directory( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Directory( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Editable( 
            /* [retval][out] */ BOOL __RPC_FAR *pfVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Editable( 
            /* [in] */ BOOL fVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FileNameForm( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FileNameForm( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FileNamePostPart( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FileNamePostPart( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FileNamePrePart( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FileNamePrePart( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FileNameChapterNumberForm( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FileNameChapterNumberForm( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FullName( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FullName( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Language( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Language( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_LeftToRight( 
            /* [retval][out] */ BOOL __RPC_FAR *pfVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_LeftToRight( 
            /* [in] */ BOOL fVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Name( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_SettingsDirectory( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_StyleSheet( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstr) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_StyleSheet( 
            /* [in] */ BSTR bstr) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Versification( 
            /* [retval][out] */ SCVersification __RPC_FAR *pvVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Versification( 
            /* [in] */ SCVersification vVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISCScriptureTextVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISCScriptureText __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISCScriptureText __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISCScriptureText __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TextsPresent )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Load )( 
            ISCScriptureText __RPC_FAR * This,
            BSTR bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Save )( 
            ISCScriptureText __RPC_FAR * This,
            BSTR bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TextEnum )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
            /* [in] */ SCTextType sttFilter,
            /* [in] */ SCTextProperties stpSmushing,
            /* [retval][out] */ ISCTextEnum __RPC_FAR *__RPC_FAR *ppTextEnum);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetText )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirstChapter,
            /* [in] */ BOOL fSingleChapter,
            /* [in] */ BOOL fDoMapin,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrText);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PutText )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirstChapter,
            /* [in] */ BOOL fSingleChapter,
            /* [in] */ BOOL fDoMapout,
            /* [in] */ BSTR bstrText);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FileName )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReference,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
            /* [in] */ BOOL fAlwaysReturnName,
            /* [retval][out] */ BSTR __RPC_FAR *bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NthFileName )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ int iFileNumber,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
            /* [retval][out] */ BSTR __RPC_FAR *bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NthTag )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ int iTagNumber,
            /* [retval][out] */ ISCTag __RPC_FAR *__RPC_FAR *ppTag);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TagIndex )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstrTagName,
            /* [retval][out] */ int __RPC_FAR *piNth);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CharToWChar )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ unsigned char __RPC_FAR *pszIn,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetParameterValue )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstrName,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrValue);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetParameterValue )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstrName,
            /* [in] */ BSTR bstrValue);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BooksPresent )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BooksPresent )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CodePage )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piCodePage);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_CodePage )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ int iCodePage);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DefaultFont )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DefaultFont )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DefaultFontSize )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DefaultFontSize )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Directory )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Directory )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Editable )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pfVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Editable )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BOOL fVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileNameForm )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FileNameForm )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileNamePostPart )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FileNamePostPart )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileNamePrePart )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FileNamePrePart )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileNameChapterNumberForm )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FileNameChapterNumberForm )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FullName )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FullName )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Language )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Language )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LeftToRight )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pfVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_LeftToRight )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BOOL fVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Name )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Name )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SettingsDirectory )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_StyleSheet )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_StyleSheet )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Versification )( 
            ISCScriptureText __RPC_FAR * This,
            /* [retval][out] */ SCVersification __RPC_FAR *pvVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Versification )( 
            ISCScriptureText __RPC_FAR * This,
            /* [in] */ SCVersification vVal);
        
        END_INTERFACE
    } ISCScriptureTextVtbl;

    interface ISCScriptureText
    {
        CONST_VTBL struct ISCScriptureTextVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISCScriptureText_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISCScriptureText_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISCScriptureText_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISCScriptureText_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISCScriptureText_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISCScriptureText_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISCScriptureText_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISCScriptureText_get_TextsPresent(This,pbstr)	\
    (This)->lpVtbl -> get_TextsPresent(This,pbstr)

#define ISCScriptureText_Load(This,bstrFileName)	\
    (This)->lpVtbl -> Load(This,bstrFileName)

#define ISCScriptureText_Save(This,bstrFileName)	\
    (This)->lpVtbl -> Save(This,bstrFileName)

#define ISCScriptureText_TextEnum(This,pSCReferenceFirst,pSCReferenceLast,sttFilter,stpSmushing,ppTextEnum)	\
    (This)->lpVtbl -> TextEnum(This,pSCReferenceFirst,pSCReferenceLast,sttFilter,stpSmushing,ppTextEnum)

#define ISCScriptureText_GetText(This,pSCReferenceFirstChapter,fSingleChapter,fDoMapin,pbstrText)	\
    (This)->lpVtbl -> GetText(This,pSCReferenceFirstChapter,fSingleChapter,fDoMapin,pbstrText)

#define ISCScriptureText_PutText(This,pSCReferenceFirstChapter,fSingleChapter,fDoMapout,bstrText)	\
    (This)->lpVtbl -> PutText(This,pSCReferenceFirstChapter,fSingleChapter,fDoMapout,bstrText)

#define ISCScriptureText_FileName(This,pSCReference,pSCReferenceFirst,pSCReferenceLast,fAlwaysReturnName,bstrFileName)	\
    (This)->lpVtbl -> FileName(This,pSCReference,pSCReferenceFirst,pSCReferenceLast,fAlwaysReturnName,bstrFileName)

#define ISCScriptureText_NthFileName(This,iFileNumber,pSCReferenceFirst,pSCReferenceLast,bstrFileName)	\
    (This)->lpVtbl -> NthFileName(This,iFileNumber,pSCReferenceFirst,pSCReferenceLast,bstrFileName)

#define ISCScriptureText_NthTag(This,iTagNumber,ppTag)	\
    (This)->lpVtbl -> NthTag(This,iTagNumber,ppTag)

#define ISCScriptureText_TagIndex(This,bstrTagName,piNth)	\
    (This)->lpVtbl -> TagIndex(This,bstrTagName,piNth)

#define ISCScriptureText_CharToWChar(This,pszIn,pbstr)	\
    (This)->lpVtbl -> CharToWChar(This,pszIn,pbstr)

#define ISCScriptureText_GetParameterValue(This,bstrName,pbstrValue)	\
    (This)->lpVtbl -> GetParameterValue(This,bstrName,pbstrValue)

#define ISCScriptureText_SetParameterValue(This,bstrName,bstrValue)	\
    (This)->lpVtbl -> SetParameterValue(This,bstrName,bstrValue)

#define ISCScriptureText_get_BooksPresent(This,pbstr)	\
    (This)->lpVtbl -> get_BooksPresent(This,pbstr)

#define ISCScriptureText_put_BooksPresent(This,bstr)	\
    (This)->lpVtbl -> put_BooksPresent(This,bstr)

#define ISCScriptureText_get_CodePage(This,piCodePage)	\
    (This)->lpVtbl -> get_CodePage(This,piCodePage)

#define ISCScriptureText_put_CodePage(This,iCodePage)	\
    (This)->lpVtbl -> put_CodePage(This,iCodePage)

#define ISCScriptureText_get_DefaultFont(This,pbstr)	\
    (This)->lpVtbl -> get_DefaultFont(This,pbstr)

#define ISCScriptureText_put_DefaultFont(This,bstr)	\
    (This)->lpVtbl -> put_DefaultFont(This,bstr)

#define ISCScriptureText_get_DefaultFontSize(This,piVal)	\
    (This)->lpVtbl -> get_DefaultFontSize(This,piVal)

#define ISCScriptureText_put_DefaultFontSize(This,iVal)	\
    (This)->lpVtbl -> put_DefaultFontSize(This,iVal)

#define ISCScriptureText_get_Directory(This,pbstr)	\
    (This)->lpVtbl -> get_Directory(This,pbstr)

#define ISCScriptureText_put_Directory(This,bstr)	\
    (This)->lpVtbl -> put_Directory(This,bstr)

#define ISCScriptureText_get_Editable(This,pfVal)	\
    (This)->lpVtbl -> get_Editable(This,pfVal)

#define ISCScriptureText_put_Editable(This,fVal)	\
    (This)->lpVtbl -> put_Editable(This,fVal)

#define ISCScriptureText_get_FileNameForm(This,pbstr)	\
    (This)->lpVtbl -> get_FileNameForm(This,pbstr)

#define ISCScriptureText_put_FileNameForm(This,bstr)	\
    (This)->lpVtbl -> put_FileNameForm(This,bstr)

#define ISCScriptureText_get_FileNamePostPart(This,pbstr)	\
    (This)->lpVtbl -> get_FileNamePostPart(This,pbstr)

#define ISCScriptureText_put_FileNamePostPart(This,bstr)	\
    (This)->lpVtbl -> put_FileNamePostPart(This,bstr)

#define ISCScriptureText_get_FileNamePrePart(This,pbstr)	\
    (This)->lpVtbl -> get_FileNamePrePart(This,pbstr)

#define ISCScriptureText_put_FileNamePrePart(This,bstr)	\
    (This)->lpVtbl -> put_FileNamePrePart(This,bstr)

#define ISCScriptureText_get_FileNameChapterNumberForm(This,pbstr)	\
    (This)->lpVtbl -> get_FileNameChapterNumberForm(This,pbstr)

#define ISCScriptureText_put_FileNameChapterNumberForm(This,bstr)	\
    (This)->lpVtbl -> put_FileNameChapterNumberForm(This,bstr)

#define ISCScriptureText_get_FullName(This,pbstr)	\
    (This)->lpVtbl -> get_FullName(This,pbstr)

#define ISCScriptureText_put_FullName(This,bstr)	\
    (This)->lpVtbl -> put_FullName(This,bstr)

#define ISCScriptureText_get_Language(This,pbstr)	\
    (This)->lpVtbl -> get_Language(This,pbstr)

#define ISCScriptureText_put_Language(This,bstr)	\
    (This)->lpVtbl -> put_Language(This,bstr)

#define ISCScriptureText_get_LeftToRight(This,pfVal)	\
    (This)->lpVtbl -> get_LeftToRight(This,pfVal)

#define ISCScriptureText_put_LeftToRight(This,fVal)	\
    (This)->lpVtbl -> put_LeftToRight(This,fVal)

#define ISCScriptureText_get_Name(This,pbstr)	\
    (This)->lpVtbl -> get_Name(This,pbstr)

#define ISCScriptureText_put_Name(This,bstr)	\
    (This)->lpVtbl -> put_Name(This,bstr)

#define ISCScriptureText_get_SettingsDirectory(This,pbstr)	\
    (This)->lpVtbl -> get_SettingsDirectory(This,pbstr)

#define ISCScriptureText_get_StyleSheet(This,pbstr)	\
    (This)->lpVtbl -> get_StyleSheet(This,pbstr)

#define ISCScriptureText_put_StyleSheet(This,bstr)	\
    (This)->lpVtbl -> put_StyleSheet(This,bstr)

#define ISCScriptureText_get_Versification(This,pvVal)	\
    (This)->lpVtbl -> get_Versification(This,pvVal)

#define ISCScriptureText_put_Versification(This,vVal)	\
    (This)->lpVtbl -> put_Versification(This,vVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_TextsPresent_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_TextsPresent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_Load_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    BSTR bstrFileName);


void __RPC_STUB ISCScriptureText_Load_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_Save_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    BSTR bstrFileName);


void __RPC_STUB ISCScriptureText_Save_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_TextEnum_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
    /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
    /* [in] */ SCTextType sttFilter,
    /* [in] */ SCTextProperties stpSmushing,
    /* [retval][out] */ ISCTextEnum __RPC_FAR *__RPC_FAR *ppTextEnum);


void __RPC_STUB ISCScriptureText_TextEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_GetText_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirstChapter,
    /* [in] */ BOOL fSingleChapter,
    /* [in] */ BOOL fDoMapin,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrText);


void __RPC_STUB ISCScriptureText_GetText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_PutText_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirstChapter,
    /* [in] */ BOOL fSingleChapter,
    /* [in] */ BOOL fDoMapout,
    /* [in] */ BSTR bstrText);


void __RPC_STUB ISCScriptureText_PutText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_FileName_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ ISCReference __RPC_FAR *pSCReference,
    /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
    /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
    /* [in] */ BOOL fAlwaysReturnName,
    /* [retval][out] */ BSTR __RPC_FAR *bstrFileName);


void __RPC_STUB ISCScriptureText_FileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_NthFileName_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ int iFileNumber,
    /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
    /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
    /* [retval][out] */ BSTR __RPC_FAR *bstrFileName);


void __RPC_STUB ISCScriptureText_NthFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_NthTag_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ int iTagNumber,
    /* [retval][out] */ ISCTag __RPC_FAR *__RPC_FAR *ppTag);


void __RPC_STUB ISCScriptureText_NthTag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_TagIndex_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstrTagName,
    /* [retval][out] */ int __RPC_FAR *piNth);


void __RPC_STUB ISCScriptureText_TagIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_CharToWChar_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ unsigned char __RPC_FAR *pszIn,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_CharToWChar_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_GetParameterValue_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstrName,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrValue);


void __RPC_STUB ISCScriptureText_GetParameterValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISCScriptureText_SetParameterValue_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstrName,
    /* [in] */ BSTR bstrValue);


void __RPC_STUB ISCScriptureText_SetParameterValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_BooksPresent_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_BooksPresent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_BooksPresent_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_BooksPresent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_CodePage_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piCodePage);


void __RPC_STUB ISCScriptureText_get_CodePage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_CodePage_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ int iCodePage);


void __RPC_STUB ISCScriptureText_put_CodePage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_DefaultFont_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_DefaultFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_DefaultFont_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_DefaultFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_DefaultFontSize_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *piVal);


void __RPC_STUB ISCScriptureText_get_DefaultFontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_DefaultFontSize_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ int iVal);


void __RPC_STUB ISCScriptureText_put_DefaultFontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_Directory_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_Directory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_Directory_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_Directory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_Editable_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pfVal);


void __RPC_STUB ISCScriptureText_get_Editable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_Editable_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BOOL fVal);


void __RPC_STUB ISCScriptureText_put_Editable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_FileNameForm_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_FileNameForm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_FileNameForm_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_FileNameForm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_FileNamePostPart_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_FileNamePostPart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_FileNamePostPart_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_FileNamePostPart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_FileNamePrePart_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_FileNamePrePart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_FileNamePrePart_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_FileNamePrePart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_FileNameChapterNumberForm_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_FileNameChapterNumberForm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_FileNameChapterNumberForm_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_FileNameChapterNumberForm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_FullName_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_FullName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_FullName_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_FullName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_Language_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_Language_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_Language_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_Language_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_LeftToRight_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pfVal);


void __RPC_STUB ISCScriptureText_get_LeftToRight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_LeftToRight_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BOOL fVal);


void __RPC_STUB ISCScriptureText_put_LeftToRight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_Name_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_Name_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_SettingsDirectory_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_SettingsDirectory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_StyleSheet_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstr);


void __RPC_STUB ISCScriptureText_get_StyleSheet_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_StyleSheet_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ BSTR bstr);


void __RPC_STUB ISCScriptureText_put_StyleSheet_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_get_Versification_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [retval][out] */ SCVersification __RPC_FAR *pvVal);


void __RPC_STUB ISCScriptureText_get_Versification_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText_put_Versification_Proxy( 
    ISCScriptureText __RPC_FAR * This,
    /* [in] */ SCVersification vVal);


void __RPC_STUB ISCScriptureText_put_Versification_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISCScriptureText_INTERFACE_DEFINED__ */


#ifndef __ISCScriptureText2_INTERFACE_DEFINED__
#define __ISCScriptureText2_INTERFACE_DEFINED__

/* interface ISCScriptureText2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISCScriptureText2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("29A2ACDE-A8EE-11D4-8900-00C0DFEC0B1A")
    ISCScriptureText2 : public ISCScriptureText
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_WritingSystem( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrEncoding) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_WritingSystem( 
            /* [in] */ BSTR bstrEncoding) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISCScriptureText2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISCScriptureText2 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISCScriptureText2 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TextsPresent )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Load )( 
            ISCScriptureText2 __RPC_FAR * This,
            BSTR bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Save )( 
            ISCScriptureText2 __RPC_FAR * This,
            BSTR bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TextEnum )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
            /* [in] */ SCTextType sttFilter,
            /* [in] */ SCTextProperties stpSmushing,
            /* [retval][out] */ ISCTextEnum __RPC_FAR *__RPC_FAR *ppTextEnum);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetText )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirstChapter,
            /* [in] */ BOOL fSingleChapter,
            /* [in] */ BOOL fDoMapin,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrText);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PutText )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirstChapter,
            /* [in] */ BOOL fSingleChapter,
            /* [in] */ BOOL fDoMapout,
            /* [in] */ BSTR bstrText);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FileName )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ ISCReference __RPC_FAR *pSCReference,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
            /* [in] */ BOOL fAlwaysReturnName,
            /* [retval][out] */ BSTR __RPC_FAR *bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NthFileName )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ int iFileNumber,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceFirst,
            /* [in] */ ISCReference __RPC_FAR *pSCReferenceLast,
            /* [retval][out] */ BSTR __RPC_FAR *bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NthTag )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ int iTagNumber,
            /* [retval][out] */ ISCTag __RPC_FAR *__RPC_FAR *ppTag);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TagIndex )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstrTagName,
            /* [retval][out] */ int __RPC_FAR *piNth);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CharToWChar )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ unsigned char __RPC_FAR *pszIn,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetParameterValue )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstrName,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrValue);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetParameterValue )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstrName,
            /* [in] */ BSTR bstrValue);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BooksPresent )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BooksPresent )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CodePage )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piCodePage);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_CodePage )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ int iCodePage);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DefaultFont )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DefaultFont )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DefaultFontSize )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *piVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DefaultFontSize )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ int iVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Directory )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Directory )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Editable )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pfVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Editable )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BOOL fVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileNameForm )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FileNameForm )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileNamePostPart )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FileNamePostPart )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileNamePrePart )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FileNamePrePart )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileNameChapterNumberForm )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FileNameChapterNumberForm )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FullName )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FullName )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Language )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Language )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LeftToRight )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pfVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_LeftToRight )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BOOL fVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Name )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Name )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SettingsDirectory )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_StyleSheet )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_StyleSheet )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Versification )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ SCVersification __RPC_FAR *pvVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Versification )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ SCVersification vVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_WritingSystem )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrEncoding);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_WritingSystem )( 
            ISCScriptureText2 __RPC_FAR * This,
            /* [in] */ BSTR bstrEncoding);
        
        END_INTERFACE
    } ISCScriptureText2Vtbl;

    interface ISCScriptureText2
    {
        CONST_VTBL struct ISCScriptureText2Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISCScriptureText2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISCScriptureText2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISCScriptureText2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISCScriptureText2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISCScriptureText2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISCScriptureText2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISCScriptureText2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISCScriptureText2_get_TextsPresent(This,pbstr)	\
    (This)->lpVtbl -> get_TextsPresent(This,pbstr)

#define ISCScriptureText2_Load(This,bstrFileName)	\
    (This)->lpVtbl -> Load(This,bstrFileName)

#define ISCScriptureText2_Save(This,bstrFileName)	\
    (This)->lpVtbl -> Save(This,bstrFileName)

#define ISCScriptureText2_TextEnum(This,pSCReferenceFirst,pSCReferenceLast,sttFilter,stpSmushing,ppTextEnum)	\
    (This)->lpVtbl -> TextEnum(This,pSCReferenceFirst,pSCReferenceLast,sttFilter,stpSmushing,ppTextEnum)

#define ISCScriptureText2_GetText(This,pSCReferenceFirstChapter,fSingleChapter,fDoMapin,pbstrText)	\
    (This)->lpVtbl -> GetText(This,pSCReferenceFirstChapter,fSingleChapter,fDoMapin,pbstrText)

#define ISCScriptureText2_PutText(This,pSCReferenceFirstChapter,fSingleChapter,fDoMapout,bstrText)	\
    (This)->lpVtbl -> PutText(This,pSCReferenceFirstChapter,fSingleChapter,fDoMapout,bstrText)

#define ISCScriptureText2_FileName(This,pSCReference,pSCReferenceFirst,pSCReferenceLast,fAlwaysReturnName,bstrFileName)	\
    (This)->lpVtbl -> FileName(This,pSCReference,pSCReferenceFirst,pSCReferenceLast,fAlwaysReturnName,bstrFileName)

#define ISCScriptureText2_NthFileName(This,iFileNumber,pSCReferenceFirst,pSCReferenceLast,bstrFileName)	\
    (This)->lpVtbl -> NthFileName(This,iFileNumber,pSCReferenceFirst,pSCReferenceLast,bstrFileName)

#define ISCScriptureText2_NthTag(This,iTagNumber,ppTag)	\
    (This)->lpVtbl -> NthTag(This,iTagNumber,ppTag)

#define ISCScriptureText2_TagIndex(This,bstrTagName,piNth)	\
    (This)->lpVtbl -> TagIndex(This,bstrTagName,piNth)

#define ISCScriptureText2_CharToWChar(This,pszIn,pbstr)	\
    (This)->lpVtbl -> CharToWChar(This,pszIn,pbstr)

#define ISCScriptureText2_GetParameterValue(This,bstrName,pbstrValue)	\
    (This)->lpVtbl -> GetParameterValue(This,bstrName,pbstrValue)

#define ISCScriptureText2_SetParameterValue(This,bstrName,bstrValue)	\
    (This)->lpVtbl -> SetParameterValue(This,bstrName,bstrValue)

#define ISCScriptureText2_get_BooksPresent(This,pbstr)	\
    (This)->lpVtbl -> get_BooksPresent(This,pbstr)

#define ISCScriptureText2_put_BooksPresent(This,bstr)	\
    (This)->lpVtbl -> put_BooksPresent(This,bstr)

#define ISCScriptureText2_get_CodePage(This,piCodePage)	\
    (This)->lpVtbl -> get_CodePage(This,piCodePage)

#define ISCScriptureText2_put_CodePage(This,iCodePage)	\
    (This)->lpVtbl -> put_CodePage(This,iCodePage)

#define ISCScriptureText2_get_DefaultFont(This,pbstr)	\
    (This)->lpVtbl -> get_DefaultFont(This,pbstr)

#define ISCScriptureText2_put_DefaultFont(This,bstr)	\
    (This)->lpVtbl -> put_DefaultFont(This,bstr)

#define ISCScriptureText2_get_DefaultFontSize(This,piVal)	\
    (This)->lpVtbl -> get_DefaultFontSize(This,piVal)

#define ISCScriptureText2_put_DefaultFontSize(This,iVal)	\
    (This)->lpVtbl -> put_DefaultFontSize(This,iVal)

#define ISCScriptureText2_get_Directory(This,pbstr)	\
    (This)->lpVtbl -> get_Directory(This,pbstr)

#define ISCScriptureText2_put_Directory(This,bstr)	\
    (This)->lpVtbl -> put_Directory(This,bstr)

#define ISCScriptureText2_get_Editable(This,pfVal)	\
    (This)->lpVtbl -> get_Editable(This,pfVal)

#define ISCScriptureText2_put_Editable(This,fVal)	\
    (This)->lpVtbl -> put_Editable(This,fVal)

#define ISCScriptureText2_get_FileNameForm(This,pbstr)	\
    (This)->lpVtbl -> get_FileNameForm(This,pbstr)

#define ISCScriptureText2_put_FileNameForm(This,bstr)	\
    (This)->lpVtbl -> put_FileNameForm(This,bstr)

#define ISCScriptureText2_get_FileNamePostPart(This,pbstr)	\
    (This)->lpVtbl -> get_FileNamePostPart(This,pbstr)

#define ISCScriptureText2_put_FileNamePostPart(This,bstr)	\
    (This)->lpVtbl -> put_FileNamePostPart(This,bstr)

#define ISCScriptureText2_get_FileNamePrePart(This,pbstr)	\
    (This)->lpVtbl -> get_FileNamePrePart(This,pbstr)

#define ISCScriptureText2_put_FileNamePrePart(This,bstr)	\
    (This)->lpVtbl -> put_FileNamePrePart(This,bstr)

#define ISCScriptureText2_get_FileNameChapterNumberForm(This,pbstr)	\
    (This)->lpVtbl -> get_FileNameChapterNumberForm(This,pbstr)

#define ISCScriptureText2_put_FileNameChapterNumberForm(This,bstr)	\
    (This)->lpVtbl -> put_FileNameChapterNumberForm(This,bstr)

#define ISCScriptureText2_get_FullName(This,pbstr)	\
    (This)->lpVtbl -> get_FullName(This,pbstr)

#define ISCScriptureText2_put_FullName(This,bstr)	\
    (This)->lpVtbl -> put_FullName(This,bstr)

#define ISCScriptureText2_get_Language(This,pbstr)	\
    (This)->lpVtbl -> get_Language(This,pbstr)

#define ISCScriptureText2_put_Language(This,bstr)	\
    (This)->lpVtbl -> put_Language(This,bstr)

#define ISCScriptureText2_get_LeftToRight(This,pfVal)	\
    (This)->lpVtbl -> get_LeftToRight(This,pfVal)

#define ISCScriptureText2_put_LeftToRight(This,fVal)	\
    (This)->lpVtbl -> put_LeftToRight(This,fVal)

#define ISCScriptureText2_get_Name(This,pbstr)	\
    (This)->lpVtbl -> get_Name(This,pbstr)

#define ISCScriptureText2_put_Name(This,bstr)	\
    (This)->lpVtbl -> put_Name(This,bstr)

#define ISCScriptureText2_get_SettingsDirectory(This,pbstr)	\
    (This)->lpVtbl -> get_SettingsDirectory(This,pbstr)

#define ISCScriptureText2_get_StyleSheet(This,pbstr)	\
    (This)->lpVtbl -> get_StyleSheet(This,pbstr)

#define ISCScriptureText2_put_StyleSheet(This,bstr)	\
    (This)->lpVtbl -> put_StyleSheet(This,bstr)

#define ISCScriptureText2_get_Versification(This,pvVal)	\
    (This)->lpVtbl -> get_Versification(This,pvVal)

#define ISCScriptureText2_put_Versification(This,vVal)	\
    (This)->lpVtbl -> put_Versification(This,vVal)


#define ISCScriptureText2_get_WritingSystem(This,pbstrEncoding)	\
    (This)->lpVtbl -> get_WritingSystem(This,pbstrEncoding)

#define ISCScriptureText2_put_WritingSystem(This,bstrEncoding)	\
    (This)->lpVtbl -> put_WritingSystem(This,bstrEncoding)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE ISCScriptureText2_get_WritingSystem_Proxy( 
    ISCScriptureText2 __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrEncoding);


void __RPC_STUB ISCScriptureText2_get_WritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISCScriptureText2_put_WritingSystem_Proxy( 
    ISCScriptureText2 __RPC_FAR * This,
    /* [in] */ BSTR bstrEncoding);


void __RPC_STUB ISCScriptureText2_put_WritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISCScriptureText2_INTERFACE_DEFINED__ */



#ifndef __SCRIPTUREOBJECTSLib_LIBRARY_DEFINED__
#define __SCRIPTUREOBJECTSLib_LIBRARY_DEFINED__

/* library SCRIPTUREOBJECTSLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SCRIPTUREOBJECTSLib;

EXTERN_C const CLSID CLSID_SCReferenceCollection;

#ifdef __cplusplus

class DECLSPEC_UUID("37A896E2-D56F-11D2-A1CE-00C0DFEC0B1A")
SCReferenceCollection;
#endif

EXTERN_C const CLSID CLSID_SCReference;

#ifdef __cplusplus

class DECLSPEC_UUID("F916A2F1-D58C-11D2-A1CE-00C0DFEC0B1A")
SCReference;
#endif

EXTERN_C const CLSID CLSID_SCTag;

#ifdef __cplusplus

class DECLSPEC_UUID("27420FB0-CBC3-11D4-8909-00C0DFEC0B1A")
SCTag;
#endif

EXTERN_C const CLSID CLSID_SCTextSegment;

#ifdef __cplusplus

class DECLSPEC_UUID("20AA6891-F664-11D2-A1D7-00C0DFEC0B1A")
SCTextSegment;
#endif

EXTERN_C const CLSID CLSID_SCTextEnum;

#ifdef __cplusplus

class DECLSPEC_UUID("20AA6893-F664-11D2-A1D7-00C0DFEC0B1A")
SCTextEnum;
#endif

EXTERN_C const CLSID CLSID_SCScriptureText;

#ifdef __cplusplus

class DECLSPEC_UUID("20AA6895-F664-11D2-A1D7-00C0DFEC0B1A")
SCScriptureText;
#endif
#endif /* __SCRIPTUREOBJECTSLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
