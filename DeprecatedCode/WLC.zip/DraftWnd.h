/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: DraftWnd.h
Responsibility: David Olson
Last reviewed: Not yet.
 
Description:
	Implements the Scripture drafting window.	
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef DRAFTWND_INCLUDED
#define DRAFTWND_INCLUDED
 

/*----------------------------------------------------------------------------------------------
	The class that displays the draft view.
	@h3{Hungarian: dvc}
----------------------------------------------------------------------------------------------*/
class DraftTextVc : public VwBaseVc
{
private:
	typedef VwBaseVc SuperClass;

public:
	DraftTextVc();
	STDMETHOD(Display)(IVwEnv * pvwenv, HVO hvo, int frag);
	STDMETHOD(EstimateHeight)(HVO hvo, int frag, int dxAvailWidth, int * pdyHeight);
	STDMETHOD(LoadDataFor)(IVwEnv * pvwenv, HVO * prghvo, int chvo, HVO hvoParent,
		int tag, int frag, int ihvoMin);
	void SetDa (CustViewDa * pcda, AfStatusBar * pstbr, UserViewSpec * puvs)
	{
		if (!m_qcda)
		{
			m_qcda = pcda;
			m_qstbr = pstbr;
			m_quvs = puvs;
		}
	}
	void RefreshDisplay();

protected:
	StVcPtr m_qstvc;
	UserViewSpecPtr m_quvs; // used for loading data.
//	HvoSet m_shvoLoaded; // Set of root objects already loaded.
	AfStatusBarPtr m_qstbr; // To report progress in loading data.
	CustViewDaPtr m_qcda; // DA into which to load data when LoadDataFor is called.
};

typedef GenSmartPtr<DraftTextVc> DraftTextVcPtr;

/*----------------------------------------------------------------------------------------------
	The main class that implements the Scripture Drafting window.
	@h3{Hungarian: sdw}
----------------------------------------------------------------------------------------------*/
class SeDraftWnd : public AfVwSplitChild
{
	friend class SeDraftClientWnd;
private:
	typedef AfVwSplitChild SuperClass;

public:
	void MakeRoot(IVwGraphics * pvg, ILgWritingSystemFactory * pwsf, IVwRootBox ** pprootb);
	virtual void OnReleasePtr();
	virtual void PostAttach(void);
protected:
	void RefreshDisplay();
	virtual void HandleSelectionChange(IVwSelection * pvwsel);
	HVO m_hvoScripture;
	CustViewDaPtr m_qcvd;
	IVwStylesheetPtr m_qsty;
	DraftTextVcPtr m_qdvc;
	SeDraftClientWnd * m_pdcwParent; // Don't use a smart pointer, it would make a cycle.
	RecordSpecPtr m_qrsp;

	// For (dis)enabling the state of the toolbar buttons.
	virtual bool CmsCharFmt(CmdState & cms);
	// For displaying TE specific Styles Dialog
	virtual bool OpenFormatStylesDialog(HWND hwnd, bool fCanDoRtl, bool fOuterRtl,
		IVwStylesheet * past, TtpVec & vqttpPara, TtpVec & vqttpChar, bool fCanFormatChar,
		StrUni * pstuStyleName, bool & fStylesChanged, bool & fApply, bool & fReloadDb);

};

typedef GenSmartPtr<SeDraftWnd> SeDraftWndPtr;

/*----------------------------------------------------------------------------------------------
	This forms the main body of the Scripture Drafting window. It supports a horizontal splitter
	bar. The superclass does most of the work; we just have to know how to create a child window.
	@h3{Hungarian: dcw} 
----------------------------------------------------------------------------------------------*/
class SeDraftClientWnd : public AfSplitterClientWnd
{
	friend class SeDraftWnd;
	typedef AfSplitterClientWnd SuperClass;
public:
	SeDraftClientWnd() {}
	virtual void OnReleasePtr();
	virtual void CreateChild(AfSplitChild * psplcCopy, AfSplitChild ** psplcNew);
	virtual void RefreshDisplay();
	void Init(CustViewDaPtr pcvd, HVO hvoScripture, IVwStylesheet * psty)
	{
		m_qcvd = pcvd;
		m_hvoScripture = hvoScripture;
		m_qsty = psty;
	}
#ifdef NEED_CREATE_METHOD
	void Create();
#endif
	void Refresh(void);

protected:
	HVO m_hvoScripture; // root object
	CustViewDaPtr m_qcvd; // access to the database
	IVwStylesheetPtr m_qsty;
};

typedef GenSmartPtr<SeDraftClientWnd> SeDraftClientWndPtr;


#endif //!DRAFTWND_INCLUDED
