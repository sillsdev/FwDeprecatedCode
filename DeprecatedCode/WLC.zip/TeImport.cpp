/*----------------------------------------------------------------------------------------------
Copyright 2000-2002, SIL International. All rights reserved.

File: TeImport.cpp
Responsibility: Bryan Wussow
Last reviewed: never

Description:
	This file contains the classes for Scripture Import.
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop

//#include "Vector_i.cpp"

#undef THIS_FILE
DEFINE_THIS_FILE


/*----------------------------------------------------------------------------------------------
	ImportStyleProxy class 
	Objects of this class represent a style (real or potential) that is mapped to
	an import tag. A hash map (eg m_hmstuisy) owns these proxies and provides the mapping.

	Note on implementation of end markers:
	For proxies that represent a char style or a footnote start, an end marker may optionally 
	be saved in the proxy's member variables. In addition, another proxy is created for the 
	end marker itself, for the only purpose of identifying the marker as a kittEndMarker.
----------------------------------------------------------------------------------------------*/

// Constructor
ImportStyleProxy::ImportStyleProxy(StrUni stuStyleName, int nStyleType, int ws,
	   ImportTagType ittTagType /*kittGeneral*/)
{
	Assert(0 <= ittTagType && ittTagType < kittLim);
	Assert(s_psts); // stylesheet

	if (ittTagType != kittEndMarker)
	{
		Assert(stuStyleName.Length() > 0);
		Assert(0 <= nStyleType && nStyleType < kstLim);
		Assert(ws);

		HRESULT hr;
		int nTypeFromStyle;
		//ENHANCE BryanW: GetType could be redesigned to use a hashmap rather than a linear search 
		// and/or return S_FALSE if the style name is not in the stylesheet
		// Right now GetStyleRgch is the only function designed to reply with S_FALSE if the
		// style name is not in the stylesheet
		// hr = s_psts->GetType(stuStyleName.Bstr(), & nTypeFromStyle); // can throw exception
		ITsTextPropsPtr qttpBogus;
		hr = s_psts->GetStyleRgch(stuStyleName.Length(), 
			const_cast<OLECHAR *>(stuStyleName.Chars()), &qttpBogus);
		if (hr == S_OK) //if stylesheet has stuStyleName
		{
			CheckHr(s_psts->GetType(stuStyleName.Bstr(), & nTypeFromStyle));
			m_fUnknownMapping = false;
			if ( nTypeFromStyle != nStyleType) //if char/para type mismatch
			{
				nStyleType = nTypeFromStyle; // char/para from the style is what we'll use
				//s_fTypeOverride = true; // need to remember?
			}
		}
		else // stylesheet does not have stuStyleName
			m_fUnknownMapping = true;
	}
	else
	{	// this proxy represents an end marker - not a style; set bogus info
		stuStyleName = L"End"; //name does not matter
		nStyleType = -1; //bogus type & ws
		ws = 0;
		m_fUnknownMapping = true; //should not be in style sheet, and we won't look there
	}
    
	m_stuStyleName = stuStyleName;
	m_nStyleType = nStyleType;
	m_ws = ws;
	m_ittTagType = ittTagType;

	//set the text property vars for this proxy
	SetTextProps();

	m_stuEndMarker.Clear();
	m_qttpFormat.Clear();
	m_fIsScriptureStyle = true; //default
}

// Set the format vars for this potential style
// used when this is an undefined mapping, to prepare for possibly adding a real style
void ImportStyleProxy::SetFormat(ITsTextProps * pttpFormat, ComBool fIsScriptureStyle)
{
	AssertPtr(pttpFormat);
	m_qttpFormat = pttpFormat;
	m_fIsScriptureStyle = fIsScriptureStyle;
}

// Set the end marker
// used optionally if this is a char style or a footnote start
void ImportStyleProxy::SetEndMarker(SmartBstr & sbstrEndMarker)
{
	Assert (m_nStyleType == kstCharacter || m_ittTagType == kittStartOfFootnote);
	m_stuEndMarker = sbstrEndMarker.Chars();
}

// Map this proxy (defined or undefined mapping) to the given style name
// used when user edits the mapping table (chooses from list, or types a stylename)
//void ImportStyleProxy::MapToStyle(StrUni stuStyleName)
//how can user select encoding???
/*void ImportStyleProxy::MapToStyle(StrUni stuStyleName, int ws) 
{
	Assert(stuStyleName.Length() > 0);
	Assert(ws);

	// call new private function, which also implements the constructor
	// we default the type to kstParagraph in case the stylename is not in stylesheet
	InitProxy(stuStyleName, kstParagraph, ws);
}*/

// GetTextProps gets the text property vars for this proxy. Used during import processing.
// if this proxy is an undefined mapping, create a new style and declare the proxy now mapped
void ImportStyleProxy::GetTextProps(ITsTextProps ** ppttpForTss, StrAnsi & staParaProps)
{
	AssertPtr(ppttpForTss);

	*ppttpForTss = m_qttpForTss;
	AddRefObj(*ppttpForTss);

	staParaProps = m_staParaProps;

	if (m_fUnknownMapping && m_ittTagType != kittEndMarker)
	{
		AddStyleToStylesheet();
		m_fUnknownMapping = false;
	}
}

// SetTextProps sets the text property vars for this proxy, from the name, type, & ws
// Used by constructor
void ImportStyleProxy::SetTextProps()
{
	if (m_ittTagType == kittEndMarker)
	{	// props are not relevant for end markers
		m_qttpForTss.Clear();
		m_staParaProps.Clear();
		return;
	}

	Assert(m_stuStyleName.Length() > 0);
	Assert(0 <= m_nStyleType && m_nStyleType < kstLim);
	Assert(m_ws);
	
	// our objective is to initialize these:
	//	ITsTextPropsPtr m_qttpForTss; // textprops for tsstring
		// (for char style, contains ws & char style name; for para style contains ws only)
	//	StrAnsi m_staParaProps; // serialized bytes for textprops for paragraph
		// (for char style, empty; for para style contains para style name)

	ITsPropsBldrPtr qtpb;
	qtpb.CreateInstance(CLSID_TsPropsBldr);
	// set m_qttpForTss
	CheckHr(qtpb->SetIntPropValues(ktptWs, ktpvDefault, m_ws));
	if (m_nStyleType == kstCharacter)
		CheckHr(qtpb->SetStrPropValue(ktptNamedStyle, m_stuStyleName.Bstr()));	
	CheckHr(qtpb->GetTextProps(&m_qttpForTss));
	// set m_staParaProps
	if (m_nStyleType == kstParagraph)
	{
		CheckHr(qtpb->SetIntPropValues(ktptWs, -1, -1)); // remove ws/ows info
		CheckHr(qtpb->SetStrPropValue(ktptNamedStyle, m_stuStyleName.Bstr()));
		ITsTextPropsPtr qttp;
		CheckHr(qtpb->GetTextProps(&qttp));
		byte rgbFmtBuf[kcbFmtBufMax];
		int nBytes;
		CheckHr(qttp->SerializeRgb(rgbFmtBuf, kcbFmtBufMax, &nBytes));
		m_staParaProps.Assign((char*)rgbFmtBuf, nBytes);
	}
	else
		m_staParaProps.Clear();
}

// Add a new real style in the stylesheet for this proxy.
void ImportStyleProxy::AddStyleToStylesheet()
{
	Assert(m_fUnknownMapping); // the only reason to add a style is if proxy is unmapped
	Assert(m_ittTagType != kittEndMarker);

	// If m_qttpFormat has not been set up, initialize it now
	if (!m_qttpFormat)
	{
		ITsPropsBldrPtr qtpb;
		qtpb.CreateInstance(CLSID_TsPropsBldr);
		CheckHr(qtpb->GetTextProps(&m_qttpFormat)); // default properties
	}

	// Get an hvo for the new style
	HVO hvoStyle;
	CheckHr(s_psts->MakeNewStyle(&hvoStyle));

	// PutStyleRgch() adds the style to the stylesheet
	// we'll give it the properties we are aware of
	//TODO BryanW: if it's a missing factory style, somehow set the correct style id
	CheckHr(s_psts->PutStyleRgch(m_stuStyleName.Length(),	
		const_cast<OLECHAR *>(m_stuStyleName.Chars()), 
		hvoStyle, 0, hvoStyle, m_nStyleType, 
		m_fIsScriptureStyle, false, false, m_qttpFormat));
}

//static member & set function

IVwStylesheet * ImportStyleProxy::s_psts = NULL; // define static member in file scope

// must call SetStylesheet before you construct ImportStyleProxy(s)
void ImportStyleProxy::SetStylesheet (IVwStylesheet * psts)
{
	AssertPtr(psts);
	s_psts = psts;
}




/*----------------------------------------------------------------------------------------------
	ScriptureImporter class exists purely to implement the ImportScripture method. 
	It allows us to break up the logic and allow the various sub-methods to share access 
	to state data.
	TODO RonM(TomB): Implement incremental loading.
----------------------------------------------------------------------------------------------*/
// Constructor
ScriptureImporter::ScriptureImporter(StrUni stuSettingsFile, StrUni stuStartRef, 
	StrUni stuEndRef, SeMainWnd * ptmw)
{
	m_stuSettingsFile = stuSettingsFile;
	m_stuStartRef = stuStartRef;
	m_stuEndRef = stuEndRef;
	m_ptmwMainWnd = ptmw;
}

// Initialize the scripture importer
void ScriptureImporter::Initialize()
{
	// Get a CustViewDa we can write to.
	m_pwlpi = m_ptmwMainWnd->GetSeLpInfo();
	AssertPtr(m_pwlpi);
	m_pwlpi->GetDataAccess(&m_qcda);
	m_qode = m_qcda->GetOleDbEncap();
	// and other fundamental info
	m_hvoScripture = m_pwlpi->GetHvoScripture();
	Assert(m_hvoScripture);
	m_ptsts = m_pwlpi->GetScriptureStylesheet();
	m_wsVern = m_pwlpi->VernWs();
	m_wsAnal = m_pwlpi->AnalWs();

#define TESTPROXYxx
#ifdef TESTPROXY
// test new import proxies
SmartBstr sbstrName0;
SmartBstr sbstrName1 = L"Tom Bogle"; //not normally in style sheet
SmartBstr sbstrName2 = L"Todd Jones"; //not normally in style sheet
// first clean up styles added previously by testproxy
// must count down to avoid skipping a style after we delete one from vector
for (int istyle = m_ptsts->GetStyles().Size(); --istyle >= 0 ; )
{
	HVO hvo = m_ptsts->GetStyles()[istyle].hvo;
	CheckHr(m_qcda->get_UnicodeProp(hvo, kflidStStyle_Name, &sbstrName0));
	if (sbstrName0.Equals(sbstrName1))
		m_ptsts->Delete(hvo);
	else if (sbstrName0.Equals(sbstrName2))
		m_ptsts->Delete(hvo);
}
// now test import proxies
ImportStyleProxy::SetStylesheet(m_ptsts);
ImportStyleProxyPtr qisy1, qisy2;
qisy1.Attach(NewObj ImportStyleProxy(L"Section Heading", kstParagraph, m_wsVern));
qisy2.Attach(NewObj ImportStyleProxy(sbstrName1.Chars(), kstParagraph, m_wsVern)); //not mapped
ImportStyleProxy isy3(L"Verse Number", kstCharacter, m_wsVern); //char style
ImportStyleProxy isy4(L"Chapter Number", kstParagraph, m_wsVern); //override as char style
ImportStyleProxy isy5(sbstrName2.Chars(), kstParagraph, m_wsVern); //not mapped
ImportStyleProxy isy6(L"Xnote", kstParagraph, m_wsVern, kittStartOfFootnote); //not mapped
SmartBstr sb = L"f*";
isy6.SetEndMarker(sb);
ImportStyleProxy isy7(L"Xnote*", 0, 0, kittEndMarker); //not mapped
Assert(!qisy1->IsUnknownMapping());
Assert( qisy2->IsUnknownMapping());
Assert(!isy3.IsUnknownMapping());
Assert(!isy4.IsUnknownMapping());
Assert( isy5.IsUnknownMapping());
if (qisy2->IsUnknownMapping())
{	//set formatting
	ITsTextPropsPtr qttpFormat;
	ITsPropsBldrPtr qtpb;
	qtpb.CreateInstance(CLSID_TsPropsBldr);
	CheckHr(qtpb->SetIntPropValues(ktptItalic, ktpvEnum, kttvOn));
	CheckHr(qtpb->GetTextProps(&qttpFormat));
	qisy2->SetFormat(qttpFormat, true); // T = for published text
}
ITsTextPropsPtr qttpZ;
StrAnsi sta;
qisy1->GetTextProps(&qttpZ, sta);
qisy2->GetTextProps(&qttpZ, sta); // creates new style if unmapped
isy3.GetTextProps(&qttpZ, sta);
isy4.GetTextProps(&qttpZ, sta);
isy5.GetTextProps(&qttpZ, sta); // creates new style if unmapped, without benefit of SetFormat
// now proxies 2 & 5 are mapped to a real style
Assert(!qisy2->IsUnknownMapping());
Assert(!isy5.IsUnknownMapping());
// verify style type, tag type, end marker info
Assert(isy3.StyleType() == kstCharacter); //overridden as char style
isy6.GetTextProps(&qttpZ, sta); // may add new style
Assert(isy6.TagType() == kittStartOfFootnote);
Assert(isy6.EndMarker() == L"f*");
isy7.GetTextProps(&qttpZ, sta); // should not add new style
Assert(isy7.TagType() == kittEndMarker);
Assert(isy7.IsUnknownMapping()); // end marker is never mapped
#endif // TESTPROXY

	// Validate that our required styles are in the stylesheet
	//TODO BryanW validate that our reqd style ids are in the stylesheet
	// (possibly with localized names). Otherwise our db needs repair.

	// Clear from the cache all properties owned by Scripture
	int chvoBooks;
	CheckHr(m_qcda->get_VecSize(m_hvoScripture, kflidScripture_ScriptureBooks, &chvoBooks));
	HVO hvoBook;
	for (int ihvo = 0; ihvo < chvoBooks; ihvo++)
	{
		CheckHr(m_qcda->get_VecItem(m_hvoScripture, kflidScripture_ScriptureBooks, ihvo,
			&hvoBook));
		CheckHr(m_qcda->ClearInfoAbout(hvoBook, true));
	}

	// Load paratext ScriptureText object and create some SCReferences
	m_qsso.CreateInstance(CLSID_SCScriptureText);
	CheckHr(m_qsso->Load(m_stuSettingsFile.Bstr()));
	ComSmartPtr<ISCReference> qscrStart;
	qscrStart.CreateInstance(CLSID_SCReference);
	ComSmartPtr<ISCReference> qscrEnd;
	qscrEnd.CreateInstance(CLSID_SCReference);
	ComSmartPtr<ISCReference> qscrName;
	qscrName.CreateInstance(CLSID_SCReference);

	// REVIEW RonM (TomB): m_stuStartRef and m_stuEndRef are only book names at this point.
	// When we have a spec, we will know whether we need to allow for chapters and maybe
	// verses to be specified in the Import dialog.
	// The starting reference is 0:0 to get the front matter of the book

	// Initialize qscrStart to beginning of book
	m_stuStartRef.Append(L" 0:0");
	CheckHr(qscrStart->Parse(m_stuStartRef.Bstr()));

	// Initialize qscrEnd to the last verse of the last chapter of the book
	// REVIEW RonM (TomB): This probably needs to change if/when we allow the user to
	// specify a range of chapters/references.
	short nLastChapter, nLastVerse;
	CheckHr(qscrEnd->Parse(m_stuEndRef.Bstr()));
	CheckHr(qscrEnd->get_LastChapter(&nLastChapter));
	CheckHr(qscrEnd->put_Chapter(nLastChapter));
	CheckHr(qscrEnd->get_LastVerse(&nLastVerse));
	CheckHr(qscrEnd->put_Verse(nLastVerse));

	// Now initialize the TextEnum with the range of scripture text we want
	CheckHr(m_qsso->TextEnum(qscrStart, qscrEnd,
		(SCTextType)(0), //scTitle | scSection | scVerseText | scNoteText | scOther),
		(SCTextProperties)0, &m_qsteTextEnum));

	// create the text segment we will use to get the data.
	CheckHr(CoCreateInstance(CLSID_SCTextSegment, NULL, CLSCTX_ALL, __uuidof(ISCTextSegment), (void **)&m_psctsTextSeg));


#define USEHMISY
#ifdef USEHMISY

	// Load the import mappings from the database
	ImportStyleProxy::SetStylesheet(m_ptsts);
	m_hmstuisy.Clear();
	LoadImportMappings();

	// ValidateImportMappings()
	//TODO BryanW: do we need to validate that certain mappings are in the hashmap?
	// (possibly with localized names). Otherwise our db needs repair?
	// or can the user modify/delete any factory mapping?
	// bool fHaveChapterNumber = false;
	// bool fHaveVerseNumber = false;
	// bool fHaveBookTitle = false;
	// bool fHaveSectionHead = false;
	// Assert(fHaveBookTitle); //TODO BryanW: how should we handle a missing factory mapping?
	// TODO BryanW: we probably should verify that the style name in each mapping does or 
	//  does not exist in the stylesheet, and update m_fUnknownMapping and other properties

	// ScanSOMappings  this could be a separate function?
	// Iterate through the ScriptureText's list of tags
	//  to add new markers and override special attributes
	ComSmartPtr<ISCTag> qsctTag;
	SCTextProperties sctpTextProps;
	SCTextType scttTextType;
	SCStyleType scstStyleType;

	SmartBstr sbstrMarker, sbstrName;
	StrUni stuTag;
	ImportStyleProxyPtr qisyProxy;
	bool fInMap;
	bool fUnknownMappingAdded = false;
	for (int iscTag = 0; ; iscTag++) // for every tag in ScriptureText
	{
		CheckHr(m_qsso->NthTag(iscTag, &qsctTag));
		if (!qsctTag) // if no more tags
			break;
		// get the Marker of this tag
		CheckHr(qsctTag->get_Marker(&sbstrMarker));
		stuTag = sbstrMarker.Chars();
		// get other properties of this tag
		CheckHr(qsctTag->get_TextProperties(&sctpTextProps));
		CheckHr(qsctTag->get_TextType(&scttTextType));
		CheckHr(qsctTag->get_Name(&sbstrName));
		CheckHr(qsctTag->get_StyleType(&scstStyleType));

		// set our import tag type, style type, writing system
		ImportTagType ittTagType = kittGeneral;
		if (sctpTextProps & scBook)
										ittTagType = kittStartOfBook;
		else if (sctpTextProps & scChapter)
										ittTagType = kittStartOfChapter;
		else if (sctpTextProps & scVerse)
										ittTagType = kittVerseNumber;
										// also treat this a verse text
		else if (scttTextType & scTitle)
										ittTagType = kittTitleText;
		else if (scttTextType & scSection)
										ittTagType = kittSectionHeadText;
		else if (scttTextType & scVerseText)
										ittTagType = kittVerseText;
		else if (sctpTextProps & scNote ||
				scstStyleType == scNoteStyle)
										ittTagType = kittStartOfFootnote;
/*		else if (scttTextType & scNoteText &&
				scstStyleType == scParagraphStyle)
										ittTagType = kittFootnoteAddlPara; */
		else if (scstStyleType == scEndStyle)
										ittTagType = kittEndMarker;

		// set our style type, writing system
		int nStyleType, nEncoding;
		if (ittTagType == kittStartOfFootnote) // possibly a styletype scNoteStyle
			nStyleType = kstParagraph; //we will set props as a para style
		else if (ittTagType == kittEndMarker)
			nStyleType = -1; //bogus styletype for end marker
		else //for most styles
			nStyleType = (scstStyleType == scParagraphStyle) ? kstParagraph : kstCharacter;
		nEncoding = (sctpTextProps & scVernacular) ? m_wsVern : m_wsAnal;
		//note that for kittEndMarker, styleType & writing system will be ignored
		//REVIEW BryanW: we should probably support char style text inheriting its ws from the para
		/*if (sctpTextProps & scVernacular)
			nEncoding = m_wsVern;
		else if (sctpTextProps & scNonvernacular)
			nEncoding = m_wsAnal;
		else nEncoding = 0; // need to handle this
		*/

		// is this marker already in the hash map of proxies?
		fInMap = m_hmstuisy.Retrieve(stuTag, qisyProxy);
		if (!fInMap)
		{
			// we will add a new proxy
			// but in some cases, first override the name
			if (sbstrName.Length() == 0)
				sbstrName = stuTag; // use tag for style name if no name is in stylesheet.
			// TODO BryanW: The following exceptions should be handled when displaying map list and when 
			// processing import, not here really. Actually, they should be handled as a special case by
			// the ScriptureObjects. Should be marked in stylesheet as a "system" style or something.
			{ // Remove this block when handled properly.
				if (stuTag.Equals(L"id"))
					sbstrName = L"(id)"; // minimal name, data not imported as styled text
				if (stuTag.Equals(L"h"))
					sbstrName = L"(h)";  // minimal name, data not imported as styled text
			}

			// add a new proxy to the hash map
			qisyProxy.Attach(NewObj ImportStyleProxy(sbstrName.Chars(), nStyleType, nEncoding,
				ittTagType));
			m_hmstuisy.Insert(stuTag, qisyProxy);

			// set formatting of this new proxy if needed (unmapped)
			if (qisyProxy->IsUnknownMapping() //if name is not in stylesheet
				&& ittTagType != kittEndMarker) // and this is not an endmarker
			{	
				fUnknownMappingAdded = true;
				//set formatting info in proxy
				ITsTextPropsPtr qttpFormat;
				ITsPropsBldrPtr qtpb;
				qtpb.CreateInstance(CLSID_TsPropsBldr);
				//TODO BryanW: need to get formatting from scTag
				CheckHr(qtpb->SetIntPropValues(ktptItalic, ktpvEnum, kttvOn)); //italic for now
				CheckHr(qtpb->GetTextProps(&qttpFormat));
				bool fPublishableText = (sctpTextProps & scPublishable ? true : false);
				qisyProxy->SetFormat(qttpFormat, fPublishableText);
			}
		}
		else // fInMap is TRUE; this marker is already in hashmap
		{
			if (qisyProxy->IsUnknownMapping()) //if name is not in stylesheet
			{	
				// this scTag marker matches an existing but unmapped proxy
				// so let's see if the tag now has a name we can successfully map to
				// if( ittTagType != kittEndMarker) // not an endmarker
				//	MapToStyle(sbstrName.Chars(), nStyleType, nEncoding, ittTagType)
			}
			else
			{
				// REVIEW BryanW: Dare we even consider updating an existing valid mapping,
				//  possibly a factry mapping, if the scTag has a different name?
				//  but not if the different name is not in the stylesheet?
				//  If we update/override under a long list of conditions, it will become
				//  difficult for consultants to figure out what is going on as they set up
				//  an import.
				//  Also we don't want to undo now items like Book Title, Section Head,
				//  Chapter, Verse that are set by override, not from the scTag; so
				//  consider if this code, if any, needs to be an elseif after the overrides
			}
		}

		// Save the end marker of the scTag, if appropriate
		//note: if map is stored in db, this will override the stored end marker
		if (nStyleType == kstCharacter || ittTagType == kittStartOfFootnote)
		{
			SmartBstr sbstrEndMarker;
			CheckHr(qsctTag->get_Endmarker(&sbstrEndMarker));
			if (sbstrEndMarker.Length())
				qisyProxy->SetEndMarker(sbstrEndMarker);
		}

		// Override certain mappings, based on special tag properties
		//  note: while we could do these overrides while processing segments, doing them now
		//  makes the overrides visible to the user when he sees the list of mappings
		if (ittTagType == kittTitleText)
		{
		// TODO BryanW: override Title stuff per spec
			if (sctpTextProps & scLevel_1)
				;
				//qisyProxy->MapToStyle(L"Book Title", nStyleType, nEncoding, ittTagType)
				// needs to update the proxy's style name, text props, etc
			else
				;
				//qisyProxy->MapToStyle(L"Book Title Secondary Text", nStyleType, nEncoding, ittTagType)
		}
		// TODO BryanW: what if name is localized differently?
		// need to map to the style id here, rather than the name!
		// if we validated the stylesheet earlier, the reqd styles already exist
		// TODO BryanW: override Section Head per spec
		// TODO BryanW: override Chapter Number per spec
		// TODO BryanW: override Verse Number per spec
 	}
	int n;
	n = m_hmstuisy.Size();

	// The mapping table is now ready for display to the user, if desired
	//  that code must enforce the same special rules applied by "Override Certain Mappings" above

	// Init member vars for special paragraph styles
	ITsTextPropsPtr qttpA;

	stuTag = L"mt"; //TODO BryanW: find the proxy by style id, rather than tag or tag type
	fInMap = m_hmstuisy.Retrieve(stuTag, qisyProxy);
	Assert(fInMap);
	qisyProxy->GetTextProps(&qttpA, m_staBookTitleParaProps);
	Assert(qisyProxy->TagType() == kittTitleText);

	stuTag = L"s"; //TODO BryanW: find the proxy by style id, rather than tag or tag type
	fInMap = m_hmstuisy.Retrieve(stuTag, qisyProxy);
	Assert(fInMap);
	qisyProxy->GetTextProps(&qttpA, m_staSectionHeadParaProps);
	Assert(qisyProxy->TagType() == kittSectionHeadText);

	stuTag = L"p"; //TODO BryanW: find the proxy by style id, rather than tag or tag type
	fInMap = m_hmstuisy.Retrieve(stuTag, qisyProxy);
	Assert(fInMap);
	qisyProxy->GetTextProps(&qttpA, m_staDefaultParaProps);
	//Assert(qisyProxy->TagType() == kittVerseText); //TODO BryanW: prob need to get the itt set properly

#endif //USEHMISY

	// Build generic character props for use with different runs of text.
	ITsPropsBldrPtr qtpb;
	qtpb.CreateInstance(CLSID_TsPropsBldr);
	// analysis character props
	CheckHr(qtpb->SetIntPropValues(ktptWs, ktpvDefault, m_wsAnal));
	CheckHr(qtpb->GetTextProps(&m_qttpAnal));
	// vernacular character props
	CheckHr(qtpb->SetIntPropValues(ktptWs, ktpvDefault, m_wsVern));
	CheckHr(qtpb->GetTextProps(&m_qttpVern));

#define oldtitlestuff
#ifdef oldtitlestuff
	// eliminate this section when title processing gets updated
	StrUni stuStyleName = L"Book Title Secondary";
	CheckHr(qtpb->SetStrPropValue(ktptNamedStyle, stuStyleName.Bstr()));
	CheckHr(qtpb->GetTextProps(&m_qttpTitleSecondaryText));
	// remove writing system and old writing system because it's not appropriate for paragraphs
	CheckHr(qtpb->SetIntPropValues(ktptWs, -1, -1));
	ITsTextPropsPtr qttp;
	//Book Title para style
	stuStyleName = L"Book Title";
	CheckHr(qtpb->SetStrPropValue(ktptNamedStyle, stuStyleName.Bstr()));
	CheckHr(qtpb->GetTextProps(&qttp));
	CheckHr(qttp->SerializeRgb(m_rgbBookTitleFmt, kcbFmtBufMax,
		&m_cbBookTitleFmtSize));
#endif

	// Our string factory
	m_qtsf.CreateInstance(CLSID_TsStrFactory);

	// Make a string builder. We will keep re-using this every time we build a paragraph.
	CheckHr(m_qtsf->GetBldr(&m_qtsbPara));

	// Clear other vars used to build the current paragraph
	m_chParaFinalChar = 0;
	m_cchTsbPara = 0;
	//m_sbstrRunText.Clear();
	//m_qttpRunProps = NULL;

#ifdef ALLOW_SOME_EMPTY_PARAGRAPHS
	m_fSuppressEmptyPara = true;
#endif

	// Init status vars
	m_staCurrentParaProps.Clear();
	m_fInSectionHeading = false;
	m_fInCharStyleWEnd = false;
	m_stuCharStyleEndMarker.Clear();
	m_fInFootnote = false;
	m_stuFootnoteEndMarker.Clear();
	m_fVersePara = false;
	m_fVerseNumFoundInPara = false;
	m_nParaStartRefFirst = m_nParaStartRefLast = 0;
	m_nPrevVerseFirst = m_nPrevVerseLast = 0;
	m_nBookNumber = 0;
	m_nChapter = 0;
	// TODO RonM(TomB): for incremental load these need to be figured out based on
	// what is in the database and what we are importing! We may also need to do
	// something about deleting stuff that is being replaced...or merging...do we
	// want to try to re-use any HVOs?
	m_hvoBook = 0;
	m_hvoSection = 0;
	m_hvoTitle = 0;
	m_iSection = 1;
#ifndef JR_PERFORMANCE_TEST
  	m_iPara = 1;
  	m_iTitlePara = 1;
#else
	m_hvoParaPrev = 0;
	m_hvoTitleParaPrev = 0;
#endif
	m_nSectionStartRef = 0;
}


// Load the import mappings from the database
void ScriptureImporter::LoadImportMappings()
{
#define SETUPFACTORYMAPPINGS // define to produce a clean default mapping instead of loading from db
#ifdef SETUPFACTORYMAPPINGS //move this to a separate function
	StrUni stuTag;
	ImportStyleProxyPtr qisyProxy;

	stuTag = L"p";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Paragraph", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"m";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Paragraph Continuation", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"inp";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Quote", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"inm";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Quote Continuation", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"q";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Poetry 1", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"q2";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Poetry 2", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"q3";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Poetry 3", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"qc";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Poetry Centered", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"c";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Chapter Number", kstCharacter, m_wsVern,
		kittStartOfChapter));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"v";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Verse Number", kstCharacter, m_wsVern,
		kittVerseNumber));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"mt";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Book Title", kstParagraph, m_wsVern,
		kittTitleText));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"st"; // chg to character style
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Book Title Secondary", kstCharacter, m_wsVern,
		kittTitleText));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"st2"; // maps to same style  // chg to character style
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Book Title Secondary", kstCharacter, m_wsVern,
		kittTitleText));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"st3"; // maps to same style  // chg to character style
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Book Title Secondary", kstCharacter, m_wsVern,
		kittTitleText));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	stuTag = L"s";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Section Heading", kstParagraph, m_wsVern, 
		kittSectionHeadText));
	m_hmstuisy.Insert(stuTag, qisyProxy);

	// ss? sss?

	stuTag = L"r";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Section Cross Reference", kstCharacter, m_wsVern, 
		kittSectionHeadText));
	m_hmstuisy.Insert(stuTag, qisyProxy);
	
	// h  Header?

	stuTag = L"ip";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Background Paragraph", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);
	
	stuTag = L"is";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Background Section Heading", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);
	
	stuTag = L"iot"; // maps to same style
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Background Section Heading", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);
	
	stuTag = L"io1";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Background Outline 1", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);
	
	stuTag = L"io2";
	qisyProxy.Attach(NewObj ImportStyleProxy(L"Background Outline 1", kstParagraph, m_wsVern));
	m_hmstuisy.Insert(stuTag, qisyProxy);
#endif // end SETUPFACTORYMAPPINGS
}


// Main loop to get and process each scripture text segement
void ScriptureImporter::MainLoop()
{
	BOOL fGotSeg;
	CheckHr(m_qsteTextEnum->Next(&m_psctsTextSeg, &fGotSeg));
	while (fGotSeg)
	{
		// Get the body text of the token and its properties.
		CheckHr(m_psctsTextSeg->get_Text(&m_sbstrSegmentText));
		CheckHr(m_psctsTextSeg->get_TextType(&m_scttTextType));
		CheckHr(m_psctsTextSeg->get_Tag(&m_qsctTag));
		CheckHr(m_qsctTag->get_TextProperties(&m_sctpTextProps));
		CheckHr(m_qsctTag->get_StyleType(&m_scstStyleType));
		CheckHr(m_qsctTag->get_Marker(&m_sbstrMarker));

		ProcessSegment();
		CheckHr(m_qsteTextEnum->Next(&m_psctsTextSeg, &fGotSeg));
	}
}


// Process this scripture text segment 
void ScriptureImporter::ProcessSegment()
{
	// get the Import Proxy for this segment, and its import properties
	StrUni stuTag = m_sbstrMarker.Chars();
	ImportStyleProxyPtr qisyProxy;
	bool fInMap;
	fInMap = m_hmstuisy.Retrieve(stuTag, qisyProxy);
	Assert(fInMap);  //TODO BryanW: handle error
	ImportTagType ittTagType = qisyProxy->TagType();

	if (ittTagType == kittEndMarker)
	{
		// Process char style end marker
		if (m_fInCharStyleWEnd && stuTag == m_stuCharStyleEndMarker)
		{
			m_fInCharStyleWEnd = false; //terminate the char style
			//Add the text to the current paragraph or footnote, without the char style props
			//TODO BryanW: for back transl, prob need qttpAnal
			if(m_fInFootnote)	
				AddTextToFootnote(m_sbstrSegmentText, m_qttpVern);
			else
				AddTextToPara(m_sbstrSegmentText, m_qttpVern);
			return;
		}
		// Process footnote end marker
        if (m_fInFootnote && stuTag == m_stuFootnoteEndMarker)
		{
			m_fInCharStyleWEnd = false; //terminate any current char style
			EndFootnote(); // terminate footnote, clear m_fInFootnote
			// Add the text to the current paragraph
			//TODO BryanW: for back transl, prob need qttpAnal
			AddTextToPara(m_sbstrSegmentText, m_qttpVern);
			return;
		}
		// if end marker does not match either one we're looking for, ignore the marker
		//TODO BryanW: ideally, repeat ttp of previous run rather than use vern
		if(m_fInFootnote)	
			AddTextToFootnote(m_sbstrSegmentText, m_qttpVern);
		else
			AddTextToPara(m_sbstrSegmentText, m_qttpVern);
		return;
	}

	// get the styletype & text properties from the proxy
	int nStyleType = qisyProxy->StyleType();
	ITsTextPropsPtr qttpForTss;
	StrAnsi staParaProps;
	qisyProxy->GetTextProps(&qttpForTss, staParaProps);

	// this tag terminates char style run, whether para style, char style, or footnote
	m_fInCharStyleWEnd = false; 
	// assume we need to insert the text at the end of this method
	bool fInsertSegment = true;

	// Book
	if (ittTagType == kittStartOfBook)
	{
		// segment is the beginning of a new book
		MakeParagraph(); // add any previously encountered paragraph to the database.
#ifdef ALLOW_SOME_EMPTY_PARAGRAPHS
		m_fSuppressEmptyPara = true;
#endif
		// Determine current Book number
		// for now we rely on a kittStartOfBook tag to come from the TextEnum as the first tag
		// of every book.
		// m_nBookNumber must be set before we can do MakeBook() etc.
		ComSmartPtr<ISCReference> qscrCurrent;
		qscrCurrent.CreateInstance(CLSID_SCReference);
		CheckHr(m_psctsTextSeg->get_FirstReference(&qscrCurrent));
		CheckHr(qscrCurrent->get_Book(&m_nBookNumber));

		m_hvoBook = m_hvoTitle = 0; // this forces creation of new book
		m_fInSectionHeading = false;
		m_iSection = 1;
		m_nChapter = 0;
		m_nPrevVerseFirst = m_nPrevVerseLast = 0;
	}
	
	// Chapter
	if (ittTagType == kittStartOfChapter)
	{
		// segment is the beginning of a new chapter; no text number provided
		if (m_fInFootnote)
			EndFootnote(); // any current footnote is terminated
		MakeParagraph(); // finish up any accumulated paragraph, start a new one
		m_nPrevVerseFirst = m_nPrevVerseLast = 0;
		m_staCurrentParaProps = m_staDefaultParaProps; // set paragraph style property for new para

		// Make token for the chapter number
		// TODO RonM(TomB): If/when TextSegment object is modified to return
		// actual chapter number as a separate text parameter, just use it and remove
		// the following code that attempts to rebuild the chapter number. This
		// existing approach won't handle weird chapter numbers (e.g., F)
  		ComSmartPtr<ISCReference> qscr;
		CheckHr(m_psctsTextSeg->get_FirstReference(&qscr));
		CheckHr(qscr->get_Chapter(&m_nChapter));
		StrUni stuTemp;
		stuTemp.Format(L"%d", (int)m_nChapter);
		AddTextToPara(stuTemp, qttpForTss);
		MakeParagraph(); // finish up this para
		// TODO BryanW: Chapter numbers should be placed at the start of verse text, not in 
		// a separate paragraph as we do now

#ifdef ALLOW_SOME_EMPTY_PARAGRAPHS
		m_fSuppressEmptyPara = true;
#endif
	}

	// Book Title
	if (ittTagType == kittTitleText)
	{
		// A book title is always a new paragraph
		MakeParagraph(); // finish up any accumulated paragraph, start a new one
		m_staCurrentParaProps = m_staBookTitleParaProps; // set para style property for new para

		if (!m_hvoBook)
		{
			MakeBook();
		}
		// Now insert the current text segment into the title.
		//TODO BryanW: This inserting of title text needs rewriting.
		//  Use section head logic below for a good model.
		int cch = m_sbstrSegmentText.Length();
		if (cch)
		{	
			// Get rid of space at the end of the Paragraph.		
			ComBool fTrailingSpace;
			CheckHr(m_pwlpi->GetCharacterPropertyEngine()->get_IsSeparator(
				*(m_sbstrSegmentText.Chars() + cch - 1), &fTrailingSpace));
			if (fTrailingSpace)
				cch--;

			if (cch)
			{
				ITsTextPropsPtr qttp;
				// Use secondary title character style for any title paragraph lower than
				// level 1
				// TODO BryanW(TomB): Eventually use a single paragraph with hard line
				// breaks (view code can't currently handle this). Also, may need to
				// implement multiple levels rather than just main and secondary since
				// the Scripture Objects can handle 4 levels.
				qttp = (m_sctpTextProps & scLevel_1)? m_qttpVern : m_qttpTitleSecondaryText;
				CheckHr(m_qtsbPara->ReplaceRgch(0, 0, m_sbstrSegmentText.Chars(), cch, qttp));

				CheckHr(m_qtsbPara->GetString(&m_qtssPara));
				// Empty it for next time.
				CheckHr(m_qtsbPara->ReplaceRgch(0, cch, NULL, 0, m_qttpVern));

				Assert(m_hvoTitle); // this will have been created/set by MakeBook.
				HVO hvoTitlePara;

#ifndef JR_PERFORMANCE_TEST
  				AppendParaToDb(m_hvoTitle, m_iTitlePara++, m_rgbBookTitleFmt,
#else
				AppendParaToDb(m_hvoTitle, m_hvoTitleParaPrev, m_rgbBookTitleFmt,
#endif
					m_cbBookTitleFmtSize, hvoTitlePara);
				int nTitleRef = m_nBookNumber * 1000000 + 1000;
				m_pwlpi->ParseNewStTxtPara(hvoTitlePara, m_qtssPara, nTitleRef, nTitleRef);
				// TODO BryanW: eliminate direct calls to Append & Parse above ?
				// To use AddTextToPara(stu, qttpForTss) we'll have to implement a way to handle
				// the m_hvoTitle. Possibly a m_hvoCurrentParaOwner that we set to hvo of
				// title, section head, or section contents. Also ck spec re nTitleRef.
				// Also note that TE displays the title at the beginning of the book,
				// not in the sequence it comes from the scripturetext,
				// so we need to debug what happens if we have multiple title paragraphs
				// though multiple section head paras seems to work okay.

			}
		}
		// don't insert this segment into the body text because it's already been handled.
		fInsertSegment = false;

		// Set the Name property of the book
		// ENHANCE TomB: May want to use running header instead of main title to populate
		// the Name property. Note that if we do that, this code will not be inside this if
		// condition since \h is not of TextType scTitle.
		if (m_sctpTextProps & scLevel_1)
		{
			CheckHr(m_psctsTextSeg->get_Text(&m_sbstrTitle));
			if (m_sbstrTitle.Length())
			{
				// Get rid of space at the end of the name, if not empty.
				StrUni stuName(m_sbstrTitle.Chars());
				int cchName = stuName.Length();
				ComBool fTrailingSpace;
				CheckHr(m_pwlpi->GetCharacterPropertyEngine()->get_IsSeparator(
					(stuName[cchName-1]), &fTrailingSpace));

				if (fTrailingSpace)
					cchName--;
				if (cchName)
				{
					// Execute SQL procedure to set MSA value.
					//exec SetMultiTxt$
					//	@flid int,
					//	@obj int,
					//	@enc int,
					//	@txt nvarchar(4000)
					m_stuSql.Format(L"exec SetMultiTxt$ %d, %d, %d, ?", kflidScrBook_Name,
						m_hvoBook, m_wsVern);
					IOleDbCommandPtr qodc;
					CheckHr(m_qode->CreateCommand(&qodc));
					CheckHr(qodc->SetParameter(1,
						DBPARAMFLAGS_ISINPUT,
						NULL,
						DBTYPE_WSTR,
						(ULONG *)(stuName.Chars()),
						cchName * 2));
					CheckHr(qodc->ExecCommand(m_stuSql.Bstr(), knSqlStmtNoResults));
				}
			}
		}
	}

	// Section Heading
	if (ittTagType == kittSectionHeadText)
	{
		if (!m_fInSectionHeading)
		{
			// A new section heading is always a new paragraph
			// even if this segment is a character style
			if (m_fInFootnote)
				EndFootnote(); // any current footnote is terminated
			MakeParagraph(); // finish up any accumulated paragraph, start a new one
			// set paragraph style property for new section head para
			m_staCurrentParaProps = m_staSectionHeadParaProps;
			
			// This segment is the beginning of a new section.
			MakeSection();
			m_fInSectionHeading = true;
		}
		else
		{	// we have another segement to add to the current section head paragraph
			// TODO BryanW: when view code will support it, we need to insert a new line now, 
			//  instead of a new para
			MakeParagraph();
		}
	}
	else //ittTagType is not kittSectionHeadText
			// (could be a p, v, or anything else; could even be char style or footnote)
	{
		if (m_fInSectionHeading)
		{	// section head para is complete, most likely

			if (ittTagType == kittStartOfFootnote) //handle error
			{
				// footnotes are not supported in section head
				// we will dump it into the section head text, with a warning
				//TODO BryanW: bracket this dump with newlines, rather than new paras
				MakeParagraph(); // prefer newline
				StrUni stuWarning = L"Misplaced footnote: ";
				AddTextToPara(stuWarning, m_qttpAnal);
				AddTextToPara(m_sbstrSegmentText, qttpForTss);
				MakeParagraph(); // prefer newline
				return;
			}

			// section head para is complete, force a new para
			MakeParagraph();  // finish up any accumulated paragraph, start a new one
			// set paragraph style property for new para
			m_staCurrentParaProps = (nStyleType == kstParagraph) ? 
				staParaProps : m_staDefaultParaProps;

			// set status vars so we are ready to add section contents
#ifndef JR_PERFORMANCE_TEST
  			m_iPara = 1; // Next para will be first para of section content
#else
			m_hvoParaPrev = 0; // Next para will be first para of section content
#endif
			m_fInSectionHeading = false;
		}
		// REVIEW BryanW: not sure yet what this is doing
		m_fVersePara |= (m_scttTextType == scVerseText);
	}

	// Footnote
	if (ittTagType == kittStartOfFootnote)
	{
		// any current footnote is terminated so we can start a new one
		if(m_fInFootnote)
			EndFootnote();

		BeginFootnote(staParaProps); //sets m_fInFootnote
		//we'll look for an end marker, though it may not exist
		m_stuFootnoteEndMarker = qisyProxy->EndMarker();
	}
/*	if (ittTagType == kittFootnoteAddlPara)
	{
		AddParaToFootnote(staParaProps);
	} */


	// Verse
    if (ittTagType == kittVerseNumber)
    {
		if (m_fInFootnote)
			EndFootnote(); // any current footnote is terminated

		// Get the reference string in m_stuVerseRef
		GetVerseRef();

		// Now insert the verse number into the paragraph.
		AddTextToPara(m_stuVerseRef, qttpForTss);

		// The segment text usually has some or all of the verse text;
		// strip off any leading space that separates the verse number from the text.
		ComBool fLeadingSpace;
		int cch = m_sbstrSegmentText.Length();
		if (cch)
		{
			CheckHr(m_pwlpi->GetCharacterPropertyEngine()->get_IsSeparator(
				*(m_sbstrSegmentText.Chars()), //first char
				&fLeadingSpace));

			// Insert this verse text into the paragraph with plain properties
			//TODO BryanW: for back transl, prob need qttpAnal
			if (fLeadingSpace)
				AddTextToPara(m_sbstrSegmentText.Chars()+1, cch-1, m_qttpVern);
			else
				AddTextToPara(m_sbstrSegmentText, m_qttpVern);
		}
		fInsertSegment = false; // don't insert again
	}

	// Begin a new paragraph if needed for general stuff
	if (nStyleType == kstParagraph
			&& ittTagType != kittStartOfChapter
			&& ittTagType != kittTitleText
			&& ittTagType != kittSectionHeadText
			&& ittTagType != kittStartOfFootnote)
	{
		if (m_fInFootnote)
			EndFootnote(); // any current footnote is terminated
		// finish up any accumulated paragraph, start a new one
		MakeParagraph(); 
		// set paragraph style props for new para
		m_staCurrentParaProps = staParaProps; 
	}

	// We've processed paragraph start and inserted specially marked text segements above.
    // Insert other marked text, from this segment, into our paragraph (or footnote)
	if (fInsertSegment)
	{
		if(m_fInFootnote)	
			AddTextToFootnote(m_sbstrSegmentText, qttpForTss);
		else
			AddTextToPara(m_sbstrSegmentText, qttpForTss);

		// if we're using a character style, determine if we'll look for an end marker
		if (nStyleType == kstCharacter && qisyProxy->EndMarker().Length())
		{
			m_fInCharStyleWEnd = true;
			m_stuCharStyleEndMarker = qisyProxy->EndMarker();
		}
	}
}


// Get the verse part of the reference from current Scripture segment into m_stuVerseRef
// and set ref status variables if needed
void ScriptureImporter::GetVerseRef()
{
  	ComSmartPtr<ISCReference> qscrFirst;
	ComSmartPtr<ISCReference> qscrLast;
    CheckHr(m_psctsTextSeg->get_FirstReference(&qscrFirst));
	CheckHr(m_psctsTextSeg->get_LastReference(&qscrLast));

	// TODO RonM(TomB): If/when TextSegment object is modified to return
	// actual verse number as a separate text parameter, just use it and remove
	// the following code that attempts to rebuild the verse number. This
	// existing approach won't handle complex verse numbers (e.g., 1-2,5)
	if (!m_nChapter)
		CheckHr(qscrFirst->get_Chapter(&m_nChapter));
 	short sVerseFirst;
	CheckHr(qscrFirst->get_Verse(&sVerseFirst));
    short sSegFirst;
    CheckHr(qscrFirst->get_Segment(&sSegFirst));
    int nVerseFirst = sVerseFirst;
    int nSegFirst = sSegFirst;

    short sVerseLast;
    CheckHr(qscrLast->get_Verse(&sVerseLast));
    short sSegLast;
    CheckHr(qscrLast->get_Segment(&sSegLast));
	if (nSegFirst)
    {
        // Convert nVerseFirst to decimal, nSeg to lowercase alpha
        m_stuVerseRef.Format(L"%d%o", nVerseFirst, nSegFirst);
	}
    else
    {
        // Convert nVerseFirst to decimal
        m_stuVerseRef.Format(L"%d", nVerseFirst);
    }

	if (sVerseFirst != sVerseLast || sSegFirst != sSegLast)
	{
		StrUni stuTemp;
		int nVerseLast = sVerseLast;
		int nSegLast = sSegLast;
		if (nSegLast)
		{
			// Convert nVerseLast to decimal, nSeg to lowercase alpha
			stuTemp.Format(L"-%d%o", nVerseLast, nSegLast);
		}
		else
		{
			// Convert nVerseLast to decimal
			stuTemp.Format(L"-%d", nVerseLast);
		}
        m_stuVerseRef += stuTemp;
	}

	// Set section and paragraph start ref status variables, if needed
	if (!m_fVerseNumFoundInPara) // if this is the first verse num found in para
	{
		m_fVerseNumFoundInPara = true;
		
		if (m_cchTsbPara > 0 && // if this verse num is after the beginning of para
			m_nPrevVerseFirst > 0) // and we have a verse num for the previous text
		{
			// set start refs based on previous verse number (or range)
			if (!m_nSectionStartRef)
				m_nSectionStartRef = m_nBookNumber * 1000000 + m_nChapter * 1000 + m_nPrevVerseFirst;
			if (!m_nParaStartRefFirst)
			{
				m_nParaStartRefFirst = m_nBookNumber * 1000000 + m_nChapter * 1000 + m_nPrevVerseFirst;
				m_nParaStartRefLast = m_nBookNumber * 1000000 + m_nChapter * 1000 + m_nPrevVerseLast;
			}
		}
	}
	// continue now for all verse nums, to set start refs & status
	if (m_nChapter && nVerseFirst) // if we have real chapter & verse numbers
	{
		// REVIEW JohnT (TomB): Should we be asserting here (and other places?) that verse
		// number is <= 999?
		// set start refs based on current verse number (or range)
		if (!m_nSectionStartRef)
			m_nSectionStartRef = m_nBookNumber * 1000000 + m_nChapter * 1000 + nVerseFirst;
		if (!m_nParaStartRefFirst)
		{
			m_nParaStartRefFirst = m_nBookNumber * 1000000 + m_nChapter * 1000 + nVerseFirst;
			m_nParaStartRefLast = m_nBookNumber * 1000000 + m_nChapter * 1000 + sVerseLast;
		}
		// save for next time
		m_nPrevVerseFirst = nVerseFirst;
		m_nPrevVerseLast = sVerseLast;
	}
}

#define BUFFERDIRECT
#ifdef BUFFERDIRECT
// Add the given text & props to the current paragraph
void ScriptureImporter::AddTextToPara(SmartBstr & sbstrText, ITsTextProps * pttpProps)
// the sbstr param is a reference because passing by value uses copy contructor every time
{
	int cchText = sbstrText.Length();
	if (cchText && sbstrText != L" ")
	{
		// send the text and props directly to the tssBuilder
		CheckHr(m_qtsbPara->ReplaceRgch(m_cchTsbPara, m_cchTsbPara, sbstrText.Chars(), 
			cchText, pttpProps));
		m_cchTsbPara += cchText;
		// remember the final char so we can test and trim later
		m_chParaFinalChar = *(sbstrText.Chars() + cchText - 1);
	}
}

void ScriptureImporter::AddTextToPara(StrUni stuText, ITsTextProps * pttpProps)
{
	int cchText = stuText.Length();
	if (cchText && stuText != L" ")
	{
		// send the text and props directly to the tssBuilder
		CheckHr(m_qtsbPara->ReplaceRgch(m_cchTsbPara, m_cchTsbPara, stuText.Chars(), 
			cchText, pttpProps));
		m_cchTsbPara += cchText;
		// remember the final char so we can test and trim later
		m_chParaFinalChar = *(stuText.Chars() + cchText - 1);
	}
}

void ScriptureImporter::AddTextToPara(const OLECHAR* rgchText, int cchText, 
									  ITsTextProps * pttpProps)
{
	if (cchText)
	{
		if (cchText == 1 && *rgchText == 32) //if == L" "
			return;

		// send the text and props directly to the tssBuilder
		CheckHr(m_qtsbPara->ReplaceRgch(m_cchTsbPara, m_cchTsbPara, rgchText, 
			cchText, pttpProps));
		m_cchTsbPara += cchText;
		// remember the final char so we can test and trim later
		m_chParaFinalChar = *(rgchText + cchText - 1);
	}
}

// When finished calling AddTextToPara for current para, call this to trim a trailing space
//  (no buffer in this implementation, so no flush is needed)
void ScriptureImporter::AddTextToParaTrimFlush()
{
	if (m_cchTsbPara)
	{
		// check if the last char we sent to the builder is a space
		ComBool fTrailingSpace;
		CheckHr(m_pwlpi->GetCharacterPropertyEngine()->get_IsSeparator(
			m_chParaFinalChar, &fTrailingSpace));
		if (fTrailingSpace)
		{
			// remove the trailing space from the builder
			CheckHr(m_qtsbPara->ReplaceRgch(m_cchTsbPara-1, m_cchTsbPara, NULL, 0,NULL));
			m_cchTsbPara --;
		}
	}
	m_chParaFinalChar = 0; // clean up
}
#endif // end BUFFERDIRECT

#ifdef BUFFERSBSTR
// Add the given text & props to the current paragraph
void ScriptureImporter::AddTextToPara(SmartBstr & sbstrText, ITsTextProps * pttpProps)
{
	int cchRunText = m_sbstrRunText.Length();
	// send our previously buffered run to the tssBuilder
	if (cchRunText && m_sbstrRunText != L" ")
	{
		CheckHr(m_qtsbPara->ReplaceRgch(m_cchTsbPara, m_cchTsbPara, m_sbstrRunText.Chars(), 
			cchRunText, m_qttpRunProps));
		m_cchTsbPara += cchRunText;
	}
	// now buffer the given text & props
	m_sbstrRunText = sbstrText; // aarg- allocates+copies a new bstr, killing our efficiency
	m_qttpRunProps = pttpProps;
}

// When finished calling AddTextToPara for current para, call this to trim a trailing space
//  and flush the buffer
void ScriptureImporter::AddTextToParaTrimFlush()
{
	int cchRunText = m_sbstrRunText.Length();
	// trim a trailing space in our previously buffered run
	if (cchRunText)
	{
		ComBool fTrailingSpace;
		CheckHr(m_pwlpi->GetCharacterPropertyEngine()->get_IsSeparator(
			*(m_sbstrRunText.Chars() + cchRunText - 1), &fTrailingSpace));
		if (fTrailingSpace)
			cchRunText--;
	}
	// send our previously buffered run to the tssBuilder
	if (cchRunText)
	{
		CheckHr(m_qtsbPara->ReplaceRgch(m_cchTsbPara, m_cchTsbPara, m_sbstrRunText.Chars(), 
			cchRunText, m_qttpRunProps));
		m_cchTsbPara += cchRunText;
	}
}
#endif // end BUFFERSBSTR

//TODO BryanW: Reimplement footnotes properly when they are defined in the CM and implemented in view
//for now, we will insert footnote text into the current paragraph within braces
// Begin a footnote
void ScriptureImporter::BeginFootnote(StrAnsi staParaProps)
{
	AddTextToPara(L"{", 1, m_qttpVern); //temp delimiter in text
	//someday init footnote para builder and save footnote para props
	m_fInFootnote = true;	// remember that we are now processing a footnote
}

// someday handle additional paragraphs in a footnote
//void ScriptureImporter::AddParaToFootnote(StrAnsi staParaProps)

// Add the given text & props to the current footnote
void ScriptureImporter::AddTextToFootnote(SmartBstr & sbstrText, ITsTextProps * pttpProps)
{
	Assert(m_fInFootnote);
	AddTextToPara(sbstrText, pttpProps); //temp insert into para text
	//someday add text to footnote para builder
}

// When finished calling AddTextToFootnote for current note, call this to process & save
void ScriptureImporter::EndFootnote()
{
	Assert(m_fInFootnote);
	AddTextToPara(L"}", 1, m_qttpVern); //temp delimiter in text
	//someday trim and ?parse? the footnote para
	//call MakeFootnote() to save it to the db
	m_fInFootnote = false;
}


// This method must be called before we create the new section (i.e., m_hvoSection still
// has to be set for the section we just finished parsing).
void ScriptureImporter::SetRefsForSection()
{
	if (m_hvoSection)
	{
		if (!m_nSectionStartRef)
		{
			m_nSectionStartRef = m_nBookNumber * 1000000 + m_nChapter * 1000 +
				m_nPrevVerseFirst;
		}
		// REVIEW SteveM(TomB): Should we use a stored procedure here?
		m_stuSql.Format(L"update [ScrSection] set [VerseRefStart]=%d, [VerseRefEnd]=%d "
			L"where id=%d",
			m_nSectionStartRef,
			m_nBookNumber * 1000000 + m_nChapter * 1000 + m_nPrevVerseLast,
			m_hvoSection);
		IOleDbCommandPtr qodc;
		CheckHr(m_qode->CreateCommand(&qodc));
		CheckHr(qodc->ExecCommand(m_stuSql.Bstr(), knSqlStmtNoResults));
		// For the next section (i.e., the one we're about to create) use the verse
		// number of the next bit of verse text we find.
		m_nSectionStartRef = 0;
	}
}

// MakeBook() deletes an existing book (if any) and creates a new one having the
// "canonical" book number m_nBookNumber. The hvo of the new book is stored in
// m_hvoBook. It also creates a title object for the book and puts the hvo of the
// title in m_hvoTitle.
void ScriptureImporter::MakeBook()
{
	Assert(!m_hvoBook);
	Assert(m_nBookNumber); //right now, we rely on ProcessSegment() to set the book number

	// TODO TomB: Need to figure out how to fix the wordform count when deleting an
	// existing book.
#ifndef JR_PERFORMANCE_TEST
	m_stuSql.Format(L"exec Import_NewScrBook %d, %d, ? output, ? output", m_hvoScripture,
		m_nBookNumber);
#else
	m_stuSql.Format(L"exec Import_NewScrBookJRP %d, %d, ? output, ? output", m_hvoScripture,
		m_nBookNumber);
#endif
	IOleDbCommandPtr qodc;
	CheckHr(m_qode->CreateCommand(&qodc));
	CheckHr(qodc->SetParameter(1,
		DBPARAMFLAGS_ISOUTPUT,
		NULL,
		DBTYPE_I4,
		(ULONG *)&m_hvoBook, sizeof(int)));
	CheckHr(qodc->SetParameter(2,
		DBPARAMFLAGS_ISOUTPUT,
		NULL,
		DBTYPE_I4,
		(ULONG *)&m_hvoTitle, sizeof(int)));

	// Actually execute the command.
	CheckHr(qodc->ExecCommand(m_stuSql.Bstr(), knSqlStmtNoResults));
	ComBool fIsNull;
	CheckHr(qodc->GetParameter(1,
		reinterpret_cast<ULONG *>(&m_hvoBook),
		sizeof(int),
		&fIsNull));
	Assert(!fIsNull);
	Assert(m_hvoBook);
	CheckHr(qodc->GetParameter(2,
		reinterpret_cast<ULONG *>(&m_hvoTitle),
		sizeof(int),
		&fIsNull));
	Assert(!fIsNull);
	Assert(m_hvoTitle);

	m_iSection = 1;
#ifndef JR_PERFORMANCE_TEST
  	m_iPara = 1;
  	m_iTitlePara = 1;
#else
	m_hvoParaPrev = 0;
	m_hvoTitleParaPrev = 0;
#endif
}

// Append (save) the new paragraph in m_qtssPara to the database.
#ifndef JR_PERFORMANCE_TEST
void ScriptureImporter::AppendParaToDb(HVO hvoOwner, int ord, byte *rgbParaFmt, 
	int cbParaFmtSize, HVO &hvoPara)
#else
void ScriptureImporter::AppendParaToDb(HVO hvoOwner, HVO &hvoParaPrev, byte *rgbParaFmt,
	int cbParaFmtSize, HVO &hvoPara)
#endif
{
	// Get the paragraph contents.
	SmartBstr sbstrPara;
	CheckHr(m_qtssPara->get_Text(&sbstrPara));

	// Copy "format" information of the TsString to the byte array "rgbFmt".
	int cbFmtBufSize = kcbFmtBufMax;
	int cbFmtSpaceTaken;
	byte * rgbFmt = NewObj byte[kcbFmtBufMax];
	HRESULT hr = E_FAIL;
	hr = m_qtssPara->SerializeFmtRgb(rgbFmt, cbFmtBufSize, &cbFmtSpaceTaken);
	if (hr != S_OK)
	{
		if (hr == S_FALSE)
		{
			//  If the supplied buffer is too small, try it again with 
			//  the value that cbFmtSpaceTaken was set to.  If this 
			//   fails, throw error.
			delete[] rgbFmt;
			rgbFmt = NewObj byte[cbFmtSpaceTaken];
			cbFmtBufSize = cbFmtSpaceTaken;
			CheckHr(m_qtssPara->SerializeFmtRgb(rgbFmt, cbFmtBufSize, &cbFmtSpaceTaken));
		}
		else
		{
			ThrowHr(WarnHr(E_UNEXPECTED));
		}
	}

	//  Execute stored procedure to add a paragraph
#ifndef JR_PERFORMANCE_TEST
  	m_stuSql.Format(L"exec Import_AppendPara %d, %d, ?, ?, ? output", hvoOwner, ord);
#else
	m_stuSql.Format(L"exec CreateObject_StTxtPara NULL, ?, NULL, ?, ?, %d, %d", hvoOwner,
		kflidStText_Paragraphs);
	if (hvoParaPrev)
	{
		m_stuSql.FormatAppend(L", %d", hvoParaPrev);
	}
	else
	{
		m_stuSql.Append(L", NULL");
	}
	m_stuSql.FormatAppend(L", ?, NULL");
#endif
	IOleDbCommandPtr qodc;
	CheckHr(m_qode->CreateCommand(&qodc));
#ifndef JR_PERFORMANCE_TEST
  	CheckHr(qodc->SetParameter(1,
   		DBPARAMFLAGS_ISINPUT,
   		NULL,
   		DBTYPE_WSTR,
   		(ULONG *)(sbstrPara.Chars()),
   		sbstrPara.Length() * 2));
   	if (cbFmtSpaceTaken)
   	{
  		CheckHr(qodc->SetParameter(2,
   			DBPARAMFLAGS_ISINPUT,
   			NULL,
   			DBTYPE_BYTES,
   			reinterpret_cast<ULONG *>(rgbFmt),
   			cbFmtSpaceTaken));
   	}
   	else
   	{
  		qodc->SetParameter(2,
   			DBPARAMFLAGS_ISINPUT,
   			NULL,
   			DBTYPE_BYTES,
   			reinterpret_cast<ULONG *>(NULL),
   			0);
   	}
  	CheckHr(qodc->SetParameter(3,
   		DBPARAMFLAGS_ISOUTPUT,
   		NULL,
   		DBTYPE_I4,
   		(ULONG *)&hvoPara, sizeof(int)));

  	if (cbParaFmtSize)
  	{
  		m_stuSql.Append(L", ?");
  		CheckHr(qodc->SetParameter(4,
  			DBPARAMFLAGS_ISINPUT,
  			NULL,
  			DBTYPE_BYTES,
  			reinterpret_cast<ULONG *>(rgbParaFmt),
  			cbParaFmtSize));
  	}
#else
	if (cbParaFmtSize)
	{
		CheckHr(qodc->SetParameter(1,
			DBPARAMFLAGS_ISINPUT,
			NULL,
			DBTYPE_BYTES,
			reinterpret_cast<ULONG *>(rgbParaFmt),
			cbParaFmtSize));
	}
	else
	{
		qodc->SetParameter(1,
			DBPARAMFLAGS_ISINPUT,
			NULL,
			DBTYPE_BYTES,
			reinterpret_cast<ULONG *>(NULL),
			0);
	}

	CheckHr(qodc->SetParameter(2,
		DBPARAMFLAGS_ISINPUT,
		NULL,
		DBTYPE_WSTR,
		(ULONG *)(sbstrPara.Chars()),
		sbstrPara.Length() * 2));

	if (cbFmtSpaceTaken)
	{
		CheckHr(qodc->SetParameter(3,
			DBPARAMFLAGS_ISINPUT,
			NULL,
			DBTYPE_BYTES,
			reinterpret_cast<ULONG *>(rgbFmt),
			cbFmtSpaceTaken));
	}
	else
	{
		qodc->SetParameter(3,
			DBPARAMFLAGS_ISINPUT,
			NULL,
			DBTYPE_BYTES,
			reinterpret_cast<ULONG *>(NULL),
			0);
	}
	CheckHr(qodc->SetParameter(4,
		DBPARAMFLAGS_ISOUTPUT,
		NULL,
		DBTYPE_I4,
		(ULONG *)&hvoPara, sizeof(int)));
#endif

	// Actually execute the command.
	CheckHr(qodc->ExecCommand(m_stuSql.Bstr(), knSqlStmtNoResults));
	ComBool fIsNull;
#ifndef JR_PERFORMANCE_TEST
  	CheckHr(qodc->GetParameter(3,
#else
	CheckHr(qodc->GetParameter(4,
#endif
		reinterpret_cast<ULONG *>(&hvoPara),
		sizeof(int),
		&fIsNull));
	delete[] rgbFmt;
	Assert(!fIsNull);
	Assert(hvoPara);
#ifdef JR_PERFORMANCE_TEST
	hvoParaPrev = hvoPara;
#endif
}

void ScriptureImporter::MakeSection()
{
	// First set verse ref properties for previous section, if any.
	SetRefsForSection();

	//  Execute stored procedure to add a section
	m_stuSql.Format(L"exec Import_AppendScrSection %d, %d, ? output, ? output, ? output",
		m_hvoBook, m_iSection++);
	IOleDbCommandPtr qodc;
	CheckHr(m_qode->CreateCommand(&qodc));
	CheckHr(qodc->SetParameter(1,
		DBPARAMFLAGS_ISOUTPUT,
		NULL,
		DBTYPE_I4,
		(ULONG *)&m_hvoSection, sizeof(int)));
	CheckHr(qodc->SetParameter(2,
		DBPARAMFLAGS_ISOUTPUT,
		NULL,
		DBTYPE_I4,
		(ULONG *)&m_hvoSectionHeading, sizeof(int)));
	CheckHr(qodc->SetParameter(3,
		DBPARAMFLAGS_ISOUTPUT,
		NULL,
		DBTYPE_I4,
		(ULONG *)&m_hvoSectionContent, sizeof(int)));

	// Actually execute the command.
	CheckHr(qodc->ExecCommand(m_stuSql.Bstr(), knSqlStmtNoResults));
	ComBool fIsNull;
	CheckHr(qodc->GetParameter(1,
		reinterpret_cast<ULONG *>(&m_hvoSection),
		sizeof(int),
		&fIsNull));
	Assert(!fIsNull);
	Assert(m_hvoSection);
	CheckHr(qodc->GetParameter(2,
		reinterpret_cast<ULONG *>(&m_hvoSectionHeading),
		sizeof(int),
		&fIsNull));
	Assert(!fIsNull);
	Assert(m_hvoSectionHeading);
	CheckHr(qodc->GetParameter(3,
		reinterpret_cast<ULONG *>(&m_hvoSectionContent),
		sizeof(int),
		&fIsNull));
	Assert(!fIsNull);
	Assert(m_hvoSectionContent);

	// set status vars so we are ready to add section head paragraph
#ifndef JR_PERFORMANCE_TEST
  	m_iPara = 1;
#else
	m_hvoParaPrev = 0;
#endif
}

// If we have any pending text in buffers or Para builder, finish making the paragraph
// and add it to the database.
// Add it to the current section (or make one if we don't have one).
// If we don't already have a current book make that also.
// Prepare for a new paragraph.
void ScriptureImporter::MakeParagraph()
{
	// Get rid of space at the end of the paragraph, flush any buffers.		
	AddTextToParaTrimFlush();

	// Now process this paragraph, if we have text
#ifdef ALLOW_SOME_EMPTY_PARAGRAPHS
	if (m_cchTsbPara > 0 || !m_fSuppressEmptyPara)
#else
	if (m_cchTsbPara > 0)
#endif
	{
		// Get the paragraph tsstring from the builder
		CheckHr(m_qtsbPara->GetString(&m_qtssPara));

		// Clear the builder, for new paragraph
		CheckHr(m_qtsbPara->ReplaceRgch(0, m_cchTsbPara, NULL, 0, m_qttpVern));
		//CheckHr(m_qtsbPara->Clear());  REVIEW BryanW: why does this invalidate the builder?
		m_cchTsbPara = 0;

		// OK, we need to insert the paragraph. But first we have to make sure we have
		// a section and book.
		if (!m_hvoBook)
		{
			MakeBook();
		}
		if (m_iSection == 1)
		{
			MakeSection();
		}
	
		// Now append the paragraph in m_qtssPara to the database
		HVO hvoPara;
		AppendParaToDb((m_fInSectionHeading ? m_hvoSectionHeading : m_hvoSectionContent),
#ifndef JR_PERFORMANCE_TEST
  			m_iPara++, 
#else
			m_hvoParaPrev,
#endif
			(byte*)m_staCurrentParaProps.Chars(), // text props for current para (para style)
			m_staCurrentParaProps.Length(), 
			hvoPara);

		// Parse the paragraph in m_qtssPara
		m_fVerseNumFoundInPara = false;
		m_fVersePara = false;
		if (!m_nParaStartRefFirst)
		{
			m_nParaStartRefFirst = m_nBookNumber * 1000000 + m_nChapter * 1000 +
				m_nPrevVerseFirst;
			m_nParaStartRefLast = m_nBookNumber * 1000000 + m_nChapter * 1000 +
				m_nPrevVerseLast;
		}
		m_pwlpi->ParseNewStTxtPara(hvoPara, m_qtssPara, m_nParaStartRefFirst,
			m_nParaStartRefLast);
	}
#ifdef ALLOW_SOME_EMPTY_PARAGRAPHS
	m_fSuppressEmptyPara = false;
#endif
	// TODO BryanW (TomB): The following is needed to deal with the "first" paragraph in a
	// book (actually everything up to and including the first paragraph with a verse
	// number). Need to decide how to mark stuff preceding the first verse and use existing
	// logic in GetVerseRef() to set this for the first real verse.
	//	if (!m_nPrevVerseFirst)
	//		GetVerseRef();
	m_nParaStartRefFirst = m_nParaStartRefLast = 0;
}

void ScriptureImporter::Finalize()
{
	// Set verse references for final section, if any.
	SetRefsForSection();

	// Spew out the last bit of stuff in the builder, if any.
	MakeParagraph();

	// Reload the top-level Scripture data, i.e., the HVOs of the books
	// ENHANCE TomB(JohnT): Add pointer to status bar if needed.
	m_ptmwMainWnd->LoadScrBooks(NULL /*pointer to status bar*/);

	// Make all client windows refresh their views. This will cause any
	// needed Scripture data to be reloaded lazily.
	AfMdiClientWnd * pmdic = m_ptmwMainWnd->GetMdiClientWnd();
	int crncw = pmdic->GetChildCount();
	for (int irncw = 0; irncw < crncw; irncw++)
	{
		AfClientWnd * pafcw = pmdic->GetChildFromIndex(irncw);
		Assert(pafcw);
		if (pafcw->Hwnd()) // if the window has actually been created, refresh it.
			pafcw->RefreshDisplay();
	}

	if (m_psctsTextSeg)
	{
		m_psctsTextSeg->Release();
		m_psctsTextSeg = NULL;
	}
}

// Explicit instantiation
#include <ComHashMap_i.cpp>
template ComHashMapStrUni<ImportStyleProxy>; // ISProxyMap; // Hungarian: hmstuisy
