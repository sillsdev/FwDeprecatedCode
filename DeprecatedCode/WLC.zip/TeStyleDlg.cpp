/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2002 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TeStyleDlg.cpp
Responsibility: Eberhard Beilharz
Last reviewed: never

Description:
	Implementation of TE specific Style Dialog
-------------------------------------------------------------------------------*//*:End Ignore*/

#include "Main.h"
#pragma hdrstop
#undef THIS_FILE
DEFINE_THIS_FILE

//:>*******************************************************************************************
//:> TeStylesDlg implementation
//:>*******************************************************************************************

/*----------------------------------------------------------------------------------------------
	Override to do special initalizations

	See ${AfStylesDlg#OnInitDlg}
	@param hwndCtrl (not used)
	@param lp (not used)
	@return true
----------------------------------------------------------------------------------------------*/
bool TeStylesDlg::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	m_hwndList = ::GetDlgItem(m_hwnd, kctidTesdCbList);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Override of ${AfStylesDialog#SetupTabs} to insert special "General" page
----------------------------------------------------------------------------------------------*/
void TeStylesDlg::SetupTabs() 
{
	SuperClass::SetupTabs();

	m_rgdlgv[0].Attach(NewObj TeFmtGenDlg(this));
}

/*----------------------------------------------------------------------------------------------
	Process notifications for this dialog from some event on a control.  This method is called
	by the framework.

	@param ctid Id of the control that issued the windows command.
	@param pnmh Windows command that is being passed.
	@param lnRet return value to be returned to the windows command.
	@return true if command is handled.
	See ${AfStylesDlg#OnNotifyChild}
----------------------------------------------------------------------------------------------*/
bool TeStylesDlg::OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet)
{
	switch(pnmh->code)
	{
	case CBN_SELCHANGE:
		{	// User changes combo box to show only published, non-published or all styles
			// First, save the values. This is done easiest by calling UpdateTabCtrl
			UpdateTabCtrl(-1, -1);

			// force styles listbox to be refilled
			UpdateStyleList();
			// check if selected style is still shown, otherwise select first visible
			int iListItem; // Index in the listview.
			if (SkipStyle(m_istyiSelected))
			{
				// select first item in the styles list
				iListItem = 0;
			}
			else
			{
				// re-select old item
				LVFINDINFO plvfi;
				plvfi.lParam = m_istyiSelected;
				plvfi.flags = LVFI_PARAM;
				iListItem = ListView_FindItem(m_hwndStylesList, -1, &plvfi);
			}

			// select an item
			DWORD dwT = LVIS_SELECTED | LVIS_FOCUSED;
			ListView_SetItemState(m_hwndStylesList, iListItem, dwT, dwT);

			// Make sure that it is visible
			ListView_EnsureVisible(m_hwndStylesList, iListItem, false);
			lnRet = 0;
			return true;
		}
	default:
		break;
	}

	return SuperClass::OnNotifyChild(ctid, pnmh, lnRet);
}

/*----------------------------------------------------------------------------------------------
	Returns true if style should not be shown in dialog
----------------------------------------------------------------------------------------------*/
bool TeStylesDlg::SkipStyle(int iStyle) const
{
	// get current value of the list combobox
	StyleTextTypes testt = static_cast<StyleTextTypes>(::SendMessage(m_hwndList, CB_GETCURSEL, 0,0));

	if (m_vstyi[iStyle].m_fPublished && testt == ksttNonpublished ||
		!m_vstyi[iStyle].m_fPublished && testt == ksttPublished)
	{
		return true;
	}

	return false;
}

/*----------------------------------------------------------------------------------------------
	Set the values for the dialog controls based
----------------------------------------------------------------------------------------------*/
void TeStylesDlg::SetDialogValues()
{
	// Fill list combobox.
	StrAnsi staTemp;
	::SendMessage(m_hwndList, CB_RESETCONTENT, 0, 0);
	staTemp.Load(kstidTesdListNonPubl); 
	::SendMessage(m_hwndList, CB_ADDSTRING, 0, (LPARAM)staTemp.Chars()); // 0
	staTemp.Load(kstidTesdListPubl);	
	::SendMessage(m_hwndList, CB_ADDSTRING, 0, (LPARAM)staTemp.Chars()); // 1
	staTemp.Load(kstidTesdListAll);		
	::SendMessage(m_hwndList, CB_ADDSTRING, 0, (LPARAM)staTemp.Chars()); // 2

	// now select the value in the combo box that represents the current selection (IP) in text
	int nSelect = ksttAll;	// what to select in list combobox
	if (!m_fShowAll)
	{
		for (int istyi = 0; istyi < m_vstyi.Size(); istyi++)
		{
			if ((!m_vstyi[istyi].m_fDeleted) && m_stuParaStyleNameOrig == m_vstyi[istyi].m_stuName)
			{
				nSelect = m_vstyi[istyi].m_fPublished;
				break;
			}
		}
	}

	::SendMessage(m_hwndList, CB_SETCURSEL, nSelect, 0);

	SuperClass::SetDialogValues();
}

/*----------------------------------------------------------------------------------------------
	Make a new style. Overriden, so that we can let user select the text type and set the 
	values accordingly
	
	@param stype Style type to be copied
	@param pstyi Style to be changed.
	@return true if new style was created, false if user canceled text type dialog
----------------------------------------------------------------------------------------------*/
bool TeStylesDlg::MakeNewStyi(const StyleType stype, StyleInfo * pstyi)
{
	AssertPtr(pstyi);

	// get current value of the list combobox
	StyleTextTypes testt = static_cast<StyleTextTypes>(::SendMessage(m_hwndList, CB_GETCURSEL, 0,0));
	bool fDefault; // true to select published text in dialog
	if (testt == ksttNonpublished)
		fDefault = false;
	else
		fDefault = true;

	// let user select text type
	TeTextTypeDlg tettd;
	tettd.SetDialogValues(fDefault);
	if (tettd.DoModal(m_hwnd) == kctidOk)
	{
		tettd.GetDialogValues(pstyi->m_fPublished);

		// if user changed the text type and we do not show this text type, we switch to show all styles
		if (pstyi->m_fPublished != fDefault && testt != ksttAll)
		{
			long lnRet;
			NMHDR nmhdr;
			nmhdr.code = CBN_SELCHANGE;

			::SendMessage(m_hwndList, CB_SETCURSEL, ksttAll, 0);
			OnNotifyChild(kctidTesdCbList, &nmhdr, lnRet);
		}
		return SuperClass::MakeNewStyi(stype, pstyi);
	}
	else
		return false;
}

/*----------------------------------------------------------------------------------------------
	Copy a style to a new one and find right values. Overriden, so that we can let user select 
	the text type and set the values accordingly.

	@param pstyiSrc - Source style
	@param pstyiDest - new style
	@return true
----------------------------------------------------------------------------------------------*/
bool TeStylesDlg::CopyStyi(const StyleInfo & styiSrc, StyleInfo & styiDest)
{
	SuperClass::CopyStyi(styiSrc, styiDest);

	// let user select text type
	TeTextTypeDlg tettd;
	tettd.SetDialogValues(styiSrc.m_fPublished);
	if (tettd.DoModal(m_hwnd) == kctidOk)
	{
		// override with user selected values
		tettd.GetDialogValues(styiDest.m_fPublished);

		// if the user changed the text type, we have to change the style for the following 
		// paragraph
		if (styiSrc.m_fPublished != styiDest.m_fPublished)
		{
			styiDest.m_hvoNext = styiDest.m_hvoStyle;

			// if we do not show this text type, we switch to show all styles
			StyleTextTypes testt = static_cast<StyleTextTypes>(::SendMessage(m_hwndList, CB_GETCURSEL, 0,0));
			if (testt != ksttAll)
			{
				long lnRet;
				NMHDR nmhdr;
				nmhdr.code = CBN_SELCHANGE;

				::SendMessage(m_hwndList, CB_SETCURSEL, ksttAll, 0);
				OnNotifyChild(kctidTesdCbList, &nmhdr, lnRet);
			}
		}

		return true;
	}
	else
		return false;
	
}

/*----------------------------------------------------------------------------------------------
	Deletes the selected style. Overwritten so that we can select a style that is shown.

	@return true
----------------------------------------------------------------------------------------------*/
bool TeStylesDlg::CmdDel()
{
	bool fRet = SuperClass::CmdDel();

	if (SkipStyle(m_istyiSelected))
	{
		// select first item in the styles list because selected (BasedOn) style is not visible
		DWORD dwT = LVIS_SELECTED | LVIS_FOCUSED;
		ListView_SetItemState(m_hwndStylesList, 0, dwT, dwT);

		// Make sure that it is visible
		ListView_EnsureVisible(m_hwndStylesList, 0, false);
	}

	return fRet;
}

//:>********************************************************************************************
//:>	Set methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Set the text type of this paragraph style to be fPublished, if it is different and set
	m_fDirty to true. Return true.

	@param styi The style to be changed.
	@param fPublished The new text style.
	@return true
----------------------------------------------------------------------------------------------*/
bool TeStylesDlg::SetPublished(StyleInfo & styi, bool fPublished)
{
	if (styi.m_fPublished != fPublished)
	{
		styi.m_fPublished = fPublished;
		if (styi.m_fBuiltIn)
			styi.m_fModified = true;
		styi.m_fDirty = true;
	}
	return true;
}

/*----------------------------------------------------------------------------------------------
	Set the Usage for this paragraph style to be stuNewUsage, if it is different from the 
	current usage and set m_fDirty to true. Return true.

	@param styi The style to be changed.
	@param stuNewUsage New usage description
	@return true
----------------------------------------------------------------------------------------------*/
bool TeStylesDlg::SetUsage(StyleInfo & styi, const StrUni & stuNewUsage)
{
	// TODO EberhardB: Implement once we have Usage in our style
//	if (!styi.m_stuUsage.Equals(stuNewUsage))
//	{
//		styi.m_stuUsage.Assign(stuNewUsage);
//		styi.m_fDirty = true;
//		if (styi.m_fBuiltIn)
//			styi.m_fModified = true;
//	}
	return true;
}


//:>*******************************************************************************************
//:> TeFmtGenDlg implementation
//:>*******************************************************************************************

/*----------------------------------------------------------------------------------------------
	The app framework calls this to initialize the dialog. All one-time initialization should
	be done here (that is, all controls have been created and have valid hwnd's, but they
	need initial values.)
----------------------------------------------------------------------------------------------*/
bool TeFmtGenDlg::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	// Get the window handles for our controls.
	m_hwndUsage = ::GetDlgItem(m_hwnd, kctidTeFgEdUsage); // Usage edit control

	// Fix static controls that contain shortcuts so the shortcuts won't do anything if
	// the controls are disabled.
	AfStaticText::FixEnabling(m_hwnd, kctidTeFgEdUsage);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Set the values for the dialog controls based on the style styi.
----------------------------------------------------------------------------------------------*/
void TeFmtGenDlg::SetDialogValues(StyleInfo & styi, Vector<int> & vwsProj)
{
	SuperClass::SetDialogValues(styi, vwsProj);

	TeStylesDlg * ptesd = dynamic_cast<TeStylesDlg*>(m_pafsd);

	// append text type to style type
	StrApp strTemp;
	
	achar rgcha[1024];
	::GetWindowText(m_hwndType, rgcha, 1024);
	strTemp = rgcha;
	strTemp.Append(L", ");
	if (styi.m_fPublished)
	{
		strTemp.AppendLoad(kstidTeFgPubl);
	}
	else
	{
		strTemp.AppendLoad(kstidTeFgNonPubl);
	}
	::SetWindowText(m_hwndType, strTemp.Chars());

	// TeStylesDlg * ptesd = dynamic_cast<TeStylesDlg*>(m_pafsd);

	// Set Usage field
	// TODO EberhardB: Implement transfer of data from database to field once it exists in 
	// database
	// staTemp.Load(kctidTeFgEdUsage);	// Dummy
	strTemp = L""; // dummy
	::SetWindowText(m_hwndUsage, strTemp.Chars());

	// We have to refill the Next combo box to show only styles with compatible text style
	::SendMessage(m_hwndNext, CB_RESETCONTENT, 0, 0);
	for (int istyi = 0; istyi < ptesd->m_vstyi.Size(); istyi++)
	{
		StyleInfo& styiTemp = ptesd->m_vstyi[istyi];
		if (styiTemp.m_fDeleted)
			continue;
		strTemp = styiTemp.m_stuName;
		if (styiTemp.m_st == styi.m_st && styiTemp.m_fPublished == styi.m_fPublished)
			::SendMessage(m_hwndNext, CB_ADDSTRING, 0, (LPARAM)strTemp.Chars());
	}

	// Select the "Next Style" value from styi for combobox.
	if (styi.m_st == kstParagraph)
	{
		strTemp = ptesd->GetNameOfStyle(styi.m_hvoNext);
		int icombobox = ::SendMessage(m_hwndNext, CB_FINDSTRINGEXACT, 0, (LPARAM)strTemp.Chars());
		::SendMessage(m_hwndNext, CB_SETCURSEL, icombobox, 0);
	}
}

/*----------------------------------------------------------------------------------------------
    Get the final values for the dialog controls, after the dialog has been closed.
----------------------------------------------------------------------------------------------*/
void TeFmtGenDlg::GetDialogValues(StyleInfo & styi, bool & fBasedOnChanged)
{
	TeStylesDlg * ptesd = dynamic_cast<TeStylesDlg*>(m_pafsd);

	achar rgcha[1024];
	::GetWindowText(m_hwndUsage, rgcha, 1024);
	StrUni stuUsage = rgcha;
	ptesd->SetUsage(styi, stuUsage);

	SuperClass::GetDialogValues(styi, fBasedOnChanged);
}

//:>*******************************************************************************************
//:> TeTextTypeDlg implementation
//:>*******************************************************************************************

/*----------------------------------------------------------------------------------------------
	Initialize the dialog
----------------------------------------------------------------------------------------------*/
bool TeTextTypeDlg::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	// Subclass the Help button.
	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidHelp, kbtHelp, NULL, 0);

	return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Transfer data from dialog to variable and vice versa
----------------------------------------------------------------------------------------------*/
void TeTextTypeDlg::DoDataExchange(AfDataExchange * padx)
{
	AssertPtr(padx);

	int n = m_fNonPubText;
	DDX_Radio(padx, kridTettdPubl, n);
	if (padx->m_fSave)
		m_fNonPubText = n;
}

