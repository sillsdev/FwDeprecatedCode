/*----------------------------------------------------------------------------------------------
Copyright 2000-2002, SIL International. All rights reserved.

File: SE.h
Responsibility: Bryan Wussow
Last reviewed: never

Description:
	This file contains the base classes for Scripture Editor.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef SE_INCLUDED
#define SE_INCLUDED 1

// Starting number for giving "MDI" (MVI) client children unique numbers
//const int kwidChildBase = 1003;  // We don't know why/if this number is significant. Sorry.
const int kwidConcHeader = 1004; // Window ID for the whole conc. header window.

class SeApp;
class SeMainWnd;
typedef GenSmartPtr<SeApp> SeAppPtr;
typedef GenSmartPtr<SeMainWnd> SeMainWndPtr;
class SeLpInfo;


/*----------------------------------------------------------------------------------------------
	Our Scripture Editor application class.
----------------------------------------------------------------------------------------------*/
class SeApp : public AfDbApp
{
	typedef AfDbApp SuperClass;


public:
	SeApp();
	virtual ~SeApp()
		{ } // Do nothing.

	int GetAppNameId()
	{
		return kstidAppName;
	}

    virtual AfDbInfo * GetDbInfo(const OLECHAR * pszDbName, const OLECHAR * pszSvrName);

	virtual const CLSID * GetAppClsid()
	{
		return &CLSID_ScriptureEditor;
	}

	StrUni m_stuBookSepr;
	StrUni m_stuChapterSepr;
	StrUni m_stuVerseSepr;
	StrUni m_stuChapterVerseSepr;
	StrUni m_stuBridge;

protected:
	virtual void Init(void);

	bool CmdFileImport(Cmd * pcmd);

	virtual int ProcessOptRetVal(OptionsReturnValue orv,
		HashMapStrUni<StrUni> * phmsustuOptions);

	CMD_MAP_DEC(SeApp);
};
	
enum ProtectedStyleId	// Must coorelate to s_rgszwProtStyleName defined below
{
	kstyidNormal,
	kstyidParagraph,
	kstyidChapterNumber,
	kstyidVerseNumber,
	kstyidSectionHeading,
	kstyidBookTitle,
	// insert additional style id's here
	kiProtStyleNameLim
};
/*----------------------------------------------------------------------------------------------
	The scripture stylesheet, hooked into a VwCacheDa database.
	Hungarian: tsts.
----------------------------------------------------------------------------------------------*/
class TeStylesheet : public AfDbStylesheet
{
	typedef AfDbStylesheet SuperClass;

public:
	//	IVwStylesheet methods.
	STDMETHOD(get_IsStyleProtected)(BSTR bstrName, ComBool * pfProtected);

	//	Other methods.
	//	Return the style name that coorelates with the given enum style id	
	//	@param styid is the style index that is used to look up the cooresponding stylename.
	inline StrUni GetProtStyleName(ProtectedStyleId styid)
	{
// TODO ToddJ: Use style GUID's and localizable name from resource when JohnT has a plan
		static const wchar * s_rgszwProtStyleName[kiProtStyleNameLim] = {g_pszwStyleNormal,
			L"Paragraph", L"Chapter Number", L"Verse Number", L"Section Heading",
			L"Book Title"};

		Assert(styid >= 0);
		Assert(styid < kiProtStyleNameLim);
		return s_rgszwProtStyleName[styid];
	}

	void CkReqdStyles(void);
};

DEFINE_COM_PTR(TeStylesheet);

/*----------------------------------------------------------------------------------------------
	The SeChangeWatcher class receives notifications of paragraph edits and implements the 
	desired side effects of re-parsing the paragraph for wordforms.
	Hungarian: sechgw
----------------------------------------------------------------------------------------------*/

class SeChangeWatcher : public AfChangeWatcher
{
		typedef AfChangeWatcher SuperClass;

public:
//	SeChangeWatcher()
//	{}
	void Init(ISilDataAccess * psda, SeLpInfo * pwlpi); 
//	~SeChangeWatcher();

protected:
	//these are the member variables needed to carry out the side effects we desire
	//note: Because this class will be registered in the CustViewDa by AfChangeWatcher
	// and tracked there by a smart pointer, 
	// use regular pointers in this class so that it won't be deadlocked when Da is going away.
	SeLpInfo * m_pwlpi;

	// we will define subclass's pure virtual function to do the effects we desire
	void DoEffectsOfPropChange(HVO hvoPara, int ivMin, int cvIns, int cvDel);
};

DEFINE_COM_PTR(SeChangeWatcher);

/*----------------------------------------------------------------------------------------------
	This class is overridden to allow us to override the GetLpInfo method
    so that it will create a SeLpInfo structure.

	@h3{Hungarian: wdbi}
----------------------------------------------------------------------------------------------*/
class SeDbInfo : public AfDbInfo
{
public:
	SeDbInfo();

	virtual AfLpInfo * GetLpInfo(HVO hvoLp);
};

typedef GenSmartPtr<SeDbInfo> SeDbInfoPtr;

typedef HashMapStrUni<HVO> MapStrHvo; // Hungarian: hmstuhvo


/*----------------------------------------------------------------------------------------------
	This class contains Translation Editor information about a language project.

	@h3{Hungarian: tlpi}
----------------------------------------------------------------------------------------------*/
class SeLpInfo : public AfLpInfo
{
public:
	SeLpInfo();
	~SeLpInfo() 
		{if (m_cbVernFmt) delete[] m_rgbVernFmt;}

	virtual bool OpenProject();
	virtual bool LoadProjBasics();
	void InitScriptureItems(HVO hvoScripture);
	void CacheScriptureName();

	void ExtractVerseNums(StrUni stuVerseNum, int &nVerseStart, int &nVerseEnd);
	void ExtractChapterNum(StrUni stuChapterNum, int &nChapter);
	void GetUpdatedWordforms();
	void ParseNewStTxtPara(HVO hvoPara, ITsStringPtr qtssPara, int nStartRefPrev,
		int nEndRefPrev);
	void ParseStTxtPara(HVO hvoPara, int ivMin, int cvIns, int cvDel);
	StrUni GetParagraphStyleName()
		{ return L"Paragraph"; }
	StrUni GetChapterNumberStyleName()
		{ return L"Chapter Number"; }
	StrUni GetVerseNumberStyleName()
		{ return L"Verse Number"; }
	bool IfChapterNumberStyle(ITsTextProps * pttp);
	bool IfVerseNumberStyle(ITsTextProps * pttp);

	HVO GetHvoScripture()
		{ return m_hvoScripture; };

	TeStylesheet * GetScriptureStylesheet()
	{
		// The scripture style sheet will utilize m_qdsts rather than a new m_qtsts,
		// so for now GetScriptureStylesheet() is equivalent to GetAfStylesheet().
		// But if we ever need both the langproj and scripture stylesheets, this should change.
		return dynamic_cast<TeStylesheet *>(m_qdsts.Ptr());
	}

	HVO GetHvoWordformInv()
	{
		return m_hvoWfi;
	}
    void SetHvoWordformInv(HVO hvo)
    {
        m_hvoWfi = hvo;
    }
	HVO GetHvoScrRefSystem()
	{
		return m_hvoScrRefSystem;
	}

	ILgCharacterPropertyEnginePtr GetCharacterPropertyEngine()
	{
		return m_qcpeVern;
	}

	StrUni GetScriptureName()
	{
		return m_stuScriptureName;
	}

	//:Ignore
	// The following method will be needed when (if?) the program deals with the values in the
	// tables LanguageProject_CurrentVernacularWritingSystems, LanguageProject_CurrentAnalysisWritingSystems,
	// LanguageProject_VernacularWritingSystems, or LanguageProject_AnalysisWritingSystems.
	//void SaveWritingSystems();
	//:End Ignore

	MapStrHvo m_hmstuhvoWordforms;

protected:
	void ParseParaAux(HVO hvoPara, ITsStringPtr qtssPara, const OLECHAR * pchStart, int ichMin,
		int cchParse, int &nBbCccVvvStart, int &nBbCccVvvEnd, bool fImporting, int ichDel = 0,
		int ihvoTwfic = 0);
	void AddWordformInContext(StrUni stuWord, HVO hvoPara, int iOffset, int nVerseRefStart,
		int nVerseRefEnd, int iOrd, bool fAtParaEnd, bool fImporting);

	HVO m_hvoScripture; // ID of scripture we are editing.
	StrUni m_stuScriptureName; // Name of the current Scripture object.
//	The scripture style sheet will utilize m_qdsts rather than a new m_qtsts.
//	TeStylesheetPtr m_qtsts; 
	HVO m_hvoWfi; // ID of Wordform Inventory
	HVO m_hvoScrRefSystem; // ID of ScrRefSystem
	int m_cbVernFmt;
	byte * m_rgbVernFmt;
	ITsStrFactoryPtr m_qtsf; // Available whenever we want to create TsStrings.
	 // vernacular character property engine (for now, this is just default Unicode props).
	ILgCharacterPropertyEnginePtr m_qcpeVern; 
};

// Used as indexes into array of spelling status bitmaps used to display in concordance. 
// The first three are used to reference bitmaps for unselected rows and the last three
// reference bitmaps for selected rows.
enum ConcSpellingStatuses
{
	kspellUndecided = 0,
	kspellIncorrect,
	kspellCorrect,
	kspellLim,
};

typedef GenSmartPtr<SeLpInfo> SeLpInfoPtr;

/*----------------------------------------------------------------------------------------------
	Our main window frame class.
----------------------------------------------------------------------------------------------*/
class SeMainWnd : public RecMainWnd
{
	typedef RecMainWnd SuperClass;

	friend class ScriptureImporter;

public:
	virtual ~SeMainWnd()
		{ } // Do nothing.

	virtual void OnReleasePtr();

	virtual void LoadSettings(const achar * pszRoot, bool fRecursive = true);
	virtual void SaveSettings(const achar * pszRoot, bool fRecursive = true);
	virtual bool OnChildEvent(int ceid, AfWnd * pAfWnd, void * lpInfo = NULL);
	void MakeNewView(UserViewType vwt, AfLpInfo * plpi, UserViewSpec * puvs, UserViewSpecVec * pvuvs = NULL);
	bool OnViewBarChange(int ilist, Set<int> & siselOld, Set<int> & siselNew);
	void UpdateCaptionBar();
    void ImportScripture(StrUni & stuSettingsFile, StrUni & stuRefStart, StrUni & stuRefEnd);
	void LoadData();
	void LoadScrBooks(AfStatusBarPtr qstbr);
	void LoadWord(HVO hvoWord);
	void LoadWfi();
    void Init(AfLpInfo * plpi);
	virtual bool CmdHelpMode(Cmd * pcmd);
	virtual bool OnClose();
	inline SeLpInfo * GetSeLpInfo()
	{
		SeLpInfo * pwlpi = dynamic_cast<SeLpInfo *>(GetLpInfo());
		AssertPtr(pwlpi);
		return pwlpi;
	}
	inline CustViewDa * GetCustViewDa()
	{
		return m_qcda;
	}
	inline IVwStylesheet * GetStyleSheet()
	{
		return GetSeLpInfo()->GetScriptureStylesheet();
	}
	bool CmdEditUndo(Cmd * pcmd);
	bool CmdEditRedo(Cmd * pcmd);
	bool CmsEditUndo(CmdState & cms);
	bool CmsEditRedo(CmdState & cms);

    // Supports the CmdWndNew command. 
    virtual void NewWindow(RecMainWnd ** ppmwnd);

	void PrepareSpellingStatusBitmaps();
	IPicturePtr GetSpellingStatusPic(int nStatus, bool fSelected = false, bool fHasFocus = false);

	// Default implementation for calling Format/Styles dialog
	virtual bool CmdFmtStyles(Cmd * pcmd);

	virtual void RenameAndDeleteStyles(Vector<StrUni> & vstuOldNames,
		Vector<StrUni> & vstuNewNames, Vector<StrUni> & vstuDelNames)
	{
		// TODO (SharonC): Implement as desired.
	}
	virtual StrApp GetRootObjName()
	{
		Assert(m_qlpi);
		StrApp str = "Dummy"; // dynamic_cast<RnLpInfo *>(m_qlpi.Ptr())->GetRnName();
		return str;
	}


protected:

	// NOTE: All of these values are used as indexes, so change them very carefully.
	enum
	{
		// Indices into the ViewBar lists (AfViewBar::m_vqlstbr).
		kiViewsList   = 0,
		kiListMax,

		// Indices into ViewBarImages_small.bmp and ViewBarImages_large.bmp.
		kimagDataEntry    = 0,
		kimagDocument     = 1,
		kimagBrowse       = 2,
		kimagTree         = 3,
		kimagFilterNone   = 4,
		kimagFilterSimple = 5,
		kimagFilterFull   = 6,
		kimagSort         = 7,
	};

	virtual void PostAttach(void);
	virtual bool OnNotifyChild(int id, NMHDR * pnmh, long & lnRet);

	// Override to return a more appropriate setting for the view bar flags.
	virtual DWORD GetViewbarSaveFlags();

	void InitMdiClient();

	// Bitmap pictures for spelling icons (selected and unselected). These are stored in
	// object so they're available throughout the application for menus, status bar, etc.
	// as well as in the words concordance.
	IPicturePtr m_qpicSpellStatus[kspellLim];
	IPicturePtr m_qpicSelSpellStatus[kspellLim];
	IPicturePtr m_qpicSelNoFocusSpellStatus[kspellLim];

	// Variables
	CustViewDaPtr m_qcda; // the parts of the FW database we load (i.e. Scripture stuff)
	SeChangeWatcherPtr m_qsechgw; // watches for paragraph changes

	CMD_MAP_DEC(SeMainWnd);
};

/*----------------------------------------------------------------------------------------------
	Scripture Reference dialog
----------------------------------------------------------------------------------------------*/
class ScriptRefDlg : public AfDialog
{
	typedef AfDialog SuperClass;
public:
	ScriptRefDlg()
	{
		m_rid = kridScriptRefDlg;
	}

	StrApp StartRefStr()
	{
		return m_strStartRef;
	}
	StrApp EndRefStr()
	{
		return m_strEndRef;
	}

	void SetInitRef(StrApp strStartRef, StrApp strEndRef);

	bool OnInitDlg(HWND hwndCtrl, LPARAM lp);

protected:

	virtual bool OnNotifyChild(int id, NMHDR * pnmh, long & lnRet);

protected:
	StrApp m_strStartRef;
	StrApp m_strEndRef;
};
typedef GenSmartPtr<ScriptRefDlg> ScriptRefDlgPtr;

extern SeApp g_app;

#endif // SE_INCLUDED
