/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 1999-2002, SIL International. All rights reserved.

File: ConcWnd.cpp
Responsibility: John Thomson
Last reviewed: Not yet.

Description:
	A simple concordance
-------------------------------------------------------------------------------*//*:End Ignore*/

//:>********************************************************************************************
//:>	   Include files
//:>********************************************************************************************
#include "main.h"
#pragma hdrstop
// any other headers (not precompiled)

const achar * kpszDraftWndPositionValue = _T("DraftWindowPosition");
const PropTag ktagSelectionDummy = -8;

#if DEBUG
#define TRACE2(msg,arg1,arg2) _CrtDbgReport(_CRT_WARN, NULL, 0, NULL, msg, arg1, arg2)
#define TRACE3(msg,arg1,arg2,arg3) _CrtDbgReport(_CRT_WARN, NULL, 0, NULL, msg, arg1, arg2, arg3)
#else
#define TRACE2(msg,arg1,arg2)
#define TRACE3(msg,arg1,arg2,arg3)
#endif

static DummyFactory g_factConcVc(_T("SIL.SE.ConcVc"));

BEGIN_CMD_MAP(ConcWnd)
	ON_CID_ALL(kcidSpellStatUndecided,
		&ConcWnd::CmdChangeSpellingStatus, &ConcWnd::CmsUpdateSpellingStatusPopup)
	ON_CID_ALL(kcidSpellStatIncorrect,
		&ConcWnd::CmdChangeSpellingStatus, &ConcWnd::CmsUpdateSpellingStatusPopup)
	ON_CID_ALL(kcidSpellStatCorrect,
		&ConcWnd::CmdChangeSpellingStatus, &ConcWnd::CmsUpdateSpellingStatusPopup)
END_CMD_MAP_NIL()

/***********************************************************************************************
***********************************************************************************************/
/*----------------------------------------------------------------------------------------------
	This function will make sure that changing the Selected property of an HVO won't cause the
	action to be added to the Undo/Redo handler. This function is not a member of any class
	because it is called from within at least two classes in ConcWnd.cpp.

	@param prootb Pointer to root box whose selection property is changing.
	@param hvo Handle to view object whose selection state is changing.
----------------------------------------------------------------------------------------------*/
void PropChangedSelection(IVwRootBox * prootb, HVO hvo)
{
	ISilDataAccessPtr qsda;
	CheckHr(prootb->get_DataAccess(&qsda));

	// Get Undo/Redo Handler and set it to NULL so the ktagSelectionDummy property change
	// is ignored by the handler. Once the property is changed, restore the handler.
	IActionHandlerPtr qacthTemp;
	CheckHr(qsda->GetActionHandler(&qacthTemp));
	CheckHr(qsda->SetActionHandler(NULL));
	
	try
	{
		// Force the selection property to change which will force the line to be
		// repainted with the appropriate colors.
		CheckHr(prootb->PropChanged(hvo, ktagSelectionDummy, 0, 0, 0));
	}
	catch (...)
	{
		// Restore Undo/Redo Handler.
		CheckHr(qsda->SetActionHandler(qacthTemp));
		throw;
	}

	// Restore Undo/Redo Handler.
	CheckHr(qsda->SetActionHandler(qacthTemp));
}

/***********************************************************************************************
	WfiChangeWatcher methods.
	The WfiChangeWatcher class receives notifications of new (and eventually deleted) wordforms
	and implements the desired side effects of adding/removing field editors in the concordance
	view.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Initialize the object.
	@param pcda  Ptr to CustViewDa that we will be registered to
	@param pconw  Ptr to Conc Window
----------------------------------------------------------------------------------------------*/
void WfiChangeWatcher::Init(ISilDataAccess * psda, ConcWnd * pconw)
{
	//init the AfChangeWatcher to check for Paragraph changes
	SuperClass::Init(psda, kflidWordformInventory_Wordforms);
	
	// init member vars for DoEffectsOfPropChange()
	AssertPtr(pconw);
	m_pconw = pconw;
}

/*----------------------------------------------------------------------------------------------
	Do the side effects.
	DoEffectsOfPropChange() is called by AfChangeWatcher when a change is detected.
	@param hvo  the viewable object that was changed
	@param ivMin the starting index where the change occurred.
	@param cvIns the number of wordforms inserted.
	@param cvDel the number of wordforms deleted. 
----------------------------------------------------------------------------------------------*/
void WfiChangeWatcher::DoEffectsOfPropChange(HVO hvoPara, int ivMin, int cvIns, int cvDel)
{
	// ENHANCE (BryanW): check that this is a wordform that we really want to display in the
	// concordance (consider filters, non-scripture texts, etc)

	for (int i = 0; i < cvIns; i++)
	{
		m_pconw->InsertWordform(ivMin);
	}
	// TODO (BryanW): implement deletions too
	m_pconw->SetHeight(); // Calculate the new height of fields.
	::InvalidateRect(m_pconw->Hwnd(), NULL, false);
}

/***********************************************************************************************
	ConcCaptionBar stuff.
***********************************************************************************************/
/*----------------------------------------------------------------------------------------------
	Constructor. This caption bar is the caption bar above the concordance window. It is owned
	by the MDI client window.
----------------------------------------------------------------------------------------------*/
ConcCaptionBar::ConcCaptionBar() : SuperClass()
{
	// Get the system's caption font and set the caption bar's font to the same
	// face name, but set it to a larger size, like Outlook's.
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, 0);
	ncm.lfCaptionFont.lfHeight = 20;
	SetCaptionFont(&ncm.lfCaptionFont);
}

/*----------------------------------------------------------------------------------------------
	Handle window messages. Return true if handled. Send the focus to the concordance window's
	current split pane when this caption bar is clicked on.

	See ${AfWnd#FWndProc} for parameter and return descriptions.
----------------------------------------------------------------------------------------------*/
bool ConcCaptionBar::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
	// 
	if (wm == WM_LBUTTONDOWN || wm == WM_MBUTTONDOWN || wm == WM_RBUTTONDOWN)
	{
		AfMdiClientWnd * pmdic = dynamic_cast<AfMdiClientWnd *>(Parent());
		ConcClientWnd * pccw = dynamic_cast<ConcClientWnd *>(pmdic->GetChildFromWid(kwidChildBase));
		ConcHeaderWnd * pchw = pccw->GetConcHeaderWnd();
		::SetFocus(pchw->GetSplitterWindow()->CurrentPane()->Hwnd());
		return true;
	}

	return SuperClass::FWndProc(wm, wp, lp, lnRet);
}

/***********************************************************************************************
	ConcWnd stuff.
***********************************************************************************************/
/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
ConcWnd::ConcWnd(ConcHeaderWnd * pchw) :
	AfLazyDeWnd(true) // fAlignFieldsToTree = true
{
	m_pchw = pchw;
	m_icfeCurrent = 0; // Set the initial Current Conc Field Editor.
	m_fHasFocus = false;
	m_fIgnoreLButtonDown = false;
	m_fIgnoreLButtonUp = false;
}

/*----------------------------------------------------------------------------------------------
	Return the separator line color we want.
----------------------------------------------------------------------------------------------*/
const COLORREF ConcWnd::GetSeparatorLineColor()
{
	return ::GetSysColor(COLOR_3DFACE);
	// Uncomment if no separator line is desired.
	// return ::GetSysColor(COLOR_WINDOW);
}

/*----------------------------------------------------------------------------------------------
	Expand or contract the node. In our case the node itself knows how.
----------------------------------------------------------------------------------------------*/
void ConcWnd::ToggleExpansion(int idfe)
{
	ConcFieldEditor * pcfe = dynamic_cast<ConcFieldEditor *>(m_vdfe[idfe]);
	Assert(pcfe);
	pcfe->ToggleExpansion();
}

/*----------------------------------------------------------------------------------------------
	Initialize the concordance window.
----------------------------------------------------------------------------------------------*/
void ConcWnd::Init(CustViewDa * pcvd)
{
	// Todo JohnT: retrieve this from a registry setting or something like that.
	SetTreeWidth(100);
	ITsStrFactoryPtr qtsf;
	qtsf.CreateInstance(CLSID_TsStrFactory);
	CheckHr(qtsf->MakeStringRgch( NULL, 0, 0, &m_qtssLabel));
	m_qcvd = pcvd;
}

/*----------------------------------------------------------------------------------------------
	Cache the hvo of the Wordform Inventory.
----------------------------------------------------------------------------------------------*/
void ConcWnd::PostAttach()
{
	SuperClass::PostAttach();
	SeLpInfoPtr qlpi = dynamic_cast<SeLpInfo *>(GetLpInfo());
	Assert(qlpi);
	m_hvoWordformInventory = qlpi->GetHvoWordformInv();
	Assert(m_hvoWordformInventory);

	// Create the Change Watcher
	m_qwfichgw.Attach(NewObj WfiChangeWatcher);
	m_qwfichgw->Init(m_qcvd, this);
}

/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
void ConcWnd::InsertWordform(int i)
{
	m_vdfe.Insert(i, NULL);
	if (m_icfeCurrent >= i)
		m_icfeCurrent++;
}

/*----------------------------------------------------------------------------------------------
	Returns the width of a single tree branch given the pointer to the corresponding field
	editor. In our case this returns the same value all the time because every tree node
	is the same width and that width places the left edge of the fields just beyond the
	+/- box.
----------------------------------------------------------------------------------------------*/
int ConcWnd::GetBranchWidth(AfDeFieldEditor * pdfe)
{
	return kdxpLeftMargin + kdxpBoxWid + kdxpRtTreeGap;
}

/*---------------------------------------------------------------------------------------------
	@param hvo Hvo of line line to make current.
	@param icfe Index to the field editor to make current.
	@param fMakeVisible Flag indicating whether or not to scroll into view, the new current
		line.
	@return True if it succeeded in opening a new field. False if the current field editor
		can't be closed or if there are no editable fields below the current field.
----------------------------------------------------------------------------------------------*/
void ConcWnd::SetCurrentLine(HVO hvo, int icfe, bool fMakeVisible)
{
	if (icfe < 0)
		icfe = m_icfeCurrent;

	// Remove existing selection.
	ConcFieldEditor * pcfe = NULL;
	if (m_icfeCurrent >= 0)
		pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(m_icfeCurrent));

	if (pcfe)
		pcfe->SetSelected(false);

	// Turn on selected field editor.
	pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(icfe));
	Assert(pcfe);
	m_icfeCurrent = icfe;
	m_hvoCurrent = hvo;
	pcfe->SetSelected();
	
	if (fMakeVisible)
		MakeCurrentVisible();

	HVO hvoGroup = pcfe->GetHvoGroup();
	if (m_hvoCurrent != hvoGroup)
	{
		// Presumably a detail line; try to select in other pane.
		// We are a ConcWnd. That makes us an AfLazyDeWnd, and AfDeSplitChild, and hence an
		// AfSplitChild. Our parent is a ConcSplitterWnd, which is an AfSplitFrame.
		// Above that is a ConcClientWnd, which is an AfClientWnd, which is an AfWnd.
		// It directly contains a ConcHeaderWnd and a ConcTextHeaderWnd, the latter
		// in m_qcthw. The ConcTextHeaderWnd contains m_qctw, the ConcTextWnd we want.
		ConcClientWnd * pccw = m_pchw->GetClientWindow();
		Assert(pccw);
		pccw->GetTextHeaderWindow()->TextWindow()->SelectTwfic(m_hvoCurrent);
	}
	else
	{
		// On Headword, update Draft pane with first instance of word
		int cTwfic, chvoTwfic;
		CheckHr(m_qcvd->get_IntProp(hvoGroup, ktagWfiWordform_TwficCount, &cTwfic));
		CheckHr(m_qcvd->get_VecSize(hvoGroup, kflidTxtWordformInContext_Analysis,
			&chvoTwfic));
		if (cTwfic != chvoTwfic)
		{
			SeMainWnd * pwmw = dynamic_cast<SeMainWnd *>(m_pchw->MainWindow());
			Assert(pwmw);
			pwmw->LoadWord(hvoGroup);
			CheckHr(m_qcvd->get_VecSize(hvoGroup, kflidTxtWordformInContext_Analysis,
				&chvoTwfic));
			if (cTwfic != chvoTwfic)
			{
				// Our little sanity check shows that the actual number of ocurrences of this
				// word has changed since we read the value from the database. So we need to
				// update the cache and the headword display.
				CheckHr(m_qcvd->CacheIntProp(hvoGroup, ktagWfiWordform_TwficCount,
					chvoTwfic));
				CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, hvoGroup,
					ktagWfiWordform_TwficCount, 0, 0, 0));
			}
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Make the "current line" (m_icfeCurrent/m_hvoCurrent) visible
----------------------------------------------------------------------------------------------*/
void ConcWnd::MakeCurrentVisible()
{
	// Make a selection in the row we want to find out its offset from the start of the field.
	ConcFieldEditor * pcfe = dynamic_cast<ConcFieldEditor *>(FieldAt(m_icfeCurrent));
	IVwRootBox * prootb = pcfe->GetRootBox();
	IVwSelectionPtr qvwsel;
	if (m_hvoCurrent == pcfe->GetHvoGroup())
	{
		// Initial, don't care editable, not a range, don't install.
		CheckHr(prootb->MakeSimpleSel(true, false, false, false, &qvwsel));
	}
	else
	{
		VwSelLevInfo rgvsli[1];
		rgvsli[0].tag = kflidTxtWordformInContext_Analysis;
		rgvsli[0].cpropPrevious = 0;
		int chvoTwfic;
		CheckHr(m_qcvd->get_VecSize(pcfe->GetHvoGroup(), kflidTxtWordformInContext_Analysis,
			&chvoTwfic));
		HVO hvoTwfic = 0;
		for (int ihvo = 0; ihvo < chvoTwfic && hvoTwfic != m_hvoCurrent; ihvo++)
		{
			CheckHr(m_qcvd->get_VecItem(pcfe->GetHvoGroup(), kflidTxtWordformInContext_Analysis, 
				ihvo, &hvoTwfic));
		}
		rgvsli[0].ihvo = ihvo - 1;
		CheckHr(prootb->MakeTextSelInObj(0, 1, rgvsli, 0, NULL,
			true, false, false, false, false, &qvwsel));
	}
	pcfe->UpdatePosition(); // may be invisible, so need this before GetParaLocation.
	Rect rcRow; // relative to the root box.
	CheckHr(qvwsel->GetParaLocation(&rcRow));

	// Get the current scroll position.
	SCROLLINFO si = {isizeof(si), SIF_PAGE | SIF_POS | SIF_RANGE};
	GetScrollInfo(SB_VERT, &si);
	int dypPos = si.nPos;

	// Get the size of the visible part of the window.
	Rect rc;
	GetClientRect(rc);

	// See if we need to scroll up to make the bottom of rcRow visible.
	int dypBottom = rcRow.bottom;
	if (dypBottom > dypPos + rc.bottom)
	{
		// It's off the bottom of the window.
		si.nPos += dypBottom - (dypPos + rc.bottom);
		SetScrollInfo(SB_VERT, &si, true);
		::InvalidateRect(m_hwnd, NULL, true); // Repaint entire window.
	}
	else if (rcRow.top < dypPos)
	{
		// It's off the top of the window.
		si.nPos -= dypPos - rcRow.top;
		SetScrollInfo(SB_VERT, &si, true);
		::InvalidateRect(m_hwnd, NULL, true); // Repaint entire window.
	}
}

/*----------------------------------------------------------------------------------------------
	Overriding OpenNextEditor to select the next line and prevent the Framework from opening 
	the next editor. 
	@param dxpCursor Not used.
	@return false all the time because we never really open an active editor.
----------------------------------------------------------------------------------------------*/
bool ConcWnd::OpenNextEditor(int dxpCursor)
{
	if (EndEdit())
	{
		HVO hvoNew;
		int icfeNew;
		GetNextLineInfo(m_hvoCurrent, m_icfeCurrent, &hvoNew, &icfeNew);
		SetCurrentLine(hvoNew, icfeNew);
		::SetFocus(Hwnd());
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Overriding OpenPreviousEditor to select the next line and prevent the Framework from opening 
	the previous editor. 
	@param dxpCursor ignored.
	@param fTopCursor ignored.
	@return false all the time because we never really open an active editor.
----------------------------------------------------------------------------------------------*/
bool ConcWnd::OpenPreviousEditor(int dxpCursor, bool fTopCursor)
{
	if (EndEdit())
	{
		HVO hvoNew;
		int icfeNew;
		GetPrevLineInfo(m_hvoCurrent, m_icfeCurrent, &hvoNew, &icfeNew);
		SetCurrentLine(hvoNew, icfeNew);
		::SetFocus(Hwnd());
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Try to open the field at idfe for editing. If it is not editable, and fSearch is true,
	keep looking at following editors and open the first one that is editable. This also selects
	the active field editor.
	@param idfe Index of the field we want to open.
	@param fSearch True if we should keep looking at following fields for the first
		editable field.
	@return True if it succeeded in opening a new field. False if the current field editor
		can't be closed or if there are no editable fields at or below idfe.
----------------------------------------------------------------------------------------------*/
bool ConcWnd::OpenEditor(int idfe, bool fSearch)
{
	ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(m_pdfe);
	bool fRet = SuperClass::OpenEditor(idfe, fSearch);
	m_fHasFocus = true;
TRACE2("ConcWnd::OpenEditor: %d, %d\n", m_fHasFocus,0);

	if (fRet && m_pdfe && pcfe != m_pdfe)
	{
		if (pcfe)
			pcfe->SetSelected(false);
		pcfe = reinterpret_cast<ConcFieldEditor *>(m_pdfe);
		pcfe->SetSelected();
		pcfe->GetRootBox()->MakeSimpleSel(true, true, false, true, NULL);
	}
	return fRet;
}

/*----------------------------------------------------------------------------------------------
	Tom said, "This is the EndEdit function for the ConcWnd."
----------------------------------------------------------------------------------------------*/
bool ConcWnd::EndEdit(HWND hwndNew)
{
	// If a field editor is open and it's OK to close, close it and clear its pointer.
	if (!CloseEditor())
		return false;

	// If the editor was successfully closed or we got here when there wasn't an editor
	// open, determine whether ConcWnd still has focus, clear the flag indicating there's
	// a field editor open and repaint the line so the head word goes back to the same
	// colors as the rest of the line.
/*	if (!m_pdfe)
	{
		if (hwndNew && hwndNew != m_hwnd)
		{
			m_fHasFocus = false;
		}

		SetCurrentLine(m_hvoCurrent);
	}
*/
	return true;
}

/*----------------------------------------------------------------------------------------------
	When a Concordance detail line is selected, giving focus back to the Concordance pane from 
	another application the OS sends a WM_SETFOCUS, WM_LBUTTONDOWN, WM_LBUTTONUP for a single 
	click. Since all we want to do is just put focus back to the Concordance pane and 
	not change the line that's selected, we only want to process the WM_SETFOCUS. This means that 
	on a WM_SETFOCUS we will ignore all mouse messages (bool fIgnoreMouseMsgs) for a period of 
	time. If a double click message comes through it needs handled as a WM_LBUTTONDBLCLK.

	This mess is necessary to handle the case where an application othert han Translation Editor
	is selected and then a Concordance line is selected. When a WM_SETFOCUS message is received:
		fIgnoreMouseMsgs is set until the WM_TIMER zzz expires 

	Handle window messages. Return true if handled.
	See ${AfWnd#FWndProc} for parameter and return descriptions.
----------------------------------------------------------------------------------------------*/
bool ConcWnd::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
//if (WM_MOUSEMOVE != wm && WM_TIMER != wm && WM_ERASEBKGND != wm && WM_NCHITTEST != wm && WM_SETCURSOR != wm)
//	TRACE2("ConcWnd::FWndProc: 0x%x, %d\n", wm, wp);

	switch(wm)
	{
	case WM_LBUTTONDOWN:
//TRACE2("ConcWnd::FWndProc: WM_LBUTTONDOWN %d, %d\n", m_fHasFocus,wp);
		if (IgnoreLButtonDown())
		{
			KillTimer(m_hwnd, kidFocusClickDelay);
			SetIgnoreLButtonDown(false);
			SetIgnoreLButtonUp(true);
			return true;
		}

		m_lpLBUTTONDOWNSaved = -1;
		if (HasFocus())
		{
			lnRet = SuperClass::FWndProc(wm, wp, lp, lnRet);
		}
		else
		{
			::SetFocus(m_hwnd);
			lnRet = true;
		}
		break;

	case WM_LBUTTONUP:
//TRACE2("ConcWnd::FWndProc: WM_LBUTTONUP %d, %d\n", m_fHasFocus, m_lpLBUTTONDOWNSaved);
		if (IgnoreLButtonUp())
		{
			SetIgnoreLButtonUp(false);
			return true;
		}
		
		if (m_fDblClkInProgress)
		{
			m_fDblClkInProgress = false;
			m_lpLBUTTONDOWNSaved = -1;
		}
		else if (m_lpLBUTTONDOWNSaved != -1)
		{
			SetTimer(m_hwnd, kidWaitForDBLCLK, GetDoubleClickTime(), NULL);
		}
		lnRet = true;
		break;

	case WM_TIMER:
		if (wp == kidWaitForDBLCLK)
		{
			KillTimer(m_hwnd, kidWaitForDBLCLK);
//TRACE2("ConcWnd::FWndProc: WM_TIMER-1 %d, %d\n", m_fHasFocus, m_lpLBUTTONDOWNSaved);
			if (ProcessLClick(wp, (int)(short)LOWORD(m_lpLBUTTONDOWNSaved),
				(int)(short)HIWORD(m_lpLBUTTONDOWNSaved)))
			{
				EditData((int)(short)LOWORD(m_lpLBUTTONDOWNSaved),
				(int)(short)HIWORD(m_lpLBUTTONDOWNSaved));
			}
			lnRet = true;
//TRACE2("ConcWnd::FWndProc: WM_TIMER-2 %d, %d\n", m_fHasFocus, m_lpLBUTTONDOWNSaved);
		}

		else if (wp == kidFocusClickDelay)
		{
			KillTimer(m_hwnd, kidFocusClickDelay);
			SetIgnoreLButtonDown(false);
			lnRet = true;
		}
		else
			lnRet = SuperClass::FWndProc(wm, wp, lp, lnRet);

		break;

	case WM_SETFOCUS:
		{
//TRACE2("ConcWnd::FWndProc: SETFOCUS %d, %d\n", m_fHasFocus,wp);
			SetTimer(m_hwnd, kidFocusClickDelay, GetDoubleClickTime() - 1, NULL);
			SetIgnoreLButtonDown(true);
			m_fHasFocus = true;

			m_pchw->GetClientWindow()->SetChildWithFocus(m_hwnd);
			m_pchw->GetSplitterWindow()->SetCurrentPane(this);

			// If there's any data in the window, this will force the selected line to be
			// repainted so its background color is appropriate to the window's focused state.
			if (m_vdfe.Size() > 0 && m_icfeCurrent < m_vdfe.Size() && !m_pdfe)
				SetCurrentLine(m_hvoCurrent, m_icfeCurrent, false);

			// remove the command handler for the draft pane. This is necessary, because 
			// ConcWnd is not derived fromAfVwRootSite --> SetActiveRootBox gets never called
			// for ConcWnd --> ConcTextWnd's command handler remains active even when we are
			// in ConcWnd/ConcFieldEditor
			AfMainWnd * pafw = m_pchw->MainWindow();
			pafw->SetActiveRootBox(NULL);

			lnRet = true;
			break;
		}

	case WM_KILLFOCUS:
#ifndef NO_HACK_NEEDED
		// Check whether the window has been shut down already.  This is only a hacked up
		// bandage, not a fix, since a closed window should not be receiving messages!
		if (!::IsWindowVisible(m_hwnd))
			break;
#endif /*NO_HACK_NEEDED*/

		m_fHasFocus = false;

		// If there's any data in the window, this will force the selected line to be
		// repainted so its background color is appropriate to the window's focused state.
		if (m_vdfe.Size() > 0 && m_icfeCurrent < m_vdfe.Size() && !m_pdfe)
			SetCurrentLine(m_hvoCurrent, m_icfeCurrent, false);

		lnRet = true;
		break;

	case WM_MBUTTONDOWN:
	case WM_RBUTTONDOWN:
		// If the user right-clicks (or middle button-clicks) then make sure the line they
		// clicked on is made current by simulating a left button click. Then pass on the right
		// click message so the context menu becomes visible. Sending a left-click when the
		// line being clicked on is already current has an undesired affect of putting the user
		// in the edit mode, then the right-click shows the context menu. All we really want is
		// the context menu to popup. To avoid going into edit mode, I first call SelectHeadwordset m_icfeCurrent
		// to an invalid value so it fools SelectHeadword into thinking the field editor just
		// right-clicked is different from what was current before the click. It's sort of
		// kludgy, but actually, works quite well... if I do say so myself... which I just did.
		ProcessLClick(wp, (int)(short)LOWORD(lp), (int)(short)HIWORD(lp));
		// fall through
	default:
		lnRet = SuperClass::FWndProc(wm, wp, lp, lnRet);
	}
	return lnRet;
}

/*----------------------------------------------------------------------------------------------
	Process key down messages (WM_KEYDOWN). Handles F2 for creating an active field editor for
	current line and Enter for completing the edit.
	@param wp Virtual key code.
	@param lp Key data: scan code, repeat info, flags.
	@return Return true if processed.
----------------------------------------------------------------------------------------------*/
bool ConcWnd::OnKeyDown(WPARAM wp, LPARAM lp)
{
	switch(wp)
	{
	case VK_HOME:
		{
			ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(0));
			SetCurrentLine(pcfe->GetHvoGroup(), 0);
			::SetFocus(Hwnd());
			break;
		}
	case VK_END:
		{
			ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(m_vdfe.Size()-1));
			// get expanded state, if expanded get twfic count, get last twfic, setcurrentline 
			// with that hvo otherwise...
			HVO hvoGroup = pcfe->GetHvoGroup();
			if (pcfe->GetExpansion() == kdtsExpanded)
			{
				int chvoTwfic = 0;
				CheckHr(m_qcvd->get_VecSize(hvoGroup, kflidTxtWordformInContext_Analysis,
					&chvoTwfic));
				if (chvoTwfic > 0)
				{
					HVO hvoLastTwfic = 0; 
					CheckHr(m_qcvd->get_VecItem(hvoGroup, kflidTxtWordformInContext_Analysis, 
						(chvoTwfic - 1), &hvoLastTwfic));
					SetCurrentLine(hvoLastTwfic, m_vdfe.Size()-1);
				}
				else
					SetCurrentLine(hvoGroup, m_vdfe.Size()-1);
			}
			else
				SetCurrentLine(hvoGroup, m_vdfe.Size()-1);

			::SetFocus(Hwnd());
			break;
		}
	case VK_PRIOR: // Page Up
		{
			SuperClass::OnKeyDown(wp, lp);
			ProcessLClick(0, ConcFieldEditor::GetDetailRefColRightMarginPos() + 1, 1);
			break;
		}
	case VK_NEXT: // Page Down
		{
			SuperClass::OnKeyDown(wp, lp);
			Rect rc;
			GetClientRect(rc);
			ProcessLClick(0, ConcFieldEditor::GetDetailRefColRightMarginPos() + 1,
				rc.bottom - m_pchw->GetConcDetailLineHeight() + 1);
			break;
		}
	case VK_UP: // Up Arrow
		OpenPreviousEditor();
		break;
	case VK_DOWN: // Down Arrow
		OpenNextEditor();
		break;
	case VK_TAB:
		if (EndEdit())
		{
			ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(m_icfeCurrent));
			SetCurrentLine(pcfe->GetHvoGroup());
			// ENHANCE RonM (TomB): Does coding standard require an Assert()?
			::SetFocus(m_pchw->GetClientWindow()->GetTextHeaderWindow()->Hwnd());
		}
		break;
	case VK_ESCAPE:
		// we already restored the original contents of popup editor in ConcFieldEditorWnd
	case VK_RETURN:
		if (EndEdit())
		{
			ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(m_icfeCurrent));
			SetCurrentLine(pcfe->GetHvoGroup());
			::SetFocus(Hwnd());
		}
		break;
	case VK_LEFT: // Left Arrow
		{	// Need braces, without them: Error C2360: initialization of 'pcfe' & 'hvoGroup' 
			// is skipped by 'case' label.
			ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(m_icfeCurrent));
			HVO hvoGroup = pcfe->GetHvoGroup();
			if (m_hvoCurrent != hvoGroup)
				SetCurrentLine(hvoGroup);
			else
				pcfe->Collapse();
			break;
		}
	case VK_RIGHT: // Right Arrow
		{	// Need braces, without them: Error C2360: initialization of 'pcfe' & 'hvoGroup' 
			// is skipped by 'case' label.
			ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(m_icfeCurrent));
			HVO hvoGroup = pcfe->GetHvoGroup();
			if (m_hvoCurrent == hvoGroup)
			{
				// Account for scrolling.
				SCROLLINFO si = {isizeof(si), SIF_PAGE | SIF_POS | SIF_RANGE};
				GetScrollInfo(SB_VERT, &si);
				int dypFieldTop = -si.nPos + TopOfField(pcfe);
				if (pcfe->GetExpansion() != kdtsExpanded)
					ToggleExpansionAndScroll(m_icfeCurrent, dypFieldTop);
				else
				{ // Select first detail line
					// Get the number of detail lines in the current head word.
					int chvoTwfic;
					CheckHr(m_qcvd->get_VecSize(hvoGroup, kflidTxtWordformInContext_Analysis,
						&chvoTwfic));
					if (chvoTwfic > 0)
					{
						// Get the hvo of the first detail line below the current head word.
						HVO hvoFirstTwfic = 0; 
							CheckHr(m_qcvd->get_VecItem(hvoGroup, kflidTxtWordformInContext_Analysis, 
								0, &hvoFirstTwfic));
						SetCurrentLine(hvoFirstTwfic);
					}
				}
			}
			break;
		}
	case VK_BACK: // Backspace
		break;
	case VK_F2: // F2
		Assert(!m_pdfe);
		OpenEditor(m_icfeCurrent, false);
		break;
	default:
		return SuperClass::OnKeyDown(wp, lp);
	}
	return true; // Don't pass the message on.
}

/*----------------------------------------------------------------------------------------------
	First selects the Headword and then toggles the expansion state of the field editor.
	@param grfmk Indicates whether various virtual keys are down.
	@param xp The x-coord of the mouse relative to the upper-left corner of the client.
	@param yp The y-coord of the mouse relative to the upper-left corner of the client.
	@return Return true if processed.
----------------------------------------------------------------------------------------------*/
bool ConcWnd::OnLButtonDblClk(uint grfmk, int xp, int yp)
{
	KillTimer(m_hwnd, kidWaitForDBLCLK);
	m_fDblClkInProgress = true;

	ProcessLClick(grfmk, xp, yp);
	
	int dypFieldTop;
	int idfe = GetField(yp, &dypFieldTop);
	if (idfe < m_vdfe.Size())
		return ToggleExpansionAndScroll(idfe, dypFieldTop);
	return true; 
}

/*----------------------------------------------------------------------------------------------
	Select the clicked line.
	@param grfmk Indicates whether various virtual keys are down.
	@param xp The x-coord of the mouse relative to the upper-left corner of the client.
	@param yp The y-coord of the mouse relative to the upper-left corner of the client.
	Return true if the click was on the previously selected item and it is editable.
	(For now, only headwords are editable, but eventually this will return true for
	detail lines as well.)
----------------------------------------------------------------------------------------------*/
bool ConcWnd::ProcessLClick(uint grfmk, int xp, int yp)
{
	int dypFieldTop;
	int idfe = GetField(yp, &dypFieldTop);
	AfDeFieldEditor * pdfe = FieldAt(idfe); // Get current editor.
	ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(pdfe);
	IVwRootBox * prootb = pcfe->GetRootBox();
	IVwGraphics * pvg;
	Rect rcSrcRoot, rcDstRoot;
	pcfe->GetGraphics(&pvg, &rcSrcRoot, &rcDstRoot);
	pcfe->ReleaseGraphics(pvg); // does the Release() for us.
	IVwSelectionPtr qvwsel;
	CheckHr(prootb->MakeSelAt(xp, yp, rcSrcRoot, rcDstRoot, false, &qvwsel));

	HVO hvoClick;
	HVO hvoPrev = -1;
	//ISilDataAccessPtr qsda;
	//CheckHr(prootb->get_DataAccess(&qsda));
	// TODO RonM: avoid infinite loop
	for (int ilev = 0 ; ; ilev++)
	{
		PropTag tag;
		int ihvo, cpropPrev;
		IVwPropertyStorePtr qvps;
		if (!qvwsel ||
			FAILED(qvwsel->PropInfo(false, ilev, &hvoClick, &tag, &ihvo, &cpropPrev, &qvps)))
		{
			// Something unexpected went wrong, ignore
			Warn("Could not find relevant object clicked");
			return false;
		}
		if (tag == 0 && xp <= ConcFieldEditor::GetDetailRefColRightMarginPos())
		{
			// REVIEW JohnT(TomB): There must be a less kludgey way to avoid an infinite
			// loop when the user clicks the reference column of the detail line.
			return ProcessLClick(grfmk, ConcFieldEditor::GetDetailRefColRightMarginPos() + 1, yp);
		}
		Assert(tag != 0); // This will avoid infinite loop when bad stuff happens.
		if (tag == kflidTxtWordformInContext_Analysis && hvoPrev >= 0)
		{
			// Click was in a detail line.
			// The second condition is needed to make sure the click
			// was not on the number of occurrences.
			hvoClick = hvoPrev;
			break;
		}
		// Test this second, it would have also tested positive for detail lines.
		if (hvoClick == pcfe->GetHvoGroup())
			break;
		hvoPrev = hvoClick;
	}
	// Make sure we account for Line, Hvo_Group where they clicked, Tag of the item (column)

	// If the user just clicked the currently selected headword and the user didn't just
	// click here from a different window, open an editor for the current word.
	if (idfe == m_icfeCurrent && hvoClick == m_hvoCurrent && HasFocus() &&
		// TODO RonM(TomB): Remove this last condition to turn on editing of detail rows.
		// Note: There is more work to do to actually make this work.
		hvoClick == pcfe->GetHvoGroup())
	{
		return true;
	}
	else
	{
		// ENHANCE RonM: Handle grfmk for selecting multiple lines if needed.
		SetCurrentLine(hvoClick, idfe);
		::SetFocus(m_hwnd);
		return false;
	}
}

/*----------------------------------------------------------------------------------------------
	Edit the data at the given point.
	@param xp The x-coord of the mouse relative to the upper-left corner of the client.
	@param yp The y-coord of the mouse relative to the upper-left corner of the client.
----------------------------------------------------------------------------------------------*/
void ConcWnd::EditData(int xp, int yp)
{
	int dypFieldTop;
	int idfe = GetField(yp, &dypFieldTop);
	AfDeFieldEditor * pdfe = FieldAt(idfe); // Get current editor.
	ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(pdfe);
	IVwRootBox * prootb = pcfe->GetRootBox();

	SuperClass::OnLButtonDownInEditor(idfe, pdfe, dypFieldTop, MK_LBUTTON, xp, yp);
	m_fHasFocus = true;
	AfVwSelInfo avsi;
	avsi.Load(prootb);
	PropChangedSelection(prootb, m_hvoCurrent);
	avsi.Set(prootb, true, NULL);
}

/*----------------------------------------------------------------------------------------------
	Make the clicked line current or (if already current) activate an editor window.
	@param idfe Index of the field we want to open.
	@param pdfe
	@param dypFieldTop
	@param grfmk Indicates whether various virtual keys are down.
	@param xp The x-coord of the mouse relative to the upper-left corner of the client.
	@param yp The y-coord of the mouse relative to the upper-left corner of the client.
----------------------------------------------------------------------------------------------*/
void ConcWnd::OnLButtonDownInEditor(int idfe, AfDeFieldEditor * pdfe, int dypFieldTop,
	uint grfmk, int xp, int yp)
{
//	bool fSameSelection; // True if selection is the same Headword as previous selection
//	fSameSelection = SelectHeadword(grfmk, xp, yp);
//	if (fSameSelection)
	m_lpLBUTTONDOWNSaved = MAKELPARAM(xp, yp); //Used in WM_TIMER
//	else
//		m_lpLBUTTONDOWNSaved = -1;
}


/*----------------------------------------------------------------------------------------------
	Show the context menu for the the concordance.
----------------------------------------------------------------------------------------------*/
bool ConcWnd::OnContextMenu(HWND hwnd, Point pt)
{
	HMENU hmenuPopup = ::CreatePopupMenu();

	StrApp str(kcidSpellStatUndecided);
	::AppendMenu(hmenuPopup, MF_STRING, kcidSpellStatUndecided, str.Chars());
	str.Load(kcidSpellStatIncorrect);
	::AppendMenu(hmenuPopup, MF_STRING, kcidSpellStatIncorrect, str.Chars());
	str.Load(kcidSpellStatCorrect);
	::AppendMenu(hmenuPopup, MF_STRING, kcidSpellStatCorrect, str.Chars());
	::TrackPopupMenu(hmenuPopup, TPM_LEFTALIGN | TPM_RIGHTBUTTON, pt.x, pt.y, 0, m_hwnd, NULL);
	::DestroyMenu(hmenuPopup);
	return true;
}

/*----------------------------------------------------------------------------------------------
	Make sure the spelling context menu get's the proper state information.
----------------------------------------------------------------------------------------------*/
bool ConcWnd::CmsUpdateSpellingStatusPopup(CmdState & cms)
{
	SeMainWnd * pwmw = dynamic_cast<SeMainWnd *>(MainWindow());
	Assert(pwmw);
	CustViewDaPtr qsda;
	pwmw->GetSeLpInfo()->GetDataAccess(&qsda);
	Assert(qsda);
	
	// Get the current status of the word.
	int nStatus;
	CheckHr(qsda->get_IntProp(m_hvoCurrent, kflidWfiWordform_SpellingStatus, &nStatus));

	switch(cms.Cid())
	{
	case kcidSpellStatUndecided:
		cms.SetCheck(nStatus == kspellUndecided);
		break;
	case kcidSpellStatIncorrect:
		cms.SetCheck(nStatus == kspellIncorrect);
		break;
	case kcidSpellStatCorrect:
		cms.SetCheck(nStatus == kspellCorrect);
		break;
	default:
		break;
	}
	
	return true;
}

/*----------------------------------------------------------------------------------------------
	The user has chosen a spelling status from the context menu. Process their choice.
----------------------------------------------------------------------------------------------*/
bool ConcWnd::CmdChangeSpellingStatus(Cmd * pcmd)
{
	int nNewStatus;

	// Determine what status the user chose.
	switch(pcmd->m_cid)
	{
	case kcidSpellStatUndecided:
		nNewStatus = kspellUndecided;
		break;
	case kcidSpellStatIncorrect:
		nNewStatus = kspellIncorrect;
		break;
	case kcidSpellStatCorrect:
		nNewStatus = kspellCorrect;
		break;
	default: break;
	}

	SeMainWnd * pwmw = dynamic_cast<SeMainWnd *>(MainWindow());
	Assert(pwmw);
	CustViewDaPtr qsda;
	pwmw->GetSeLpInfo()->GetDataAccess(&qsda);
	Assert(qsda);
	
	// Get the current status of the word.
	int nOldStatus;
	CheckHr(qsda->get_IntProp(m_hvoCurrent, kflidWfiWordform_SpellingStatus, &nOldStatus));
	
	// If the status has changed then update the database and the concordance view.
	if (nOldStatus != nNewStatus)
	{
		CheckHr(qsda->SetInt(m_hvoCurrent, kflidWfiWordform_SpellingStatus, nNewStatus));
		CheckHr(qsda->PropChanged(NULL, kpctNotifyAll, m_hvoCurrent,
			kflidWfiWordform_SpellingStatus, 0, 0, 0));
	}
	return true;
}

/*----------------------------------------------------------------------------------------------
	Set the size of the vector of field editors to the number of wordforms.
----------------------------------------------------------------------------------------------*/
void ConcWnd::ResetVdfeSize(bool fCloseEditors)
{
	if (fCloseEditors)
		CloseAllEditors();
	int chvoWords;
	CheckHr(m_qcvd->get_VecSize(m_hvoWordformInventory, kflidWordformInventory_Wordforms, 
		&chvoWords));
	m_vdfe.Resize(chvoWords);
}

/*----------------------------------------------------------------------------------------------
	Redraw Columns
----------------------------------------------------------------------------------------------*/
void ConcWnd::ReDrawColumns()
{
	// Determine the number of logical pixels per vertical inch
	HDC hdc = ::GetDC(NULL);
	int xPointsPerPixel = kdzmpInch / ::GetDeviceCaps(hdc, LOGPIXELSX);
	::ReleaseDC(NULL, hdc);

	// Go through each column and set up the table column widths vector with the new widths.
	Vector<VwLength> vvlen;
	vvlen.Resize(m_pchw->vcci().Size());
	for (int icol = 0; icol < m_pchw->vcci().Size(); icol++)
	{
		vvlen[icol].unit = kunPoint1000;
		vvlen[icol].nVal = m_pchw->vcci()[icol].dxpCurrentWidth * xPointsPerPixel;
	}

	// We must subtract the scroll bar width to get the actual width of the data
	// portion of the last column.
	int mpScrollBarWidth = ::GetSystemMetrics(SM_CXVSCROLL) * xPointsPerPixel;
	vvlen[m_pchw->vcci().Size()-1].nVal -= mpScrollBarWidth;

	// Save the base width of column one.
	int nWidthCol1;
	Assert(icol > 0); // better have at least one column!
	if (icol > 0)
	{
		nWidthCol1 = vvlen[0].nVal;
	}

	for (int idfe = m_vdfe.Size(); --idfe >= 0; )
	{
		if (m_vdfe[idfe])
		{
			// For each field editor, we will subtract the tree branch width to get the 
			// actual width of the data portion of column one.
			vvlen[0].nVal = nWidthCol1 - 
				GetBranchWidth(m_vdfe[idfe]) * xPointsPerPixel;
			// Now set the column widths
			dynamic_cast<ConcFieldEditor *>(m_vdfe[idfe])->SetTableColWidths(vvlen.Begin(),
				vvlen.Size());
		}
	}
	::UpdateWindow(m_hwnd);
}
/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
void ConcWnd::OnReleasePtr()
{
	m_qcvd.Clear();
	m_qwfichgw.Clear();
	m_qtssLabel.Clear();
	SuperClass::OnReleasePtr();
}

/*----------------------------------------------------------------------------------------------
	This receives an hvo and index to a field editor and, taking into account the field
	editor's expanded state, determines what is the previous hvo and editor index.

	@param hvoCurr Hvo of the line immediately following the line whose hvo we're looking for.
	@param icfeCurr Index of the field editor hvoCurr is in.
	@param phvoNew Pointer to the previous line's hvo (this is a return value).
	@param picfeNew Pointer to the previous line's field editor index (this is a return value).
----------------------------------------------------------------------------------------------*/
void ConcWnd::GetPrevLineInfo(HVO hvoCurr, int icfeCurr,
							 HVO * phvoNew, int * picfeNew)
{
	Assert(icfeCurr >= 0 && icfeCurr < m_vdfe.Size());
	ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(icfeCurr));
	Assert(pcfe);

	// Initialize these at the onset to return the current hvo and editor index.
	*phvoNew = hvoCurr;
	*picfeNew = icfeCurr;

	// If the current line is a head word then...
	if (hvoCurr == pcfe->GetHvoGroup())
	{
		if (icfeCurr == 0)
		{
			// Already at top!
			return;
		}

		// At this point we know the previous line's hvo will be in the head word
		// immediately preceeding the one whose field editor index is icfeCurr. Therefore,
		// determine whether or not the preceeding head word is expanded.
		*picfeNew = icfeCurr - 1;
		ConcFieldEditor * pcfePrev = reinterpret_cast<ConcFieldEditor *>(FieldAt(*picfeNew));
		Assert(pcfePrev);
		int hvoPrevGroup = pcfePrev->GetHvoGroup();
		
		// Get the number of detail lines in the preceeding head word.
		int chvoTwfic;
		CheckHr(m_qcvd->get_VecSize(hvoPrevGroup, kflidTxtWordformInContext_Analysis,
			&chvoTwfic));

		// If the preceeding head word has no detail lines or the preceeding head word is
		// collapsed, just return the hvo of the preceeding head word.
		if (chvoTwfic == 0 || pcfePrev->GetExpansion() == kdtsCollapsed)
		{
			*phvoNew = hvoPrevGroup;
			return;
		}

		// Get the hvo of the last detail line under the preceeding head word and return it.
		if (chvoTwfic > 0)
			CheckHr(m_qcvd->get_VecItem(hvoPrevGroup,
				kflidTxtWordformInContext_Analysis, chvoTwfic - 1, phvoNew));
		return;
	}
		
	int hvoGroup = pcfe->GetHvoGroup();

	// Get the number of detail lines in the current head word.
	int chvoTwfic;
	CheckHr(m_qcvd->get_VecSize(hvoGroup, kflidTxtWordformInContext_Analysis,
		&chvoTwfic));

	// Get the hvo of the first detail line below the current head word.
	HVO hvoFirstTwfic = 0; 
	if (chvoTwfic > 0)
		CheckHr(m_qcvd->get_VecItem(hvoGroup, kflidTxtWordformInContext_Analysis, 
			0, &hvoFirstTwfic));
	
	// If the current hvo is the first detail line below a head word, return the hvo of
	// the head word.
	if (hvoCurr == hvoFirstTwfic)
	{
		*phvoNew = hvoGroup;
		return;
	}
	
	// Loop through all the detail lines and find the one whose hvo is the same as that
	// of the current. This will give us the index into the vector of the current detail
	// line's hvo.
	HVO hvoTwfic = 0;
	for (int ihvo = chvoTwfic - 1; ihvo >= 0 && hvoTwfic != hvoCurr; ihvo--)
	{
		CheckHr(m_qcvd->get_VecItem(hvoGroup, kflidTxtWordformInContext_Analysis, 
			ihvo, &hvoTwfic));
	}

	// Assuming we found the index of the current detail line's hvo,
	// return the previous hvo in the vector.
	if (hvoTwfic == hvoCurr && ihvo >= 0)
		CheckHr(m_qcvd->get_VecItem(hvoGroup, kflidTxtWordformInContext_Analysis, 
			ihvo, phvoNew));
}

/*----------------------------------------------------------------------------------------------
	This receives an hvo and index to a field editor and, taking into account the field
	editor's expanded state, determines what is the next hvo and editor index.

	@param hvoCurr Hvo of the line immediately preceeding the line whose hvo we're looking for.
	@param icfeCurr Index of the field editor hvoCurr is in.
	@param phvoNew Pointer to the next line's hvo (this is a return value).
	@param picfeNew Pointer to the next line's field editor index (this is a return value).
----------------------------------------------------------------------------------------------*/
void ConcWnd::GetNextLineInfo(HVO hvoCurr, int icfeCurr,
							 HVO * phvoNew, int * picfeNew)
{
	Assert(icfeCurr >= 0 && icfeCurr < m_vdfe.Size());
	ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(icfeCurr));
	Assert(pcfe);
	int hvoGroup = pcfe->GetHvoGroup();
	
	// Initialize these at the onset to return the current hvo and editor index.
	*phvoNew = hvoCurr;
	*picfeNew = icfeCurr;

	// Get the number of detail lines in the current head word.
	int chvoTwfic;
	CheckHr(m_qcvd->get_VecSize(hvoGroup, kflidTxtWordformInContext_Analysis,
		&chvoTwfic));

	// Get the hvo of the last detail line under the current head word.
	HVO hvoLastTwfic = 0; 
	if (chvoTwfic > 0)
		CheckHr(m_qcvd->get_VecItem(hvoGroup, kflidTxtWordformInContext_Analysis, 
			chvoTwfic - 1, &hvoLastTwfic));

	// If the current head word has no detail lines or we're on a head word and it's not
	// expanded or we're on the last detail line of an expanded head word, then return the
	// index to the next field editor and it's hvo.
	if (chvoTwfic == 0 ||
		(pcfe->GetExpansion() == kdtsCollapsed && hvoCurr == hvoGroup) ||
		(pcfe->GetExpansion() == kdtsExpanded  && hvoCurr == hvoLastTwfic))
	{
		*picfeNew = icfeCurr + (icfeCurr < m_vdfe.Size() - 1 ? 1 : 0);
		ConcFieldEditor * pcfe = reinterpret_cast<ConcFieldEditor *>(FieldAt(*picfeNew));
		*phvoNew = pcfe->GetHvoGroup();
		return;
	}

	// Get the hvo of the first detail line below the current head word.
	HVO hvoFirstTwfic = 0; 
	if (chvoTwfic > 0)
		CheckHr(m_qcvd->get_VecItem(hvoGroup, kflidTxtWordformInContext_Analysis, 
			0, &hvoFirstTwfic));
	
	// At this point we know we're deailing with an expanded head word. Therefore, If
	// we're on the head word, return the hvo of its first detail line. and the index
	// to the same field editor as the head word (.
	if (hvoCurr == hvoGroup)
	{
		*phvoNew = hvoFirstTwfic;
		return;
	}

	// Loop through all the detail lines and find the one whose hvo is the same as that
	// of the current. This will give us the index into the vector of the current detail
	// line's hvo.
	HVO hvoTwfic = 0;
	for (int ihvo = 0; ihvo < chvoTwfic && hvoTwfic != hvoCurr; ihvo++)
	{
		CheckHr(m_qcvd->get_VecItem(hvoGroup, kflidTxtWordformInContext_Analysis, 
			ihvo, &hvoTwfic));
	}

	// Assuming we found the index of the current detail line's hvo, increment it and
	// return the next hvo in the vector.
	if (hvoTwfic == hvoCurr && ihvo < chvoTwfic)
		CheckHr(m_qcvd->get_VecItem(hvoGroup,	kflidTxtWordformInContext_Analysis,
			ihvo, phvoNew));
}

/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
AfDeFieldEditor * ConcWnd::MakeEditorAt(int idfe)
{
	HVO hvoGroup;
	CheckHr(m_qcvd->get_VecItem(m_hvoWordformInventory, kflidWordformInventory_Wordforms, 
		idfe, &hvoGroup));

	SeMainWnd * pwmw = dynamic_cast<SeMainWnd *>(MainWindow());
	Assert(pwmw);

	// Now we're doing this only when we expand a word
//    pwmw->LoadWord(hvoGroup);

	ConcFieldEditorPtr qcfe;
	qcfe.Attach(NewObj ConcFieldEditor(hvoGroup, m_qcvd, m_pchw));

	// When we make the first editor we need initialize the current hvo.
	if (idfe == m_icfeCurrent)
		m_hvoCurrent = hvoGroup;

//	ITsStrFactoryPtr qtsf;
//	qtsf.CreateInstance(CLSID_TsStrFactory);
//	int encEng = StrUtil::ParseWs("ENG");
//	ITsStringPtr qtssHelp;
//	CheckHr(qtsf->MakeStringRgch(L"", 0, encEng, &qtssHelp));

	ITsStringPtr qtssHelp;
	AfApp::GetResourceTss(kstidHelpMakeEditorAt, &qtssHelp);

	// Get the default vernacular writing system.
	SeLpInfo * pwlpi = pwmw->GetSeLpInfo();
	int encVern = pwlpi->VernWss()[0];

	// Use an empty string as the label. The FLID (arg 2) is arbitrary, but must not be zero
	// because of an Assert.
	qcfe->Initialize(hvoGroup, 1, 0, m_qtssLabel, qtssHelp, this, NULL, encVern);

	m_vdfe[idfe] = qcfe;
	return qcfe.Detach();
}

/***********************************************************************************************
	ConcFieldEditor stuff.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Constructor/Destructor.
----------------------------------------------------------------------------------------------*/
ConcFieldEditor::ConcFieldEditor(HVO hvoGroup, CustViewDa * pcvd, ConcHeaderWnd * pchw) :
	m_dtsExpanded(kdtsCollapsed),
	m_hvoGroup(hvoGroup),
	m_qcvd(pcvd),
	m_pchw(pchw),
	m_fTwficDataLoaded(false)
{
}

ConcFieldEditor::~ConcFieldEditor()
{
}

/*----------------------------------------------------------------------------------------------
	Expand or contract the node by switching its view into the opposite mode.
----------------------------------------------------------------------------------------------*/
void ConcFieldEditor::ToggleExpansion()
{
	if (m_dtsExpanded == kdtsExpanded)
		Collapse();
	else
		Expand();
}

/*----------------------------------------------------------------------------------------------
	Expand the node by setting its view to kdtsExpanded.
----------------------------------------------------------------------------------------------*/
void ConcFieldEditor::Expand()
{
	if (m_dtsExpanded != kdtsExpanded)
	{
		int cTwfic, chvoTwfic;
		CheckHr(m_qcvd->get_IntProp(m_hvoGroup, ktagWfiWordform_TwficCount, &cTwfic));
		CheckHr(m_qcvd->get_VecSize(m_hvoGroup, kflidTxtWordformInContext_Analysis,
			&chvoTwfic));
		if (cTwfic != chvoTwfic)
		{
			SeMainWnd * pwmw = dynamic_cast<SeMainWnd *>(m_pchw->MainWindow());
			Assert(pwmw);
			pwmw->LoadWord(m_hvoGroup);
			CheckHr(m_qcvd->get_VecSize(m_hvoGroup, kflidTxtWordformInContext_Analysis,
				&chvoTwfic));
			if (cTwfic != chvoTwfic)
			{
				// Our little sanity check shows that the actual number of ocurrences of this
				// word has changed since we read the value from the database. So we need to
				// update the cache and the headword display.
				CheckHr(m_qcvd->CacheIntProp(m_hvoGroup, ktagWfiWordform_TwficCount,
					chvoTwfic));
				CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, m_hvoGroup,
					ktagWfiWordform_TwficCount, 0, 0, 0));
			}
		}
		m_dtsExpanded = kdtsExpanded;
		m_qcvc->SetExpansion(m_dtsExpanded);
		CheckHr(m_qrootb->Reconstruct());
	}
}
/*----------------------------------------------------------------------------------------------
	Collapse the node by setting its view to kdtsCollapsed.
----------------------------------------------------------------------------------------------*/
void ConcFieldEditor::Collapse()
{
	if (m_dtsExpanded != kdtsCollapsed)
	{
		m_dtsExpanded = kdtsCollapsed;
		m_qcvc->SetExpansion(m_dtsExpanded);
		CheckHr(m_qrootb->Reconstruct());

		// If the current line is a detail line then make sure the current line gets changed
		// to the head word line. It wouldn't be good to have the current line be stuck to
		// one of the detail lines when it's not even visible due to a collapse.
		ConcWnd * pconw = dynamic_cast<ConcWnd *>(GetDeWnd());
		Assert(pconw);
		if (pconw->FieldAt(pconw->m_icfeCurrent) == this)
		{
			if (pconw->HvoCurrent() != m_hvoGroup)
				pconw->SetCurrentLine(m_hvoGroup);
		}
	}
}

/*----------------------------------------------------------------------------------------------
	Provide access to member vairable
----------------------------------------------------------------------------------------------*/
void ConcFieldEditor::SetSelected(bool fSelected, bool fUpdateProps)
{
	m_fSelected = fSelected;

	if (fUpdateProps && m_qrootb)
		PropChangedSelection(m_qrootb, m_hvoGroup);
}

/*----------------------------------------------------------------------------------------------
	Answer whether the specified HVO is selected.
----------------------------------------------------------------------------------------------*/
bool ConcFieldEditor::IsHvoSelected(HVO hvo)
{
	if (!m_fSelected)
		return false;
	ConcWnd * pconw = dynamic_cast<ConcWnd *>(GetDeWnd());
	Assert(pconw);
	return hvo == pconw->HvoCurrent();
}

/*----------------------------------------------------------------------------------------------
	Create a new window for editing the contents.
	@param hwndParent The hwnd for the parent window.
	@param rcBounds The position of the new window relative to the parent window.
	@return A pointer to the new AfDeVwWnd window. The caller obtains one (and initially only)
		reference count to the window.
----------------------------------------------------------------------------------------------*/
AfDeVwWnd * ConcFieldEditor::CreateEditWnd(HWND hwndParent, Rect & rcBounds)
{
	ConcFieldEditorWndPtr qdvw;
	qdvw.Attach(NewObj ConcFieldEditorWnd(this));

	// ENHANCE JohnT: could some or all of this be moved into BeginEdit so subclasses
	// don't have to mess with it? Maybe we could pass in wcs instead of rcBounds,
	// and have this method just call InitChild with appropriate parameters.
	WndCreateStruct wcs;
	wcs.InitChild(_T("AfVwWnd"), hwndParent, 0);
	wcs.style |= WS_VISIBLE;
	wcs.SetRect(rcBounds);

	qdvw->CreateHwnd(wcs);
	return qdvw.Detach(); // Give the caller the initial ref count.
}

/*----------------------------------------------------------------------------------------------
	Compute the layout. Overridden to report progress.
----------------------------------------------------------------------------------------------*/
int ConcFieldEditor::SetHeightAt(int dxpWidth)
{
	ConcWnd * pconw = dynamic_cast<ConcWnd *>(m_qadsc.Ptr());
	if (pconw->m_nProgress++ % 40 == 0)
	{
		// Report progress
		StrApp staReport;
		staReport.Format(_T("formatted %d of %d groups"), pconw->m_nProgress, pconw->m_nWords);
		AfStatusBar * psb = pconw->MainWindow()->GetStatusBarWnd();
		psb->StoreHelpText(staReport.Chars());
		psb->DisplayHelpText();
	}
	return SuperClass::SetHeightAt(dxpWidth);
}

/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
void ConcFieldEditor::OnReleasePtr()
{
	m_qcvc.Clear();
	m_qcvd.Clear(); // contains string ptrs
	SuperClass::OnReleasePtr();
}

/*----------------------------------------------------------------------------------------------
	Make the root box.
----------------------------------------------------------------------------------------------*/
void ConcFieldEditor::MakeRoot(IVwGraphics * pvg, ILgWritingSystemFactory * pwsf,
	IVwRootBox ** pprootb)
{
	AssertPtrN(pwsf);
	*pprootb = NULL;

	IVwRootBoxPtr qrootb;
	qrootb.CreateInstance(CLSID_VwRootBox);
	CheckHr(qrootb->SetSite(this));
	qrootb->put_DefaultTextType(kttpPublishedText);

	int frag = kfrGroup;

	// Set up a new view constructor.
	m_qcvc.Attach(NewObj ConcVc(m_ws, m_pchw, this));
	IVwViewConstructor * pvvc = m_qcvc;

	if (pwsf)
		CheckHr(m_qcvd->putref_WritingSystemFactory(pwsf));
	CheckHr(qrootb->putref_DataAccess(m_qcvd));
	// Pass phony vectors of one item each (the last argument) by taking the address of
	// each single item.
	IVwStylesheet * psty = this->m_pchw->GetClientWindow()->GetStyleSheet();
	CheckHr(qrootb->SetRootObjects(&m_hvoGroup, &pvvc, &frag, psty, 1));

	SeMainWnd * ptmw = dynamic_cast<SeMainWnd *>(GetDeWnd()->MainWindow());
	ptmw->RegisterRootBox(qrootb);
	*pprootb = qrootb.Detach();
}

/*----------------------------------------------------------------------------------------------
	Change the column widths in the field editor's root box.
----------------------------------------------------------------------------------------------*/
void ConcFieldEditor::SetTableColWidths(VwLength *prgvlen, int cvlen)
{
	CheckHr(m_qrootb->SetTableColWidths(prgvlen, cvlen));
}

/*----------------------------------------------------------------------------------------------
	Get the width of the tree branch corresponding to this field editor.
----------------------------------------------------------------------------------------------*/
int ConcFieldEditor::GetBranchWidth()
{
	// We know that the text in the tree is 0-length, so we can simplify the width calculation
	// as found in AfDeSplitChild::GetBranchWidth(AfDeFieldEditor * pdfe) 
	return s_nBranchWidth;
}

/*----------------------------------------------------------------------------------------------
	Returns true if the contents of the Headword was changed.
----------------------------------------------------------------------------------------------*/
bool ConcFieldEditor::HeadwordChanged(StrUni &stuOrig, StrUni &stuNew)
{
	// Get the selection from the current view window.
	IVwSelectionPtr qvwsel;
	CheckHr(m_qrootb->get_Selection(&qvwsel));

	// Get the modified text.
	int ich, ws;
	ComBool fAssocPrev;
	HVO hvoObj;
	ITsStringPtr qtssModifiedText;
	PropTag tag;
	CheckHr(qvwsel->TextSelInfo(false, &qtssModifiedText, &ich, &fAssocPrev, &hvoObj, &tag, &ws));
	if (tag == kflidWfiWordform_Form)
	{
		const OLECHAR * pchModifiedText;
		int cch;
		// Get the modified Headword
		CheckHr(qtssModifiedText->LockText(&pchModifiedText, &cch));
		stuNew.Assign(const_cast<OLECHAR *>(pchModifiedText), cch);
		CheckHr(qtssModifiedText->UnlockText(pchModifiedText));

		// Get the original Headword.
		const OLECHAR * pchOrigText;
		ITsStringPtr qtssOrigText;
		CheckHr(m_qcvd->get_MultiStringAlt(m_hvoGroup, kflidWfiWordform_Form, ws, &qtssOrigText));
		CheckHr(qtssOrigText->LockText(&pchOrigText, &cch));
		stuOrig.Assign(const_cast<OLECHAR *>(pchOrigText), cch);
		CheckHr(qtssOrigText->UnlockText(pchOrigText));

		if (stuNew != stuOrig)
			return true;
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Validate the data and return true if it is valid. If invalid, the method should
	raise an error for the user indicating the problem that needs to be corrected.
	This only needs to be overwritten if data for this field can be in an invalid state
	(e.g., a date string that doesn't parse into a date).
	@return True if data is valid.
----------------------------------------------------------------------------------------------*/
bool ConcFieldEditor::IsOkToClose()
{
	static bool s_fInIsOkToClose = false;
	// If we're already in here, don't come in again.
	if (s_fInIsOkToClose)
		return false;

	s_fInIsOkToClose = true;
	bool fReturnValue = true;

	StrUni stuOrig, stuNew;
	if (HeadwordChanged(stuOrig, stuNew))
	{
		if (stuNew.Length() == 0)
		{ // Headword has been deleted
			fReturnValue = false;
			achar psz[250];
			_stprintf(psz, _T("Headword cannot be blank."));
			MessageBox( m_hwnd, psz, _T("Error with Headword"), MB_OK);
		}
		// ENHANCE RonM(TomB): Check for invalid characters.
		else
		{
			// Get number of occurrences for TextWordFormInContext.
			int cTwfic;
			CheckHr(m_qcvd->get_IntProp(m_hvoGroup, ktagWfiWordform_TwficCount, &cTwfic));

			bool fConfirm = true;
			if (fConfirm && fReturnValue && cTwfic > 1)
			{
				//Put up confirmation dialog box.
				//ENHANCE RonM (TomB):This dialog box needs to be Unicode compliant (i.e., using Graphite)
				achar psz[250];
				_stprintf(psz, _T("Change all %d instances?"), cTwfic);
				if (MessageBox(m_hwnd, psz, _T("Confirmation of Headword Change"), MB_YESNO | MB_ICONQUESTION) == IDNO)
				{
					// Don't change the spelling of the word, but quit editing the headword
					fReturnValue = false;
				}
			}
		}
	}

	s_fInIsOkToClose = false;
	return fReturnValue;
}

/*----------------------------------------------------------------------------------------------
	Load the word list if it's not already loaded. Step through the word list changing each 
	instance.
	
	Close the current editor, saving changes that were made. hwnd is the editor hwnd.
	@param fForce True if we want to force the editor closed without making any
		validity checks or saving any changes.
----------------------------------------------------------------------------------------------*/
void ConcFieldEditor::EndEdit(bool fForce)
{
	StrUni stuOrig, stuNew;
	if (HeadwordChanged(stuOrig, stuNew) && !fForce)
	{
		int cTwfic, chvoTwfic;
		CheckHr(m_qcvd->get_IntProp(m_hvoGroup, ktagWfiWordform_TwficCount, &cTwfic));
		CheckHr(m_qcvd->get_VecSize(m_hvoGroup, kflidTxtWordformInContext_Analysis,
			&chvoTwfic));
		if (cTwfic != chvoTwfic)
		{
			SeMainWnd * pwmw = dynamic_cast<SeMainWnd *>(m_pchw->MainWindow());
			Assert(pwmw);
			pwmw->LoadWord(m_hvoGroup);
			CheckHr(m_qcvd->get_VecSize(m_hvoGroup, kflidTxtWordformInContext_Analysis,
				&chvoTwfic));
		}

		HVO * prghvo = (HVO *)malloc(chvoTwfic * isizeof(HVO));
		for (int ihvo = 0; ihvo < chvoTwfic; ihvo++)
		{
			CheckHr(m_qcvd->get_VecItem(m_hvoGroup, kflidTxtWordformInContext_Analysis, ihvo,
				&(prghvo[ihvo])));
		}
		CheckHr(m_qcvc->LoadDataFor(NULL, prghvo, chvoTwfic, m_hvoGroup, 0, kfrDetailLine, 0));

		ITsStrBldrPtr qtsb;
//		for (ihvo = 0; ihvo < chvoTwfic; ihvo++)
		for (ihvo = chvoTwfic - 1; ihvo >= 0; ihvo--)
		{
			HVO hvoPara;
			ITsStringPtr qtssPara;
			int ichOffset;
			CheckHr(m_qcvd->get_ObjectProp(prghvo[ihvo], kflidCmObject_Owner, &hvoPara));
			Assert(hvoPara);
			CheckHr(m_qcvd->get_IntProp(prghvo[ihvo], kflidTxtWordformInContext_ParaCharOffset,
				&ichOffset));
			CheckHr(m_qcvd->get_StringProp(hvoPara, kflidStTxtPara_Contents, &qtssPara));

			// We will use this string builder to construct paragraph strings.
			CheckHr(qtssPara->GetBldr(&qtsb));
			CheckHr(qtsb->ReplaceRgch(ichOffset, ichOffset + stuOrig.Length(), stuNew.Chars(), 
				stuNew.Length(), NULL));
			CheckHr(qtsb->GetString(&qtssPara));
			CheckHr(m_qcvd->SetString(hvoPara, kflidStTxtPara_Contents, qtssPara));
			CheckHr(m_qcvd->PropChanged(NULL, kpctNotifyAll, hvoPara, kflidStTxtPara_Contents, 
				ichOffset, stuNew.Length(), stuOrig.Length()));
		}
		// REVIEW JohnW(RonM): Do we need to update the status of the "old" word to incorrect?
		// TODO TomB(RonM): Enable the model to remember spelling changes.
		free(prghvo);

	}
	SuperClass::EndEdit(fForce);
}

/*----------------------------------------------------------------------------------------------
	Handle keyboard message.
----------------------------------------------------------------------------------------------*/
bool ConcFieldEditorWnd::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	switch(nChar)
	{
	case VK_ESCAPE:
		{
			StrUni stuOrig, stuNew;
			if (m_pcfe->HeadwordChanged(stuOrig, stuNew))
			{
				// put stuOrig back into the popup editor and then EndEdit()
				if (stuNew.Length() != 0)
				{
					HRESULT hr = m_pcfe->GetRootBox()->MakeSimpleSel(true, true, true, true, NULL);
					// We ignore E_FAIL since the text window may be empty, in which case making a
					// selection is impossible.
					if (hr != E_FAIL)
						CheckHr(hr);
				}

				// Get the selection from the current view window.
				IVwSelectionPtr qvwsel;
				CheckHr(m_pcfe->GetRootBox()->get_Selection(&qvwsel));

				// Get the modified text.
				int ich, ws;
				ComBool fAssocPrev;
				HVO hvoObj;
				ITsStringPtr qtssModifiedText;
				PropTag tag;
				// ENHANCE RonM(TomB): Do we have to use TextSelInfo and the if() or can we use GetSelectionString?
				CheckHr(qvwsel->TextSelInfo(false, &qtssModifiedText, &ich, &fAssocPrev, &hvoObj, &tag, &ws));
				if (tag == kflidWfiWordform_Form)
				{
					// We will use this string builder to re-construct old content
					ITsStrBldrPtr qtsb;
					CheckHr(qtssModifiedText->GetBldr(&qtsb));
					CheckHr(qtsb->ReplaceRgch(0, stuNew.Length(), stuOrig.Chars(), 
						stuOrig.Length(), NULL));
					CheckHr(qtsb->GetString(&qtssModifiedText));
					qvwsel->ReplaceWithTsString(qtssModifiedText);
				}
			}
		} // fall through
	case VK_RETURN:
	case VK_UP: // Up Arrow
	case VK_DOWN: // Down Arrow
	case VK_TAB:
		{	// Need braces, without them: Error C2360: initialization of 'pconw' is skipped by 'case' label.
			ConcWnd * pconw = dynamic_cast<ConcWnd *>(AfWnd::GetAfWnd(::GetParent(m_hwnd)));
			AssertPtr(pconw);
			return pconw->OnKeyDown(nChar, MAKELONG(nRepCnt, nFlags));
			break;
		}
	case VK_PRIOR: // Page Up
	case VK_NEXT: // Page Down
		return true;
		break;
	default:
		return SuperClass::OnKeyDown(nChar, nRepCnt, nFlags);
	}
}

/*----------------------------------------------------------------------------------------------
	Process left button down (WM_LBUTTONDOWN). xp/yp are current coordinates. grfmk identifies
	button/keys pressed.
----------------------------------------------------------------------------------------------*/
bool ConcFieldEditorWnd::OnLButtonDown(uint grfmk, int xp, int yp) 
{
	AssertPtr(Window());
	::SetCapture(Window()->Hwnd());

	IVwRootBox * prootb = m_pcfe->GetRootBox();
	IVwGraphics * pvg;
	Rect rcSrcRoot, rcDstRoot;
	m_pcfe->GetGraphics(&pvg, &rcSrcRoot, &rcDstRoot);
	m_pcfe->ReleaseGraphics(pvg); // does the Release() for us.
	IVwSelectionPtr qvwsel;
	CheckHr(prootb->MakeSelAt(xp, yp, rcSrcRoot, rcDstRoot, false, &qvwsel));

	bool fEndEdit = false;
	HVO hvoClick;
	PropTag tag;
	int ihvo, cpropPrev;
	IVwPropertyStorePtr qvps;
	if (!qvwsel || FAILED(qvwsel->PropInfo(false, 0, &hvoClick, &tag, &ihvo, &cpropPrev, &qvps)))
	{
		// Something unexpected went wrong, ignore
		fEndEdit = true;
	}
	else if (hvoClick != m_pcfe->GetHvoGroup() || tag != kflidWfiWordform_Form)
	{
		// Click was not in the headword.
		fEndEdit = true;
	}

	if (fEndEdit)
	{
		ConcWnd * pconw = dynamic_cast<ConcWnd *>(m_pcfe->GetDeWnd());
		Assert(pconw);
		pconw->EndEdit();
		pconw->SetIgnoreLButtonUp(true);
	}
	else
	{
		SuperClass::OnLButtonDown(grfmk, xp, yp);
	}
	//OutputDebugString("Out of AfVwRootSite::OnLButtonDown\n");
	return true;
}
/*----------------------------------------------------------------------------------------------
	This will make sure the field editor gets closed when its window loses focus.
----------------------------------------------------------------------------------------------*/
bool ConcFieldEditorWnd::OnKillFocus(HWND hwndNew)
{
	IVwSelectionPtr qsel;
	m_pcfe->GetRootBox()->get_Selection(&qsel);
	if (!qsel)
		return true;
	ConcHeaderWnd * pchw = m_pcfe->GetConcHeaderWnd();
	ConcWnd * pconw = dynamic_cast<ConcWnd *>(pchw->GetSplitterWindow()->CurrentPane());
	AssertPtr(pconw);
	if (!pconw->EndEdit(hwndNew))
		return true;
	::SendMessage(pconw->Hwnd(), WM_KILLFOCUS, (WPARAM)hwndNew, (LPARAM)0);
//	pconw->SetCurrentLine(pconw->HvoCurrent());
	return true;
}

/*----------------------------------------------------------------------------------------------
	Enable/Disable formatting toolbar buttons and comboboxes (and the format font command)
----------------------------------------------------------------------------------------------*/
bool ConcFieldEditorWnd::CmsCharFmt(CmdState & cms)
{
	// When editing a headword, we don't need any toolbars enabled. No formatting can be done
	// here.
	cms.Enable(false);
	return true;
}


/***********************************************************************************************
	ConcVc stuff.
***********************************************************************************************/
/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
ConcVc::ConcVc(int encVern, ConcHeaderWnd * pchw, ConcFieldEditor * pcfeOwner)
{
	m_wsVern = encVern;
	m_dtsExpanded = kdtsCollapsed;
	m_pchw = pchw;
	m_pcfeOwner = pcfeOwner;
	m_qtsf.CreateInstance(CLSID_TsStrFactory);
}

/*----------------------------------------------------------------------------------------------
	This is a helper function to return a string representing the book for a twfic.
	ENHANCE TomB: For now, this just returns the SIL ID, but eventually, we want the user to
	be able to choose ScrBookRef.BookID or ScrBook.Name or ScrBook.Abbrev. 
----------------------------------------------------------------------------------------------*/
void ConcVc::GetBookAsString(ISilDataAccessPtr qsda, HVO hvoTwfic, SmartBstr &sbstrBook)
{
	HVO hvoPara, hvoStText, hvoT, hvoBook;
	CheckHr(qsda->get_ObjectProp(hvoTwfic, kflidCmObject_Owner, &hvoPara));
	CheckHr(qsda->get_ObjectProp(hvoPara, kflidCmObject_Owner, &hvoStText));
	int nFlid;
	CheckHr(qsda->get_IntProp(hvoStText, kflidCmObject_OwnFlid, &nFlid));
	switch(nFlid)
	{
	case kflidScrSection_Content:
	case kflidScrSection_Heading:
		CheckHr(qsda->get_ObjectProp(hvoStText, kflidCmObject_Owner, &hvoT));
		break;
	case kflidScrBook_Title:
		hvoT = hvoStText;
		break;
	default:
		Assert(false); // Unexpected owning field for StText
		hvoT = 0;
		break;
	}
	CheckHr(qsda->get_ObjectProp(hvoT, kflidCmObject_Owner, &hvoBook));
	Assert(hvoBook);
	switch(m_pchw->cri().tag)
	{
	case ktagName:
	case ktagAbbrev:
		{
			ITsStringPtr qtssBook;
			CheckHr(qsda->get_MultiStringAlt(hvoBook, m_pchw->cri().tag, 
				m_pchw->cri().ws, &qtssBook));
			const OLECHAR * pch;
			int cch;
			CheckHr(qtssBook->LockText(&pch, &cch));
			sbstrBook.Assign(pch, cch);
			CheckHr(qtssBook->UnlockText(pch));
		}
		break;
	case ktagSIL:
	default:
		{
			HVO hvoScrBookRef;
			CheckHr(qsda->get_ObjectProp(hvoBook, kflidScrBook_BookId, &hvoScrBookRef));
			CheckHr(qsda->get_UnicodeProp(hvoScrBookRef, ktagScrBookRef_TitleCaseBookId, &sbstrBook));
		}
	}
}

/*----------------------------------------------------------------------------------------------
	This allows us to reject a change made to a Headword, after applying changes to Twfics.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ConcVc::UpdateProp(ISilDataAccess * psda, HVO hvo, int tag, int frag,
								ITsString * ptssVal, ITsString ** pptssRepVal)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(psda);
	ChkComArgPtrN(ptssVal);
	ChkComOutPtr(pptssRepVal);

	if (tag == kflidWfiWordform_Form)
	{
		// *pptssRepVal = ptssVal;
		// Call PropChanged to fix the display
		CheckHr(psda->PropChanged(NULL, kpctNotifyAll, hvo, tag, 0, 0, 0));
	}

	END_COM_METHOD(g_factConcVc, IID_IVwViewConstructor);
}
/*----------------------------------------------------------------------------------------------
	This is the main interesting method of displaying objects and fragments of them. It displays
	the wordform as a table showing frequency and References. And possibly other things.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ConcVc::Display(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pvwenv);

	// Determine the number of logical pixels per vertical inch
	HDC hdc = ::GetDC(NULL);
	int xPointsPerPixel = kdzmpInch / ::GetDeviceCaps(hdc, LOGPIXELSX);
	int yPointsPerPixel = kdzmpInch / ::GetDeviceCaps(hdc, LOGPIXELSY);
	::ReleaseDC(NULL, hdc);
	const int kmpCellPadding = 0; //1 * xPointsPerPixel; // 2 pixels padding
	ConcWnd * pconw = dynamic_cast<ConcWnd *>(m_pcfeOwner->GetDeWnd());

	switch(frag)
	{
	case kfrGroup:
		{
			// We must subtract the tree branch width to get the  actual width of the data
			// portion of column one.
			int mpTreeBranchWidth = m_pcfeOwner->GetBranchWidth() * xPointsPerPixel;
			// We must subtract the scroll bar width to get the actual width of the data
			// portion of the last column.
			int mpScrollBarWidth = ::GetSystemMetrics(SM_CXVSCROLL) * xPointsPerPixel;

			int xpTableWidth = 0;
			// Display the root group object header row
			for(int icci = 0; icci < m_pchw->vcci().Size(); icci++)
			{
				xpTableWidth += m_pchw->vcci()[icci].dxpCurrentWidth * xPointsPerPixel;
			}
			// Subtract the width of the tree branch and width of the scroll bar
			xpTableWidth -= mpTreeBranchWidth;
			xpTableWidth -= mpScrollBarWidth;
			VwLength vlTab = { xpTableWidth, kunPoint1000 };
			//VwLength vlTab = { 10000, kunPercent100 };

			CheckHr(pvwenv->OpenTable(m_pchw->vcci().Size(),
				&vlTab,
				1 * xPointsPerPixel, // border thickness about a pixel
				kvaLeft, // default alignment
				kvfpVoid, // no border
				kvrlNone, // no rules between cells
				0, // no forced space between cells
				kmpCellPadding)); // padding inside cells

			PropTag tagDummy = ktagSelectionDummy;
			pvwenv->NoteDependency(&hvo, &tagDummy, 1);

TRACE2("ConcVc::Display %d, %d\n", pconw->HasFocus(),0);

		for(icci = 0; icci < m_pchw->vcci().Size(); icci++)
			{
				int mpAdjust = (icci == 0)? mpTreeBranchWidth :
					((icci == m_pchw->vcci().Size() - 1)? mpScrollBarWidth : 0);
				VwLength vlCol = { m_pchw->vcci()[icci].dxpCurrentWidth * xPointsPerPixel - mpAdjust,
					kunPoint1000 };
				CheckHr(pvwenv->MakeColumns(1, vlCol)); // "1" is column count, not index
			}

			CheckHr(pvwenv->OpenTableRow());

			for(icci = 0; icci < m_pchw->vcci().Size(); icci++)
			{
				// Set the current line's background and foreground colors to
				// make it look selected.
				if (m_pcfeOwner->IsHvoSelected(hvo))
				{
					int clrFore = pconw->HasFocus() ?
						::GetSysColor(COLOR_HIGHLIGHTTEXT) : ::GetSysColor(COLOR_BTNTEXT);

					int clrBack = pconw->HasFocus() ?
						::GetSysColor(COLOR_HIGHLIGHT) : ::GetSysColor(COLOR_3DFACE);

					CheckHr(pvwenv->put_IntProperty(ktptBackColor, ktpvDefault, clrBack));
					CheckHr(pvwenv->put_IntProperty(ktptForeColor, ktpvDefault, clrFore));
				}

				CheckHr(pvwenv->OpenTableCell(1,1));
				switch(m_pchw->vcci()[icci].tag)
				{
				case ktagHeadword:
					{
						// If the head word's editor is open for editing then draw a border
						// around it and set its background and foreground colors to match
						// those of the system colors for text windows.
						if (pconw->GetActiveFieldEditor() && pconw->HvoCurrent() == hvo)
						{
							CheckHr(pvwenv->put_IntProperty(ktptBorderTop, ktpvMilliPoint,
								yPointsPerPixel));
							CheckHr(pvwenv->put_IntProperty(ktptBorderBottom, ktpvMilliPoint,
								yPointsPerPixel));
							CheckHr(pvwenv->put_IntProperty(ktptBorderLeading, ktpvMilliPoint,
								xPointsPerPixel));
							CheckHr(pvwenv->put_IntProperty(ktptBorderTrailing, ktpvMilliPoint,
								xPointsPerPixel));
							CheckHr(pvwenv->put_IntProperty(ktptBackColor, ktpvDefault,
								::GetSysColor(COLOR_WINDOW)));
							CheckHr(pvwenv->put_IntProperty(ktptForeColor, ktpvDefault,
								::GetSysColor(COLOR_WINDOWTEXT)));
						}
						CheckHr(pvwenv->put_IntProperty(ktptMarginLeading,
							ktpvMilliPoint, 5 * xPointsPerPixel));

						CheckHr(pvwenv->put_IntProperty(kspMaxLines, ktpvDefault, 1));
						CheckHr(pvwenv->AddStringAltMember(kflidWfiWordform_Form, m_wsVern, this));
					}
				break;
				case ktagStatus:
					{
						// Get the spelling status of the current word form.
						ISilDataAccessPtr qsda;
						CheckHr(pvwenv->get_DataAccess(&qsda));
						int nSpellingStatus;
						CheckHr(qsda->get_IntProp(hvo, kflidWfiWordform_SpellingStatus,
							&nSpellingStatus));
						
						CheckHr(pvwenv->put_IntProperty(ktptAlign, ktpvEnum, ktalCenter));

						// Get a pointer to the main window object in order to retrieve a
						// spelling status bitmap for the current spelling status.
						SeMainWnd * pwmw = dynamic_cast<SeMainWnd *>(pconw->MainWindow());
						CheckHr(pvwenv->AddPicture(pwmw->GetSpellingStatusPic(
							nSpellingStatus,
							m_pcfeOwner->IsHvoSelected(hvo),
							pconw->HasFocus())));
						
						PropTag tagT = kflidWfiWordform_SpellingStatus;
						pvwenv->NoteDependency(&hvo, &tagT, 1);
					}
				break;
				case ktagCount:
					{
						CheckHr(pvwenv->put_IntProperty(ktptEditable, ktpvEnum, ktptNotEditable));
						CheckHr(pvwenv->put_IntProperty(kspMaxLines, ktpvDefault, 1));

						CheckHr(pvwenv->put_IntProperty(ktptAlign, ktpvEnum, ktalRight));
						CheckHr(pvwenv->put_IntProperty(ktptMarginTrailing,
							ktpvMilliPoint, 4 * xPointsPerPixel));

						
						CheckHr(pvwenv->OpenParagraph());
#ifdef NEED_DISPLAY_VEC
						CheckHr(pvwenv->AddObjVec(kflidTxtWordformInContext_Analysis, this, 
							kfrCount));
#else
						CheckHr(pvwenv->AddIntProp(ktagWfiWordform_TwficCount));
#endif
						CheckHr(pvwenv->CloseParagraph());
					}
				break;
				case ktagReference:
#ifdef NEED_DISPLAY_VEC
					{
						CheckHr(pvwenv->put_IntProperty(ktptEditable, ktpvEnum, ktptNotEditable));
						CheckHr(pvwenv->put_IntProperty(kspMaxLines, ktpvDefault, 1));
						CheckHr(pvwenv->put_IntProperty(ktptMarginLeading,
							ktpvMilliPoint, 7 * xPointsPerPixel));
						CheckHr(pvwenv->OpenParagraph());
						CheckHr(pvwenv->AddObjVec(kflidTxtWordformInContext_Analysis, this, 
							kfrRefPara));
						CheckHr(pvwenv->CloseParagraph());
					}
#endif
				break;
				default:
					Assert(false);
					break;
				}
				CheckHr(pvwenv->CloseTableCell());
			}
			CheckHr(pvwenv->CloseTableRow());
			CheckHr(pvwenv->CloseTable());

			// If this word is expanded, display the concordance detail rows
			if (m_dtsExpanded == kdtsExpanded)
			{
				// expanded view: make a table and add rows
				CheckHr(pvwenv->AddLazyVecItems(kflidTxtWordformInContext_Analysis, 
					this, kfrDetailLine));
			}

		}
		break;
	case kfrScrRef:
		{
			// Display a TxtWordformInContext by showing its reference
			ISilDataAccessPtr qsda;
			CheckHr(pvwenv->get_DataAccess(&qsda));
			int nVerseRefStart, nVerseRefEnd;
			CheckHr(qsda->get_IntProp(hvo, kflidTxtWordformInContext_VerseRefStart,
				&nVerseRefStart));
			CheckHr(qsda->get_IntProp(hvo, kflidTxtWordformInContext_VerseRefEnd,
				&nVerseRefEnd));
			int nBook, nChapStart, nChapEnd, nVerseStart, nVerseEnd;

			GetBCV(nVerseRefStart, nBook, nChapStart, nVerseStart);
			GetBCV(nVerseRefEnd, nBook, nChapEnd, nVerseEnd);
			SmartBstr sbstrBook;
			GetBookAsString(qsda, hvo, sbstrBook);
			StrUni stuRef;
			stuRef.Format(L"%s %d%s", sbstrBook.Chars(), nChapStart, L":");
			if (nChapStart != nChapEnd)
			{
				stuRef.FormatAppend(L"%d%s%d%s%d", nVerseStart, L"-", nChapEnd, L":",
					nVerseEnd);
			}
			else if (nVerseStart != nVerseEnd)
				stuRef.FormatAppend(L"%d%s%d", nVerseStart, L"-", nVerseEnd);
			else
				stuRef.FormatAppend(L"%d", nVerseEnd);

			ITsStringPtr qtssRef;
			// TODO RonM (TomB): Use appropriate writing system depending on how book names
			// are being displayed.
			CheckHr(m_qtsf->MakeStringRgch(const_cast<OLECHAR *>(stuRef.Chars()),
				stuRef.Length(), m_wsVern, &qtssRef));
			HVO rghvoT[2] = {hvo, hvo};
			PropTag rgtagT[2] = {kflidTxtWordformInContext_VerseRefStart,
				kflidTxtWordformInContext_VerseRefEnd};
			pvwenv->NoteDependency(rghvoT, rgtagT, 2);
			CheckHr(pvwenv->put_IntProperty(ktptLineHeight, ktpvMilliPoint,
				-(m_pchw->GetConcDetailLineHeight()) * xPointsPerPixel));
			CheckHr(pvwenv->OpenParagraph());
			CheckHr(pvwenv->AddString(qtssRef));
			CheckHr(pvwenv->CloseParagraph());
		}
		break;
	case kfrDetailLine:
		{ // Block
			// Display a TxtWordformInContext by showing its text ref and context.
			// Each row is its own table to facilitate laziness.

			// Table occupies all available width
			VwLength vlTab = { 10000, kunPercent100 };
			
			CheckHr(pvwenv->OpenDiv());
			CheckHr(pvwenv->put_IntProperty(ktptLeadingIndent, ktpvMilliPoint, 
				GetDetailLineIndent()));

			// If the current detail line is selected then highlight it with colors
			// appropriate for the focused state of the concordance window.
			if (m_pcfeOwner->IsHvoSelected(hvo))
			{
				int clrFore = pconw->HasFocus() ?
					::GetSysColor(COLOR_HIGHLIGHTTEXT) : ::GetSysColor(COLOR_BTNTEXT);

				int clrBack = pconw->HasFocus() ?
					::GetSysColor(COLOR_HIGHLIGHT) : ::GetSysColor(COLOR_3DFACE);

				CheckHr(pvwenv->put_IntProperty(ktptBackColor, ktpvDefault, clrBack));
				CheckHr(pvwenv->put_IntProperty(ktptForeColor, ktpvDefault, clrFore));
			}
			CheckHr(pvwenv->OpenTable(2,
				&vlTab,
				GetDetailBorderWidth() * xPointsPerPixel,
				kvaLeft, // default alignment
				kvfpVoid, // no border
				kvrlNone, // no rules between cells
				0, // no forced space between cells
				kmpCellPadding)); // padding inside cells
			// Column 1 - Reference
			VwLength vlCol1 = { GetRefColWidth(), kunPoint1000 };
			CheckHr(pvwenv->MakeColumns(1, vlCol1)); // arg is column count, not index
			// Column 2 takes all available space except what col 1 uses - Scripture
			VwLength vlCol2 = { kdzmpInch, kunRelative };
			CheckHr(pvwenv->MakeColumns(1, vlCol2));

			PropTag tagDummy = ktagSelectionDummy;
			pvwenv->NoteDependency(&hvo, &tagDummy, 1);


			CheckHr(pvwenv->OpenTableRow());

			CheckHr(pvwenv->OpenTableCell(1,1));
			CheckHr(pvwenv->put_IntProperty(ktptEditable, ktpvEnum, ktptNotEditable));
			CheckHr(pvwenv->put_IntProperty(kspMaxLines, ktpvDefault, 1));
			CheckHr(pvwenv->AddObj(hvo, this, kfrScrRef));
			CheckHr(pvwenv->CloseTableCell());

			CheckHr(pvwenv->OpenTableCell(1,1));
			ISilDataAccessPtr qsda;
			CheckHr(pvwenv->get_DataAccess(&qsda));
			// Look up position of word in paragraph, lookup length of word to be able to
			// highlight the word in the detail section.
			int ichMin, ichLim, cch;
			ITsStringPtr qtssWordform;
			CheckHr(qsda->get_IntProp(hvo, kflidTxtWordformInContext_ParaCharOffset, &ichMin));
			// Must use TxtWordformInContext.Form as the basis for getting the length of the
			// wordform. It may have a different length than the one in WfiWordform_Form
			// because captial and lowercase equivalents are not always the same length.
			CheckHr(qsda->get_StringProp(hvo, kflidTxtWordformInContext_Form, &qtssWordform));
			CheckHr(qtssWordform->get_Length(&cch));
			ichLim = ichMin + cch;

			CheckHr(pvwenv->put_IntProperty(ktptLineHeight, ktpvMilliPoint,
				-(m_pchw->GetConcDetailLineHeight()) * xPointsPerPixel));
			CheckHr(pvwenv->OpenConcPara(ichMin, ichLim, kcpoDefault, kdzmpInch * 5/2));
			PropTag tagT = kflidTxtWordformInContext_ParaCharOffset;

			pvwenv->NoteDependency(&hvo, &tagT, 1);
			CheckHr(pvwenv->AddObjProp(kflidCmObject_Owner, this, kfrContext));
			CheckHr(pvwenv->CloseParagraph());
			CheckHr(pvwenv->CloseTableCell());

			CheckHr(pvwenv->CloseTableRow());
			CheckHr(pvwenv->CloseTable());

			CheckHr(pvwenv->CloseDiv());
		}
		break;
	case kfrContext:
		{
			// Display the context of a word by displaying the contents of the paragraph
			// TODO RonM(TomB): Finish this to get conc detail lines to center properly and
			// use correct font based on paragraph font.
			ISilDataAccessPtr qsda;
			CheckHr(pvwenv->get_DataAccess(&qsda));
			ITsTextPropsPtr qttp;
			CheckHr(qsda->get_UnknownProp(hvo, kflidStPara_StyleRules, IID_ITsTextProps,
				(void **) &qttp));
			// Cause a regenerate when the style changes.
			int flid = kflidStPara_StyleRules;
			// REVIEW JohnT(TomB): Why isn't this working? We don't regenerate this when the
			// paragraph style changes.
			CheckHr(pvwenv->NoteDependency(&hvo, &flid, 1));
			if (qttp)
			{
				ITsPropsBldrPtr qtpb;
				CheckHr(qttp->GetBldr(&qtpb));
				// REVIEW JohnT(TomB): For now, we are just using the vernacular writing system, but
				// some of the paragraphs appearing in the conc detail rows could contain runs
				// that are not vernacular. Unless they are marked with a special character
				// style, they will not display correctly. This could be especially raunchy
				// when the whole paragraph is non-vernacular, and the concorded word is the
				// only vernacular word (in a run by itself). How can we apply PART of the
				// style, without overwriting a whole bunch of stuff that we don't want to
				// overwrite? Do we need to create on-the-fly conc-only styles, or do we need
				// to modify the framework to allow partial application of styles?
				CheckHr(qtpb->SetIntPropValues(ktptWs, ktpvDefault, m_wsVern));
				CheckHr(qtpb->GetTextProps(&qttp));
				IVwPropertyStorePtr qvps;
				qvps.CreateInstance(CLSID_VwPropertyStore);
				ConcClientWnd * pccw = m_pchw->GetClientWindow();
				SeLpInfoPtr qtlpi = dynamic_cast<SeLpInfo *>(pccw->GetCustViewDa()->GetLpInfo());
				TeStylesheet * ptsts = qtlpi->GetScriptureStylesheet();
				Assert(ptsts);
				CheckHr(qvps->putref_Stylesheet(ptsts));
				LgCharRenderProps chrp;
				CheckHr(qvps->get_ChrpFor(qttp, &chrp));
				StrUni stuFontFace(chrp.szFaceName);

				// REVIEW JohnT (TomB) Raid #3055: If multiple put_IntProperty are applied to 
				// pvwenv then the bolding of the concorded word is lost on the detail lines.
				if ((chrp.dympHeight / 1000) > m_pchw->GetConcDetailLineHeight())
					//Need to reduce the font size
					CheckHr(pvwenv->put_IntProperty(ktptFontSize, ktpvMilliPoint, 
					(m_pchw->GetConcDetailLineHeight() * 1000)));
				else
					CheckHr(pvwenv->put_IntProperty(ktptFontSize, ktpvMilliPoint,chrp.dympHeight));
				//BSTR bstrFontFamily;
				//CheckHr(qvps->get_FontFamily(&bstrFontFamily));
				//CheckHr(pvwenv->put_StringProperty(ktptFontFamily, bstrFontFamily));
				//CheckHr(pvwenv->put_StringProperty(ktptFontFamily, stuFontFace.Bstr()));
				//CheckHr(pvwenv->put_IntProperty(ktptItalic, ktpvEnum, chrp.fItalic));
				//int nUnderline;
				//CheckHr(qvps->get_IntProperty(ktptUnderline, &nUnderline));
				//CheckHr(pvwenv->put_IntProperty(ktptUnderline, ktpvEnum, nUnderline));
			}
			CheckHr(pvwenv->AddStringProp(kflidStTxtPara_Contents, this));
			break;
		}
	default:
		Assert(false);
		break;
	}
	return S_OK;

	END_COM_METHOD(g_factConcVc, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	This routine is used to estimate the height of an item. The item will be one of
	those you have added to the environment using AddLazyVecItems. Note that the calling code
	does NOT ensure that data for displaying the item in question has been loaded.
	The first three arguments are as for Display, that is, you are being asked to estimate
	how much vertical space is needed to display this item in the available width.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ConcVc::EstimateHeight(HVO hvo, int frag, int dxAvailWidth, int * pdyHeight)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pdyHeight);
	// TODO: Header and detail lines may not be the same height. Look at frag and return
	// appropriate value.
	*pdyHeight = m_pchw->GetConcDetailLineHeight();
	END_COM_METHOD(g_factConcVc, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	Load data needed to display the specified objects using the specified fragment.
	This is called before attempting to Display an item that has been listed for lazy display
	using AddLazyVecItems. It may be used to load the necessary data into the DataAccess object.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ConcVc::LoadDataFor(IVwEnv * pvwenv, HVO * prghvo, int chvo, HVO hvoParent,
	int tag, int frag, int ihvoMin)
{
	BEGIN_COM_METHOD;
	ChkComArgPtrN(pvwenv);
	ChkComArrayArg(prghvo, chvo);

	CustViewDaPtr qcvd = dynamic_cast<CustViewDa*>(m_pchw->GetClientWindow()->GetSilDa().Ptr());

	switch(frag)
	{
	case kfrDetailLine:
		{
			// ENHANCE TomB: Implement progress bar
			bool fStartProgressBar = false; // m_qstbr && !m_qstbr->IsProgressBarActive();
			int ihvo;
			HVO hvoPara, hvoStText;

			HvoVec vhvoPara; // vector of StTxtPara objects we need to load data about.
			for (HVO * phvo = prghvo; phvo < prghvo + chvo; phvo++)
			{
				qcvd->get_ObjectProp(*phvo, kflidCmObject_Owner, &hvoPara);
				Assert(hvoPara);
				qcvd->get_ObjectProp(hvoPara, kflidCmObject_Owner, &hvoStText);
				if (!hvoStText)
					vhvoPara.Push(hvoPara);
			}
			// If none of the wanted objects need loading we are done.
			if (vhvoPara.Size() == 0)
				return S_OK;
			IDbColSpecPtr qdcs;
			qdcs.CreateInstance(CLSID_DbColSpec);
			StrUni stuQuery;
			stuQuery.Format(L"select st.[Id], st.Owner$, st.OwnFlid$, stp.[Id], stp.Owner$, "
				L"stp.OwnFlid$ from StText_ st (readuncommitted) join StTxtPara_ stp (readuncommitted) on stp.Owner$ = st.[Id] and "
				L"stp.OwnFlid$ = %d where st.[Id] in (select distinct Owner$ from StTxtPara_ (readuncommitted) "
				L"where [Id] in (%d",	kflidStText_Paragraphs, vhvoPara[0]);
			for (ihvo = 1; ihvo < vhvoPara.Size(); ihvo++)
			{
				stuQuery.FormatAppend(L",%d", vhvoPara[ihvo]);
			}
			stuQuery.Append(L")) order by st.[Id], stp.OwnOrd$");

			// Set up column specs in qdcs
			qdcs->Clear();
			qdcs->Push(koctBaseId, 0, 0, 0);
			// ENHANCE JohnT(TomB): I think we should have another koct value for atomic object
			// properties so that the owner and flid can be set automatically in the
			// Load method without having to pass a duplicate column.
			qdcs->Push(koctObj, 1, kflidCmObject_Owner, 0);
			qdcs->Push(koctInt, 1, kflidCmObject_OwnFlid, 0);
			qdcs->Push(koctObjVec, 1, kflidStText_Paragraphs, 0);
			// ENHANCE JohnT(TomB): I think we should have another koct value for owned object
			// sequence/collection properties so that the owner can be set automatically in the
			// Load method without having to pass a duplicate column.
			qdcs->Push(koctObj, 4, kflidCmObject_Owner, 0);
			qdcs->Push(koctInt, 4, kflidCmObject_OwnFlid, 0);

			// ENHANCE TomB: Add pointer to status bar.
			qcvd->Load(stuQuery.Bstr(), qdcs, 0, 0, NULL /*m_qstbr*/, FALSE);

			// Now, for any texts that were just loaded, if they are owned by a section, we
			// have to load all the sections (as an ordered sequence) for the book.
			HvoVec vhvoSection; // vector of ScrSection objects we need to load data about.
			HVO hvoSection;
			for (ihvo = 0; ihvo < vhvoPara.Size(); ihvo++)
			{
				qcvd->get_ObjectProp(vhvoPara[ihvo], kflidCmObject_Owner, &hvoStText);
				Assert(hvoStText);
				int nFlid;
				qcvd->get_IntProp(hvoStText, kflidCmObject_OwnFlid, &nFlid);
				switch(nFlid)
				{
				case kflidScrSection_Content:
				case kflidScrSection_Heading:
					CheckHr(qcvd->get_ObjectProp(hvoStText, kflidCmObject_Owner, &hvoSection));
					vhvoSection.Push(hvoSection);
					break;
				case kflidScrBook_Title:
					break;
				default:
					Assert(false); // Unexpected owning field for StText
					break;
				}
			}
			// If any sections need loading...
			if (vhvoSection.Size())
			{
				stuQuery.Format(L"select bk.[Id], sec.[Id], sec.Owner$, sec.OwnFlid$ from "
					L"ScrBook bk (readuncommitted) join ScrSection_ sec (readuncommitted) on sec.Owner$ = bk.[Id] and sec.OwnFlid$"
					L" = %d where bk.[Id] in (select distinct Owner$ from ScrSection_ (readuncommitted) where [Id] "
					L"in (%d",	kflidScrBook_Sections, vhvoSection[0]);
				for (ihvo = 1; ihvo < vhvoSection.Size(); ihvo++)
				{
					stuQuery.FormatAppend(L",%d", vhvoSection[ihvo]);
				}
				stuQuery.Append(L")) order by bk.[Id], sec.OwnOrd$");

				// Set up column specs in qdcs
				qdcs->Clear();
				qdcs->Push(koctBaseId, 0, 0, 0);
				// ENHANCE JohnT(TomB): I think we should have another koct value for owned object
				// sequence/collection properties so that the owner can be set automatically in the
				// Load method without having to pass a duplicate column.
				qdcs->Push(koctObjVec, 1, kflidScrBook_Sections, 0);
				qdcs->Push(koctObj, 2, kflidCmObject_Owner, 0);
				qdcs->Push(koctInt, 2, kflidCmObject_OwnFlid, 0);

				// ENHANCE TomB: Add pointer to status bar.
				qcvd->Load(stuQuery.Bstr(), qdcs, 0, 0, NULL /*m_qstbr*/, FALSE);
			}

			// If we had to start a progress bar, return things to normal.
			if (fStartProgressBar)
			{
//				m_qstbr->EndProgressBar();
			}
		}
		break;
	default:
		break;
	}
	END_COM_METHOD(g_factConcVc, IID_IVwViewConstructor);
}

#ifdef NEED_DISPLAY_VEC
/*----------------------------------------------------------------------------------------------
	Display a fragment which is a vector. For kfrCount, just display the vector size. For
	kfrRefPara, summerize the list of references in a single string.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ConcVc::DisplayVec(IVwEnv * pvwenv, HVO hvo, int tag, int frag)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pvwenv);

	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	int chvo;
	CheckHr(qsda->get_VecSize(hvo, kflidTxtWordformInContext_Analysis, &chvo));

	switch(frag)
	{
	case kfrCount:
		{
			StrUni stuNum;
			stuNum.Format(L"%d", chvo);
			ITsStringPtr qtssNum;
			CheckHr(m_qtsf->MakeStringRgch(const_cast<OLECHAR *>(stuNum.Chars()),
				stuNum.Length(), m_wsVern, &qtssNum));
			CheckHr(pvwenv->put_IntProperty(ktptAlign, ktpvEnum, ktalRight));
			CheckHr(pvwenv->put_IntProperty(ktptPadTrailing, ktpvMilliPoint, 3000));
			CheckHr(pvwenv->AddString(qtssNum));
		}
		break;

	case kfrRefPara:
		{
			// We handle refs as a sequence so we can compact them and insert separators.
			StrUni stuDisplayRefs(L"");
			ITsStringPtr qtssDisplayRefs;

			if (chvo == 0)
			{
				stuDisplayRefs.Load(kstidNoScriptRef); 
			}
			else
			{
				int nCurrBook;
				int nPrevBook = -1, nPrevChap = -1;
				int nCurrChapStart, nCurrChapEnd;
				int nChapRgStart = -1, nChapRgEnd = -1;
				int nCurrVerseStart, nCurrVerseEnd;
				int nVerseRgStart = -1, nVerseRgEnd = -1;
				SmartBstr sbstrBook;
				bool fRange = false;

				for (int ihvo = 0; ihvo < chvo; ihvo++)
				{
					HVO hvoTwfic;
					CheckHr(qsda->get_VecItem(hvo, kflidTxtWordformInContext_Analysis,
						ihvo, &hvoTwfic));
					int nVerseRefStart, nVerseRefEnd;
					CheckHr(qsda->get_IntProp(hvoTwfic,
						kflidTxtWordformInContext_VerseRefStart, &nVerseRefStart));
					CheckHr(qsda->get_IntProp(hvoTwfic,
						kflidTxtWordformInContext_VerseRefEnd, &nVerseRefEnd));
					GetBCV(nVerseRefStart, nCurrBook, nCurrChapStart, nCurrVerseStart);
					GetBCV(nVerseRefEnd, nCurrBook, nCurrChapEnd, nCurrVerseEnd);

					//Determine what to output
					if (nCurrBook != nPrevBook)
					{
						// New book, print closing chapter & verse numbers, if necessary.
						if (fRange)
						{
							if (nChapRgStart != nChapRgEnd)
							{
								stuDisplayRefs.FormatAppend(L"%d%s", nChapRgEnd, 
									g_app.m_stuChapterVerseSepr.Chars());
							}
							stuDisplayRefs.FormatAppend(L"%d", nVerseRgEnd);
							fRange = false;
						}
						if (nPrevBook != -1)
							stuDisplayRefs.FormatAppend(L"%s ", g_app.m_stuBookSepr.Chars());

						// Now we're ready to start dealing with the new book. First, we
						// need to convert the book number into a string of some sort.
						GetBookAsString(qsda, hvoTwfic, sbstrBook);

						stuDisplayRefs.Append(sbstrBook.Chars());
						stuDisplayRefs.FormatAppend(L" %d%s%d", nCurrChapStart,
							g_app.m_stuChapterVerseSepr.Chars(), nCurrVerseStart);
						if (nCurrVerseStart != nCurrVerseEnd ||
							nCurrChapStart != nCurrChapEnd)
						{
							stuDisplayRefs.FormatAppend(L"%s", g_app.m_stuBridge.Chars());
							fRange = true;
						}
						nPrevBook = nCurrBook;
						nPrevChap = nCurrChapStart;
						nChapRgStart = nCurrChapStart;
						nChapRgEnd = nCurrChapEnd;
						nVerseRgStart = nCurrVerseStart;
						nVerseRgEnd = nCurrVerseEnd;
					}
					// if the current chapter/verse begins before the existing range or the
					// current starting chapter is after the existing range, then end the
					// existing range.
					else if (nCurrChapStart > nChapRgEnd ||	nCurrChapStart < nChapRgStart ||
						(nCurrChapStart == nChapRgStart && nCurrVerseStart < nVerseRgStart))
					{
						if (fRange)
						{
							if (nChapRgStart != nChapRgEnd)
							{
								stuDisplayRefs.FormatAppend(L"%d%s", nChapRgEnd,
									g_app.m_stuChapterVerseSepr.Chars());
							}
							stuDisplayRefs.FormatAppend(L"%d", nVerseRgEnd);
							fRange = false;
						}
						if (nCurrChapStart != nChapRgEnd)
						{
							stuDisplayRefs.FormatAppend(L"%s %d%s%d",
								g_app.m_stuChapterSepr.Chars(), nCurrChapStart,
								g_app.m_stuChapterVerseSepr.Chars(), nCurrVerseStart);
						}
						else
						{
							stuDisplayRefs.FormatAppend(L"%s %d", g_app.m_stuVerseSepr.Chars(),
								nCurrVerseStart);
						}

						if (nCurrVerseStart != nCurrVerseEnd ||
							nCurrChapStart != nCurrChapEnd)
						{
							stuDisplayRefs.FormatAppend(L"%s", g_app.m_stuBridge.Chars());
							fRange = true;
						}
						nChapRgStart = nCurrChapStart;
						nChapRgEnd = nCurrChapEnd;
						nVerseRgStart = nCurrVerseStart;
						nVerseRgEnd = nCurrVerseEnd;
					}
					// If the current verse/bridge starts inside the existing range
					// or with the verse immediately following the existing range,
					// then extend the range if necessary.
					else if (nCurrChapStart < nChapRgEnd ||
						(nCurrChapStart == nChapRgEnd && nCurrVerseStart <= nVerseRgEnd + 1))
					{
						if (fRange)
						{
							if (nChapRgEnd < nCurrChapEnd)
							{
								nChapRgEnd = nCurrChapEnd;
								nVerseRgEnd = nCurrVerseEnd;
							}
							else if (nVerseRgEnd < nCurrVerseEnd)
								nVerseRgEnd = nCurrVerseEnd;
							// else current ref is entirely contained in existing range
						}
						else if (nChapRgEnd < nCurrChapEnd ||
							(nChapRgEnd == nCurrChapEnd && nCurrVerseEnd > nVerseRgEnd))
						{
							stuDisplayRefs.FormatAppend(L"%s", g_app.m_stuBridge.Chars());
							nChapRgEnd = nCurrChapEnd;
							nVerseRgEnd = nCurrVerseEnd;
							fRange = true;
						}
					}
					else
					{
						if (fRange)
						{
							if (nChapRgStart != nChapRgEnd)
							{
								stuDisplayRefs.FormatAppend(L"%d%s", nChapRgEnd,
									g_app.m_stuChapterVerseSepr.Chars());
							}
							stuDisplayRefs.FormatAppend(L"%d", nVerseRgEnd);
							fRange = false;
						}
						if (nCurrChapStart != nChapRgEnd)
						{
							stuDisplayRefs.FormatAppend(L"%s %d%s%d", 
								g_app.m_stuChapterSepr.Chars(), nCurrChapStart,
								g_app.m_stuChapterVerseSepr.Chars(), nCurrVerseStart);
						}
						else
						{
							stuDisplayRefs.FormatAppend(L"%s %d", g_app.m_stuVerseSepr.Chars(), 
								nCurrVerseStart);
						}
						nChapRgStart = nCurrChapStart;
						nChapRgEnd = nCurrChapEnd;
						nVerseRgStart = nCurrVerseStart;
						nVerseRgEnd = nCurrVerseEnd;
						if (nCurrVerseStart != nCurrVerseEnd ||
							nCurrChapStart != nCurrChapEnd)
						{
							stuDisplayRefs.FormatAppend(L"%s", g_app.m_stuBridge.Chars());
							fRange = true;
						}
					}
				}
				if (fRange)
				{
					if (nChapRgStart != nChapRgEnd)
					{
						stuDisplayRefs.FormatAppend(L"%d%s", nChapRgEnd,
							g_app.m_stuChapterVerseSepr.Chars());
					}
					stuDisplayRefs.FormatAppend(L"%d", nVerseRgEnd);
				}
			}
			CheckHr(m_qtsf->MakeString(stuDisplayRefs.Bstr(), NULL, &qtssDisplayRefs));
			CheckHr(pvwenv->AddString(qtssDisplayRefs));
		}
		break;

	default:
		Assert(false);
		break;
	}

	END_COM_METHOD(g_factConcVc, IID_IVwViewConstructor);
}
#endif

/***********************************************************************************************
	ConcClientWnd stuff.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Release all COM pointers, to break cycles.
----------------------------------------------------------------------------------------------*/
void ConcClientWnd::OnReleasePtr(void)
{
	m_qcvd.Clear();
	m_qchw.Clear();
	m_qcthw.Clear();
	SuperClass::OnReleasePtr();
}

/*----------------------------------------------------------------------------------------------
	Refresh the main Concordance window.
----------------------------------------------------------------------------------------------*/
void ConcClientWnd::RefreshDisplay()
{
	m_qchw->RefreshConc();
	m_qcthw->Refresh();
}
/*----------------------------------------------------------------------------------------------
	Create the child windows for the Concordance window.
----------------------------------------------------------------------------------------------*/
void ConcClientWnd::PostAttach(void)
{
	SuperClass::PostAttach();
	
	m_rccthwCoords.Clear();
	
	// Create and attach Concordance window.
	m_qchw.Attach(NewObj ConcHeaderWnd(this));
	WndCreateStruct wcs;
	wcs.InitChild(_T("AfClientWnd"), m_hwnd, 1000);

	// Get the name of the view to be used for the caption bar text.
	StrApp str(kstidConcordanceCaption);
	SetViewName(str);

	SeMainWnd * ptmwMainWnd = dynamic_cast<SeMainWnd *>(MainWindow());
	Assert(ptmwMainWnd);
	m_qcvd = ptmwMainWnd->GetCustViewDa();
	m_hvoScripture = ptmwMainWnd->GetSeLpInfo()->GetHvoScripture();
	m_qsty = ptmwMainWnd->GetStyleSheet();
	
	// Create the window with a column heading bar and no caption. The caption above this
	// window is part of the mdi client window. Creating this window with a width of 0
	// doesn't matter since the window's parent (i.e. this) will adjust it's width
	// appropriately in the OnSize method.
	m_qchw->Create(NULL, 0, kfhwcColHeadings | kfhwcEtchedColHeadingTop, 0);
	m_qchw->CreateHwnd(wcs);
	::ShowWindow(m_qchw->Hwnd(), SW_SHOW);

	// Since we're just building the concordance view, setup things so the concordance
	// window gets the focus first. m_hChildWithFocus will be used later when this client
	// window gets WM_SETFOCUS messages.
	ConcWnd * pconw = dynamic_cast<ConcWnd *>(m_qchw->GetSplitterWindow()->GetPane(0));
	m_hChildWithFocus = (pconw) ? pconw->Hwnd() : 0;

	// Create and attach Draft window.
	m_qcthw.Attach(NewObj ConcTextHeaderWnd(this));
	WndCreateStruct wcs2;
	wcs2.InitChild(_T("AfClientWnd"), m_hwnd, 0);

	// Create the window with a caption bar that contains the scripture draft. Creating
	// this window with a width of 0 doesn't matter since the window's parent (i.e. this)
	// will adjust it's width appropriately in the OnSize method.
	str.Load(kstidDraftViewCaption);
	m_qcthw->Create(str.Chars(), 0, 0, 0,
		kdypcthwCaptionBarHeight, kfcbcAllowCaptionToSizeParent |
		kfcbcEnhance3DTopCaptionBrdr);

	m_qcthw->CreateHwnd(wcs2);

	// Send a kill focus message to the draft window to fool it into setting its
	// caption color to the unfocused color.
	::SendMessage(m_qcthw->Hwnd(), WM_KILLFOCUS, (WPARAM)0, (LPARAM)0);

	::ShowWindow(m_qcthw->Hwnd(), SW_SHOW);
}

/*----------------------------------------------------------------------------------------------
	Save settings specific to this window to the registry. Save the concordance column widths.

	@param pszRoot The string that is used for this app as the root for all registry entries. 
	@param fRecursive If true, then every child window will be asked to save their settings.
----------------------------------------------------------------------------------------------*/
void ConcClientWnd::SaveSettings(const achar * pszRoot, bool fRecursive)
{
	AssertPszN(pszRoot);
	SuperClass::SaveSettings(pszRoot, fRecursive);
	SaveConcWindowPosition(pszRoot);
}

/*----------------------------------------------------------------------------------------------
	Load the size and position of the window.

	@param pszRoot Registry subkey name for the application.
	@param pszValue Registry key value name.
----------------------------------------------------------------------------------------------*/
void ConcClientWnd::LoadConcWindowPosition(const achar * pszRoot)
{
	Assert(::IsWindow(m_hwnd)); // Make sure the window handle is valid.

	Rect rc;
	::GetClientRect(m_hwnd, &rc);

	// Make the default height of the draft window 1/4 of the height of it's parent and
	// its default position is at the bottom of it's parent.
	m_rccthwCoords = rc;
	m_rccthwCoords.top = rc.bottom * 3/4;

	// If this is true it means m_hwnd hasn't been sized properly yet.
	if (m_rccthwCoords.top >= m_rccthwCoords.bottom)
		return;

	FwSettings * pfws = AfApp::GetSettings();

	if (pfws->GetBinary(pszRoot, kpszDraftWndPositionValue, (BYTE *)&rc, isizeof(RECT)))
		m_rccthwCoords = rc;
}


/*----------------------------------------------------------------------------------------------
	Save the size and position of the window.

	@param pszRoot Registry subkey name for the application.
	@param pszValue Registry key value name.
----------------------------------------------------------------------------------------------*/
void ConcClientWnd::SaveConcWindowPosition(const achar * pszRoot)
{
	FwSettings * pfws = AfApp::GetSettings();
	pfws->SetBinary(pszRoot, kpszDraftWndPositionValue, (BYTE *)&m_rccthwCoords,
		isizeof(RECT));
}

/*----------------------------------------------------------------------------------------------
	Resizing both child windows (Concordance and Draft).
----------------------------------------------------------------------------------------------*/
bool ConcClientWnd::OnSize(int wst, int dxp, int dyp)
{
	// If the coordinates of the draft window haven't been determined, then read them
	// from the registry.
	if (m_rccthwCoords.top >= m_rccthwCoords.bottom)
		LoadConcWindowPosition(NULL);

	m_rccthwCoords.right = dxp;
	m_rccthwCoords.bottom = dyp;
	
	// Size Concordance window
	::MoveWindow(m_qchw->Hwnd(), 0, 0, dxp, m_rccthwCoords.top, true);
		
	// Size Draft Window
	::MoveWindow(m_qcthw->Hwnd(), 0, m_rccthwCoords.top, dxp,
		m_rccthwCoords.Height(), true);

	return SuperClass::OnSize(wst, dxp, dyp);
}

/*----------------------------------------------------------------------------------------------
	This handles events sent from any ConcClientWnd's children. At this point, the only event
	being handled is the user dragging the top border of the ConcTextHeaderWnd's caption bar.

	@param ceid The child's event ID.
	@param pChildWnd A pointer to the child window object.
	@param lpInfo Pointer to any extra information that might be necessary. In this case it
			is an int pointer to a value that is the net change (in pixels) of the draft
			window's height.
----------------------------------------------------------------------------------------------*/
bool ConcClientWnd::OnChildEvent(int ceid, AfWnd *pChildWnd, void *lpInfo)
{
	SuperClass::OnChildEvent(ceid, pChildWnd, lpInfo);

	// If the child that sent us this event is not the draft window, then do nothing
	// since that's the only child event we care about, at this point.
	if (dynamic_cast<ConcTextHeaderWnd *>(pChildWnd) != m_qcthw)
		return true;

	// If the event id isn't a dragging border event, then ignore it.
	if (ceid != kceidDraggingBorder)
		return true;

	// lpInfo points to the vertical net change (in pixels) of the draft window's height.
	int *pdyp = (int *)lpInfo;

	// Copy the rectangle that bounds the draft window and change it's top to reflect how
	// many pixels the mouse has been dragged.
	Rect rc(m_rccthwCoords);
	rc.top += *pdyp;

	// Don't allow the top of the draft window to get less than the caption bar's
	// from the top of its parent window. Also don't let it to be sized shorter than
	// the height of its caption bar.
	if (rc.top <= m_qcthw->GetCaptionBarHeight() ||
		rc.Height() <= m_qcthw->GetCaptionBarHeight())
		return true;

	// Size Concordance window
	::MoveWindow(m_qchw->Hwnd(), 0, 0, rc.right, rc.top, true);

	// Size Draft Window
	::MoveWindow(m_qcthw->Hwnd(), 0, rc.top, rc.right, rc.Height(), true);

	m_rccthwCoords = rc;
	
	return true;
}

/*----------------------------------------------------------------------------------------------
	Handle window messages. Return true if handled.
	See ${AfWnd#FWndProc} for parameter and return descriptions.
----------------------------------------------------------------------------------------------*/
bool ConcClientWnd::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
	bool fRet = SuperClass::FWndProc(wm, wp, lp, lnRet);

	// This window should never really get the focus (at least as far as the user is
	// concerned) therefore, pass it on to the appropriate child of this window.
	if (wm == WM_SETFOCUS)
		::SetFocus(m_hChildWithFocus);

	return fRet;
}

/***********************************************************************************************
	ConcHeaderWnd stuff.
***********************************************************************************************/
// Registry keys for retaining column widths
const achar * kpszColCount = _T("ColCount");
const achar * kpszColInfo = _T("ColInfo");

// Registry key for how references are displayed
const achar * kpszBookRefFmt = _T("BookRefFmt");

/*----------------------------------------------------------------------------------------------
	Release all COM pointers, to break cycles.
----------------------------------------------------------------------------------------------*/
void ConcHeaderWnd::OnReleasePtr(void)
{
	m_qcsw.Clear();
	SuperClass::OnReleasePtr();
}

/*----------------------------------------------------------------------------------------------
	Create the child window for the Concordance window and initialize the column headers.
----------------------------------------------------------------------------------------------*/
void ConcHeaderWnd::PostAttach(void)
{
	m_hwndCurrentPane = 0;

	SuperClass::PostAttach();

	// Create and initialize the main concordance splitter window
	m_qcsw.Attach(NewObj ConcSplitterWnd(m_pccw));
	WndCreateStruct wcs;
	wcs.InitChild(_T("AfClientWnd"), m_hwnd, 1000);
	m_qcsw->CreateHwnd(wcs);

	// Load window settings (column order, widths, etc.)
	LoadSettings(NULL, false);

	if (m_vcci.Size() == 0)
	{
		ConcColInfo cci;
		cci.tag = ktagHeadword;
		cci.dxpCurrentWidth = 100;
		m_vcci.Push(cci);
		cci.tag = ktagStatus;
		cci.dxpCurrentWidth = 25;
		m_vcci.Push(cci);
		cci.tag = ktagCount;
		cci.dxpCurrentWidth = 50;
		m_vcci.Push(cci);
		cci.tag = ktagReference;
		cci.dxpCurrentWidth = 100;
		m_vcci.Push(cci);
	}

	StrAppBuf strbT; // Holds temp string

	// Set the column headings.
	for (int icci = 0; icci < m_vcci.Size(); icci++)
	{
		switch(m_vcci[icci].tag)
		{
		case ktagHeadword:
			{
				strbT.Load(kstidColWord);
				AddColumn(icci, strbT.Chars(), m_vcci[icci].dxpCurrentWidth, 35, true, false);
			}
			break;
		case ktagStatus:
			{
				strbT.Load(kstidColStatus);
				AddColumn(icci, strbT.Chars(), m_vcci[icci].dxpCurrentWidth, 25, false, false);
			}
			break;
		case ktagCount:
			{
				strbT.Load(kstidColCount);
				AddColumn(icci, strbT.Chars(), m_vcci[icci].dxpCurrentWidth, 25, true, false);

				// Now that the column is added, make sure this column's text heading
				// is right alignmened. Do that by making sure left and center alignment
				// are turned off before turning right alignment on.
				HDITEM hdi = {HDI_FORMAT};
				Header_GetItem(m_hwndColHeading, 2, &hdi);
				hdi.fmt = hdi.fmt & ~(HDF_LEFT | HDF_CENTER) | HDF_RIGHT;
				Header_SetItem(m_hwndColHeading, 2, &hdi);
			}
			break;
		case ktagReference:
			{
				strbT.Load(kstidColRef);
				AddColumn(icci, strbT.Chars(), m_vcci[icci].dxpCurrentWidth, 25, true, true);
			}
			break;
		default:
			Assert(false);
			break;
		}
	}

	// Determine the concordance line height based on the normal Scripture paragraph font size.
	SeLpInfoPtr qtlpi = dynamic_cast<SeLpInfo *>(m_pccw->GetCustViewDa()->GetLpInfo());
	StrUni stuStyleName(qtlpi->GetParagraphStyleName());
	TeStylesheet * ptsts = qtlpi->GetScriptureStylesheet();
	Assert(ptsts);
	HDC hdc = ::GetDC(NULL);
	m_dypConcDetailLineHeight = ptsts->GetLineHeight(stuStyleName.Bstr(), qtlpi->VernWs(),
		hdc);
	m_dypConcDetailLineHeight += 4; // Add extra heigth to account for superscript verse numbers.
	::ReleaseDC(NULL, hdc);

	::ShowWindow(m_qcsw->Hwnd(), SW_SHOW);
}

/*----------------------------------------------------------------------------------------------
	Resizing concordance splitter window.
----------------------------------------------------------------------------------------------*/
bool ConcHeaderWnd::OnSize(int wst, int dxp, int dyp)
{
	bool fRet = SuperClass::OnSize(wst, dxp, dyp);
	
	// Size the concordance splitter window.
	::MoveWindow(m_qcsw->Hwnd(), 0, m_ypTopOfClient, dxp, dyp - m_ypTopOfClient, true);
	return fRet;
}

/*----------------------------------------------------------------------------------------------
	Change the column width.
----------------------------------------------------------------------------------------------*/
void ConcHeaderWnd::ChangeColWidth(int icci, int dxpNew)
{
	SuperClass::ChangeColWidth(icci, dxpNew);

	Assert(icci < m_vcci.Size()); // Assert if index is greater than number of columns

	// Store dxpNew in the member vector of column widths
	m_vcci[icci].dxpCurrentWidth = dxpNew;
}

/*----------------------------------------------------------------------------------------------
	Refresh the main Concordance window.
----------------------------------------------------------------------------------------------*/
void ConcHeaderWnd::RefreshConc(void)
{
	m_qcsw->RefreshConc();
}
/*----------------------------------------------------------------------------------------------
	ReDraw the main Concordance window.
----------------------------------------------------------------------------------------------*/
void ConcHeaderWnd::ReDrawColumns(void)
{
	// SuperClass::ReDrawColumns(); 
	m_qcsw->ReDrawColumns();
}

/*----------------------------------------------------------------------------------------------
 	Read column vector to get widths.
----------------------------------------------------------------------------------------------*/
void ConcHeaderWnd::LoadSettings(const achar * pszRoot, bool fRecursive)
{
	Assert(m_hwnd); // The window must have already been created before this can be called.
   
	SuperClass::LoadSettings(pszRoot, fRecursive);

	StrApp strSubKey(pszRoot);
	strSubKey += m_pccw->GetViewName();

	FwSettings * pfws = AfApp::GetSettings();

	unsigned long cCol;
	if (!pfws->GetDword(strSubKey, kpszColCount, &cCol))
		return;

	ConcColInfo * pcciBuffer = (ConcColInfo *)malloc(cCol * isizeof(ConcColInfo));
	if (!pfws->GetBinary(strSubKey, kpszColInfo, (BYTE *)pcciBuffer,
		cCol * isizeof(ConcColInfo)))
	{
		free(pcciBuffer);
		return;
	}

	for (unsigned long iCol = 0; iCol < cCol; iCol++)
	{
		m_vcci.Push(pcciBuffer[iCol]);
	}
	free(pcciBuffer);

	if (!pfws->GetBinary(strSubKey, kpszBookRefFmt, (BYTE *)&m_cri, 
		isizeof(ConcReferenceInfo)))
	{
		m_cri.tag = ktagSIL;
		m_cri.ws = 0;
	}
}

/*----------------------------------------------------------------------------------------------
	Save settings specific to this window to the registry. Save the concordance column widths.

	@param pszRoot The string that is used for this app as the root for all registry entries. 
	@param fRecursive If true, then every child window will be asked to save their settings.
----------------------------------------------------------------------------------------------*/
void ConcHeaderWnd::SaveSettings(const achar * pszRoot, bool fRecursive)
{
	AssertPszN(pszRoot);
	SuperClass::SaveSettings(pszRoot, fRecursive);
	StrApp strSubKey(pszRoot);
	strSubKey += m_pccw->GetViewName();
	FwSettings * pfws = AfApp::GetSettings();

	if (!pfws->SetDword(strSubKey, kpszColCount, m_vcci.Size()))
	{
		Assert(false);
		return;
	}

	ConcColInfo * pcciBuffer = (ConcColInfo *)malloc(m_vcci.Size() * isizeof(ConcColInfo));
	for (int iCol = 0; iCol < m_vcci.Size(); iCol++)
	{
		pcciBuffer[iCol].tag = m_vcci[iCol].tag;
		pcciBuffer[iCol].dxpCurrentWidth = m_vcwiColInfo[iCol].dxpPrefer;
	}
	Assert(pfws->SetBinary(strSubKey, kpszColInfo, (BYTE *)pcciBuffer,
		m_vcci.Size() * isizeof(ConcColInfo)));
	free(pcciBuffer);

	Assert(pfws->SetBinary(strSubKey, kpszBookRefFmt, (BYTE *)&m_cri, 
		isizeof(ConcReferenceInfo)));
}


/***********************************************************************************************
	ConcSplitterWnd stuff.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Create the child window.
----------------------------------------------------------------------------------------------*/
void ConcSplitterWnd::CreateChild(AfSplitChild * psplcCopy, AfSplitChild ** psplcNew)
{
	WndCreateStruct wcs;
	wcs.InitChild(_T("AfVwWnd"), m_hwnd, 0);
	wcs.style |=  WS_VISIBLE;
	ConcWndPtr qconw;
	qconw.Attach(NewObj ConcWnd(m_pccw->m_qchw));
	qconw->Init(m_pccw->m_qcvd);
	*psplcNew = qconw;
	qconw->CreateHwnd(wcs);
	qconw->ResetVdfeSize(false);
	AddRefObj(*psplcNew);
}

/*----------------------------------------------------------------------------------------------
	Refresh the main Concordance window, check for 2 panes.
----------------------------------------------------------------------------------------------*/
void ConcSplitterWnd::RefreshConc(void)
{
	ConcWnd * pconw = dynamic_cast<ConcWnd *>(GetPane(0));
	pconw->ResetVdfeSize();
	pconw->SetHeight(); // Calculate the new height of fields.
	::InvalidateRect(pconw->Hwnd(), NULL, true);

	pconw = dynamic_cast<ConcWnd *>(GetPane(1));
	if (pconw)
	{
		pconw->ResetVdfeSize();
		pconw->SetHeight(); // Calculate the new height of fields.
		::InvalidateRect(pconw->Hwnd(), NULL, true);
	}
}

/*----------------------------------------------------------------------------------------------
	ReDraw the main Concordance window, check for 2 panes.
----------------------------------------------------------------------------------------------*/
void ConcSplitterWnd::ReDrawColumns(void)
{
	ConcWnd * pconw = dynamic_cast<ConcWnd *>(GetPane(0));
	pconw->ReDrawColumns();

	pconw = dynamic_cast<ConcWnd *>(GetPane(1));
	if (pconw)
		pconw->ReDrawColumns();
}

/***********************************************************************************************
	ConcTextHeaderWnd stuff.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Release all COM pointers, to break cycles.
----------------------------------------------------------------------------------------------*/
void ConcTextHeaderWnd::OnReleasePtr(void)
{
	m_qctw.Clear();
	SuperClass::OnReleasePtr();
}

/*----------------------------------------------------------------------------------------------
	Create the child window for the Concordance window.
----------------------------------------------------------------------------------------------*/
void ConcTextHeaderWnd::PostAttach(void)
{
	SuperClass::PostAttach();

	// Create and initialize the draft pane.
	m_qctw.Attach(NewObj ConcTextWnd);
	m_qctw->m_pcthwParent = this;
	WndCreateStruct wcs;
	wcs.InitChild(_T("AfClientWnd"), m_hwnd, 0);
	m_qctw->Init(m_pccw->m_qcvd, m_pccw->m_hvoScripture);
	m_qctw->CreateHwnd(wcs);

	// Get the system's caption font and set the header Window's
	// caption font to the same thing.
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, 0);
	GetCaptionBar()->SetCaptionFont(&ncm.lfCaptionFont);

	// Change the caption border thickness so it's a bit smaller than the default.
	GetCaptionBar()->SetCaptionBorderWidth(kdzscthwCaptionBorderWidth, true);

	::ShowWindow(m_qctw->Hwnd(), SW_SHOW);
}

/*----------------------------------------------------------------------------------------------
	Resizing draft window pane.
----------------------------------------------------------------------------------------------*/
bool ConcTextHeaderWnd::OnSize(int wst, int dxp, int dyp)
{
	// We must call the superclass method first so m_ypTopOfClient
	// gets set appropriately.
	bool fRet = SuperClass::OnSize(wst, dxp, dyp);
	
	// Size the concordance draft window so its top accounts for the caption.
	::MoveWindow(m_qctw->Hwnd(), 0, m_ypTopOfClient, dxp, dyp - m_ypTopOfClient, true);
	return fRet;
}

/*----------------------------------------------------------------------------------------------
	Handle window messages. Return true if handled.
	See ${AfWnd#FWndProc} for parameter and return descriptions.
----------------------------------------------------------------------------------------------*/
bool ConcTextHeaderWnd::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
	bool fRet = SuperClass::FWndProc(wm, wp, lp, lnRet);
	
	if (m_fDraggingTopCaptionBorder)
	{
		Point pt = MakePoint(lp);
						
		if (wm == WM_MOUSEMOVE)
		{
			(AfWnd *)Parent()->OnChildEvent(kceidDraggingBorder, (AfWnd *)this, &(pt.y));
			return true;
		}
	}
	else
	{
		switch(wm)
		{
		case WM_SETFOCUS:
			// Give the caption a color as a visual clue that the draft window has focus.
			m_qcpbr->SetCaptionBackColor(::GetSysColor(COLOR_3DSHADOW), true);

			// Tell the client window who has focus now.
			m_pccw->SetChildWithFocus(Hwnd());

			// Send focus to the draft window (i.e. ConcTextWnd - the window that
			// actually contains the IP and data).
			::SetFocus(m_qctw->Hwnd());
			break;

		case WM_KILLFOCUS:
			// Change the draft window's caption color so it looks like it doesn't have
			// focus. Do that by making the focused color's RGB values a little lighter.
			m_qcpbr->SetCaptionBackColor(RGB(
				GetRValue(::GetSysColor(COLOR_3DSHADOW)) + 30,
				GetGValue(::GetSysColor(COLOR_3DSHADOW)) + 30,
				GetBValue(::GetSysColor(COLOR_3DSHADOW)) + 30), true);
			break;
		}
	}

	return fRet;
}

/*----------------------------------------------------------------------------------------------
	Refresh the Concordance draft pane.
----------------------------------------------------------------------------------------------*/
void ConcTextHeaderWnd::Refresh(void)
{
	m_qctw->Refresh();
}

/*----------------------------------------------------------------------------------------------
	Initialize the concordance window by loading the strings of interest into m_vcsi and
	calling RetrieveWordforms. This method needs to be implemented in all subclasses if we break
	this up into a base class and derived classes.
----------------------------------------------------------------------------------------------*/
void ConcTextWnd::Init(CustViewDa * pcvd, HVO hvoScripture)
{
	m_qcvd = pcvd;
	m_hvoScripture = hvoScripture;
}

/*----------------------------------------------------------------------------------------------
	Make the root box.
----------------------------------------------------------------------------------------------*/
void ConcTextWnd::MakeRoot(IVwGraphics * pvg, ILgWritingSystemFactory * pwsf, IVwRootBox ** pprootb)
{
	AssertPtrN(pwsf);
	*pprootb = NULL;

	// Make sure we are attached. If not, don't make the root box. PostAttach tries again.
	SeMainWnd * ptmw = dynamic_cast<SeMainWnd *>(m_pcthwParent->MainWindow());
	if (!ptmw)
		return;

	AfLpInfo * plpi = dynamic_cast<AfLpInfo *>(ptmw->GetLpInfo());
	AssertPtr(plpi);

	// Check the database connection.
	IOleDbEncapPtr qode;
	plpi->GetDbInfo()->GetDbAccess(&qode);
	if (!qode)
		// Review JohnT: should we return E_FAIL or S_FALSE?
		return;	 // No current session, can't make root box.

	IVwRootBoxPtr qrootb;
	qrootb.CreateInstance(CLSID_VwRootBox);
	CheckHr(qrootb->SetSite(this));
	qrootb->put_DefaultTextType(kttpPublishedText);

	// Set hvo to the ID of the dummy vector that stores the root objects that have been
	// filtered and sorted.
	ConcClientWnd * pccw = dynamic_cast<ConcClientWnd *>(m_pcthwParent->Parent());
	int wid = pccw->GetWindowId();
	AfMdiClientWnd * pmdic = dynamic_cast<AfMdiClientWnd *>(m_pcthwParent->Parent()->Parent());
	AssertPtr(pmdic);
	int iview;
	iview = pmdic->GetChildIndexFromWid(wid);
	UserViewSpecVec & vuvs = plpi->GetDbInfo()->GetUserViewSpecs();
	ClsLevel clevKey(kclidScripture, 0);
	vuvs[iview]->m_hmclevrsp.Retrieve(clevKey, m_qrsp);

	// Set up a new view constructor.
	m_qdvc.Attach(NewObj DraftTextVc());

	AfStatusBarPtr qstbr = ptmw->GetStatusBarWnd();
	Assert(qstbr);
	qstbr->StepProgressBar();

	m_qdvc->SetDa(m_qcvd, qstbr, vuvs[iview]);

	if (pwsf)
		CheckHr(m_qcvd->putref_WritingSystemFactory(pwsf));
	CheckHr(qrootb->putref_DataAccess(m_qcvd));
	IVwStylesheet * psty = m_pcthwParent->m_pccw->GetStyleSheet();
	CheckHr(qrootb->SetRootObject(m_hvoScripture, m_qdvc, kfrScripture, psty));

	// Added this to keep from Asserting if the user tries to scroll the ConcTextWnd before
	// clicking into it to place the insertion point.
	// REVIEW DavidO: This doesn't cause the IP to become visible. Is that desired?
	HRESULT hr = qrootb->MakeSimpleSel(true, true, false, true, NULL);

	// We ignore E_FAIL since the text window may be empty, in which case making a
	// selection is impossible.
	if (hr != E_FAIL)
		CheckHr(hr);

	ptmw->RegisterRootBox(qrootb);
	*pprootb = qrootb.Detach();
}

/*----------------------------------------------------------------------------------------------
	Take the chance to respond to gaining focus.
----------------------------------------------------------------------------------------------*/
bool ConcTextWnd::OnSetFocus(HWND hwndOld, bool fTbControl)
{
	// Let this window's owner process focus setting, so pass it on.
	::SendMessage(::GetParent(m_hwnd), WM_SETFOCUS, (WPARAM)hwndOld, (LPARAM)0);
	return ScrollSuperClass::OnSetFocus(hwndOld, fTbControl);
}

/*----------------------------------------------------------------------------------------------
	Take the chance to respond to a focus loss.
----------------------------------------------------------------------------------------------*/
bool ConcTextWnd::OnKillFocus(HWND hwndNew)
{
	// Let this window's owner process focus loss, so pass it on.
	::SendMessage(::GetParent(m_hwnd), WM_KILLFOCUS, (WPARAM)hwndNew, (LPARAM)0);
	return SuperClass::OnKillFocus(hwndNew);
}

/*----------------------------------------------------------------------------------------------
	Refresh the Concordance draft pane.
----------------------------------------------------------------------------------------------*/
void ConcTextWnd::Refresh(void)
{
	m_qrootb->Reconstruct();
	// Added this to keep from Asserting if the user tries to scroll the ConcTextWnd before
	// clicking into it to place the insertion point.
	// REVIEW DavidO: This doesn't cause the IP to become visible. Is that desired?
	HRESULT hr = m_qrootb->MakeSimpleSel(true, true, false, true, NULL);

	// We ignore E_FAIL since the text window may be empty, in which case making a
	// selection is impossible.
	if (hr != E_FAIL)
		CheckHr(hr);
}

/*----------------------------------------------------------------------------------------------
	Clean up smart pointers.
----------------------------------------------------------------------------------------------*/
void ConcTextWnd::OnReleasePtr()
{
	m_qcvd.Clear();
	m_qdvc.Clear();
	m_qrsp.Clear();
	SuperClass::OnReleasePtr();
}

/*----------------------------------------------------------------------------------------------
	Change the reference in the title bar when the selection changes in the draft pane. 
----------------------------------------------------------------------------------------------*/
void ConcTextWnd::HandleSelectionChange(IVwSelection * pvwselNew)
{
	SuperClass::HandleSelectionChange(pvwselNew);
	SetDraftCaptionBarForSelection(pvwselNew, m_qcvd, m_pcthwParent->GetCaptionBar());
}

/*----------------------------------------------------------------------------------------------
	Make a text selection corresponding to the specified text wordform in context.
	Assume the first occurrence of the property.
----------------------------------------------------------------------------------------------*/
bool FillInVsli(VwSelLevInfo * pvsli, HVO hvoSrc, PropTag tag, HVO hvoDst,
	ISilDataAccess * psda)
{
	pvsli->cpropPrevious = 0;
	pvsli->tag = tag;
	int chvo;
	CheckHr(psda->get_VecSize(hvoSrc, tag, &chvo));
	for (int ihvo = 0; ihvo < chvo; ihvo++)
	{
		HVO hvoItem;
		CheckHr(psda->get_VecItem(hvoSrc, tag, ihvo, &hvoItem));
		if (hvoItem == hvoDst)
		{
			pvsli->ihvo = ihvo;
			return true;
		}
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Make a text selection corresponding to the specified text wordform in context.
	It is helpful to pass the vernacular writing system.
----------------------------------------------------------------------------------------------*/
void ConcTextWnd::SelectTwfic(HVO hvoTwfic)
{
	VwSelLevInfo rgvsli[4]; // indicate the para, text, (optional) section, book, in that order.
	int ivsli = 0;
	HVO hvoPara, hvoText, hvoBook;
	CheckHr(m_qcvd->get_ObjectProp(hvoTwfic, kflidCmObject_Owner, &hvoPara));
	CheckHr(m_qcvd->get_ObjectProp(hvoPara, kflidCmObject_Owner, &hvoText));
	if (!FillInVsli(&rgvsli[ivsli++], hvoText, kflidStText_Paragraphs, hvoPara, m_qcvd))
	{
		Warn("Could not make selection in draft pane");
		return;
	}

	// The next one is special. If the TWFIC is in a section, the next prop is not a vector
	// prop at all. It could be either in the heading or the contents.
	int nFlid;
	CheckHr(m_qcvd->get_IntProp(hvoText, kflidCmObject_OwnFlid, &nFlid));
	switch(nFlid)
	{
	case kflidScrSection_Content:
	case kflidScrSection_Heading:
		{
			rgvsli[ivsli].cpropPrevious = 0;
			rgvsli[ivsli].tag = nFlid;
			rgvsli[ivsli++].ihvo = 0; // has to be, for atomic prop.
			HVO hvoSection;
			CheckHr(m_qcvd->get_ObjectProp(hvoText, kflidCmObject_Owner, &hvoSection));
			CheckHr(m_qcvd->get_ObjectProp(hvoSection, kflidCmObject_Owner, &hvoBook));
			if (!FillInVsli(&rgvsli[ivsli++], hvoBook, kflidScrBook_Sections, hvoSection,
				m_qcvd))
			{
				Warn("Could not make selection in draft pane");
				return;
			}
			break;
		}
	case kflidScrBook_Title:
		// This TWFIC will have a vector of only 3 levels because it is not in a section.
		// If the TWFIC is in a book title, the next prop is not a vector prop at all.
		rgvsli[ivsli].cpropPrevious = 0;
		rgvsli[ivsli].tag = nFlid;
		rgvsli[ivsli++].ihvo = 0; // has to be, for atomic prop.
		CheckHr(m_qcvd->get_ObjectProp(hvoText, kflidCmObject_Owner, &hvoBook));
		break;
	default:
		Assert(false); // Unexpected owning field for StText
		Warn("Could not make selection in draft pane");
		return;
	}

	if (!FillInVsli(&rgvsli[ivsli++], m_hvoScripture, kflidScripture_ScriptureBooks, hvoBook,
		m_qcvd))
	{
		Warn("Could not make selection in draft");
		return;
	}

	ITsStringPtr qtssWordform;
	int cch;
	int ichAnchor;
	CheckHr(m_qcvd->get_IntProp(hvoTwfic, kflidTxtWordformInContext_ParaCharOffset,
		&ichAnchor));
	CheckHr(m_qcvd->get_StringProp(hvoTwfic, kflidTxtWordformInContext_Form, &qtssWordform));
	CheckHr(qtssWordform->get_Length(&cch));
	int ichEnd = ichAnchor + cch;

	// Tell the root box to highlight the selection, even though it
	// doesn't have the focus (IP would not flash or show).
	CheckHr(m_qrootb->Activate(vssOutOfFocus));
	// Now we have all the info to make the selection.
	IVwSelectionPtr qvwsel;
	if (FAILED(m_qrootb->MakeTextSelection(
			0, // In the first (and only) root object, the whole Scripture
			ivsli, // takes 3 or 4 vslis to indicate the book, (optional) section, text, & para
			rgvsli, // and here they are
			kflidStTxtPara_Contents, // final text sel is in this property.
			0, // the first (and only) occurrence of that property
			ichAnchor, // from here
			ichEnd, // to here
			0, // not multilingual, so don't care about writing system
			false, // not an IP, so assocPrev doesn't matter
			-1, // not a multi-paragraph selection
			NULL, // We don't want to override the props to be applied if the user types
			true, // We do want this selection installed in the view.
			&qvwsel))) // And this is it, though we don't really want it.
	{
		Warn("Could not make selection in draft pane");
		return;
	}
	MakeSelectionVisible();
}

/*----------------------------------------------------------------------------------------------
	Enable/Disable formatting toolbar buttons and comboboxes (and the format font command)
----------------------------------------------------------------------------------------------*/
bool ConcTextWnd::CmsCharFmt(CmdState & cms)
{
	// Disable all direct formatting toolbar buttons.
	// Keep styles & old writing systems comboboxes enabled.
	if (cms.Cid() == kcidFmttbStyle || cms.Cid() == kcidFmttbWrtgSys)
	{
		return SuperClass::CmsCharFmt(cms);
	}
	else
	{
		cms.Enable(false);
		return true;
	}
}

/*----------------------------------------------------------------------------------------------
	Open TE specific Styles Dialog. 
----------------------------------------------------------------------------------------------*/
bool ConcTextWnd::OpenFormatStylesDialog(HWND hwnd, bool fCanDoRtl, bool fOuterRtl,
	IVwStylesheet * past, TtpVec & vqttpPara, TtpVec & vqttpChar, bool fCanFormatChar,
	StrUni * pstuStyleName, bool & fStylesChanged, bool & fApply, bool & fReloadDb)
{
	TeStylesDlg tesd;
	return tesd.AdjustTsTextProps(hwnd, fCanDoRtl, fOuterRtl, false, past,
		vqttpPara, vqttpChar, fCanFormatChar, pstuStyleName,
		fStylesChanged, fApply, fReloadDb);
}

// Explicit instantiation.
// ENHANCE JohnT: why isn't this done in AppCore, and how do other apps work without it?
// Maybe all other Vector functions used for this class are inline?
#include "Vector_i.cpp"
template Vector<AfDeFieldEditor *>;
template Vector<ConcColInfo>; // ConcColVec; //Hungarian vcci
