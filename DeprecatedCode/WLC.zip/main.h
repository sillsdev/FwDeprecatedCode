/*----------------------------------------------------------------------------------------------
Copyright 2000-2002, SIL International. All rights reserved.

File: main.h
Responsibility: Darrell Zook
Last reviewed: never

Description:
	Main header file for the Wordlist Concordance EXE.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef HWMAIN_H
#define HWMAIN_H 1

/***********************************************************************************************
	Resource headers
***********************************************************************************************/
#include "resource.h"
#include "TeFmtGenDlgRes.h"
#include "TeStylesDlgRes.h"
#include "TlsOptViewRes.h"

#ifdef WE_THINK_THIS_IS_JUNK
// Special defines
enum
{
	ktagRef = 12654,
};
#endif

/***********************************************************************************************
	Generic header files.
***********************************************************************************************/
#include "Common.h"

/***********************************************************************************************
	Interface headers.
***********************************************************************************************/
#include "FwKernelTlb.h"
#include "DbAccessTlb.h"
#include "LanguageTlb.h"
#include "ViewsTlb.h"
#include "ScriptureObjects.h"
#include "WlcTlb.h"

/***********************************************************************************************
	Additional AppCore headers.
***********************************************************************************************/
#include "AfCore.h"
#include "AfDeCore.h" // Uses stuff from Data Entry framework
#include "AfPrjNotFndDlgRes.h"

typedef enum ScriptureModuleDefns
{
	#define CMCG_SQL_ENUM 1
	#include "Scripture.sqh"
	#include "Ling.sqh"
	#undef CMCG_SQL_ENUM
} ScriptureModuleDefns;

/***********************************************************************************************
	Headers for this project itself.
***********************************************************************************************/
#include "FwAppVersion.h"
#include "DraftWnd.h"
#include "ConcWnd.h"
#include "WLC.h"
#include "TeStyleDlg.h"
#include "TeUtils.h"
#include "TeImport.h"

#endif // !HWMAIN_H
