// TODO: EberhardB (AlistairI) Assign some better IDs to these, and strip out ApStudio junk!
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TeStylesDlg.rc
//
#define kridTeSelectTextType            103
#define kctidTesdCbList                 24390
#define kstidTesdListPubl               24391
#define kridTettdPubl                   24392
#define kstidTesdListNonPubl            24393
#define kridTettdNonPubl                24394
#define kstidTesdListAll                24395
#define kridTeStyleDlg                  3001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         24396
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
