/*--------------------------------------------------------------------*//*:Ignore this sentence.
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: resource.h
Responsibility: Alistair Imrie
Last reviewed: never

Description:
	Defined IDs for WLC resources.
-------------------------------------------------------------------------------*//*:End Ignore*/

/*
	IDs in actual applications start at 1024 (==WM_USER) and work UP.
	To find out why we start at WM_USER, see ms-help://MS.VSCC/MS.MSDNVS/winui/messques_4soi.htm
*/

//#define kridAppMenu                     1024

// After the menu, we need to leave a gap to allow for our Menu Manager class to allocate
// accelerator IDs to the main menu top level items. The gap size has been decided at 20.
// Therefore, no IDs other than kridAppMenu should have a value less than 1044.

#define kridSEIcon				1044

// File menu.
//#define kcidFilePrintPrevw              1045
#define kcidFileImpt                    1046
#define kcidFileExpt                    1047
#define kcidFileProps                   1048

// View menu.
// View...Views submenu.
//#define kcidViewViewsConfig				1050
// View...Filters submenu.
#define kcidViewFltrsNone				1051
//#define kcidViewFltrsConfig				1052

// GoTo menu.
#define kcidGoToBookBegin				1055
#define kcidGoToBookPrev				1056
#define kcidGoToBookNext				1057
#define kcidGoToBookLast				1058

// Insert menu.
#define kcidInsVerseNumber				1059
#define kcidInsSection					1060
#define kcidInsNote						1061
#define kcidInsFootnote					1062

// Format menu.

// Tools menu.
#define kcidToolsSplg					1064
#define kcidToolsOpts                   1065
#define kcidToolsCust                   1066

// Windows menu.
//#define kcidWndCascad					1067
//#define kcidWndTile						1068
//#define kcidWndSideBy					1069

// Help...FieldWorks submenu.
#define kcidHelpConts                   1070
#define kcidHelpIndex                   1071
#define kcidHelpFind                    1072
// Help menu.
#define kcidHelpApp                     1073
#define kcidHelpHowDoI                  1074
//#define kcidHelpWhatsThis               1075
#define kcidHelpTutls                   1076

// Spelling Status menu.
#define kcidSpellStatUndecided			2000
#define kcidSpellStatIncorrect			2001
#define kcidSpellStatCorrect			2002

// ViewBar resource IDs.
#define kridVBarSmall          1086 // Bitmap
#define kridVBarLarge          1087 // Bitmap

// Toolbar resource IDs.
//#define kridTBarStd                   1108 // Bitmap
//#define kridTBarView                  1111 // Bitmap
//#define kridTBarIns                   1112 // Bitmap
//#define kridTBarTools                 1113 // Bitmap
//#define kridTBarWnd                   1114 // Bitmap
#define kridTBarSpelling              1116
//#define kridAccelStd                  1117

// String IDs
#define kstidViews							1120
#define kstidFilters						1121
#define kstidSortMethods					1122
#define kstidParaContentsName				1124
#define kstidHelpMakeEditorAt				1125 // Help string for conc editors - REMcG 4/18/01
#define kstidColWord						1127			
#define kstidColStatus						1128
#define kstidColCount						1129
#define kstidColRef							1130
#define	kstidNoScriptRef					1131 //"No Scripture reference"
#define	kstidImport							1132 //"Import"
#define kstidDefaultNewScriptureName		1133 //"New Scripture"

#define kstidConcordanceCaption				1150
#define kstidDraftViewCaption				1151
#define kstidDraftCaptWithRef				1152

//#define kstidMenu						1160
//#define kstidTBarStd					1161
//#define kstidTBarFmtg					1162
//#define kstidTBarIns					1164
#ifndef kstidTBarTools
#define kstidTBarTools					23820
#endif
//#define kstidTBarWnd					1166


// Splash window resource IDs
#define kridSplashStartMessage          4300
#define kridSplashSqlMessage            4301
#ifndef kridSplashFinishingMessage
#define kridSplashFinishingMessage      23816
#endif


// Load Scripture Reference dialog box
#define kridScriptRefDlg				4325
#define kctidScriptStartRef             4326
#define kctidScriptEndRef               4327

// This group is used for messages displayed in the first pane of the status bar while a
// progress bar is active in the second pane.  Make sure they are between the range given by
// kstidStBar_Min and kstidStBar_Lim in AfCoreRes.h (27900-28000).
#define kstidStBar_CreatingConcordanceView	27900
#define kstidStBar_CreatingDraftView		27901
#ifndef kstidStBar_LoadingLanguageProject
#define kstidStBar_LoadingLanguageProject	27904
#endif
