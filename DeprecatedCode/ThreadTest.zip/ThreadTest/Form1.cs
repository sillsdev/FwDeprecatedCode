using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Cellar;
using SIL.FieldWorks.FDO.LangProj;
using SIL.FieldWorks.FDO.Notebk;

namespace ThreadTest
{

	/// <summary>
	/// testDataSource makes up phony names that are probably unique.
	/// </summary>
	public class testDataSource
	{
		public FdoCache cache;
		public LanguageProject lp;
		public FdoOwningSequence vPeople;
		protected long sequence = 0;
		protected long increment = 0;
		protected string msg;

		public void init()
		{
			sequence = DateTime.Now.Ticks;
			increment = (3 * sequence) + 1;
			cache = FdoCache.Create("ZPU");
			lp = cache.LanguageProject;
			vPeople = lp.PeopleOA.PossibilitiesOS;
		}

		public testDataSource()
		{
			init();
		}

		public string name
		{
			get
			{
				lock (this)
				{
					sequence += increment;
					return "Mike" + sequence.ToString();
				}
			}
		}

		public string message
		{
			get
			{
				lock (this)
				{
					return msg;
				}
			}
			set
			{
				lock (this)
				{
					msg = value;
				}
			}
		}
	}

	/// <summary>
	/// This class is used to communicate with a test running on another thread.
	/// </summary>
	public class testInfo
	{
		protected bool updated; // True iff something changed.
		protected bool enabled; // True iff test should continue.
		protected bool forceFail; // Set to test failure reporting.
		protected int passCount; // Number of times test passed.
		protected int failCount; // Number of times test failed.
		protected string cause;	// Cause of last failure.
		public testDataSource td;

		public System.Threading.Thread testThread;

		public bool kill
		{
			get
			{
				lock (this) return forceFail;
			}
			set
			{
				lock (this) forceFail = value;
			}
		}

		public bool enable
		{
			get
			{
				lock (this) return enabled;
			}
			set
			{
				lock (this) enabled = value;
			}
		}

		public bool failed
		{
			get
			{
				lock (this) return (failCount != 0);
			}
		}

			public bool changed
		{
			get
			{
				lock (this) return updated;
			}
		}

		public string status	// On-line description of test status.
		{
			get
			{
				lock (this)
				{
					updated = false;
					if (enabled)
					{
						if (failCount != 0)
							return "running; FAILED "+failCount.ToString()+"; (passed "+passCount.ToString()+") "+cause;
						return "running; passed "+passCount.ToString()+" OK";
					}
					else
					{
						if (failCount != 0)
							return "STOPPED; FAILED "+failCount.ToString()+"; (passed "+passCount.ToString()+") "+cause;
						return "stopped; passed "+passCount.ToString()+" OK";
					}
				}
			}
			set
			{
				lock (this)
				{
					updated = true;
					cause = value;
				}
			}
		}
		
		public void incPassed()
		{
			lock (this)
			{
				updated = true;
				passCount++;
			}
		}

		public void incFailed()
		{
			lock (this)
			{
				updated = true;
				failCount++;
			}
		}

		public void incFailed(string why)
		{
			lock (this)
			{
				updated = true;
				failCount++;
				cause = why;
			}
		}

		public bool passing()
		{
			lock (this)
				return (failCount == 0);
		}

		public void init()
		{
			lock (this)
			{
				updated = true;
				enabled = false;
				cause = "";
				passCount = 0;
				failCount = 0;
				forceFail = false;
			}
		}

		public testInfo()
		{
			init();
		}

		public void iteration()
		{
			int i;
			CmPerson p;

			if (forceFail)
				throw new System.InvalidOperationException("User forced failure.");
			// Do test here.
			lock(td.vPeople)
			{
				if (td.vPeople.Count < 16)
				{
					p = (CmPerson)td.vPeople.Append((CmObject)new CmPerson());
					p.Name.AnalysisDefaultWritingSystem = td.name;
				}
				i = td.vPeople.Count;
				if (i > 8)
					td.vPeople.RemoveAt(i-1);
			}
			td.message = i.ToString()+" entries.";
		}

		public void cleanUp()
		{
			foreach(CmPerson pn in td.lp.PeopleOA.PossibilitiesOS)
			{
				if ((pn.Name.AnalysisDefaultWritingSystem == null) ||
				   (pn.Name.AnalysisDefaultWritingSystem.StartsWith("Mike")))
					td.vPeople.Remove(pn);
			}
		}

		public void runTest()
		{
			while (enable)
			{
				try
				{
					iteration();
					incPassed();
				}
				catch (Exception e)
				{
					status = e.ToString();
					incFailed();
				}
			}
		}

		public void runThreaded()
		{
			System.Threading.ThreadStart start = new System.Threading.ThreadStart(runTest);
			init();
			lock (this)
			{
				enabled = true;
				testThread = new System.Threading.Thread(start);
			}
			testThread.Start();
		}
	}

	/// <summary>
	/// Main thread test user interface.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label statusLabel;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.CheckBox checkBox3;
		private System.Windows.Forms.Label mainLabel;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Timer timer1;
		private System.ComponentModel.IContainer components;

		protected testInfo testInfo1;
		protected testInfo testInfo2;
		private System.Windows.Forms.CheckBox kill1CheckBox;
		private System.Windows.Forms.CheckBox kill2CheckBox;
		private System.Windows.Forms.CheckBox kill3CheckBox;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button button1;
		protected testInfo testInfo3;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		protected testDataSource td;


		protected void Fail1()
		{
			mainLabel.BackColor = Color.Red;
			checkBox1.BackColor = Color.Red;
			this.BackColor = Color.Red;
			statusLabel.BackColor = Color.Red;
			label1.BackColor = Color.Red;
		}
			
		protected void Fail2()
		{
			label2.BackColor = Color.Red;
			checkBox2.BackColor = Color.Red;
			this.BackColor = Color.Red;
			statusLabel.BackColor = Color.Red;
			label1.BackColor = Color.Red;
		}

		protected void Fail3()
		{
			label3.BackColor = Color.Red;
			checkBox3.BackColor = Color.Red;
			this.BackColor = Color.Red;
			statusLabel.BackColor = Color.Red;
			label1.BackColor = Color.Red;
		}



		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			td = new testDataSource();
			testInfo1 = new testInfo();
			testInfo2 = new testInfo();
			testInfo3 = new testInfo();
			testInfo1.td = td;
			testInfo2.td = td;
			testInfo3.td = td;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.statusLabel = new System.Windows.Forms.Label();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.checkBox3 = new System.Windows.Forms.CheckBox();
			this.mainLabel = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.kill1CheckBox = new System.Windows.Forms.CheckBox();
			this.kill2CheckBox = new System.Windows.Forms.CheckBox();
			this.kill3CheckBox = new System.Windows.Forms.CheckBox();
			this.label4 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// statusLabel
			// 
			this.statusLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.statusLabel.BackColor = System.Drawing.Color.Lime;
			this.statusLabel.Location = new System.Drawing.Point(8, 8);
			this.statusLabel.Name = "statusLabel";
			this.statusLabel.Size = new System.Drawing.Size(672, 13);
			this.statusLabel.TabIndex = 0;
			this.statusLabel.Text = "Select a checkbox to run its test.";
			// 
			// checkBox1
			// 
			this.checkBox1.BackColor = System.Drawing.Color.Lime;
			this.checkBox1.Location = new System.Drawing.Point(8, 32);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(104, 16);
			this.checkBox1.TabIndex = 1;
			this.checkBox1.Text = "&Main thread";
			this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// checkBox2
			// 
			this.checkBox2.BackColor = System.Drawing.Color.Lime;
			this.checkBox2.Location = new System.Drawing.Point(8, 56);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(104, 16);
			this.checkBox2.TabIndex = 2;
			this.checkBox2.Text = "Thread &2";
			this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
			// 
			// checkBox3
			// 
			this.checkBox3.BackColor = System.Drawing.Color.Lime;
			this.checkBox3.Location = new System.Drawing.Point(8, 80);
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.Size = new System.Drawing.Size(104, 16);
			this.checkBox3.TabIndex = 3;
			this.checkBox3.Text = "Thread &3";
			this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
			// 
			// mainLabel
			// 
			this.mainLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.mainLabel.BackColor = System.Drawing.Color.Lime;
			this.mainLabel.Location = new System.Drawing.Point(112, 32);
			this.mainLabel.Name = "mainLabel";
			this.mainLabel.Size = new System.Drawing.Size(648, 16);
			this.mainLabel.TabIndex = 4;
			this.mainLabel.Text = "Idle";
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.label2.BackColor = System.Drawing.Color.Lime;
			this.label2.Location = new System.Drawing.Point(112, 56);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(648, 16);
			this.label2.TabIndex = 5;
			this.label2.Text = "Thread 2 not created.";
			// 
			// label3
			// 
			this.label3.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.label3.BackColor = System.Drawing.Color.Lime;
			this.label3.Location = new System.Drawing.Point(112, 80);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(648, 16);
			this.label3.TabIndex = 6;
			this.label3.Text = "Thread 3 not yet created.";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Lime;
			this.label1.Location = new System.Drawing.Point(8, 104);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 13);
			this.label1.TabIndex = 7;
			this.label1.Text = "Initializing...";
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// kill1CheckBox
			// 
			this.kill1CheckBox.Location = new System.Drawing.Point(8, 144);
			this.kill1CheckBox.Name = "kill1CheckBox";
			this.kill1CheckBox.Size = new System.Drawing.Size(144, 16);
			this.kill1CheckBox.TabIndex = 8;
			this.kill1CheckBox.Text = "Force main failure";
			this.kill1CheckBox.CheckedChanged += new System.EventHandler(this.kill1CheckBox_CheckedChanged);
			// 
			// kill2CheckBox
			// 
			this.kill2CheckBox.Location = new System.Drawing.Point(8, 160);
			this.kill2CheckBox.Name = "kill2CheckBox";
			this.kill2CheckBox.Size = new System.Drawing.Size(144, 16);
			this.kill2CheckBox.TabIndex = 9;
			this.kill2CheckBox.Text = "Force 2 failure";
			this.kill2CheckBox.CheckedChanged += new System.EventHandler(this.kill2CheckBox_CheckedChanged);
			// 
			// kill3CheckBox
			// 
			this.kill3CheckBox.Location = new System.Drawing.Point(8, 176);
			this.kill3CheckBox.Name = "kill3CheckBox";
			this.kill3CheckBox.Size = new System.Drawing.Size(144, 16);
			this.kill3CheckBox.TabIndex = 10;
			this.kill3CheckBox.Text = "Force 3 failure";
			this.kill3CheckBox.CheckedChanged += new System.EventHandler(this.kill3CheckBox_CheckedChanged);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(8, 128);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(350, 13);
			this.label4.TabIndex = 11;
			this.label4.Text = "Check exception catching in the test program with these checkboxes:";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(400, 120);
			this.button1.Name = "button1";
			this.button1.TabIndex = 12;
			this.button1.Text = "&Go1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(488, 120);
			this.button2.Name = "button2";
			this.button2.TabIndex = 13;
			this.button2.Text = "Go2";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(576, 120);
			this.button3.Name = "button3";
			this.button3.TabIndex = 14;
			this.button3.Text = "Go3";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(400, 152);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(200, 23);
			this.button4.TabIndex = 15;
			this.button4.Text = "&Remove test data from database";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.Lime;
			this.ClientSize = new System.Drawing.Size(768, 197);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button4,
																		  this.button3,
																		  this.button2,
																		  this.button1,
																		  this.label4,
																		  this.kill3CheckBox,
																		  this.kill2CheckBox,
																		  this.kill1CheckBox,
																		  this.label1,
																		  this.label3,
																		  this.label2,
																		  this.mainLabel,
																		  this.checkBox3,
																		  this.checkBox2,
																		  this.checkBox1,
																		  this.statusLabel});
			this.Name = "MainForm";
			this.Text = "ThreadTest";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			DateTime dt = DateTime.Now;
			System.DateTime utc = dt.ToUniversalTime();
			label1.Text = utc.ToString("dddd, dd MMMM yyyy H:mm:ss.f UTC");
			statusLabel.Text = testInfo1.td.message;
			if (testInfo1.changed)
			{
				mainLabel.Text = testInfo1.status;
				if (testInfo1.failed)
					Fail1();
			}
			if (testInfo2.changed)
			{
				label2.Text = testInfo2.status;
				if (testInfo2.failed)
					Fail2();
			}
			if (testInfo3.changed)
			{
				label3.Text = testInfo3.status;
				if (testInfo3.failed)
					Fail3();
			}
			if (testInfo1.enable)
			{
				try
				{
					testInfo1.iteration();
					testInfo1.incPassed();
				}
				catch (Exception Err)
				{
					testInfo1.incFailed(Err.ToString());
				}
			}
		}

		private void checkBox1_CheckedChanged(object sender, System.EventArgs e)
		{
			testInfo1.enable = checkBox1.Checked;
		}

		private void checkBox2_CheckedChanged(object sender, System.EventArgs e)
		{
			if (checkBox2.Checked)
				testInfo2.runThreaded();
			else
				testInfo2.enable = false;
		}

		private void checkBox3_CheckedChanged(object sender, System.EventArgs e)
		{
			if (checkBox3.Checked)
				testInfo3.runThreaded();
			else
				testInfo3.enable = false;
		}

		private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			testInfo3.enable = false;
			testInfo2.enable = false;
			testInfo1.enable = false;
		}

		private void kill1CheckBox_CheckedChanged(object sender, System.EventArgs e)
		{
			testInfo1.kill = kill1CheckBox.Checked;
		}

		private void kill2CheckBox_CheckedChanged(object sender, System.EventArgs e)
		{
			testInfo2.kill = kill2CheckBox.Checked;
		}

		private void kill3CheckBox_CheckedChanged(object sender, System.EventArgs e)
		{
			testInfo3.kill = kill3CheckBox.Checked;
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			try
			{
				testInfo1.iteration();
				testInfo1.incPassed();
			}
			catch (Exception Err)
			{
				testInfo1.incFailed(Err.ToString());
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			try
			{
				testInfo2.iteration();
				testInfo2.incPassed();
			}
			catch (Exception Err)
			{
				testInfo2.incFailed(Err.ToString());
			}
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			try
			{
				testInfo3.iteration();
				testInfo3.incPassed();
			}
			catch (Exception Err)
			{
				testInfo3.incFailed(Err.ToString());
			}
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			testInfo1.cleanUp();
		}

	}
}
