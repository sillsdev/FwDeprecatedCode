/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: DbAdmin.cpp
Responsibility: John Thomson

Description:
	Implementation of database administration interfaces.

	This file contains class definitions for the following classes:
		DbAdmin
-------------------------------------------------------------------------------*//*:End Ignore*/
#include "main.h"
#pragma hdrstop
#undef THIS_FILE
DEFINE_THIS_FILE

//:>********************************************************************************************
//:>	DbAdmin - Constructor/Destructor.
//:>********************************************************************************************
DbAdmin::DbAdmin()
{
	m_cref = 1;
	ModuleEntry::ModuleAddRef();
}


DbAdmin::~DbAdmin()
{
	ModuleEntry::ModuleRelease();
}

//:>********************************************************************************************
//:>    Generic factory stuff to allow creating an instance with CoCreateInstance.
//:>********************************************************************************************
static GenericFactory g_fact(
	_T("SIL.DbAccess.DbAdmin"),
	&CLSID_DbAdmin,
	_T("SIL database access"),
	_T("Apartment"),
	&DbAdmin::CreateCom);


void DbAdmin::CreateCom(IUnknown *punkCtl, REFIID riid, void ** ppv)
{
	AssertPtr(ppv);
	Assert(!*ppv);
	if (punkCtl)
	{
		ThrowHr(WarnHr(CLASS_E_NOAGGREGATION));
	}
	ComSmartPtr<DbAdmin> qzode;
	qzode.Attach(NewObj DbAdmin());		// ref count initially 1
	CheckHr(qzode->QueryInterface(riid, ppv));
}


//:>********************************************************************************************
//:>	IDbAdmin - IUnknown Methods
//:>********************************************************************************************
STDMETHODIMP DbAdmin::QueryInterface(REFIID iid, void ** ppv)
{
	AssertPtr(ppv);
	if (!ppv)
		return WarnHr(E_POINTER);
	*ppv = NULL;

	if (iid == IID_IUnknown)
		*ppv = static_cast<IUnknown *>(static_cast<IDbAdmin *>(this));
	else if (iid == IID_IDbAdmin)
		*ppv = static_cast<IDbAdmin *>(this);
	else if (iid == IID_ISupportErrorInfo)
	{
		*ppv = NewObj CSupportErrorInfo(
			static_cast<IUnknown *>(static_cast<IDbAdmin *>(this)), IID_IDbAdmin);
		return S_OK;
	}
	else
		return E_NOINTERFACE;

	reinterpret_cast<IUnknown *>(*ppv)->AddRef();
	return S_OK;
}


STDMETHODIMP_(ULONG) DbAdmin::AddRef(void)
{
	Assert(m_cref > 0);
	::InterlockedIncrement(&m_cref);
	return m_cref;
}

STDMETHODIMP_(ULONG) DbAdmin::Release(void)
{
	Assert(m_cref > 0);
	ulong cref = ::InterlockedDecrement(&m_cref);
	if (!cref)
	{
		m_cref = 1;
		delete this;
	}
	return cref;
}


//:>********************************************************************************************
//:>	IDbAdmin Methods
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Copy a (detached) database to a (detached) destination.
	Source path is the full name without extension of the mdf/log file pair.
	Destination path is the full name without extension of the mdf/log pair to create.
	This does not attach the database or change its internal name.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DbAdmin::CopyDatabase(BSTR bstrSrcPathName, BSTR bstrDstPathName)
{
	BEGIN_COM_METHOD;
	ChkComBstrArg(bstrSrcPathName);
	ChkComBstrArg(bstrDstPathName);
	StrUni stuMdfSrcName(bstrSrcPathName);
	stuMdfSrcName += L".mdf";
	StrUni stuMdfDstName(bstrDstPathName);
	stuMdfDstName += L".mdf";
	if (::CopyFileW(stuMdfSrcName.Chars(), stuMdfDstName.Chars(), TRUE) == 0) // fail if exists
		return E_FAIL;
	END_COM_METHOD(g_fact, IID_IDbAdmin);
}

/*----------------------------------------------------------------------------------------------
	Attach a database so it can be used.
	The first argument gives the internal name to be assigned to the database.
	The second gives the full path (excluding any extension) to the mdf/log file pair.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DbAdmin::AttachDatabase(BSTR bstrDatabaseName, BSTR bstrPathName)
{
	BEGIN_COM_METHOD;
	ChkComBstrArg(bstrDatabaseName);
	ChkComBstrArg(bstrPathName);
	IOleDbEncapPtr qode; // Declare before qodc.
	IOleDbCommandPtr qodc;
	qode.CreateInstance(CLSID_OleDbEncap);
	StrUni stuServer(SilUtil::LocalServerName());
	if (!stuServer.Length())
		stuServer.Assign(L".\\SILFW");
	StrUni stuMaster(L"master");
	// Put up a message box if unable to attach master; no timeout.
	CheckHr(qode->Init(stuServer.Bstr(), stuMaster.Bstr(), m_qfist, koltMsgBox,
		koltvFwDefault));
	CheckHr(qode->CreateCommand(&qodc));
	StrUni stuCmd;
	// Check whether the log file exists, and build the attach command accordingly.
	StrUni stuLdf;
	stuLdf.Format(L"%s_log.ldf", bstrPathName);
	StrUni stuLdf2;
	StrUni stuPath(bstrPathName); // We'll be using the path up to the db name.
	int cchPath =  stuPath.ReverseFindCh('\\');
	if (cchPath > 0)
	{
		stuLdf2.Assign(stuPath.Chars(), cchPath);
		stuLdf2.FormatAppend(L"%s_log.ldf", bstrDatabaseName);
	}
	WIN32_FIND_DATA wfd;
	HANDLE hFind = ::FindFirstFileW(stuLdf.Chars(), &wfd);
	HANDLE hFind2 = INVALID_HANDLE_VALUE;
	if (stuLdf2.Length() != 0 && hFind == INVALID_HANDLE_VALUE)
	{
		hFind2 = ::FindFirstFileW(stuLdf2.Chars(), &wfd);
	}
	if (hFind != INVALID_HANDLE_VALUE)
	{
		::FindClose(hFind);
		// sp_attach_db will attach whatever transaction log is passed to it. The
		// FW default is to name the transaction log file the same as the database
		// database file name + "_log", such as TestLangProj.mdf and
		// TestLangProj_log.ldf.
		stuCmd.Format(
			L"EXEC sp_attach_db @dbname=N'%s', @filename1=N'%s.mdf', @filename2=N'%s'",
			bstrDatabaseName, bstrPathName, stuLdf.Chars());
	}
	else if (hFind2 != INVALID_HANDLE_VALUE)
	{
		::FindClose(hFind);
		stuPath.Replace(cchPath, stuPath.Length(), bstrDatabaseName);
		stuCmd.Format(
			L"EXEC sp_attach_db @dbname=N'%s', @filename1=N'%s.mdf', @filename2=N'%s'",
			bstrDatabaseName, stuPath.Chars(), stuLdf.Chars());
	}
	else
	{
		// sp_attach_single_file_db generates a new lof file. Unfortunately, the new log
		// file is named after the database name, not the file name of the database. For 
		// example, CopyOfBlankLangProj.mdf and DummyDb_log.ldf. The same is true with
		// using sp_attach_db.
		//
		stuCmd.Format(L"EXEC sp_attach_single_file_db @dbname=N'%s', @physname=N'%s.mdf'",
			bstrDatabaseName, bstrPathName);
	}
	// We randomly have SQLServer locking access to the database file in the process of
	// attaching and detaching. It may be related to COM pointers not being cleared
	// adequately, so we'll do this explicitly here rather than returning directly.
	//return qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults);
	HRESULT hr = qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults);
	qodc.Clear();
	qode.Clear();
	return hr;
	END_COM_METHOD(g_fact, IID_IDbAdmin);
}
	
/*----------------------------------------------------------------------------------------------
	Detach a database.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DbAdmin::DetachDatabase(BSTR bstrDatabaseName)
{
	BEGIN_COM_METHOD;
	ChkComBstrArg(bstrDatabaseName);
	IOleDbEncapPtr qode; // Declare before qodc.
	IOleDbCommandPtr qodc;
	qode.CreateInstance(CLSID_OleDbEncap);
	StrUni stuServer(SilUtil::LocalServerName());
	if (!stuServer.Length())
		stuServer.Assign(L".\\SILFW");
	StrUni stuMaster(L"master");
	// Put up a message box if unable to attach master; no timeout.
	CheckHr(qode->Init(stuServer.Bstr(), stuMaster.Bstr(), m_qfist, koltMsgBox,
		koltvFwDefault));
	CheckHr(qode->CreateCommand(&qodc));
	StrUni stuCmd;
	stuCmd.Format(L"EXEC sp_detach_db '%s'", bstrDatabaseName);
	// We randomly have SQLServer locking access to the database file in the process of
	// attaching and detaching. It may be related to COM pointers not being cleared
	// adequately, so we'll do this explicitly here rather than returning directly.
	//return qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults);
	CheckHr(qodc->ExecCommand(stuCmd.Bstr(), knSqlStmtNoResults));
	qodc.Clear();
	qode.Clear();
	// The above didn't work, so we'll try to sleep awhile after the detach to let
	// everything settle down. It never seems to give trouble when single-stepping. Once
	// locked, however, the only way to unlock it seems to be to stop SQL Server.
	Sleep(1500);
	END_COM_METHOD(g_fact, IID_IDbAdmin);
}
	
/*----------------------------------------------------------------------------------------------
	Rename a database.
	The database is found in bstrDirName\bstrOldName.mdf.
	This file is renamed to bstrDirName\bstrNewName.mdf.
	If there is a file bstrDirName\bstrOldName_log.ldf, it is deleted. (A new log is typially
	created by attaching the renamed database.)
	If the database is attached to begin with, set fDetachBefore to get it detached before the
	files are renamed. This assumes its internal name is the same as the main body of the
	filename.
	Set fAttachAfter to attach the database afterwards and give it the internal name
	bstrNewName.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DbAdmin::RenameDatabase(BSTR bstrDirName, BSTR bstrOldName,	
	BSTR bstrNewName, ComBool fDetachBefore, ComBool fAttachAfter)
{
	BEGIN_COM_METHOD;
	ChkComBstrArg(bstrDirName);
	ChkComBstrArg(bstrOldName);
	ChkComBstrArg(bstrNewName);

	if (fDetachBefore)
		CheckHr(DetachDatabase(bstrOldName));

	StrUni stuOldMdfPath = bstrDirName;
	stuOldMdfPath += L"\\";
	stuOldMdfPath += bstrOldName;
	StrUni stuOldLogPath = stuOldMdfPath;
	stuOldMdfPath += L".mdf";
	stuOldLogPath += L"_log.ldf";

	StrUni stuNewPath = bstrDirName;
	stuNewPath += L"\\";
	stuNewPath += bstrNewName;
	StrUni stuNewPathMdf = stuNewPath;
	stuNewPathMdf += L".mdf";
	if (0 == ::MoveFile(stuOldMdfPath.Chars(), stuNewPathMdf.Chars()))
		return E_FAIL;
	// Ignore any errors, we did our best. Most likely it had never been attached so the
	// log file did not exist.
	::DeleteFile(stuOldLogPath.Chars());

	if (fAttachAfter)
		CheckHr(AttachDatabase(bstrNewName, stuNewPath.Bstr()));
	END_COM_METHOD(g_fact, IID_IDbAdmin);
}

/*----------------------------------------------------------------------------------------------
	Set a log stream that can be used to report errors.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DbAdmin::putref_LogStream(IStream * pstrm)
{
	BEGIN_COM_METHOD;
	ChkComArgPtr(pstrm);
	m_qfist = pstrm;
	END_COM_METHOD(g_fact, IID_IDbAdmin);
}


/*----------------------------------------------------------------------------------------------
	Get the FW root directory
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DbAdmin::get_FwRootDir(BSTR * pbstr)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pbstr);
	*pbstr = ::SysAllocString(DirectoryFinder::FwRootDir());
	END_COM_METHOD(g_fact, IID_IDbAdmin);
}
/*----------------------------------------------------------------------------------------------
	Get the FW directory that holds data migration scripts.
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DbAdmin::get_FwMigrationScriptDir(BSTR * pbstr)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pbstr);
	*pbstr = ::SysAllocString(DirectoryFinder::FwMigrationScriptDir());
	END_COM_METHOD(g_fact, IID_IDbAdmin);
}
/*----------------------------------------------------------------------------------------------
	Get the FW directory that holds FW databases
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DbAdmin::get_FwDatabaseDir(BSTR * pbstr)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pbstr);
	*pbstr = ::SysAllocString(DirectoryFinder::FwDatabaseDir());
	END_COM_METHOD(g_fact, IID_IDbAdmin);
}
/*----------------------------------------------------------------------------------------------
	Get the FW directory that holds templates (e.g., BlankLangProj)
----------------------------------------------------------------------------------------------*/
STDMETHODIMP DbAdmin::get_FwTemplateDir(BSTR * pbstr)
{
	BEGIN_COM_METHOD;
	ChkComOutPtr(pbstr);
	*pbstr = ::SysAllocString(DirectoryFinder::FwTemplateDir());
	END_COM_METHOD(g_fact, IID_IDbAdmin);
}
