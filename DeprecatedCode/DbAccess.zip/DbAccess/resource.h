//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DbAccess.rc
//
#define kstiddbeCreateSession			1103
#define kstiddbeDAI						1104
#define kstiddbeDatSrc					1105
#define kstiddbeInit					1106
#define kstiddbeITransact				1107
#define kstidSQLFailure					1108
#define kstidSQLStartFailure			1109
#define kstiddbeSetup					1110
#define kstidDetachFailure				1111
//#define kstidRenameFailure				1112
#define kstidAttachFailure				1113
#define kstidSQLOutOfMemory				1114
#define kstidSQLNotStarted				1115
#define kstidSCManagerFail				1116
#define kstidNoStatus					1117
#define kstidNoMemory					1118
#define kstidCantOpen					1119
#define kstidQSSFailed					1120
#define kstidCantStart					1121
#define kstidStatusFailed				1122

// Error messages and help ids.
#define khcidDatabaseError				1150
#define kstidDatabaseGeneral			1151
#define kstidDatabaseCommLink			1152
#define kstidDatabaseResources			1153
#define kstidDatabaseIntegrity			1154
#define kstidDatabaseHardware			1155
#define kstidDatabaseTruncate			1156
#define kstidDatabaseLockTim			1157
// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
