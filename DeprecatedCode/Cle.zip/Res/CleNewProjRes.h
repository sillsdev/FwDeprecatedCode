/*----------------------------------------------------------------------------------------------
Copyright 2001, SIL International. All rights reserved.

File: CleNewProjRes.h
Responsibility: Steve McConnel
Last reviewed: Not yet.

Description:
	Resource definitions for the New Language Project wizard.
----------------------------------------------------------------------------------------------*/

// Create New Language Project Wizard Pages

#define kridEmptyList                 4660
#define kridEmptyListIcon             4661
#define kridEmptyListHeader           4662
#define kctidEmptyLNewItem            4663

#define kctidEmptyLImport             4665
#define kstidEmptyListHeaderFmt       4666

