/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: CleLstNotFndDlgRes.h
Responsibility: John Landon
Last reviewed: never

Description: Header file for constants in CleLstNotFndDlg.rc.
-------------------------------------------------------------------------------*//*:End Ignore*/
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CleLstNotFndDlg.rc
//
#define kridCleLstNotFndDlg             4500
#define kridLstNotFndIcon               4502
#define kridLstNotFndHeader             4503
#define kctidLstNotFndOpen              4510
#define kctidLstNotFndNew               4511
#define kctidLstNotFndExit              4512
#define kstidLstNotFndHeaderFmt         4520
