using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace SIL.ANA.AnaToParadigm
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class EditParameters : System.Windows.Forms.Form
	{
		public string parameters = "%<>";
		private bool m_bHasChanged = false;
		private System.Windows.Forms.Label AmbiguityLabel;
		private System.Windows.Forms.Label LeadingStemLabel;
		private System.Windows.Forms.Label TrailingStemLabel;
		private System.Windows.Forms.TextBox ambiguityDelimiter;
		private System.Windows.Forms.TextBox leadingStemDelimiter;
		private System.Windows.Forms.TextBox trailingStemDelimiter;
		private System.Windows.Forms.Button OK;
		private System.Windows.Forms.Button Cancel;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public EditParameters(string inParameters)
		{
			//
			// Required for Windows Form Designer support
			//
			if (inParameters != null && inParameters.Length > 2)
				parameters = inParameters;

			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.AmbiguityLabel = new System.Windows.Forms.Label();
			this.LeadingStemLabel = new System.Windows.Forms.Label();
			this.TrailingStemLabel = new System.Windows.Forms.Label();
			this.ambiguityDelimiter = new System.Windows.Forms.TextBox();
			this.leadingStemDelimiter = new System.Windows.Forms.TextBox();
			this.trailingStemDelimiter = new System.Windows.Forms.TextBox();
			this.OK = new System.Windows.Forms.Button();
			this.Cancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// AmbiguityLabel
			// 
			this.AmbiguityLabel.Enabled = false;
			this.AmbiguityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.AmbiguityLabel.Location = new System.Drawing.Point(16, 32);
			this.AmbiguityLabel.Name = "AmbiguityLabel";
			this.AmbiguityLabel.Size = new System.Drawing.Size(128, 24);
			this.AmbiguityLabel.TabIndex = 2;
			this.AmbiguityLabel.Text = "Ambiguity Delimiter";
			// 
			// LeadingStemLabel
			// 
			this.LeadingStemLabel.Enabled = false;
			this.LeadingStemLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.LeadingStemLabel.Location = new System.Drawing.Point(16, 88);
			this.LeadingStemLabel.Name = "LeadingStemLabel";
			this.LeadingStemLabel.Size = new System.Drawing.Size(144, 24);
			this.LeadingStemLabel.TabIndex = 4;
			this.LeadingStemLabel.Text = "Leading Stem Delimiter";
			// 
			// TrailingStemLabel
			// 
			this.TrailingStemLabel.Enabled = false;
			this.TrailingStemLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.TrailingStemLabel.Location = new System.Drawing.Point(16, 144);
			this.TrailingStemLabel.Name = "TrailingStemLabel";
			this.TrailingStemLabel.Size = new System.Drawing.Size(144, 24);
			this.TrailingStemLabel.TabIndex = 5;
			this.TrailingStemLabel.Text = "Trailing Stem Delimiter";
			// 
			// ambiguityDelimiter
			// 
			this.ambiguityDelimiter.AccessibleDescription = "Ambiguity Delimiter";
			this.ambiguityDelimiter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.ambiguityDelimiter.Location = new System.Drawing.Point(176, 24);
			this.ambiguityDelimiter.MaxLength = 1;
			this.ambiguityDelimiter.Name = "ambiguityDelimiter";
			this.ambiguityDelimiter.Size = new System.Drawing.Size(24, 21);
			this.ambiguityDelimiter.TabIndex = 4;
			this.ambiguityDelimiter.Text = parameters[0].ToString();
			this.ambiguityDelimiter.WordWrap = false;
			this.ambiguityDelimiter.TextChanged += new System.EventHandler(this.ambiguityDelimiter_TextChanged);
			// 
			// leadingStemDelimiter
			// 
			this.leadingStemDelimiter.AccessibleDescription = "Leading Stem Delimiter";
			this.leadingStemDelimiter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.leadingStemDelimiter.Location = new System.Drawing.Point(176, 80);
			this.leadingStemDelimiter.MaxLength = 1;
			this.leadingStemDelimiter.Name = "leadingStemDelimiter";
			this.leadingStemDelimiter.Size = new System.Drawing.Size(24, 21);
			this.leadingStemDelimiter.TabIndex = 5;
			this.leadingStemDelimiter.Text = parameters[1].ToString();
			this.leadingStemDelimiter.WordWrap = false;
			this.leadingStemDelimiter.TextChanged += new System.EventHandler(this.leadingStemDelimiter_TextChanged);
			// 
			// trailingStemDelimiter
			// 
			this.trailingStemDelimiter.AccessibleDescription = "Trailing Stem Delimiter";
			this.trailingStemDelimiter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.trailingStemDelimiter.Location = new System.Drawing.Point(176, 136);
			this.trailingStemDelimiter.MaxLength = 1;
			this.trailingStemDelimiter.Name = "trailingStemDelimiter";
			this.trailingStemDelimiter.Size = new System.Drawing.Size(24, 21);
			this.trailingStemDelimiter.TabIndex = 6;
			this.trailingStemDelimiter.Text = parameters[2].ToString();
			this.trailingStemDelimiter.WordWrap = false;
			this.trailingStemDelimiter.TextChanged += new System.EventHandler(this.trailingStemDelimiter_TextChanged);
			// 
			// OK
			// 
			this.OK.AccessibleDescription = "OK";
			this.OK.AccessibleName = "OK";
			this.OK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.OK.Location = new System.Drawing.Point(32, 208);
			this.OK.Name = "OK";
			this.OK.Size = new System.Drawing.Size(64, 24);
			this.OK.TabIndex = 7;
			this.OK.Text = "OK";
			this.OK.Click += new System.EventHandler(this.OK_Click);
			// 
			// Cancel
			// 
			this.Cancel.AccessibleDescription = "Cancel";
			this.Cancel.AccessibleName = "Cancel";
			this.Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.Cancel.Location = new System.Drawing.Point(136, 208);
			this.Cancel.Name = "Cancel";
			this.Cancel.Size = new System.Drawing.Size(72, 24);
			this.Cancel.TabIndex = 8;
			this.Cancel.Text = "Cancel";
			this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
			// 
			// EditParameters
			// 
			this.AcceptButton = this.OK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.Cancel;
			this.ClientSize = new System.Drawing.Size(244, 268);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Cancel,
																		  this.OK,
																		  this.trailingStemDelimiter,
																		  this.leadingStemDelimiter,
																		  this.ambiguityDelimiter,
																		  this.TrailingStemLabel,
																		  this.LeadingStemLabel,
																		  this.AmbiguityLabel});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "EditParameters";
			this.Text = "Edit Parameter File";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Ok.
		/// </summary>
		private void OK_Click(object sender, System.EventArgs e)
		{
			if (m_bHasChanged == true)
				parameters = ambiguityDelimiter.Text + leadingStemDelimiter.Text
					+ trailingStemDelimiter.Text;
			else
				parameters = null;

		}

		/// <summary>
		/// Cancel.
		/// </summary>
		private void Cancel_Click(object sender, System.EventArgs e)
		{
			parameters = null;
		}

		/// <summary>
		/// Ambiguity Delimiter has changed
		/// </summary>
		private void ambiguityDelimiter_TextChanged(object sender, System.EventArgs e)
		{
			m_bHasChanged = true;
		}

		/// <summary>
		/// Leading Stem Delimiter has changed.
		/// </summary>
		private void leadingStemDelimiter_TextChanged(object sender, System.EventArgs e)
		{
			m_bHasChanged = true;		
		}

		/// <summary>
		/// Trailing Stem Delimiter has changed.
		/// </summary>
		private void trailingStemDelimiter_TextChanged(object sender, System.EventArgs e)
		{
			m_bHasChanged = true;		
		}

	}
}
