// --------------------------------------------------------------------------------------------
// <copyright from='2003' to='2003' company='SIL International'>
//    Copyright (c) 2003, SIL International. All Rights Reserved.   
// </copyright> 
// 
// File: ANAToPositionMainWnd.cs
// Responsibility: RoyE
// Last reviewed: 
// 
// <remarks>
// Implementation of TestAppAnaConverter.
// </remarks>
//
// --------------------------------------------------------------------------------------------

using System;
using System.IO;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using SIL.ANA.AnaToParadigm;
using SIL.WordWorks.GAFAWS.ANAConversion;
using SIL.WordWorks.GAFAWS.PositionAnalysis;
using SIL.WordWorks.GAFAWS;
using System.Diagnostics;
using System.Xml.Xsl;

namespace SIL.WordWorks.GAFAWS.AnaToParadigm
{
	/// <summary>
	/// ANAToPositionMainWnd.cs provides input for ANAConverter.cs.
	/// </summary>
	public class ANAToPositionMainWnd : System.Windows.Forms.Form
	{
		private ANAGAFAWSConverter m_agc;
		private PositionAnalyzer m_pa;
		private string m_sConverterPath;
		private string m_sPositionPath = null;
		private string m_sANAFileName = null;
		private string m_sParametersFileName = null;

		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem SaveAs;
		private System.Windows.Forms.MenuItem Execute;
		private System.Windows.Forms.MenuItem ViewFile;
		private System.Windows.Forms.MenuItem FileMenu;
		private System.Windows.Forms.MenuItem OpenANAFile;
		private System.Windows.Forms.MenuItem OpenParameterFile;
		private System.Windows.Forms.MenuItem Exit;
		private System.Windows.Forms.MenuItem Edit;
		private System.Windows.Forms.MenuItem CreateParameterFile;
		private System.Windows.Forms.MenuItem EditParameterFile;
		private System.Windows.Forms.MenuItem View;
		private System.Windows.Forms.MenuItem Window;
		private System.Windows.Forms.MenuItem Help;
		private System.Windows.Forms.MenuItem ExecuteOnMainMenu;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ANAToPositionMainWnd()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			m_agc = new ANAGAFAWSConverter();
			m_pa  = new PositionAnalyzer();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.FileMenu = new System.Windows.Forms.MenuItem();
			this.OpenANAFile = new System.Windows.Forms.MenuItem();
			this.OpenParameterFile = new System.Windows.Forms.MenuItem();
			this.SaveAs = new System.Windows.Forms.MenuItem();
			this.Exit = new System.Windows.Forms.MenuItem();
			this.ExecuteOnMainMenu = new System.Windows.Forms.MenuItem();
			this.Execute = new System.Windows.Forms.MenuItem();
			this.Edit = new System.Windows.Forms.MenuItem();
			this.CreateParameterFile = new System.Windows.Forms.MenuItem();
			this.EditParameterFile = new System.Windows.Forms.MenuItem();
			this.View = new System.Windows.Forms.MenuItem();
			this.ViewFile = new System.Windows.Forms.MenuItem();
			this.Window = new System.Windows.Forms.MenuItem();
			this.Help = new System.Windows.Forms.MenuItem();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.FileMenu,
																					  this.ExecuteOnMainMenu,
																					  this.Edit,
																					  this.View,
																					  this.Window,
																					  this.Help});
			// 
			// FileMenu
			// 
			this.FileMenu.Index = 0;
			this.FileMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.OpenANAFile,
																					 this.OpenParameterFile,
																					 this.SaveAs,
																					 this.Exit});
			this.FileMenu.Text = "Files";
			// 
			// OpenANAFile
			// 
			this.OpenANAFile.Index = 0;
			this.OpenANAFile.Text = "Open &ANA File";
			this.OpenANAFile.Click += new System.EventHandler(this.OpenANAFile_Click);
			// 
			// OpenParameterFile
			// 
			this.OpenParameterFile.Index = 1;
			this.OpenParameterFile.Text = "Open &Parameter File";
			this.OpenParameterFile.Click += new System.EventHandler(this.OpenParameterFile_Click);
			// 
			// SaveAs
			// 
			this.SaveAs.Index = 2;
			this.SaveAs.Text = "&Save As";
			this.SaveAs.Click += new System.EventHandler(this.SaveAs_Click);
			// 
			// Exit
			// 
			this.Exit.Index = 3;
			this.Exit.Text = "E&xit";
			this.Exit.Click += new System.EventHandler(this.Exit_Click);
			// 
			// ExecuteOnMainMenu
			// 
			this.ExecuteOnMainMenu.Index = 1;
			this.ExecuteOnMainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							  this.Execute});
			this.ExecuteOnMainMenu.Text = "Execute";
			// 
			// Execute
			// 
			this.Execute.Index = 0;
			this.Execute.Text = "E&xecute";
			this.Execute.Click += new System.EventHandler(this.Execute_Click);
			// 
			// Edit
			// 
			this.Edit.Index = 2;
			this.Edit.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				 this.CreateParameterFile,
																				 this.EditParameterFile});
			this.Edit.Text = "Edit";
			// 
			// CreateParameterFile
			// 
			this.CreateParameterFile.Index = 0;
			this.CreateParameterFile.Text = "&Create Parameter File";
			this.CreateParameterFile.Click += new System.EventHandler(this.CreateParameterFile_Click);
			// 
			// EditParameterFile
			// 
			this.EditParameterFile.Index = 1;
			this.EditParameterFile.Text = "&Edit Parameter File";
			this.EditParameterFile.Click += new System.EventHandler(this.EditParameterFile_Click);
			// 
			// View
			// 
			this.View.Index = 3;
			this.View.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				 this.ViewFile});
			this.View.Text = "View";
			// 
			// ViewFile
			// 
			this.ViewFile.Index = 0;
			this.ViewFile.Text = "View Output File";
			this.ViewFile.Click += new System.EventHandler(this.ViewFile_Click);
			// 
			// Window
			// 
			this.Window.Index = 4;
			this.Window.Text = "Window";
			// 
			// Help
			// 
			this.Help.Index = 5;
			this.Help.Text = "Help";
			// 
			// ANAToPositionMainWnd
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 225);
			this.Menu = this.mainMenu1;
			this.Name = "ANAToPositionMainWnd";
			this.Text = "AnaToParadigm";
			this.Load += new System.EventHandler(this.ANAToPositionMainWnd_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new ANAToPositionMainWnd());
		}

		private void ANAToPositionMainWnd_Load(object sender, System.EventArgs e)
		{
		
		}

		/// <summary>
		/// Get analysis file name.
		/// </summary>
		private void OpenANAFile_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog dialog = new OpenFileDialog();
			dialog.CheckFileExists = true;
			dialog.Title = "Ample Analysis File";
			dialog.Filter = "ANA files (*.ana)|*.ana|All files (*.*)|*.*" ;
			GetFileName(dialog);
			m_sANAFileName = dialog.FileName;
			dialog.Dispose();
		}

		/// <summary>
		/// Get parameters file name.
		/// </summary>
		private void OpenParameterFile_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog dialog = new OpenFileDialog();
			dialog.CheckFileExists = true;
			dialog.Title = "Parameters File";
			dialog.Filter = "PRM files (*.prm)|*.prm|All files (*.*)|*.*" ;
			GetFileName(dialog);
			m_sParametersFileName = dialog.FileName;
			dialog.Dispose();
		}

		/// <summary>
		/// Sends path data to ANAConverter, and to PositionAnalyzer.
		/// </summary>
		private void Execute_Click(object sender, System.EventArgs e)
		{
			if (m_sANAFileName == null)
			{
				MessageBox.Show ("You must choose an analysis file", "Analysis File", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			try
			{
				m_sConverterPath = m_agc.Process(m_sANAFileName, m_sParametersFileName);
				m_sPositionPath = m_pa.Process(m_sConverterPath, null);
			}
			catch (Exception er)
			{
				MessageBox.Show (er.Message, "Exception",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		/// <summary>
		/// Create Parameter File.
		/// </summary>
		private void CreateParameterFile_Click(object sender, System.EventArgs e)
		{
			string parameters = null;
			EditParameters editDialog = new EditParameters(parameters);
			editDialog.parameters = parameters;
			editDialog.Text = "Create Parameter File";
			if (editDialog.ShowDialog() == DialogResult.OK)
				if (editDialog.parameters != null)
				{
					SaveFileDialog dialog = new SaveFileDialog();
					dialog.Title = "Save Created Parameter File";
					dialog.Filter = "PRM files (*.prm)|*.prm|All files (*.*)|*.*" ;
					dialog.CheckFileExists = false;
					GetFileName(dialog);
                    m_sParametersFileName = dialog.FileName;

					StreamWriter parameterWriter = new StreamWriter(m_sParametersFileName);
					try
					{
						parameters = editDialog.parameters;
						parameterWriter.WriteLine(parameters);
					}
					catch (Exception er)
					{
						MessageBox.Show (er.Message, "Exception",
							MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
					finally
					{
						parameterWriter.Close();
					}
				}
			editDialog.Dispose();
		}

		/// <summary>
		/// Edit Parameter File.
		/// </summary>
		private void EditParameterFile_Click(object sender, System.EventArgs e)
		{
			string parameters = null;
			if (m_sParametersFileName == null)
			{
				OpenFileDialog dialog = new OpenFileDialog();
				dialog.CheckFileExists = true;
				dialog.Filter = "PRM files (*.prm)|*.prm|All files (*.*)|*.*" ;
				GetFileName(dialog);
				m_sParametersFileName = dialog.FileName;
			}
			// Canceled
			if (m_sParametersFileName == null)
				return;

			{
				StreamReader parameterReader = new StreamReader(m_sParametersFileName);
				try 
				{
					parameters = parameterReader.ReadLine();
					if (parameters == null)	//The file is empty.
						throw new FileLoadException("Parameters File is empty", m_sParametersFileName);
				}
				catch (Exception er)
				{
					MessageBox.Show (er.Message, "Exception",
						MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
/*				catch (FileLoadException er)
				{
					MessageBox.Show (er.Message, "File Load Exception",
						MessageBoxButtons.OK, MessageBoxIcon.Error);
				} */
				finally
				{
					parameterReader.Close();
				}
			}

			EditParameters editDialog = new EditParameters(parameters);
			editDialog.Text = "Edit Parameter File";
			if (editDialog.ShowDialog()== DialogResult.OK)
				if (editDialog.parameters != null)
				{
					StreamWriter parameterWriter = new StreamWriter(m_sParametersFileName);
					try
					{
						parameters = editDialog.parameters;
						parameterWriter.WriteLine(parameters);
					}
					catch (Exception er)
					{
						MessageBox.Show (er.Message, "Exception",
							MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
					finally
					{
						parameterWriter.Close();
					}
				}
			editDialog.Dispose();		
		}

		/// <summary>
		/// Close the form.
		/// </summary>
		private void Exit_Click(object sender, System.EventArgs e)
		{
			if (m_sConverterPath != null)
				File.Delete(m_sConverterPath);
			if (m_sPositionPath != null)
				File.Delete(m_sPositionPath);
//			Application.ApplicationExit;
			this.Close();
		}

		/// <summary>
		/// Save As.
		/// </summary>
		private void SaveAs_Click(object sender, System.EventArgs e)
		{
			if (m_sPositionPath == null)
			{
				MessageBox.Show ("No output file - Execute first", "Output File", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			SaveFileDialog saveFileDialog = new SaveFileDialog();
 
			saveFileDialog.InitialDirectory = "c:." ;
			saveFileDialog.Filter = "txt files (*.xml)|*.xml|All files (*.*)|*.*"  ;
			saveFileDialog.FilterIndex = 2 ;
			saveFileDialog.RestoreDirectory = true ;
			saveFileDialog.Title = "Save Xml Output File As ...";
			if(saveFileDialog.ShowDialog() != DialogResult.OK)
			{
				MessageBox.Show ("File Canceled", "Output File", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			else
				File.Copy(m_sPositionPath, saveFileDialog.FileName, true);
		}

		/// <summary>
		/// Open File Dialog box.
		/// </summary>
		private void GetFileName(FileDialog dialog)
		{
			OpenFileDialog openParametersFileDialog = new OpenFileDialog();

			openParametersFileDialog.InitialDirectory = "c:." ;
			openParametersFileDialog.Filter = dialog.Filter;
			openParametersFileDialog.RestoreDirectory = true ;
			openParametersFileDialog.CheckFileExists = dialog.CheckFileExists;
			openParametersFileDialog.CheckPathExists = true;
			openParametersFileDialog.Title = dialog.Title;
			if(openParametersFileDialog.ShowDialog() != DialogResult.OK)
				{
					dialog.FileName = null;
					MessageBox.Show ("File Canceled", openParametersFileDialog.Title, 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}

			dialog.FileName = openParametersFileDialog.FileName;
		}

		/// <summary>
		/// View the processed ANA.
		/// </summary>
		private void ViewFile_Click(object sender, System.EventArgs e)
		{
			Cursor = Cursors.WaitCursor;
			string htmlOutput = null;
			try
			{
				XslTransform trans = new XslTransform();
				trans.Load(Environment.GetEnvironmentVariable("FWROOT")
					+ "\\Src\\WW-GAFAWS\\GAFAWSDataLayer\\XML\\AffixPositionChart.xsl");
				htmlOutput = Path.GetTempFileName() + ".html";
				trans.Transform(m_sPositionPath, htmlOutput);

				Process.Start(htmlOutput);
			}
			catch (Exception er)
			{
				MessageBox.Show (er.Message, "Exception",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				Cursor = Cursors.Default;
			}
		}

	}
}
/*		// Launch associated tool on document.
		string dir = Directory.GetCurrentDirectory();
		string outPath = "file:\\\\" + dir + "\\" + OutputFileName;
		Process.Start(outPath);

		MSXML2.XSLTemplate40Class xslt = new MSXML2.XSLTemplate40Class();
		MSXML2.FreeThreadedDOMDocument40Class xslDoc = new MSXML2.FreeThreadedDOMDocument40Class();
		MSXML2.DOMDocument40Class xmlDoc = new MSXML2.DOMDocument40Class();
		MSXML2.IXSLProcessor xslProc;

		xslDoc.async = false;
		xslDoc.load(Stylesheet);
		xslt.stylesheet = xslDoc;
		xmlDoc.async = false;
		...
		
		xmlDoc.load(sInput);
		xslProc = xslt.createProcessor();
		xslProc.input = xmlDoc;
		xslProc.transform();
		StreamWriter sr = File.CreateText(OutputFileName);
		sr.Write(xslProc.output);
		sr.Close();
		
The easier transform code is:

XslTransform trans = new XslTransform();
trans.Load(Environment.GetEnvironmentVariable("FWROOT")
	+ "\\Src\\WW-GAFAWS\\GAFAWSDataLayer\\XML\\AffixPositionChart.xsl");
htmlOutput = Path.GetTempFileName() + ".html";
trans.Transform(analyzedPathname, htmlOutput);

It avoids using the MSXSL2 code altogether in favor of regular C# code. That was used to make the results look pretty.
Randy Regnier says:
It only replaces part of the other stuff.




		
*/

