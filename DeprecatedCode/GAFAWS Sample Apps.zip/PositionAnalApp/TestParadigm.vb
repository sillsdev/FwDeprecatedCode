Option Strict Off
Option Explicit On
Friend Class Paradigm
    Inherits System.Windows.Forms.Form

    Dim m_sParametersPath As String = "NoPath"
    Dim m_sInputPath As String
    Dim m_sOutputPath As String
	Dim m_fShowResults As Boolean
    Dim m_fPassed As Boolean

#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
    Public WithEvents btnA As System.Windows.Forms.Button
    Friend WithEvents btnA1 As System.Windows.Forms.Button
    Friend WithEvents btnB As System.Windows.Forms.Button
    Friend WithEvents btnC As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ButtonRegTests As System.Windows.Forms.Button
    Friend WithEvents btnA2 As System.Windows.Forms.Button
    Friend WithEvents btnBrowse As System.Windows.Forms.Button
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
		Me.btnA = New System.Windows.Forms.Button()
		Me.btnA1 = New System.Windows.Forms.Button()
		Me.btnB = New System.Windows.Forms.Button()
		Me.btnC = New System.Windows.Forms.Button()
		Me.Button1 = New System.Windows.Forms.Button()
		Me.ButtonRegTests = New System.Windows.Forms.Button()
		Me.btnA2 = New System.Windows.Forms.Button()
		Me.btnBrowse = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'btnA
		'
		Me.btnA.BackColor = System.Drawing.SystemColors.Control
		Me.btnA.Cursor = System.Windows.Forms.Cursors.Default
		Me.btnA.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnA.ForeColor = System.Drawing.SystemColors.ControlText
		Me.btnA.Location = New System.Drawing.Point(40, 16)
		Me.btnA.Name = "btnA"
		Me.btnA.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.btnA.TabIndex = 0
		Me.btnA.Text = "Test A"
		'
		'btnA1
		'
		Me.btnA1.Location = New System.Drawing.Point(40, 56)
		Me.btnA1.Name = "btnA1"
		Me.btnA1.TabIndex = 1
		Me.btnA1.Text = "Test A1"
		'
		'btnB
		'
		Me.btnB.Location = New System.Drawing.Point(136, 16)
		Me.btnB.Name = "btnB"
		Me.btnB.TabIndex = 2
		Me.btnB.Text = "Test B"
		'
		'btnC
		'
		Me.btnC.Location = New System.Drawing.Point(136, 56)
		Me.btnC.Name = "btnC"
		Me.btnC.TabIndex = 3
		Me.btnC.Text = "Test C"
		'
		'Button1
		'
		Me.Button1.Location = New System.Drawing.Point(136, 96)
		Me.Button1.Name = "Button1"
		Me.Button1.TabIndex = 4
		Me.Button1.Text = "HAB1"
		'
		'ButtonRegTests
		'
		Me.ButtonRegTests.Location = New System.Drawing.Point(40, 136)
		Me.ButtonRegTests.Name = "ButtonRegTests"
		Me.ButtonRegTests.Size = New System.Drawing.Size(168, 23)
		Me.ButtonRegTests.TabIndex = 5
		Me.ButtonRegTests.Text = "Regression Tests"
		'
		'btnA2
		'
		Me.btnA2.Location = New System.Drawing.Point(40, 96)
		Me.btnA2.Name = "btnA2"
		Me.btnA2.TabIndex = 6
		Me.btnA2.Text = "Test A2"
		'
		'btnBrowse
		'
		Me.btnBrowse.Location = New System.Drawing.Point(40, 176)
		Me.btnBrowse.Name = "btnBrowse"
		Me.btnBrowse.Size = New System.Drawing.Size(168, 23)
		Me.btnBrowse.TabIndex = 8
		Me.btnBrowse.Text = "I'll find my own file, thank you..."
		'
		'Paradigm
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(256, 214)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnBrowse, Me.btnA2, Me.ButtonRegTests, Me.Button1, Me.btnC, Me.btnB, Me.btnA1, Me.btnA})
		Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Location = New System.Drawing.Point(4, 23)
		Me.Name = "Paradigm"
		Me.Text = "Test GAFAWS Analysis"
		Me.ResumeLayout(False)

	End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As Paradigm
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As Paradigm
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New Paradigm()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region

	Private Sub RunParadigm()
		Dim startDT As DateTime
		Dim endDT As DateTime
		Dim span As TimeSpan
		Dim P As SIL.WordWorks.GAFAWS.PositionAnalysis.PositionAnalyzer
		P = New SIL.WordWorks.GAFAWS.PositionAnalysis.PositionAnalyzer()

		Try
			startDT = DateTime.Now
			m_sOutputPath = P.Process(m_sInputPath, m_sParametersPath)
			endDT = DateTime.Now
		Catch ex As Exception
			m_fShowResults = False
			MsgBox(ex.ToString)
		End Try
		If m_fShowResults Then
			span = endDT.Subtract(startDT)
			MsgBox("Milliseconds to run: " + span.Milliseconds.ToString())
			Dim xslt As MSXML2.XSLTemplate40Class
			Dim xslDoc As MSXML2.FreeThreadedDOMDocument40Class
			Dim xmlDoc As MSXML2.DOMDocument40Class
			Dim xslProc As MSXML2.IXSLProcessor
			Dim sr As System.IO.StreamWriter
			Dim outPath As String
			Dim outPathhtml As String
			Dim stylesheet As String
			Dim fwroot As String

			xslt = New MSXML2.XSLTemplate40Class()
			xslDoc = New MSXML2.FreeThreadedDOMDocument40Class()
			xmlDoc = New MSXML2.DOMDocument40Class()
			fwroot = System.Environment.GetEnvironmentVariable("FWROOT")
			stylesheet = fwroot + "\Src\WW-GAFAWS\GAFAWSDataLayer\XML\AffixPositionChart.xsl"

			xslDoc.async = False
			xslDoc.load(stylesheet)
			xslt.stylesheet = xslDoc
			xmlDoc.async = False
			xmlDoc.load(m_sOutputPath)
			xslProc = xslt.createProcessor()
			xslProc.input = xmlDoc
			xslProc.transform()
			outPath = System.IO.Path.GetTempFileName()
			outPathhtml = outPath + ".html"
			System.IO.File.Copy(outPath, outPathhtml)
			System.IO.File.Delete(outPath)
			sr = System.IO.File.CreateText(outPathhtml)
			sr.Write(xslProc.output)
			sr.Close()

			' Launch associated tool on document.
			Process.Start(outPathhtml)
		End If
		P = Nothing
	End Sub

	Private Sub A_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles btnA.Click
		SetInputPath("testA.xml")
		m_fShowResults = True
		RunParadigm()
	End Sub

	Private Sub A1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnA1.Click
		SetInputPath("testA1.xml")
		m_fShowResults = True
		RunParadigm()
	End Sub

	Private Sub btnA2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnA2.Click
		SetInputPath("testA2.xml")
		m_fShowResults = True
		RunParadigm()
	End Sub

	Private Sub B_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnB.Click
		SetInputPath("testB.xml")
		m_fShowResults = True
		RunParadigm()
	End Sub

	Private Sub C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnC.Click
		SetInputPath("testC.xml")
		m_fShowResults = True
		RunParadigm()
	End Sub

	Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
		SetInputPath("hab1.xml")
		m_fShowResults = True
		RunParadigm()
	End Sub

	Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
		Dim openFileDialog1 As New OpenFileDialog()
		openFileDialog1.Filter = "GAFAWS data Files|*.xml"
		openFileDialog1.Title = "Select a GAFAWS Data File"

		' Show the Dialog.
		If openFileDialog1.ShowDialog() = DialogResult.OK Then
			If openFileDialog1.FileName <> "" Then
				m_sInputPath = openFileDialog1.FileName
				m_fShowResults = True
				RunParadigm()
			End If
		End If
	End Sub

	Private Sub ButtonRegTests_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonRegTests.Click
		m_fShowResults = False
		m_fPassed = True

		SetInputPath("testA.xml")
		RunParadigm()
		CheckEquality()

		SetInputPath("testA1.xml")
		RunParadigm()
		CheckEquality()

		SetInputPath("testA2.xml")
		RunParadigm()
		CheckEquality()

		SetInputPath("testB.xml")
		RunParadigm()
		CheckEquality()

		SetInputPath("testC.xml")
		RunParadigm()
		CheckEquality()

		SetInputPath("hab1.xml")
		RunParadigm()
		CheckEquality()

		m_fShowResults = True
		If m_fPassed Then
			MessageBox.Show("Passed regression tests.")
		Else
			MessageBox.Show("Flunked regression tests.")
		End If
	End Sub

	Private Sub SetInputPath(ByVal sFilename As String)
		m_sInputPath = Environment.GetEnvironmentVariable("FWRoot") + _
		 "\\Src\\WW-GAFAWS\\GAFAWSDataLayer\\XML\\" + sFilename
	End Sub


	Private Sub CheckEquality()
		Dim sr As System.IO.StreamReader
		Dim sRTfile As String
		Dim sRTData As String
		Dim sNewData As String
		Dim sMsg As String
		Dim sJunk As String
		Dim fi As System.IO.FileInfo

		sr = System.IO.File.OpenText(m_sOutputPath)
		' Skip first three lines, since date and time will not match.
		sJunk = sr.ReadLine()
		sJunk = sr.ReadLine()
		sJunk = sr.ReadLine()
		sNewData = sr.ReadToEnd()
		sr.Close()
		fi = New System.IO.FileInfo(m_sOutputPath)
		sRTfile = fi.DirectoryName + "\RT-" + fi.Name
		sr = System.IO.File.OpenText(sRTfile)
		' Skip first three lines, since date and time will not match.
		sJunk = sr.ReadLine()
		sJunk = sr.ReadLine()
		sJunk = sr.ReadLine()
		sRTData = sr.ReadToEnd()
		sr.Close()

		If Not sRTData = sNewData Then
			sMsg = m_sOutputPath + " is not the same."
			MessageBox.Show(sMsg)
			m_fPassed = False
		End If

	End Sub
End Class