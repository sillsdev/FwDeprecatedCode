This project is a C# console application to create a proof of concept that embedded MySQL can be used with C#.

I made it to the point where I was setting up the struct my_charset_handler_st in MyEmbeddedTest.cs. my_charset_handler_st sets up pointers to methods.  Damien advised that this is doable, but would take a great deal of work and expertise. So I am again abandoning this project. We can return to it if we need to. Perhaps by then someone will have an embedded version of Connector .NET available.

If you pick up this project, you will need MySQL's library libmySQL.dll. The solution/project expects it to be in the same directory currently. I removed it form here in the interest of space, as well as the bin, obj, and _ReSharper.MySqlEmbeddedTest subdirectories.

--Steve Miller
