﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

// for class LibMySQLWrapper
using System.Security;
using System.Runtime.InteropServices;
using MySqlEmbeddedTest;

namespace MySqlEmbeddedTest
{
	public sealed class LibMySQLWrapper
	{
		// See http://forums.mysql.com/read.php?38,67281,67917 for examples.
		// See http://lists.mysql.com/dotnet/1092 for other examples.

		// According to the MySQL doc, we're supposed to use mysql_library_init,
		// but that method isn't exported. However, in the mysql.h file, there is this:
		// #define mysql_library_init mysql_server_init
		[SuppressUnmanagedCodeSecurity]
		[DllImport("libmySQL.dll")]
		public static extern int mysql_server_init(
			int parameters, string[] serverOptions, string[] groups);

		// According to the MySQL doc, we're supposed to use mysql_library_end,
		// but that method isn't exported. However, in the mysql.h file, there is this:
		// #define mysql_library_end mysql_server_end
		[SuppressUnmanagedCodeSecurity]
		[DllImport("libmySQL.dll")]
		public static extern void mysql_server_end();

		[SuppressUnmanagedCodeSecurity]
		[DllImport("libmySQL.dll")]
		public static extern IntPtr mysql_init(IntPtr pMySQL);

		[SuppressUnmanagedCodeSecurity]
		[DllImport("libmySQL.dll")]
		public static extern void mysql_close(IntPtr pMySQL);

		[SuppressUnmanagedCodeSecurity]
		[DllImport("libmySQL.dll")]
		public static extern void mysql_options(
			IntPtr pMySQL, mysqlOptions MySqlOpt, string Dummy);

		[SuppressUnmanagedCodeSecurity]
		[DllImport("libmySQL.dll")]
		public static extern void mysql_real_connect(
			IntPtr pMySQL, string Host, string User, string Password, string Database,
			uint Port, string UnixSocket, ulong ClientFlag);

		[SuppressUnmanagedCodeSecurity]
		[DllImport("libmySQL.dll")]
		public static extern void mysql_query(IntPtr pMySQL, string query);

		[SuppressUnmanagedCodeSecurity]
		[DllImport("libmySQL.dll")]
		public static extern MYSQL_RES mysql_store_result(IntPtr pMySQL);

		//[SuppressUnmanagedCodeSecurity]
		//[DllImport("libmySQL.dll")]
		// TODO This needs to be fleshed out with a MYSQL_RES parameter
		//public static extern void mysql_free_result();
	}

	// For use with MySQL C API mysql_options 
	public enum mysqlOptions
	{
		MYSQL_OPT_CONNECT_TIMEOUT, MYSQL_OPT_COMPRESS, MYSQL_OPT_NAMED_PIPE,
		MYSQL_INIT_COMMAND, MYSQL_READ_DEFAULT_FILE, MYSQL_READ_DEFAULT_GROUP,
		MYSQL_SET_CHARSET_DIR, MYSQL_SET_CHARSET_NAME, MYSQL_OPT_LOCAL_INFILE,
		MYSQL_OPT_PROTOCOL, MYSQL_SHARED_MEMORY_BASE_NAME, MYSQL_OPT_READ_TIMEOUT,
		MYSQL_OPT_WRITE_TIMEOUT, MYSQL_OPT_USE_RESULT,
		MYSQL_OPT_USE_REMOTE_CONNECTION, MYSQL_OPT_USE_EMBEDDED_CONNECTION,
		MYSQL_OPT_GUESS_CONNECTION, MYSQL_SET_CLIENT_IP, MYSQL_SECURE_AUTH,
		MYSQL_REPORT_DATA_TRUNCATION, MYSQL_OPT_RECONNECT,
		MYSQL_OPT_SSL_VERIFY_SERVER_CERT
	}

	// Ported from mysql.h
	public struct MYSQL_RES
	{
		public UInt64 row_count;
	    public MYSQL_FIELD fields;
		public MYSQL_DATA data;
		public MYSQL_ROWS datacursor;
		public ulong lengths;
		//public MYSQL handle;
	} 

	// Ported from mysql.h
	public struct MYSQL_FIELD
	{
		public string name;        /* Name of column */
		public string org_name;    /* Original column name, if an alias */
		public string table;       /* Table of column if column was a field */
		public string org_table;   /* Org table name, if table was an alias */
		public string db;          /* Database for table */
		public string catalog;		/* Catalog for table */
		public string def;         /* Default value (set by mysql_list_fields) */
		public ulong length;       /* Width of column (create length) */
		public ulong max_length;   /* Max width for selected set */
		public uint name_length;
		public uint org_name_length;
		public uint table_length;
		public uint org_table_length;
		public uint db_length;
		public uint catalog_length;
		public uint def_length;
		public uint flags;         /* Div flags */
		public uint decimals;      /* Number of decimals in field */
		public uint charsetnr;     /* Character set */
		public enum_field_types type; /* Type of field. See mysql_com.h for types */  //enum enum_field_types type;
		public string extension; // void *extension;
	}

	// ported from mysql_com.h
	public enum enum_field_types { MYSQL_TYPE_DECIMAL, MYSQL_TYPE_TINY,
			MYSQL_TYPE_SHORT,  MYSQL_TYPE_LONG,
			MYSQL_TYPE_FLOAT,  MYSQL_TYPE_DOUBLE,
			MYSQL_TYPE_NULL,   MYSQL_TYPE_TIMESTAMP,
			MYSQL_TYPE_LONGLONG,MYSQL_TYPE_INT24,
			MYSQL_TYPE_DATE,   MYSQL_TYPE_TIME,
			MYSQL_TYPE_DATETIME, MYSQL_TYPE_YEAR,
			MYSQL_TYPE_NEWDATE, MYSQL_TYPE_VARCHAR,
			MYSQL_TYPE_BIT, 
			MYSQL_TYPE_NEWDECIMAL=246,
			MYSQL_TYPE_ENUM=247,
			MYSQL_TYPE_SET=248,
			MYSQL_TYPE_TINY_BLOB=249,
			MYSQL_TYPE_MEDIUM_BLOB=250,
			MYSQL_TYPE_LONG_BLOB=251,
			MYSQL_TYPE_BLOB=252,
			MYSQL_TYPE_VAR_STRING=253,
			MYSQL_TYPE_STRING=254,
			MYSQL_TYPE_GEOMETRY=255
	};

	// ported from mysql.h
	public class MYSQL_DATA
	{
		public MYSQL_ROWS data;
		public MYSQL_DATA embedded_info;
		public MEM_ROOT alloc;
		public UInt64 rows;
		public uint fields;
		/* extra info for embedded library */
		public object extension;
	}

	// ported from mysql.h
	public class MYSQL_ROWS
	{
		public MYSQL_ROWS next;
		public string[] data; // typedef char **MYSQL_ROW;	/* return data as array of strings */
		public ulong length;
	}

	// ported from mysql.h
	public struct MEM_ROOT
	{
		public USED_MEM free;                  /* blocks with free memory in it */
		public USED_MEM used;                  /* blocks almost without free memory */
		public USED_MEM pre_alloc;             /* preallocated block */
		/* if block have less memory it will be put in 'used' list */
			// size_t should be mapped via IntPtr. See:
			// http://bytes.com/topic/c-sharp/answers/458667-interop-size_t
		public IntPtr min_malloc; // size_t min_malloc;
		public IntPtr block_size; // size_t block_size;     /* initial block size */
		public uint block_num;          /* allocated blocks counter */
		/* 
		 first free block in queue test counter (if it exceed 
		 MAX_BLOCK_USAGE_BEFORE_DROP block will be dropped in 'used' list)
		*/
		public uint first_block_usage;
		public object error_handler; //void (*error_handler)(void);
	}

	// ported from mysql.h
	public class USED_MEM
	{
		public USED_MEM next;	   /* Next block in use */
		public uint	left;		   /* memory left in block  */
		public uint	size;		   /* size of block */
	}

	public struct MYSQL
	{
		public NET net;			/* Communication parameters */
		//unsigned char	*connector_fd;
		public byte[] connector_fd; 		/* ConnectorFd for SSL */
		//char		*host,*user,*passwd,*unix_socket,*server_version,*host_info;
		public string host;
		public string user;
		public string passwd;
		public string unix_socket;
		public string server_version;
		public string host_info;
		public string info;
		public string db;
		//struct charset_info_st charset;
		//MYSQL_FIELD	*fields;
		//MEM_ROOT	field_alloc;
		//my_ulonglong affected_rows;
		//my_ulonglong insert_id;		/* id if insert on table with NEXTNR */
		//my_ulonglong extra_info;		/* Not used */
		//unsigned long thread_id;		/* Id for connection in server */
		//unsigned long packet_length;
		//unsigned int	port;
		//unsigned long client_flag,server_capabilities;
		//unsigned int	protocol_version;
		//unsigned int	field_count;
		//unsigned int 	server_status;
		//unsigned int  server_language;
		//unsigned int	warning_count;
		//struct st_mysql_options options;
		//enum mysql_status status;
		//my_bool	free_me;		/* If free in mysql_close */
		//my_bool	reconnect;		/* set to 1 if automatic reconnect */

		///* session-wide random string */
		//char	        scramble[SCRAMBLE_LENGTH+1];

		///*
		//Set if this is the original connection, not a master or a slave we have
		//added though mysql_rpl_probe() or mysql_set_master()/ mysql_add_slave()
		//*/
		//my_bool rpl_pivot;
		///*
		//Pointers to the master, and the next slave connections, points to
		//itself if lone connection.
		//*/
		//struct st_mysql* master, *next_slave;

		//struct st_mysql* last_used_slave; /* needed for round-robin slave pick */
		///* needed for send/read/store/use result to work correctly with replication */
		//struct st_mysql* last_used_con;

		//LIST  *stmts;                     /* list of all statements */
		//const struct st_mysql_methods *methods;
		//void *thd;
		///*
		//Points to boolean flag in MYSQL_RES  or MYSQL_STMT. We set this flag 
		//from mysql_stmt_close if close had to cancel result set of this object.
		//*/
		//my_bool *unbuffered_fetch_owner;
		///* needed for embedded server - no net buffer to store the 'info' */
		//char *info_buffer;
		//void *extension;
	}

	public struct NET {
		// CHECK_EMBEDDED_DIFFERENCES nor EMBEDDED_LIBRARY was found to be defined.
		//#if !defined(CHECK_EMBEDDED_DIFFERENCES) || !defined(EMBEDDED_LIBRARY)
		//Vio *vio;
		//unsigned char *buff,*buff_end,*write_pos,*read_pos;
		//my_socket fd;					/* For Perl DBI/dbd */
		///*
		//The following variable is set if we are doing several queries in one
		//command ( as in LOAD TABLE ... FROM MASTER ),
		//and do not want to confuse the client with OK at the wrong time
		//*/
		//unsigned long remain_in_buf,length, buf_length, where_b;
		//unsigned long max_packet,max_packet_size;
		//unsigned int pkt_nr,compress_pkt_nr;
		//unsigned int write_timeout, read_timeout, retry_count;
		//int fcntl;
		//unsigned int *return_status;
		//unsigned char reading_or_writing;
		//char save_char;
		//my_bool unused0; /* Please remove with the next incompatible ABI change. */
		//my_bool unused; /* Please remove with the next incompatible ABI change */
		//my_bool compress;
		//my_bool unused1; /* Please remove with the next incompatible ABI change. */
		///*
		//Pointer to query object in query cache, do not equal NULL (0) for
		//queries in cache that have not stored its results yet
		//*/
		//#endif
		/*
		'query_cache_query' should be accessed only via query cache
		functions and methods to maintain proper locking.
		*/
		public byte[] query_cache_query; //unsigned char *query_cache_query;
		public uint last_errno;
		public byte error;  //unsigned char error; 
		public char unused2; // my_bool unused2; /* Please remove with the next incompatible ABI change. */
		public char return_errno; // my_bool return_errno;
		/** Client library error message buffer. Actually belongs to struct MYSQL. */
		public string lasterror; // char last_error[MYSQL_ERRMSG_SIZE];
		/** Client library sqlstate buffer. Set along with the error message. */
		public string sqlstate; // char sqlstate[SQLSTATE_LENGTH+1];
		public object extension; // void *extension;
	}

	// ported from m_ctype.h
	public struct charset_info_st
	{
		public uint      number;
		public uint      primary_number;
		public uint      binary_number;
		public uint      state;
		public string csname; // const char *csname;
		public string name; // const char *name;
		public string comment; // const char *comment;
		public string tailoring; // const char *tailoring;
		public byte[]  ctype;
		public byte[] to_lower;
		public byte[] to_upper;
		public byte[] sort_order;
		public UInt16[] contractions;
		public UInt16[][]   sort_order_big;
		public UInt16      tab_to_uni;
		MY_UNI_IDX  tab_from_uni;
		MY_UNICASE_INFO[][] caseinfo;
		public byte[] state_map;
		public byte[] ident_map;
		public uint strxfrm_multiply;
		public byte[] caseup_multiply;
		public byte[] casedn_multiply;
		public uint      mbminlen;
		public uint      mbmaxlen;
		public UInt16    min_sort_char;
		public UInt16 max_sort_char; /* For LIKE optimization */
		public byte[] pad_char;
		public string   escape_with_backslash_is_dangerous;
		MY_CHARSET_HANDLER *cset;
		MY_COLLATION_HANDLER *coll;
	}

	public struct MY_UNI_IDX
	{
		UInt16 from;
		UInt16 to;
		byte[] tab;
	}

	public struct MY_UNICASE_INFO
	{
		UInt16 toupper;
		UInt16 tolower;
		UInt16 sort;
	}

	// NOTE: This is where I, Steve Miller, met my demise by dragon. Farewell. May
	// you fare better than I, intrepid traveler.

	typedef struct my_charset_handler_st
	{
		my_bool (*init)(struct charset_info_st *, void *(*alloc)(size_t));
		/* Multibyte routines */
		uint    (*ismbchar)(struct charset_info_st *, const char *, const char *);
		uint    (*mbcharlen)(struct charset_info_st *, uint c);
		size_t  (*numchars)(struct charset_info_st *, const char *b, const char *e);
		size_t  (*charpos)(struct charset_info_st *, const char *b, const char *e,
						 size_t pos);
		size_t  (*well_formed_len)(struct charset_info_st *,
								 const char *b,const char *e,
								 size_t nchars, int *error);
		size_t  (*lengthsp)(struct charset_info_st *, const char *ptr, size_t length);
		size_t  (*numcells)(struct charset_info_st *, const char *b, const char *e);

		/* Unicode conversion */
		my_charset_conv_mb_wc mb_wc;
		my_charset_conv_wc_mb wc_mb;

		/* CTYPE scanner */
		int (*ctype)(struct charset_info_st *cs, int *ctype,
				   const uchar *s, const uchar *e);

		/* Functions for case and sort conversion */
		size_t  (*caseup_str)(struct charset_info_st *, char *);
		size_t  (*casedn_str)(struct charset_info_st *, char *);

		my_charset_conv_case caseup;
		my_charset_conv_case casedn;

		/* Charset dependant snprintf() */
		size_t (*snprintf)(struct charset_info_st *, char *to, size_t n,
						 const char *fmt,
						 ...) ATTRIBUTE_FORMAT_FPTR(printf, 4, 5);
		size_t (*long10_to_str)(struct charset_info_st *, char *to, size_t n,
							  int radix, long int val);
		size_t (*longlong10_to_str)(struct charset_info_st *, char *to, size_t n,
								  int radix, longlong val);

		void (*fill)(struct charset_info_st *, char *to, size_t len, int fill);

		/* String-to-number conversion routines */
		long        (*strntol)(struct charset_info_st *, const char *s, size_t l,
				 int base, char **e, int *err);
		ulong      (*strntoul)(struct charset_info_st *, const char *s, size_t l,
				 int base, char **e, int *err);
		longlong   (*strntoll)(struct charset_info_st *, const char *s, size_t l,
				 int base, char **e, int *err);
		ulonglong (*strntoull)(struct charset_info_st *, const char *s, size_t l,
				 int base, char **e, int *err);
		double      (*strntod)(struct charset_info_st *, char *s, size_t l, char **e,
				 int *err);
		longlong    (*strtoll10)(struct charset_info_st *cs,
							   const char *nptr, char **endptr, int *error);
		ulonglong   (*strntoull10rnd)(struct charset_info_st *cs,
									const char *str, size_t length,
									int unsigned_fl,
									char **endptr, int *error);
		size_t        (*scan)(struct charset_info_st *, const char *b, const char *e,
							int sq);
		} MY_CHARSET_HANDLER;
}

class GetUserServer
{
	static void Main(string[] args)
	{
		StartMySqlLib();
		var MySqlPtr = InitMySql();
		UseEmbeddedMySql(MySqlPtr);
		ConnectToMySql(MySqlPtr, "localhost", "root", "inscrutable", "mysql");



		StopMySql(MySqlPtr);
	}

	/// <summary>
	/// Start up the MySQL library.
	/// </summary>
	internal static void StartMySqlLib()
	{
		var serverOptions = new string[4];
		serverOptions[0] = "mysql_test";
		serverOptions[1] = "--datadir=C:/Documents and Settings/All Users/Application Data/MySQL/MySQL Server 5.1/data";
		serverOptions[2] = "--language=C:/Program Files/MySQL/MySQL Server 5.1/share/english";
		serverOptions[3] = null;

		var parameters = serverOptions.Count();

		var groups = new string[2];
		groups[0] = "libmysqld_server";
		groups[1] = null;

		try
		{
			LibMySQLWrapper.mysql_server_init(
				parameters, serverOptions, groups);
		}
		catch (Exception e)
		{
			Console.WriteLine(e.ToString());
			LibMySQLWrapper.mysql_server_end();
		}
	}

	/// Initialize MySQL
	/// </summary>
	/// <returns></returns>
	internal static IntPtr InitMySql ()
	{
		var MySqlPtr = IntPtr.Zero;
		try
		{
			MySqlPtr = LibMySQLWrapper.mysql_init(IntPtr.Zero);
			Debug.Assert(MySqlPtr != IntPtr.Zero);
			return MySqlPtr;
		}
		catch (Exception e)
		{
			Console.WriteLine(e.ToString());
		}
		return MySqlPtr;
	}

	/// <summary>
	/// Spin up the embedded version of MySQL
	/// </summary>
	/// <returns></returns>
	internal static void UseEmbeddedMySql(IntPtr pMySQL)
	{
		LibMySQLWrapper.mysql_options(
			pMySQL, mysqlOptions.MYSQL_OPT_USE_EMBEDDED_CONNECTION, null);
	}

	/// <summary>
	/// Connect to the MySQL Database
	/// </summary>
	internal static void ConnectToMySql(IntPtr pMySQL, string HostName,
		string User, string Password, string Database)
	{
		// TODO: This should have some defaults for null parameters.
		LibMySQLWrapper.mysql_real_connect(pMySQL, HostName, User, Password, Database,
			0, null, 0);
	}

	/// <summary>
	/// Loads the query string
	/// </summary>
	/// <param name="MySqlPtr"></param>
	/// <param name="Query"></param>
	internal static void QueryMySql (IntPtr MySqlPtr, string Query)
	{
		LibMySQLWrapper.mysql_query(MySqlPtr, Query);
		LibMySQLWrapper.mysql_store_result(MySqlPtr);
	}

	/// <summary>
	/// Shut down MySQL
	/// </summary>
	/// <param name="MySqlPtr"></param>
	internal static void StopMySql (IntPtr MySqlPtr)
	{
		LibMySQLWrapper.mysql_close(MySqlPtr);
		LibMySQLWrapper.mysql_server_end();
	}
}
