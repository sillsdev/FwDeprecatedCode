﻿namespace SIL.FieldWorks.FDO.Infrastructure
{
	/// <summary>
	/// Domain to have bulk loaded by the backend provider
	/// </summary>
	public enum BackendBulkLoadDomain
	{
		/// <summary>WFI and WfiWordforms</summary>
		WFI,
		/// <summary>Lexicon and entries.</summary>
		Lexicon,
		/// <summary>Texts and their paragraphs (no twfics or wordforms)</summary>
		Text,
		/// <summary></summary>
		Scripture,
		/// <summary>Load everything.</summary>
		All,
		/// <summary>Strictly 'on demand' loading</summary>
		None
	}

	/// <summary>
	/// Supported backend data providers.
	/// </summary>
	public enum FDOBackendProviderType
	{
		/// <summary>
		/// An in-process Firebird database.
		/// </summary>
		/// <remarks>FirebirdBackendProvider</remarks>
		kFirebird = 1,

		/// <summary>
		/// An XML file in some currently unspecified format.
		/// </summary>
		/// <remarks>XMLBackendProvider</remarks>
		kXML = 2,

		/// <summary>
		/// A DB4o object database.
		/// </summary>
		/// <remarks>DB4oBackendProvider</remarks>
		kDb4o = 3,

		/// <summary>
		/// A BerkeleyDB database.
		/// </summary>
		/// <remarks>BerkeleyDBBackendProvider</remarks>
		kBerkeleyDB = 4,

		/// <summary>
		/// A mostly 'do nothing' backend.
		/// This backend is used where there is no actual backend data store on the hard drive.
		/// This could be used for tests, for instance, that create all FDO test data themselves.
		/// </summary>
		/// <remarks>MemoryOnlyBackendProvider</remarks>
		kMemoryOnly = 5,

		/// <summary>
		/// An embedded MySQL database.
		/// </summary>
		/// <remarks>MySqlBackendProvider</remarks>
		kMySQL = 6
	};

	/// <summary>
	/// Enumeration of types or main obejct properties.
	/// </summary>
	internal enum ObjectPropertyType
	{
		Owning,
		Reference
	}
}