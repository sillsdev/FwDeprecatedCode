// --------------------------------------------------------------------------------------------
// Copyright (C) 2008 SIL International. All rights reserved.
// 
// Distributable under the terms of either the Common Public License or the
// GNU Lesser General Public License, as specified in the LICENSING.txt file.
// 
// File: MySqlBackendProvider.cs
// Responsibility: Randy Regnier, Steve Miller
// Last reviewed: never
// --------------------------------------------------------------------------------------------

//TODO: MySQL is released under the GNU license. Someone needs to think about legalities if 
//we use this, because I (Steve) certainly don't.

using System;
using System.Collections.Generic;
using System.IO; // Path & File
using System.Data; // CommandType
using MySql.Data.MySqlClient;
//using MySql.Data.Types;
using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.FDO.Infrastructure.PersistenceImpl
{
	/// <summary>
	/// A subclass of the FDOBackendProvider
	/// which handles an embedded MySQL database.
	/// </summary>
	internal sealed class MySqlBackendProvider : FDOBackendProvider
	{
		private MySqlConnection m_con;
		private uint m_dbid = 1;
		private readonly Dictionary<Guid, uint> m_guid2dbid = new Dictionary<Guid, uint>();
		private uint m_custFieldDbid = 1;
		private readonly Dictionary<string, uint> m_guid2custFieldDBid = new Dictionary<string, uint>();

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="cache"></param>
		/// <param name="identityMap"></param>
		/// <param name="mdc"></param>
		internal MySqlBackendProvider(FdoCache cache, IdentityMap identityMap, IFwMetaDataCacheManagedInternal mdc)
			: base(cache, identityMap, mdc)
		{
		}

		#region IFWDisposable implementation

		/// <summary>
		/// Executes in two distinct scenarios.
		/// 
		/// 1. If disposing is true, the method has been called directly
		/// or indirectly by a user's code via the Dispose method.
		/// Both managed and unmanaged resources can be disposed.
		/// 
		/// 2. If disposing is false, the method has been called by the 
		/// runtime from inside the finalizer and you should not reference (access) 
		/// other managed objects, as they already have been garbage collected.
		/// Only unmanaged resources can be disposed.
		/// </summary>
		/// <param name="disposing"></param>
		/// <remarks>
		/// If any exceptions are thrown, that is fine.
		/// If the method is being done in a finalizer, it will be ignored.
		/// If it is thrown by client code calling Dispose,
		/// it needs to be handled by fixing the bug.
		/// 
		/// If subclasses override this method, they should call the base implementation.
		/// </remarks>
		protected override void Dispose(bool disposing)
		{
			// Can be called more than once,
			// but only do things the first time.
			if (IsDisposed)
				return;

			if (disposing)
			{
				if (m_con != null)
					m_con.Close();
			}

			// Dispose unmanaged resources here, whether disposing is true or false.

			// Set all member variables to null.
			m_con = null;

			base.Dispose(disposing);
		}

		#endregion IFWDisposable implementation

		/// <summary>
		/// Start the BEP.
		/// </summary>
		/// <param name="backendProviderOptions"></param>
		/// <returns></returns>
		protected override void StartupInternal(object[] backendProviderOptions)
		{
			var csb = BasicInit(backendProviderOptions);

			if (!File.Exists(csb.Database))
				throw new InvalidOperationException("File does not exist.");

			m_con = new MySqlConnection(csb.ToString());
			m_con.Open();

			// Get data from MAIN.
			using (var cmd = m_con.CreateCommand())
			{
				cmd.CommandType = CommandType.Text;
				// Get custom fields
				cmd.CommandText = "SELECT * FROM CUSTOMFIELD";
				using (var dataReader = cmd.ExecuteReader())
				{
					var customFields = new List<CustomFieldInfo>();
					while (dataReader.Read())
					{
						var custFieldDbid = (uint)dataReader.GetInt32(0);
						if (m_custFieldDbid < custFieldDbid)
							m_custFieldDbid = custFieldDbid;
						m_custFieldDbid++;

						var cfi = new CustomFieldInfo
			          	{
			          		m_classname = dataReader.GetString(1),
			          		m_fieldname = dataReader.GetString(2),
			          		m_fieldType = GetFlidTypeFromString(dataReader.GetString(3))
			          	};
						customFields.Add(cfi);

						// Add to map.
						m_guid2custFieldDBid[cfi.m_classname + "^" + cfi.m_fieldname] = custFieldDbid;
					}
					if (customFields.Count > 0)
						m_mdcInternal.AddCustomFields(customFields);
				}

				cmd.CommandText = "SELECT * FROM MAIN";
				using (var dataReader = cmd.ExecuteReader())
				{
					while (dataReader.Read())
					{
						var dbid = (uint)dataReader.GetInt32(0);
						if (m_dbid < dbid)
							m_dbid = dbid;
						m_dbid++;

						var surrogate = CmObjectSurrogate.CreateFromDataStoreInternal(
							m_cache,
							dataReader.GetString(1));
						RegisterInactiveSurrogate(surrogate);

						// Add to map (this class only).
						m_guid2dbid[surrogate.Guid] = dbid;
					}
				}
			}
		}

		private MySqlConnectionStringBuilder BasicInit(object[] backendProviderOptions)
		{
			var csb = new MySqlConnectionStringBuilder
			          	{
							Server = "localhost",
			          		Database = (string)backendProviderOptions[0],
			          		UserID = "root",
			          		Password = ""
			          	};
			DatabaseName = Path.GetFileName(csb.Database);
			return csb;
		}

		/// <summary>
		/// Create a LangProject with the BEP.
		/// </summary>
		/// <param name="backendProviderOptions"></param>
		protected override void CreateInternal(object[] backendProviderOptions)
		{
			var csb = BasicInit(backendProviderOptions);
			
			if (File.Exists(csb.Database))
				throw new InvalidOperationException("File already exists.");

			m_con = new MySqlConnection(csb.ToString());
			m_con.Open();

			// Create a brand new DB and the table.
			using (var trans = m_con.BeginTransaction())
			{
				using (var cmd = m_con.CreateCommand())
				{
					cmd.Transaction = trans;
					try
					{
						cmd.CommandType = CommandType.Text;
						cmd.CommandText = "CREATE DATABASE" + csb;
						cmd.ExecuteNonQuery();
						cmd.CommandText = "CREATE TABLE IF NOT EXISTS MAIN (" + 
						                  "ID INTEGER NOT NULL PRIMARY KEY, " + 
										  "XMLDATA BLOB)";
						// We may end up needing to use character set UCS2 for the VARCHARS
						cmd.CommandText = "CREATE TABLE IF NOT EXISTS CUSTOMFIELD (" + 
							"ID INTEGER NOT NULL PRIMARY KEY," +
						    "CLASSNAME VARCHAR(50) CHARACTER SET utf8," +
							"FIELDNAME VARCHAR(50) CHARACTER SET utf8," +
							"FIELDTYPE VARCHAR(50) CHARACTER SET utf8)";
						cmd.ExecuteNonQuery();
						trans.Commit();
					}
					catch (Exception)
					{
						trans.Rollback();
						throw;
					}
				}
			}
		}

		#region IDataStorer implementation

		/// <summary>
		/// Update the backend store.
		/// </summary>
		/// <param name="newbies">The newly created objects</param>
		/// <param name="dirtballs">The recently modified objects</param>
		/// <param name="goners">The recently deleted objects</param>
		public override bool Commit(
			Set<CmObjectSurrogate> newbies, Set<CmObjectSurrogate> dirtballs,
			Set<CmObjectSurrogate> goners)
		{
			var cfiList = m_mdcInternal.GetCustomFields();
			if (newbies.Count == 0 && dirtballs.Count == 0 && goners.Count == 0 && cfiList.Count == 0)
				return true; // Nothing to do.

			EnsureItemsInOnlyOneSet(newbies, dirtballs, goners);
			
			MySqlTransaction trans = null;
			try
			{
				if (m_con.State == ConnectionState.Closed)
					m_con.Open();

				trans = m_con.BeginTransaction();
				using (var cmd = m_con.CreateCommand())
				{
					cmd.Transaction = trans;
					cmd.CommandType = CommandType.Text;

					// Add new custom fields
					cmd.CommandText = "INSERT INTO CUSTOMFIELD (ID, CLASSNAME, FIELDNAME, FIELDTYPE) VALUES (?, ?, ?, ?)";
					var pId = cmd.Parameters.Add("@ID", MySqlDbType.Int32);
					var pClassName = cmd.Parameters.Add("@CLASSNAME", MySqlDbType.VarChar);
					var pFieldName = cmd.Parameters.Add("@FIELDNAME", MySqlDbType.VarChar);
					var pFieldType = cmd.Parameters.Add("@FIELDTYPE", MySqlDbType.VarChar);
					foreach (var cfi in cfiList)
					{
						var cfiKey = cfi.m_classname + "^" + cfi.m_fieldname;
						if (!m_guid2custFieldDBid.ContainsKey(cfiKey))
						{
							pId.Value = m_custFieldDbid;
							pClassName.Value = cfi.m_classname;
							pFieldName.Value = cfi.m_fieldname;
							pFieldType.Value = GetFlidTypeAsString(cfi.m_fieldType);
							cmd.ExecuteNonQuery();

							// Add to map.
							m_guid2custFieldDBid[cfiKey] = m_custFieldDbid++;
						}
					}

					// Handle insertions.
					cmd.Parameters.Clear();
					pId = cmd.Parameters.Add("@ID", MySqlDbType.Int32);
					var pXml = cmd.Parameters.Add("@XMLDATA", MySqlDbType.Text);
					cmd.CommandText = "INSERT INTO MAIN (ID, XMLDATA) VALUES (?, ?)";
					foreach (var newby in newbies)
					{
						pId.Value = m_dbid;
						pXml.Value = newby.XML;
						cmd.ExecuteNonQuery();
			
						// Add to map (for this class only).
						m_guid2dbid[newby.Guid] = m_dbid++;
					}

					// Handle update.
					cmd.Parameters.Clear();
					pXml = cmd.Parameters.Add("@XMLDATA", MySqlDbType.Text);
					pId = cmd.Parameters.Add("@ID", MySqlDbType.Int32);
					cmd.CommandText = "UPDATE MAIN SET XMLDATA = ? WHERE ID = ?";
					foreach (var dirtball in dirtballs)
					{
						pId.Value = m_guid2dbid[dirtball.Guid];
						pXml.Value = dirtball.XML;
						cmd.ExecuteNonQuery();
					}

					// Handle deletions.
					cmd.Parameters.Clear();
					pId = cmd.Parameters.Add("@ID", MySqlDbType.Int32);
					cmd.CommandText = "DELETE FROM MAIN WHERE ID = ?";
					foreach (var goner in goners)
					{
						var dbid = m_guid2dbid[goner.Guid];
						pId.Value = dbid;
						cmd.ExecuteNonQuery();

						// Remove from map (this class only).
						m_guid2dbid.Remove(goner.Guid);
					}

					trans.Commit();
					trans.Dispose();
				}
			}
			catch  (Exception)
			{
				if (trans != null)
				{
					trans.Rollback();
					trans.Dispose();
				}
				throw;
			}

			return base.Commit(newbies, dirtballs, goners);
		}

		#endregion IDataStorer implementation
	}
}