//#define USECSHARPWSF
using System;
using System.Collections.Generic;
using Microsoft.Practices.ServiceLocation;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.FwUtils;
using SIL.FieldWorks.FDO.Infrastructure;
using SIL.FieldWorks.FDO.Infrastructure.PersistenceImpl;

namespace SIL.FieldWorks.FDO.DomainImpl
{
	/// <summary>
	/// Factory for hard-wired FDO Common Service Locator.
	/// </summary>
	internal sealed partial class FdoServiceLocatorFactory : IServiceLocatorBootstrapper
	{
		private readonly FDOBackendProviderType m_backendProviderType;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="backendProviderType"></param>
		public FdoServiceLocatorFactory(FDOBackendProviderType backendProviderType)
		{
			m_backendProviderType = backendProviderType;
		}

		#region Implementation of IServiceLocatorBootstrapper

		/// <summary>
		/// Create an IServiceLocator instance.
		/// </summary>
		/// <returns>An IServiceLocator instance.</returns>
		public IServiceLocator CreateServiceLocator()
		{
			var servicesByType = new Dictionary<Type, object>();
			var servicesByName = new Dictionary<string, object>();

			// Add ITsStrFactory
			ITsStrFactory tsf = TsStrFactoryClass.Create();
			RegisterService("TsStrFactory", tsf, typeof(ITsStrFactory), servicesByType, servicesByName);

			var cache = new FdoCache();
			// Add FdoCache
			RegisterService("Cache", cache, servicesByType, servicesByName);

#if !USECSHARPWSF // It is not longer a singleton, so the C# impl need not be used in here.
			// Add ILgWritingSystemFactory factory
			ILgWritingSystemFactory wsf = LgWritingSystemFactoryClass.Create();
			wsf.Clear();
			RegisterService("WritingSystemFactory", wsf, typeof(ILgWritingSystemFactory), servicesByType, servicesByName);
#else
			// Add ILgWritingSystemFactory factory
			ILgWritingSystemFactory wsf = new LgWritingSystemFactoryFdoImpl(
				cache,
				((ILgWritingSystemRepository)servicesByName["ILgWritingSystemRepository"]),
				((ILgWritingSystemFactoryFdo)servicesByName["ILgWritingSystemFactoryFdo"]));
			RegisterService("WritingSystemFactory", wsf, typeof(ILgWritingSystemFactory), servicesByType, servicesByName);
#endif

			// Add MDC
			var mdc = new FdoMetaDataCache();
			RegisterService("MetaDataCache", mdc, typeof(IFwMetaDataCacheManaged), servicesByType, servicesByName);

			// Add IdentityMap
			var identitymap = new IdentityMap(mdc);
			RegisterService("IdentityMap", identitymap, servicesByType, servicesByName);

			// Add BEP.
			IDataSetup bep;
			switch (m_backendProviderType)
			{
				default:
					throw new InvalidOperationException(Strings.ksInvalidBackendProviderType);
				case FDOBackendProviderType.kFirebird:
					bep = new FirebirdBackendProvider(cache, identitymap, mdc);
					break;
				case FDOBackendProviderType.kXML:
					bep = new XMLBackendProvider(cache, identitymap, mdc);
					break;
				case FDOBackendProviderType.kDb4o:
					bep = new DB4oBackendProvider(cache, identitymap, mdc);
					break;
				case FDOBackendProviderType.kBerkeleyDB:
					bep = new BerkeleyDBBackendProvider(cache, identitymap, mdc);
					break;
				case FDOBackendProviderType.kMemoryOnly:
					bep = new MemoryOnlyBackendProvider(cache, identitymap, mdc);
					break;
				case FDOBackendProviderType.kMySQL:
					bep = new MySqlBackendProvider(cache, identitymap, mdc);
					break;
			}
			// Only register the IDataStore interface, as the others are internal, not public
			RegisterService("DataSetup", bep, typeof(IDataSetup), servicesByType, servicesByName);

			// Add Mediator
			var mediator = new FdoMediator((IDataStorer)bep, identitymap);
			RegisterService("ActionHandler", mediator, typeof(IActionHandler), servicesByType, servicesByName);

			// Add generated factories.
			AddFactories(cache, servicesByType, servicesByName);

			// Add generated Repositories
			AddRepositories(cache, (IDataReader)bep, servicesByType, servicesByName);

			// Add SDA
			// Done after the Repositories, since SDA wants one.
			var sda = new DomainDataByFlidFacade.DomainDataByFlid(((ICmObjectRepository)servicesByName["ICmObjectRepository"]), mdc, mediator, tsf, wsf);
			RegisterService("DomainDataByFlid", sda, typeof(ISilDataAccessManaged), servicesByType, servicesByName);

			return new FdoServiceLocatorAdapter(servicesByType, servicesByName);
		}

		private static void RegisterService(string key, object service, IDictionary<Type, object> servicesByType, IDictionary<string, object> servicesByName)
		{
			RegisterService(key, service, service.GetType(), servicesByType, servicesByName);
		}

		private static void RegisterService(string key, object service, Type serviceType, IDictionary<Type, object> servicesByType, IDictionary<string, object> servicesByName)
		{
			servicesByType.Add(serviceType, service);
			servicesByName.Add(key, service);
		}

		#endregion
	}

	/// <summary>
	/// Hard-wired FDO Adapter for Common Service Locator.
	/// </summary>
	public sealed class FdoServiceLocatorAdapter : ServiceLocatorImplBase
	{
		private readonly Dictionary<Type, object> m_servicesByType;
		private readonly Dictionary<string, object> m_servicesByName;

		///<summary>
		/// 
		///</summary>
		///<param name="servicesByType"></param>
		///<param name="servicesByName"></param>
		///<exception cref="NotImplementedException"></exception>
		internal FdoServiceLocatorAdapter(Dictionary<Type, object> servicesByType, Dictionary<string, object> servicesByName)
		{
			if (servicesByType == null) throw new ArgumentNullException("servicesByType");
			if (servicesByName == null) throw new ArgumentNullException("servicesByName");

			m_servicesByType = servicesByType;
			m_servicesByName = servicesByName;
		}

		#region Overrides of ServiceLocatorImplBase

		/// <summary>
		/// When implemented by inheriting classes, this method will do the actual work of resolving
		///             the requested service instance.
		/// </summary>
		/// <param name="serviceType">Type of instance requested.</param><param name="key">Name of registered service you want. May be null.</param>
		/// <returns>
		/// The requested service instance.
		/// </returns>
		protected override object DoGetInstance(Type serviceType, string key)
		{
			// Sample code for cases where new ones are created for each request.
			//if (serviceType.Name == "IGatherOccupancyStudyDataService")
			//	return new GatherOccupancyStudyDataService(); // New one for each request.

			object service;
			if (string.IsNullOrEmpty(key))
			{
				if (m_servicesByType.TryGetValue(serviceType, out service))
					return service;
				throw new ArgumentException("Cannot find the service of the given type.");
			}

			if (m_servicesByName.TryGetValue(key, out service))
				return service;
			throw new ArgumentException("Cannot find the service with the given name.");
		}

		/// <summary>
		/// When implemented by inheriting classes, this method will do the actual work of
		///             resolving all the requested service instances.
		/// </summary>
		/// <param name="serviceType">Type of service requested.</param>
		/// <returns>
		/// Sequence of service instance objects.
		/// </returns>
		protected override IEnumerable<object> DoGetAllInstances(Type serviceType)
		{
			return new List<object>(1) { DoGetInstance(serviceType, null) };
		}

		#endregion
	}
}