//#define USEENVANDTRANS
using System;
using System.Collections.Generic;
using System.Reflection;
using System.IO;
using NUnit.Framework;
using SIL.FieldWorks.FDO.FDOTests;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.FDO.Infrastructure;

namespace SIL.FieldWorks.FDO.CoreTests.PersistingLayerTests
{
	/// <summary>
	/// This class defines all the tests to be run by the
	/// persisting backend providers (BEP).
	/// That is, the BEPs that actually store data
	/// derive from this base class, in order to create the required BEP.
	/// All tests are defined on this class, however, so all BEPs
	/// can be tested the exact same way.
	/// I can do this, because BEPs only support the four basic
	/// "CRUD" operations (Create, Read, Update, and Delete).
	/// 
	/// Test CmObject properties.
	/// 1. Guid,
	/// 2. Owner.
	/// 3. OwningFlid
	/// 
	/// Test the most basic generated properties.
	/// We test these flid types here:
	/// CellarModuleDefns.kcptBoolean: Done
	/// CellarModuleDefns.kcptInteger: Done
	/// CellarModuleDefns.kcptTime: Done
	/// CellarModuleDefns.kcptGuid: Done
	/// CellarModuleDefns.kcptGenDate: Done
	/// CellarModuleDefns.kcptBinary: Done
	/// 
	/// CellarModuleDefns.kcptUnicode: Done
	/// CellarModuleDefns.kcptBigUnicode: Done
	/// 
	/// CellarModuleDefns.kcptString: Done
	/// CellarModuleDefns.kcptBigString: Done
	/// 
	/// CellarModuleDefns.kcptMultiString: Done
	/// CellarModuleDefns.kcptMultiBigString: Done
	/// 
	/// CellarModuleDefns.kcptMultiUnicode: Done
	/// CellarModuleDefns.kcptMultiBigUnicode: Done
	/// 
	/// CellarModuleDefns.kcptNumeric: (Not used in model.)
	/// CellarModuleDefns.kcptFloat: (Not used in model.)
	/// CellarModuleDefns.kcptImage: (Not used in model.)
	/// 
	/// </summary>
	public abstract class PersistingBackendProviderTestBase : FdoTestBase
	{
		private int m_customCertifiedFlid;
		private int m_customITsStringFlid;
		private int m_customMultiUnicodeFlid;
		private int m_customAtomicReferenceFlid;
		//private int m_customReferenceSequenceFlid;
		/// <summary></summary>
		protected BackendBulkLoadDomain m_loadType = BackendBulkLoadDomain.All;

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// If a test overrides this, it should call the base implementation.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[TestFixtureSetUp]
		public override void FixtureSetup()
		{
			base.FixtureSetup();

			var servLoc = Cache.ServiceLocator;
			var mdc = servLoc.GetInstance<IFwMetaDataCacheManaged>();
			if (m_internalRestart)
			{
				m_customCertifiedFlid = (int)mdc.GetFieldId("WfiWordform", "Certified", false);
				m_customITsStringFlid = (int)mdc.GetFieldId("WfiWordform", "NewTsStringProp", false);
				m_customMultiUnicodeFlid = (int)mdc.GetFieldId("WfiWordform", "MultiUnicodeProp", false);
				m_customAtomicReferenceFlid = (int)mdc.GetFieldId("WfiWordform", "NewAtomicRef", false);
				//m_customReferenceSequenceFlid = (int)mdc.GetFieldId("WfiWordform", "NewRefSeq", false);
			}
			else
			{
				m_customCertifiedFlid = (int)mdc.AddCustomField("WfiWordform", "Certified", FieldType.kcptBoolean, 0);
				m_customITsStringFlid = (int)mdc.AddCustomField("WfiWordform", "NewTsStringProp", FieldType.kcptString, 0);
				m_customMultiUnicodeFlid = (int)mdc.AddCustomField("WfiWordform", "MultiUnicodeProp", FieldType.kcptMultiUnicode, 0);
				m_customAtomicReferenceFlid = (int)mdc.AddCustomField("WfiWordform", "NewAtomicRef", FieldType.kcptReferenceAtom, CmPersonTags.kClassId);
				//m_customReferenceSequenceFlid = (int)mdc.AddCustomField("WfiWordform", "NewRefSeq", FieldType.kcptReferenceSequence, CmPersonTags.kClassId);
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// If a test overrides this, it should call the base implementation.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public override void FixtureTeardown()
		{
			m_customCertifiedFlid = 0;
			//m_customITsStringFlid = 0;
			//m_customMultiUnicodeFlid = 0;
			m_customAtomicReferenceFlid = 0;
			//m_customReferenceSequenceFlid = 0;

			base.FixtureTeardown();
		}

		/// <summary>
		/// Make sure the basic data types are right.
		/// </summary>
		[Test]
		public void BasicDataTypes()
		{
			Cache.DomainDataByFlid.BeginNonUndoableTask();

			var lp = Cache.LanguageProject;

			// 'Remember' some guids.
			// Atomic property.
			var lpGuid = lp.Guid;
			var wfiGuid = lp.WordformInventoryOA.Guid;
			// Owning collection property.
			var aaGuid = lp.AnalyzingAgentsOC.ToArray()[0].Guid;
			// Owning sequence property.
			var pssGuid = lp.TranslationTagsOA.PossibilitiesOS[0].Guid;

			// CellarModuleDefns.kcptBoolean:
			var isClosed = lp.TranslationTagsOA.IsClosed;
			// CellarModuleDefns.kcptInteger:
			lp.TranslationTagsOA.Depth = 5;
			var depth = lp.TranslationTagsOA.Depth;
			// CellarModuleDefns.kcptTime
			var dateCreated = lp.DateCreated;
			// CellarModuleDefns.kcptGuid
			var uv = Cache.ServiceLocator.GetInstance<IUserViewFactory>().Create();
			uv.App = Guid.NewGuid();
			var appGuid = uv.App;
			var uvGuid = uv.Guid;
			// CellarModuleDefns.kcptGenDate
			lp.PeopleOA = Cache.ServiceLocator.GetInstance<ICmPossibilityListFactory>().Create();
			var eve = Cache.ServiceLocator.GetInstance<ICmPersonFactory>().Create();
			lp.PeopleOA.PossibilitiesOS.Add(eve);
			eve.DateOfBirth += 1;
			var eveDOB = eve.DateOfBirth;
			// CellarModuleDefns.kcptBinary:
			var byteArrayValue = new byte[] { 1, 2, 3 };
			uv.Details = byteArrayValue;
			// CellarModuleDefns.kcptUnicode & CellarModuleDefns.kcptBigUnicode:
			const string newEthCode = "ZPI";
			lp.EthnologueCode = newEthCode;
			// CellarModuleDefns.kcptString & CellarModuleDefns.kcptBigString:
			var le = Cache.ServiceLocator.GetInstance<ILexEntryFactory>().Create();
			lp.LexDbOA.EntriesOC.Add(le);
			var irOriginalValue = Cache.TsStrFactory.MakeString("import residue",
				Cache.WritingSystemFactory.UserWs);
			le.ImportResidue = irOriginalValue;
			var streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTssAsXml(irOriginalValue,
				 Cache.WritingSystemFactory,
				 0,
				 Cache.WritingSystemFactory.UserWs, true);
			var xmlOriginalValue = streamWrapper.Contents;

			// Use same test, since the multiString and MultiUnicode props
			// all use the same mechanism (on MultiAccessor) to read/write
			// the data.
			// CellarModuleDefns.kcptMultiString:
			// CellarModuleDefns.kcptMultiBigString:
			// CellarModuleDefns.kcptMultiUnicode:
			// CellarModuleDefns.kcptMultiBigUnicode:
			var tsf = Cache.TsStrFactory;
			var englishWsHvo = Cache.WritingSystemFactory.GetWsFromStr("en");
			var spanishWsHvo = Cache.WritingSystemFactory.GetWsFromStr("es");
			var nameEnValue = tsf.MakeString("Stateful FDO Test Project", englishWsHvo);
			streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTssAsXml(nameEnValue,
				 Cache.WritingSystemFactory,
				 0,
				 englishWsHvo, true);
			var enXML = streamWrapper.Contents;
			// Set LP's Name.
			lp.Name.set_String(
				englishWsHvo,
				nameEnValue);
			var nameEsValue = tsf.MakeString("Proyecto de prueba: FDO", spanishWsHvo);
			streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTssAsXml(nameEsValue,
				 Cache.WritingSystemFactory,
				 0,
				 spanishWsHvo, true);
			var esXML = streamWrapper.Contents;
			lp.Name.set_String(
				spanishWsHvo,
				nameEsValue);

			// Check that ScriptureReferenceSystem is persisted & reloaded.
			var srs = lp.ScriptureReferenceSystem;

			// Restart BEP.
			RestartCache(true);
			lp = Cache.LanguageProject;

			// Atomic property.
			var lpGuidRestored = lp.Guid;
			Assert.IsTrue(lpGuid == lpGuidRestored, "Object Guid not saved/restored properly.");
			Assert.IsTrue(lp.WordformInventoryOA.Owner == Cache.LanguageProject,
				"WFI owner is not the LP.");
			Assert.IsTrue(lp.WordformInventoryOA.Guid == wfiGuid,
				"WFI Guid not the same.");

			// Owning collection property.
			Assert.IsTrue(lp.AnalyzingAgentsOC.ToArray()[0].Guid == aaGuid,
				"AnalyzingAgent Guid not the same.");

			// Owning sequence property.
			Assert.IsTrue(lp.TranslationTagsOA.PossibilitiesOS[0].Guid == pssGuid,
				"Translation type Guid not the same.");

			// Check bool.
			Assert.AreEqual(isClosed,
				lp.TranslationTagsOA.IsClosed,
				"Wrong boolean value restored.");
			// Check int.
			Assert.AreEqual(depth,
				lp.TranslationTagsOA.Depth,
				"Wrong integer value restored.");
			// Check time.
			Assert.AreEqual(dateCreated.Year,
				lp.DateCreated.Year,
				"Wrong year part of time value restored.");
			Assert.AreEqual(dateCreated.Month,
				lp.DateCreated.Month,
				"Wrong month part of time value restored.");
			Assert.AreEqual(dateCreated.Day,
				lp.DateCreated.Day,
				"Wrong day part of time value restored.");
			Assert.AreEqual(dateCreated.Hour,
				lp.DateCreated.Hour,
				"Wrong hour part of time value restored.");
			Assert.AreEqual(dateCreated.Minute,
				lp.DateCreated.Minute,
				"Wrong minute part of time value restored.");
			Assert.AreEqual(dateCreated.Second,
				lp.DateCreated.Second,
				"Wrong second part of time value restored.");
			Assert.AreEqual(dateCreated.Millisecond,
				lp.DateCreated.Millisecond,
				"Wrong millisecond time value restored.");
			// Check Guid.
			uv = Cache.ServiceLocator.GetInstance<IUserViewRepository>().GetObject(uvGuid);
			Assert.AreEqual(appGuid,
				uv.App,
				"Wrong Guid value restored.");
			// Check GenDate
			eve = (ICmPerson)lp.PeopleOA.PossibilitiesOS[0];
			Assert.AreEqual(eveDOB,
				eve.DateOfBirth,
				"Wrong DOB value restored.");
			// Check Binary.
			Assert.AreEqual(byteArrayValue,
				uv.Details,
				"Wrong Binary value restored.");
			// Check Unicode
			Assert.AreEqual(newEthCode,
				lp.EthnologueCode,
				"Wrong Unicode value restored.");
			// Check string (ITsString)
			var irRestoredValue = lp.LexDbOA.EntriesOC.ToArray()[0].ImportResidue;
			streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTssAsXml(irRestoredValue,
				 Cache.WritingSystemFactory,
				 0,
				 Cache.WritingSystemFactory.UserWs, true);
			var xmlRestoredValue = streamWrapper.Contents;
			Assert.AreEqual(xmlOriginalValue, xmlRestoredValue,
				"Wrong ITsString value restored.");
			
			englishWsHvo = Cache.WritingSystemFactory.GetWsFromStr("en");
			irRestoredValue = lp.Name.get_String(englishWsHvo);
			streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTssAsXml(irRestoredValue,
				 Cache.WritingSystemFactory,
				 0,
				 englishWsHvo, true);
			Assert.AreEqual(enXML, streamWrapper.Contents,
				"Wrong ITsString value (Name) restored.");
			spanishWsHvo = Cache.WritingSystemFactory.GetWsFromStr("es");
			irRestoredValue = lp.Name.get_String(spanishWsHvo);
			streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTssAsXml(irRestoredValue,
				 Cache.WritingSystemFactory,
				 0,
				 spanishWsHvo, true);
			Assert.AreEqual(esXML, streamWrapper.Contents,
				"Wrong ITsString value (Name) restored.");

			Assert.AreEqual(srs.Guid, lp.ScriptureReferenceSystem.Guid, "Wrong ScriptureReferenceSystem Guid.");
		}

		/// <summary>
		/// Make sure BackendProvider does an 'on demand' load.
		/// </summary>
		[Test]
		public void OnDemandLoadTest()
		{
			var originalLoadType = m_loadType;
			try
			{
				m_loadType = BackendBulkLoadDomain.None;
				RestartCache(false);

				var lp = Cache.LanguageProject;
				var wfi = lp.WordformInventoryOA;
				Assert.IsNotNull(wfi, "Null WFI.");
			}
			finally
			{
				m_loadType = originalLoadType;
				RestartCache(false);
			}
		}

		/// <summary>
		/// Add new custom field, persist it, and reload it.
		/// </summary>
		[Test]
		public void CustomFieldTest()
		{
			// No changes, but a task is needed for the restart to work.
			Cache.DomainDataByFlid.BeginNonUndoableTask();

			// Restart BEP.
			RestartCache(true);

			// Make sure the custom fields were reloaded,
			// which means they had to also have been saved.
			var mdc = Cache.ServiceLocator.GetInstance<IFwMetaDataCacheManaged>();
			var flid = mdc.GetFieldId("WfiWordform", "Certified", false);
			Assert.IsTrue(mdc.IsCustom(flid));
			flid = mdc.GetFieldId("WfiWordform", "NewAtomicRef", false);
			Assert.IsTrue(mdc.IsCustom(flid));
		}

		/// <summary>
		/// Add new custom field data, persist it, and reload it.
		/// </summary>
		[Test]
		public void CustomFieldDataTest()
		{
			var servLoc = Cache.ServiceLocator;
			var sda = servLoc.GetInstance<ISilDataAccessManaged>();
			var lp = Cache.LanguageProject;

			sda.BeginNonUndoableTask();
			var wf = servLoc.GetInstance<IWfiWordformFactory>().Create();
			lp.WordformInventoryOA.WordformsOC.Add(wf);
			var wfGuid = wf.Guid;
			// Set custom boolean property.
			sda.SetBoolean(wf.Hvo, m_customCertifiedFlid, true);
			// Set custom ITsString property.
			var tsf = Cache.TsStrFactory;
			var userWs = Cache.WritingSystemFactory.UserWs;
			var newStringValue = tsf.MakeString("New ITsString", userWs);
			sda.SetString(wf.Hvo, m_customITsStringFlid, newStringValue);
			// Set custom MultiUnicode property.
			var newUnicodeTsStringValue = tsf.MakeString("New unicode ITsString", userWs);
			sda.SetMultiStringAlt(wf.Hvo, m_customMultiUnicodeFlid, userWs, newUnicodeTsStringValue);
			// Set atomic reference custom property.
			var possListFactory = servLoc.GetInstance<ICmPossibilityListFactory>();
			lp.PeopleOA = possListFactory.Create();
			var personFactory = servLoc.GetInstance<ICmPersonFactory>();
			var person = personFactory.Create();
			lp.PeopleOA.PossibilitiesOS.Add(person);
			var personGuid = person.Guid;
			sda.SetObjProp(wf.Hvo, m_customAtomicReferenceFlid, person.Hvo);

			// Restart BEP.
			RestartCache(true);

			servLoc = Cache.ServiceLocator;
			userWs = Cache.WritingSystemFactory.UserWs;
			sda = servLoc.GetInstance<ISilDataAccessManaged>();
			wf = servLoc.GetInstance<IWfiWordformRepository>().GetObject(wfGuid);
			Assert.IsTrue(sda.get_BooleanProp(wf.Hvo, m_customCertifiedFlid), "Custom prop is not 'true'.");
			var tss = sda.get_StringProp(wf.Hvo, m_customITsStringFlid);
			Assert.AreEqual(tss.Text, newStringValue.Text, "Wrong TsString in custom property.");
			tss = sda.get_MultiStringAlt(wf.Hvo, m_customMultiUnicodeFlid, userWs);
			Assert.AreEqual(tss.Text, newUnicodeTsStringValue.Text, "MultiUnicode custom property is not newUnicodeTsStringValue.");
			person = servLoc.GetInstance<ICmPersonRepository>().GetObject(personGuid);
			Assert.AreEqual(person.Hvo, sda.get_ObjectProp(wf.Hvo, m_customAtomicReferenceFlid), "Wrong atomic ref custom value.");
		}

		/// <summary>
		/// Make sure the open BackendProvider can be ported to a new BEP.
		/// </summary>
		[Test]
		public void PortFromOpenDBToNewDBTest()
		{
			if (File.Exists(BEPOptions.kFirebirdTarget))
				File.Delete(BEPOptions.kFirebirdTarget);

			if (File.Exists(BEPOptions.kXMLTarget))
				File.Delete(BEPOptions.kXMLTarget);

			if (File.Exists(BEPOptions.kDB4oTarget))
				File.Delete(BEPOptions.kDB4oTarget);

			if (File.Exists(BEPOptions.kBerkeleyIdxTarget))
				File.Delete(BEPOptions.kBerkeleyIdxTarget);
			if (File.Exists(BEPOptions.kBerkeleyTarget))
				File.Delete(BEPOptions.kBerkeleyTarget);

			var sourceGuids = new List<Guid>();
			foreach (var obj in Cache.ServiceLocator.GetInstance<ICmObjectRepository>().AllInstances())
				sourceGuids.Add(obj.Guid);

			// 1. Test against a Firebird target DB.
			DoMigrationAndCheckResults(sourceGuids, BEPOptions.s_fdbTargetParms);
			// 2. Test against an XML target DB.
			DoMigrationAndCheckResults(sourceGuids, BEPOptions.s_xmlTargetParms);
			// 3. Test against a DB4o target DB.
			DoMigrationAndCheckResults(sourceGuids, BEPOptions.s_db4oTargetParms);
			// 4. Test against a Berkeley DB target DB.
			DoMigrationAndCheckResults(sourceGuids, BEPOptions.s_bdbTargetParms);
			// 5. Test against a Memory only target DB.
			DoMigrationAndCheckResults(sourceGuids, BEPOptions.s_memoryOnlyTargetParms);
		}

		private void DoMigrationAndCheckResults(ICollection<Guid> sourceGuids, BackendStartupParameter targetParms)
		{
			// Migrate source data to new BEP.
			using (var targetCache = FdoCache.CreateCache(targetParms.ProviderType))
			{
				var targetDataSetup = targetCache.ServiceLocator.GetInstance<IDataSetup>();
				targetDataSetup.CreateNewLanguageProject(targetParms.StartupOptions, Cache);
				targetDataSetup.LoadDomain(BackendBulkLoadDomain.All);

				var allTargetObjects = targetCache.ServiceLocator.GetInstance<ICmObjectRepository>().AllInstances();
				Assert.AreEqual(sourceGuids.Count, allTargetObjects.Length, "Wrong number of objects in target DB.");
				foreach (var obj in allTargetObjects)
					Assert.IsTrue(sourceGuids.Contains(obj.Guid), "Missing guid in target DB.");
			}
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kMemoryOnly
	/// backend provider. Technically, this one need not be test here, since it doesn't
	/// actually persist anything, but in order to have the test stabel be complete for
	/// all BEPs, I run them anyway.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class MemoryOnlyTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			return BootstrapSystem(FDOBackendProviderType.kMemoryOnly, null, m_loadType);
		}

		/// <summary>
		/// Override to do nothing.
		/// </summary>
		/// <param name="doCommit">'True' to end the task and commit the changes. 'False' to skip the commit.</param>
		protected override void RestartCache(bool doCommit)
		{
			if (doCommit)
				Cache.DomainDataByFlid.EndNonUndoableTask();
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kDb4o
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class DB4oTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string filename = "TestLangProj.db4o";
			if (!m_internalRestart && File.Exists(filename))
				File.Delete(filename);

			return BootstrapSystem(FDOBackendProviderType.kDb4o, new object[] { filename }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kFirebird
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class FirebirdTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string filename = "TestLangProj.fdb";
			if (!m_internalRestart && File.Exists(filename))
				File.Delete(filename);

			return BootstrapSystem(FDOBackendProviderType.kFirebird, new object[] { filename }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kBerkeleyDB
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class BerkeleyDBTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			var codepath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase.Substring(8));
			var bdbPath = Path.Combine(codepath, "TestLangProj.bdb");
#if USEENVANDTRANS
			string dirMain = Path.Combine(codepath, "Main");
			if (!Directory.Exists(dirMain))
				Directory.CreateDirectory(dirMain);
			string dirSecondary = Path.Combine(codepath, "Secondary");
			if (!Directory.Exists(dirSecondary))
				Directory.CreateDirectory(dirSecondary);
#endif
			if (!m_internalRestart)
			{
#if USEENVANDTRANS
				string mainPath = Path.Combine(dirMain, "TestLangProj.bdb");
				if (File.Exists(mainPath))
					File.Delete(mainPath);
				string idxPath = Path.Combine(Path.Combine(codepath, @"Secondary"), "TestLangProj.idx");
				if (File.Exists(idxPath))
					File.Delete(idxPath);
#else
				if (File.Exists(bdbPath))
					File.Delete(bdbPath);
				var idxPath = Path.Combine(codepath, "TestLangProj.idx");
				if (File.Exists(idxPath))
					File.Delete(idxPath);
#endif
			}

			return BootstrapSystem(FDOBackendProviderType.kBerkeleyDB, new object[] {bdbPath}, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kXML
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class XMLTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string filename = "TestLangProj.xml";
			if (!m_internalRestart)
			{
				if (File.Exists(filename))
					File.Delete(filename);
			}

			return BootstrapSystem(FDOBackendProviderType.kXML, new object[] { filename }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kMySQL
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class MySqlTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			if (!m_internalRestart)
			{
				if (File.Exists("TestLangProj.myd"))
					File.Delete("TestLangProj.myd");
				if (File.Exists("TestLangProj.frm"))
					File.Delete("TestLangProj.frm");
				if (File.Exists("TestLangProj.myi"))
					File.Delete("TestLangProj.myi");
			}
			return BootstrapSystem(FDOBackendProviderType.kMySQL, new object[] { "TestLangProj.myd" }, m_loadType);
		}
	}

	internal static class BEPOptions
	{
		internal const string kFirebirdSource = "TLP.fdb";
		internal const string kFirebirdTarget = "TLP_New.fdb";
		internal const string kXMLSource = "TLP.xml";
		internal const string kXMLTarget = "TLP_New.xml";
		internal const string kDB4oSource = "TLP.db4o";
		internal const string kDB4oTarget = "TLP_New.db4o";
		internal const string kBerkeleyIdxSource = "TLP.idx";
		internal const string kBerkeleySource = "TLP.bdb";
		internal const string kBerkeleyIdxTarget = "TLP_New.idx";
		internal const string kBerkeleyTarget = "TLP_New.bdb";
		internal const string kMySQLSource = "TLP.myd";
		internal const string kMySQLTarget = "TLP_New.myd";

		internal static readonly BackendStartupParameter s_fdbSourceParms = new BackendStartupParameter(
			FDOBackendProviderType.kFirebird,
			BackendBulkLoadDomain.All,
			new object[] { kFirebirdSource });

		internal static readonly BackendStartupParameter s_fdbTargetParms = new BackendStartupParameter(
			FDOBackendProviderType.kFirebird,
			BackendBulkLoadDomain.All,
			new object[] { kFirebirdTarget });

		internal static readonly BackendStartupParameter s_xmlSourceParms = new BackendStartupParameter(
			FDOBackendProviderType.kXML,
			BackendBulkLoadDomain.All,
			new object[] { kXMLSource });

		internal static readonly BackendStartupParameter s_xmlTargetParms = new BackendStartupParameter(
			FDOBackendProviderType.kXML,
			BackendBulkLoadDomain.All,
			new object[] { kXMLTarget });

		internal static readonly BackendStartupParameter s_db4oSourceParms = new BackendStartupParameter(
			FDOBackendProviderType.kDb4o,
			BackendBulkLoadDomain.All,
			new object[] { kDB4oSource });

		internal static readonly BackendStartupParameter s_db4oTargetParms = new BackendStartupParameter(
			FDOBackendProviderType.kDb4o,
			BackendBulkLoadDomain.All,
			new object[] { kDB4oTarget });

		internal static readonly BackendStartupParameter s_bdbSourceParms = new BackendStartupParameter(
			FDOBackendProviderType.kBerkeleyDB,
			BackendBulkLoadDomain.All,
			new object[] { kBerkeleySource });

		internal static readonly BackendStartupParameter s_bdbTargetParms = new BackendStartupParameter(
			FDOBackendProviderType.kBerkeleyDB,
			BackendBulkLoadDomain.All,
			new object[] { kBerkeleyTarget });

		internal static readonly BackendStartupParameter s_memoryOnlySourceParms = new BackendStartupParameter(
			FDOBackendProviderType.kMemoryOnly,
			BackendBulkLoadDomain.All,
			null);

		internal static readonly BackendStartupParameter s_memoryOnlyTargetParms = new BackendStartupParameter(
			FDOBackendProviderType.kMemoryOnly,
			BackendBulkLoadDomain.All,
			null);

		internal static readonly BackendStartupParameter s_mydSourceParms = new BackendStartupParameter(
			FDOBackendProviderType.kMySQL,
			BackendBulkLoadDomain.All,
			new object[] { kMySQLSource });

		internal static readonly BackendStartupParameter s_mydTargetParms = new BackendStartupParameter(
			FDOBackendProviderType.kMySQL,
			BackendBulkLoadDomain.All,
			new object[] { kMySQLTarget });

	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Test migrating data from each persisting type of BEP to all others.
	/// 
	/// These test cases where neither system is opened at the start.
	/// See the "PortFromOpenDBToNewDBTest()" test in PersistingBackendProviderTestBase
	/// for porting from an open system to a new one.
	/// </summary>
	/// <remarks>
	/// We can't run a test starting with kMemoryOnly,
	/// since it can't be persisted and restarted and that is part of the test.
	/// </remarks>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class MigrationToAnotherBEPTests
	{
		private static void DoMigrationAndCheckResults(bool createSource, BackendStartupParameter sourceParms, BackendStartupParameter targetParms)
		{
			if (sourceParms == null) throw new ArgumentNullException("sourceParms");
			if (targetParms == null) throw new ArgumentNullException("targetParms");

			// Set up data source.
			var sourceGuids = new List<Guid>();
			using (var sourceCache = FdoCache.CreateCache(sourceParms.ProviderType))
			{
				var sourceDataSetup = sourceCache.ServiceLocator.GetInstance<IDataSetup>();
				// When 'createSource' is true, the source is created.
				// When 'createSource' is false, the source is just loaded from its file.
				if (createSource)
					sourceDataSetup.CreateNewLanguageProject(sourceParms.StartupOptions);
				else
					sourceDataSetup.StartupExtantLanguageProject(sourceParms.StartupOptions);
				sourceDataSetup.LoadDomain(sourceParms.BulkLoadDomain);
				foreach (var obj in sourceCache.ServiceLocator.GetInstance<ICmObjectRepository>().AllInstances())
					sourceGuids.Add(obj.Guid);
			}

			// Migrate source data to new BEP.
			using (var targetCache = FdoCache.CreateCache(targetParms.ProviderType))
			{
				var targetDataSetup = targetCache.ServiceLocator.GetInstance<IDataSetup>();
				targetDataSetup.CreateNewLanguageProject(targetParms.StartupOptions, sourceParms);
				targetDataSetup.LoadDomain(BackendBulkLoadDomain.All);

				var allTargetObjects = targetCache.ServiceLocator.GetInstance<ICmObjectRepository>().AllInstances();
				Assert.AreEqual(sourceGuids.Count, allTargetObjects.Length, "Wrong number of objects in target DB.");
				foreach (var obj in allTargetObjects)
					Assert.IsTrue(sourceGuids.Contains(obj.Guid), "Missing guid in target DB.");
			}
		}

		/// <summary>
		/// Set up before each test.
		/// </summary>
		[SetUp]
		public void TestSetup()
		{
			if (File.Exists(BEPOptions.kFirebirdSource))
				File.Delete(BEPOptions.kFirebirdSource);
			if (File.Exists(BEPOptions.kFirebirdTarget))
				File.Delete(BEPOptions.kFirebirdTarget);

			if (File.Exists(BEPOptions.kXMLSource))
				File.Delete(BEPOptions.kXMLSource);
			if (File.Exists(BEPOptions.kXMLTarget))
				File.Delete(BEPOptions.kXMLTarget);

			if (File.Exists(BEPOptions.kDB4oSource))
				File.Delete(BEPOptions.kDB4oSource);
			if (File.Exists(BEPOptions.kDB4oTarget))
				File.Delete(BEPOptions.kDB4oTarget);

			if (File.Exists(BEPOptions.kBerkeleyIdxSource))
				File.Delete(BEPOptions.kBerkeleyIdxSource);
			if (File.Exists(BEPOptions.kBerkeleySource))
				File.Delete(BEPOptions.kBerkeleySource);
			if (File.Exists(BEPOptions.kBerkeleyIdxTarget))
				File.Delete(BEPOptions.kBerkeleyIdxTarget);
			if (File.Exists(BEPOptions.kBerkeleyTarget))
				File.Delete(BEPOptions.kBerkeleyTarget);
		}

		/// <summary>
		/// Make sure kFirebird BEP migrates to all other BEP types.
		/// </summary>
		[Test]
		public void kFirebird_MigrationTests()
		{
			// 1. Test against another Firebird DB.
			DoMigrationAndCheckResults(true, BEPOptions.s_fdbSourceParms, BEPOptions.s_fdbTargetParms);
			// 2. Test against an XML DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_fdbSourceParms, BEPOptions.s_xmlTargetParms);
			// 3. Test against a DB4o DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_fdbSourceParms, BEPOptions.s_db4oTargetParms);
			// 4. Test against a Berkeley DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_fdbSourceParms, BEPOptions.s_bdbTargetParms);
			// 5. Test against a Memory only DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_fdbSourceParms, BEPOptions.s_memoryOnlyTargetParms);
		}

		/// <summary>
		/// Make sure kXML BEP migrates to all other BEP types.
		/// </summary>
		[Test]
		public void kXML_MigrationTests()
		{
			// 1. Test against a Firebird DB.
			DoMigrationAndCheckResults(true, BEPOptions.s_xmlSourceParms, BEPOptions.s_fdbTargetParms);
			// 2. Test against an XML DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_xmlSourceParms, BEPOptions.s_xmlTargetParms);
			// 3. Test against a DB4o DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_xmlSourceParms, BEPOptions.s_db4oTargetParms);
			// 4. Test against a Berkeley DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_xmlSourceParms, BEPOptions.s_bdbTargetParms);
			// 5. Test against a Memory only DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_xmlSourceParms, BEPOptions.s_memoryOnlyTargetParms);
		}

		/// <summary>
		/// Make sure kDb4o BEP migrates to all other BEP types.
		/// </summary>
		[Test]
		public void kDb4o_MigrationTests()
		{
			// 1. Test against a Firebird DB.
			DoMigrationAndCheckResults(true, BEPOptions.s_db4oSourceParms, BEPOptions.s_fdbTargetParms);
			// 2. Test against an XML DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_db4oSourceParms, BEPOptions.s_xmlTargetParms);
			// 3. Test against a DB4o DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_db4oSourceParms, BEPOptions.s_db4oTargetParms);
			// 4. Test against a Berkeley DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_db4oSourceParms, BEPOptions.s_bdbTargetParms);
			// 5. Test against a Memory only DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_db4oSourceParms, BEPOptions.s_memoryOnlyTargetParms);
		}

		/// <summary>
		/// Make sure kBerkeleyDB BEP migrates to all other BEP types.
		/// </summary>
		[Test]
		public void kBerkeleyDB_MigrationTests()
		{
			// 1. Test against a Firebird DB.
			DoMigrationAndCheckResults(true, BEPOptions.s_bdbSourceParms, BEPOptions.s_fdbTargetParms);
			// 2. Test against an XML DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_bdbSourceParms, BEPOptions.s_xmlTargetParms);
			// 3. Test against a DB4o DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_bdbSourceParms, BEPOptions.s_db4oTargetParms);
			// 4. Test against a Berkeley DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_bdbSourceParms, BEPOptions.s_bdbTargetParms);
			// 5. Test against a Memory only DB.
			DoMigrationAndCheckResults(false, BEPOptions.s_bdbSourceParms, BEPOptions.s_memoryOnlyTargetParms);
		}
	}
}