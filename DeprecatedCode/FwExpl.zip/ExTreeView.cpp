/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: ExTreeView.cpp
Responsibility: John Wimbish
Last reviewed:

	Implementation of ExTreeView.

    ENHANCE: 
       - 
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop
#undef THIS_FILE
DEFINE_THIS_FILE

/***********************************************************************************************
	ExTreeView SUPERCLASS
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Constructs the tree view, setting up the member variables.
----------------------------------------------------------------------------------------------*/
ExTreeView::ExTreeView()
{
    m_pwndParentFrame = NULL;
}



/*----------------------------------------------------------------------------------------------
	Creates the tree view window, doing initializations that require an hwnd.
----------------------------------------------------------------------------------------------*/
void ExTreeView::Initialize(ExMainWnd * pwndParentFrame, HWND hwndTab, bool bIsVisible, uint rid, 
                            HIMAGELIST himages)
{
    Assert(pwndParentFrame);
    Assert(hwndTab);

    m_pwndParentFrame = pwndParentFrame;

    WndCreateStruct ows;
	ows.InitChild(WC_TREEVIEW, hwndTab, rid);
    ows.style |= WS_BORDER | TVS_HASLINES | TVS_SHOWSELALWAYS | TVS_HASBUTTONS;
    if (bIsVisible)
        ows.style |= WS_VISIBLE;
	ows.dwExStyle |= WS_EX_CLIENTEDGE;
	//ows.lpCreateParams = pwndParentFrame;
    //ows.lpszName  = "Tree View";
	CreateAndSubclassHwnd(ows);

    SetImageList(TVSIL_NORMAL, himages);
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
HTREEITEM ExTreeView::InsertItem(const StrUni & stu, int iImage, int iSelectedImage, HTREEITEM hParent,
		HTREEITEM hInsertAfter)
{
    extern ExplorerApp g_app;
    ITsStringPtr qtss;
    g_app.MakeUIString(stu, qtss);
    return SuperClass::InsertItem(qtss, iImage, iSelectedImage, hParent, hInsertAfter);
}


/*----------------------------------------------------------------------------------------------
	From the currently selected item in the tree, returns the corresponding icon and the 
    TsString (as out parameters). 

    Returns: true if successful, false otherwise (e.g., nothing was selected in the tree)
----------------------------------------------------------------------------------------------*/
bool ExTreeView::GetCurrentSelection(int * iIconOut, ITsStringPtr & qtssNameOut)
{
    // Get the current selection. If nothing is selected, return that we failed.
	HTREEITEM hItem = TreeView_GetSelection(m_hwnd);
    if (NULL == hItem)
        return false;

    // Retrieve the item according as a TsString.
    GetItemInfo(hItem, iIconOut, qtssNameOut);
    return true;
}

/*----------------------------------------------------------------------------------------------
	Retrieve thte text and icon for an item in the tree. 
----------------------------------------------------------------------------------------------*/
void ExTreeView::GetItemInfo(HTREEITEM hItem, int * iIconOut, ITsStringPtr & qtssNameOut)
{
    Assert(hItem);
    FW_TVITEM tviItem;
    tviItem.hItem = hItem;
    tviItem.mask = TVIF_TEXT | TVIF_IMAGE;
    GetItem(&tviItem);
    *iIconOut = tviItem.iImage;
    qtssNameOut = tviItem.qtss;
}



/*----------------------------------------------------------------------------------------------
	Searches through the children of hParent in the tree, looking for a match with the name
    passed in. 

    Parameters:
        qtssName - the target name for which we are searching
        hParent  - The node in the tree whose children we are comparing against qtssName.
    
    Returns the HTREEITEM of the matching child, or NULL if not found. 
----------------------------------------------------------------------------------------------*/
HTREEITEM ExTreeView::FindItemByName(const StrUni & stuName, HTREEITEM hParent)
{
    Assert(NULL != hParent);

    // TreeView structure for retrieving item information
    FW_TVITEM item;
    item.mask = TVIF_TEXT;

    // Examine each child for a match, break out of the loop if a match is found
    BSTR bstrItem;
    HTREEITEM hChild = TreeView_GetChild(Hwnd(), hParent);
    while (NULL != hChild)
    {
        item.hItem = hChild;
        GetItem(&item);
        item.qtss->get_Text(&bstrItem);
        if ( 0 == wcscmp(bstrItem, stuName.Bstr()) )
            break;
        hChild = TreeView_GetNextSibling(Hwnd(), hChild);
    }

    return hChild;
}



/*----------------------------------------------------------------------------------------------
    Expands the nodes of the tree down to a certain level. All nodes lower than that level
    are collapsed.

	Parameters
        nLevel - the level down to which will be expanded. The Root node is Level 0. Thus a
            call with nLevel set to 0 will expand the root node to show its children; nLevel 
            set to 1 will expand to show the root's grandchildren.
        hNode - used for recursive calls to this function as it works down through the nodes
            in the tree. The calling code should ignore this (it will thus be set to NULL
            as per the header file.)
----------------------------------------------------------------------------------------------*/
void ExTreeView::ExpandToLevel(int nLevel, HTREEITEM hNode)
{
    // If hNode is NULL, then we want the root.
    if (NULL == hNode)
        hNode = TreeView_GetRoot(Hwnd());
    Assert(NULL != hNode);

    // Determine the current level. It is how many distant we are from the root.
    HTREEITEM hRoot = TreeView_GetRoot(Hwnd());
    Assert(NULL != hRoot);
    int nCurrentLevel = 0;
    for( HTREEITEM h = hNode; h != hRoot; h = TreeView_GetParent(Hwnd(),h))
        nCurrentLevel++;

    // Determine whether to expand or contract this node
    UINT nExpandFlag = (nLevel > nCurrentLevel) ? TVE_EXPAND : TVE_COLLAPSE ;

    // Do the appropriate action on this node
    TreeView_Expand(Hwnd(), hNode, nExpandFlag);

    // Recurse to the children, so they'll be properly done.
    HTREEITEM hChild = TreeView_GetChild(Hwnd(), hNode);
    while (NULL != hChild)
    {
        ExpandToLevel(nLevel, hChild);
        hChild = TreeView_GetNextSibling(Hwnd(), hChild);
    }
}


/*----------------------------------------------------------------------------------------------
    On startup, we want the tree to resemble the Windows Explorer, where the first project
    (the C:\ drive) is expanded down a level, but all others are visible but not expanded.
    This method first expands the first level, and then expands the first project an 
    additional level.
----------------------------------------------------------------------------------------------*/
void ExTreeView::InitialExpansion()
{
    // Close up everything below, and just expand so that the projects are showing.
    ExpandToLevel(1);

    // Locate the first project, and expand it.
    HTREEITEM hRoot = TreeView_GetRoot(Hwnd());
    if (NULL == hRoot)
        return;
    HTREEITEM hProject = TreeView_GetChild(Hwnd(), hRoot);
    if (NULL == hProject)
        return;
    TreeView_Expand(Hwnd(), hProject, TVE_EXPAND);

    // Select that project, so the list view and other items will be updated
    SelectItem(hProject);
}

/*----------------------------------------------------------------------------------------------
    Selects the item in the tree control, expanding parent nodes if necessary and scrolling
    into view if necessary.

	Returns TRUE if successful, FALSE otherwise.
----------------------------------------------------------------------------------------------*/
BOOL ExTreeView::SelectItem(HTREEITEM hItem)
{
    return TreeView_SelectItem(Hwnd(), hItem);
}


/***********************************************************************************************
	ExFolderTreeView METHODS
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
HTREEITEM ExFolderTreeView::InsertItem(ExFolder * pfold, HTREEITEM hParent)
{
    HTREEITEM hItem = SuperClass::InsertItem(pfold->DisplayName(), pfold->GetIcon(), 
            pfold->GetIcon()+1, hParent, TVI_LAST);
    return hItem;
}


/*----------------------------------------------------------------------------------------------
	Returns the ExFolder corresponding to the current selection, or NULL if there is no such
    ExFolder.
----------------------------------------------------------------------------------------------*/
ExFolder * ExFolderTreeView::GetSelectedFolder(void) 
{
	HTREEITEM hItem = TreeView_GetSelection(m_hwnd);
    if (NULL == hItem)
        return NULL;
    return GetFolder(hItem);
}


/*----------------------------------------------------------------------------------------------
	Givin an item in the tree, returns the corresponding ExFolder. This function works 
    recursively up the tree to find the appropriate folder. Thus duplicate names within the
    tree will not confuse the method, as long as there are no duplicate names within a 
    single node.

    Parameter:
        hItem - the HTREEITEM for which the corresponding an ExFolder is desired.

    Returns a pointer to the ExFolder, or NULL if the selection was at the top "My Data" node.
    The Debug version fires an assertion if there is not matching ExFolder for the item;
    the Release version returns NULL in this case.

    Assumptions:
        1. The topmost node of the tree is "My Data". It does not correspond to an ExFolder.
            It has no siblings; everything of interest is below it.
        2. Everything under "My Data" is a Project, corresponding to something in the main
            window's vector of projects.
        3. All siblings within a node are unique with regard to their names.
----------------------------------------------------------------------------------------------*/
ExFolder * ExFolderTreeView::GetFolder(HTREEITEM hItem) 
{
    Assert(NULL != hItem);

    // Retrieve the tree's root. This is the "My Data" node on the tree. There should be
    // exactly one node at this highest level in the tree. If this matches hItem, then 
    // we return NULL, as there is no corresponding ExFolder to this root node.
    HTREEITEM hRoot = TreeView_GetRoot(m_hwnd);
    Assert(NULL != hRoot);
    if (hItem == hRoot)
        return NULL;

    // Retrieve the data from the tree.
    int iIconOut;
    ITsStringPtr qtssName;
    GetItemInfo(hItem, &iIconOut, qtssName); 
    BSTR bstrItem;
    qtssName->get_Text(&bstrItem);

    // Get hItem's parent item. 
    HTREEITEM hParentItem = TreeView_GetParent(m_hwnd, hItem);
    Assert(NULL != hParentItem);

    // If hParentItem is the same our hRoot, then we can search the projects for a match.
    // That is, we are at the highest level of the tree (and of the folders hierarchy.)
    if (hRoot == hParentItem) 
    {
        ExProject * pprj = m_pwndParentFrame->GetRoot().GetProject(bstrItem);

        // If this assertion fires, it means we have something illegal in the tree at the 
        // Project level. (I.e., we have a project that we don't recognize in our vector 
        // of projects.)
        Assert(NULL != pprj);

        return pprj;
    }

    // If we've gotten this far, then we are somewhere in the tree lower down than the Projects
    // level. So we recursively call this function, using the parent as a parameter, in order
    // to get a valid ExFolder. The recursion will work its way up until the above code that
    // works through the Projects is called. Then it will recurse through the following code
    // block where the children are checked.
    ExFolder * pfoldParentItem = GetFolder(hParentItem);
    Assert(NULL != pfoldParentItem);

    // Search the parent folder's children for a match
    for(int i=0; i < pfoldParentItem->m_vqfold.Size(); i++)
    {
        if ( 0 == wcscmp(bstrItem, pfoldParentItem->m_vqfold[i]->DisplayName().Bstr()) )
            return pfoldParentItem->m_vqfold[i];
    }

    // If we get here, it is because there is stuff in the tree that does not exist in the
    // ExFolder hierarchy. (Or some other reason I failed to predict.)
    Assert(false);
    return NULL;
}


/***********************************************************************************************
	ExToolTreeView METHODS
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Inserts a tool into the tree.
----------------------------------------------------------------------------------------------*/
HTREEITEM ExToolTreeView::InsertItem(ExTool * ptool, HTREEITEM hParent)
{
    if (NULL == hParent)
        hParent = TreeView_GetRoot(Hwnd());
    HTREEITEM hItem = SuperClass::InsertItem(ptool->Name(), ptool->GetIcon(), 
            ptool->GetIcon()+1, hParent, TVI_LAST);
    return hItem;
}

/*----------------------------------------------------------------------------------------------
	Returns the ExFolder corresponding to the current selection, or NULL if there is no such
    ExFolder.

    We currently assume a tree of two levels, the root which is the parent of the tools. Thus
    we don't have to mess with hierarchy. Also, we assume that all of the tools have unique
    names (something that is required within a given node of a hierarchy.) Thus all we need to 
    do is to compare the text we retrieve from the tree with the names of the tools; and we
    have our answer.

    Returns: a pointer to the selected tool, or NULL if no tool is currently selected (e.g.,
    if the tree's root is selected.)
----------------------------------------------------------------------------------------------*/
ExTool * ExToolTreeView::GetSelectedTool(void) 
{
    // Retrieve the data from the tree corresponding to the current selection. 
    int iIconOut;
    ITsStringPtr qtssName;
    bool fFound = GetCurrentSelection(&iIconOut, qtssName); 
    if (!fFound)
        return NULL;
    BSTR bstrItem;
    qtssName->get_Text(&bstrItem);

    // Search the tools for a match
    ExTool * ptool = m_pwndParentFrame->GetRoot().GetTool(bstrItem);
    if (NULL != ptool)
        return ptool;

    // We were at the root.
    return NULL;
}

/*----------------------------------------------------------------------------------------------
	Prevent the tool tree's root node from being collapsed.
----------------------------------------------------------------------------------------------*/
bool ExToolTreeView::OnItemExpanding(FW_NMTREEVIEW * pfnmv, long & lnRet)
{
    if (TVE_COLLAPSE == pfnmv->action )
    {
        lnRet = TRUE;                       // Signal Windows to prevent the collapse
        return true;
    }
    return false;
}

/*----------------------------------------------------------------------------------------------
	Prevent the root item of the tree from being selected.
----------------------------------------------------------------------------------------------*/
bool ExToolTreeView::OnSelChanging(FW_NMTREEVIEW * pfnmv, long & lnRet)
{
    if (pfnmv->itemNew.hItem == TreeView_GetRoot(m_hwnd))
    {
        lnRet = TRUE;                       // Signal Windows to prevent the change
        return true;
    }
    return false;
}

