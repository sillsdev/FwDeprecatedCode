/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExTreeView.h
Responsibility: John Wimbish
Last reviewed: never

Description:
	...
----------------------------------------------------------------------------------------------*/


#pragma once
#ifndef EXTREEVIEW_H
#define EXTREEVIEW_H 1

class ExMainWnd;
class ExFolder;
class ExTool;

class ExTreeView;
class ExFolderTreeView;
class ExToolTreeView;
typedef GenSmartPtr<ExTreeView>       ExTreeViewPtr;
typedef GenSmartPtr<ExFolderTreeView> ExFolderTreeViewPtr;
typedef GenSmartPtr<ExToolTreeView>   ExToolTreeViewPtr;

/*----------------------------------------------------------------------------------------------
	This class supports several convenience methods, on top of the TsString Tree View.
	Hungarian: etv
----------------------------------------------------------------------------------------------*/
class ExTreeView : public TssTreeView
{
typedef TssTreeView SuperClass;

public:
    // Creation and Initialization
    ExTreeView();
    void Initialize(ExMainWnd * pwndParent, HWND hwndTab, bool bIsVisible, 
        uint rid, HIMAGELIST himages);

    // Tree state operations
    void ExpandToLevel(int nlevel, HTREEITEM hNode=NULL);
    void InitialExpansion();
    BOOL SelectItem(HTREEITEM hItem);
    HTREEITEM InsertItem(const StrUni & stu, int iImage, int iSelectedImage, HTREEITEM hParent,
		HTREEITEM hInsertAfter);

    // Current selection
    bool GetCurrentSelection(int * iIconOut, ITsStringPtr & qtssNameOut); 

    // Data access
    HTREEITEM FindItemByName(const StrUni & stuName, HTREEITEM hParent);
    void GetItemInfo(HTREEITEM hItem, int * iIconOut, ITsStringPtr & qtssNameOut);

protected:
    ExMainWnd * m_pwndParentFrame;          // The Explorer that ultimate owns this tree
};


/*----------------------------------------------------------------------------------------------
	...
	Hungarian: eftv
----------------------------------------------------------------------------------------------*/
class ExFolderTreeView : public ExTreeView
{
    typedef ExTreeView SuperClass;

public:
    // Creation and Initialization
    ExFolderTreeView() : ExTreeView() {}
    HTREEITEM InsertItem(ExFolder * pfold, HTREEITEM hParent);

    // Data Retrieval
    ExFolder * GetSelectedFolder(void);
    ExFolder * GetFolder(HTREEITEM hItem);

};


/*----------------------------------------------------------------------------------------------
	...
	Hungarian: eftv
----------------------------------------------------------------------------------------------*/
class ExToolTreeView : public ExTreeView
{
    typedef ExTreeView SuperClass;

public:
    // Creation and Initialization
    ExToolTreeView() : ExTreeView() {}
    HTREEITEM InsertItem(ExTool * ptool, HTREEITEM hParent = NULL);

    // Data Retrieval
    ExTool * GetSelectedTool(void);

protected:
	virtual bool OnItemExpanding(FW_NMTREEVIEW * pfnmv, long & lnRet);
	virtual bool OnSelChanging(FW_NMTREEVIEW * pfnmv, long & lnRet);
};



#endif //!EXTREEVIEW_H

