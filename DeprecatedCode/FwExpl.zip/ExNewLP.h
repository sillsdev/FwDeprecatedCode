/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExNewLP.h
Responsibility: John Wimbish
Last reviewed: never

Description:
	New Language Project Wizard Classes
----------------------------------------------------------------------------------------------*/



/*----------------------------------------------------------------------------------------------
	Provides the page wherein the user types in the name of the language, for which the
    new project will be known. The language name is shown in FieldWorks in one of the 
    UI Writing Systems, and thus we can use a normal edit box for it.

	Hungarian: wlpn.
----------------------------------------------------------------------------------------------*/
class ExPageGetName : public AfWizardPage
{
typedef AfWizardPage SuperClass;
public:
    ExPageGetName() : AfWizardPage(kridWizProjPageGetName) {}
protected:
    virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
};

typedef GenSmartPtr<ExPageGetName> ExPageGetNamePtr;


/*----------------------------------------------------------------------------------------------
	Provides the page wherein the user types in the ethnologue code for the language.
	Hungarian: wlpn.
----------------------------------------------------------------------------------------------*/
class ExPageGetEthCode : public AfWizardPage
{
typedef AfWizardPage SuperClass;
public:
    ExPageGetEthCode() : AfWizardPage(kridWizProjPageEth) {}
protected:
    virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
};

typedef GenSmartPtr<ExPageGetEthCode> ExPageGetEthCodePtr;


/*----------------------------------------------------------------------------------------------
	...
	Hungarian: wlpn.
----------------------------------------------------------------------------------------------*/
class ExPageGetLocation : public AfWizardPage
{
typedef AfWizardPage SuperClass;
public:
    ExPageGetLocation() : AfWizardPage(kridWizProjPageLoc) {}
protected:
    virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
};

typedef GenSmartPtr<ExPageGetLocation> ExPageGetLocationPtr;

/*----------------------------------------------------------------------------------------------
	...
	Hungarian: wlpc.
----------------------------------------------------------------------------------------------*/
class ExPageGetComputer : public AfWizardPage
{
typedef AfWizardPage SuperClass;
public:
    ExPageGetComputer() : AfWizardPage(kridWizProjPageComputer) {}
protected:
    virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
};

typedef GenSmartPtr<ExPageGetComputer> ExPageGetComputerPtr;


/*----------------------------------------------------------------------------------------------
	...
	Hungarian: wlpl.
----------------------------------------------------------------------------------------------*/
class ExPageGetTopicLists : public AfWizardPage
{
typedef AfWizardPage SuperClass;
public:
    ExPageGetTopicLists() : AfWizardPage(kridWizProjPageLists) {}
protected:
    virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
};

typedef GenSmartPtr<ExPageGetTopicLists> ExPageGetTopicListsPtr;




/*----------------------------------------------------------------------------------------------
	...
	Hungarian: wlpn.
----------------------------------------------------------------------------------------------*/
class ExPageReady : public AfWizardPage
{
typedef AfWizardPage SuperClass;
public:
    ExPageReady() : AfWizardPage(kridWizProjPageReady) {}
};

typedef GenSmartPtr<ExPageReady> ExPageReadyPtr;


/*----------------------------------------------------------------------------------------------
	...
	Hungarian: wlp.
----------------------------------------------------------------------------------------------*/
class ExNewLangProjWizard : public AfWizardDlg
{
typedef AfWizardDlg SuperClass;

public:
    ExNewLangProjWizard() : AfWizardDlg() {}

protected:
    virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);

};

typedef GenSmartPtr<ExNewLangProjWizard> ExNewLangProjWizardPtr;
