/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: Explorer.h
Responsibility: John Wimbish
Last reviewed: never

Description:
	This class provides the base for Explorer functions.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef EXPLORER_INCLUDED
#define EXPLORER_INCLUDED 1


/*----------------------------------------------------------------------------------------------
	Explorer Application class

    Hungarian: app
----------------------------------------------------------------------------------------------*/
class ExplorerApp : public AfDbApp
{
	typedef AfDbApp SuperClass;

public:
    // Construction, etc.
    ExplorerApp();

    // Returns a registry key for storing all Explorer settings
    achar * GetRegistryKey(achar * pszSubkey);

    // Send messages to the splash window, if it is up
    void SetSplashMessage(wchar * pwszMessage);
    void SetSplashMessage(uint nMessageId);
    void SetSplashLoadingMessage(wchar * pwszItemBeingLoaded);

    // Message boxes (convenience methods)
    int MessageBox(int rid, UINT uType, ...);
    void InformationBox(int krid);
    void ErrorBox(int krid, int nLastError = 0);

    // Sql server operations
    bool ServerIsRunning();
    bool StartServer();

    // Create a string according to the current writing system
    void InitializeLocale();
    void MakeUIString(wchar * pwsz, ulong c, ITsStringPtr & qtss);
    void MakeUIString(const StrUni & stu, ITsStringPtr & qtss);
    void LoadStuFromResources(uint rid, StrUni & stuOut);

    int GetUIWritingSystem() { return m_wsUserInterface; }

	// This is not currently used, but needed for compilation as an AfDbApp.
	virtual AfDbInfo * GetDbInfo(const OLECHAR * pszDbName, const OLECHAR * pszSvrName)
	{
		return NULL;
	}
protected:
	ITsStrFactoryPtr m_qtsfStringFactory;   // Factory for creating strings
    int m_wsUserInterface;                 // Writing system for the user interface displays
// 	AfSplashWndPtr m_qsplSplashWnd;         // The splash window used during startup
    ExMainWndPtr   m_qwndMain;              // The main frame window for the Explorer

    // Methods
	virtual void Init(void);
	virtual bool CmdFileExit(Cmd * pcmd);

	CMD_MAP_DEC(ExplorerApp);
};


/*----------------------------------------------------------------------------------------------
    Sets the mouse to the hourglass wait cursor. The wait cursor stays in effect until 
    the CWaitCursor object goes out of scope, or until RestoreCursor() is called.

    Hungarian: wait
----------------------------------------------------------------------------------------------*/
class CWaitCursor
{
public:
    CWaitCursor() {
        HCURSOR hWaitCursor = LoadCursor(NULL, IDC_WAIT);
        m_hOldCursor = (hWaitCursor != NULL) ? SetCursor(hWaitCursor) : NULL;
    }
    ~CWaitCursor() {
        RestoreCursor();
    }
    void RestoreCursor() {
        if (m_hOldCursor)
            SetCursor(m_hOldCursor);
        m_hOldCursor = NULL;
    }
protected:
    HCURSOR m_hOldCursor;
};


/*----------------------------------------------------------------------------------------------
	This class is overridden to allow us to create an RnLpInfo structure.

	@h3{Hungarian: dbi}
----------------------------------------------------------------------------------------------
class ExDbInfo : public AfDbInfo
{
public:
	ExDbInfo();

	virtual AfLpInfo * GetLpInfo(HVO hvoLp);
};

typedef GenSmartPtr<RnDbInfo> RnDbInfoPtr;*/




#endif // EXPLORER_INCLUDED
