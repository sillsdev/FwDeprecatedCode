/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: Explorer.cpp
Responsibility: John Wimbish
Last reviewed: never

Description:
	This class provides the base for FW Explorer functions.
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop
#include "Vector_i.cpp"
#undef THIS_FILE
DEFINE_THIS_FILE


/***********************************************************************************************
    ExplorerApp implementation
***********************************************************************************************/

// Create one global instance. It has to exist before WinMain is called.
ExplorerApp g_app;

BEGIN_CMD_MAP(ExplorerApp)
	ON_CID_ALL(kcidFileExit, &ExplorerApp::CmdFileExit, NULL)
END_CMD_MAP_NIL()


/*----------------------------------------------------------------------------------------------
	Construction
----------------------------------------------------------------------------------------------*/
ExplorerApp::ExplorerApp()
{
    // No UI writing system is defined at this point
    m_wsUserInterface = -1;
	s_fws.SetRoot(_T("Explorer"));//"Software\\SIL\\FieldWorks\\Explorer";
}


/*----------------------------------------------------------------------------------------------
	Initialize the application.
----------------------------------------------------------------------------------------------*/
void ExplorerApp::Init(void)
{
	// See whether we are being started up as a Server (supporting COM interfaces for another
	// application, e.g. the Task Scheduler). This is established by the occurrence of
	// -Embedding or /Embedding in the command line.
	bool fCOMServer = HasEmbedding();

    // Initialize the COM library (use the version that supports drag and drop)
	HRESULT hr = OleInitialize(NULL);
	if (FAILED(hr))	
        return;

    // Initialize the string factory, determine the UI
    InitializeLocale();

    // Start SQL if it is not already running
    if (!ServerIsRunning())
    {
		if (!fCOMServer)
			SetSplashMessage(kstidSplashSqlMessage);
        StartServer();
    }

    // Superclass initialization. (July 6, 2000: I had to move this after the StartServer
    // initialization, because code had been added (with a "kludge" comment about doing
    // some startup stuff. Previously, AfApp::Init() was the first thing in this Init
    // method.
	SuperClass::Init();

	if (fCOMServer)
		return;

    // Create and show main Explorer window
	AfWnd::RegisterClass(_T("ExplorerMainWnd"), 0, 0, kridAppMenu, COLOR_3DFACE,
		(int)IDI_APPLICATION);
	WndCreateStruct wcs;
	wcs.InitMain(_T("ExplorerMainWnd"));
	m_qwndMain.Create();
	m_qwndMain->CreateHwnd(wcs);
	m_qwndMain->Show(m_nShow);

    // Main window is now visible; thus we're now done with splash screen
	if (m_qsplSplashWnd)
		m_qsplSplashWnd->RequestShutDown();

	// Check if a backup is overdue.
	DIFwBackupDbPtr qzbkup;
	qzbkup.CreateInstance(CLSID_FwBackup);
	qzbkup->Init(this, (int)m_qwndMain->Hwnd());
	qzbkup->CheckForMissedSchedules();
}


/*----------------------------------------------------------------------------------------------
	Checks to see if the local server is running.
----------------------------------------------------------------------------------------------*/
bool ExplorerApp::ServerIsRunning()
{
    DWORD dwErr = 0;
    DWORD dwStatus = SQLSCMGetLocalServiceState(_T("MSSQL$SILFW"), &dwErr);
    return SERVICE_RUNNING == dwStatus;
}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool ExplorerApp::StartServer()
{
    // Send the message to start the server
    DWORD dwErr = 0;
    SQLSCMLocalServiceControl(_T("MSSQL$SILFW"), SQLSCMCmd_START, &dwErr, 0, NULL);

    // Go into an infinite loop until we learn that the server is actually running.
    while ( SERVICE_RUNNING != SQLSCMGetLocalServiceState(_T("MSSQL$SILFW"), &dwErr) )
    {
        // Don't check except every second, so that we don't hog processor cycles
        Sleep(1000);

        // If at any time SQLSCMLocalServiceControl sets dwErr, we know to break out of the loop
        if (0 != dwErr)
            return false;

    }
    return true;
}


/*----------------------------------------------------------------------------------------------
	Splash window messages
----------------------------------------------------------------------------------------------*/
void ExplorerApp::SetSplashMessage(wchar * pwszMessage)
{
    if (m_qsplSplashWnd.Ptr())
        m_qsplSplashWnd->SetMessage(pwszMessage);
}
void ExplorerApp::SetSplashMessage(uint nMessageId)
{
    if (m_qsplSplashWnd.Ptr())
        m_qsplSplashWnd->SetMessage(nMessageId);
}
void ExplorerApp::SetSplashLoadingMessage(wchar * pwszItemBeingLoaded)
{
    if (m_qsplSplashWnd.Ptr())
        m_qsplSplashWnd->SetLoadingMessage(pwszItemBeingLoaded);
}



/*----------------------------------------------------------------------------------------------
	Message Boxes (for convenience)
----------------------------------------------------------------------------------------------*/
int ExplorerApp::MessageBox(int rid, UINT uType, ...)
{
    achar szTitle[kMax];
    ::LoadString(GetInstance(), kstidWindowTitle, szTitle, sizeof(szTitle));

    achar szFormat[kMax];
    ::LoadString(GetInstance(), rid, szFormat, sizeof(szFormat));

    // Format the string
    achar szMessage[kMax];
    va_list argptr;
    va_start( argptr, uType );
	_vstprintf( szMessage, szFormat, argptr );
    va_end( argptr);

	HWND hwnd = NULL;
	if (m_qwndMain && m_qwndMain->Hwnd())
		hwnd = m_qwndMain->Hwnd();

    return ::MessageBox(hwnd, szMessage, szTitle, uType);
}
int average( int first, ... )
{
   int count = 0, sum = 0, i = first;
   va_list marker;

   va_start( marker, first );     /* Initialize variable arguments. */
   while( i != -1 )
   {
      sum += i;
      count++;
      i = va_arg( marker, int);
   }
   va_end( marker );              /* Reset variable arguments.      */
   return( sum ? (sum / count) : 0 );
}

void ExplorerApp::InformationBox(int rid)
{
    ExplorerApp::MessageBox(rid, MB_ICONINFORMATION | MB_OK);
}

void ExplorerApp::ErrorBox(int rid, int nLastError)
{
	if (!nLastError)
		ExplorerApp::MessageBox(rid, MB_ICONERROR | MB_OK);
	else
	{
		// Get system text message relating to GetLastError()
		LPVOID lpMsgBuf;		
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS, NULL, nLastError, 
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  (LPTSTR) &lpMsgBuf, 0, NULL);
		StrApp str(rid);
		ExplorerApp::MessageBox(kstidWindowTitle, MB_ICONERROR | MB_OK, str.Chars(),
			(LPCTSTR)lpMsgBuf);
		LocalFree(lpMsgBuf);
	}
}

/*----------------------------------------------------------------------------------------------
	Handle the exit command.
----------------------------------------------------------------------------------------------*/
bool ExplorerApp::CmdFileExit(Cmd * pcmd)
{
	Quit(true);
	OleUninitialize();
	return true;
}


/*----------------------------------------------------------------------------------------------
	Returns the desired key into the registry. We use "Software\\SIL\\FieldWorks\\Explorer"
    as the base key into the registry, and then append subkeys for different types of
    information. The purpose of this method is to ensure that all settings for the Explorer
    are stored in the same area of the Registry.
----------------------------------------------------------------------------------------------*/
achar * ExplorerApp::GetRegistryKey(achar * pszSubKey)
{
	AssertObj(this);
	AssertPsz(pszSubKey);

    static achar s_szCoordsKey[64];
    static achar s_szBaseKey[] =  { _T("Software\\SIL\\FieldWorks\\Explorer") };

    // Make sure we will not overflow the destination buffer
    Assert( _tcslen(s_szBaseKey) + _tcslen(pszSubKey) + 2 < sizeof(s_szCoordsKey) );

    // Build the key
    _tcscpy(s_szCoordsKey, s_szBaseKey);
    if (*pszSubKey != '\\')
        _tcscat(s_szCoordsKey, _T("\\"));
    _tcscat(s_szCoordsKey, pszSubKey);

    return s_szCoordsKey;
}


/*----------------------------------------------------------------------------------------------
    Sets up the locale. This involves querying the operating system to find out which is the
    current language, and then performing setup accordingly.
----------------------------------------------------------------------------------------------*/
void ExplorerApp::InitializeLocale()
{
    Assert(-1 == m_wsUserInterface);
    achar szDefaultWritingSystem[] = {_T("ENG")};	// If all else fails, we use English
    achar szCurrentEncoding[kMax];				// Where we'll store the desired writing system

    // Create a string factory. We'll use this factory from all over the Explorer any time we
    // need to create a TsString using the UI writing system. This allows us to centralize the
    // creation of UI strings, rather than having, e.g., "ENG" sprinkled all over the code.
    m_qtsfStringFactory.CreateInstance(CLSID_TsStrFactory);

    // Retrieve the Operating System's current language, and determine an writing system to use.
    LANGID lgid = GetUserDefaultLangID();
    switch (PRIMARYLANGID(lgid))
    {
    // All dialects of English are just treated as generic English
    case LANG_ENGLISH:
        _tcscpy(szCurrentEncoding, _T("ENG"));
        break;

    // All dialects of French are just treated as generic French
    case LANG_FRENCH:
        _tcscpy(szCurrentEncoding, _T("FRN"));
        break;

    // If un-recognized, then build a string from the abbreviation of the language
    default:
        {
            achar szUserWritingSystem[kMax];
            LCID lcidUser = GetUserDefaultLCID();
            _tcscpy(szCurrentEncoding, szDefaultWritingSystem);
            if (!GetLocaleInfo(lcidUser, LOCALE_SABBREVLANGNAME, szUserWritingSystem,
                sizeof(szUserWritingSystem)))
            {
                _tcscpy(szCurrentEncoding, szUserWritingSystem);
            }
        }
        break;
    }

    // Get the number corresponding to the desired writing system. If nothing was found, try again
    // using the default.
	m_wsUserInterface = StrUtil::ParseWs(szCurrentEncoding);
    if (-1 == m_wsUserInterface)
	    m_wsUserInterface = StrUtil::ParseWs(szDefaultWritingSystem);
    Assert(-1 != m_wsUserInterface);

    // ENHANCE: This is where we should load the appropriate DLL from which to get resources. 
    // The name of the resource DLL should be the szCurrentEncoding, e.g., FRN.dll, or ES.DLL.
    // I believe the proper approach is via the LoadLibrary function. The idea is that
    // once the proper resource DLL is loaded, the rest of the code just automatically
    // gets its resources from there.
}


/*----------------------------------------------------------------------------------------------
	Given a wide null-terminated string, creates a TsString in the current user interface
    writing system.

    Parameters:
        pwsz - the string for which we want a TsString
        c - the length of the string in pwsz.
        qtssOut - the resultant TsString.
----------------------------------------------------------------------------------------------*/
void ExplorerApp::MakeUIString(wchar * pwsz, ulong c, ITsStringPtr & qtssOut)
{
    Assert(-1 != m_wsUserInterface);
    m_qtsfStringFactory->MakeStringRgch(pwsz, c, m_wsUserInterface, &qtssOut);
}


/*----------------------------------------------------------------------------------------------
	Given a StrUni, creates a TsString in the current user interface writing system.

    Parameters:
        stu - the string for which we want a TsString
        qtssOut - the resultant TsString.
----------------------------------------------------------------------------------------------*/
void ExplorerApp::MakeUIString(const StrUni & stu, ITsStringPtr & qtssOut)
{
    Assert(-1 != m_wsUserInterface);
    m_qtsfStringFactory->MakeStringRgch(stu.Bstr(), stu.Length(), m_wsUserInterface, &qtssOut);
}


/*----------------------------------------------------------------------------------------------
	Given a resource id, loads the corresponding string and places it into a StrUni in the
    current user interface writing system.

    Parameters:
        rid - the id of the resource we wish to add
        qtssOut - the destination of the string once we load it.
----------------------------------------------------------------------------------------------*/
void ExplorerApp::LoadStuFromResources(uint rid, StrUni & stuOut)
{
    Assert(-1 != m_wsUserInterface);

    achar szBuffer[512];
    ::LoadString(GetInstance(), rid, szBuffer, sizeof(szBuffer));

#ifdef UNICODE
    stuOut = szBuffer;
#else
    int cHeaderLen = strlen(szBuffer);
    WCHAR wszBuffer[512];
    MultiByteToWideChar(CP_ACP, 0, szBuffer, -1, wszBuffer, 512);
    stuOut = wszBuffer;
#endif
}
