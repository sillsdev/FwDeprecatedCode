/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: DlgFileOpen.cpp
Responsibility: John Wimbish
Last reviewed: Not yet.

Description:
	Implementation of the File Open dialog class.

Note: Requires including winsock2.h and linking with ws2_32.lib.
----------------------------------------------------------------------------------------------*/
#pragma hdrstop
#include "main.h"
#undef THIS_FILE
DEFINE_THIS_FILE

#include "Vector_i.cpp"  
template class Vector<StrUni>;

extern ExplorerApp g_app;


/***********************************************************************************************
    IMPLEMENTATION OF EMBEDDED CLASS ProjectInfo
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Constructor, sets values into the items we are interested in in this class.
----------------------------------------------------------------------------------------------*/
ProjectInfo::ProjectInfo(int nProjectId, StrUni & stuDatabaseName, wchar * pwszProjectName, 
    GUID guid)
{
    m_nProjectId = nProjectId;
    m_stuProjectName = pwszProjectName;
    m_stuDatabaseName = stuDatabaseName;
    m_guid = guid;
    m_fDuplicateProjectName = false;
}

/*----------------------------------------------------------------------------------------------
	Copy Constructor, required for use of this in a vector. 
----------------------------------------------------------------------------------------------*/
ProjectInfo::ProjectInfo(const ProjectInfo & piSource)
{
    m_nProjectId      = piSource.m_nProjectId;
    m_stuProjectName  = piSource.m_stuProjectName;
    m_stuDatabaseName = piSource.m_stuDatabaseName;
    m_guid            = piSource.m_guid;
    m_fDuplicateProjectName = piSource.m_fDuplicateProjectName;
}

/*----------------------------------------------------------------------------------------------
	Returns the display name for this item. This is temporary and should be used before any
    subsequent calls to this method. 

    If the project is unique (as indicated by m_fDuplicateProjectName being false) then we
    just return the name of the project. If it is not unique, then we append the name of
    the database to the project name. 
----------------------------------------------------------------------------------------------*/
const StrUni & ProjectInfo::GetDisplayName()
{
    static StrUni s_stuDisplayName;

    if (!m_fDuplicateProjectName)
        return m_stuProjectName;
    else
    {
        s_stuDisplayName = m_stuProjectName;
        s_stuDisplayName.Append(L" (");
        s_stuDisplayName.Append(m_stuDatabaseName);
        s_stuDisplayName.Append(L")");
        return s_stuDisplayName;
    }
}


/*----------------------------------------------------------------------------------------------
	Goes through all of the projects in the vector, checking to see if any have identical
    names. For those that do, the m_fDuplicateProjectName flag is set to true. This then
    effects the return value of the GetDisplayName method.
----------------------------------------------------------------------------------------------*/
void ProjectInfo::CheckDuplicationNames(Vector<ProjectInfo> * pvpi)
{
    int i,k;

    // Reset all of the projects to not being duplicate
    for(i = 0; i < pvpi->Size(); i++)
        (*pvpi)[i].m_fDuplicateProjectName = false;

    // Compare each against all others.
    for(i = 0; i < pvpi->Size(); i++) 
    {
        for(k = i+1; k < pvpi->Size(); k++)
        {
            if (0 == wcscmp((*pvpi)[i].m_stuProjectName, (*pvpi)[k].m_stuProjectName) )
            {
                (*pvpi)[i].m_fDuplicateProjectName = true;
                (*pvpi)[k].m_fDuplicateProjectName = true;
            }
        }
    }
}



/***********************************************************************************************
    IMPLEMENTATION OF DlgFileOpen
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Constructor
----------------------------------------------------------------------------------------------*/
DlgFileOpen::DlgFileOpen()
{
	m_rid = kridDlgFileOpen;
    m_szLocalMachineName[0] = '\0';
    m_himlTree = NULL;
    m_hwndList = NULL;
}






/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
void DlgFileOpen::FillListControl(NMTREEVIEW * pnmtv)
{
    IOleDbEncapPtr   qode;                  // Current connection. Declare before qodc.
    IOleDbCommandPtr qodc;                 // Currently-executing command
    ComBool fMoreRows;                         // T while there are more rows in the rowset
    ComBool fIsNull;                           // T if the value sought by GetColVal is NULL
	ULONG luSpaceTaken;                     // Size of data returned by GetColVal
    Vector<StrUni> vqstuDatabases;          // Databases on this machine
    achar szTemp[kMax];						// temp holding area for strings

    // Delete everything out of the list box
    ListView_DeleteAllItems(m_hwndList);

    // Retrieve the name of the server from the tree control. If we don't have a server 
    // selected in the tree control, then there is nothing left to do.
    HTREEITEM hItem = pnmtv->itemNew.hItem;
    Assert(NULL != hItem);
    TVITEM tv;
    tv.hItem  = hItem;
    tv.pszText = m_szServerName;
    tv.cchTextMax = sizeof(m_szServerName);
    tv.mask = TVIF_TEXT | TVIF_IMAGE ;
    if (FALSE == TreeView_GetItem(m_qntv->Hwnd(), &tv))
        return;
    if (kridImageComputer != tv.iImage)
        return;

    // Redraw the listbox immediately, so the user doesn't continue looking at the old list of stuff.
    LoadString(g_app.GetInstance(), kstidStatusSearching, szTemp, sizeof(szTemp));
    InsertItemIntoListViewCtrl(m_hwndList, 0, szTemp, kridSearch);
    InvalidateRect(m_hwndList, NULL, true);
    UpdateWindow(m_hwndList);

    // Turn on the hourglass (wait) cursor and the animation. These will automatically dissappear 
    // when this function is exited (via the objects' destructors).
    CWaitCursor wait;
    RECT rect;
    GetWindowRect(GetDlgItem(Hwnd(), kcidHelpTopics), &rect);
    POINT pt;
    pt.x = rect.left;
    pt.y = rect.bottom;
    ScreenToClient(Hwnd(), &pt);
    ExAnimateCtrl anim(Hwnd(), kridAviSearching, pt.x+3, pt.y+20);

	// If the local machine, use the instance string as the server name. Then, we'll open without
	// having to go across the network. (This is especially required for Windows 9x.)
    if (0 == _tcscmp(m_szServerName, m_szLocalMachineName))
	{
		StrApp str = dynamic_cast<AfDbApp *>(AfApp::Papp())->GetLocalServer();
        _tcscpy(m_szServerName, str.Chars());
	}

    // Attempt to open "master" on the target machine. If it doesn't open, then sql is either 
    // not installed or it isn't running. (We will want to display an appropriate message in 
    // the list control; then we're done; we use m_fConnected to do that.)
    qode.CreateInstance(CLSID_OleDbEncap);
    m_fConnected = false;
	StrUni stuServerName = m_szServerName;
    StrUni stuDatabase = L"master";
	HRESULT hr;
	IStreamPtr qfist;
	// Get the IStream pointer for logging. NULL returned if no log file.
	hr = AfApp::Papp()->GetLogPointer(&qfist);
    hr = qode->Init(stuServerName.Bstr(), stuDatabase.Bstr(), qfist, koltMsgBox, 0);
    if (FAILED(hr))
    {
        ListView_DeleteAllItems(m_hwndList);
        LoadString(g_app.GetInstance(), kstidServerNotRunning, szTemp, sizeof(szTemp));
        InsertItemIntoListViewCtrl(m_hwndList, 0, szTemp, kridSearch);
        return;
    }
    m_fConnected = true;

    // Retrieve a list of potential FieldWorks databases, place them in a vector for future use
    StrUni stuCommand;
    stuCommand.Format(
        L"select  name " \
	    L"from    sysdatabases (readuncommitted) " \
	    L"where   name not in ('master', 'model', 'msdb', 'Northwind', 'pubs', 'tempdb') " \
        L"        and object_id(name+'..Class$') is not null " \
        L"        and object_id(name+'..Field$') is not null");
	qode->CreateCommand(&qodc);
    qodc->ExecCommand(stuCommand.Bstr(), knSqlStmtSelectWithOneRowset);
	qodc->GetRowset(0);
    qodc->NextRow(&fMoreRows);
    wchar wszDatabaseName[kMax];
    while (fMoreRows)
    {
        // Get the database name
		qodc->GetColValue(1, reinterpret_cast <ULONG *>(wszDatabaseName), 
            sizeof(wszDatabaseName), &luSpaceTaken, &fIsNull, 2);

        // Place it into the vector
		StrUni stu(wszDatabaseName);
	    vqstuDatabases.Push(stu);

        // Get the next row
        qodc->NextRow(&fMoreRows);
    }

    // Go through the databases one at a time, and get each Language Project. Place into
    // a special structure, including its name and the name of the database.
    m_vpi.Clear();
    while (vqstuDatabases.Size())
    {
        try
        {
            // Open the database
			qodc.Clear();
            hr = qode->Init(stuServerName.Bstr(), vqstuDatabases[0].Bstr(), qfist,
				koltMsgBox, 0);
            if (FAILED(hr))
                goto NextDatabase;

            // Execute a command to retrieve all language projects within the database
            stuCommand.Format(
                L" select lp.id, mt.txt, cm.guid$ " \
                L" from   LangProj lp  " \
                L" join   multitxt$ mt on mt.obj=lp.id  " \
                L" join   CmObject cm on cm.id=lp.id  " \
                L" where  mt.flid =  " \
                L"            (select id from field$ where name ='Name' and class =  " \
	            L"                  (select id from class$ where name = 'CmProject'))   " \
                L" and    mt.ws = %d",
                g_app.GetUIWritingSystem());
	        CheckHr(qode->CreateCommand(&qodc));
            CheckHr(qodc->ExecCommand(stuCommand.Bstr(), knSqlStmtSelectWithOneRowset));
	        CheckHr(qodc->GetRowset(0));

            // Compile a list of all of the language projects
            ulong luProjectId;
            wchar wszProjectName[kMax];
            GUID guid;
            CheckHr(qodc->NextRow(&fMoreRows));
            while (fMoreRows)
            {
                // Get the project id
                qodc->GetColValue(1, &luProjectId, sizeof(ulong), & luSpaceTaken, & fIsNull, 0);

                // Get the project name
		        qodc->GetColValue(2, reinterpret_cast <ULONG *>(wszProjectName), 
                    sizeof(wszProjectName), &luSpaceTaken, &fIsNull, 2);

                // Get the guid
		        qodc->GetColValue(3, reinterpret_cast <ULONG *>(& guid), 
                    sizeof(guid), &luSpaceTaken, &fIsNull, 0);

                // Stuff into the vector
                ProjectInfo pi(luProjectId, vqstuDatabases[0], wszProjectName, guid);
                m_vpi.Insert(m_vpi.Size(), 1, pi);

                // Get the next row
                CheckHr(qodc->NextRow(&fMoreRows));
            }
        } 
        catch (...) 
        {
            // We don't really care what went wrong. We'll just move on to the next
            // database. Thus no action is needed in this catch block.
        }

        // Delete this database, then revisit the loop again. (Once all databases
        // have been deleted, we will not loop anymore.
NextDatabase:
        vqstuDatabases.Delete(0);
    }
	qodc.Clear();
	qode.Clear();

    // Go through the list, and for any unique project names, set a flag so we'll know 
    // to display a full name. Then sort the list.
    ProjectInfo::CheckDuplicationNames(&m_vpi);

    // Place the project names (full name if appropriate) into the list control.
    ListView_DeleteAllItems(m_hwndList);
    for (int i = 0; i < m_vpi.Size(); i++)
    {
#ifdef UNICODE
		InsertItemIntoListViewCtrl(m_hwndList, i, 
			const_cast<wchar *>(m_vpi[i].GetDisplayName().Chars()), kridFileDrawerClosed);
#else
		wcstombs(szTemp, m_vpi[i].GetDisplayName().Chars(), sizeof(szTemp));
        InsertItemIntoListViewCtrl(m_hwndList, i, szTemp, kridFileDrawerClosed);
#endif
    }

    // If the vector was empty, indicate that we have an empty list.
    if (0 == i)
    {
        ::LoadString(g_app.GetInstance(), kstidNoItemsInTheList, szTemp, sizeof(szTemp));
        InsertItemIntoListViewCtrl(m_hwndList, 0, szTemp, kridSearch);
    }
}


/*----------------------------------------------------------------------------------------------
	Set up the dialog controls before displaying the dialog to the user.
----------------------------------------------------------------------------------------------*/
bool DlgFileOpen::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
    // Get handle to the controls
    m_hwndList = GetDlgItem( Hwnd(), kctidChooseProject);
    Assert(m_hwndList);

    // Subclass the Windows tree view to use our special Network treeview.
	HWND hwndNetworkTree = GetDlgItem(Hwnd(), kctidChooseComputer);
    Assert(NULL != hwndNetworkTree);
	m_qntv.Create();
	m_qntv->SubclassTreeView(hwndNetworkTree);

    // Initialize image list into the listview control
    m_himlList = ImageList_Create(17, 17, ILC_COLORDDB | ILC_MASK, 5, 5);
    HBITMAP hbmImageList = LoadBitmap(g_app.GetInstance(), MAKEINTRESOURCE(kridImagesSmall));
    ImageList_AddMasked(m_himlList, hbmImageList, RGB(255,255,255));
    DeleteObject(hbmImageList);
    ListView_SetImageList(m_hwndList, m_himlList, LVSIL_SMALL);
    	
    return true;
}


/*----------------------------------------------------------------------------------------------
	Process notifications from user.
----------------------------------------------------------------------------------------------*/
bool DlgFileOpen::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	switch(pnmh->code)
	{
    // The user has selected an item in the tree. Place the appropriate corresponding contents 
    // into the list control.
    case TVN_SELCHANGED:
        FillListControl((NMTREEVIEW*)pnmh);
        break;

	// Default is do nothing.
    default:
        break;
	}

	return AfWnd::OnNotifyChild(ctidFrom, pnmh, lnRet);
}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool DlgFileOpen::GetSelectedProject(int & nProjectId, StrUni & stuProject, 
        StrUni & stuDatabase, StrUni & stuMachine, GUID * guid)
{
    if (false == n_fProjectIsSelected)
        return false;
    nProjectId  = m_nProjectId;
    stuDatabase = m_stuDatabase;
    stuProject  = m_stuProject;
    stuMachine  = m_stuMachine;
    *guid       = m_guid;
    return true;
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
void DlgFileOpen::DoDataExchange(AfDataExchange * padx) // Does nothing.
{ 
    AssertPtr(padx); 
    if (!padx->m_fSave)
        return;

    // Default to nothing selected.
    m_nProjectId = -1;
    m_stuDatabase = L"";
    m_stuProject = L"";
    m_stuMachine = L"";
    n_fProjectIsSelected = false;

    // Is there anything selected in the list box? Return if not.
    int iSelectedItem = GetListViewSelection(m_hwndList);
    if (-1 == iSelectedItem)
        return;

    // Get the item's information
    LVITEM item;
    achar szName[kMax];
    item.pszText = szName;
    item.cchTextMax = sizeof(szName);
    item.mask = LVIF_IMAGE | LVIF_TEXT;
    item.iItem = iSelectedItem;
    item.iSubItem = 0;
    ListView_GetItem(m_hwndList, &item);

    // If the image is of our searching icon, then we don't have a project.
    if (kridSearch == item.iImage)
        return;

    // Go through our vector, looking for a match for the name
#ifdef UNICODE
    for (int i = 0; i < m_vpi.Size(); i++) 
    {
        if (0 == wcscmp(m_vpi[i].GetDisplayName().Chars(), szName))
            break;
    }
#else
    wchar wszName[kMax];
    mbstowcs(wszName, szName, kMax);
    for (int i = 0; i < m_vpi.Size(); i++) 
    {
        if (0 == wcscmp(m_vpi[i].GetDisplayName().Chars(), wszName))
            break;
    }
#endif
    Assert(i < m_vpi.Size());

    // We have a match. It will coincide with something in our ProjectInfo vector.
    if (i < m_vpi.Size())
    {
        m_nProjectId  = m_vpi[i].GetProjectId();
        m_stuDatabase = m_vpi[i].GetDatabaseName();
        m_stuProject  = m_vpi[i].GetProjectName();
        m_guid        = m_vpi[i].GetGuid();
        m_stuMachine  = m_szServerName;
        n_fProjectIsSelected = true;
    }
}


/***********************************************************************************************
    UTILITIES

    ENHANCE: Move to some utilities location.
************************************************************************************************/

#ifdef COMPI
/*----------------------------------------------------------------------------------------------
	For purposes of displaying in the tree, we remove the leading backslashes, and convert
    the name to lowercase (except for the initial letter.) The source string is actually
    converted, so its original (uppercase) state is lost.
----------------------------------------------------------------------------------------------*/
char *CreateDisplayableNetworkName(char * pszSrc)
{
    char szBuffer[512];
    char * pszStart = pszSrc;
    Assert(sizeof(szBuffer) > strlen(pszSrc));
    char * pszDest = szBuffer;

    // Get rid of leading backslashes
    while (*pszSrc == '\\' )
        ++pszSrc;

    // Preserve the state of the first letter
    if (*pszSrc)
    {
        *pszDest++ = (char)toupper(*pszSrc);
        pszSrc++;
    }

    // Convert all of the remaining letters to lower case
    while (*pszSrc)
    {
        *pszDest++ = (char)tolower( *pszSrc );
        pszSrc++;
    }
    *pszDest = '\0';

    // The destination string cannot have grown, so this copy operation is safe.
    Assert(strlen(szBuffer) <= strlen(pszStart));
    strcpy(pszStart, szBuffer);
    return pszStart;
}
#endif


