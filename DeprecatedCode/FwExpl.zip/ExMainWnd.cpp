/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExMainWnd.cpp
Responsibility: John Wimbish
Last reviewed: never

Description:
	...
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop

#include "Vector_i.cpp"

#undef THIS_FILE
DEFINE_THIS_FILE


/*----------------------------------------------------------------------------------------------
	Message Map
----------------------------------------------------------------------------------------------*/
BEGIN_CMD_MAP(ExMainWnd)
	ON_CID_ALL(kcidFileOpenProject, 	   &ExMainWnd::CmdFileOpenProject,		  NULL)
	ON_CID_ALL(kcidFileCloseProject,	   &ExMainWnd::CmdFileCloseProject, 	  &ExMainWnd::CmsFileCloseProjectUpdate)
	ON_CID_ALL(kcidFilePropertiesListItem, &ExMainWnd::CmdFileProperties,		  &ExMainWnd::CmsFilePropertiesUpdate)
	ON_CID_ALL(kcidFileNewLangProj, 	   &ExMainWnd::CmdFileNewLangProj, NULL)
	ON_CID_ALL(kcidFileBackup,			   &ExMainWnd::CmdFileBackup,			  NULL)
	ON_CID_ALL(kcidHelpAbout,			   &ExMainWnd::CmdHelpAbout,			  NULL)

	ON_CID_GEN(kcidViewLargeIcons, &ExMainWnd::CmdListModeToggle, &ExMainWnd::CmsListModeToggleUpdate)
	ON_CID_GEN(kcidViewSmallIcons, &ExMainWnd::CmdListModeToggle, &ExMainWnd::CmsListModeToggleUpdate)
	ON_CID_GEN(kcidViewList,	   &ExMainWnd::CmdListModeToggle, &ExMainWnd::CmsListModeToggleUpdate)
	ON_CID_GEN(kcidViewDetails,    &ExMainWnd::CmdListModeToggle, &ExMainWnd::CmsListModeToggleUpdate)
END_CMD_MAP_NIL()


/*----------------------------------------------------------------------------------------------
	Construction
----------------------------------------------------------------------------------------------*/
ExMainWnd::ExMainWnd() 
{
	m_xSplit = kdxDefaultSplitPos;
	m_hwndTab = NULL;
	m_himlSmall = NULL;
	m_himlLarge = NULL;
	m_fIsPositioningSplit = false;
	m_hwndChildWithCurrentFocus = NULL;
}


/*----------------------------------------------------------------------------------------------
	Release smart pointers. This virtual function is called by the AfWnd framework from the 
	WM_NCDESTROY message.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::OnReleasePtr()
{
	m_root.Clear();
	SuperClass::OnReleasePtr();
}


/*----------------------------------------------------------------------------------------------
	Returns the application's instance.
----------------------------------------------------------------------------------------------*/
HINSTANCE ExMainWnd::GetAppInst()
{
	return GetApp()->GetInstance();
}

/*----------------------------------------------------------------------------------------------
	Returns the application
----------------------------------------------------------------------------------------------*/
ExplorerApp * ExMainWnd::GetApp()
{
	extern ExplorerApp g_app;
	return &g_app;
}

/*----------------------------------------------------------------------------------------------
	The hwnd has just been attached. Create the child windows.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::PostAttach(void)
{
	extern ExplorerApp g_app;
	AssertObj(this);
	Assert(m_hwnd != NULL);

	SuperClass::PostAttach();

	const int rgrid[] =
	{
		kctidTBarStd,
	};
	GetMenuMgr()->LoadToolBars(rgrid, SizeOfArray(rgrid));
	GetMenuMgr()->LoadAccelTable(kridAccelStd, 0, m_hwnd);

	SetWindowTitle();

	// TODO JohnW(DarrellZ): The Explorer needs to override the LoadSettings and SaveSettings methods
	// which should take care of creating the toolbars. Look at the Notebook to see how it should
	// be done. The CreateToolBar method calls here should be removed then.

	// Standard toolbar
	AfToolBarPtr qtlbr;
	qtlbr.Create();
	qtlbr->Initialize(kctidTBarStd, kctidTBarStd, _T("Standard"));
	m_vqtlbr.Push(qtlbr);
	CreateToolBar(qtlbr, true, true, 200);	   // ENHANCE: Only call CreateToolBar for those we wish to show.

	qtlbr->SetupComboControl(&m_qecbPathnameCombo, kctidPathnameCombo, 300, 250, false);
	Assert(m_qecbPathnameCombo->Hwnd());

	// Image Lists (will be used in numerous places in the interface)
	InitializeImageLists();

	// Initialize Combo box
	m_qecbPathnameCombo->SetImageList(m_himlSmall);

	// Child windows (client area)
	CreateTabChildWindow();
	CreateListView();

	// Retrieve the data needed to populate the trees. We must get the project data first,
	// in order for the tool initialization to take place properly. After both trees are 
	// set up (which includes having something selected in each tree) we set the tree
	// visiblility, which propagates information to the combo box, caption bar, and
	// list box appropriately.
	m_root.Init(m_qetvFolders, m_qetvTools);
	SetTreeVisibility();

	// Initialization is done. We can get rid of our splash screen.
	g_app.SetSplashMessage(kstidSplashFinishingMessage);
	g_app.AddCmdHandler(this, 1);
}


/*----------------------------------------------------------------------------------------------
	Creates the image lists and initializes them from the appropriate resource files. We use
	a masked list so that the image will be painted on top of the background. The images should
	be created with a white background in their bmp files; Windows will then substitute this
	white background for the appropriate one (e.g., menu background, etc.)
----------------------------------------------------------------------------------------------*/
void ExMainWnd::InitializeImageLists()
{
	Assert(m_himlSmall == NULL && m_himlLarge == NULL);

	m_himlSmall = ImageList_Create(17, 17, ILC_COLORDDB | ILC_MASK, 20, 5);
	m_himlLarge = ImageList_Create(35, 35, ILC_COLORDDB | ILC_MASK, 20, 5);

	HBITMAP hbmImageSmall = LoadBitmap(GetAppInst(), MAKEINTRESOURCE(kridImagesSmall));
	HBITMAP hbmImageLarge = LoadBitmap(GetAppInst(), MAKEINTRESOURCE(kridImagesLarge));

	ImageList_AddMasked(m_himlSmall, hbmImageSmall, RGB(255,255,255));
	ImageList_AddMasked(m_himlLarge, hbmImageLarge, RGB(255,255,255));

	DeleteObject(hbmImageSmall);
	DeleteObject(hbmImageLarge);

	if (!m_himlSmall || !m_himlLarge)
	{
		Warn("Creating the image lists failed!");
		ThrowHr(WarnHr(E_FAIL));
	}
}


/*----------------------------------------------------------------------------------------------
	Create the tab window on the left side of the explorer
----------------------------------------------------------------------------------------------*/
void ExMainWnd::CreateTabChildWindow()
{
	extern ExplorerApp g_app;
	InitCommonControls(); 

	// We want to occupy the left part of the client area.
	Rect rcClient;
	GetClientRect(rcClient); 
	WndCreateStruct wcs;
	wcs.InitChild(WC_TABCONTROL, m_hwnd, 0);
	wcs.style = WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_VISIBLE | TCS_BOTTOM |
		TCS_HOTTRACK;
	Rect rcT(rcClient.left+5, rcClient.top+5, m_xSplit - rcClient.left - 10,
		(rcClient.bottom-rcClient.top)-10);
	wcs.SetRect(rcT);
	AfWndPtr qwnd;
	qwnd.Create();
	qwnd->CreateAndSubclassHwnd(wcs);
	m_hwndTab = qwnd->Hwnd();

	// Appropriate GUI font
	HFONT hfontGui = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
	SendMessage(m_hwndTab, WM_SETFONT, (WPARAM) hfontGui,  MAKELPARAM(FALSE, 0) );

	// Image List
	Assert(m_himlSmall);
	TabCtrl_SetImageList(m_hwndTab, m_himlSmall);

	// Add tabs for the two types of approaches
	TCITEM tie; 
	tie.mask = TCIF_TEXT | TCIF_IMAGE; 
	tie.iImage = kridFolderClosed; 
	tie.pszText = _T("Folders"); 
	if (TabCtrl_InsertItem(m_hwndTab, 0, &tie) == -1) { 
		DestroyWindow(m_hwndTab); 
		return; 
	}
	tie.iImage = kridTool; 
	tie.pszText = _T("Tools"); 
	if (TabCtrl_InsertItem(m_hwndTab, 1, &tie) == -1) { 
		DestroyWindow(m_hwndTab); 
		return; 
	}

	// Tree controls 
	m_qetvTools.Create();
	m_qetvTools->Initialize(this, m_hwndTab, true, kctidToolsTree, m_himlSmall);
	m_qetvFolders.Create();
	m_qetvFolders->Initialize(this, m_hwndTab, false, kctidFoldersTree, m_himlSmall);

	StrUni stu;
	g_app.LoadStuFromResources(kstidRootFolders, stu);
	m_qetvFolders->ExTreeView::InsertItem(stu, kridFileCabinetClosed, kridFileCabinetOpened, TVI_ROOT, TVI_FIRST);
	g_app.LoadStuFromResources(kstidRootTools, stu);
	m_qetvTools->ExTreeView::InsertItem(stu, kridToolChestClosed, kridToolChestOpened, TVI_ROOT, TVI_FIRST);

}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
void ExMainWnd::CreateListView()
{
	// Create the caption bar.
	m_qcpbrCaptionBar.Create();
	m_qcpbrCaptionBar->Create(m_hwnd, kctidCaptionBar, m_himlSmall);
	m_qcpbrCaptionBar->AddIcon(0);

	// Create the control
	m_qelvDataList.Create();
	m_qelvDataList->Create(this, kctidDocList);

	// Insert the columns
	m_qelvDataList->AppendColumn(kstidName,	   150);
	m_qelvDataList->AppendColumn(kstidSize,		90, ExListView::kStartInteger);
	m_qelvDataList->AppendColumn(kstidType,	   100);
	m_qelvDataList->AppendColumn(kstidModified,	65, ExListView::kDate);
	m_qelvDataList->AppendColumn(kstidCreated,	65, ExListView::kDate);

	// Default to Report Mode
	SendMessage(Hwnd(), WM_COMMAND, MAKEWPARAM(kcidViewDetails, 0), 0);
}


/*----------------------------------------------------------------------------------------------
	Reposition our child windows - status bar, etc.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::OnSize(int wst, int dxs, int dys)
{
	SuperClass::OnSize(wst, dxs, dys);

	// Retrieve size of client area
	Rect rcClient;
	GetClientRect(rcClient); 

	// Tab window
	int yTop = rcClient.top + 4;
	int dxTab = m_xSplit - rcClient.left - 6;
	int dyCtrl = (rcClient.bottom-rcClient.top)-6;
	SetWindowPos(m_hwndTab, NULL, 3, yTop, dxTab, dyCtrl, SWP_NOZORDER);
	SetWindowPos(m_qetvFolders->Hwnd(), NULL, 2, 2, dxTab-6, dyCtrl-28, SWP_NOZORDER);
	SetWindowPos(m_qetvTools->Hwnd(),	NULL, 2, 2, dxTab-6, dyCtrl-28, SWP_NOZORDER);

	// List Control
	int dxList = rcClient.right - rcClient.left - m_xSplit - 6;
	SetWindowPos(m_qcpbrCaptionBar->Hwnd(), NULL, rcClient.left+m_xSplit+3, yTop, 
		dxList, 30, SWP_NOZORDER);
	SetWindowPos(m_qelvDataList->Hwnd(), NULL, rcClient.left+m_xSplit+3, yTop+30, 
		dxList, dyCtrl-30, SWP_NOZORDER);
 
	return false;
}


/*----------------------------------------------------------------------------------------------
	Display window title. 
----------------------------------------------------------------------------------------------*/
void ExMainWnd::SetWindowTitle()
{
	StrApp str;
	str.Load(kstidWindowTitle);
	::SendMessage(m_hwnd, WM_SETTEXT, 0, (LPARAM)str.Chars());
}

/*----------------------------------------------------------------------------------------------
	Prior to window creation, retrieve coordinates from the registry as to where to create the
	window (we create it where it was last closed.) Set the CREATESTRUCT (cs) with these
	coordinates. If none are found, set it to some reasonable default values. This function
	should be called from within PreCreateHwnd, so that the window will be placed appropriately 
	prior to displaying it.

	Arguments:

		cs - The CREATESTRUCT into which we place the results.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::CalcCreatePos(CREATESTRUCT & cs)
{
	AssertObj(this);
	AssertPsz(cs.lpszClass);

	HKEY hk;
	if (0 == ::RegCreateKey(HKEY_LOCAL_MACHINE, GetApp()->GetRegistryKey(_T("Coords")), &hk))
	{
		// Collect values that are currently in the registry
		int iLeft  = 10, 
			iTop   = 10, 
			iRight = 600, 
			iBottom = 500, 
			iIsMaximized = 0;
		ULONG cbT;

		#define GET_VAL(pv, psz, vDef) \
			cbT = isizeof(*pv); \
			if (0 != RegQueryValueEx(hk, psz, 0, NULL, (BYTE *)pv, &cbT)) \
				*pv = vDef; else (void)0
		GET_VAL(&iLeft,   _T("left"),	iLeft);
		GET_VAL(&iTop,	  _T("top"),	iTop);
		GET_VAL(&iRight,  _T("right"),	iRight);
		GET_VAL(&iBottom, _T("bottom"), iBottom);
		GET_VAL(&m_xSplit,_T("split"),	m_xSplit);
		GET_VAL(&iIsMaximized, _T("maximized"), 0);
		#undef GET_VAL
		
		RegCloseKey(hk);

		// Handle case where mazimized
		if( iIsMaximized ) 
			cs.style |= WS_MAXIMIZE;

		// Retrieve amount of space on the screen.
		RECT rcWork;
		if (!SystemParametersInfo(SPI_GETWORKAREA, 0, &rcWork, false)) 
		{
			rcWork.left = 0;
			rcWork.top = 0;
			rcWork.right = 640;
			rcWork.bottom = 480;
		}

		// Calc coordinates to everything is visible (left, top, if all else fails.)
		cs.cx = min(iRight-iLeft, rcWork.right-rcWork.left);  // Make sure width will fit on screen
		cs.cx = max(cs.cx, kdxMinWndWidth); 				  // Yet, make sure we're at least minimum width
		cs.x = min(iLeft, rcWork.right - cs.cx);			  // Make sure right border is on screen
		cs.x = max(cs.x, rcWork.left);						  // Yet, make sure left border is on screen.
		cs.cy = min(iBottom-iTop, rcWork.bottom-rcWork.top);
		cs.cy = max(cs.cy, kdyMinWndHeight);
		cs.y = min(iTop, rcWork.bottom - cs.cy);
		cs.y = max(cs.y, rcWork.top);
	}
}


/*----------------------------------------------------------------------------------------------
	Save the window layout to the registry so we can restart at same screen location next time
----------------------------------------------------------------------------------------------*/
void ExMainWnd::SaveWindowPos()
{
	HKEY hk;
	RECT rcWork;
	if (!IsIconic(m_hwnd) && 
		SystemParametersInfo(SPI_GETWORKAREA, 0, &rcWork, false) &&
		0 == RegCreateKey(HKEY_LOCAL_MACHINE, GetApp()->GetRegistryKey(_T("Coords")), &hk) )
	{
		RECT rectPos;
		GetWindowRect(m_hwnd, &rectPos);   // Gets values in screen coordinates
		OffsetRect(&rectPos, -rcWork.left, -rcWork.top);

		int iIsZoomed = IsZoomed(m_hwnd);

		#define SET_VAL(pv, psz) \
			RegSetValueEx(hk, psz, 0, REG_BINARY, (BYTE *)pv, isizeof(*pv))
		SET_VAL(&rectPos.left,	 _T("left"));
		SET_VAL(&rectPos.top,	 _T("top"));
		SET_VAL(&rectPos.right,  _T("right"));
		SET_VAL(&rectPos.bottom, _T("bottom"));
		SET_VAL(&m_xSplit,		 _T("split"));
		SET_VAL(&iIsZoomed, _T("maximized"));
		#undef SET_VAL

		RegCloseKey(hk);
	}
}

/*----------------------------------------------------------------------------------------------
	Process mouse move (WM_MOUSEMOVE). xp/yp are current coordinates. grfmk identifies
	button/keys pressed. Return true if processed.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::OnMouseMove(uint grfmk, int xp, int yp)
{
	AssertObj(this);

	// If we are currently repositioning the split, update the window
	if (m_fIsPositioningSplit)
	{
		m_xSplit = xp;
		::SendMessage(m_hwnd, WM_SIZE, kwstRestored, 0);  // Causes window to be redrawn 
	}

	// Otherwise if we are near the split, switch to a sizing cursor.
	else if (m_xSplit - 3 < xp && xp <= m_xSplit + 3)
		::SetCursor(::LoadCursor(NULL, IDC_SIZEWE));

	// Otherwise just use the normal arrow cursor
	else 
		::SetCursor(::LoadCursor(NULL, IDC_ARROW));

	return true; // Don't pass message on.
}


/*----------------------------------------------------------------------------------------------
	Process left button down (WM_LBUTTONUP): If we are repositioning the splitter width, 
	release the mouse capture.

	Parameters:
		xp/yp are current coordinates. 
		grfmk identifies button/keys pressed. 

	Return true if processed.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::OnLButtonUp(uint grfmk, int xp, int yp)
{
	if (m_fIsPositioningSplit)
	{
		::ReleaseCapture();
		m_fIsPositioningSplit = false;
		::ClipCursor(NULL);
		::SetCursor(::LoadCursor(NULL, IDC_ARROW));
		return true; // Don't pass message on.
	}
	return false; // Pass message on.
}


/*----------------------------------------------------------------------------------------------
	Process left button down (WM_LBUTTONDOWN). If we are close to the split position, start a 
	drag, setting the capture so that we can limit the dragging area.

	Parameters:
		xp/yp are current coordinates. 
		grfmk identifies button/keys pressed. 

	Return true if processed.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::OnLButtonDown(uint grfmk, int xp, int yp)
{
	if (m_xSplit - 3 < xp && xp <= m_xSplit + 3)
	{
		m_xSplitOldPosition = m_xSplit; // Save old value in case ESC is hit.
		m_fIsPositioningSplit = true;
		::SetCapture(m_hwnd);
		::SetFocus(m_hwnd); // Allows us to catch ESC for cancel.
		Rect rc;
		::GetClientRect(m_hwnd, &rc);
		::MapWindowPoints(m_hwnd, NULL, (POINT *)&rc, 2);
		rc.left += kdxpMinSplitter;
		rc.right -= kdxpMinSplitter;
		::ClipCursor(&rc);
		return true; // Don't pass message on.
	}
	return false; // Pass message on.
}

/*----------------------------------------------------------------------------------------------
	Process key down messages (WM_KEYDOWN). 

	If we are currently resizing the splitter and the user hits ESC, we exit out of the 
	resize operation.

	Return true if processed.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::OnKeyDown(WPARAM wp, LPARAM lp)
{
	if (wp == VK_ESCAPE && m_fIsPositioningSplit)
	{
		m_xSplit = m_xSplitOldPosition;
		::SendMessage(m_hwnd, WM_SIZE, kwstRestored, 0);  // Causes window to be redrawn 
		OnLButtonUp(0, 0, 0);
		return true; // Don't pass the message on.
	}
	return false;
}

/*----------------------------------------------------------------------------------------------
	Depending upon which tab is current, show or hide the corresponding tree control. The
	first tab is Folders; the second is Tools.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::SetTreeVisibility()
{
	int iCurrentTab = TabCtrl_GetCurSel(m_hwndTab); 
	Assert(-1 < iCurrentTab && iCurrentTab < 2);
	ShowWindow(m_qetvFolders->Hwnd(), (0==iCurrentTab) ? SW_SHOW : SW_HIDE);
	ShowWindow(m_qetvTools->Hwnd(),   (1==iCurrentTab) ? SW_SHOW : SW_HIDE);
	PropagateTreeSelection( (0==iCurrentTab) ? kctidFoldersTree : kctidToolsTree);
}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::FolderTreeIsActive()
{
	int iCurrentTab = TabCtrl_GetCurSel(m_hwndTab); 
	Assert(-1 < iCurrentTab && iCurrentTab < 2);
	return 0 == iCurrentTab;
}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::ToolTreeIsActive()
{
	return ! FolderTreeIsActive();
}


/*----------------------------------------------------------------------------------------------
	Launches the properties dialog for the first selected item in the list control. If the
	user clicks on OK to exit that dialog (therefore implying a data change), updates the
	Explorer display.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmdFileProperties(Cmd * pcmd)
{
	// Retrieve the ID of the current list selection. If nothing is selected, then we are done.
	ExItem * pitem = m_qelvDataList->GetSelectedItem();
	if (NULL == pitem)
		return true;

	// Run the dialog. Redisplay the list if things have been changed.
	if (pitem->LaunchPropertiesDlg(Hwnd()))
		PropagateTreeSelection( FolderTreeIsActive() ? kctidFoldersTree : kctidToolsTree);

	return true;
}

/*----------------------------------------------------------------------------------------------
	It is possible to view a project's properties only if a project is selected.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmsFilePropertiesUpdate(CmdState & cms)
{
	ExItem * pitem = m_qelvDataList->GetSelectedItem();
	cms.Enable(pitem != NULL);

	// Indicate we have handled the command
	return true; 
}

/*----------------------------------------------------------------------------------------------
	Launches the wizard to create a new language project.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmdFileNewLangProj(Cmd * pcmd)
{
	ExNewLangProjWizardPtr pwlp;
	pwlp.Create();
	if( kctidOk == pwlp->DoModal(this->Hwnd()))
	{
		PropagateTreeSelection( FolderTreeIsActive() ? kctidFoldersTree : kctidToolsTree);
	}
	return true;
}


/*----------------------------------------------------------------------------------------------
	User command to open a new project into the Explorer. The method first calls the dialog
	by which the user navigates to the desired project; then adds the project to the list;
	and finally updates the UI to reflect the change. 
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmdFileOpenProject(Cmd * pcmd)
{
	AssertObj(pcmd);

	// Execute the File-Open dialog.
	DlgFileOpenPtr qdfo;
	qdfo.Create();
	if (!qdfo->DoModal(Hwnd()))
		return true;

	// Retrieve the selected project, if any, the database, and the server
	int nProjectId;
	StrUni stuProject;
	StrUni stuDatabase;
	StrUni stuMachine;
	GUID guid;
	if (false == qdfo->GetSelectedProject(nProjectId, stuProject, stuDatabase, stuMachine, &guid))
		return true;

	// Open the requested project
	m_root.AddLangProj(stuMachine, stuDatabase, guid);
	m_root.AddLastProjectToTree(m_qetvFolders);

	// Select the new project in the folders tree (if this is the active tree)
	HTREEITEM hItem = m_qetvFolders->FindItemByName(stuProject, TreeView_GetRoot(m_qetvFolders->Hwnd()));
	Assert(NULL != hItem);
	m_qetvFolders->SelectItem(hItem);

	// No propagate the tree's selection (no matter which tree is active) so that the list box
	// is properly updated. 
	PropagateTreeSelection( FolderTreeIsActive() ? kctidFoldersTree : kctidToolsTree);

	return true;
}


/*----------------------------------------------------------------------------------------------
	Close down the project. This means removing it from the vector (which deletes it), and
	removing it from the user interface. (When the Explorer shuts down, it will automatically
	update the registry, removing the project from it so that it will not be opened the
	next time Explroer is invokved.)
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmdFileCloseProject(Cmd * pcmd)
{
	AssertObj(pcmd);
	Assert(FolderTreeIsActive());

	// Retrieve the currently-selected project.
	ExProject * pproj = m_root.GetSelectedProject(m_qetvFolders);
	Assert(NULL != pproj);

	// Query the user. We don't want to close the project unless he confirms it.
	char szProjectName[kMax];
	StrUni stuProjectName = pproj->DisplayName();
	wcstombs( szProjectName, stuProjectName.Bstr(), kMax );
	if (IDYES != GetApp()->MessageBox(kstidProjCloseConfirm, MB_ICONQUESTION | MB_YESNO, 
		szProjectName))
	{
		return false;
	}

	// Retrieve the current selection from the tree
	HTREEITEM hItem = TreeView_GetSelection(m_qetvFolders->Hwnd());
	Assert(NULL != hItem);

	// Select the root of the tree, as our current selection will be deleted.
	HTREEITEM hItemRoot = TreeView_GetRoot(m_qetvFolders->Hwnd());
	Assert(NULL != hItemRoot);
	TreeView_SelectItem(m_qetvFolders->Hwnd(), hItemRoot);

	// Remove the selection from the tree. We prefer to remove it, rather than rebuild the tree, 
	// so that we don't loose whatever expansion, etc., the user has done to other parts of 
	/// the tree.
	m_qetvFolders->DeleteItem(hItem);

	// Remove the project from the vector of folders. (Note, for some reason dealing with
	// the smart pointers, we must remove it from the vector AFTER we have deleted it from
	// the tree. If we attempt to do it before, the TssTreeView's _OnDeleteItem gets called
	// twice; the second time resulting in an access violation.)
	m_root.RemoveProject(pproj);
	return true;
}


/*----------------------------------------------------------------------------------------------
	It is possible to delete a Project only if a project has been selected in the folders
	tree view (for that matter, the folders tree view must be visible.)
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmsFileCloseProjectUpdate(CmdState & cms)
{
	// If the folders tree view is not visible, disable the command.
	if (!FolderTreeIsActive())
		cms.Enable(false);

	// If a project is not currently selected in the folders tree, disable the command.
	if (NULL == m_root.GetSelectedProject(m_qetvFolders))
		cms.Enable(false);

	// Otherwise, all clear to delete. Enable the command.
	cms.Enable(true);

	// Indicate we have handled the command
	return true; 
}


/*----------------------------------------------------------------------------------------------
	Display dialog for file backup and restore
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmdFileBackup(Cmd * pcmd)
{
	AssertObj(pcmd);

	DIFwBackupDbPtr qzbkup;
	qzbkup.CreateInstance(CLSID_FwBackup);
//	qzbkup->Init((int)this, (int)Hwnd());
//REVIEW (TE Team): With KenZ's agreement, we put the NULL parameter in the following line
// to keep the compile from breaking. If Explorer is revived, we'll need to redesign
// how Explorer interfaces with the Backup feature.
	qzbkup->Init(NULL, (int)Hwnd());
	int nUserAction;
	qzbkup->UserConfigure((ComBool)false, &nUserAction);

	return true;
}


/*----------------------------------------------------------------------------------------------
	Displays the help dialog for the Explorer.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmdHelpAbout(Cmd * pcmd)
{
	AssertObj(pcmd);

	HelpAboutDlgPtr qabt;
	qabt.Create();
	qabt->DoModal(Hwnd());
	return true;
}


/***********************************************************************************************
	SWITCH LIST VIEW MODES
***********************************************************************************************/

// ENHANCE: Set the button state

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmdListModeToggle(Cmd * pcmd)
{
	AssertObj(pcmd);

	// Set the correct view in the List View control
	switch (pcmd->m_cid)
	{
	case kcidViewLargeIcons:
		m_qelvDataList->SetLargeIconMode();
		break;
	case kcidViewSmallIcons:
		m_qelvDataList->SetSmallIconMode();
		break;
	case kcidViewList:
		m_qelvDataList->SetListMode();
		break;
	case kcidViewDetails:
		m_qelvDataList->SetReportMode();
		break;
	}

	// Update the toolbar to show the current view
	AfToolBarPtr qtlb = GetToolBar(kctidTBarStd);
	SendMessage(qtlb->Hwnd(), TB_PRESSBUTTON, kcidViewLargeIcons, MAKELONG(FALSE,0));
	SendMessage(qtlb->Hwnd(), TB_PRESSBUTTON, kcidViewSmallIcons, MAKELONG(FALSE,0));
	SendMessage(qtlb->Hwnd(), TB_PRESSBUTTON, kcidViewList, MAKELONG(FALSE,0));
	SendMessage(qtlb->Hwnd(), TB_PRESSBUTTON, kcidViewDetails, MAKELONG(FALSE,0));
	SendMessage(qtlb->Hwnd(), TB_PRESSBUTTON, pcmd->m_cid, MAKELONG(TRUE,0));

	return true;
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::CmsListModeToggleUpdate(CmdState & cms)
{
	switch (cms.Cid())
	{
	case kcidViewLargeIcons:
		cms.SetCheck(m_qelvDataList->IsLargeIconMode());
		break;
	case kcidViewSmallIcons:
		cms.SetCheck(m_qelvDataList->IsSmallIconMode());
		break;
	case kcidViewList:
		cms.SetCheck(m_qelvDataList->IsListMode());
		break;
	case kcidViewDetails:
		cms.SetCheck(m_qelvDataList->IsReportMode());
		break;
	}
	return true;
}


/***********************************************************************************************
	...
***********************************************************************************************/



/*----------------------------------------------------------------------------------------------
	Called prior to creating the window.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::PreCreateHwnd(CREATESTRUCT & cs)
{
	AssertObj(this);
	AssertPsz(cs.lpszClass);
	CalcCreatePos(cs);
}


/*----------------------------------------------------------------------------------------------
	Sets the text and the icon of the caption bar, according to the current selection of the
	active tree (either the folders or the tools tree.)

	ENHANCE: We currently have to convert the wide string to single characters, because
	of the implementation of the caption bar. Need to change this someday if we are going to
	support unicode.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::UpdateCaptionBar()
{
	achar szCaption[kMax];
	extern ExplorerApp g_app;

	// Determine which tab is currently active (and thus which tree view)
	int iTab = TabCtrl_GetCurSel(m_hwndTab);
	Assert(-1 != iTab);
	int nTreeCaption = (iTab == 0) ? kstidCaptionFolder : kstidCaptionTool;
	ExTreeView * petv = m_qetvFolders;
	if (iTab == 1)							// compiler choked on the ?: statement. :(
		petv = m_qetvTools;

	// Get the icon and text of the current selection in the tree view
	int iIcon;
	ITsStringPtr qtss;
	int nResult = petv->GetCurrentSelection(&iIcon, qtss);

	// If nothing is selected, it means we have nothing in the tree to select, and therefore
	// nothing to display in the list box and caption bar. 
	if (0 == nResult)
	{
		int cCharsLoaded = LoadString(g_app.GetInstance(), kstidEmptyCaption, szCaption, kMax);
		Assert(0 != cCharsLoaded);				// The resource should exist
		m_qcpbrCaptionBar->SetCaptionText(szCaption);
		m_qcpbrCaptionBar->SetIconImage(0, 0);
		return;
	}

	// Convert the string to something we can display (single-wide characters)
	BSTR bstr;
	qtss->get_Text(&bstr);
	char szName[kMax];
	wcstombs(szName, (const wchar_t *)(bstr), kMax);

	// Retrieve the appropriate "mother" string from the resources
	achar szFormat[kMax];
	int cCharsLoaded = LoadString(g_app.GetInstance(), nTreeCaption, szFormat, kMax);
	Assert(0 != cCharsLoaded);				// The resource should exist

	// Create the joined string, and set the caption bar's content to it.
	_stprintf(szCaption, szFormat, szName);
	m_qcpbrCaptionBar->SetCaptionText(szCaption);
	m_qcpbrCaptionBar->SetIconImage(0, iIcon);
}


/*----------------------------------------------------------------------------------------------
	One of the two trees on the left has had a selection change.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::PropagateTreeSelection(UINT nIdTree)
{
	// If the Folders tree
	if (kctidFoldersTree == nIdTree)
	{
		// Get the selected Folder
		ExFolder * pfold = m_qetvFolders->GetSelectedFolder();
 
		// Update the content of the various controls in the Explorer
		UpdateListControl(pfold);
		UpdateCaptionBar();
		FillCombo(pfold);
	}

	// Else it is the Tools tree
	else if (kctidToolsTree == nIdTree)
	{
		// Get the selected Tool
		ExTool * ptool = m_qetvTools->GetSelectedTool();

		// Update the content of the various controls in the Explorer
		UpdateListControl(ptool);
		UpdateCaptionBar();
		FillCombo(ptool);
	}
}


/*----------------------------------------------------------------------------------------------
	Update the contents of the list control with pfold as the parent.

	Parameters:
		pfold - a pointer to the parent folder that we will use to populate the list control.
			If NULL, it means we are at the root of the tree control, and therefore wish
			to populate the list with the projects. 

	ENHANCE: Should we display a "dalam process" indicator if this leads to a sql call?
----------------------------------------------------------------------------------------------*/
void ExMainWnd::UpdateListControl(ExFolder * pfold)
{
	// Start with an empty list.
	m_qelvDataList->DeleteAllItems();

	// If we have a value for the folder, then get the corresponding documents and subfolders
	// from the sql database and put them into the list control.
	if (NULL != pfold)
	{
		pfold->UpdateDocumentList();
		pfold->PlaceChildrenIntoListControl(m_qelvDataList);
	}

	// Otherwise, we are at the root of the tree, and we need to just put the current set of
	// projects into the list control.
	else
	{
		for(int i=0; i<m_root.NumberOfProjects(); i++)
			m_root.GetProject(i)->PlaceIntoListControl(m_qelvDataList);
	}
}


/*----------------------------------------------------------------------------------------------
	Update the contents of the list control, listing all documents for which ptool can be run.

	Parameters:
		ptool - a pointer to the tool that we will use to populate the list control.
			If NULL, it means we are at the root of the tree control, and therefore should
			result in an empty list.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::UpdateListControl(ExTool * ptool)
{
	// Start with an empty list.
	m_qelvDataList->DeleteAllItems();

	// If (and only if) we have a value for the tool, then get the corresponding documents 
	// and put them into the list control.
	if (NULL != ptool)
	{
		for(int i = 0; i < m_root.NumberOfProjects(); i++)
		{
			m_root.GetProject(i)->PlaceDescendantDocumentsIntoListControl(
				ptool->GetDocumentType(), m_qelvDataList);
		}
		m_qelvDataList->SortList();
	}
}


/*----------------------------------------------------------------------------------------------
	Populates the combo box with the currently-available tools.

	Note: For the tools version of the combo box, we do not show a root node, because it 
	would be meaningless to select it in terms of propagating the selection to the tree and
	list controls.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::FillCombo(ExTool * ptoolTarget)
{
	int nItemNo = 0;
	int nTargetItem = 0;

	// Clear out the combo box
	m_qecbPathnameCombo->ResetContent();

	// Insert the tools. (They are all at the top level in our current implementation)
	for(int i = 0; i < m_root.NumberOfTools(); i++)
	{
		ExTool * ptool = m_root.GetTool(i);
		if (ptool == ptoolTarget)
			nTargetItem = nItemNo;
		ptool->PlaceIntoComboControl(m_qecbPathnameCombo, nItemNo++);
	}

	// The target tool should exist now. Select it.
	::SendMessage(m_qecbPathnameCombo->Hwnd(), CB_SETCURSEL, WPARAM(nTargetItem), 0);
}


/*----------------------------------------------------------------------------------------------
	Clears out the combo box, then places into it the folder hierarchy as appropriate for the
	currently selected folder in the Folder Tree view (which is passed in as pfoldTarget). The
	function calls a worker function, _FillCombo, which works recursively through the folders 
	to insert them. The goal is to show:
	   a. The Root (e.g., My Data),
	   b. All of the Projects under the root
	   c. The hierarchy down to the currently-selected node in the tree
	   d. The child folders of this node.
	This mimics the Win95 Explorer (though the IE 4.0 user interface has changed this behavior
	somewhat.

	Parameter:
		pfoldTarget - a pointer to the folder which has been selected in the tree view.
----------------------------------------------------------------------------------------------*/
void ExMainWnd::FillCombo(ExFolder * pfoldTarget)
{
	int nItemNo = 0;
	int nLevel	= 0;
	int nTargetItem = 0;

	// Clear out the combo box
	m_qecbPathnameCombo->ResetContent();

	// Insert the "My Data" node
	extern ExplorerApp g_app;
	StrUni stu;
	g_app.LoadStuFromResources(kstidRootFolders, stu);
	InsertIntoComboControl(m_qecbPathnameCombo, stu, kridFileCabinetClosed, nItemNo++, 
		nLevel, NULL);

	// Insert the projects. We either recurse down the nodes (by calling _FillCombo
	// until we get to the target folder, or we just add all of the projects. That is, 
	// we want all of the projects, whether they contain the target folder or not.
	for(int i = 0; i < m_root.NumberOfProjects(); i++)
	{
		ExProject * pProj = m_root.GetProject(i);
		if (pProj->ContainsFolder(pfoldTarget))
			nTargetItem = _FillCombo(pfoldTarget, pProj, nLevel + 1, &nItemNo);
		else
		{
			// Add the project
			pProj->PlaceIntoComboControl(m_qecbPathnameCombo, nItemNo++, nLevel + 1);

			// If this project is our target, we want to add its children also.
			if (pProj == pfoldTarget)
			{
				nTargetItem = nItemNo - 1;		// We had already incremented when we added it
				for(int k = 0; k < pfoldTarget->m_vqfold.Size(); k++)
					pfoldTarget->m_vqfold[k]->PlaceIntoComboControl(m_qecbPathnameCombo, 
					nItemNo++, nLevel + 2);
			}
		}
	}

	// The target folder should exist now. Select it.
	::SendMessage(m_qecbPathnameCombo->Hwnd(), CB_SETCURSEL, WPARAM(nTargetItem), 0);
}


/*----------------------------------------------------------------------------------------------
	Recursive helper function for filling the combo control with the path to the currently
	selected folder.

	Parameters:
		pfoldTarget - a pointer to the folder which has been selected in the tree view.
		pfoldCurrent - Used recursively to tell the method at what node we are currently 
			processing.
		nLevel - A reference to how many levels down the hierarchy we have travelled. Each
			level is indented 10 pixels within the combo control.
		nItemNo - a pointer to the zero-based index of the string being inserted into the
			list part of the combo box. That is, this is the item number at which we do
			an insertion into the list.
----------------------------------------------------------------------------------------------*/
int ExMainWnd::_FillCombo(ExFolder * pfoldTarget, ExFolder * pfoldCurrent, int nLevel, 
	int * nItemNo)
{
	Assert(NULL != pfoldTarget);
	Assert(NULL != pfoldCurrent);
	Assert(true == pfoldCurrent->ContainsFolder(pfoldTarget));
	Assert(NULL != nItemNo);
	Assert( *(nItemNo) > 0);
	Assert( nLevel > 0);

	// Put the pfoldCurrent into the combo box
	pfoldCurrent->PlaceIntoComboControl(m_qecbPathnameCombo, *nItemNo, nLevel);
	(*nItemNo)++;

	// Now search through its children to run down the hierarchy to the target.
	for(int i = 0; i < pfoldCurrent->m_vqfold.Size(); i++)
	{
		ExFolder *pfoldChild = pfoldCurrent->m_vqfold[i];

		// If we found the target, then add it and its children and then we're done
		if (pfoldChild == pfoldTarget)
		{
			int nTargetItemNo = *nItemNo;
			pfoldChild->PlaceIntoComboControl(m_qecbPathnameCombo, 
					(*nItemNo)++, nLevel + 1);

			for(int k = 0; k < pfoldChild->m_vqfold.Size(); k++)
			{
				pfoldChild->m_vqfold[k]->PlaceIntoComboControl(m_qecbPathnameCombo, 
					(*nItemNo)++, nLevel + 2);
			}
			return nTargetItemNo;
		}

		// Otherwise, continue the recursive calls
		else if (pfoldCurrent->m_vqfold[i]->ContainsFolder(pfoldTarget))
		{
			return _FillCombo(pfoldTarget, pfoldCurrent->m_vqfold[i], nLevel + 1, nItemNo);
		}
	}
	return -1;
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::PropagateComboSelection()
{
	// Retrieve the new selection from the combo box
	FW_COMBOBOXEXITEM fcbi;
	fcbi.iItem = m_qecbPathnameCombo->GetCurSel();
	Assert(CB_ERR != fcbi.iItem);
	fcbi.mask = CBEIF_TEXT | CBEIF_LPARAM;
	m_qecbPathnameCombo->GetItem(&fcbi);

	// Locate it in the tree control. (We cannot assume unique strings in the tree control.)
	// We have stored the HTREEITEM's in the combo box for just this purpose. A NULL value
	// means the user has selected the root ("My Data").
	HTREEITEM hTreeItem = (HTREEITEM)fcbi.lParam;

	// Get the current tree control selection. 
	HTREEITEM hCurSel = TreeView_GetSelection(m_qetvFolders->Hwnd());

	// If these are the same thing, then we need do nothing else. 
	// The test against the current tree control selection is how we ensure we don't get into
	// calling this method forever (since changing the tree control will therefore change the
	// combo control which would then change the tree control, ad infinitum.)
	if (NULL != hTreeItem && hTreeItem == hCurSel)
		return true;
	HTREEITEM hTreeRoot = FolderTreeIsActive() ? 
		TreeView_GetRoot(m_qetvFolders->Hwnd()) :
		TreeView_GetRoot(m_qetvTools->Hwnd());
	if (NULL == hTreeItem && hCurSel == hTreeRoot)
		return true;

	// Select it into the tree control if it isn't already selected. This will then fire the
	// normal mechanisms for populating the list control and re-populating the combo control.
	if (FolderTreeIsActive())
		m_qetvFolders->SelectItem((hTreeItem == NULL) ? hTreeRoot : hTreeItem);
	else
		m_qetvTools->SelectItem((hTreeItem == NULL) ? hTreeRoot : hTreeItem);
	return true;
}

/*----------------------------------------------------------------------------------------------
	Retrieves the currently selected item from the list box, and launches the default tool
	for that item.

	ENHANCE: Hook up the Data Notebook and other tools to this.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::LaunchDefaultToolOnListSelection()
{
	// Get the index of the selected item.
	ExItem * pitem = m_qelvDataList->GetSelectedItem();
	if (NULL == pitem)
		return true;

	// Convert to a ExDocument, if possible
	ExDocument * pdoc = dynamic_cast<ExDocument *>(pitem);
	if (NULL == pdoc)
		return true;

	// We'll need the document's owning project in order to know which server/database
	// we want to open.
	ExProject * pprj = pdoc->GetOwningProject();
	Assert(NULL != pprj);

	// Retrieve the identifier of the tool we wish to launch. If it is IID_IUnknown, we do
	// not have a tool defined for the document.
	REFIID riid = pdoc->GetRefiid();
	if (IID_IUnknown == riid)
		return true;

	// Launch the requested application. (Note: the two bstr temporary variables are needed,
	// rather than placing Get() methods inline, due to some paramemeter-passing compiler
	// bug that was zeroing out the value of GetDatabase.
	IFwToolPtr qft;
	try
	{
		CWaitCursor wait;
		qft.CreateInstance(riid);
		long htool;
		int pidNew;
		BSTR bstrServer = pprj->GetServer();
		BSTR bstrDatabase = pprj->GetDatabase();
		CheckHr(qft->NewMainWnd(bstrServer, bstrDatabase, 
			pprj->GetId(), pdoc->GetId(), GetApp()->GetUIWritingSystem(), 
			0, // tool-dependent identifier of which tool to use; does nothing for RN yet
			0, // another tool-dependend parameter, does nothing in RN yet
			&pidNew,
			&htool)); // value you can pass to CloseMainWnd if you want.
	}
	catch (...)
	{
		GetApp()->ErrorBox(kstidErrCannotLaunchApp);
		return true;
	}

	return true;
}


/*----------------------------------------------------------------------------------------------
	These functions test for various messages that may have been sent to FWndProc. They are
	only used from within FWndProc.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::TestComboSelectionChanged(uint wm, WPARAM wp)
{
	return WM_COMMAND == wm && 
		   CBN_SELCHANGE == HIWORD(wp) && 
		   kctidPathnameCombo == (int) LOWORD(wp);
}
bool ExMainWnd::TestListItemDoubleClicked(uint wm, LPARAM lp)
{
	NMHDR * pnmhdr = (NMHDR *)lp;
	NMLISTVIEW * pnmInfo = (NMLISTVIEW *)lp;
	return WM_NOTIFY == wm && 
		   NM_DBLCLK == pnmhdr->code && 
		   kctidDocList == pnmhdr->idFrom && 
		   -1 != pnmInfo->iItem;
}


/*----------------------------------------------------------------------------------------------
	Handle window messages.
----------------------------------------------------------------------------------------------*/
bool ExMainWnd::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
	AssertObj(this);
	Assert(!lnRet);
	extern ExplorerApp g_app;

	// The user has selected something new in the pathname combo control
	if (TestComboSelectionChanged(wm, wp))
		return PropagateComboSelection();

	// The user has double-clicked on an item in the list box
	if (TestListItemDoubleClicked(wm, lp))
		return LaunchDefaultToolOnListSelection();


	switch (wm)
	{
	case WM_CLOSE:
		// Save the currently open projects to the registry
		m_root.SaveToRegistry();

		// Store window coordinates in the registry
		SaveWindowPos();

		// the superclass will do any other processing
		break;

	case WM_MOUSEMOVE:
		return OnMouseMove(wp, (int)(short)LOWORD(lp), (int)(short)HIWORD(lp));

	case WM_LBUTTONDOWN:
		return OnLButtonDown(wp, (int)(short)LOWORD(lp), (int)(short)HIWORD(lp));

	case WM_LBUTTONUP:
		return OnLButtonUp(wp, (int)(short)LOWORD(lp), (int)(short)HIWORD(lp));

	case WM_KEYDOWN:
		return OnKeyDown(wp, lp);

	// Restore focus to the appropriate child control. (See the note on NM_SETFOCUS in the
	// WM_NOTIFY section.)
	case WM_SETFOCUS:
		if (NULL != m_hwndChildWithCurrentFocus)
		{
			::SetFocus(m_hwndChildWithCurrentFocus);
			return true;
		}
		return false;

	case WM_NOTIFY: 
		{
			NMHDR * pnmhdr = (NMHDR *)lp;

			// Selection has changed in the tab control; set tree window visibility accordingly
			if (m_hwndTab == pnmhdr->hwndFrom && TCN_SELCHANGE == pnmhdr->code)
			{
				SetTreeVisibility();
				return true;
			}
			// Selection has changed in a tree control
			else if (TVN_SELCHANGED == pnmhdr->code)
			{
				PropagateTreeSelection(pnmhdr->idFrom);
				return true;
			}
			// One of the child windows has received focus. We want to remember this, so that
			// if the main frame window looses focus (e.g., another app is made active) and then
			// receives focus again, we can reactivate the appropriate child.
			else if (NM_SETFOCUS  == pnmhdr->code || CBEN_BEGINEDIT == pnmhdr->code)
			{
				m_hwndChildWithCurrentFocus = pnmhdr->hwndFrom;
				return true;
			}
		}
		break;

	}

	return SuperClass::FWndProc(wm, wp, lp, lnRet);
}

