/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: ExCM.cpp
Responsibility: John Wimbish
Last reviewed:

	Implementation of the conceptual model classes defined in ExCM.h

    ENHANCE: 
       - Remove the "Unknown Project Name" string and put it into the resources.
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop
#undef THIS_FILE
DEFINE_THIS_FILE

#define kMax 512                            // Generic size of buffers for retrieving text

#include "Vector_i.cpp"  
template class Vector<ExFolderPtr>;

extern ExplorerApp g_app;

/***********************************************************************************************
    EXITEM IMPLEMENTATION
************************************************************************************************/

/*----------------------------------------------------------------------------------------------
    Constructor
----------------------------------------------------------------------------------------------*/
ExItem::ExItem()
{
    m_luId = 0; 
    m_luIdOwner = 0;
    m_pprj = NULL;
}


/*----------------------------------------------------------------------------------------------
    Run the Properties dialog on this item.
----------------------------------------------------------------------------------------------*/
bool ExItem::LaunchPropertiesDlg(HWND hwnd)
{
    ExDlgPropertiesPtr dlp;
    dlp.Create();
    dlp->Init(this);
    return kctidOk == dlp->DoModal(hwnd);
}

/*----------------------------------------------------------------------------------------------
    Retrieves a string appropriate for the user interface to describe the type of item.
----------------------------------------------------------------------------------------------*/
void ExItem::GetType(achar * pszDest, uint cchMax, uint rid)
{
    Assert(cchMax > 0);
    achar szBuffer[kMax];
    int cCharsLoaded = ::LoadString(g_app.GetInstance(), rid, szBuffer, kMax);
    Assert(0 != cCharsLoaded);
    *pszDest = '\0';
    if (cchMax >= (uint)cCharsLoaded)
        _tcscpy(pszDest, szBuffer);
}

/*----------------------------------------------------------------------------------------------
    Returns the description for the item. This is a "load on demand" method, in that if we
    have an empty value, we query the database for the desired value. The value is stored
    in sql as a BigString; here we store it locally as a StrUni.
----------------------------------------------------------------------------------------------*/
const StrUni & ExItem::GetDescription()
{
    if (0 == m_stuDescription.Length())
    {
        Assert(NULL != m_pprj);
        StrUni stuCommand;
        stuCommand.Format(
            L"select Txt from MultiBigStr$ (readuncommitted) " \
            L"where flid = ( " \
	        L"    select id from Field$ " \
	        L"    where name='Description' and class = ( " \
		    L"        select id from class$ where name='%s' " \
		    L"        ) " \
	        L"    ) " \
            L"and Ws = %d and Obj = %d " ,
            IsDocument() ? L"CmMajorObject" : L"CmFolder",
            g_app.GetUIWritingSystem(), m_luId);
        if (m_pprj->m_sql.GetNextRow(stuCommand))
            m_pprj->m_sql.GetColumnStu(1, m_stuDescription, true);
        m_pprj->m_sql.CloseCommand();
    }
    return m_stuDescription;
}

/*----------------------------------------------------------------------------------------------
    Saves the description both to this internal class, but also out to the sql database. 
----------------------------------------------------------------------------------------------*/
void ExItem::SetDescription(const StrUni & stuDescription)
{
    m_stuDescription = stuDescription;

    ITsStringPtr qtssDescription;
    g_app.MakeUIString(m_stuDescription, qtssDescription);

    m_pprj->m_sql.SetTss(qtssDescription, m_luId, 
        IsDocument() ? kflidCmMajorObject_Description : kflidCmFolder_Description, true);
}


/*----------------------------------------------------------------------------------------------
    Saves the name both to this internal class, but also out to the sql database. 
----------------------------------------------------------------------------------------------*/
void ExItem::SetName(const StrUni & stuName)
{
    m_stuName = stuName;

    ITsStringPtr qtssName;
    g_app.MakeUIString(m_stuName, qtssName);

    ulong luIdString;

    if (IsDocument())
    {
   	    StrUni stuCommand;
        stuCommand.Format(L"select id from CmFolderObject (readuncommitted) where Object='%d'",
			m_luId);
        m_pprj->m_sql.GetNextRow(stuCommand);
        m_pprj->m_sql.GetColumnNumeric(1, &luIdString);
        m_pprj->m_sql.CloseCommand();
    }
    else
    {
        luIdString = m_luId;
    }

    m_pprj->m_sql.SetTss(qtssName, luIdString, 
        IsDocument() ? kflidCmFolderObject_Name : kflidCmFolder_Name, false);
}


/***********************************************************************************************
    EXFOLDER IMPLEMENTATION
************************************************************************************************/

/*----------------------------------------------------------------------------------------------
    Checks to make certain that we have a valid internal state for debugging purposes.

    The IsFullyInitialized method returns true when both initializations have
    taken place. Thus in all methods other than the initialization ones, we want to
    check:
       AssertObj - which makes certain AssertValid is called,
       Assert(IsFullyInitialized()) - which makes certain that when AssertValid was
            called, that it tested for a complete initialization of everything.
----------------------------------------------------------------------------------------------*/
#ifdef DEBUG
bool ExFolder::AssertValid() const
{
  	AssertPtr(this);
    switch (m_nInitialized)
    {
    case kTree:
        Assert(NULL != m_hTreeItem);
        // Fall through

    case kProj:
        AssertPtr(m_pprj);
        Assert(0 != m_luId);
        Assert(0 != m_luIdOwner);
        // Fall through

    case kNo:
        break;

    default:
        Assert(false);
    }
	return true;
}
#endif


/*----------------------------------------------------------------------------------------------
    Constructor. Sets the Id and the IdOwner to zero. The ExFolder is not valid until it 
    has a nonzero Id.
----------------------------------------------------------------------------------------------*/
ExFolder::ExFolder() : ExItem()
{
    m_nInitialized = kNo;
    m_hTreeItem = NULL;
}

/*----------------------------------------------------------------------------------------------
    Initialization Step #1 of 2 - Initializes the information about each folder that we pull 
    from the rowset describing each folder in sql. Additional initialization is required before 
    operations involving the Explorer's controls can be done.
----------------------------------------------------------------------------------------------*/
void ExFolder::Init(ulong luId, ulong luIdOwner, SilTime stimCreated, StrUni & stuName,
    ExProject * pprj)
{
    AssertObj(this);
    AssertPtr(pprj);
    m_luId = luId;
    m_luIdOwner = luIdOwner;
    m_stimCreated = stimCreated;
    m_stuName = stuName;
    m_pprj = pprj;
    m_nInitialized = kProj;
}


/*----------------------------------------------------------------------------------------------
    Initialization Step #2 of 2 - Initializes the ExFolder to have a valid HTREEITEM.

    Parameters:
        hItem - the HTREEITEM within the tree that this folder is represented by.
----------------------------------------------------------------------------------------------*/
void ExFolder::SetTreeItem(HTREEITEM hItem)
{
    Assert(NULL != hItem);
    AssertObj(this);
    Assert(kNo != m_nInitialized);

    m_hTreeItem = hItem;
    m_nInitialized = kTree;
}


/*----------------------------------------------------------------------------------------------
    Adds this folder and its subfolders to the tree control. This method is re-entrant, meaning 
    that it updates the tree to match the folder contents, rather than deleting and starting 
    over. (The purpose is so that the Explorer's tree can be refreshed as the data changes 
    without necessarily having to change what is displayed to the user, in terms of what nodes 
    have been expanded, etc.)

    The method calls itself recursively in order to update the various nodes underneath 
    this one.

    Parameters:
        qetv - the tree to update
        hParent - the node which will be the parent of this folder's data.
----------------------------------------------------------------------------------------------*/
void ExFolder::AddToTree(ExFolderTreeViewPtr & qetv, HTREEITEM hParent)
{
    AssertObj(this);

	if (!qetv)
		return;

    // If hParent is NULL, then we want to use as the hParent the first child (e.g.,
    // the one called 'My Data'.) We do not want the TVI_ROOT.)
    if (NULL == hParent)
    {
        hParent = TreeView_GetChild(qetv->Hwnd(),TVI_ROOT);
        Assert(NULL != hParent);  // Improperly initialized tree
    }

    // Iterate through the parent's children to find the item (by name) if it already exists
    HTREEITEM hChild = qetv->FindItemByName(DisplayName(), hParent);

    // If it wasn't found, go ahead and add it.
    if (NULL == hChild)
    {
        FW_TVITEM item;
        hChild = qetv->InsertItem(this, hParent);
        SetTreeItem(hChild);
    }
    Assert(NULL != hChild);

    // Re-entrance support. Look through this child's children. If there are any that are not
    // in this ExFolder, then remove them from the tree. The other's we'll leave alone.
    FW_TVITEM itemGrandChild;
    itemGrandChild.mask = TVIF_TEXT;
    HTREEITEM hGrandChild = TreeView_GetChild(qetv->Hwnd(), hChild);
    BSTR bstrGrandChild;
    int i;
    while (NULL != hGrandChild)
    {
        // Get the string for this child in the tree
        itemGrandChild.hItem = hGrandChild;
        qetv->GetItem(&itemGrandChild);
        itemGrandChild.qtss->get_Text(&bstrGrandChild);

        // Scan through the folder list, looking for this string
        for(i=0; i<m_vqfold.Size(); i++)
        {
            if ( 0 == wcscmp(bstrGrandChild, m_vqfold[i]->m_stuName.Bstr()) )
                break;
        }

        // If we didn't find it, then we must delete the child from the tree. (Also, must
        // restart the iteration since the grandchild list has changed.)
        if (i == m_vqfold.Size())
        {
            TreeView_DeleteItem(qetv->Hwnd(), hGrandChild);
            hGrandChild = TreeView_GetChild(qetv->Hwnd(), hChild);
        }
        // Otherwise keep iterating through the grandchildren
        else
            hGrandChild = TreeView_GetNextSibling(qetv->Hwnd(), hGrandChild);
    }

    // Recurse as to add the subfolders to the tree
    int iMax = m_vqfold.Size();
    for(i=0; i<iMax; i++)
    {
        m_vqfold[i]->AddToTree(qetv, hChild);
    }

}

/*----------------------------------------------------------------------------------------------
	...

        select  mo.Id, fObjName.Txt, mo.DateCreated, mo.DateModified, c.Name, 
                mo.Guid$, mo.Class$
        from    CmMajorObject_ mo
        join    class$ c on mo.Class$=c.id
        join    cmfolderobject_ fObj on fObj.Object = mo.Id
        join    cmfolderobject_name fObjName on fObjName.Obj=fObj.Id
        where   fobj.owner$ = <folder id>
        and     fobjName.ws = (select Code from LgWritingSystem where Abbr = '<writing system name>') 

----------------------------------------------------------------------------------------------*/
int ExFolder::UpdateDocumentList()
{
    AssertObj(this);
    Assert(IsFullyInitialized());
    AssertPtr(m_pprj);

    // Create the command syntax
    StrUni stuCommand;
    stuCommand.Format(
        L"select  mo.Id, fObjName.Txt, mo.DateCreated, mo.DateModified, c.Name, " \
        L"        fobj.owner$, mo.Guid$, mo.Class$ " \
        L"from    CmMajorObject_ mo (readuncommitted) " \
        L"join    class$ c on mo.Class$=c.id " \
        L"join    cmfolderobject_ fObj (readuncommitted) on fObj.Object = mo.Id " \
        L"join    cmfolderobject_name fObjName (readuncommitted) on fObjName.Obj=fObj.Id " \
        L"where   fobj.owner$ = %u " \
        L"and     fobjName.ws = %d",
        m_luId, g_app.GetUIWritingSystem());

    // Execute the command, creating a ExDocument for each resultant row
    ExDocumentPtr qdoc;
    m_vqdoc.Clear();
    while (m_pprj->m_sql.GetNextRow(stuCommand))
    {
        qdoc.Create();
        qdoc->InterpretSqlRow(m_pprj);
        InsertChildDocument(qdoc);
    }

    // Done
    return EXIT_SUCCESS;
}


/*----------------------------------------------------------------------------------------------
    ...
----------------------------------------------------------------------------------------------*/
void ExFolder::InsertChildDocument(ExDocumentPtr & qdoc)
{
    AssertObj(this);
    m_vqdoc.Insert( m_vqdoc.Size(), qdoc);
}


/*----------------------------------------------------------------------------------------------
    Moves folders from a vector of folders to the folders vector within this ExFolder. First
    clears out the target vector, in case there is anything there from previous times of
    building the tree. Then, scans through the source vector for any folders whose Owner
    is this folder. The method calls itself recursively in order to populate the child
    folders as well.

    Parameters:
        vqfold - the source vector, containing all of the folders which have yet to be
            placed into an ExFolder.
----------------------------------------------------------------------------------------------*/
void ExFolder::_InitFoldersFromVector(FoldV & vqfold, ExProject * pprj)
{
    AssertObj(this);
    Assert(m_luId != 0);

    // Remove any subfolders from previous tree builds
    m_vqfold.Clear();

    // Loop through every item in the source vector
    int iLim = vqfold.Size();
    for(int i=0; i<iLim; i++)
    {
        if (vqfold[i] && vqfold[i]->m_luIdOwner == m_luId)
        {
            // Transfer the folder from source vector to this ExFolder's vector
            m_vqfold.Insert( m_vqfold.Size(), vqfold[i]);
            vqfold[i] = NULL;

            // Recurse so as to build children folders
            m_vqfold[ m_vqfold.Size()-1 ]->_InitFoldersFromVector(vqfold, pprj);
        }
    }
}


/*----------------------------------------------------------------------------------------------
    ...
----------------------------------------------------------------------------------------------*/
void ExFolder::PlaceChildrenIntoListControl(ExListViewPtr & qelvDataList)
{
    AssertObj(this);
    Assert(IsFullyInitialized());

    int i;

    // Add in the subfolders
    for(i=0; i<m_vqfold.Size(); i++)
        m_vqfold[i]->PlaceIntoListControl(qelvDataList);

    // Add in the documents
    for(i=0; i<m_vqdoc.Size(); i++)
        m_vqdoc[i]->PlaceIntoListControl(qelvDataList);

    // Sort the contents of the list control
    qelvDataList->SortList();
}


/*----------------------------------------------------------------------------------------------
    Adds the documents of this folder and its descendants into the list control. Only adds
    those documents which match the nDocType.
----------------------------------------------------------------------------------------------*/
void ExFolder::PlaceDescendantDocumentsIntoListControl(int nDocType, ExListViewPtr & qelvDataList)
{
    AssertObj(this);
    Assert(IsFullyInitialized());

    int i;

    // Add in the documents, if any
    for(i = 0; i < m_vqdoc.Size(); i++)
    {
        if (m_vqdoc[i]->DocumentType() == nDocType)
            m_vqdoc[i]->PlaceIntoListControl(qelvDataList);
    }

    // Recurse through the subfolders, if any
    for(i = 0; i < m_vqfold.Size(); i++)
    {
        m_vqfold[i]->PlaceDescendantDocumentsIntoListControl(nDocType, qelvDataList);
    }
}


/*----------------------------------------------------------------------------------------------
    ...
----------------------------------------------------------------------------------------------*/
void ExFolder::PlaceIntoComboControl(AfToolBarComboPtr & qecbCombo, int iItemNo, int nIndent)
{
    AssertObj(this);
    Assert(IsFullyInitialized());
    Assert(NULL != m_hTreeItem);

    InsertIntoComboControl(qecbCombo, DisplayName(), GetIcon(), iItemNo, nIndent, m_hTreeItem);
}


/*----------------------------------------------------------------------------------------------
    Retrieves a string appropriate for the user interface to describe the type of item (in 
    this case, a folder.)
----------------------------------------------------------------------------------------------*/
void ExFolder::GetType(achar * pszDest, uint cchMax)
{
    ExItem::GetType(pszDest, cchMax, kstidTypeFolder);
}

/*----------------------------------------------------------------------------------------------
    Retrieves a string appropriate for the user interface to describe the number of items
    this object owns.
----------------------------------------------------------------------------------------------*/
void ExFolder::GetSizePhrase(achar * pszDest, uint cchMax)
{
    Assert(cchMax > 0);

    achar szFormat[kMax];

    int cCharsLoaded = ::LoadString(g_app.GetInstance(), kstidSizeFolder, szFormat, kMax);
    Assert(0 != cCharsLoaded);

    ulong cluItems = m_vqfold.Size() + m_vqdoc.Size();

    if (cchMax > _tcslen(szFormat) + 10)
        _stprintf(pszDest, szFormat, cluItems);
    else
        *pszDest = '\0';
}

/*----------------------------------------------------------------------------------------------
    Retrieves a string appropriate for the user interface to describe the location of this
    object.
----------------------------------------------------------------------------------------------*/
void ExFolder::GetLocation(achar * pszDest, uint cchMax)
{
    Assert(cchMax > 0);

    // Recurse all the way up the ownership hierarchy until we reach the project level. 
    if (m_pprj != this)
    {
        ExFolder * pfoldOwner = m_pprj->FindFolder(m_luIdOwner);
        pfoldOwner->GetLocation(pszDest, cchMax);
    }
    else
        *pszDest = '\0';                    // At top level, make it an empty string

    // Concatenate this ExFolder's name to the destination string
	StrApp strName(m_stuName);
//-    achar szName[kMax];
//-#ifdef UNICODE
//-	wcsncpy(szName, m_stuName.Chars(), kMax);
//-#else
//-	wcstombs(szName, m_stuName.Chars(), kMax);
//-#endif
//-    if (_tcslen(szName) + _tcslen(pszDest) + 1 < cchMax)
//-        _tcscat(pszDest, szName);
    if (strName.Length() + _tcslen(pszDest) + 1 < cchMax)
        _tcscat(pszDest, strName.Chars());

    // Concatenate the ending marker
    if (_tcslen(pszDest) + 3 < cchMax)
    {
        if (m_pprj == this)
            _tcscat(pszDest, _T(":"));
        _tcscat(pszDest, _T("\\"));
    }
}


/*----------------------------------------------------------------------------------------------
    ...
----------------------------------------------------------------------------------------------*/
void ExFolder::PlaceIntoListControl(ExListViewPtr & m_qelvDataList)
{
    AssertObj(this);
    Assert(IsFullyInitialized());

    achar szBuffer[kMax];
    achar szDate[kMax];
#ifndef UNICODE
    wchar wszBuffer[kMax];
    wchar wszDate[kMax];
#endif

    // Initialize a structure for each column in the list
    FW_LVITEM lviText(LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM, 0, 0);
    FW_LVITEM lviSize(LVIF_TEXT, 0, 1);
    FW_LVITEM lviType(LVIF_TEXT, 0, 2);
    FW_LVITEM lviModi(LVIF_TEXT, 0, 3);
    FW_LVITEM lviCrea(LVIF_TEXT, 0, 4);

    // Initialize the strings we will place into each column
    lviText.iImage = GetIcon();
    lviText.lParam = (LPARAM)this;
    g_app.MakeUIString(m_stuName, lviText.qtss);

    // Type (e.g., "Folder")
    GetType(szBuffer, kMax);
#ifdef UNICODE
	g_app.MakeUIString(szBuffer, kMax, lviType.qtss);
#else
	mbstowcs((wchar *)wszBuffer, (char *)szBuffer, kMax);
	g_app.MakeUIString(wszBuffer, kMax, lviType.qtss);
#endif

    // Size phrase
    achar szSizePhrase[kMax];
    GetSizePhrase(szSizePhrase, kMax);
#ifdef UNICODE
    g_app.MakeUIString(szBuffer, kMax, lviSize.qtss);
#else
	mbstowcs((wchar *)wszBuffer, (char *)szSizePhrase, kMax);
    g_app.MakeUIString(wszBuffer, kMax, lviSize.qtss);
#endif

    // Create Date
    _stprintf(szDate, _T("%d/%02d/%d"), m_stimCreated.Month(), m_stimCreated.Date(), 
        m_stimCreated.Year());
#ifdef UNICODE
    g_app.MakeUIString(szDate, kMax, lviCrea.qtss);
#else
	mbstowcs((wchar *)wszDate, (char *)szDate, kMax);
    g_app.MakeUIString(wszDate, kMax, lviCrea.qtss);
#endif

    // Place the strings into the list 
    m_qelvDataList->InsertItem(&lviText);
    m_qelvDataList->SetItem(&lviSize);
    m_qelvDataList->SetItem(&lviType);
    m_qelvDataList->SetItem(&lviModi);
    m_qelvDataList->SetItem(&lviCrea);
}

/*----------------------------------------------------------------------------------------------
    Returns true if any of this folder's descendents is pfold. False otherwise.
----------------------------------------------------------------------------------------------*/
bool ExFolder::ContainsFolder(ExFolder * pfold)
{
    AssertObj(this);
    Assert(IsFullyInitialized());

    for(int i = 0; i < m_vqfold.Size(); i++)
    {
        if (pfold == m_vqfold[i])
            return true;
        if (m_vqfold[i]->ContainsFolder(pfold))
            return true;
    }
    return false;
}

/*----------------------------------------------------------------------------------------------
    Given an id, searches this folder and on down recursively through the hierarchy for for
    a match. Returns a pointer to the folder that matches the id, if found.
----------------------------------------------------------------------------------------------*/
ExFolder * ExFolder::FindFolder(ulong luId)
{
    AssertObj(this);

    if (m_luId == luId)
        return this;

    ExFolder * pfold;
    for(int i = 0; i < m_vqfold.Size(); i++)
    {
        pfold = m_vqfold[i]->FindFolder(luId);
        if (NULL != pfold)
            return pfold;
    }

    return NULL;
}

/*----------------------------------------------------------------------------------------------
    Given an id, searches this folder and on down recursively through the hierarchy for a
    match document. Returns a pointer to the document that matches the id, if found.
----------------------------------------------------------------------------------------------*/
ExDocument * ExFolder::FindDocument(ulong luId)
{
    AssertObj(this);
    int i;

    // Search this folder's documents
    for(i = 0; i < m_vqdoc.Size(); i++)
    {
        if (m_vqdoc[i]->GetId() == luId)
            return m_vqdoc[i];
    }

    // Search child-folder's documents recursively
    ExDocument * pdoc;
    for(i = 0; i < m_vqfold.Size(); i++)
    {
        pdoc = m_vqfold[i]->FindDocument(luId);
        if (NULL != pdoc)
            return pdoc;
    }

    // Not found
    return NULL;
}



/***********************************************************************************************
    EXPROJECT IMPLEMENTATION
************************************************************************************************/


/*----------------------------------------------------------------------------------------------
    Construction.
----------------------------------------------------------------------------------------------*/
ExProject::ExProject()
{
}


/*----------------------------------------------------------------------------------------------
    Retrieves a string appropriate for the user interface to describe the type of item (in 
    this case, a project.)
----------------------------------------------------------------------------------------------*/
void ExProject::GetType(achar * pszDest, uint cchMax)
{
    ExItem::GetType(pszDest, cchMax, kstidTypeProject);
}



/*----------------------------------------------------------------------------------------------
    Initializes the project, by storing into its member attributes the values passed in, and 
    then by reading in the subfolders and documents data from the sql database.

    Parameters:
        suServer - the name of the server (machine). For the local machine, this can
            be the string ("."). It should NOT be "(local)", as this works only on NT,
            not on Win9x. Normally we use "<machine name>\SILFW".
        suDatabase - the name of the database on the suServer. 
        guid - the unique guid of the project. 

    Returns true if succcessful, false otherwise.
----------------------------------------------------------------------------------------------*/
bool ExProject::Init(StrUni suServer, StrUni suDatabase, GUID guid)
{
    if (false == m_sql.Init(suServer, suDatabase))
        return false;
    m_guid = guid;
    if (false == _InitProjectBasics())
        return false;
    if (false == _InitProjectFolders())
        return false;
    if (false == _InitProjectDocuments())
        return false;
    return true;
}





/*----------------------------------------------------------------------------------------------
    Saves the project information to the registry. This is the information needed to open
    the project when Explorer is next started up.
	Each project saved should be given a unique subkey. Thus this project will be saved under a 
	key something like "...\Projects\3". 

	@param iSubKeyNumber subkey of project to save
----------------------------------------------------------------------------------------------*/
void ExProject::SaveToRegistry(int iSubKeyNumber)
{
    HKEY hk;
    achar szSubKey[32];
    _stprintf(szSubKey,_T("Projects\\%d"), iSubKeyNumber);
	if (0 == ::RegCreateKey(HKEY_LOCAL_MACHINE, g_app.GetRegistryKey(szSubKey), &hk))
    {
		// Save the guid
		StrApp strVal;
		strVal.Format(_T("%g"), &m_guid);
		::RegSetValueEx(hk, _T(""), 0, REG_MULTI_SZ, (BYTE *)strVal.Chars(),
			(strVal.Length() + 1) * isizeof(achar));

		// Save the server name
		strVal = m_sql.GetServerName();
		::RegSetValueEx(hk, _T("server"), 0, REG_MULTI_SZ,
			(BYTE *)strVal.Chars(), (strVal.Length() + 1) * isizeof(achar));

		// Save the database name
		strVal = m_sql.GetDatabaseName();
		::RegSetValueEx(hk, _T("database"), 0, REG_MULTI_SZ, 
			(BYTE *)strVal.Chars(), (strVal.Length() + 1) * isizeof(achar));

		// Save the project name
		strVal = m_stuProjectName;
		::RegSetValueEx(hk, _T("name"), 0, REG_MULTI_SZ,
			(BYTE *)strVal.Chars(), (strVal.Length() + 1) * isizeof(achar));

		// Save the type of project
		strVal = ProjectType();
		::RegSetValueEx(hk, _T("type"), 0, REG_SZ, 
			(BYTE *)strVal.Chars(), (strVal.Length() + 1) * isizeof(achar));

		::RegCloseKey(hk);
    }
}


/*----------------------------------------------------------------------------------------------
	Populates the project with its folders, filling up the folders hierarchy all the way
    down. We do this in two steps:
        1. We retrieve ALL of the folders from the database and stuff them into a
            temporary vector. This results in just one sql call, although it does mean
            that if there are other projects in the database we wind up retrieving a lot
            of folders we don't need.
        2. We next scan through the temporary vector and move the folders into this
            Project's hierarchy, based on the luIdOwner value. The method that does this
            is called recursively in order to populate the entire hierarchy. When done,
            we discard any extra folers in theh temporary vector.

    Returns true if successful, false otherwise. 
----------------------------------------------------------------------------------------------*/
bool ExProject::_InitProjectFolders()
{
    StrUni stuCommand;
    ulong luId;
    ulong luIdOwner;
    SilTime stimCreated = SilTime::CurTime();
    StrUni stuName;
    FoldV vfold;

    // Sql command to retrieve all of the folders in the database, regardless of which
    // project owns them.
    stuCommand.Format(
        L"select  isnull(NUM_CHILDREN, 0) CHILDREN, cf.id, cf.Owner$, cf.DateCreated, mt.txt " \
        L"from    CmFolder_ cf (readuncommitted) " \
        L"left outer join ( " \
	    L"        select   owner$ PARENT_ID, count(*) NUM_CHILDREN  " \
	    L"        from     cmobject (readuncommitted) " \
	    L"        where    class$ = (select id from class$ (readuncommitted) " \
		L"where name='CmFolder')  " \
	    L"        group by owner$ " \
	    L"        ) child_table on child_table.PARENT_ID = cf.id " \
        L"join    multitxt$ mt on mt.obj = cf.id  ");

    // Collect all the folders, stuff them into ExFolder objects in our temporary vfold.
    while (m_sql.GetNextRow(stuCommand))
    {
        // Column #2: the folder's id. A value of zero represents a problem in the data.
        m_sql.GetColumnNumeric(2, &luId);
        if (0 == luId)
            return false;

        // Column #3: the parent folder's id. A value of zero represents a data problem.
        m_sql.GetColumnNumeric(3, &luIdOwner);
        if (0 == luIdOwner)
            return false;

        // Column #4: The date the folder was created
        m_sql.GetColumnDate(4, stimCreated);

        // column #5: the name of the folder. A name of zero length is a data problem.
        m_sql.GetColumnStu(5, stuName);
        if (0 == stuName.Length())
            return false;

        // Create and do basic initializion on the folder
        ExFolderPtr qfold;
        qfold.Create();
        vfold.Insert( vfold.Size(), qfold);
        qfold->Init(luId, luIdOwner, stimCreated, stuName, this);
    }

    // Go through the vector, and copy everything that we own to our Folders attribute. The
    // method _InitFoldersFromVector is a recursive method defined on ExFolder, and will 
    // thus fill up all of the folders all the way down the hierarchy. Anything left in
    // vfold when we're done belongs to other projects in the database, and we just
    // discard them.
    _InitFoldersFromVector(vfold, this);
    vfold.Clear();
    return true;
}

/*----------------------------------------------------------------------------------------------
	Populates all of the folders in the project with their documents. We first issue a single
    query to the sql database in which we retrieve all of the documents. Then for each one,
    we place it into its folder (as each document knows the id of its owning folder). Those
    documents whose folders are not in this project are ignored (as we have retrieved ALL
    documents, including those from other projects.)

    Returns true if successful, false otherwise. 
----------------------------------------------------------------------------------------------*/
bool ExProject::_InitProjectDocuments()
{
    Assert(-1 != g_app.GetUIWritingSystem());

    StrUni stuCommand;
    StrUni stuName;
    ExDocumentPtr qdoc;
    int nIdOwningFolder;
    ExFolder * pfoldParent;

    // Assemble the sql command to retrieve all of the documents.
    stuCommand.Format(
        L"select mo.Id, fObjName.Txt, mo.DateCreated, mo.DateModified, c.Name,  " \
        L"       fobj.owner$, mo.Guid$, mo.Class$ " \
        L"from   CmMajorObject_ mo (readuncommitted) " \
        L"join   class$ c on mo.Class$=c.id " \
        L"join   cmfolderobject_ fObj (readuncommitted) on fObj.Object = mo.Id " \
        L"join   cmfolderobject_name fObjName (readuncommitted) on fObjName.Obj=fObj.Id " \
        L"and    fobjName.ws = %d",
        g_app.GetUIWritingSystem());

    // Loop through all of the documents returned by the command
    while (m_sql.GetNextRow(stuCommand))
    {
        // Create and initialize the document (by interpreting the row)
        qdoc.Create();
        nIdOwningFolder = qdoc->InterpretSqlRow(m_pprj);

        // Locate its owning folder, if it is in this project.
        pfoldParent = m_pprj->FindFolder(nIdOwningFolder);

        // If we have a non-NULL value, then the document is a member of this project.
        // Otherwise, we just discard it.
        if (NULL != pfoldParent)
            pfoldParent->InsertChildDocument(qdoc);
    }

    return true;
}



/***********************************************************************************************
    EXLANGUAGEPROJECT IMPLEMENTATION
************************************************************************************************/

/*----------------------------------------------------------------------------------------------
    Retrieves a string appropriate for the user interface to describe the type of item (in 
    this case, a language project.)
----------------------------------------------------------------------------------------------*/
void ExLangProj::GetType(achar * pszDest, uint cchMax)
{
    ExItem::GetType(pszDest, cchMax, kstidTypeLangProj);
}



/*----------------------------------------------------------------------------------------------
    Retrieves the basic information about the language project. This is largely information
    that is specific to the language project (e.g., fields that are not available on the
    ExProject level.)

    Returns true if successful, or false if anything goes wrong.
----------------------------------------------------------------------------------------------*/
bool ExLangProj::_InitProjectBasics()
{
    Assert(-1 != g_app.GetUIWritingSystem());

    ulong luId;
    SilTime stimCreated = SilTime::CurTime();
    StrUni stuCommand;

    // Assemble a sql command to retrieve basic language project information
    stuCommand.Format(
        L"select lp.id, mt.txt, lp.ethnologuecode  " \
        L"from   LangProj lp (readuncommitted) " \
        L"join   multitxt$ mt (readuncommitted) on mt.obj=lp.id  " \
        L"where  mt.flid =  " \
    	L"           (select id from field$ where name ='Name' and class =  " \
        L"	             (select id from class$ where name = 'CmProject'))  " \
        L"and    mt.ws = %d " \
        L"and    lp.id = (select id from cmobject cm (readuncommitted) where guid$ in ('%g')) ",
        g_app.GetUIWritingSystem(), &m_guid);

    // Execute the command. We are only retrieving one row.
    if (!m_sql.GetNextRow(stuCommand))
        return false;

    // Column #1: the database's Id for the Language Project. Zero is not considered
    // to be valid data.
    m_sql.GetColumnNumeric(1, &luId);
    if (0 == luId)
        return false;

    // Column #2: the name of the language project. An empty string is not considered
    // to be valid data.
    m_sql.GetColumnStu(2, m_stuProjectName);
    if (0 == m_stuProjectName.Length())
        return false;

    // column #3: the three-letter (usually) Ethnologue code of the language project.
    // We permit an empty string (as the person may not have entered a code, yet.)
    m_sql.GetColumnStu(3, m_stuEthnologueCode);

    // Initialize the folder
    ExFolder::Init(luId, luId, stimCreated, m_stuProjectName, this);

    // The display name is different if remote
    m_stuDisplayName = m_stuProjectName;
    m_sql.AddRemoteSuffix(m_stuDisplayName);

    // Done with this query (don't need to process any more rows (shouldn't be any
    // more rows, for that matter.))
    m_sql.CloseCommand();
    return true;
}



/***********************************************************************************************
    EMBEDDED CLASS SqlAccess
************************************************************************************************/

/*----------------------------------------------------------------------------------------------
    Construction. Initialize various booleans to false.
----------------------------------------------------------------------------------------------*/
ExProject::SqlAccess::SqlAccess()
{
    m_fIsInitialized = false;
    m_fIsRemote = false;
    m_fMoreRows = false;
	m_fTemporarilyDisconnected = false;
}


/*----------------------------------------------------------------------------------------------
    Destruction. Clean up memory. (The call to m_qode.Clear results in a call to Release()
    on the DbAccess com object. 
----------------------------------------------------------------------------------------------*/
ExProject::SqlAccess::~SqlAccess()
{
	if (!m_fTemporarilyDisconnected)
	{
		CloseCommand();
		m_qode.Clear();
	}
}


/*----------------------------------------------------------------------------------------------
    Initializes this SqlAccess object. This includes setting up the name of the server and
    database, creating the internal OleDbEncap object, and opening the actual connection
    to the sql database.

    We do not worry about leaving the open connection. Benchmarks indicate that there is no
    performance hit when we have dormant, open connections. So, we open it as part of this
    Init method, and leave it open for various queries that may arise.

    Parameters:
        suServer - the name of the server (machine). For the local machine, this can
            be the string ("."). It should NOT be "(local)", as this works only on NT,
            not on Win9x. Normally we use "<machine name>\SILFW".
        suDatabase - the name of the database on the suServer. 
----------------------------------------------------------------------------------------------*/
bool ExProject::SqlAccess::Init(StrUni & stuServer, StrUni & stuDatabase)
{
    Assert(m_fIsInitialized == m_fTemporarilyDisconnected);

    // Copy sql information into member attributes
    m_stuServer = stuServer;
    m_stuDatabase = stuDatabase;

    // Consider it as remote if the server name is not "<machine name>\SILFW"
	if (!m_stuServer.EqualsCI(dynamic_cast<AfDbApp *>(AfApp::Papp())->GetLocalServer()))
        m_fIsRemote = true;

    // Create the DbAccess object
    m_qode.CreateInstance(CLSID_OleDbEncap);

    // Open the data source.
	HRESULT hr;
	IStreamPtr qfist;
	// Get the IStream pointer for logging. NULL returned if no log file.
	hr = AfApp::Papp()->GetLogPointer(&qfist);
    hr = m_qode->Init(m_stuServer.Bstr(), m_stuDatabase.Bstr(), qfist, koltMsgBox, 0);
    if (FAILED(hr))
        return false;

    // Indicate that we are initialized
    m_fIsInitialized = true;
    return true;
}


/*----------------------------------------------------------------------------------------------
    Retrieves the next row matching the current command. If the command has not been issued,
    it is first issued and then the next row retrieved. If the command has already been
    issued, then the next row in the rowset is retrieved. The method keeps track of whether
    or not the command has been issued by the value of m_fMoreRows, which is set either by:
        1. The call to NextRow(), or
        2. By a call to CloseCommand().

    Returns: true if a row is made available by executing this method; false if no data
		was retrieved.
----------------------------------------------------------------------------------------------*/
bool ExProject::SqlAccess::GetNextRow(StrUni & stuCommand)
{
    Assert(m_fIsInitialized);
	if (m_fTemporarilyDisconnected)
		return false;

    // Either start up a command
    if (false == m_fMoreRows)
    {
	    m_qode->CreateCommand(&m_qodc);
        m_qodc->ExecCommand(stuCommand.Bstr(), knSqlStmtSelectWithOneRowset);
	    m_qodc->GetRowset(0);
        m_qodc->NextRow(&m_fMoreRows);
    }
    // Or continue a command
    else
    {
	    m_qodc->NextRow(&m_fMoreRows);
        if (false == m_fMoreRows)
			CloseCommand();
    }
    return m_fMoreRows;
}


/*----------------------------------------------------------------------------------------------
    Executes the supplied command.
----------------------------------------------------------------------------------------------*/
void ExProject::SqlAccess::DoCommand(StrUni & stuCommand)
{
	Assert(!m_fTemporarilyDisconnected);
    m_qode->CreateCommand(&m_qodc);
    m_qodc->ExecCommand(stuCommand.Bstr(), knSqlStmtSelectWithOneRowset);
}




/*----------------------------------------------------------------------------------------------
    Cancels out the current command, releasing the rowset. Subsequent calls to GetNextRow()
    will issue the command anew.

    Note: As this is called as part of the constructor, m_fIsInitialized may not necessarily
    have been set to true prior to calling this method.
----------------------------------------------------------------------------------------------*/
void ExProject::SqlAccess::CloseCommand()
{
    m_qodc.Clear();
    m_fMoreRows = false;
}

/*----------------------------------------------------------------------------------------------
    Retrieves a numeric value, specifically a ulong, from the current row. This is a wrapper
    around the GetColValue method.

    Parameters:
        iColumn - the number of the column for which we wish to retrieve data.
        pluDest - the ulong into which we place the value we have retrieved.
----------------------------------------------------------------------------------------------*/
void ExProject::SqlAccess::GetColumnNumeric(int iColumn, ulong * pluDest)
{
    Assert(m_fIsInitialized);
    Assert(m_fMoreRows);
	Assert(!m_fTemporarilyDisconnected);
	ULONG luSpaceTaken;
    ComBool fIsNull;
    m_qodc->GetColValue(iColumn, pluDest, sizeof(ulong), & luSpaceTaken, & fIsNull, 0);
    Assert(luSpaceTaken);  // otherwise, we didn't get anything.
}

/*----------------------------------------------------------------------------------------------
    Retrieves a wide-char, 00-terminated string from the current row.

    Parameters:
        iColumn - the number of the column for which we wish to retrieve data.
        pwszDest - the destination wchar into which we wish to retrieve data.
        cluDestSize - the amount of memory available in pwszDest.
----------------------------------------------------------------------------------------------*/
void ExProject::SqlAccess::GetColumnWstr(int iColumn, wchar * pwszDest, ulong cluDestSize)
{
    Assert(m_fIsInitialized);
    Assert(m_fMoreRows);
	Assert(!m_fTemporarilyDisconnected);
	ULONG luSpaceTaken;
    ComBool fIsNull;
    m_qodc->GetColValue(iColumn, reinterpret_cast <ULONG *>(pwszDest), 
        cluDestSize, &luSpaceTaken, &fIsNull, 2);
    Assert(luSpaceTaken);  // otherwise, we didn't get anything.
}


/*----------------------------------------------------------------------------------------------
    Retrieves an StrUni from the current row.

    Parameters:
        iColumn - the number of the column for which we wish to retrieve data.
        stuDest - the destination into which we wish to retrieve data.
----------------------------------------------------------------------------------------------*/
void ExProject::SqlAccess::GetColumnStu(int iColumn, StrUni & stuDest, bool fIsBigString)
{
    Assert(m_fIsInitialized);
    Assert(m_fMoreRows);
	Assert(!m_fTemporarilyDisconnected);
	ULONG luSpaceTaken;
    ComBool fIsNull;
    wchar * pwsz;
    int cPadding = 2;

    // Make a first attempt with an intentionally small buffer
    pwsz =  reinterpret_cast<wchar *> (CoTaskMemAlloc(sizeof(wchar) * 2));
	m_qodc->GetColValue(iColumn, reinterpret_cast <ULONG *>(pwsz), 2, &luSpaceTaken, 
        &fIsNull, cPadding);

    // Now reallocate (assuming more space is needed) and get the memory we actually need
	if (luSpaceTaken > 2)
	{
		CoTaskMemFree(pwsz);
		pwsz = reinterpret_cast<wchar *> (CoTaskMemAlloc(2 + sizeof(wchar) * luSpaceTaken));
		m_qodc->GetColValue(iColumn, reinterpret_cast <ULONG *>(pwsz), luSpaceTaken, 
				&luSpaceTaken, &fIsNull, cPadding);
	}

    // Kludge: GetColValue appears to be ignoring the cPadding for big strings, where
    // the DBTYPE is DBTYPE_IUNKNOWN.
    if (fIsBigString)
    {
        int iNulPos = luSpaceTaken/2 - 1;
        if (iNulPos >= 0)
            *(pwsz + iNulPos) = '\0';
    }

    // Place the data into the destination string, and release the temporary buffer
    stuDest = pwsz;
	CoTaskMemFree(pwsz);
}


/*----------------------------------------------------------------------------------------------
    Retrieves an SilTime from the current row. The default time is set to the system's 
    current time, should the sql database not have a valid time.

    Parameters:
        iColumn - the number of the column for which we wish to retrieve data.
        stimDest - the SilTime into which we wish to retrieve data.
----------------------------------------------------------------------------------------------*/
void ExProject::SqlAccess::GetColumnDate(int iColumn, SilTime & stimDest)
{
    Assert(m_fIsInitialized);
    Assert(m_fMoreRows);
	Assert(!m_fTemporarilyDisconnected);
	ULONG luSpaceTaken = 0;
    ComBool fIsNull;
    wchar wszTemp[sizeof(DBTIMESTAMP)/2];

	m_qodc->GetColValue(iColumn, reinterpret_cast <ULONG *>(wszTemp), sizeof(DBTIMESTAMP), 
			&luSpaceTaken, &fIsNull, 0);
	if (luSpaceTaken)
	{
        stimDest.SetYear(   (int)wszTemp[0] );
        stimDest.SetMonth(  (int)wszTemp[1] );
        stimDest.SetDate(   (int)wszTemp[2] );
        stimDest.SetHour(   (int)wszTemp[3] );
        stimDest.SetMinute( (int)wszTemp[4] );
        stimDest.SetSecond( (int)wszTemp[5] );
    }
    // If there was no time, we just set something bogus. If everything is coded correctly,
    // this should never happen. However, I cannot control what someone might do somewhere,
    // so we need something reasonable to happen. Hence we set to the current time.
    else
    {
        stimDest = SilTime::CurTime();
    }
}

/*----------------------------------------------------------------------------------------------
    Given the StrUni, appends a suffix to it representing the name of the server, e.g.,
    (AC-WimbishJ).

    Parameters:
        stuDest - the destination string onto which to append the suffix.
----------------------------------------------------------------------------------------------*/
void ExProject::SqlAccess::AddRemoteSuffix(StrUni & stuDest)
{
    Assert(m_fIsInitialized);
    if (m_fIsRemote)
    {
        stuDest.Append(L" (");
        stuDest.Append(m_stuServer);
        stuDest.Append(L")");
    }
}

/*----------------------------------------------------------------------------------------------
	Saves a tss to the sql database. We use a stored procedure which updates the existing table 
    member, or appends a new one if necessary.

    Parameters:
        qtss - the multistring to save (we are just saving the current UI writing system.)
        luId - the object's id, as it will be stored in the MultiStr$ table. This is
            also the id of the owning object (e.g., the Description for a Data Notebook.)
		flid - The field id.
		bool - True for a big TsString. False for a Unicode string.
----------------------------------------------------------------------------------------------*/
void ExProject::SqlAccess::SetTss(ITsStringPtr & qtss, ulong luId, int flid, bool fBig)
{
	Assert(!m_fTemporarilyDisconnected);

    HRESULT hr;

    try
    {
   	    IOleDbCommandPtr qodc;            // Currently-executing command
	    m_qode->CreateCommand(&qodc);

        // Assemble the command
    	StrUni stuCommand;
		if (fBig)
			stuCommand.Format(L"exec SetMultiBigStr$ %d, %d, %d, ?, ?", flid, luId,
				g_app.GetUIWritingSystem());
		else
			stuCommand.Format(L"exec SetMultiTxt$ %d, %d, %d, ?", flid, luId,
				g_app.GetUIWritingSystem());

        // First parameter: the text of the multistring
	    SmartBstr sbstr;
        CheckHr(qtss->get_Text(&sbstr));
        CheckHr(qodc->SetParameter(1, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_WSTR, 
            (ulong *)(sbstr.Chars()), sbstr.Length() * 2));

		if (fBig)
		{
			// Second parameter: the formatting imformation for the multistring
    		const kcbFmtBufMax = 1024;
			byte * rgbFmt = NewObj byte[kcbFmtBufMax]; // REVIEW: This doesn't seem to get deleted
			int cbFmtBufSize = kcbFmtBufMax;
    		int cbFmtSpaceTaken;
			hr = qtss->SerializeFmtRgb(rgbFmt, cbFmtBufSize, &cbFmtSpaceTaken);
			if (hr != S_OK)
			{
				// Try again with larger buffer
				if (hr == S_FALSE)
				{
					delete rgbFmt;
					rgbFmt = NewObj byte[cbFmtSpaceTaken];
					cbFmtBufSize = cbFmtSpaceTaken;
					CheckHr(qtss->SerializeFmtRgb(rgbFmt, cbFmtBufSize, &cbFmtSpaceTaken));
				}
				else
				{
					ThrowHr(WarnHr(E_UNEXPECTED));
				}
			}
			CheckHr(qodc->SetParameter(2, DBPARAMFLAGS_ISINPUT, NULL, DBTYPE_BYTES,
				(ulong *)rgbFmt, cbFmtSpaceTaken));
		}

        //  Execute the SQL update command.
        CheckHr(qodc->ExecCommand(stuCommand.Bstr(), knSqlStmtNoResults));
    }
    catch (...)
    {
    	ThrowHr(WarnHr(E_FAIL));
    }
}

/*----------------------------------------------------------------------------------------------
	Disconnects from the database. This is useful during a restore operation, so that a database
	can be restored without having to close the program down.
----------------------------------------------------------------------------------------------*/
void ExProject::SqlAccess::TemporarilyDisconnectDB()
{
    CloseCommand();
    m_qode.Clear();
	m_fTemporarilyDisconnected = true;
}

/*----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------*/
bool ExProject::SqlAccess::ReconnectDB()
{
	Assert(m_fTemporarilyDisconnected);

	if (Init(m_stuServer, m_stuDatabase))
	{
		m_fTemporarilyDisconnected = false;
		return true;
	}
	return false;
}



/***********************************************************************************************
    CLASS ExDocument IMPLEMENTATION
************************************************************************************************/
/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
ExDocument::ExDocument() : ExItem()
{
    m_nType = kUnknown;
    m_fIsInitialized = false;
    m_iIcon = kridImageUnknownDocument;
    m_cluSize = 0;
}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
int ExDocument::GetIcon() 
{ 
    Assert(m_fIsInitialized);
    return m_iIcon;
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
REFIID ExDocument::GetRefiid()
{
    switch (m_nType)
    {
    case kDataNotebook:
        return CLSID_ResearchNotebook;
// ENHANCE: Rand, define the CLSID and uncomment this.
    case kChoicesList:
        return CLSID_ChoicesListEditor;
    default:
        return IID_IUnknown;
    }
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
void ExDocument::Initialize(ulong luId, ulong luIdOwner, wchar * pwszName, SilTime & stimCreated,
        SilTime & stimModified, wchar * pwszClassName, ExProject *pprj)
{
    Assert(!m_fIsInitialized);

    int nTypeResource = -1;
    int nSizeResource = -1;
    wchar wszCommand[] = L"select count(*) from cmobject (readuncommitted) " \
		L"where ownflid$=%d and owner$=%d ";

    m_luId = luId;
    m_luIdOwner = luIdOwner;
    m_stimCreated = stimCreated;
    m_stimModified = stimModified;
    m_pprj = pprj;
    m_stuName = pwszName;

    // Determine the document type. First, we check amongst some hard-wired types we are aware of.
    if (0 == wcscmp(pwszClassName, L"RnResearchNotebook"))
    {
        m_nType = kDataNotebook;
        m_iIcon = kridImageDataNotebook;
        m_stuSizeCommand.Format(wszCommand, 4001001, m_luId);
    }
    // ENHANCE: Need a hierarchical query. The query used currently just counts the number
    // of top-level items; rather than the entire hierarchy.
    else if (0 == wcscmp(pwszClassName, L"CmPossibilityList"))
    {
        m_nType = kChoicesList;
        m_iIcon = kridImageChoiceList;
        m_stuSizeCommand.Format(wszCommand, 8008, m_luId);
    }
    else if (0 == wcscmp(pwszClassName, L"LexicalDatabase"))
    {
        m_nType = kLexicalDatabase;
        m_iIcon = kridImageLexicalDatabase;
        m_stuSizeCommand.Format(wszCommand, 5005001, m_luId);
    }
    else if (0 == wcscmp(pwszClassName, L"WordformInventory"))
    {
        m_nType = kWordformInventory;
        m_iIcon = kridImageWordformInventory;
        m_stuSizeCommand.Format(wszCommand, 5063001, m_luId);
    }
    else if (0 == wcscmp(pwszClassName, L"RnResultsNotebook"))
    {
        m_nType = kResultsNotebook;
        m_iIcon = kridImageResultsNotebook;
        m_stuSizeCommand.Format(wszCommand, 4002001, m_luId);
    }


    // If we didn't find the document in the hard-wired section, we check in the registry for 
    // a new type someone may have added. The registry will also need to supply an icon.
    // ENHANCE: Implement this part. For now we assert if we come across something unkown.
    // ENHANCE: Should we just pull it ALL out of the registry, rather than the hard-wired
    //      part above?
    Assert(kUnknown != m_nType);
    m_fIsInitialized = true;
}


/*----------------------------------------------------------------------------------------------
    Retrieves a string appropriate for the user interface to describe the type of item (in 
    this case, a document.)
----------------------------------------------------------------------------------------------*/
void ExDocument::GetType(achar * pszDest, uint cchMax)
{
    uint rid;
    switch (m_nType)
    {
    case kDataNotebook:      rid = kstidTypeDataNotebook;      break;
    case kResultsNotebook:   rid = kstidTypeResultsNotebook;   break;
    case kChoicesList:       rid = kstidTypeChoiceList;        break;
    case kLexicalDatabase:   rid = kstidTypeLexicalDatabase;   break;
    case kWordformInventory: rid = kstidTypeWordformInventory; break;
    default: Assert(0);
    }

    ExItem::GetType(pszDest, cchMax, rid);
}

/*----------------------------------------------------------------------------------------------
    Retrieves a string appropriate for the user interface to describe the number of items
    this object owns.
----------------------------------------------------------------------------------------------*/
void ExDocument::GetSizePhrase(achar * pszDest, uint cchMax)
{
    Assert(cchMax > 0);

    // Get the format string from the resource for the kind of document
    uint rid;
    switch (m_nType)
    {
    case kDataNotebook:      rid = kstidSizeDataNotebook;      break;
    case kResultsNotebook:   rid = kstidSizeResultsNotebook;   break;
    case kChoicesList:       rid = kstidSizeChoiceList;        break;
    case kLexicalDatabase:   rid = kstidSizeLexicalDatabase;   break;
    case kWordformInventory: rid = kstidSizeWordformInventory; break;
    default: Assert(0);
    }
    achar szFormat[kMax];
    int cCharsLoaded = LoadString(g_app.GetInstance(), rid, szFormat, kMax);
    Assert(0 != cCharsLoaded);

    // Build the size string
    if (cchMax > _tcslen(szFormat) + 10)
        _stprintf(pszDest, szFormat, m_cluSize);
    else
        *pszDest = '\0';
}

/*----------------------------------------------------------------------------------------------
    Retrieves a string appropriate for the user interface to describe the location of this
    object.
----------------------------------------------------------------------------------------------*/
void ExDocument::GetLocation(achar * pszDest, uint cchMax)
{
    ExFolder * pfoldOwner = m_pprj->FindFolder(m_luIdOwner);
    Assert(NULL != pfoldOwner);
    pfoldOwner->GetLocation(pszDest, cchMax);
}


/*----------------------------------------------------------------------------------------------
    Places the relevant informatin about the document into an item in the list control.
----------------------------------------------------------------------------------------------*/
void ExDocument::PlaceIntoListControl(ExListViewPtr & m_qelvDataList)
{
    achar szDate[kMax];

    // Initialize a structure for each column in the list
    FW_LVITEM lviText(LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM, 0, 0);
    FW_LVITEM lviSize(LVIF_TEXT, 0, 1);
    FW_LVITEM lviType(LVIF_TEXT, 0, 2);
    FW_LVITEM lviModi(LVIF_TEXT, 0, 3);
    FW_LVITEM lviCrea(LVIF_TEXT, 0, 4);

    // We'll set a pointer to this object as the lParam
    lviText.lParam = (LPARAM)this;

    // Initialize the strings we will place into each column
    achar szType[kMax];
    lviText.iImage = GetIcon();
    GetType(szType, sizeof(szType));
#ifdef UNICODE
    g_app.MakeUIString(szType, kMax, lviType.qtss);
#else
    wchar wszType[kMax];
	mbstowcs(wszType, szType, sizeof(szType));
    g_app.MakeUIString(wszType, kMax, lviType.qtss);
#endif

    g_app.MakeUIString(m_stuName.Chars(), lviText.qtss);

    // Modify date
    _stprintf(szDate, _T("%d/%02d/%d"), m_stimModified.Month(), m_stimModified.Date(), 
        m_stimModified.Year());
#ifdef UNICODE
    g_app.MakeUIString(szDate, kMax, lviModi.qtss);
#else
    wchar wszDate[kMax];
    mbstowcs(wszDate, szDate, kMax);
    g_app.MakeUIString(wszDate, kMax, lviModi.qtss);
#endif

    // Create date
    _stprintf(szDate, _T("%d/%02d/%d"), m_stimCreated.Month(), m_stimCreated.Date(), 
        m_stimCreated.Year());
#ifdef UNICODE
    g_app.MakeUIString(szDate, kMax, lviCrea.qtss);
#else
    mbstowcs(wszDate, szDate, kMax);
    g_app.MakeUIString(wszDate, kMax, lviCrea.qtss);
#endif

    // Retrieve count of the document's owned objects
    m_pprj->m_sql.GetNextRow(m_stuSizeCommand);
    m_pprj->m_sql.GetColumnNumeric(1, &m_cluSize);
    m_pprj->m_sql.CloseCommand();

    // Number of items
    achar szSizePhrase[kMax];
    GetSizePhrase(szSizePhrase, kMax);
#ifdef UNICODE
    g_app.MakeUIString(szSizePhrase, kMax, lviSize.qtss);
#else
    wchar wszSizePhrase[kMax];
	mbstowcs(wszSizePhrase, szSizePhrase, sizeof(szType));
    g_app.MakeUIString(wszSizePhrase, kMax, lviSize.qtss);
#endif

    // Place them into the list
    m_qelvDataList->InsertItem(&lviText);
    m_qelvDataList->SetItem(&lviSize);
    m_qelvDataList->SetItem(&lviType);
    m_qelvDataList->SetItem(&lviModi);
    m_qelvDataList->SetItem(&lviCrea);
}

/*----------------------------------------------------------------------------------------------
    ENHANCE: Be sure and document out assumptions about how the sql row is laid out.
----------------------------------------------------------------------------------------------*/
ulong ExDocument::InterpretSqlRow(ExProject * pprj)
{
    ulong luId;                             // The database's id for the document
    wchar wszName[kMax];                    // The name of the doc within the current writing system
    SilTime stimCreated;                    // The time the document was created
    SilTime stimModified;                   // The time the document was last modified
    wchar wszClass[kMax];                   // The name of the class
    ulong nIdOwningFolder;                  // The id of the owning folder

    // Column #1: the database's Id for the document
    pprj->m_sql.GetColumnNumeric(1, &luId);

    // Column #2: the name of the document (in the current writing system)
    pprj->m_sql.GetColumnWstr(2, wszName, kMax);

    // Column #3: The date the document was created
    pprj->m_sql.GetColumnDate(3, stimCreated);

    // Column #4: The date the document was last modified
    pprj->m_sql.GetColumnDate(4, stimModified);

    // Column #5: The name of the class (e.g., RnDataNotebook)
    pprj->m_sql.GetColumnWstr(5, wszClass, kMax);

    // Column #6: The id of the owning folder
    pprj->m_sql.GetColumnNumeric(6, &nIdOwningFolder);

    // Initialize the document to these values
    Initialize(luId, nIdOwningFolder, wszName, stimCreated, stimModified, wszClass, pprj);

    // Return the id of the owner
    return nIdOwningFolder;
}


/***********************************************************************************************
    CLASS ExTool IMPLEMENTATION
************************************************************************************************/

/*----------------------------------------------------------------------------------------------
    ...
----------------------------------------------------------------------------------------------*/
void ExTool::Init(int iIcon, int nDocumentType, UINT nIdToolName)
{
    g_app.LoadStuFromResources(nIdToolName, m_stuName);
    m_iIcon = iIcon;
    m_nDocumentType = nDocumentType;
}


/*----------------------------------------------------------------------------------------------
    ...
----------------------------------------------------------------------------------------------*/
void ExTool::PlaceIntoComboControl(AfToolBarComboPtr & qecbCombo, int iItemNo)
{
    InsertIntoComboControl(qecbCombo, Name(), GetIcon(), iItemNo, 1, m_hTreeItem);
}


/*----------------------------------------------------------------------------------------------
    ...
----------------------------------------------------------------------------------------------*/
void ExTool::PlaceIntoTreeControl(ExToolTreeViewPtr & qetv)
{
    m_hTreeItem = qetv->InsertItem(this);
    Assert(NULL != m_hTreeItem);
}

/***********************************************************************************************
    CLASS ExRoot IMPLEMENTATION
************************************************************************************************/

/*----------------------------------------------------------------------------------------------
    Releases all memory associated with the root (and its owned objects.)
----------------------------------------------------------------------------------------------*/
void ExRoot::Clear()
{
    m_vqprj.Clear();
    m_vqtool.Clear();
}

/*----------------------------------------------------------------------------------------------
    Removes a project from the vector and deletes it.
----------------------------------------------------------------------------------------------*/
void ExRoot::RemoveProject(ExProject * pproj)
{
    // Locate the project within the vector
    for(int i=0; i<m_vqprj.Size(); i++)
    {
        if (pproj == GetProject(i))
            break;
    }
    Assert(i >= 0 && i != m_vqprj.Size());

    // Delete the project from the vector
    m_vqprj.Delete(i);
}


/*----------------------------------------------------------------------------------------------
    Initializes the folder and tools hierarchies, by populating the vectors and the tree 
    controls with the data and tools currently recognized by FieldWorks.

    Parameter:
        qetvFolders - the tree control that will be populated with the projects & folders.
        qetvTree - the tree control that will be populated with the tools.
----------------------------------------------------------------------------------------------*/
void ExRoot::Init(ExFolderTreeViewPtr & qetvFolders, ExToolTreeViewPtr & qetvTools)
{
    // Get projects from the registry and their corresponding data from sql, add them to the
    // folders tree.
    int cProjects = AddProjectsFromRegistry();

    // If nothing was added, then we'll add the default projects, if available.
    // ENHANCE: For now, we're using TestLangProj; but at some point we'll want
    // to instead load the Sample language projects we'll be doing.
    static const GUID guids[] = {    // French, German 
        { 0xd7f71350, 0xe8cf, 0x11d3, { 0x97, 0x64, 0x0, 0xc0, 0x4f, 0x18, 0x69, 0x33 } },
        { 0x232cc850, 0xeeee, 0x11d3, { 0x97, 0x70, 0x0, 0xc0, 0x4f, 0x18, 0x69, 0x33 } }
    };
	char szLocal[MAX_COMPUTERNAME_LENGTH + 1];
	DWORD cbLocal = isizeof(szLocal);
	if (!GetComputerNameA(szLocal, &cbLocal))
  		strcpy(szLocal, "");
	StrUni stu = szLocal;
	stu.Append(L"\\SILFW");
    if (0 == cProjects)
    {
        for (int i=0; i<2; i++)
            AddLangProj(stu.Chars(), L"TestLangProj", guids[i]);
    }

	AddProjectsToTree(qetvFolders);

    // Add the three tools that Version One will support. We will eventually want to retrieve
    // this from the registry or the database, rather than hard-coding it. The AddTool
    // methods add the tool both to our ToolV vector and to the qetv tree control.
	AddTool(kridTool, ExDocument::kDataNotebook,     kstidAppDataNotebookEditor,     qetvTools);
	AddTool(kridTool, ExDocument::kResultsNotebook,  kstidAppResultsNotebookEditor,  qetvTools);
	AddTool(kridTool, ExDocument::kChoicesList,      kstidAppChoicesListEditor,      qetvTools);

    // Expand the folders tree so that we see the first language project, and so that 
    // something is initially selected. 
	qetvFolders->InitialExpansion();

    // Similarly, expand the tools tree so that we see all the tools; select the first tool 
    // so that something is initially selected when the user first sees the tree.
    qetvTools->InitialExpansion();
}

/*----------------------------------------------------------------------------------------------
    Adds an individual tool to the Explorer, both by adding it to the vector and by adding it
    to the tree control. This includes creating a new ExTool object.

    Parameters:
        iIcon - the index of the icon to display in the tree view.
        nDocumentType - the unique id of the type of document, which we use to know whicih
                tool to open on which document.
        nIdToolName - the id of the name of the tool (a string resource)
        qetv - the tools tree control into which to place this new tool.
----------------------------------------------------------------------------------------------*/
void ExRoot::AddTool(int iIcon, int nDocumentType, UINT nIdToolName, ExToolTreeViewPtr & qetv)
{
    ExToolPtr qtool;
    qtool.Create();
    qtool->Init(iIcon, nDocumentType, nIdToolName);
    m_vqtool.Insert(m_vqtool.Size(), qtool);
    qtool->PlaceIntoTreeControl(qetv);
}

/*----------------------------------------------------------------------------------------------
    Adds a project to the Explorer, which includes initializing it (including reading all of
    its data from the sql database), and adding it to the project vector.

    Parameters:
        suServer - the name of the server (machine). For the local machine, this can
            be the string ("."). It should NOT be "(local)", as this works only on NT,
            not on Win9x. Normally we use "<machine name>\SILFW".
        suDatabase - the name of the database on the suServer. 
        guid - the unique guid of the project. 

    Returns: true if we successfully opened the project, false otherwise.
----------------------------------------------------------------------------------------------*/
bool ExRoot::AddLangProj(StrUni stuServer, StrUni stuDatabase, GUID guid)
{
    ExProjectPtr qprj;
    ExLangProjPtr qlprj;

    // Check to see if the project is already open. Abort if so.
    if (IsProjectAlreadyOpen(stuServer, stuDatabase, guid))
    {
        g_app.InformationBox(kstidProjAlreadyOpen);
        return false;
    }

    // As this may take a while (due to lower level calls to sql), turn on the hourglass cursor
    CWaitCursor wait;

    // Add the project
    qlprj.Create();
    if (qlprj->Init(stuServer, stuDatabase, guid))
    {
        qprj = qlprj;
        m_vqprj.Insert( m_vqprj.Size(), qprj);
        return true;
    }

    // Did not add the project
    return false;
}

/*----------------------------------------------------------------------------------------------
	Adds all its projects to the Tree View
----------------------------------------------------------------------------------------------*/
void ExRoot::AddProjectsToTree(ExFolderTreeViewPtr & qetv)
{
    for(int i=0; i<m_vqprj.Size(); i++)
    {
        ExProject * pprj = GetProject(i);
		pprj->AddToTree(qetv);
	}
}

/*----------------------------------------------------------------------------------------------
	Adds the most recently added project to the Tree View
----------------------------------------------------------------------------------------------*/
void ExRoot::AddLastProjectToTree(ExFolderTreeViewPtr & qetv)
{
    ExProject * pprj = GetProject(m_vqprj.Size() - 1);
	pprj->AddToTree(qetv);
}

/*----------------------------------------------------------------------------------------------
    Checks to see if a language project has already been opened in the project. We don't want
    to open a project more than once.

    Parameters:
        guid - the unique id of the project that we wish to check.

    Returns true if the project is already open in the Explorer, false otherwise.
----------------------------------------------------------------------------------------------*/
bool ExRoot::IsProjectAlreadyOpen(StrUni stuServer, StrUni stuDatabase, GUID guid)
{
    for(int i=0; i<m_vqprj.Size(); i++)
    {
        ExProject * pprj = GetProject(i);
        if ( 0 == wcscmp(stuServer.Bstr(), pprj->GetServer()) && 
             0 == wcscmp(stuDatabase.Bstr(), pprj->GetDatabase()) &&
             pprj->GetGuid() == guid )
        {
            return true;
        }
    }
    return false;
}


/*----------------------------------------------------------------------------------------------
    Scans the registry for those projects which were previously open in the Explorer, and for 
    each of those creates a project and instantiates its data from the sql server. 

    Parameters
        qetv - The tree control into which to add the projects.

    Returns the number of projects actually opened.
----------------------------------------------------------------------------------------------*/
int ExRoot::AddProjectsFromRegistry()
{
    int cProjectsOpened = 0;                // How many projects we actually open
    HKEY hkProjects;                        // Parent key for the projects info
    HKEY hk;                                // Key for iterating through Project's subkeys
    achar szKeyName[MAX_PATH+1];             // Holds the names of the subkeys (hk)
    DWORD dwIndex = 0;                      // Used for RegEnumKey iteration
    ExProjectPtr qprj;                      // Points to each new project as we create it
    ULONG cb;                               // Where RegQueryValueEx returns size of data read
    ULONG luQueryType;                      // RegQueryValueEx query type parameter
    WCHAR wszGuid[256];                     // Holds incoming multistring data
    char szGuid[256];                       // Translate wchar guid to mb string.
    WCHAR wszServer[64];                    // Holds incoming multistring data
    WCHAR wszDatabase[64];                  // Holds incoming multistring data
    WCHAR wszProjectName[64];               // Holds incoming multistring data
    GUID guid;                              // Holds the guid (converted from wszGuid)

	if (0 ==
		::RegCreateKey(HKEY_LOCAL_MACHINE, g_app.GetRegistryKey(_T("Projects")), &hkProjects))
    {
		while (0 == ::RegEnumKey(hkProjects, dwIndex++, szKeyName, sizeof(szKeyName)))
        {
			if (0 == ::RegOpenKey(hkProjects, szKeyName, &hk)) 
            {
                // Create a new project of the appropriate type
                achar szType[64];
                cb = sizeof(szType);
                luQueryType = REG_SZ;
                if (ERROR_SUCCESS ==
					::RegQueryValueEx(hk, _T("type"), NULL, &luQueryType, (BYTE *)szType, &cb))
                {
                    // Verify that we are dealing with a language project. (Later we'll
                    // add other things besides Language Projects here.) If it isn't a
                    // language project, then we skip this key and  move on.
                    if (_tcscmp(szType, _T("Language"))!=0)
                        goto NextKey;

                    // Shorthand for retrieving multibyte strings
#define GETVAL(name, buff) \
	cb = sizeof(buff); \
	luQueryType = REG_MULTI_SZ; \
	if ( ERROR_SUCCESS != RegQueryValueEx(hk, name, NULL, &luQueryType, (BYTE *)buff, &cb)) \
	goto NextKey;

                    // Retrieve the GUID
                    GETVAL(_T(""), wszGuid);
                    wcstombs(szGuid, wszGuid, sizeof(szGuid) );
                    ParseGuid(szGuid, &guid);

                    // Retrieve the server
                    GETVAL(_T("server"), wszServer);
					if (!wcslen(wszServer))
						wcscpy(wszServer,
							dynamic_cast<AfDbApp *>(AfApp::Papp())->GetLocalServer());

                    // Retrieve the database
                    GETVAL(_T("database"), wszDatabase);

                    // Retrieve the project name
                    GETVAL(_T("name"), wszProjectName);

                    // Update the splash window (if there is one)
                    g_app.SetSplashLoadingMessage(wszProjectName);

                    // Initialize the project and get its data from the sql database
                    if (AddLangProj(wszServer, wszDatabase, guid))
                        ++cProjectsOpened;
                }
NextKey:
		        RegCloseKey(hk);
            }
        } // endwhile enum through keys

		RegCloseKey(hkProjects);
    }

    return cProjectsOpened;
}

/*----------------------------------------------------------------------------------------------
    Returns the project within the vector corresponding to the passed display name, or
    NULL if not found.
----------------------------------------------------------------------------------------------*/
ExProject * ExRoot::GetProject(BSTR bstrDisplayName)
{
    for (int i=0; i<NumberOfProjects(); i++)
    {
        if ( 0 == wcscmp(bstrDisplayName, GetProject(i)->DisplayName().Bstr()) )
            return GetProject(i);
    }
    return NULL;
}

/*----------------------------------------------------------------------------------------------
	Returns the ExProject that is currently selected in the folders tree, or NULL if
    something other than a project is selected.
----------------------------------------------------------------------------------------------*/
ExProject * ExRoot::GetSelectedProject(ExFolderTreeViewPtr & qetvFolders)
{
    int iIconOut;
    ITsStringPtr qtss;
    if (false == qetvFolders->GetCurrentSelection(&iIconOut, qtss))
        return NULL;
    BSTR bstr;
    qtss->get_Text(&bstr);
    return GetProject(bstr);
}

/*----------------------------------------------------------------------------------------------
	Returns the project within the vector corresponding to the passed index number.
----------------------------------------------------------------------------------------------*/
ExProject * ExRoot::GetProject(int i)
{
    Assert(i >= 0 && i < m_vqprj.Size());
    return m_vqprj[i];
}

/*----------------------------------------------------------------------------------------------
    Returns the tool within the vector corresponding to the passed display name, or
    NULL if not found.
----------------------------------------------------------------------------------------------*/
ExTool * ExRoot::GetTool(BSTR bstrName)
{
    for (int i=0; i<NumberOfTools(); i++)
    {
        if ( 0 == wcscmp(bstrName, GetTool(i)->Name().Bstr()) )
            return GetTool(i);
    }
    return NULL;
}


/*----------------------------------------------------------------------------------------------
	Returns the tool within the vector corresponding to the passed index number.
----------------------------------------------------------------------------------------------*/
ExTool * ExRoot::GetTool(int i)
{
    Assert(i >= 0 && i < m_vqtool.Size());
    return m_vqtool[i];
}


/*----------------------------------------------------------------------------------------------
	Saves a record of all of the open projects into the registry.
----------------------------------------------------------------------------------------------*/
void ExRoot::SaveToRegistry()
{
    HKEY hk;
	if (0 == ::RegCreateKey(HKEY_LOCAL_MACHINE, g_app.GetRegistryKey(_T("")), &hk) ) 
    {
        ::RegDeleteKey(hk, _T("Projects"));
        for (int i=0; i<m_vqprj.Size(); i++)
            m_vqprj[i]->SaveToRegistry(i+1);
		::RegCloseKey(hk);
    }
}


/*----------------------------------------------------------------------------------------------
	... 
----------------------------------------------------------------------------------------------*/
