/*--------------------------------------------------------------------*//*:Ignore this sentence.
Copyright (C) 2000, 2001 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: resource.h
Responsibility: Alistair Imrie
Last reviewed: never

Description:
	Defined IDs for FW Explorer resources.
-------------------------------------------------------------------------------*//*:End Ignore*/

/*
	IDs in actual applications start at 1024 (==WM_USER) and work UP.
	To find out why we start at WM_USER, see ms-help://MS.VSCC/MS.MSDNVS/winui/messques_4soi.htm
*/


#include "..\..\AppCore\Res\AfWizardDlgRes.h"

#define kstidWindowTitle				1045

// Misc messages
#define kstidNoItemsInTheList			1046  // Message when there is nothing in the list view
#define kstidStatusSearching			1047  // Message when searching to fill a list view
#define kstidServerNotRunning			1048  // Message (File-Open) for when the sql server isn't running
#define kstidProjAlreadyOpen			1049  // Message: the project is already open and can't be opened multiple times.
#define kstidEmptyCaption				1050  // Caption bar where there are no projects in the folders tree
#define kstidProjCloseConfirm			1051  // Message: Are you sure you want to close the selected project?
#define kstidErrCannotLaunchApp 		1052

#define kridAviSearching				1053

// Control ID's for UI Components
#define kctidTBarStd					4100  // Standard toolbar
#define kctidPathnameCombo				4101  // Combo box on std toolbar (shows the obj's path)
#define kctidFoldersTree				4102
#define kctidToolsTree					4103
#define kctidCaptionBar 				4104
#define kctidDocList					4105

// File-Open Dialog
#define kridDlgFileOpen 				4200
#define kctidChooseComputer 			4201
#define kctidChooseProject				4202

// Splash window
#define kstidSplashStartMessage 		4300
#define kstidSplashSqlMessage			4301
#define kstidSplashFinishingMessage 	4302

// Properties dialog (and tabs)
#define kridDlgProperties				4320
#define kcidPropertiesDlgTab			4321
#define kridPropGenTab					4330
#define kstidPropGenTabTitle			4331
#define kridPropGenTabIcon				4332
#define kctidPropGenTabNameLarge		4333
#define kctidPropGenTabName 			4334
#define kctidPropGenTabType 			4335
#define kctidPropGenTabLocation 		4336
#define kctidPropGenTabSize 			4337
#define kctidPropGenTabCreated			4338
#define kctidPropGenTabModified 		4339
#define kctidPropGenTabDescription		4340


// Image Lists
#define kridImagesLarge 				4000
#define kridImagesSmall 				4001
#define kridFileCabinetClosed			   0
#define kridFileCabinetOpened			   1
#define kridFileDrawerClosed			   2
#define kridFileDrawerOpened			   3
#define kridFolderClosed				   4
#define kridFolderOpened				   5
#define kridToolChestClosed 			   6
#define kridToolChestOpened 			   7
#define kridToolDrawerClosed			   8
#define kridToolDrawerOpened			   9
#define kridTool						  10
#define kridDocument					  36
#define kridSearch						  44

#define kridImageUnknownDocument		  28
#define kridImageChoiceList 			  26
#define kridImageDataNotebook			  18
#define kridImageResultsNotebook		  24
#define kridImageLexicalDatabase		  22
#define kridImageWordformInventory		  12

// Column header srrings for the list view
#define kstidName						4500
#define kstidType						4501
#define kstidSize						4502
#define kstidCreated					4503
#define kstidModified					4504

// Tab strings for the tree pane
#define kstidTabFolders 				4505
#define kstidTabTools					4506

// Strings for the root node
#define kstidRootFolders				4507
#define kstidRootTools					4508

// Strings for the Caption Bar
#define kstidCaptionFolder				4509
#define kstidCaptionTool				4510

// Document strings for type and size
#define kstidTypeFolder 				4520
#define kstidTypeProject				4521
#define kstidTypeLangProj				4522
#define kstidTypeChoiceList 			4523
#define kstidTypeDataNotebook			4524
#define kstidTypeResultsNotebook		4525
#define kstidTypeLexicalDatabase		4526
#define kstidTypeWordformInventory		4527
#define kstidSizeFolder 				4530
#define kstidSizeChoiceList 			4531
#define kstidSizeDataNotebook			4532
#define kstidSizeResultsNotebook		4533
#define kstidSizeLexicalDatabase		4534
#define kstidSizeWordformInventory		4535

// Tool names
#define kstidAppDataNotebookEditor		4550
#define kstidAppResultsNotebookEditor	4551
#define kstidAppChoicesListEditor		4552

// Create New Project Wizard Pages
#define kridWizProjPicture				4600
#define kridWizProjPageGetName			4601
#define kctidWizProjLanguageName		4602
#define kstidWizProjDefLangName 		4603
#define kridWizProjPageEth				4604
#define kctidWizProjEthCode 			4605
#define kstidWizProjDefEthCode			4606
#define kridWizProjPageLoc				4607
#define kctidWizProjRegion				4608
#define kstidWizProjRegAfrica			4609
#define kstidWizProjRegAsia 			4610
#define kstidWizProjRegAmerica			4611
#define kstidWizProjRegEurope			4612
#define kstidWizProjRegPacific			4613
#define kctidWizProjCountry 			4614
#define kctidWizProjProvince			4615
#define kridWizProjPageComputer 		4616
#define kctidWizProjNetworkTree 		4617
#define kctidWizProjComputer			4618
#define kridWizProjPageLists			4619
#define kctidWizProjLists				4620
#define kridWizProjPageReady			4621

// Menus
#define kridMenuListHeader				2002
#define kridMenuListItem				2003
#define kridMenuListBlank				2004
#define kridMenuToolsItem				2005
#define kridMenuToolsBlank				2006
#define kridMenuFoldersItem 			2007
#define kridMenuFoldersBlank			2008
#define kridMenuCombo					2009
#define kridMenuCaption 				2010

// Menu commands
#define kcidFileNewFolder				2010 
#define kcidFileNewLangProj 			2011 
#define kcidFileNewShortcut 			2012
#define kcidFileOpenProject 			2013
#define kcidFileCloseProject			2014
#define kcidFileDelete					2015
#define kcidFileRename					2016
#define kcidFilePropertiesListItem		2017
#define kcidFileImport					2019

#define kcidEditPasteShortcut			2024
#define kcidEditFind					2025

#define kcidViewToolbar 				2030
#define kcidViewStatusBar				2031
#define kcidViewLargeIcons				2032
#define kcidViewSmallIcons				2033
#define kcidViewList					2034
#define kcidViewDetails 				2035
#define kcidViewArrangeByName			2036
#define kcidViewArrangeBySize			2037
#define kcidViewArrangeByType			2038
#define kcidViewArrangeByDateCreated	2039
#define kcidViewArrangeByDateModified	2040
#define kcidViewLineUpIcons 			2041

#define kcidFavoritesAdd				2045
#define kcidFavoritesOrganize			2046

#define kcidHelpTopics					2050

#define kcidMoveUpOneLevel				2060
