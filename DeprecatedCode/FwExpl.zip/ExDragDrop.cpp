/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: ExDragDrop.cpp
Responsibility: John Wimbish
Last reviewed:

	...

    ENHANCE: 
       - ...
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop
#undef THIS_FILE
DEFINE_THIS_FILE



/***********************************************************************************************
 IMPLEMENTATION OF ExDropSource
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Constructor. Initialize the reference count.
----------------------------------------------------------------------------------------------*/
ExDropSource::ExDropSource()
{
    m_cref = 0;
}

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
ExDropSource::~ExDropSource(void)
{
}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ExDropSource::QueryInterface(REFIID riid, void ** ppvObj)
{
	if (NULL == ppvObj) 
		return E_INVALIDARG; 

	// Set to the proper interface
	*ppvObj = NULL;
	if (IID_IUnknown == riid)
		*ppvObj = (IUnknown *) this;
	else if (IID_IDropSource == riid)
		*ppvObj = this;
	else
		return E_NOINTERFACE;

	AddRef();
	return NOERROR;
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
STDMETHODIMP_(ULONG) ExDropSource::AddRef(void)
{
    return InterlockedIncrement(&m_cref); 
}  


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
STDMETHODIMP_(ULONG) ExDropSource::Release(void)
{
	long lw = InterlockedDecrement(&m_cref);
	if (lw == 0)
		delete this;
	return lw;
}  

/*----------------------------------------------------------------------------------------------
	Determines whether a drag-and-drop operation should be continued, canceled, or completed. 
    Our code does not call this method directly; rather, the OLE DoDragDrop function calls this 
    method during a drag-and-drop operation. The DoDragDrop function calls this method
    whenever it detects a change in the keyboard or mouse button state during a drag-and-drop 
    operation. 

    Parameters:
        [in] fEsc       - TRUE if the ESC key was pressed.
        [in] dwKeyState - States of keys and mouse buttons. Valid values can be a combination
                          of any of the flags MK_CONTROL, MK_SHIFT, MK_ALT, MK_BUTTON, 
                          MK_LBUTTON, MK_MBUTTON, and MK_RBUTTON. 

    Returns an HRESULT: 
        DRAGDROP_S_CANCEL - to stop the drag,
        DRAGDROP_S_DROP   - to drop the data where it is, or 
        NOERROR           - to continue.  
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ExDropSource::QueryContinueDrag(BOOL fEsc, DWORD dwKeyState)
{
	// TODO: Add BEGIN_COM_METHOD and END_COM_METHOD macros
    // ESC was pressed: stop the drag
    if (fEsc)
        return ResultFromScode(DRAGDROP_S_CANCEL);
    
    // Left mouse no longer down: drop the data where it is
    if (!(dwKeyState & MK_LBUTTON))
        return ResultFromScode(DRAGDROP_S_DROP);

    // Otherwise, continue dragging
    return NOERROR;
}       


/*----------------------------------------------------------------------------------------------
	Enables a source application to give visual feedback to the end user during a drag-and-drop 
    operation by providing the DoDragDrop function with an enumeration value specifying the 
    visual effect.

    Parameter:
        [in] dwEffect - The DROPEFFECT value returned by the most recent call to 
                        IDropTarget::DragEnter, IDropTarget::DragOver, or IDropTarget::DragLeave. 
                        Possible values are:
                            DROPEFFECT_NONE  - Drop target cannot accept the data. 
                            DROPEFFECT_COPY  - Drop results in a copy. The original data is 
                                               untouched by the drag source. 
                            DROPEFFECT_MOVE  - Drag source should remove the data. 
                            DROPEFFECT_LINK  - Drag source should create a link to the original 
                                               data. 
                            DROPEFFECT_SCROLL -Scrolling is about to start or is currently 
                                               occurring in the target. This value is used in 
                                               addition to the other values. 

    Returns an HRESULT:
        DRAGDROP_S_USEDEFAULTCURSORS - just use the normal Windows mouse cursors.

    REVIEW(JohnW): Do we want to do anything fancy with cursors, or just leave this using
        the Windows defaults?
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ExDropSource::GiveFeedback(DWORD dwEffect)
{
    return DRAGDROP_S_USEDEFAULTCURSORS;
} 
 

