/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExDragDrop.h
Responsibility: John Wimbish
Last reviewed: never

Description:
	...
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef EXDRAGDROP_H
#define EXDRAGDROP_H 1


#ifdef EXAMPLE__
class ExDataObject : public IDataObject
{
private:
    long m_cRef;
    PCDataObject    m_pObj;
    LPUNKNOWN       m_pUnkOuter;
public:
    CImpIDataObject(PCDataObject, LPUNKNOWN);
    ~CImpIDataObject(void);
    
    //IUnknown members that delegate to m_pUnkOuter.
    STDMETHODIMP         QueryInterface(REFIID, PPVOID);
    STDMETHODIMP_(ULONG) AddRef(void);
    STDMETHODIMP_(ULONG) Release(void);
    
    //IDataObject members
    STDMETHODIMP GetData(LPFORMATETC, LPSTGMEDIUM);
    STDMETHODIMP GetDataHere(LPFORMATETC, LPSTGMEDIUM);
    STDMETHODIMP QueryGetData(LPFORMATETC);
    STDMETHODIMP GetCanonicalFormatEtc(LPFORMATETC, LPFORMATETC);
    STDMETHODIMP SetData(LPFORMATETC, LPSTGMEDIUM, BOOL);
    STDMETHODIMP EnumFormatEtc(DWORD, LPENUMFORMATETC *);
    STDMETHODIMP DAdvise(LPFORMATETC, DWORD,  LPADVISESINK, DWORD *);
    STDMETHODIMP DUnadvise(DWORD);
    STDMETHODIMP EnumDAdvise(LPENUMSTATDATA *);
}; 
#endif

/*----------------------------------------------------------------------------------------------
	...
	Hungarian: drag
----------------------------------------------------------------------------------------------*/
class ExDropSource : public IDropSource
{
protected:
    long m_cref;
    
public:
    ExDropSource();
    ~ExDropSource(void);
    
    //IUnknown interface members
    STDMETHODIMP_(ULONG) AddRef(void);
    STDMETHODIMP_(ULONG) Release(void);
    STDMETHODIMP QueryInterface(REFIID,  void ** ppv);
    
    //IDropSource interface members
    STDMETHODIMP QueryContinueDrag(BOOL, DWORD);
    STDMETHODIMP GiveFeedback(DWORD);
}; 



#endif //!EXDRAGDROP_H
