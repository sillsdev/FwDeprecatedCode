/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExNewLP.cpp
Responsibility: John Wimbish
Last reviewed: never

Description:
	...
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop

#include "Vector_i.cpp"

#undef THIS_FILE
DEFINE_THIS_FILE


/***********************************************************************************************
    ExPageGetName Implementation
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Sets the Language Name edit control to an appropriate default value.
----------------------------------------------------------------------------------------------*/
bool ExPageGetName::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
    // Set a default text into the Language Name control
    SetWindowText(kctidWizProjLanguageName, kstidWizProjDefLangName);

    SuperClass::OnInitDlg(hwndCtrl, lp);
    return false;
}

/***********************************************************************************************
    ExPageGetEthCode Implementation
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Sets the Ethnologue edit control to an appropriate default value.
----------------------------------------------------------------------------------------------*/
bool ExPageGetEthCode::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
    // Set a default text into the Ethnologue Code control
    SetWindowText(kctidWizProjEthCode, kstidWizProjDefEthCode);

    SuperClass::OnInitDlg(hwndCtrl, lp);
    return false;
}

/***********************************************************************************************
    ExPageGetLocation Implementation
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Sets up the controls on the Location page.
----------------------------------------------------------------------------------------------*/
bool ExPageGetLocation::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
    // Populate the Region combo box
	HWND hwndRegion = ::GetDlgItem(m_hwnd, kctidWizProjRegion);
    Assert(NULL != hwndRegion);
    uint rgrid[5] = {
        kstidWizProjRegAfrica,
        kstidWizProjRegAsia,
        kstidWizProjRegAmerica,
        kstidWizProjRegEurope,
        kstidWizProjRegPacific,
    };
    achar szBuffer[kMax];
    for(int i=0; i<sizeof(rgrid)/sizeof(uint); i++)
    {
        LoadString(ModuleEntry::GetModuleHandle(), rgrid[i], szBuffer, sizeof(szBuffer));
	    ::SendMessage(hwndRegion, CB_ADDSTRING, 0, (LPARAM)szBuffer);
    }
    SetWindowText(kctidWizProjRegion, kstidWizProjRegAfrica);

    SuperClass::OnInitDlg(hwndCtrl, lp);
    return false;
}



/***********************************************************************************************
    ExPageGetComputer Implementation
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Sets up the controls on the Get Computer page.
----------------------------------------------------------------------------------------------*/
bool ExPageGetComputer::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
    SuperClass::OnInitDlg(hwndCtrl, lp);

    // Subclass the Windows tree view to use our special Network treeview.
	HWND hwndNetworkTree = GetDlgItem(Hwnd(), kctidWizProjNetworkTree);
    Assert(NULL != hwndNetworkTree);
	NetworkTreeViewPtr qntv;
	qntv.Create();
	qntv->SubclassTreeView(hwndNetworkTree);

    return false;
}


/***********************************************************************************************
    ExPageGetTopicLists Implementation
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Sets up the controls on the Location page.
----------------------------------------------------------------------------------------------*/
bool ExPageGetTopicLists::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
    SuperClass::OnInitDlg(hwndCtrl, lp);
    return false;
}


/***********************************************************************************************
    ExNewLanguageProjectWizard Implementation
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool ExNewLangProjWizard::OnInitDlg(HWND hwndParent, LPARAM lp)
{
    AddPage(NewObj ExPageGetName());
    AddPage(NewObj ExPageGetEthCode());
    AddPage(NewObj ExPageGetLocation());
    AddPage(NewObj ExPageGetComputer());
    AddPage(NewObj ExPageGetTopicLists());
    AddPage(NewObj ExPageReady());
    SuperClass::OnInitDlg(hwndParent, lp);
    return false;
}
