/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExCM.h
Responsibility: John Wimbish
Last reviewed: never

Description:
	Conceptual Model wrapper classes for various items used by the Explorer. We retrieve
    data from the sql database into these classes; and then just work with these classes
    in accomplishing the Explorer tasks.

    Class ExProject embeds a SqlAccess class, through which we do ALL calls to the sql
    database. The idea is that at the project level, we store the name of the database,
    the server, etc., so this is where it is appropriate to make such sql calls. The
    SqlAccess class wraps the various methods for accessing the database, resulting in a
    relatively simple way in the rest of the code of making database calls.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef EX_CM_H
#define EX_CM_H 1

/*----------------------------------------------------------------------------------------------
	Classes declared in this file
----------------------------------------------------------------------------------------------*/
class ExFolder;
class ExProject;
class ExLangProj;
class ExDocument;
class ExTool;
typedef GenSmartPtr<ExFolder> ExFolderPtr;
typedef GenSmartPtr<ExProject> ExProjectPtr;
typedef GenSmartPtr<ExLangProj> ExLangProjPtr;
typedef GenSmartPtr<ExDocument> ExDocumentPtr;
typedef GenSmartPtr<ExTool> ExToolPtr;
typedef Vector<ExFolderPtr>   FoldV;
typedef Vector<ExDocumentPtr> DocV;
typedef Vector<ExProjectPtr>  ProjV;
typedef Vector<ExToolPtr>     ToolV;


/*----------------------------------------------------------------------------------------------
	Generic superclass for folders and documents.

    Hungarian: item
----------------------------------------------------------------------------------------------*/
class ExItem : public GenRefObj
{
public:
    ExItem();

    // Data access
    const StrUni & GetDescription();
    void SetDescription(const StrUni & stuDescription);
    void SetName(const StrUni & stuName);
    const StrUni * GetName() { return & m_stuName; }
    virtual const StrUni & Name() { return m_stuName; }

    // Stubs for accessing data; the subclasses should implement s.t. meaningful here.
    virtual int GetIcon() { Assert(0); return -1; }
    virtual const SilTime * GetTimeCreated() { return NULL; }
    virtual const SilTime * GetTimeModified() { return NULL; }
    virtual void GetType(achar * pszDest, uint cchMax)
	{
		Assert(cchMax > 0);
		*pszDest = '\0';
	}
    virtual void GetSizePhrase(achar * pszDest, uint cchMax)
	{
		Assert(cchMax > 0);
		*pszDest = '\0';
	}
    virtual void GetLocation(achar * pszDest, uint cchMax)
	{
		Assert(cchMax > 0);
		*pszDest = '\0';
	}
    void GetType(achar * pszDest, uint cchMax, uint rid);

    // Provides a Properties dlg with just a general tab.
    virtual bool LaunchPropertiesDlg(HWND hwnd);
    virtual bool IsDocument() { return false; }

protected:
    ulong   m_luId;                         // Id within the sql database
    ulong   m_luIdOwner;                    // Id within the sql database of the owning folder
    ExProject * m_pprj;                     // The parent project (somehere up the hierarchy)
    StrUni  m_stuDescription;               // Contains a comment about the object
    StrUni  m_stuName;                      // Contains the item name in the current writing system
};




/*----------------------------------------------------------------------------------------------
	This wrapper class contains the information for a folder, plus certain behavioral methods
    for convenience. The folder is also the superclass for Projects (and thus, for 
    LangProj.)

	Hungarian: fold
----------------------------------------------------------------------------------------------*/
class ExFolder : public ExItem
{
public:
    // Creation and initialization
    ExFolder();
    void Init(ulong luId, ulong luIdOwner, SilTime stimCreated, StrUni & stuName, 
        ExProject * pprj);
    void SetTreeItem(HTREEITEM hItem);

    // Interaction with UI widgets
    void AddToTree(ExFolderTreeViewPtr & qetv, HTREEITEM hParent = NULL);
    void PlaceChildrenIntoListControl(ExListViewPtr & qelvDataList);
    void PlaceDescendantDocumentsIntoListControl(int nDocType, ExListViewPtr & qelvDataList);
    void PlaceIntoListControl(ExListViewPtr & m_qelvDataList);
    void PlaceIntoComboControl(AfToolBarComboPtr & qecbCombo, int iItemNo, int nIndent);

    // Data operations
    int  UpdateDocumentList();
    void InsertChildDocument(ExDocumentPtr & qdoc);

    // Queries
    bool ContainsFolder(ExFolder * pfold);
    ExFolder * FindFolder(ulong luId);
    ExDocument * ExFolder::FindDocument(ulong luId);

    // Data Access Methods
    virtual int GetIcon() { return kridFolderClosed;}
    virtual const StrUni & DisplayName() { return m_stuName; }
    ExProject * GetOwningProject() { return m_pprj; }
    ulong GetId() { return m_luId; }
    virtual const SilTime * GetTimeCreated() { return & m_stimCreated; }
    virtual void GetType(achar * pszDest, uint cchMax);
    virtual void GetSizePhrase(achar * pszDesc, uint cchMax);
    virtual void GetLocation(achar * pszDest, uint cchMax);

    // Debugging
#ifdef DEBUG
	virtual bool AssertValid(void) const;
    bool IsFullyInitialized() { return kTree == m_nInitialized; }
#endif

    // ENHANCE: Make protected
    FoldV m_vqfold;                         // Folders that this folder owns

protected: 
    enum { kNo, kProj, kTree } m_nInitialized; // Current state of initialization
    SilTime      m_stimCreated;             // The date that the folder was created
    HTREEITEM    m_hTreeItem;               // Corresponding id within the folders tree
    DocV         m_vqdoc;                   // Documents that this folder owns

    // Low level worker methods
    void _InitFoldersFromVector(FoldV & vfold, ExProject * pprj);
};


/*----------------------------------------------------------------------------------------------
	This wrapper class contains the information about a generic project. This is in anticipation
    of having different types of projects (e.g., Language Projects, Carla Projects, etc.)

    There is an internal class, SqlAccess, which handles all queries to/from the database. 
    All queries from owned folders, etc., are funneled up to the project level. 

	Hungarian: prj
----------------------------------------------------------------------------------------------*/
class ExProject : public ExFolder
{
public:
    ExProject();
    bool Init(StrUni suServer, StrUni suDatabase, GUID guid);
    void SaveToRegistry(int iSubKeyNumber);
    virtual int GetData() { return EXIT_FAILURE; }

    // Data Access Methods
    virtual int GetIcon() { return kridFileDrawerClosed;}
    virtual char * ProjectType() { return "Generic"; }
    virtual const StrUni & DisplayName() { return m_stuDisplayName; }
    virtual const StrUni & Name() { return m_stuDisplayName; }
    const BSTR & GetServer() { return m_sql.GetServerName().Bstr(); }
    const BSTR & GetDatabase() { return m_sql.GetDatabaseName().Bstr(); }
    const GUID   GetGuid() { return m_guid; }
    virtual void GetType(achar * pszDest, uint cchMax);
	void TemporarilyDisconnectDB() { m_sql.TemporarilyDisconnectDB(); }
	bool ReconnectDB() { return m_sql.ReconnectDB(); }
	bool IsTemporarilyDisconnected() { return m_sql.IsTemporarilyDisconnected(); }

    // Embedded class: convenience methods for doing sql operations; encapsulates the
    // DbAccess function calls.
    class SqlAccess
    {
    public:
        SqlAccess();
        ~SqlAccess();
        bool Init(StrUni & stuServer, StrUni & stuDatabase);
        bool GetNextRow(StrUni & stuCommand);
        void CloseCommand();
        void DoCommand(StrUni & stuCommand);
        void GetColumnNumeric(int iColumn, ulong * pluDest);
        void GetColumnWstr(int iColumn, wchar * wszDest, ulong cluDestSize);
        void GetColumnDate(int iColumn, SilTime & stimDest);
        void GetColumnStu(int iColumn, StrUni & stuDest, bool fIsBigString = false);
        void SetTss(ITsStringPtr & qtss, ulong luId, int flid, bool fBig);
        void AddRemoteSuffix(StrUni & stuDest);
        StrUni & GetServerName() { return m_stuServer; }
        StrUni & GetDatabaseName() { return m_stuDatabase; }
		void TemporarilyDisconnectDB();
		bool ReconnectDB();
		bool IsTemporarilyDisconnected() { return m_fTemporarilyDisconnected; }
    protected:
        IOleDbEncapPtr m_qode;              // The DbAccess connectivity object
	    IOleDbCommandPtr m_qodc;            // Currently-executing command
        StrUni m_stuServer;                 // The server where this project is found
        StrUni m_stuDatabase;               // The Database containing this project
        bool m_fIsInitialized;              // T if Init() has been called
        bool m_fIsRemote;                   // T if project is not on this computer
        ComBool m_fMoreRows;                // True if we're in the midst of a command
		bool m_fTemporarilyDisconnected;
    } m_sql;

protected:
    // Attributes
    StrUni m_stuProjectName;                // The name of the project (for the splash wnd msg)
    GUID  m_guid;                           // Identifies the project (even in the xml file)
    StrUni m_stuDisplayName;                // Includes remote server name, if needed.

    // Initialization methods
    virtual bool _InitProjectBasics() {return true;}
    bool _InitProjectFolders();
    bool _InitProjectDocuments();
};



/*----------------------------------------------------------------------------------------------
	...
	Hungarian: lprj
----------------------------------------------------------------------------------------------*/
class ExLangProj : public ExProject
{
public:
    virtual void GetType(achar * pszDest, uint cchMax);

protected:
    StrUni m_stuEthnologueCode;  // Contains the three-letter Ethnologue code

    virtual char * ProjectType() { return "Language"; }

    virtual bool _InitProjectBasics();
};



/*----------------------------------------------------------------------------------------------
	...
	Hungarian: doc
----------------------------------------------------------------------------------------------*/
class ExDocument : public ExItem
{
public:
    enum DocumentTypes 
    {
        kUnknown = 0,
        kDataNotebook,
        kResultsNotebook,
        kChoicesList,
        kLexicalDatabase,
        kWordformInventory,
        kLim
    } Types;

    enum { kSizeMax = 64 };

    ExDocument();

    ulong InterpretSqlRow(ExProject * pprj);
    void Initialize(ulong luId, ulong luIdOwner, wchar * pwszName, SilTime & stimCreated,
        SilTime & stimModified, wchar * pwszClassName, ExProject *pprj);
    void PlaceIntoListControl(ExListViewPtr & m_qelvDataList);
    virtual bool IsDocument() { return true; }

    // Data Access
    int DocumentType() { return m_nType; }
    ulong GetId() { return m_luId;}
    ExProject * GetOwningProject() { return m_pprj; }
    REFIID GetRefiid();
    virtual int GetIcon();
    virtual const SilTime * GetTimeCreated() { return & m_stimCreated; }
    virtual const SilTime * GetTimeModified() { return & m_stimModified; }
    virtual void GetType(achar * pszDest, uint cchMax);
    virtual void GetSizePhrase(achar * pszDesc, uint cchMax);
    virtual void GetLocation(achar * pszDest, uint cchMax);

protected:
    bool    m_fIsInitialized;               // T if Initialize has been sucessfully called.
    SilTime m_stimCreated;                  // The date that the document was created
    SilTime m_stimModified;                 // The date that the document was last modified
    int m_nType;                            // Unique number representing the subclass of CmMajorObj
    int m_iIcon;                            // Icon representing this document subclass
    ulong m_cluSize;                        // Number of records, entries, etc in this doc.
    StrUni m_stuSizeCommand;                // Sql command to retrieve the object's size
};


/*----------------------------------------------------------------------------------------------
	An internal representation of the information regarding applications in the FieldWorks
    system. 

	Hungarian: tool
----------------------------------------------------------------------------------------------*/
class ExTool : public GenRefObj
{
public:
    void Init(int iIcon, int nDocumentType, UINT nIdToolName);

    // User interface widgets interaction
    void PlaceIntoComboControl(AfToolBarComboPtr & qecbCombo, int iItemNo);
    void PlaceIntoTreeControl(ExToolTreeViewPtr & qetv);

    // Data Access
    const StrUni & Name() { return m_stuName; }
    int GetIcon() { return m_iIcon; }
    int GetDocumentType() { return m_nDocumentType; }

protected:
    StrUni m_stuName;                       // The name of the tool
    int m_iIcon;                            // Icon representing this tool
    int m_nDocumentType;                    // The DocumentType that this tool supports
    HTREEITEM m_hTreeItem;                  // Corresponding id within the folders tree
};

/*----------------------------------------------------------------------------------------------
	A root object which owns the projects, folders, documents and tools; as represented by 
    the other classes in this header file.

	Hungarian: root
----------------------------------------------------------------------------------------------*/
class ExRoot : public GenRefObj
{
public:
    // Construction, destruction, initialization, etc.
    void Init(ExFolderTreeViewPtr & qetvFolders, ExToolTreeViewPtr & qetvTools);
    void AddTool(int iIcon, int nDocumentType, UINT nIdToolName, ExToolTreeViewPtr & qetv);
    int AddProjectsFromRegistry();
    bool AddLangProj(StrUni stuServer, StrUni stuDatabase, GUID guid);
	void AddProjectsToTree(ExFolderTreeViewPtr & qetv);
	void AddLastProjectToTree(ExFolderTreeViewPtr & qetv);
    void RemoveProject(ExProject * pproj);
    void Clear();
    void SaveToRegistry();

    // Data Access
    const int NumberOfProjects() { return m_vqprj.Size(); }
    const int NumberOfTools()    { return m_vqtool.Size(); }
    ExProject  * GetProject(BSTR bstrDisplayName);
    ExProject  * GetProject(int i);
    ExProject  * GetSelectedProject(ExFolderTreeViewPtr & qetvFolders);
    ExTool     * GetTool(BSTR bstrName);
    ExTool     * GetTool(int i);

protected:
    // Attributes
	ProjV m_vqprj;                          // Projs currently open in the Explorer
    ToolV m_vqtool;                         // Tools currently in the Tools tree view

    bool IsProjectAlreadyOpen(StrUni stuServer, StrUni stuDatabase, GUID guid);
};


#endif //!EX_CM_H
