/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: DlgFileOpen.h
Responsibility: John Wimbish
Last reviewed: Not yet.

Description:
	Header file for the Open File dialog class.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef DLGFILEOPEN_H_INCLUDED
#define DLGFILEOPEN_H_INCLUDED

char * CreateDisplayableNetworkName(char *pszSrc);


// Class for building the list of projects
class ProjectInfo
{
public:
    ProjectInfo(const ProjectInfo & piSource);
    ProjectInfo(int nProjectId, StrUni & stuDatabaseName, wchar * pwszProjectName, GUID guid);
    const StrUni & GetDisplayName();
    static void CheckDuplicationNames(Vector<ProjectInfo> * pvpi);
    int GetProjectId() { return m_nProjectId; }
    const StrUni & GetDatabaseName() { return m_stuDatabaseName;}
    const StrUni & GetProjectName()  { return m_stuProjectName;}
    GUID GetGuid() { return m_guid; }
protected:
    int    m_nProjectId;
    StrUni m_stuDatabaseName;
    StrUni m_stuProjectName;
    GUID   m_guid;
    bool   m_fDuplicateProjectName;
};

////
class DlgFileOpen : public AfDialog 
{
public:
    DlgFileOpen();
    virtual ~DlgFileOpen() {}
    bool GetSelectedProject(int & nProjectId, StrUni & stuProject, StrUni & stuDatabase, 
        StrUni & stuMachine, GUID * guid);

protected:
	NetworkTreeViewPtr m_qntv;              // The network tree control
    HIMAGELIST m_himlTree;                  // Image list used in the tree control
    HIMAGELIST m_himlList;                  // Image list used in the listview control
//    HWND m_hwndTree;                        // For convenience, the tree control's handle.
    HWND m_hwndList;                        // For convenience, the list control's handle.
	achar m_szLocalMachineName[256];		// E,g, Ac-wimbishj
    bool m_fConnected;                      // If F, we couldn't connect to target machine
	achar m_szServerName[256];				// The machine currently selected in the tree ctrl

    int m_nProjectId;                       // Id of currently-selected project
    StrUni m_stuDatabase;                   // Database name of currently-selected project
    StrUni m_stuProject;                    // Name of the currently-selected project
    StrUni m_stuMachine;                    // Machine containing currently-selected project
    GUID   m_guid;                          // Guid of the currently-selected project
    bool n_fProjectIsSelected;              // If true, we've got a project in the list box


	bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	bool OnNotifyChild(int id, NMHDR * pnmh, long & lnRet);
	virtual void DoDataExchange(AfDataExchange * padx);

#ifdef MARKED_FOR_DESTRUCTION
    bool GetLocalMachineName();
    bool PopulateNetworkNeighborhood();
    bool PopulateEntireNetwork(HTREEITEM hTreeNeighborhood, NETRESOURCE *pnetrParent);
    void ExpandGroupNode(TVITEM *item);
    bool FindChildNetResource(char *pszTarget, NETRESOURCE *pnetrParent, 
        char *pszBuffer, DWORD *cBufferSize);
#endif
    void FillListControl(NMTREEVIEW *pnmtv);

#ifdef MARKED_FOR_DESTRUCTION
    // Convenient methods for dealing with a tree control
    HTREEITEM InsertIntoTree(HTREEITEM hParent, char *pszText, int iImage);
    void GetItemText(HTREEITEM hItem, char *pszText, int cText);
#endif

    Vector<ProjectInfo> m_vpi; 
};

typedef GenSmartPtr<DlgFileOpen> DlgFileOpenPtr;


#endif  // DLGFILEOPEN_H_INCLUDED
