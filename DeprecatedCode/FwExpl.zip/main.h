/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: main.h
Responsibility: John Wimbish
Last reviewed: never

Description:
	Main header file for the FieldWorks Explorer EXE.
----------------------------------------------------------------------------------------------*/
#pragma once
#ifndef EXPLMAIN_H
#define EXPLMAIN_H 1

/***********************************************************************************************
	Resource headers
***********************************************************************************************/
#include "res\resource.h"


/***********************************************************************************************
	Generic header files.
***********************************************************************************************/
#include "Common.h"

#include "Oledb.h"
#include "Msdasc.h"
#include "Oledberr.h"

/***********************************************************************************************
	Additional AppCore headers.
***********************************************************************************************/
#include "AfCore.h"

#include "NotebkTlb.h"
#include "DbServicesTlb.h"
#include "CleTlb.h"
#include "TssWidgets.h"
#include "wn95scm.h"

/***********************************************************************************************
	Code headers
***********************************************************************************************/

#pragma warning (disable : 4172)   // returning address of local variable or temporary
#pragma warning (disable : 4189)   // local variable is initialized but not referenced

#include "ExListView.h"
#include "ExTreeView.h"
#include "ExCM.h"
#include "ExNewLp.h"
#include "DlgFileOpen.h"
#include "ExMainWnd.h"
#include "Explorer.h"
#include "ExDragDrop.h"
#include "ExProperties.h"


/***********************************************************************************************
	Stuff in ExUtilities.cpp
***********************************************************************************************/
bool ParseGuid(const char * pszGuid, GUID * pguidRet);
void InsertIntoComboControl(AfToolBarComboPtr & qecbCombo, const StrUni & stu, int nIcon, 
    int iItemNo, int nIndent, HTREEITEM hTreeItem);
void InsertItemIntoListViewCtrl(HWND hwndList, int iItem, achar * pszText, 
    int iImage = -1, int iSubItem = 0);
int GetListViewSelection(HWND hwndList);

// Plays things like the roving flashing animation.
// Hungarian: anim
class ExAnimateCtrl
{
public:
    ExAnimateCtrl(HWND hwndParent, int kridAviClip, int cx, int cy);
    ~ExAnimateCtrl();
    void StopAndRemove();
protected:
    HWND m_hwndCtrl;
};

#define kMax 512   // Size for work/temprary string buffers


#endif // !EXPLMAIN_H
