/*----------------------------------------------------------------------------------------------
Copyright 1999, SIL International. All rights reserved.

File: ExListView.cpp
Responsibility: John Wimbish
Last reviewed:

	Implementation of ExListView.

    ENHANCE: 
       - 
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop
#undef THIS_FILE
DEFINE_THIS_FILE

extern ExplorerApp g_app;

/***********************************************************************************************
	CONSTRUCTION, CREATION, ETC.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Constructs the list view, setting up the member variables.
----------------------------------------------------------------------------------------------*/
ExListView::ExListView()
{
    m_iSortedColumn = 0;                         // Sort the first column
    m_fSortAscending = true;                     // Default to a-z.
}


/*----------------------------------------------------------------------------------------------
	Creates the list view window, doing initializations that require an hwnd.
----------------------------------------------------------------------------------------------*/
void ExListView::Create(AfWnd * pwndParent, uint rid)
{
    WndCreateStruct ows;
	ows.InitChild(WC_LISTVIEW, pwndParent->Hwnd(), rid);
	ows.style |= WS_VISIBLE | WS_BORDER | LVS_REPORT ;
	ows.dwExStyle |= WS_EX_CLIENTEDGE;
	ows.lpCreateParams = pwndParent;
    ows.lpszName  = _T("List View");
	CreateAndSubclassHwnd(ows);

    // Set up the Image lists (we can't share with other Explorer controls because the masking
    // gets lost. Don't ask me why.
    Assert(m_himlSmall == NULL && m_himlLarge == NULL);
    m_himlSmall = ImageList_Create(17, 17, ILC_COLORDDB | ILC_MASK, 20, 5);
    m_himlLarge = ImageList_Create(35, 35, ILC_COLORDDB | ILC_MASK, 20, 5);
    HBITMAP hbmImageSmall = LoadBitmap(g_app.GetInstance(), MAKEINTRESOURCE(kridImagesSmall));
    HBITMAP hbmImageLarge = LoadBitmap(g_app.GetInstance(), MAKEINTRESOURCE(kridImagesLarge));
    ImageList_AddMasked(m_himlSmall, hbmImageSmall, RGB(255,255,255));
    ImageList_AddMasked(m_himlLarge, hbmImageLarge, RGB(255,255,255));
    DeleteObject(hbmImageSmall);
    DeleteObject(hbmImageLarge);
    ListView_SetImageList(Hwnd(), m_himlLarge, LVSIL_NORMAL);
    ListView_SetImageList(Hwnd(), m_himlSmall, LVSIL_SMALL);
}


/*----------------------------------------------------------------------------------------------
	Adds a column to the list view. 
----------------------------------------------------------------------------------------------*/
void ExListView::AppendColumn(uint ridColumnTitle, int nWidth, ColumnType eColType )
{
    Assert(eColType >= 0 && eColType < kMaxType);

    // Get the current number of columns in the control
    int cColumns = GetNumberOfColumns();

    // Structure for column definition
    FW_LVCOLUMN lvc;
    lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT ;
    lvc.fmt  = LVCFMT_LEFT;
    lvc.cx   = nWidth;
    lvc.iSubItem = cColumns;
    lvc.iImage = 0;
    lvc.iOrder = cColumns;

    // Retrieve Column Header string from resources, convert to wide characters
    achar szBuffer[512];
    LoadString(g_app.GetInstance(), ridColumnTitle, szBuffer, sizeof(szBuffer));
    int cHeaderLen = _tcslen(szBuffer);

#ifdef UNICODE
    g_app.MakeUIString(szBuffer, cHeaderLen, lvc.qtss);
#else
    WCHAR wszBuffer[512];
    MultiByteToWideChar(CP_ACP, 0, szBuffer, -1, wszBuffer, 512);
    g_app.MakeUIString(wszBuffer, cHeaderLen, lvc.qtss);
#endif

    // Finally, insert the column into the control and into the type vector
    InsertColumn(cColumns, &lvc);
    m_rgColumnTypes[cColumns] = eColType;
}



/***********************************************************************************************
	DATA ACCESS
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
int ExListView::GetNumberOfColumns()
{
    HWND hwndHeader = GetHeaderCtrl();
    Assert(hwndHeader);
    int cColumns = Header_GetItemCount(hwndHeader);
    Assert(-1 != cColumns);
    return cColumns;
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
ITsStringPtr &ExListView::GetSubItemText(int iItem, int iSubitem, ITsStringPtr &qtss)
{
    FW_LVITEM flvi;
    flvi.iItem = iItem;
    flvi.iSubItem = iSubitem;
    GetItemText(iItem, &flvi);
    qtss = flvi.qtss;
    return qtss;
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
void ExListView::SetSubItemText(int iItem, int iSubitem, ITsStringPtr &qtss)
{
    FW_LVITEM flvi;
    flvi.iItem = iItem;
    flvi.iSubItem = iSubitem;
    flvi.qtss = qtss;
    SetItemText(iItem, &flvi);
}


/*----------------------------------------------------------------------------------------------
	Returns the image number of the image at the given row
----------------------------------------------------------------------------------------------*/
int ExListView::GetItemImage(int iRow)
{
    FW_LVITEM flvi;
    flvi.mask = LVIF_IMAGE;
    flvi.iItem = iRow;
    flvi.iSubItem = 0;
    GetItem( &flvi );
    return flvi.iImage;
}

/***********************************************************************************************
	SORTING
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Parses the date into the year, month and day values of a _SYSTEMTIME. Currently assumes
    a date in the format "MM/DD/YY" or MM/DD/YYYY". MM and DD can have leading zero or not.

    ENHANCE: Beef this up to deal with internationalization dates. We probably want some
    method to carefully control what is placed into the list view, so that when we pull it
    out for parsing, we can know it will definitely parse.
----------------------------------------------------------------------------------------------*/
void ExListView::ParseDate(const wchar * pszw, _SYSTEMTIME * ptimeOut)
{
    ptimeOut->wYear = ptimeOut->wMonth = ptimeOut->wDay = 0;

    ptimeOut->wMonth = (unsigned short)_wtoi(pszw);

    while ( *pszw && *pszw != '/')
        ++pszw;
    if (*pszw == '/')
        ++pszw;

    ptimeOut->wDay = (unsigned short)_wtoi(pszw);

    while ( *pszw && *pszw != '/')
        ++pszw;
    if (*pszw == '/')
        ++pszw;

    ptimeOut->wYear = (unsigned short)_wtoi(pszw);
    if (ptimeOut->wYear < 50)          // Interpret '00' to '49' as '2000' to '2049'
        ptimeOut->wYear += 2000;
    else if(ptimeOut->wYear < 100)     // Interpret '50' to '99' as '1950' to '1999'
        ptimeOut->wYear += 1900;
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
int ExListView::CompareItems(int i1, int i2)
{
    // Primary sort key deals with folder images, we want them all in one group
    if (GetItemImage(i1) == kFolderImage && GetItemImage(i2) != kFolderImage)
        return (m_fSortAscending) ? -1 : 1;
    if (GetItemImage(i1) != kFolderImage && GetItemImage(i2) == kFolderImage)
        return (m_fSortAscending) ? 1 : -1;

    // Retrieve the strings from the list control
    BSTR bstr1, bstr2;
    ITsStringPtr qtss1, qtss2;
    GetSubItemText(i1, m_iSortedColumn, qtss1);
    qtss1->get_Text(&bstr1);
    GetSubItemText(i2, m_iSortedColumn, qtss2);
    qtss2->get_Text(&bstr2);

    // Handle the ascending / descending distinction
    BSTR * pbstr1 = (m_fSortAscending) ? &bstr1 : &bstr2;
    BSTR * pbstr2 = (m_fSortAscending) ? &bstr2 : &bstr1;

    // Secondary key: deal with the data, comparing based on the column type
    switch (m_rgColumnTypes[m_iSortedColumn])
    {
    case kStartInteger:
        return( _wtoi(*pbstr1) - _wtoi(*pbstr2) );

    case kDate:
        {
        // If 1 is empty and 2 has content, then 1 is smaller
        if( !*pbstr1 && *pbstr2) 
            return -1;
        // If 1 has content and 2 is empty, then 1 is larger
        if( *pbstr1 && !*pbstr2) 
            return  1;
        // If both 1 and 2 are empty, then they are considered the same
        if( !*pbstr1 && !*pbstr2) 
            return  0;
        // Parse into time
        _SYSTEMTIME time1, time2;
        ParseDate((const wchar_t*)(*pbstr1), &time1);
        ParseDate((const wchar_t*)(*pbstr2), &time2);
        if (time1.wYear != time2.wYear)
            return time1.wYear - time2.wYear;
        if (time1.wMonth != time2.wMonth)
            return time1.wMonth - time2.wMonth;
        return time1.wDay - time2.wDay;
        }

    case kString:
        return _wcsicmp( (const wchar_t*)(*pbstr1), (const wchar_t*)(*pbstr2));
    }

    // Shouldn't ever get here.
    Assert(false);
    return 0;
}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
void ExListView::SwapItems( int i1, int i2)
{
    int i;

    // Don't bother if they're the same item.
    if (i1 == i2)
        return;

    // Retrieve state information about the two rows. We use this to swap
    // the images, selected state, etc. (Everything but the text.)
    FW_LVITEM lvi1, lvi2;
    lvi1.mask = LVIF_IMAGE | LVIF_PARAM | LVIF_STATE;
    lvi1.iSubItem = 0;
    lvi1.stateMask = LVIS_CUT | LVIS_DROPHILITED | LVIS_FOCUSED | LVIS_SELECTED | 
        LVIS_OVERLAYMASK | LVIS_STATEIMAGEMASK;
    lvi2 = lvi1;
    lvi1.iItem = i1;
    lvi2.iItem = i2;
    GetItem(&lvi1);
    GetItem(&lvi2);

    // vtssRowText will hold all column text for one row
    ComVector<ITsString> vtssRowText;
    int cColCount = GetNumberOfColumns();
    vtssRowText.EnsureSpace(cColCount, true);

    // First part of swap: save the first value as Temp
    ITsStringPtr qtss1;
    for( i=0; i<cColCount; i++)
        vtssRowText.Insert(i, GetSubItemText(i1, i, qtss1));

    // Second part of swap: Place the second value into the first position
    ITsStringPtr qtss2;
    for( i=0; i<cColCount; i++)
        SetSubItemText(i1, i, GetSubItemText(i2, i, qtss2));
    lvi2.iItem = i1;
    SetItem( &lvi2 );

    // Last part of swap: Place the Temp value into the second position
    for( i=0; i<cColCount; i++)
        SetSubItemText(i2, i, vtssRowText[i]);
    lvi1.iItem = i2;
    SetItem( &lvi1 );
}

/*----------------------------------------------------------------------------------------------
	Uses the QSort algorithm to perform a sort on the current column in the list control.

    ListView member variables used:
        m_iSortedColumn - specifies which column will be sorted.
        m_fSortAscending - direction of sort (ascending if T, else descending).

    Credit: This code originated directly from code posted on the Internet by Zafir Anjum at
    www.codeguru.com, an Internet site of free source code for MFC applications. It includes 
    additions by Tal J. Rosen (same Internet site) to make it compare dates and integers 
    (Anjum's code was just for strings). It has been changed here (various clarifications,
    adaptation to TsString, etc.)
----------------------------------------------------------------------------------------------*/
bool ExListView::Sort(int iLow /*= 0*/, int iHigh /*= -1*/)
{
    // Make sure the desired column is in acceptable range for the header
    Assert(m_iSortedColumn >= 0 && m_iSortedColumn < GetNumberOfColumns());

    // Set up for the sort (including recursive setup)
    if( iHigh == -1 ) 
        iHigh = GetItemCount() - 1;
    int iLo = iLow;
    int iHi = iHigh;
    if( iHi <= iLo ) 
        return false;
    int iMidItem = (iLo + iHi)/2;

    while( iLo <= iHi )
    {
        // find the first element that is greater than or equal to
        // the partition element starting from the left Index.
        while( (iLo<iHigh) && ( CompareItems(iLo,iMidItem) < 0 ) )
            ++iLo;

        // find an element that is smaller than or equal to
        // the partition element starting from the right Index.
        while( (iHi>iLow) && ( CompareItems(iHi,iMidItem) > 0 ) )
            --iHi;

        // if the indexes have not crossed, and if the items are not equal, swap
        if( iLo <= iHi) 
        {
            // swap only if the items are not equal
            if( iLo != iHi && CompareItems(iLo,iHi) != 0 ) 
            {
                // We must update iMidItem so that it still points to what it used to
                // point to.
                if (iMidItem == iLo)
                    iMidItem = iHi;
                else if (iMidItem == iHi)
                    iMidItem = iLo;

                // Now swap the items.
                SwapItems(iLo, iHi);
            }

            ++iLo;
            --iHi;
        }
    }

    // If the right index has not reached the left side of array, sort the left partition.
    if( iLow < iHi )
        Sort( iLow, iHi);

    // If the left index has not reached the right side of array, sort the right partition.
    if( iLo < iHigh )
        Sort( iLo, iHigh );

    return true;
}

/*----------------------------------------------------------------------------------------------
	Given a click on the header of the list, process it to determine what kind of sorting
    to do. If it is a left click, then we will sort that column. If the column is already
    sorted, then we reverse the order (from ascending to descending.)
----------------------------------------------------------------------------------------------*/
void ExListView::OnListHeaderButtonClicked(NMHEADER * pInfo)
{
    // Ignore if something other than the left mouse button
    if (0 != pInfo->iButton)
        return;

    // If it is the same column as previously, then reverse the ascending thing
    if (pInfo->iItem == m_iSortedColumn)
        m_fSortAscending = !m_fSortAscending;
    else
        m_fSortAscending = true;
    m_iSortedColumn = pInfo->iItem;

    // We're all set. Do the sort.
    Sort();
}



/*----------------------------------------------------------------------------------------------
	Dispatch messages from the Header child window.
----------------------------------------------------------------------------------------------*/
bool ExListView::OnNotifyChild(int id, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	switch(pnmh->code)
	{
    // The user has clicked on one of the column header buttons (sort the column)
	case HDN_ITEMCLICKA:
	case HDN_ITEMCLICKW:
        OnListHeaderButtonClicked((NMHEADER*) pnmh);
		break;

	// Default is do nothing.
    default:
        break;
	}

	return SuperClass::OnNotifyChild(id, pnmh, lnRet);
}



/***********************************************************************************************
	DISPLAY MODE
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
void ExListView::SetMode(long lMode)
{
  	long lStyle = GetWindowLong(Hwnd(), GWL_STYLE);
    lStyle &= ~(LVS_TYPEMASK);               // turn off all style (view mode) bits
    lStyle |= lMode;		                 // Set the new Style for the control
    SetWindowLong(Hwnd(), GWL_STYLE, lStyle);  // done!
}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool ExListView::IsMode( long lMode ) 
{
    long lStyle = GetWindowLong(Hwnd(), GWL_STYLE);
    lStyle &= (LVS_TYPEMASK);                // turn off all non-style (view mode) bits
    return lStyle == lMode;
}



/***********************************************************************************************
	MISCELLANEOUS
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Override of the WM_PAINT hander to handle the case where there are no items in the list.
    We want to display a message to the effect that "there ain't nothing to display." 

    OnPaint should false if it did not process the message, true if it did. Through some
    trial and error, it would appear that returning false gives the desired behavior,
    because some painting is still handled by the ListView control. Apparently the
    BeginPaint/EndPaint sequence handles validation of the window so that everything
    happens appropriately.
----------------------------------------------------------------------------------------------*/
bool ExListView::OnPaint(HDC hdc)
{ 
    // If it has content, return to the parent for painting.
    if (0 != GetItemCount())
        return false; 

    // Set up to paint. By calling BeginPaint, proper window invalidations apparently take place.
    PAINTSTRUCT paint;
    hdc = BeginPaint(Hwnd(), &paint);
    if (NULL == hdc)
        return false;

    // Save the dc state, as we're going to change it.
    int nSavedDc = SaveDC(hdc);
    if (0 == nSavedDc)
        return false;
    ::SetTextColor(hdc, GetSysColor(COLOR_WINDOWTEXT));
    ::SetBkColor(hdc, GetSysColor(COLOR_WINDOW));
	::SelectObject(hdc, ::GetStockObject(DEFAULT_GUI_FONT));

    // Determine the bounding rectangle within which we will draw the text.
    RECT rect;
    GetWindowRect(Hwnd(), &rect);
    POINT pt;
    pt.x = rect.right;
    pt.y = rect.bottom;
    ScreenToClient(Hwnd(), &pt);
    int xpHeight = pt.y;
    int xpWidth  = pt.x;
    int xpTop = 0;

    // In report view, the header shows, so we must paint a bit lower.
    HWND hwndHeader = ListView_GetHeader(Hwnd());
    if (hwndHeader && IsWindowVisible(hwndHeader))
    {
        RECT rectHeader;
        Header_GetItemRect(hwndHeader, 0, &rectHeader);
        xpTop += rectHeader.bottom;
    }

    RECT rectDraw;
    rectDraw.top = xpTop;
    rectDraw.left = 3;          // Leave a small left margin
    rectDraw.right = xpWidth;
    rectDraw.bottom = xpHeight;

    // Retrieve and draw the message
    achar szMessage[512];
    ::LoadString( g_app.GetInstance(), kstidNoItemsInTheList, szMessage, sizeof(szMessage));
    DrawText(hdc, szMessage, _tcslen(szMessage), &rectDraw,
		DT_LEFT | DT_WORDBREAK | DT_NOPREFIX | DT_NOCLIP );

    // Set things back to how they were before the draw
    RestoreDC(hdc, nSavedDc);
    EndPaint(Hwnd(), &paint);

    // The ListView may have other drawing to do
    return false;
}



/*----------------------------------------------------------------------------------------------
	Handle window messages.

    Return true if we handle the message, false otherwise (in which case the superclass
    will handle it.)
----------------------------------------------------------------------------------------------*/
bool ExListView::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
	AssertObj(this);
	Assert(!lnRet);

#ifdef WHEN_NEEDED
	switch (wm)
	{          
	case WM_LBUTTONDOWN:
        return false;
        break;
    }
#endif

	return SuperClass::FWndProc(wm, wp, lp, lnRet);
}


/*----------------------------------------------------------------------------------------------
	Returns the ID of the selected item. If nothing is selected, returns NULL. 

    This method will only return the ID of the first selected item. If the listview supports
    multiple selected items, subsequent items will not be returned.
----------------------------------------------------------------------------------------------*/
ExItem * ExListView::GetSelectedItem()
{
    // Is there anything selected in the list box? Return -1 if not.
    if (0 == ListView_GetSelectedCount(Hwnd()))
        return NULL;

    // Locate the selected item
    int iMax = ListView_GetItemCount(Hwnd());
    for(int iSelectedItem = 0; iSelectedItem < iMax; iSelectedItem++)
    {
        if (ListView_GetItemState(Hwnd(), iSelectedItem, LVIS_SELECTED))
            break;
    }
    Assert(iSelectedItem != iMax);

    // Get the list item's information.
    FW_LVITEM flvi;
    flvi.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM;
    flvi.iItem = iSelectedItem;
    flvi.iSubItem = 0;
    GetItem(&flvi);
    ExItem * pitem = (ExItem *)flvi.lParam;

    // A null pitem means the list item was not properly initialized.
    Assert(NULL != pitem);

    return pitem;
}




