/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExUtilities.cpp
Responsibility: John Wimbish
Last reviewed: never

Description:
	This module provides various utilities for the Explorer code. The function declarations
	are in Main.h
----------------------------------------------------------------------------------------------*/

#include "Main.h"
#pragma hdrstop
#undef THIS_FILE
DEFINE_THIS_FILE

extern ExplorerApp g_app;


/*----------------------------------------------------------------------------------------------
	Returns the index of the first item in the list view which is selected, or -1 if no
    list item is selected.
----------------------------------------------------------------------------------------------*/
int GetListViewSelection(HWND hwndList)
{
    // Is there anything selected in the list box? Return -1 if not.
    if (0 == ListView_GetSelectedCount(hwndList))
        return -1;

    // Locate the selected item
    int iMax = ListView_GetItemCount(hwndList);
    for(int i=0; i<iMax; i++)
    {
        if (ListView_GetItemState(hwndList, i, LVIS_SELECTED))
            break;
    }
    Assert(i != iMax);
    return i;
}


/***********************************************************************************************
	IMPLEMENTATION OF ExAnimateCtrl
***********************************************************************************************/

ExAnimateCtrl::ExAnimateCtrl(HWND hwndParent, int kridAviClip, int cx, int cy)
{
    m_hwndCtrl = Animate_Create(hwndParent, kridAviClip, 
        WS_CHILD | WS_VISIBLE | ACS_AUTOPLAY | ACS_CENTER | ACS_TRANSPARENT,
        g_app.GetInstance());
    if (NULL == m_hwndCtrl)
        return;
    SetWindowPos(m_hwndCtrl, NULL, cx, cy, 60, 60, SWP_NOZORDER | SWP_DRAWFRAME);
    if (0 == Animate_Open(m_hwndCtrl, MAKEINTRESOURCE(kridAviClip)))
    {
        DestroyWindow(m_hwndCtrl);
        m_hwndCtrl = NULL;
        return;
    }
    if (0 == Animate_Play(m_hwndCtrl, 0, -1, -1))
    {
        DestroyWindow(m_hwndCtrl);
        m_hwndCtrl = NULL;
        return;
    }
}

ExAnimateCtrl::~ExAnimateCtrl()
{
    StopAndRemove();
}

void ExAnimateCtrl::StopAndRemove()
{
    if (m_hwndCtrl)
    {
        Animate_Stop(m_hwndCtrl);
        Animate_Close(m_hwndCtrl);
        DestroyWindow(m_hwndCtrl);
        m_hwndCtrl = NULL;
    }
}


/***********************************************************************************************
	MISC
***********************************************************************************************/
void InsertItemIntoListViewCtrl(HWND hwndList, int iItem, achar * pszText, int iImage,
	int iSubItem)
{
    LVITEM item;
    item.iSubItem = iSubItem; 
    item.mask = LVIF_TEXT;
    if (-1 != iImage)
    {
        item.iImage = iImage;
        item.mask |= LVIF_IMAGE;
    }
    item.iItem = iItem; 
    item.pszText = pszText;
    item.cchTextMax = _tcslen(item.pszText);
    ListView_InsertItem(hwndList, &item);
}


/*----------------------------------------------------------------------------------------------
    Inserts an item into the TssCombo control.

    Parameters:
        qecbCombo - the combo control into which to do the insertion. 
        qtss - the text of the combo control
        nIcon - the icon to display to the left of the text. The bitmap from which this comes
            should be arranged so that nIcon + 1 is the selected version of the image.
        iItemNo - the position in the list into which to do the insertion.
        nIndent - The amount of indentation for the item. The integer passed in is multipled
            by a factor of 10 pixels by the combo control.
----------------------------------------------------------------------------------------------*/
void InsertIntoComboControl(AfToolBarComboPtr & qecbCombo, const StrUni & stu, int nIcon, 
    int iItemNo, int nIndent, HTREEITEM hTreeItem)
{
    FW_COMBOBOXEXITEM it;
    it.iImage = nIcon;
    it.iSelectedImage = nIcon + 1;
    it.iIndent = nIndent;
    it.iItem = iItemNo;
    it.mask = CBEIF_TEXT;
    it.mask = CBEIF_IMAGE | CBEIF_INDENT | CBEIF_SELECTEDIMAGE | CBEIF_TEXT | CBEIF_LPARAM;
    g_app.MakeUIString(stu, it.qtss);
    it.lParam = (LPARAM)hTreeItem;
    qecbCombo->InsertItem(&it);
}


/*----------------------------------------------------------------------------------------------
	Try to parse a string as a guid.  Return true if successful, and otherwise return false.
	// REVIEW SteveMc: make this a general purpose utility function?
	// REVIEW SteveMc: should we handle other formats?

    NOTE: SteveM gave me this for now; he intends to make it part of the system
    at some later date, at which time I'll remove it from here.
----------------------------------------------------------------------------------------------*/
static const char g_szHexDigits[23] = "0123456789ABCDEFabcdef";
bool ParseGuid(const char * pszGuid, GUID * pguidRet)
{
	AssertPsz(pszGuid);
	AssertPtr(pguidRet);
	int cSect = 0;
	char * psz = NULL;
	char szBuffer[4];
	GUID guid;
	if (strlen(pszGuid) != 36)		// (For example, "9261D3B0-F064-11d3-9041-00400541F6D3".)
		return false;
	memset(szBuffer, 0, isizeof(szBuffer));
	memset(&guid, 0, isizeof(GUID));
	if (*pszGuid)
	{
		guid.Data1 = strtoul(pszGuid, &psz, 16);
		++cSect;
	}
	if (psz && *psz == '-')
	{
		guid.Data2 = static_cast<ushort>(strtol(psz+1, &psz, 16));
		++cSect;
	}
	if (psz && *psz == '-')
	{
		guid.Data3 = static_cast<ushort>(strtol(psz+1, &psz, 16));
		++cSect;
	}
	if (psz && *psz == '-')
	{
		++psz;
		if (strspn(psz, g_szHexDigits) == 4)
		{
			memcpy(szBuffer, psz, 2);
			guid.Data4[0] = static_cast<uchar>(strtol(szBuffer, NULL, 16));
			++cSect;
			psz += 2;
			guid.Data4[1] = static_cast<uchar>(strtol(psz, &psz, 16));
			++cSect;
		}
		else
			psz = NULL;
	}
	if (psz && *psz == '-')
	{
		++psz;
		if (strspn(psz, g_szHexDigits) == 12)
		{
			for (int i = 2; i < 7; ++i)
			{
				memcpy(szBuffer, psz, 2);
				guid.Data4[i] = static_cast<uchar>(strtol(szBuffer, NULL, 16));
				++cSect;
				psz += 2;
			}
			guid.Data4[7] = static_cast<uchar>(strtol(psz, &psz, 16));
			++cSect;
		}
	}
	if (cSect == 11)
	{
		memcpy(pguidRet, &guid, isizeof(GUID));
		return true;
	}
	else
	{
		return false;
	}
}
