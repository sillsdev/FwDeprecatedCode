/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExProperties.h
Responsibility: John Wimbish
Last reviewed: never

Description:
	...
----------------------------------------------------------------------------------------------*/

class ExPropGenTab;
class ExDlgProperties;


/*----------------------------------------------------------------------------------------------
	Provides the functionality particular to the General tab for a properties dialog.
	Hungarian: dlpg.
----------------------------------------------------------------------------------------------*/
class ExPropGenTab : public AfDialogView
{
typedef AfDialogView SuperClass;
public:
    ExPropGenTab(ExDlgProperties * pdlp, ExItem * pitem);
    ~ExPropGenTab();
    void Save();

protected:
	ExDlgProperties * m_pdlpParent;
    ExItem * m_pitem;
    HICON    m_hicon;
    HFONT    m_hfontLargeName;
    StrUni   m_stuName;
    StrUni   m_stuDescription;

	bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	bool OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet);
    void SetLargeNameText();
    void SetTimeText(const SilTime * ptime, uint ridCtrl);
    void SetInfoText(achar * pszText, uint ridCtrl);
    void SetupEditCtrl(StrUni & stuInitialText, uint rid);
    void UpdateClassDataFromControls();
};


/*----------------------------------------------------------------------------------------------
	Provides for a tabbed dialog. (This is my proposal for a generic class to add to the
    AfCore stuff.)
	Hungarian: dlgt.
----------------------------------------------------------------------------------------------*/
class AfTabbedDialog : public AfDialog
{
typedef AfDialog SuperClass;

public:
    AfTabbedDialog(uint krid);
    ~AfTabbedDialog() {}
    void AddTab(AfDialogView * pdlgv, uint kridTitle);

protected:
    // Attributes
	HWND m_hwndTab;                         // child tab window (owns the tabs)
    enum { kcdlgv = 8 };                    // Max number of tabs the dialog can have
	AfDialogViewPtr m_rgdlgv[kcdlgv];       // Array of tabs in the dialog
    int  m_cTabs;                           // Number of tabs currently in the dialog
	int m_itabCurrent;                      // Tab currently being displayed
	int m_dxsClient;                        // x position for embedded pages
	int m_dysClient;                        // y position for embedded pages

    virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
    void Resize();
	bool ShowChildDlg(int itab);
};

/*----------------------------------------------------------------------------------------------
	Provides the Properties dialog. It embeds child dialogs (using the tabbed interface)
	Hungarian: dlp.
----------------------------------------------------------------------------------------------*/
class ExDlgProperties : public AfTabbedDialog
{
typedef AfTabbedDialog SuperClass;
	friend class ExPropGenTab;
public:
    ExDlgProperties();
    void Init(ExItem * pitem);

protected:
    virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	virtual bool OnApply(bool fClose);
    bool     m_bIsInitialized;             // T if the Init function has successfully completed
    ExItem * m_pitem;                      // The item for which we are showing properties
    ExPropGenTab * m_pdlpg;                // Pointer to the General tab

};

typedef GenSmartPtr<ExDlgProperties> ExDlgPropertiesPtr;
