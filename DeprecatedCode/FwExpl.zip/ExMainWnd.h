/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExMainWnd.h
Responsibility: John Wimbish
Last reviewed: never

Description:
	...
----------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------------
	Constants
----------------------------------------------------------------------------------------------*/
const int kdxMinWndWidth      = 400;   // Minimum size for the window width
const int kdyMinWndHeight     = 300;   // Minimum size for the window height
const int kdxpMinSplitter     =  50;   // Minimum size for the splitter position
const int kdxDefaultSplitPos  = 175;   // Default position of splitter


class ExplorerApp;

/*----------------------------------------------------------------------------------------------
	Our main window frame class.
----------------------------------------------------------------------------------------------*/

class ExMainWnd : public AfMainWnd
{
public:
	typedef AfMainWnd SuperClass;

    ExMainWnd(void);
    virtual ~ExMainWnd(void) {}

    HINSTANCE GetAppInst();
    ExplorerApp * GetApp();

    // Data access
    ExRoot & GetRoot() { return m_root; }

	virtual int GetMinHeight()
	{
		return kdyMinWndHeight;
	}
	virtual int GetMinWidth()
	{
		return kdxMinWndWidth;
	}

	virtual void RenameAndDeleteStyles(Vector<StrUni> & vstrOldNames,
		Vector<StrUni> & vstrNewNames, Vector<StrUni> & vstuDelNames)
	{
		Assert(false);
	}

protected:
    ExRoot m_root;
    HWND   m_hwndChildWithCurrentFocus;

	virtual void PostAttach(void);

	/*******************************************************************************************
		Message handlers.
	*******************************************************************************************/
	virtual void OnReleasePtr();
	virtual bool OnSize(int wst, int dxs, int dys);
    bool OnMouseMove(uint grfmk, int xp, int yp);
    bool OnLButtonUp(uint grfmk, int xp, int yp);
    bool OnLButtonDown(uint grfmk, int xp, int yp);
    bool OnKeyDown(WPARAM wp, LPARAM lp);

    bool TestComboSelectionChanged(uint wm, WPARAM wp);
    bool PropagateComboSelection();

    bool TestListItemDoubleClicked(uint wm, LPARAM lp);
    bool LaunchDefaultToolOnListSelection();


    // Command Handlers
    bool CmdListModeToggle(Cmd * pcmd);
    bool CmsListModeToggleUpdate(CmdState & cms);
	virtual bool CmdFileOpenProject(Cmd * pcmd);
	virtual bool CmdFileCloseProject(Cmd * pcmd);
	virtual bool CmsFileCloseProjectUpdate(CmdState & cms);
    virtual bool CmdFileProperties(Cmd * pcmd);
	virtual bool CmsFilePropertiesUpdate(CmdState & cms);
    virtual bool CmdFileNewLangProj(Cmd * pcmd);
    virtual bool CmdHelpAbout(Cmd * pcmd);
	virtual bool CmdFileBackup(Cmd * pcmd);

    // Pathname combo box in main toolbar
    AfToolBarComboPtr m_qecbPathnameCombo;
    void FillCombo(ExTool * ptoolTarget);
    void FillCombo(ExFolder * pfoldTarget);
    int _FillCombo(ExFolder * pfoldTarget, ExFolder * pfoldCurrent, int nLevel, int * nItemNo);

    // Child Tab Window, tree windows, etc.
    HWND m_hwndTab;                         // Tab control (one tab for each tree control)
    ExFolderTreeViewPtr m_qetvFolders;      // Tree control for displaying folders hierarchy
    ExToolTreeViewPtr   m_qetvTools;        // Tree control for displaying tools hierarchy
    void CreateTabChildWindow();
    void SetTreeVisibility();
    void PropagateTreeSelection(UINT nIdTree);
    bool FolderTreeIsActive();
    bool ToolTreeIsActive();

    // List view
	AfCaptionBarPtr m_qcpbrCaptionBar;      // Caption Bar window
    ExListViewPtr m_qelvDataList;           // List of data objects (corresponding to tree ctrl)
    void CreateListView();
    void UpdateCaptionBar();
    void UpdateListControl(ExFolder * pfold);
    void UpdateListControl(ExTool * ptool);

    // Image lists
    HIMAGELIST m_himlLarge;
    HIMAGELIST m_himlSmall;
    void InitializeImageLists();

    // Window split position
    int m_xSplit;                           // Current position of the split
    int m_xSplitOldPosition;                // Old position, in case user cancels split op
    bool m_fIsPositioningSplit;             // If T, we are currently repositioning the split


    void SetWindowTitle();

	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);

	virtual void PreCreateHwnd(CREATESTRUCT & cs);

    // Save, Retrieve window sizes from the registry
    void CalcCreatePos(CREATESTRUCT & cs);
    void SaveWindowPos();

	CMD_MAP_DEC(ExMainWnd);
};


typedef GenSmartPtr<ExMainWnd> ExMainWndPtr;
