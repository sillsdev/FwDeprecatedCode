/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExListView.h
Responsibility: John Wimbish
Last reviewed: never

Description:
	...
----------------------------------------------------------------------------------------------*/


#pragma once
#ifndef EXLISTVIEW_H
#define EXLISTVIEW_H 1

class ExItem;

/*----------------------------------------------------------------------------------------------
	This class supports several convenience methods, on top of the TsString Tree View.
	Hungarian: elv
----------------------------------------------------------------------------------------------*/
class ExListView : public TssListView
{
typedef TssListView SuperClass;

public:
    // Enables each individual column to sort appropriately
    enum ColumnType { 
        kString = 0,              // Each item is a string
        kStartInteger,            // Items begin with an integer (may have other stuff after)
        kDate,                    // Each item is a date
        kMaxType                  // for debugging
    };

    // Creation and Initialization
    ExListView();
    void Create(AfWnd * pwndParent, uint rid);
    void AppendColumn(uint ridColumnTitle, int nWidth, ColumnType eColType = kString);

    // Functions to get and set the mode of the list
    void SetReportMode()    { SetMode(LVS_REPORT); }
    void SetListMode()      { SetMode(LVS_LIST); }
    void SetSmallIconMode() { SetMode(LVS_SMALLICON); }
    void SetLargeIconMode() { SetMode(LVS_ICON); }
    bool IsReportMode()     { return IsMode(LVS_REPORT); }
    bool IsListMode()       { return IsMode(LVS_LIST); }
    bool IsSmallIconMode()  { return IsMode(LVS_SMALLICON); }
    bool IsLargeIconMode()  { return IsMode(LVS_ICON); }

    // Operations
    ExItem * GetSelectedItem();

    // Initialize sort
    bool SortList() {return Sort();}

protected:
    enum { kFolderImage = kridFolderClosed }; // Images to group together when sorting
    enum { kColsMax = 20 };                 // Maximum number of columns we support
    int m_iSortedColumn;                    // Which column list is currently sorted by
    bool m_fSortAscending;                  // How m_iSortedColumn is currently sorted
    ColumnType m_rgColumnTypes[kColsMax];   // A type for each column, used for sorting
    HIMAGELIST m_himlLarge;
    HIMAGELIST m_himlSmall;

    int GetNumberOfColumns();

    // Functions for sorting columns
    bool Sort(int iLow = 0, int iHigh = -1);
    int CompareItems( int i1, int i2);
    void SwapItems( int i1, int i2);
    void ParseDate(const wchar * pszw, _SYSTEMTIME * ptimeOut);

    // Getting and setting item data
    ITsStringPtr &GetSubItemText(int iItem, int iSubitem, ITsStringPtr &qtss);
    void SetSubItemText(int iItem, int iSubitem, ITsStringPtr &qtss);
    int GetItemImage(int iRow);

    // Support functions to get and set the mode of the list
    void SetMode(long lMode);
    bool IsMode(long lMode);

    // Responding to miscellaneous user actions
	virtual bool OnNotifyChild(int id, NMHDR * pnmh, long & lnRet);
    void OnListHeaderButtonClicked(NMHEADER * pInfo);
	virtual bool OnPaint(HDC hdc);
	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);

};

typedef GenSmartPtr<ExListView> ExListViewPtr;


#endif //!EXLISTVIEW_H

