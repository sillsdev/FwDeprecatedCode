/*----------------------------------------------------------------------------------------------
Copyright 2000, SIL International. All rights reserved.

File: ExProperties.cpp
Responsibility: John Wimbish
Last reviewed: never

Description:
	...
----------------------------------------------------------------------------------------------*/
#include "Main.h"
#pragma hdrstop

#include "Vector_i.cpp"

#undef THIS_FILE
DEFINE_THIS_FILE

extern ExplorerApp g_app;

/***********************************************************************************************
    AfTabbedDialog Methods
***********************************************************************************************/
AfTabbedDialog::AfTabbedDialog(uint rid)
{
	m_rid = rid;
	m_itabCurrent = -1;
	m_hwndTab = NULL;
    m_cTabs = 0;
}


/*----------------------------------------------------------------------------------------------
    Update Diaglog changes.
----------------------------------------------------------------------------------------------*/
bool AfTabbedDialog::ShowChildDlg(int itab)
{
	Assert(itab >= 0 && itab < m_cTabs);
	AssertPtr(m_rgdlgv[itab]);

	if (m_itabCurrent == itab)
		return true;

    // If this assert fires, a call to Resise() was not done.
    Assert(NULL != m_rgdlgv[itab]->Hwnd());

	if (!m_rgdlgv[itab]->SetActive())
		return false;

	::ShowWindow(m_rgdlgv[itab]->Hwnd(), SW_SHOW);

	if (m_itabCurrent != -1)
		::ShowWindow(m_rgdlgv[m_itabCurrent]->Hwnd(), SW_HIDE);

	m_itabCurrent = itab;
	TabCtrl_SetCurSel(m_hwndTab, m_itabCurrent);
	return true;
}


/*----------------------------------------------------------------------------------------------
    Add a tab to the tabbed dialog
----------------------------------------------------------------------------------------------*/
void AfTabbedDialog::AddTab(AfDialogView * pdlgv, uint kridTitle)
{
    // Make certain there is room in the array
    Assert( m_cTabs < kcdlgv - 1);

    // Insert the General Page into the array
	m_rgdlgv[m_cTabs].Attach(pdlgv);
    ++m_cTabs;

    // Insert the item into the tab control
	StrAppBuf strb;
	TCITEM ti;
	ti.mask = TCIF_TEXT;
	strb.Load(kridTitle);
	ti.pszText = const_cast<achar *>(strb.Chars());
    if (NULL == m_hwndTab)
    	m_hwndTab = GetDlgItem(m_hwnd, kcidPropertiesDlgTab);
    Assert(NULL != m_hwndTab);
	TabCtrl_InsertItem(m_hwndTab, 0, &ti);

}

/*----------------------------------------------------------------------------------------------
    Performs the following: 
    1. Sizes the tab control to just contain the largest tab page, 
    2. Places the row of buttons underneath the tab control,
    3. Sizes the dialog to just contain everything.
----------------------------------------------------------------------------------------------*/
void AfTabbedDialog::Resize()
{
    // Calculate the place where we want to display the tab pages. (This section must happen
	// after at least one tab gets added to the tab control.)
    Assert(m_cTabs > 0);
	RECT rcTab;
	::GetWindowRect(m_hwndTab, &rcTab);
	TabCtrl_AdjustRect(m_hwndTab, false, &rcTab);
	POINT pt = { rcTab.left, rcTab.top };
	::ScreenToClient(m_hwnd, &pt);
	m_dxsClient = pt.x;
	m_dysClient = pt.y;

    // Calculate the rectangle of the largest page
    int i;
    RECT rc;
    int nHeight = 0;
    int nWidth = 0;
    for (i = 0; i < m_cTabs; i++)
    {
        // Create the window if it hasn't been done already
	    if (!m_rgdlgv[i]->Hwnd())
	    {
		    HWND hwnd = ::GetFocus();
		    m_rgdlgv[i]->DoModeless(m_hwnd);
		    ::SetWindowPos(m_rgdlgv[i]->Hwnd(), NULL, m_dxsClient, m_dysClient, 0, 0,
			    SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);

		    // If this is the first time we are creating the internal dialog and the focus was
		    // on the tab control, Windows moves the focus to the dialog, so set it back.
		    if (hwnd == m_hwndTab)
			    ::SetFocus(m_hwndTab);
	    }

        // Retrieve its coordinates
    	::GetWindowRect(m_rgdlgv[i]->Hwnd(), &rc);
        nHeight = max(nHeight, rc.bottom - rc.top);
        nWidth  = max(nWidth,  rc.right  - rc.left);
    }

    // Size the tab control to just contain the largest page
    Assert(NULL != m_hwndTab);
    rcTab.right = rcTab.left + nWidth;
    rcTab.bottom = rcTab.top + nHeight;
    TabCtrl_AdjustRect(m_hwndTab, true, &rcTab);
    ::SetWindowPos(m_hwndTab, NULL, 0, 0, rcTab.right - rcTab.left, 
        rcTab.bottom - rcTab.top, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);

    // Calculate the button position
    POINT ptBtn;
    ptBtn.x = rcTab.right;
    ptBtn.y = rcTab.bottom + 5;
	::ScreenToClient(m_hwnd, &ptBtn);

   // Move the buttons
   HWND hwnd;
   RECT rcBtn;
   static uint rgidButtons[] = { kctidHelp, kctidCancel, kctidOk };
   for(i = 0; i < sizeof(rgidButtons)/sizeof(uint); i++ )
   {
       hwnd = GetDlgItem(m_hwnd, rgidButtons[i]);
       ::GetWindowRect(hwnd, &rcBtn);
       ::SetWindowPos(hwnd, NULL, 
           ptBtn.x - (rcBtn.right - rcBtn.left), ptBtn.y, 
           rcBtn.right - rcBtn.left, rcBtn.bottom - rcBtn.top, 
           SWP_NOZORDER | SWP_NOACTIVATE);
       ptBtn.x -= ((rcBtn.right - rcBtn.left) + 5);
   }

    // Size the dialog to contain the tab plus room for the buttons
    ::SetWindowPos(Hwnd(), NULL, 0, 0, rcTab.right - rcTab.left + 24, 
        rcTab.bottom - rcTab.top + 67, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
}


/*----------------------------------------------------------------------------------------------
	Initialize the dialog
----------------------------------------------------------------------------------------------*/
bool AfTabbedDialog::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
    return true;
}


/***********************************************************************************************
    General Tab (ExPropGenTab) Methods
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Constructor
----------------------------------------------------------------------------------------------*/
ExPropGenTab::ExPropGenTab(ExDlgProperties * pdlp, ExItem * pitem)
{
    // Process the parameters
	m_rid = kridPropGenTab;
	m_pdlpParent = pdlp;
    m_pitem = pitem;

    // Retrieve the data from item which the user might choose to edit
    m_stuName = *(pitem->GetName());
    m_stuDescription = pitem->GetDescription();

    // Initialize other member variables to NULL
    m_hicon = NULL;
    m_hfontLargeName = NULL;
}

/*----------------------------------------------------------------------------------------------
	Destructor
----------------------------------------------------------------------------------------------*/
ExPropGenTab::~ExPropGenTab()
{
    if (m_hicon)
        DeleteObject(m_hicon);
    if (m_hfontLargeName)
	{
        DeleteObject(m_hfontLargeName);
		m_hfontLargeName = 0;
	}
}

/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
bool ExPropGenTab::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
    Assert(NULL == m_hicon);
    Assert(NULL == m_hfontLargeName);

    achar szText[kMax];

    // Load the icon for the dialog
    int iIcon = m_pitem->GetIcon();
    if (-1 != iIcon)
    {
        HIMAGELIST himl = ImageList_Create(35, 35, ILC_COLORDDB | ILC_MASK, 20, 5);
        HBITMAP hbmp = LoadBitmap(g_app.GetInstance(), MAKEINTRESOURCE(kridImagesLarge));
        ImageList_AddMasked(himl, hbmp, RGB(255,255,255));
        m_hicon = ImageList_ExtractIcon(g_app.GetInstance(), himl, iIcon);
        DeleteObject(hbmp);
        DeleteObject(himl);
        SendDlgItemMessage(Hwnd(), kridPropGenTabIcon, STM_SETIMAGE,
            (WPARAM) IMAGE_ICON, (LPARAM) m_hicon); 
    }

    // Set up the Large Name static box
    m_hfontLargeName = CreateFont(21,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,ANSI_CHARSET,
		OUT_CHARACTER_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		VARIABLE_PITCH|FF_ROMAN, _T("Times New Roman"));
    if (m_hfontLargeName)
    {
	    HWND hwndLargeName = GetDlgItem(Hwnd(), kctidPropGenTabNameLarge);
        Assert(NULL != hwndLargeName);
        SendMessage(hwndLargeName, WM_SETFONT, (WPARAM)m_hfontLargeName, (LPARAM)FALSE );
        SetLargeNameText();
    }

    // Set up the Name and Description edit boxes
    SetupEditCtrl(m_stuName, kctidPropGenTabName);
    SetupEditCtrl(m_stuDescription, kctidPropGenTabDescription);

    // Type
    m_pitem->GetType(szText, sizeof(szText));
    SetInfoText(szText, kctidPropGenTabType);

    // Location
    m_pitem->GetLocation(szText, sizeof(szText));
    SetInfoText(szText, kctidPropGenTabLocation);

    // Size
    m_pitem->GetSizePhrase(szText, sizeof(szText));
    SetInfoText(szText, kctidPropGenTabSize);

    // Dates
    SetTimeText(m_pitem->GetTimeCreated(), kctidPropGenTabCreated);
    SetTimeText(m_pitem->GetTimeModified(), kctidPropGenTabModified);

    return SuperClass::OnInitDlg(hwndCtrl, lp);
}

/*----------------------------------------------------------------------------------------------
	Convenience shortcut function which sets up our speckal TssEdit controls.
----------------------------------------------------------------------------------------------*/
void ExPropGenTab::SetupEditCtrl(StrUni & stuInitialText, uint rid)
{
	// REVIEW We probably need the writing system factory for the correct database. This is a hack
	// to get it to compile, and it works, at least to some degree.
	ILgWritingSystemFactoryPtr qwsf;
	qwsf.CreateInstance(CLSID_LgWritingSystemFactory);	// Get the registry-based factory.

	TssEditPtr qte;
	qte.Create();
	qte->SubclassEdit(Hwnd(), rid, qwsf);

	ITsStringPtr qtss;
    g_app.MakeUIString(stuInitialText.Bstr(), stuInitialText.Length(), qtss);

	HWND hwndEdit = GetDlgItem(Hwnd(), rid);
    Assert(NULL != hwndEdit);
	SendMessage(hwndEdit, FW_EM_SETTEXT, 0, (LPARAM)qtss.Ptr());
}


/*----------------------------------------------------------------------------------------------
	Convenience shortcut function which, given a string, places it into the dialog's control.
----------------------------------------------------------------------------------------------*/
void ExPropGenTab::SetInfoText(achar * pszText, uint ridCtrl)
{
    HWND hwndCtrl = GetDlgItem(Hwnd(), ridCtrl);
    Assert(NULL != hwndCtrl);
    SendMessage(hwndCtrl, WM_SETTEXT, 0, (LPARAM)pszText);
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
void ExPropGenTab::SetTimeText(const SilTime * ptime, uint ridCtrl)
{
    // Format a time string
    achar sz[kMax];
    if (NULL != ptime)
    {
        _stprintf(sz, _T("%d/%d/%d  %d:%02d %s"), ptime->Month(), ptime->Date(), ptime->Year(), 
            ptime->Hour() > 12 ? ptime->Hour()-12 : ptime->Hour(), 
            ptime->Minute(),
            ptime->Hour() > 12 ? _T("pm") : _T("am"));
    }
    else
    {
        _tcscpy(sz, _T("N/A"));
    }

    // Place the time into the target control
    SetInfoText(sz, ridCtrl);
}


/*----------------------------------------------------------------------------------------------
	...
----------------------------------------------------------------------------------------------*/
void ExPropGenTab::SetLargeNameText()
{
	HWND hwndLargeName = GetDlgItem(Hwnd(), kctidPropGenTabNameLarge);
	Assert(NULL != hwndLargeName);
#ifdef UNICODE
    ::SendMessage(hwndLargeName, WM_SETTEXT, 0, (LPARAM)m_stuName.Chars());
#else
    char sz[kMax];
    wcstombs(sz, m_stuName.Chars(), kMax);
    ::SendMessage(hwndLargeName, WM_SETTEXT, 0, (LPARAM)sz);
#endif
}

/*----------------------------------------------------------------------------------------------
	Handles notifications from the controls within the tab.
----------------------------------------------------------------------------------------------*/
bool ExPropGenTab::OnNotifyChild(int ctid, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);
	switch(pnmh->code)
	{
    case EN_KILLFOCUS:
        if (kctidPropGenTabName == pnmh->idFrom)
        {
            UpdateClassDataFromControls();
            SetLargeNameText();
        }
        break;
    }
	return SuperClass::OnNotifyChild(ctid, pnmh, lnRet);
}


/*----------------------------------------------------------------------------------------------
	Retrieves the data from the editable controlsl and places them into the dialog's
    member variables.
----------------------------------------------------------------------------------------------*/
void ExPropGenTab::UpdateClassDataFromControls()
{
	achar rgch[kMax * 4];

	// TODO JohnW(DarrellZ): This needs to be changed to use FW_EM_GETTEXT instead of
	// WM_GETTEXT.
	HWND hwndEdit = GetDlgItem(Hwnd(), kctidPropGenTabName);
	Assert(NULL != hwndEdit);
	::SendMessage(hwndEdit, WM_GETTEXT, (WPARAM)kMax, (LPARAM)rgch);
#ifdef UNICODE
	m_stuName = rgch;
#else
	wchar rgchw[kMax * 4];
	mbstowcs(rgchw, rgch, kMax);
	m_stuName = rgchw;
#endif

	// TODO JohnW(DarrellZ): This needs to be changed to use FW_EM_GETTEXT instead of
	// WM_GETTEXT.
    HWND hwndDescription = GetDlgItem(Hwnd(), kctidPropGenTabDescription);
    Assert(NULL != hwndDescription);
    ::SendMessage(hwndDescription, WM_GETTEXT, (WPARAM)kMax, (LPARAM)rgch);
#ifdef UNICODE
    m_stuDescription = rgch;
#else
    mbstowcs(rgchw, rgch, kMax);
    m_stuDescription = rgchw;
#endif
}


/*----------------------------------------------------------------------------------------------
	Save edited fields.
----------------------------------------------------------------------------------------------*/
void ExPropGenTab::Save()
{
    Assert(NULL != m_pitem);
    UpdateClassDataFromControls();
    m_pitem->SetName(m_stuName);
    m_pitem->SetDescription(m_stuDescription);
}


/***********************************************************************************************
    ExDlgProperties Methods
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Constructor
----------------------------------------------------------------------------------------------*/
ExDlgProperties::ExDlgProperties()
: AfTabbedDialog(kridDlgProperties)
{
    m_bIsInitialized = false;
    m_pdlpg = NULL;
}

/*----------------------------------------------------------------------------------------------
	Initialization prior to invokving DoModal
----------------------------------------------------------------------------------------------*/
void ExDlgProperties::Init(ExItem * pitem)
{
    Assert(NULL != pitem);
    m_pitem = pitem;
    m_bIsInitialized = true;
}


/*----------------------------------------------------------------------------------------------
	Initialize the dialog. Called from DoModal.
----------------------------------------------------------------------------------------------*/
bool ExDlgProperties::OnInitDlg(HWND hwndParent, LPARAM lp)
{
    Assert(m_bIsInitialized);    // ExDlgProperties::Init must have been called before DoModal()
    Assert(NULL != m_pitem);

    // Insert the General Page
    m_pdlpg = NewObj ExPropGenTab(this, m_pitem);
    AddTab(m_pdlpg, kstidPropGenTabTitle);

    // Size everything to fit.
    Resize();

    // Show the first tab
	ShowChildDlg(0);

    // Superclass initializations
    CenterInWindow(hwndParent);
	return SuperClass::OnInitDlg(hwndParent, lp);
}


/*----------------------------------------------------------------------------------------------
	Process notifications from user.
----------------------------------------------------------------------------------------------*/
bool ExDlgProperties::OnApply(bool fClose)
{
    m_pdlpg->Save();
	return AfDialog::OnApply(fClose);
}
