// DummyIAdvInd4.cs
// User: Jean-Marc Giffin at 12:32 P 23/07/2008

namespace SIL.FieldWorks.FwCoreDlgs
{
	public interface IAdvInd4
	{
		string Message {get; set;}
		int Position {get; set;}
		int StepSize {get; set;}
		string Title {get; set;}
	}
}