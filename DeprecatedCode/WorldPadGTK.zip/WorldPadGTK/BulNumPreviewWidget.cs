// BulNumPreviewWidget.cs
// User: Jean-Marc Giffin at 4:33 P 04/06/2008

using System;
using Pango;

namespace SIL.FieldWorks.GtkCustomWidget
{	
	public class BulNumPreviewWidget : Gtk.DrawingArea
	{
		public BulNumPreviewWidget()
		{
		}
	}
}
