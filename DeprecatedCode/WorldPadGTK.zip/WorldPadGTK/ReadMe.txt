#
#    ReadMe.txt
#
#    ReadMe for GTK version of WorldPad
#
#    Andrew Weaver - 2008-05-01
#
#    $Id$
#

Instructions for building and running WorldPad
==============================================

1. Build the application (WorldPad.exe) by running the shell script, make.sh.

2. Run the program from within terminal by executing the following command:

	mono WorldPad.exe

Andrew Weaver, Apr 29 2008
