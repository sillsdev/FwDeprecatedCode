#!/bin/sh
gmcs -out:Rc2glade.exe -r:System.Drawing GladeInterface.cs Rc2glade.cs

