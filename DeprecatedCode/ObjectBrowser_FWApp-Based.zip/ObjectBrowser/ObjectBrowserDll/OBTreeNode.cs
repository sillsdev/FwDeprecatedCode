// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: OBNode.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
//		these are various sub classes of TreeNode which met such different kinds of FieldWorks properties
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Framework.TreeForms;
using System.Collections;
using System.Diagnostics;

namespace SIL.FieldWorks.ObjectBrowser
{
	/// <summary>
	/// Summary description for OBNode.
	/// </summary>
	public abstract class OBTreeNode : TreeNode
	{
		protected FdoCache m_cache;
		
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="OBTreeNode"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public OBTreeNode(FdoCache cache)
		{
			m_cache = cache;
		}

		//steps that can't be done until all of the construction is complete
		//should be called only by base classes
		protected void FinishInit()
		{
			this.Text = this.ToString();
			if(GetHaveChildren())
				//this is a hack to make the node expandable before we have filled in any actual children
				this.Nodes.Add(new TreeNode("should not see this"));

		}

		abstract protected  bool GetHaveChildren();

		abstract public void AddChildren ();
	}

	public class ObjectTreeNode:OBTreeNode
	{
		protected CmObject m_object;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ObjectTreeNode"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public ObjectTreeNode(FdoCache cache, CmObject dbobject, bool isReference):base(cache)
		{
			m_object = dbobject;
			FinishInit();
			if(isReference)
			{
				this.ImageIndex =7;
				this.SelectedImageIndex =7;
			}
			else
			{
				this.ImageIndex =6;
				this.SelectedImageIndex =6;
			}

		}

		/// <summary>
		/// the database ID of the obj and that this TreeNode represents
		/// </summary>
		public int Hvo
		{
			get
			{
				return m_object.Hvo;
			}
		}

		/// <summary>
		/// the CmObject of this node
		/// </summary>
		public CmObject DBObject
		{
			get{return m_object;}
		}

		protected override bool GetHaveChildren()
		{
			return true; //not really always true, I am lazy
		}

		public override string ToString()
		{
			return m_object.ShortName;
		}

		public override void AddChildren()
		{
			// ENHANCE: could add the children only if it is apparent that we haven't done it before
			Nodes.Clear();

			foreach(ClassAndPropInfo cpi in m_cache.GetFieldsOfClass((uint)m_object.ClassID))
			{
				if(!cpi.isBasic)
				{
					if(cpi.isVector)
						this.Nodes.Add(new VectorFieldNode(m_cache, m_object, cpi));
					//could show the first one, but need something to keep from showing this once for each sub class
					else if(cpi.fieldName != "Owner$")
						Nodes.Add(new AtomicFieldNode(m_cache, m_object, cpi));
				}
			} 
		}
	}

	public abstract class FieldNode : OBTreeNode
	{
		protected CmObject m_parent;
		protected ClassAndPropInfo m_cpi;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="AtomicFieldNode"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public FieldNode(FdoCache cache, CmObject parent, ClassAndPropInfo cpi):base(cache)
		{
			Debug.Assert(parent != null);
			m_parent = parent;
			m_cpi = cpi;
		}	

		public override string ToString()
		{
			return m_cpi.fieldName;
		}

		/// <summary>
		/// the field ID that this TreeNode represents
		/// </summary>
		public uint Flid
		{
			get
			{
				return m_cpi.flid;
			}
		}
	}

	public class VectorFieldNode : FieldNode
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="AtomicFieldNode"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public VectorFieldNode(FdoCache cache, CmObject parent, ClassAndPropInfo cpi):base(cache, parent, cpi)
		{
			FinishInit();
			if(cpi.isReference)
			{
				this.ImageIndex =2;
				this.SelectedImageIndex =2;
			}
			else
			{
				this.ImageIndex =0;
				this.SelectedImageIndex =0;
			}
		}
		
		protected override bool GetHaveChildren()
		{
			return m_cache.GetVectorSize(m_parent.Hvo,(int) m_cpi.flid)>0;
		}
		
		public override void AddChildren ()
		{
			// ENHANCE: could add the children only if it is apparent that we haven't done it before
			this.Nodes.Clear();

			foreach(CmObject obj in this.DBObjects)
			{
				this.Nodes.Add(new ObjectTreeNode(m_cache, obj, m_cache.IsReferenceProperty((int)m_cpi.flid)));
			}
		}
		
		/// <summary>
		/// the owned or referred to CmObject, if any
		/// </summary>
		public ArrayList DBObjects//may be null
		{
			get
			{
				return m_parent.GetObjectsInVectorField((int)m_cpi.flid, 100); 
			}
		}
	}

	public class AtomicFieldNode : FieldNode
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="AtomicFieldNode"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public AtomicFieldNode(FdoCache cache, CmObject parent, ClassAndPropInfo cpi):base(cache, parent, cpi)
		{
			FinishInit();
			if(cpi.isReference)
			{
				this.ImageIndex =5;
				this.SelectedImageIndex =5;
			}
			else
			{
				this.ImageIndex =4;
				this.SelectedImageIndex =4;
			}
		}
		
		protected override bool GetHaveChildren()
		{
			return m_cache.GetObjProperty(m_parent.Hvo, (int)m_cpi.flid) !=0;
		}

		public override void AddChildren ()
		{
			// ENHANCE: could add the children only if it is apparent that we haven't done it before
			this.Nodes.Clear();

			CmObject obj = this.DBObject;
			if (obj != null)
			{
				this.Nodes.  Add (new ObjectTreeNode(m_cache, obj, m_cache.IsReferenceProperty((int)m_cpi.flid)));
			}
		}
		
		/// <summary>
		/// the owned or referred to CmObject, if any
		/// </summary>
		public CmObject DBObject
		{
			get
			{
				return m_parent.GetObjectInAtomicField((int)m_cpi.flid); //may be null
			}
		}
	}

	public class LPTreeNode : ObjectTreeNode
	{

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="ObjectTreeNode"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public LPTreeNode(FdoCache cache):base(cache,cache.LanguageProject, false)
		{
			FinishInit();
		}

		public override string ToString()
		{
			return m_cache.LanguageProject.Name.AnalysisDefaultWritingSystem;
		}

	}

 }
