// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: DatabaseTreeController.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Xml;
using System.Runtime.InteropServices; // needed for Marshal

using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.Common.Framework.TreeForms;

namespace SIL.FieldWorks.ObjectBrowser
{
	/// <summary>
	/// Summary description for DatabaseTreeController.
	/// </summary>
	public class DatabaseTreeController
	{
		protected FdoCache m_cache;
		protected TreeView m_treeview;
		protected DataTree m_dataTree;
		protected int m_currentHvo;
		//protected XdeTemplateCollector templateCollector;
		protected StatusBar m_statusBar;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="DatabaseTreeController"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public DatabaseTreeController(FdoCache cache, TreeView treeview, DataTree dataTree, StatusBar statusBar)
		{
			m_statusBar = statusBar;
			m_currentHvo = 0;
			Debug.Assert(treeview != null);
			m_cache = cache;
			m_dataTree = dataTree;
			m_treeview = treeview;
			m_treeview.BeforeExpand += new TreeViewCancelEventHandler(OnBeforeExpand);
			m_treeview.AfterSelect += new TreeViewEventHandler(OnAfterSelect);
			m_treeview.Click += new System.EventHandler(OnClick);
			//templateCollector = new XdeTemplateCollector(null);
		}

		public void LoadSettings(Microsoft.Win32.RegistryKey settingsKey)
		{
			try
			{
				Object o = settingsKey.GetValue("SelectedHvo");	//may be null
				if(o != null)
				{
					m_currentHvo = (int)o;
					ShowAndSelectObject(m_currentHvo);
				}
				else
					m_currentHvo = 0;
			}
			catch(Exception){} // ignore errors
		}
		
		// the tricky part here is that the tree is not fully populated with all of the possible nodes.
		// therefore, it is not as simple as just finding the node which corresponds to this object,
		// because if that node is not already visible, it probably does not exist.
		public void ShowAndSelectObject(int hvo)
		{
			// See if it is the DB at all.
			IOleDbCommand odc = null;
			m_cache.DatabaseAccessor.CreateCommand(out odc);
			try
			{
				string sqlQuery = "select Id from CmObject (readuncommitted) where Id='" + hvo.ToString() + "'";
				//uint cbSpaceTaken;
				bool fMoreRows;
				//bool fIsNull;
				//uint uintSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(uint));
				odc.ExecCommand(sqlQuery, (int)FwKernelLib.SqlStmtType.knSqlStmtSelectWithOneRowset);
				odc.GetRowset(0);
				odc.NextRow(out fMoreRows);
				if (!fMoreRows)
					hvo = 0;
			}
			finally
			{
				DbOps.ShutdownODC(ref odc);
			}

			if(hvo < 1)
				hvo = m_cache.LanguageProject.Hvo;

			// find this object in the tree, in the place where it is owned (not just referenced)
			// TODO: handle objects which are not ultimately owned by the language project

			System.Collections.Stack objects = new System.Collections.Stack();
			System.Collections.Stack fields = new System.Collections.Stack();
			int current = hvo;
			uint flid = 0;

			do
			{
				objects.Push(current);

				//which field is this object owned in?
				flid = (uint)m_cache.GetOwningFlidOfObject(current);
				fields.Push(flid);
				
				//who owns this object?
				current = m_cache.GetOwnerOfObject(current);
			}
			while(flid > 0); //stop when we get to an unowned object. 
			// this should leave us with a root level object (e.g. language project) 
			// at the top of the the objects stack, and a 0 at the top of the fields stack.

			
			// now walk the TreeView, expanding appropriate nodes until we get to where this object is
			Debug.Assert(0==(uint)fields.Peek());
			ObjectTreeNode objNode=null;

			while(objects.Count>0)
			{
				int objectHvo =(int)objects.Pop();
				flid = (uint)fields.Pop();
				if(flid == 0)
				{
					objNode = FindRootObjectNode(objectHvo);
				}
				else
				{
					FieldNode fieldNode = FindFieldNode(objNode, flid);
					if(fieldNode== null)
						throw(new ApplicationException("ShowAndSelectObject could not find the field."));
					fieldNode.Expand();
					objNode = FindObjectNode(fieldNode, objectHvo);		
					if(objNode== null)
						throw(new ApplicationException("ShowAndSelectObject could not find the object."));
				}

				if(objects.Count>0)	//no reason to expand the last one, we just want to select it
					objNode.Expand();
			}

			//			Debug.Assert(0==(int)fields.Pop());
			//			int objectHvo =(int)objects.Pop();
			//			ObjectTreeNode objNode = FindRootObjectNode(objectHvo);
			//			objNode.Expand();
			//
			//			while(objects.Count>0)
			//			{
			//				FieldNode fieldNode = FindFieldNode(objNode, (int)fields.Pop());
			//				fieldNode.Expand();
			//				objNode = FindObjectNode(fieldNode, (int)owners.Pop());		
			//				if(fieldNode== null)
			//					throw(new ApplicationException("ShowAndSelectObject could not find the object."));
			//				objNode.Expand();
			//				if (objects.  Count > 0)
			//					objectHvo =(int)objects.Pop();
			//			}

			objNode.EnsureVisible();
			m_treeview.SelectedNode=objNode;
		}

		/// <summary>
		/// finds the TreeNode which represents the given object (e.g. language project)
		/// </summary>
		private ObjectTreeNode FindRootObjectNode(int searchHvo)
		{
			Debug.Assert( searchHvo== m_cache.LanguageProject.Hvo, "root objects other than language projects are not yet supported by this method.");
			return (ObjectTreeNode)m_treeview.Nodes[0];
		}

		private ObjectTreeNode FindObjectNode(FieldNode searchNode, int searchHvo)
		{
			foreach(ObjectTreeNode node in searchNode.Nodes)
			{
				if(node.Hvo == searchHvo)
					return node;
			}
			// not really an error.  This object could have been deleted. Debug.Assert(false,"could not find a node matching the hvo");
			return null;
		}

		private FieldNode FindFieldNode(OBTreeNode searchNode, uint searchFlid)
		{
			foreach(FieldNode node in searchNode.Nodes)
			{
				if(node.Flid == searchFlid)
					return node;
			}
			Debug.Assert(false,"could not find a node matching the field");
			return null;
		}

		public void SaveSettings(Microsoft.Win32.RegistryKey settingsKey)
		{
			settingsKey.SetValue("SelectedHvo", m_currentHvo);
			// Save Database Settings
			settingsKey.SetValue("LatestDatabaseName", m_cache.DatabaseName);
			settingsKey.SetValue("LatestDatabaseServer", m_cache.ServerName);
			settingsKey.SetValue("LatestProjectName", 
				m_cache.LanguageProject.Name.AnalysisDefaultWritingSystem);
		}

		public void OnBeforeExpand(object sender,TreeViewCancelEventArgs e	)
		{
			OBTreeNode node = (OBTreeNode)	e.Node;
			Cursor.Current = Cursors.WaitCursor;
			node.AddChildren();
			Cursor.Current = Cursors.Default;
		}


		public void OnClick(object sender,System.EventArgs e	)
		{
			//OBTreeNode node = (OBTreeNode)	e.Node;
		}

		public void OnAfterSelect(object sender,TreeViewEventArgs e	)
		{
			OBTreeNode node = (OBTreeNode)	e.Node;
			//why doesn't this work? if(node.GetType().IsInstanceOfType(typeof(ObjectTreeNode)))
			if(node.GetType() == typeof(ObjectTreeNode) || node.GetType() == typeof(LPTreeNode))
			{
				CmObject obj = ((ObjectTreeNode) node).DBObject;
				string name;
				m_cache.MetaDataCacheAccessor.GetClassName((uint)obj.ClassID, out name);
		

				try
				{	
					//templateCollector.Reload();//enhance: this is just here to allow changing the templates without the starting the application.
					Cursor.Current = Cursors.WaitCursor;
					m_dataTree.ShowObject(obj.Hvo, templateCollector.Templates);
					Cursor.Current = Cursors.Default;
					m_currentHvo = obj.Hvo;
				}
				catch(Exception error)
				{
					System.Windows.Forms.MessageBox.Show("There was an error while trying to build the tree form for the subject. " +error.  Message);
					//					System.Windows.Forms.MessageBox.Show("There was an error while trying to build the tree form for the subject.  Using xde at "+path+". " +error.  Message);
					return;
				}

				m_statusBar.Text = "HVO = " + obj.Hvo.ToString();
			}
		}

		/// <summary>
		/// used when the userchooses a different language project
		/// </summary>
		/// <param name="cache"></param>
		public void ResetLanguageProject(FdoCache cache,  DataTree dataTree)
		{
			m_cache = cache;
			m_dataTree = dataTree;
			FillTree();
		}
		public void FillTree()
		{
			m_treeview.Nodes.Clear();
			m_treeview.Nodes.Add(new LPTreeNode(m_cache));
		}


		//I (JH) gave up on this for now because I cannot figure out how to know which noted you right-clicked on.
		//it is *not* the selected note, which is the last note that you left clicked on.
		public void OnContextMenu_Popup(Menu contextMenu)
		{
			OBTreeNode node = (OBTreeNode)m_treeview.SelectedNode;
			if(node == null)
				return;
			//cannot delete nodes that are just therefore navigation
			contextMenu.MenuItems[0].Text = "Use Edit Menu To Delete " + node.Text;;
			contextMenu.MenuItems[0].Enabled = false;//!(node is FieldNode);
		}

		//I (JH) gave up on this for now because I cannot figure out how to know which noted you right-clicked on.
		//it is *not* the selected note, which is the last note that you left clicked on.
		public void OnDeleteObjectMenu()
		{
			ObjectTreeNode node = (ObjectTreeNode)m_treeview.SelectedNode;
			if(node == null)
				return;
			Cursor.Current = Cursors.WaitCursor;
			m_treeview.Nodes.Remove(node);
			m_cache.DeleteObject(node.Hvo);
			Cursor.Current = Cursors.Default;

		}
		
		public void UpdateDeleteMenu(MenuItem mnuDelete)
		{
			OBTreeNode node = (OBTreeNode)m_treeview.SelectedNode;
			if(node == null)
			{
				mnuDelete.Enabled = false;
				mnuDelete.Text = "Cannot Delete " + node.Text;;
				return;
			}
			mnuDelete.Enabled = !(node is FieldNode);
			mnuDelete.Text = "Delete " + node.Text;
		}
	}
}
