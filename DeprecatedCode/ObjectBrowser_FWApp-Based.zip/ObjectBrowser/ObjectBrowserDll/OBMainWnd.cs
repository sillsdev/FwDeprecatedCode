// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: OBMainWnd.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Xml;

using System.Configuration;
using System.Diagnostics;
using Microsoft.Win32;

using SIL.FieldWorks;
using SIL.FieldWorks.Common.Controls;
using SIL.FieldWorks.Common.Framework;
using SIL.FieldWorks.Common.RootSites;
using SIL.FieldWorks.FDO;
using SIL.FieldWorks.FDO.Ling;
using SIL.FieldWorks.FDO.Ling.Generated;
using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.ObjectBrowser
{
	/// <summary>
	/// Summary description for OBMainWnd.
	/// </summary>
	public class OBMainWnd : System.Windows.Forms.Form, IFwMainWnd
	{
		protected FdoCache m_cache;
		protected DatabaseTreeController m_databaseTreeController;
		private System.Windows.Forms.TreeView m_databaseTree;
		private System.Windows.Forms.ImageList m_imageList;
		private SIL.FieldWorks.Common.Framework.TreeForms.DataTree m_dataEntryForm;
		private System.Windows.Forms.Timer m_timerStartup;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem mnuUndo;
		private System.Windows.Forms.MenuItem mnuRedo;
		private System.Windows.Forms.MenuItem mnuEdit;
		private System.Windows.Forms.StatusBar m_statusBar;
		private System.Windows.Forms.ContextMenu m_contextMenu;
		private System.Windows.Forms.MenuItem mnuDeleteObject;
		private System.Windows.Forms.MenuItem mnuDelete;
		private System.ComponentModel.IContainer components;

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="OBMainWnd"/> class.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public OBMainWnd(FdoCache cache, Form wndCopyFrom): base()
		{
			Cache = cache;
			m_databaseTreeController = null; // can't be created until the Windows forms elements are created

			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

	
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged 
		/// resources; <c>false</c> to release only unmanaged resources. 
		/// </param>
		/// -----------------------------------------------------------------------------------
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				m_databaseTreeController.SaveSettings(SettingsKey);	//review: there must be a better place for this
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(OBMainWnd));
			this.m_databaseTree = new System.Windows.Forms.TreeView();
			this.m_contextMenu = new System.Windows.Forms.ContextMenu();
			this.mnuDeleteObject = new System.Windows.Forms.MenuItem();
			this.m_imageList = new System.Windows.Forms.ImageList(this.components);
			this.m_timerStartup = new System.Windows.Forms.Timer(this.components);
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.mnuEdit = new System.Windows.Forms.MenuItem();
			this.mnuUndo = new System.Windows.Forms.MenuItem();
			this.mnuRedo = new System.Windows.Forms.MenuItem();
			this.mnuDelete = new System.Windows.Forms.MenuItem();
			this.m_statusBar = new System.Windows.Forms.StatusBar();
			this.SuspendLayout();
			// 
			// m_databaseTree
			// 
			this.m_databaseTree.ContextMenu = this.m_contextMenu;
			this.m_databaseTree.Dock = System.Windows.Forms.DockStyle.Left;
			this.m_databaseTree.Font = new System.Drawing.Font("Arial Unicode MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.m_databaseTree.ImageList = this.m_imageList;
			this.m_databaseTree.Name = "m_databaseTree";
			this.m_databaseTree.Size = new System.Drawing.Size(240, 582);
			this.m_databaseTree.Sorted = true;
			this.m_databaseTree.TabIndex = 1;
			// 
			// m_contextMenu
			// 
			this.m_contextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						  this.mnuDeleteObject});
			this.m_contextMenu.Popup += new System.EventHandler(this.OnContextMenu_Popup);
			// 
			// mnuDeleteObject
			// 
			this.mnuDeleteObject.Index = 0;
			this.mnuDeleteObject.Text = "Delete Object";
			this.mnuDeleteObject.Click += new System.EventHandler(this.contextMnuDeleteObject_Click);
			// 
			// m_imageList
			// 
			this.m_imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.m_imageList.ImageSize = new System.Drawing.Size(16, 16);
			this.m_imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("m_imageList.ImageStream")));
			this.m_imageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// m_timerStartup
			// 
			this.m_timerStartup.Tick += new System.EventHandler(this.m_timerStartup_Tick);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.mnuEdit});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem5,
																					  this.menuItem4});
			this.menuItem1.Text = "&File";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "&Choose Database...";
			this.menuItem2.Click += new System.EventHandler(this.mnuFile_ChooseLangProj);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
			this.menuItem3.Text = "&Save";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 2;
			this.menuItem5.Text = "-";
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 3;
			this.menuItem4.Text = "E&xit";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// mnuEdit
			// 
			this.mnuEdit.Index = 1;
			this.mnuEdit.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuUndo,
																					this.mnuRedo,
																					this.mnuDelete});
			this.mnuEdit.Text = "&Edit";
			this.mnuEdit.Popup += new System.EventHandler(this.mnuEdit_Popup);
			// 
			// mnuUndo
			// 
			this.mnuUndo.Index = 0;
			this.mnuUndo.Shortcut = System.Windows.Forms.Shortcut.CtrlZ;
			this.mnuUndo.Text = "&Undo";
			this.mnuUndo.Click += new System.EventHandler(this.mnuUndo_Click);
			// 
			// mnuRedo
			// 
			this.mnuRedo.Index = 1;
			this.mnuRedo.Shortcut = System.Windows.Forms.Shortcut.CtrlY;
			this.mnuRedo.Text = "&Redo";
			this.mnuRedo.Click += new System.EventHandler(this.mnuRedo_Click);
			// 
			// mnuDelete
			// 
			this.mnuDelete.Index = 2;
			this.mnuDelete.Text = "&Delete yyyy";
			this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
			// 
			// m_statusBar
			// 
			this.m_statusBar.Location = new System.Drawing.Point(240, 560);
			this.m_statusBar.Name = "m_statusBar";
			this.m_statusBar.Size = new System.Drawing.Size(488, 22);
			this.m_statusBar.TabIndex = 2;
			this.m_statusBar.Text = "Hello";
			// 
			// OBMainWnd
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(728, 582);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.m_statusBar,
																		  this.m_databaseTree});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "OBMainWnd";
			this.Text = "FW Object Browser";
			this.ResumeLayout(false);

		}
		#endregion

		private void JoinWithSplitter(Control left, Control right)
		{
			Debug.Assert(left.Parent == right.Parent);
			Control p = left.Parent;
			p.SuspendLayout();
			p.Controls.Remove(left);
			p.Controls.Remove(right);
			
			//in case we are being called for a second time on the same panel,
			//get rid of the splinter we made last time
			foreach(Control c in p.Controls)
				if(c is Splitter)
					p.Controls.Remove(c);

			Splitter s = new System.Windows.Forms.Splitter();
			s.Dock = System.Windows.Forms.DockStyle.Left;
			s.Visible = true;
			left.Dock = System.Windows.Forms.DockStyle.Left;
			right.Dock = System.Windows.Forms.DockStyle.Fill;
			p.Controls.AddRange(new System.Windows.Forms.Control[]{right, s, left});
			p.ResumeLayout(true);
		}

		#region IFwMainWnd implementation
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Gets the currently active view (client window).
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public virtual IRootSite ActiveView
		{
			get
			{
				// TODO WW team: implement this if needed (see FwMainWnd.ActiveView for example)
				return null;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called when a window is finished being created and completely initialized.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public void OnFinishedInit()
		{
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// 
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public string ApplicationName
		{
			get {return string.Empty;}
		}
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// The window rectangle (DesktopBounds) that is persisted in the registry.
		/// Use this property when trying to set the DesktopBounds for a new window.
		/// (Simply setting DesktopBounds will not give the desired result in the Show method.)
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public Rectangle PersistentDesktopBounds
		{
			set
			{
				DesktopBounds = value;
				//	m_persistence.SaveWindowPosition(SettingsKey);
			}
		}
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Enable or disable this window.
		/// </summary>
		/// 
		/// <param name="fEnable">Enable (true) or disable (false).</param>
		/// -----------------------------------------------------------------------------------
		public void EnableWindow(bool fEnable)
		{
			// TODO TomB: Implement this.
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Save all data in this window, ending the current transaction.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public void SaveData()
		{
			// REVIEW TeTeam:
			// If this class someday implements record-based stuff, we may need to updated the
			// DateModified in the records. Ref RecMainWnd::SaveData().
			this.Cache.Save();
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Returns the NormalStateDesktopBounds property from the persistence object.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public Rectangle NormalStateDesktopBounds
		{
			get
			{
				return new Rectangle(Location, Size);
			}
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Gets or sets the data objects cache.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public virtual FdoCache Cache
		{
			get
			{
				return m_cache;
			}
			set
			{
				if (m_cache != null)
				{
					// TODO TomB: Probably all kinds of stuff needs to be done if the connection is
					// being changed.
					Debug.Assert(false);
				}
				m_cache = value;
			}
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Create the client windows and add correspnding stuff to the sidebar, View menu,
		/// etc.
		/// </summary>
		/// From FwMainWnd
		/// -----------------------------------------------------------------------------------
		public  void InitAndShowClient()
		{
			this.Text = "OB: " + m_cache.LanguageProject.Name.AnalysisDefaultWritingSystem;

			if(m_dataEntryForm != null)
				this.Controls.Remove(m_dataEntryForm);
			m_dataEntryForm = new SIL.FieldWorks.Common.Framework.TreeForms.DataTree();
			this.Controls.Add(m_dataEntryForm);
			JoinWithSplitter(m_databaseTree, m_dataEntryForm);
			m_dataEntryForm.Initialize(m_cache, true);
			if (m_databaseTreeController == null)
				m_databaseTreeController = new DatabaseTreeController(m_cache,
					m_databaseTree, m_dataEntryForm, m_statusBar);
			else
				m_databaseTreeController.ResetLanguageProject(m_cache, m_dataEntryForm); 

			m_databaseTreeController.FillTree();
			m_databaseTreeController.LoadSettings(SettingsKey);
			m_timerStartup.Enabled = true;
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called just before a window syncronizes it's views with DB changes (e.g. when an
		/// undo or redo command is issued).
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public virtual bool PreSynchronize(SyncInfo sync)
		{
			// TODO: Implement it. This is copied from TE.
			return true;
		}
		
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Called when a window syncronizes it's views with DB changes (e.g. when an undo or
		/// redo command is issued).
		/// </summary>
		/// <param name="sync">syncronization information record</param>
		/// ------------------------------------------------------------------------------------
		public virtual bool Synchronize(SyncInfo sync)
		{
			// TODO: Implement it. This is copied from TE.
			//Updating views in all windows.
			//FwApp.App.RefreshAllViews();
			return true;
		}

		#endregion // IFwMainWnd implementation

		private void m_panelListAndRight_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Registry key for settings for this window.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		virtual public RegistryKey SettingsKey
		{
			get
			{
				Debug.Assert(FwApp.App != null);
				return FwApp.App.SettingsKey;
			}
		}


		#region boot strap hack stuff

//		protected void InitDataEntryForm()
//		{
//			string xdeFile = System.Environment.ExpandEnvironmentVariables(@"%fwroot%\samples\samples.net\desample\PhonemeSetXde.xml");
//
//			XmlDocument xdoc = new XmlDocument();
//			xdoc.Load(xdeFile);
//			int hvo = SetupSampleObject();
////			m_dataEntryForm.Initialize(m_cache, hvo, xdoc["xde"], true);
//
//		}
//	
//		private int SetupSampleObject()
//		{
//			int hvo = 0;
//
//			hvo = GetFirstPhonemeSet(m_cache);
//			PhPhonemeSet ps = new PhPhonemeSet(m_cache, hvo);
//			PhPhoneme ph = new PhPhoneme(m_cache, ps.PhonemesOC.hvoArray[0]);
//			TsStringAccessor st = ph.Description.AnalysisDefaultWritingSystem;
//			string st1 = ph.Name.VernacularDefaultWritingSystem;
//			ph = new PhPhoneme(m_cache, ps.PhonemesOC.hvoArray[1]);
//
//			//load the cache w/ the strings
//			st = ph.Description.AnalysisDefaultWritingSystem;
//			st1 = ph.Name.VernacularDefaultWritingSystem;
//
//			return hvo;
//		}
//		int GetFirstPhonemeSet(FDO.FdoCache cache)
//		{
//			if (cache.LanguageProject.PhonologicalDataOA == null)
//			{
//				cache.LanguageProject.PhonologicalDataOA = new PhPhonologicalData();
//			}
//			FdoOwningSequence fos = cache.LanguageProject.PhonologicalDataOA.PhonemeSetsOS;
//			if (fos.Count > 0)
//				return fos[0].hvo;
//			else
//				return fos.Append(new PhPhonemeSet()).hvo;
//		}
		#endregion

		private void m_timerStartup_Tick(object sender, System.EventArgs e)
		{
			m_timerStartup.Enabled=false;
			m_databaseTree.Nodes[0].Expand();
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			m_cache.Save();
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void mnuEdit_Popup(object sender, System.EventArgs e)
		{
			mnuUndo.Text = m_cache.UndoText;
			mnuUndo.Enabled = m_cache.CanUndo;
			mnuRedo.Text = m_cache.RedoText;
			mnuRedo.Enabled = m_cache.CanRedo;
			m_databaseTreeController.UpdateDeleteMenu(mnuDelete);
		}

		private void mnuUndo_Click(object sender, System.EventArgs e)
		{
			m_cache.Undo();
			m_dataEntryForm.RefreshList();
		}

		private void mnuRedo_Click(object sender, System.EventArgs e)
		{
			m_cache.Redo();
			m_dataEntryForm.RefreshList();
		}

		private void mnuFile_ChooseLangProj(object sender, System.EventArgs e)
		{
			string sWsUser = "en";
			// Results parms for the dlg.
			bool fHaveProject;
			int hvoProj;
			string sProject;
			Guid guid;
			bool fHaveSubitem;
			int hvoSubitem;
			string sName;
			string sServer = (m_cache != null) ? m_cache.ServerName : MiscUtils.LocalServerName;
			string sDatabase;

			FwViews.OpenFWProjectDlgClass dlg = new FwViews.OpenFWProjectDlgClass();
			dlg.Show(null, null, sServer, sWsUser, (uint)this.Handle, true, 0, "xxxxx.htm");
			dlg.GetResults(out fHaveProject, out hvoProj, out sProject,
				out sDatabase, out sServer, out guid, out fHaveSubitem, out hvoSubitem, out sName);
			System.Runtime.InteropServices.Marshal.ReleaseComObject(dlg);
			// Only change it, if we have one and it is different from what we already have.
			if (fHaveProject && (sServer != m_cache.ServerName || sDatabase != m_cache.DatabaseName))
			{
				FdoCache newCache = FdoCache.Create(sServer, sDatabase, sProject, null);
//				m_databaseTreeController.ResetCache (newCache);
				if (m_cache != null)
					m_cache.Dispose();
				m_cache = newCache;
				InitAndShowClient();
			}
		}

		private void contextMnuDeleteObject_Click(object sender, System.EventArgs e)
		{
			m_databaseTreeController.OnDeleteObjectMenu();
		}

		private void OnContextMenu_Popup(object sender, System.EventArgs e)
		{
			m_databaseTreeController.OnContextMenu_Popup(m_contextMenu);		
		}

		private void mnuDelete_Click(object sender, System.EventArgs e)
		{
			m_databaseTreeController.OnDeleteObjectMenu();	
		}
	}
}
