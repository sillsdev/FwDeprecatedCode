// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2002' to='2002' company='SIL International'>
//		Copyright (c) 2002, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: OBApp.cs
// Responsibility: John Hatton
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Windows.Forms;
using SIL.FieldWorks.Common.Framework;
using Microsoft.Win32;
using SIL.FieldWorks.FDO;

namespace SIL.FieldWorks.ObjectBrowser
{
	/// <summary>
	/// This is a tool for inspecting and editing any object in a language project.
	/// </summary>
	public class OBApp : FwApp
	{
		#region OBApp Properties
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Guid for the application (used for uniquely identifying DB items that "belong" to
		///		this app.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public static Guid AppGuid
		{
			get
			{
				return new Guid("7885FF12-B860-48e8-9407-43AE0E50A55B");
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// The HTML help file (.chm) for the app.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public override string HelpFile
		{
			get { return string.Empty; }
		}
		#endregion // OBApp Properties

		#region Main entry point
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Application entry point. 
		/// </summary>
		/// <param name="rgArgs">Command-line arguments</param>
		/// <returns>0</returns>
		/// -----------------------------------------------------------------------------------
		[STAThread]
		public static int Main(string[] rgArgs) 
		{
			Process proc = ExistingProcess;
			if (proc == null)
			{
				using(OBApp app = new OBApp(rgArgs))
				{
					app.Run();
				}
			}
			else
			{
				// TODO: Try to figure out how to activate this process?
				MessageBox.Show("Object Browser is already running. Go catch it!");
			}
			return 0;
		}

		#endregion // Main entry point

		#region Construction and Initializing

		public OBApp(string[] rgArgs)
			: base(rgArgs)
		{
		}

		#endregion // Construction and Initializing

		#region ISettings implementation

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// The RegistryKey for this application.
		/// </summary>
		///***********************************************************************************
		override public RegistryKey SettingsKey
		{
			get 
			{
				return base.SettingsKey.CreateSubKey("ObjectBrowser");
			}
		}

		/// <summary>
		/// Save the persisted settings now.
		/// </summary>
		new public void SaveSettingsNow()
		{
		}

		#endregion // ISettings implementation

		#region FwApp required methods

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Creates a new instance of the main Translation Editor window
		/// </summary>
		/// 
		/// <param name="cache">Instance of the FW Data Objects cache that the new main window
		/// will use for accessing the database.</param>
		/// <param name="fNewCache">Flag indicating whether one-time, application-specific
		/// initialization should be done for this cache.</param>
		/// <param name="fOpeningNewProject"><c>true</c> if opening a brand spankin' new
		/// project (ignored in this app)</param>
		/// <returns>New instance of TeMainWnd if Scripture data has been successfully loaded;
		/// null, otherwise</returns>
		/// -----------------------------------------------------------------------------------
		override protected Form NewMainAppWnd(FdoCache cache, bool fNewCache, Form wndCopyFrom,
			bool fOpeningNewProject)
		{
			Debug.Assert(wndCopyFrom == null, "wndCopyFrom handling not implemented");
			if (!LoadData(cache))
				return null;

			if (fNewCache)
			{
			}
			return new OBMainWnd(cache, wndCopyFrom);
		}

		#endregion // FwApp required methods

		#region Miscellaneous Methods

		//hack until FwApp handles choosing/changing the project
		internal void ChooseProject()
		{
			//	ILgWritingSystemFactory wsf = m_fdoCache.LanguageWritingSystemFactoryAccessor;
			//			int ws = wsf.UserWs; 
			//			// results parms for the dlg.
			//			bool fHaveProject;
			//			int hvoProj;
			//			string sProject;
			//			Guid  guid;
			//			bool fHaveSubItem;
			//			int hvoSubItem;
			//			string sSubItemName;
			//			string sServer= Environment.MachineName +"\\SILFW";
			//			string sDatabase;
			// 
			//			//SIL.FieldWorks.Common.COMInterfaces.IOpenFWProjectDlg dlg = new SIL.FieldWorks.FwCoreDlgs
			//			//FwKernelLib.OpenFWProjectDlgClass dlg = new FwKernelLib.OpenFWProjectDlgClass();
			//			dlg.Show(null, sServer, ws, (uint)0/*this.Handle*/, true, 0, "xxxxxxxxxx.htm");
			//			dlg.GetResults(out fHaveProject, out hvoProj, out sProject,
			//				out sDatabase, 
			//				out sServer, //REVIEW RandyR: the intellisense says "machine".  Should be "server", since it must include SILFW.
			//				out guid, //REVIEW RandyR: can you give a more descriptive intellisense label?  I don't know what the guid is.
			//				out fHaveSubItem, out hvoSubItem,
			//				out sSubItemName);//REVIEW RandyR: can you give a more descriptive intellisense label? I don't know what the name is.
			//			if (!fHaveProject)
			//				return;
			//            
			//			FdoCache cache = FdoCache.Create(sServer, sDatabase, sProject, sSubItemName);
			//
			//			//hack
			//			//!!! the application will wantexit when the last window is closed
			//			foreach(Form w in this.MainWindows)
			//			{
			//				w.Close();
			//				break; //we only have one, and closing that window actually invalidated the Enumerator.
			//			}
			//
			//
			//			RegistryKey key = this.SettingsKey; //Registry.CurrentUser.CreateSubKey("Software\\SIL\\FieldWorks\\OB");
			//			
			//			// Save Database Settings
			//			key.SetValue("LatestDatabaseName", cache.DatabaseName);
			//			key.SetValue("LatestDatabaseServer", cache.ServerName);
			//			key.SetValue("LatestProjectName", cache.LanguageProject.Name.AnalysisDefaultEncoding);
			//
			//			//warning: any msgBox now will make this app be stuck running when it should exit.
			//			///			MessageBox.Show("HACK: OB will now exit and run again.");
			//
			//			System.Diagnostics.ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo(Application.ExecutablePath);
			//			System.Diagnostics.Process.Start(info); //relaunch me
		}
	
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Make sure that this LanguageProject is ready for WordWorks.
		/// </summary>
		/// 
		/// <param name="cache">FDO cache for accessing DB</param>
		/// 
		/// <returns>true if data loaded successfully; false, otherwise</returns>
		/// -----------------------------------------------------------------------------------
		protected bool LoadData(FdoCache cache)
		{
			return true;
		}

		#endregion
	}
}
