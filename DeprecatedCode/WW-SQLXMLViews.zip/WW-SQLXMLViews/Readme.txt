This folder contains three kinds of files (OK, there may be more, but I have identified these):

1)filterSpecs.xsl and filterSpecs2.xsl
2) filterCellar.xsl and filterCelar2.xsl
3) batch files which apply filterCellar(2).xsl to the xmi2cellar3.xml file to produce XDR files 
	(in the "fw\DistFiles\WW\annotatedSchemas" directory).

	These either apply filterCellar.xsl (which reads filterSpecs.xsl),
	or
	These either apply filterCellar2.xsl (which reads filterSpecs2.xsl).
In either case, the batch file invokes MSXL with a parameter identifying which "list" of specs should be used (e.g. WFI, SKETCH, or M3Stage1Dump.).

The difference between the 1 and 2 versions of these files is that in the initial pass, things were written such that you identified which things 
you wanted to *leave out*.

In the version 2 files, you instead specify which modules and signatures you want to *include*.
This is more convenient when 
a) you want to leave out more than you want to include
b) you do not want to worry about new attributes and things being added to CELLAR that 
	will automatically sneak into your xdr (until you modify the filters to omit them).
Note that even in this version, you specify which attributes you want to *exclude*.

Thus, in the version 2 files, a class is included in the schema if the signature if its module and signature are listed.
In the schema, a class will include a given property if
	a) the class of that attribute is included in the schema (by the prior rule)
	b) its attribute is not listed as one that should be omitted.

OK, I apologize that I have not been good documentation yet.  But this is a start...
JohnH
