Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmMain
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents sXPathQuery As System.Windows.Forms.ComboBox
	Public WithEvents comboView As System.Windows.Forms.ComboBox
	Public WithEvents btnDisplay As System.Windows.Forms.Button
	Public WithEvents Browser As AxSHDocVw.AxWebBrowser
	Public WithEvents picSplitter As System.Windows.Forms.PictureBox
	Public WithEvents tvTreeView As AxMSComctlLib.AxTreeView
	Public WithEvents sbStatusBar As AxMSComctlLib.AxStatusBar
	Public WithEvents dlgCommonDialog As AxMSComDlg.AxCommonDialog
	Public WithEvents imlToolbarIcons As AxMSComctlLib.AxImageList
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents imgSplitter As System.Windows.Forms.PictureBox
	Public WithEvents mnuFileOpenDB As System.Windows.Forms.MenuItem
	Public WithEvents mnuChooseMappingSchema As System.Windows.Forms.MenuItem
	Public WithEvents mnuDiv As System.Windows.Forms.MenuItem
	Public WithEvents mnuFileOpenXML As System.Windows.Forms.MenuItem
	Public WithEvents mnuFilePrint As System.Windows.Forms.MenuItem
	Public WithEvents mnuFile As System.Windows.Forms.MenuItem
	Public WithEvents mnuSetupList As System.Windows.Forms.MenuItem
	Public WithEvents mnuDisableCaching As System.Windows.Forms.MenuItem
	Public WithEvents mnuViewRefresh As System.Windows.Forms.MenuItem
	Public WithEvents mnuView As System.Windows.Forms.MenuItem
	Public WithEvents mnuHelpAbout As System.Windows.Forms.MenuItem
	Public WithEvents mnuHelp As System.Windows.Forms.MenuItem
	Public MainMenu1 As System.Windows.Forms.MainMenu
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.sXPathQuery = New System.Windows.Forms.ComboBox()
        Me.comboView = New System.Windows.Forms.ComboBox()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.Browser = New AxSHDocVw.AxWebBrowser()
        Me.picSplitter = New System.Windows.Forms.PictureBox()
        Me.tvTreeView = New AxMSComctlLib.AxTreeView()
        Me.sbStatusBar = New AxMSComctlLib.AxStatusBar()
        Me.dlgCommonDialog = New AxMSComDlg.AxCommonDialog()
        Me.imlToolbarIcons = New AxMSComctlLib.AxImageList()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.imgSplitter = New System.Windows.Forms.PictureBox()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuFileOpenDB = New System.Windows.Forms.MenuItem()
        Me.mnuChooseMappingSchema = New System.Windows.Forms.MenuItem()
        Me.mnuDiv = New System.Windows.Forms.MenuItem()
        Me.mnuFileOpenXML = New System.Windows.Forms.MenuItem()
        Me.mnuFilePrint = New System.Windows.Forms.MenuItem()
        Me.mnuView = New System.Windows.Forms.MenuItem()
        Me.mnuSetupList = New System.Windows.Forms.MenuItem()
        Me.mnuDisableCaching = New System.Windows.Forms.MenuItem()
        Me.mnuViewRefresh = New System.Windows.Forms.MenuItem()
        Me.mnuHelp = New System.Windows.Forms.MenuItem()
        Me.mnuHelpAbout = New System.Windows.Forms.MenuItem()
        CType(Me.Browser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tvTreeView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sbStatusBar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dlgCommonDialog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imlToolbarIcons, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'sXPathQuery
        '
        Me.sXPathQuery.BackColor = System.Drawing.SystemColors.Window
        Me.sXPathQuery.Cursor = System.Windows.Forms.Cursors.Default
        Me.sXPathQuery.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sXPathQuery.ForeColor = System.Drawing.SystemColors.WindowText
        Me.sXPathQuery.Location = New System.Drawing.Point(128, 8)
        Me.sXPathQuery.Name = "sXPathQuery"
        Me.sXPathQuery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.sXPathQuery.Size = New System.Drawing.Size(553, 22)
        Me.sXPathQuery.TabIndex = 8
        Me.sXPathQuery.Text = "Combo1"
        '
        'comboView
        '
        Me.comboView.BackColor = System.Drawing.SystemColors.Window
        Me.comboView.Cursor = System.Windows.Forms.Cursors.Default
        Me.comboView.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboView.ForeColor = System.Drawing.SystemColors.WindowText
        Me.comboView.Location = New System.Drawing.Point(128, 32)
        Me.comboView.Name = "comboView"
        Me.comboView.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.comboView.Size = New System.Drawing.Size(449, 22)
        Me.comboView.TabIndex = 7
        Me.comboView.Text = "Combo1"
        '
        'btnDisplay
        '
        Me.btnDisplay.BackColor = System.Drawing.SystemColors.Control
        Me.btnDisplay.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnDisplay.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplay.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDisplay.Location = New System.Drawing.Point(592, 32)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnDisplay.Size = New System.Drawing.Size(89, 25)
        Me.btnDisplay.TabIndex = 6
        Me.btnDisplay.Text = "Display"
        '
        'Browser
        '
        Me.Browser.Enabled = True
        Me.Browser.Location = New System.Drawing.Point(144, 56)
        Me.Browser.OcxState = CType(resources.GetObject("Browser.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Browser.Size = New System.Drawing.Size(401, 257)
        Me.Browser.TabIndex = 3
        '
        'picSplitter
        '
        Me.picSplitter.BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(128, Byte), CType(128, Byte))
        Me.picSplitter.Cursor = System.Windows.Forms.Cursors.Default
        Me.picSplitter.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picSplitter.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picSplitter.Location = New System.Drawing.Point(360, 103)
        Me.picSplitter.Name = "picSplitter"
        Me.picSplitter.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.picSplitter.Size = New System.Drawing.Size(5, 272)
        Me.picSplitter.TabIndex = 2
        Me.picSplitter.Visible = False
        '
        'tvTreeView
        '
        Me.tvTreeView.Location = New System.Drawing.Point(8, 63)
        Me.tvTreeView.Name = "tvTreeView"
        Me.tvTreeView.OcxState = CType(resources.GetObject("tvTreeView.OcxState"), System.Windows.Forms.AxHost.State)
        Me.tvTreeView.Size = New System.Drawing.Size(118, 280)
        Me.tvTreeView.TabIndex = 1
        '
        'sbStatusBar
        '
        Me.sbStatusBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.sbStatusBar.Location = New System.Drawing.Point(0, 417)
        Me.sbStatusBar.Name = "sbStatusBar"
        Me.sbStatusBar.OcxState = CType(resources.GetObject("sbStatusBar.OcxState"), System.Windows.Forms.AxHost.State)
        Me.sbStatusBar.Size = New System.Drawing.Size(813, 19)
        Me.sbStatusBar.TabIndex = 0
        '
        'dlgCommonDialog
        '
        Me.dlgCommonDialog.Enabled = True
        Me.dlgCommonDialog.Location = New System.Drawing.Point(64, 368)
        Me.dlgCommonDialog.Name = "dlgCommonDialog"
        Me.dlgCommonDialog.OcxState = CType(resources.GetObject("dlgCommonDialog.OcxState"), System.Windows.Forms.AxHost.State)
        Me.dlgCommonDialog.Size = New System.Drawing.Size(32, 32)
        Me.dlgCommonDialog.TabIndex = 9
        '
        'imlToolbarIcons
        '
        Me.imlToolbarIcons.Enabled = True
        Me.imlToolbarIcons.Location = New System.Drawing.Point(16, 360)
        Me.imlToolbarIcons.Name = "imlToolbarIcons"
        Me.imlToolbarIcons.OcxState = CType(resources.GetObject("imlToolbarIcons.OcxState"), System.Windows.Forms.AxHost.State)
        Me.imlToolbarIcons.Size = New System.Drawing.Size(38, 38)
        Me.imlToolbarIcons.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(56, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(65, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "XSLT View:"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(48, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(72, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "XPath Query:"
        '
        'imgSplitter
        '
        Me.imgSplitter.Cursor = System.Windows.Forms.Cursors.SizeWE
        Me.imgSplitter.Location = New System.Drawing.Point(128, 64)
        Me.imgSplitter.Name = "imgSplitter"
        Me.imgSplitter.Size = New System.Drawing.Size(10, 271)
        Me.imgSplitter.TabIndex = 11
        Me.imgSplitter.TabStop = False
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuView, Me.mnuHelp})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileOpenDB, Me.mnuChooseMappingSchema, Me.mnuDiv, Me.mnuFileOpenXML, Me.mnuFilePrint})
        Me.mnuFile.Text = "&File"
        '
        'mnuFileOpenDB
        '
        Me.mnuFileOpenDB.Index = 0
        Me.mnuFileOpenDB.Text = "&Open Database..."
        '
        'mnuChooseMappingSchema
        '
        Me.mnuChooseMappingSchema.Index = 1
        Me.mnuChooseMappingSchema.Text = "&Choose Mapping Schema..."
        '
        'mnuDiv
        '
        Me.mnuDiv.Index = 2
        Me.mnuDiv.Text = "-"
        '
        'mnuFileOpenXML
        '
        Me.mnuFileOpenXML.Enabled = False
        Me.mnuFileOpenXML.Index = 3
        Me.mnuFileOpenXML.Text = "Open &XML File... (not implemented)"
        '
        'mnuFilePrint
        '
        Me.mnuFilePrint.Enabled = False
        Me.mnuFilePrint.Index = 4
        Me.mnuFilePrint.Shortcut = System.Windows.Forms.Shortcut.CtrlP
        Me.mnuFilePrint.Text = "&Print (doesn't work)"
        '
        'mnuView
        '
        Me.mnuView.Index = 1
        Me.mnuView.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuSetupList, Me.mnuDisableCaching, Me.mnuViewRefresh})
        Me.mnuView.Text = "&View"
        '
        'mnuSetupList
        '
        Me.mnuSetupList.Index = 0
        Me.mnuSetupList.Text = "&Setup List..."
        '
        'mnuDisableCaching
        '
        Me.mnuDisableCaching.Index = 1
        Me.mnuDisableCaching.Text = "&Disable SQL Server XML Caching"
        '
        'mnuViewRefresh
        '
        Me.mnuViewRefresh.Index = 2
        Me.mnuViewRefresh.Shortcut = System.Windows.Forms.Shortcut.F5
        Me.mnuViewRefresh.Text = "&Refresh"
        '
        'mnuHelp
        '
        Me.mnuHelp.Index = 2
        Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuHelpAbout})
        Me.mnuHelp.Text = "&Help"
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Index = 0
        Me.mnuHelpAbout.Text = "&About "
        '
        'frmMain
        '
        Me.AcceptButton = Me.btnDisplay
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(813, 436)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.sXPathQuery, Me.comboView, Me.btnDisplay, Me.Browser, Me.picSplitter, Me.tvTreeView, Me.sbStatusBar, Me.dlgCommonDialog, Me.imlToolbarIcons, Me.Label2, Me.Label1, Me.imgSplitter})
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Location = New System.Drawing.Point(11, 49)
        Me.Menu = Me.MainMenu1
        Me.Name = "frmMain"
        Me.Text = "XBrowse"
        CType(Me.Browser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tvTreeView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sbStatusBar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dlgCommonDialog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imlToolbarIcons, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmMain
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmMain
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmMain()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	
	Dim mbMoving As Boolean
	Const sglSplitLimit As Short = 500
	Private FWDBDialog As FWDataSource
	Private m_sMappingSchemaPath As String
	Private m_sListQuery As String
	Private m_sItemQuery As String
	
	Private Sub loadViewCombo()
		Dim shellObj As New Shell32.Shell
		Dim oFolder As Shell32.Folder
		Dim folderItem As Shell32.ShellFolderItem
		With comboView
			.Items.Clear()
			.Items.Add("Raw XML")
			.SelectedIndex = 0
			
			'Suck in all the xsl sheets at the level of  (for now, the app path)
			
			
			oFolder = shellObj.NameSpace(BaseFolder)
			
			If oFolder Is Nothing Then Exit Sub
			
			For	Each folderItem In oFolder.Items
				If VB.Right(folderItem.Name, 3) = "xsl" Then
					.Items.Add(folderItem.Path)
				End If
			Next folderItem
			
			' If .ListCount > 1 Then
			'    .ListIndex = 1
			'End If
		End With
		
	End Sub
	
	Private Sub LoadQueryCombo()
		With sXPathQuery
			.Items.Clear()
			.Items.Add("C:\fw\ww\code\xmlMapSchemaWork\M3Stage1DumpTemplate.xml")
			.Items.Add("PartOfSpeech")
			.Items.Add("PhPhonologicalData")
			.Items.Add("MoMorphologicalData")
			.Items.Add("LexMajorEntry")
			.Items.Add("MoMorphType")
			.Items.Add("-------------")
			.Items.Add("WfiWordform")
		End With
	End Sub
	Private Function BaseFolder() As String
		Dim f As New Scripting.FileSystemObject
		BaseFolder = f.GetParentFolderName(m_sMappingSchemaPath)
	End Function
	Private Sub btnDisplay_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles btnDisplay.Click
		Cursor = System.Windows.Forms.Cursors.WaitCursor
		Dim conn As ADODB.Connection
        '		conn = FWDBDialog.CreateConnection("SQLXMLOLEDB.2.0;data provider=SQLOLEDB")
        conn = FWDBDialog.CreateConnection("SQLXMLOLEDB;data provider=SQLOLEDB")

		'    Browser.Navigate "about:blank" ' DOESN'T ACTUALLY GET AROUND TO GOING THERE...
		btnDisplay.Text = "thinkin'"
		Dim sXSLTViewPath As String
		sXSLTViewPath = comboView.Text
		
		
		Dim sQry As String
		sQry = Replace(sXPathQuery.Text, "$lpid", CStr(FWDBDialog.LangProjID))
		
		Dim sHTMLPath As String
		If Not FWSQLXMLAccess.QueryDBToHTML(conn, m_sMappingSchemaPath, sQry, sXSLTViewPath, sHTMLPath, mnuDisableCaching.Checked) Then
			'MsgBox "There was an error"
		End If
		sbStatusBar.Style = MSComctlLib.SbarStyleConstants.sbrSimple
		
		sbStatusBar.SimpleText = "Query took " & (glExecuteQueryTime / 1000) & " seconds."
		
		Browser.Offline = True
		Browser.Navigate(sHTMLPath)
		'UPGRADE_ISSUE: Unable to determine which constant to upgrade vbNormal to. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2049"'
		'UPGRADE_ISSUE: Form property frmMain.MousePointer does not support custom mousepointers. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2036"'
        Cursor = System.Windows.Forms.Cursors.WaitCursor
		
		btnDisplay.Text = "Display"
		
	End Sub
	
	Private Sub frmMain_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Browser.Offline = True
		FWDBDialog = New FWDataSource
		FWDBDialog.LoadFromRegistry()
		
		m_sMappingSchemaPath = GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MappingSchemaPath", "")
        m_sListQuery = GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "ListQuery", dlgListSetup.s_DefaultListQry)
        m_sItemQuery = GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "ItemQuery", dlgListSetup.s_DefaultItemQry)
		
		SetWindowTitle()
		
		loadViewCombo()
		LoadQueryCombo()
		
		comboView.Text = GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "View", "RAW XML")
		sXPathQuery.Text = GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "XPathQuery", "WFI")
		Do While m_sMappingSchemaPath = ""
			If MsgBoxResult.Cancel = MsgBox("Please locate a mapping schema.", MsgBoxStyle.OKCancel) Then
				Exit Sub ' couldn't get unload me to actually kill the app
			End If
			
			mnuChooseMappingSchema_Click(mnuChooseMappingSchema, New System.EventArgs())
		Loop 
		
		Me.Left = VB6.TwipsToPixelsX(CSng(GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MainLeft", CStr(1000))))
		Me.Top = VB6.TwipsToPixelsY(CSng(GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MainTop", CStr(1000))))
		Me.Width = VB6.TwipsToPixelsX(CSng(GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MainWidth", CStr(6500))))
		Me.Height = VB6.TwipsToPixelsY(CSng(GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MainHeight", CStr(6500))))
		
        '    btnDisplay_Click
        tvTreeView.Nodes.Add(, , , "Press F5 for wordforms")
    End Sub

    'UPGRADE_WARNING: Form event frmMain.Unload has a new behavior. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2065"'
    Private Sub frmMain_Closed(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed
        Dim i As Short


        'close all sub forms
        'UPGRADE_ISSUE: Forms collection was not upgraded. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2068"'
        'UPGRADE_WARNING: Couldn't resolve default property of object Forms.Count. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup1037"'
        'For i = Forms.Count - 1 To 1 Step -1
        '	'UPGRADE_ISSUE: Forms collection was not upgraded. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2068"'
        '	'UPGRADE_ISSUE: Unload Forms() was not upgraded. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2029"'
        '	Unload(Forms(i))
        'Next 
        If Me.WindowState <> System.Windows.Forms.FormWindowState.Minimized Then
            SaveSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MainLeft", CStr(VB6.PixelsToTwipsX(Me.Left)))
            SaveSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MainTop", CStr(VB6.PixelsToTwipsY(Me.Top)))
            SaveSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MainWidth", CStr(VB6.PixelsToTwipsX(Me.Width)))
            SaveSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MainHeight", CStr(VB6.PixelsToTwipsY(Me.Height)))

            SaveSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "XPathQuery", sXPathQuery.Text)
            SaveSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "View", comboView.Text)
            SaveSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "MappingSchemaPath", m_sMappingSchemaPath)
            SaveSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "ListQuery", m_sListQuery)
            SaveSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Settings", "ItemQuery", m_sItemQuery)

        End If
    End Sub



    'UPGRADE_WARNING: Event frmMain.Resize may fire when form is intialized. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2075"'
    Private Sub frmMain_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
        On Error Resume Next
        If VB6.PixelsToTwipsX(Me.Width) < 3000 Then Me.Width = VB6.TwipsToPixelsX(3000)
        SizeControls((VB6.PixelsToTwipsX(imgSplitter.Left)))
    End Sub


    Private Sub imgSplitter_MouseDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles imgSplitter.MouseDown
        Dim Button As Short = eventArgs.Button \ &H100000
        Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
        Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
        Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
        With imgSplitter
            picSplitter.SetBounds(.Left, .Top, VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(.Width) \ 2), VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(.Height) - 20))
        End With
        picSplitter.Visible = True
        mbMoving = True
    End Sub


    Private Sub imgSplitter_MouseMove(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles imgSplitter.MouseMove
        Dim Button As Short = eventArgs.Button \ &H100000
        Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
        Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
        Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
        Dim sglPos As Single


        If mbMoving Then
            sglPos = X + VB6.PixelsToTwipsX(imgSplitter.Left)
            If sglPos < sglSplitLimit Then
                picSplitter.Left = VB6.TwipsToPixelsX(sglSplitLimit)
            ElseIf sglPos > VB6.PixelsToTwipsX(Me.Width) - sglSplitLimit Then
                picSplitter.Left = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - sglSplitLimit)
            Else
                picSplitter.Left = VB6.TwipsToPixelsX(sglPos)
            End If
        End If
    End Sub


    Private Sub imgSplitter_MouseUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles imgSplitter.MouseUp
        Dim Button As Short = eventArgs.Button \ &H100000
        Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
        Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
        Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
        SizeControls((VB6.PixelsToTwipsX(picSplitter.Left)))
        picSplitter.Visible = False
        mbMoving = False
    End Sub


    Private Sub TreeView1_DragDrop(ByRef Source As System.Windows.Forms.Control, ByRef X As Single, ByRef Y As Single)
        If Source.Equals(imgSplitter.Image) Then
            SizeControls(X)
        End If
    End Sub


    Sub SizeControls(ByRef X As Single)
        On Error Resume Next


        'set the width
        If X < 1500 Then X = 1500
        If X > (VB6.PixelsToTwipsX(Me.Width) - 1500) Then X = VB6.PixelsToTwipsX(Me.Width) - 1500
        tvTreeView.Width = VB6.TwipsToPixelsX(X)
        imgSplitter.Left = VB6.TwipsToPixelsX(X)
        Browser.Width = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - (VB6.PixelsToTwipsX(Browser.Left) + 200))

        'set the top

        Browser.Top = tvTreeView.Top


        'set the height
        tvTreeView.Height = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.ClientRectangle.Height) - (VB6.PixelsToTwipsY(sbStatusBar.Height) + 900))


        Browser.Height = tvTreeView.Height
        imgSplitter.Top = tvTreeView.Top
        imgSplitter.Height = tvTreeView.Height
    End Sub

    Public Sub mnuChooseMappingSchema_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuChooseMappingSchema.Popup
        mnuChooseMappingSchema_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuChooseMappingSchema_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuChooseMappingSchema.Click
        With dlgCommonDialog
            .DialogTitle = "Open"
            .CancelError = False
            'ToDo: set the flags and attributes of the common dialog control
            .Filter = "Sql Server Mapping Schemas (*.xdr *.xsd *.xml)|*.xdr;*.xsd;*.xml|"
            .ShowOpen()
            If Len(.FileName) = 0 Then
                Exit Sub
            End If
            m_sMappingSchemaPath = .FileName
        End With
        SetWindowTitle()
        loadViewCombo()
    End Sub

    Public Sub mnuDisableCaching_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuDisableCaching.Popup
        mnuDisableCaching_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuDisableCaching_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuDisableCaching.Click
        mnuDisableCaching.Checked = Not mnuDisableCaching.Checked
    End Sub

    Public Sub mnuFileOpenDB_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFileOpenDB.Popup
        mnuFileOpenDB_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuFileOpenDB_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFileOpenDB.Click
        With FWDBDialog

            .ShowDialog()
            If .bDidOK Then
                If .GotSource Then ' warning: .GotSource will cause a reload of the dlg if user used the 'x' close button
                    .SaveInRegistry()
                End If
            Else
                FWDBDialog.Close()
                Exit Sub
            End If
        End With
        SetWindowTitle()
    End Sub

    Public Sub mnuFilePrint_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFilePrint.Popup
        mnuFilePrint_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuFilePrint_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFilePrint.Click
        'DOESN"T WORK
        Const IDM_PRINTPREVIEW As Short = 2003
        Const IDM_PRINT As Short = 27
        Dim h As mshtml.IHTMLDocument2 ' there is a 4
        h = Browser.Document
        Dim b As Boolean
        b = h.execCommand(CStr(IDM_PRINTPREVIEW), True)
        ' h.execCommand IDM_PRINT, True
    End Sub

    Private Sub tbToolBar_ButtonClick(ByVal Button As MSComctlLib.Button)
        On Error Resume Next
        Select Case Button.Key
            Case "Print"
                'ToDo: Add 'Print' button code.
                MsgBox("Add 'Print' button code.")
            Case "Find"
                'ToDo: Add 'Find' button code.
                MsgBox("Add 'Find' button code.")
        End Select
    End Sub

    Public Sub mnuHelpAbout_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuHelpAbout.Popup
        mnuHelpAbout_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuHelpAbout_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuHelpAbout.Click
        VB6.ShowForm(frmAbout.DefInstance, VB6.FormShowConstants.Modal, Me)
    End Sub

    Public Sub mnuSetupList_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuSetupList.Popup
        mnuSetupList_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuSetupList_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuSetupList.Click
        Dim dlg As New dlgListSetup()
        With dlg
            .sListQuery.Text = m_sListQuery
            .sItemQuery.Text = m_sItemQuery
            .FillInBlanks()
            VB6.ShowForm(dlg, (VB6.FormShowConstants.Modal))
            If .bDidOK Then
                m_sListQuery = .sListQuery.Text
                m_sItemQuery = .sItemQuery.Text
            End If
        End With

        dlg.Close()
    End Sub

    Public Sub mnuViewRefresh_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewRefresh.Popup
        mnuViewRefresh_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuViewRefresh_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewRefresh.Click
        'ToDo: Add 'mnuViewRefresh_Click' code.
        LoadObjectsList()
    End Sub

    Private Sub mnuFileOpen_Click()
        Dim sFile As String


        With dlgCommonDialog
            .DialogTitle = "Open"
            .CancelError = False
            'ToDo: set the flags and attributes of the common dialog control
            .Filter = "All Files (*.*)|*.*"
            .ShowOpen()
            If Len(.FileName) = 0 Then
                Exit Sub
            End If
            sFile = .FileName
        End With
        'ToDo: add code to process the opened file

    End Sub

    Private Sub SetWindowTitle()
        Me.Text = System.Reflection.Assembly.GetExecutingAssembly.GetName.Name & " " & System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMajorPart & "." & System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMinorPart & "        " & FWDBDialog.sServer.Text & "-" & FWDBDialog.SDB.Text & "-" & FWDBDialog.sLangProject & " with map """ & m_sMappingSchemaPath & """"

    End Sub


    Private Function LoadObjectsList() As Integer
        Dim rs As ADODB.Recordset
        On Error GoTo catch_Renamed
        Dim conn As ADODB.Connection
        conn = FWDBDialog.CreateConnection("")

        tvTreeView.Visible = False
        tvTreeView.Nodes.Clear()

        rs = conn.Execute(m_sListQuery)
        Dim sTxt As String
        Dim n As MSComctlLib.Node
        If rs.EOF Then
            tvTreeView.Visible = True
            tvTreeView.Nodes.Add(, , , "No Items Found")
            Exit Function
        End If

        'sbStatusBar.SimpleText = .RecordCount & " Entries"
        System.Diagnostics.Debug.Assert(rs.Fields.Count > 0)
        LoadObjectsList = rs.Fields(0).Value ' id of first one
        While True
            '  If .Fields!enc = m_ivernEnc Then 'Or IsNull(.Fields!enc) Then 'IsNull(.Fields!txt) Then
            'UPGRADE_WARNING: Use of Null/IsNull() detected. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup1049"'
            If IsDBNull(rs.Fields(1).Value) Then
                sTxt = "***"
            Else
                sTxt = rs.Fields(1).Value
            End If
            On Error Resume Next
            n = Me.tvTreeView.Nodes.Add(, , getKey(rs.Fields(0).Value), sTxt)
            If Err.Number <> 0 And Err.Number <> 35602 Then '35602 means we had a duplicate id  todo deal with this
                MsgBox("There was a problem with item " & rs.Fields(0).Value & "'" & sTxt & "'" & vbCrLf & Err.Description)
            End If
            On Error GoTo 0

            rs.MoveNext()
            If rs.BOF Or rs.EOF Then GoTo done
        End While

        GoTo done
catch_Renamed:
        CatchError(("Executing List Query"))
done:
        rs.Close()
        tvTreeView.Visible = True


    End Function



    Public Sub CatchError(ByRef sProcName As Object)
        If Err.Number <> 0 Then
            'UPGRADE_WARNING: Couldn't resolve default property of object sProcName. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup1037"'
            MsgBox("While in " & sProcName & ", got " & vbCrLf & Err.Description)
        End If

        On Error GoTo 0
    End Sub


    Private Sub tvTreeView_NodeClick(ByVal eventSender As System.Object, ByVal eventArgs As AxMSComctlLib.ITreeViewEvents_NodeClickEvent) Handles tvTreeView.NodeClick
        SelectObject(GetSelectedObjId)
    End Sub

    Private Function GetSelectedObjId() As String
        GetSelectedObjId = GetIdFromKey(tvTreeView.SelectedItem.Key)
    End Function

    'needed because vb doesn't let us use raw digits as a key
    Private Function GetIdFromKey(ByRef sKey As String) As String
        GetIdFromKey = Mid(sKey, 3)
    End Function

    ' because we are not allowed to put integers as keys to the
    ' Treeview, we make a key by prepending "ID" to the number
    Private Function getKey(ByVal id As Integer) As String
        getKey = "id" & id.ToString().Trim()
    End Function

    Private Sub SelectObject(ByRef id As String)

        On Error Resume Next ' may not be able to focus when starting up
        Me.Activate()
        On Error GoTo 0 ' reset error handling
        tvTreeView.SelectedItem = tvTreeView.Nodes(getKey(id))
        sbStatusBar.SimpleText = "Showing object " & tvTreeView.SelectedItem.Index & " of " & tvTreeView.Nodes.Count & ".  object.id= " & id
        'sHeading = "object: " & tvTreeView.SelectedItem.Text
        sXPathQuery.Text = Replace(m_sItemQuery, "$id", id)
        btnDisplay_Click(btnDisplay, New System.EventArgs())
    End Sub
End Class