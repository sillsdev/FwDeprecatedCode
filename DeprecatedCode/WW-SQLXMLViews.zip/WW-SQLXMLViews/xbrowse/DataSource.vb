Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class FWDataSource
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents btnLookupProjects As System.Windows.Forms.Button
	Public WithEvents lstProjects As System.Windows.Forms.ListBox
	Public WithEvents SDB As System.Windows.Forms.TextBox
	Public WithEvents sServer As System.Windows.Forms.TextBox
	Public WithEvents CancelButton_Renamed As System.Windows.Forms.Button
	Public WithEvents OKButton As System.Windows.Forms.Button
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents _Label1_1 As System.Windows.Forms.Label
	Public WithEvents _Label2_0 As System.Windows.Forms.Label
	Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Label2 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FWDataSource))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.ToolTip1.Active = True
		Me.btnLookupProjects = New System.Windows.Forms.Button
		Me.lstProjects = New System.Windows.Forms.ListBox
		Me.SDB = New System.Windows.Forms.TextBox
		Me.sServer = New System.Windows.Forms.TextBox
		Me.CancelButton_Renamed = New System.Windows.Forms.Button
		Me.OKButton = New System.Windows.Forms.Button
		Me.Label3 = New System.Windows.Forms.Label
		Me._Label1_1 = New System.Windows.Forms.Label
		Me._Label2_0 = New System.Windows.Forms.Label
		Me.Label1 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.Label2 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label2, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Text = "Open Database Source"
		Me.ClientSize = New System.Drawing.Size(402, 210)
		Me.Location = New System.Drawing.Point(184, 250)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "FWDataSource"
		Me.btnLookupProjects.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.btnLookupProjects.Text = "Lookup"
		Me.btnLookupProjects.Size = New System.Drawing.Size(65, 17)
		Me.btnLookupProjects.Location = New System.Drawing.Point(208, 120)
		Me.btnLookupProjects.TabIndex = 8
		Me.btnLookupProjects.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnLookupProjects.BackColor = System.Drawing.SystemColors.Control
		Me.btnLookupProjects.CausesValidation = True
		Me.btnLookupProjects.Enabled = True
		Me.btnLookupProjects.ForeColor = System.Drawing.SystemColors.ControlText
		Me.btnLookupProjects.Cursor = System.Windows.Forms.Cursors.Default
		Me.btnLookupProjects.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.btnLookupProjects.TabStop = True
		Me.btnLookupProjects.Name = "btnLookupProjects"
		Me.lstProjects.Size = New System.Drawing.Size(273, 59)
		Me.lstProjects.Location = New System.Drawing.Point(16, 136)
		Me.lstProjects.TabIndex = 6
		Me.lstProjects.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lstProjects.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lstProjects.BackColor = System.Drawing.SystemColors.Window
		Me.lstProjects.CausesValidation = True
		Me.lstProjects.Enabled = True
		Me.lstProjects.ForeColor = System.Drawing.SystemColors.WindowText
		Me.lstProjects.IntegralHeight = True
		Me.lstProjects.Cursor = System.Windows.Forms.Cursors.Default
		Me.lstProjects.SelectionMode = System.Windows.Forms.SelectionMode.One
		Me.lstProjects.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lstProjects.Sorted = False
		Me.lstProjects.TabStop = True
		Me.lstProjects.Visible = True
		Me.lstProjects.MultiColumn = False
		Me.lstProjects.Name = "lstProjects"
		Me.SDB.AutoSize = False
		Me.SDB.Size = New System.Drawing.Size(273, 25)
		Me.SDB.Location = New System.Drawing.Point(16, 80)
		Me.SDB.TabIndex = 1
		Me.SDB.Text = "Text2"
		Me.SDB.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.SDB.AcceptsReturn = True
		Me.SDB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.SDB.BackColor = System.Drawing.SystemColors.Window
		Me.SDB.CausesValidation = True
		Me.SDB.Enabled = True
		Me.SDB.ForeColor = System.Drawing.SystemColors.WindowText
		Me.SDB.HideSelection = True
		Me.SDB.ReadOnly = False
		Me.SDB.Maxlength = 0
		Me.SDB.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.SDB.MultiLine = False
		Me.SDB.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.SDB.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.SDB.TabStop = True
		Me.SDB.Visible = True
		Me.SDB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.SDB.Name = "SDB"
		Me.sServer.AutoSize = False
		Me.sServer.Size = New System.Drawing.Size(273, 25)
		Me.sServer.Location = New System.Drawing.Point(16, 24)
		Me.sServer.TabIndex = 0
        Me.sServer.Text = "(local)"
		Me.sServer.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.sServer.AcceptsReturn = True
		Me.sServer.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.sServer.BackColor = System.Drawing.SystemColors.Window
		Me.sServer.CausesValidation = True
		Me.sServer.Enabled = True
		Me.sServer.ForeColor = System.Drawing.SystemColors.WindowText
		Me.sServer.HideSelection = True
		Me.sServer.ReadOnly = False
		Me.sServer.Maxlength = 0
		Me.sServer.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.sServer.MultiLine = False
		Me.sServer.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.sServer.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.sServer.TabStop = True
		Me.sServer.Visible = True
		Me.sServer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.sServer.Name = "sServer"
		Me.CancelButton_Renamed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.CancelButton = Me.CancelButton_Renamed
		Me.CancelButton_Renamed.Text = "Cancel"
		Me.CancelButton_Renamed.Size = New System.Drawing.Size(81, 25)
		Me.CancelButton_Renamed.Location = New System.Drawing.Point(312, 80)
		Me.CancelButton_Renamed.TabIndex = 4
		Me.CancelButton_Renamed.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.CancelButton_Renamed.BackColor = System.Drawing.SystemColors.Control
		Me.CancelButton_Renamed.CausesValidation = True
		Me.CancelButton_Renamed.Enabled = True
		Me.CancelButton_Renamed.ForeColor = System.Drawing.SystemColors.ControlText
		Me.CancelButton_Renamed.Cursor = System.Windows.Forms.Cursors.Default
		Me.CancelButton_Renamed.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.CancelButton_Renamed.TabStop = True
		Me.CancelButton_Renamed.Name = "CancelButton_Renamed"
		Me.OKButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.OKButton.Text = "OK"
		Me.AcceptButton = Me.OKButton
		Me.OKButton.Size = New System.Drawing.Size(81, 25)
		Me.OKButton.Location = New System.Drawing.Point(312, 24)
		Me.OKButton.TabIndex = 2
		Me.OKButton.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.OKButton.BackColor = System.Drawing.SystemColors.Control
		Me.OKButton.CausesValidation = True
		Me.OKButton.Enabled = True
		Me.OKButton.ForeColor = System.Drawing.SystemColors.ControlText
		Me.OKButton.Cursor = System.Windows.Forms.Cursors.Default
		Me.OKButton.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.OKButton.TabStop = True
		Me.OKButton.Name = "OKButton"
		Me.Label3.Text = "Language Projects"
		Me.Label3.Size = New System.Drawing.Size(129, 17)
		Me.Label3.Location = New System.Drawing.Point(16, 120)
		Me.Label3.TabIndex = 7
		Me.Label3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label3.BackColor = System.Drawing.SystemColors.Control
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me._Label1_1.Text = "Server Machine"
		Me._Label1_1.Size = New System.Drawing.Size(145, 17)
		Me._Label1_1.Location = New System.Drawing.Point(16, 8)
		Me._Label1_1.TabIndex = 5
		Me._Label1_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_1.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_1.Enabled = True
		Me._Label1_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_1.UseMnemonic = True
		Me._Label1_1.Visible = True
		Me._Label1_1.AutoSize = False
		Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_1.Name = "_Label1_1"
		Me._Label2_0.Text = "Database"
		Me._Label2_0.Size = New System.Drawing.Size(145, 17)
		Me._Label2_0.Location = New System.Drawing.Point(16, 64)
		Me._Label2_0.TabIndex = 3
		Me._Label2_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._Label2_0.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label2_0.BackColor = System.Drawing.SystemColors.Control
		Me._Label2_0.Enabled = True
		Me._Label2_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label2_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label2_0.UseMnemonic = True
		Me._Label2_0.Visible = True
		Me._Label2_0.AutoSize = False
		Me._Label2_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label2_0.Name = "_Label2_0"
		Me.Controls.Add(btnLookupProjects)
		Me.Controls.Add(lstProjects)
		Me.Controls.Add(SDB)
		Me.Controls.Add(sServer)
		Me.Controls.Add(CancelButton_Renamed)
		Me.Controls.Add(OKButton)
		Me.Controls.Add(Label3)
		Me.Controls.Add(_Label1_1)
		Me.Controls.Add(_Label2_0)
		Me.Label1.SetIndex(_Label1_1, CType(1, Short))
		Me.Label2.SetIndex(_Label2_0, CType(0, Short))
		CType(Me.Label2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
	End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As FWDataSource
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As FWDataSource
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New FWDataSource()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 

    Public sServerPath As String
    Public sLangProject As String
    'Visual Basic says that this attribute is inherited, but I do not see it on the form class. Public SDB As String
    Public bDidOK As Boolean
	Private lLangProjID As Integer
	Const kencEng As Integer = 740664001
	
	'this is just code a client can use to create a connection based on the current settings of this object
	Public Function CreateConnection(Optional ByRef sProvider As String = "") As ADODB.Connection
		If sProvider = "" Then
            sProvider = "SQLOLEDB.1"
		End If
		
		CreateConnection = New ADODB.Connection
		With CreateConnection
			.ConnectionTimeout = 10 ' five seconds
			.CursorLocation = ADODB.CursorLocationEnum.adUseClient
			.Open("Provider=" & sProvider & ";Initial Catalog=" & SDB.Text & ";Data Source=" & sServerPath, "FWDeveloper", "careful")
		End With
	End Function
	Private Sub LoadProjList()
		
		lstProjects.Items.Clear()
		
		Dim s As String
        s = "select obj, txt from cmproject_name (readuncommitted) where ws = " & kencEng ' todo: remove english only
		
		Dim db As New ADODB.Connection
		Dim rs As ADODB.Recordset
		Dim iObj As Short
		With db
			Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
			On Error GoTo catchOpen
			.Open("Provider=SQLOLEDB.1;Initial Catalog=" & SDB.Text & ";Data Source=" & sServerPath, "FWDeveloper", "careful")
			On Error GoTo catchLookup
			rs = .Execute(s)
			With rs
				.MoveFirst()
				While Not (.BOF Or .EOF)
					'UPGRADE_WARNING: Use of Null/IsNull() detected. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup1049"'
					If Not IsDbNull(.Fields!txt.Value) Then
						lstProjects.Items.Add(.Fields!txt.Value)
						iObj = .Fields!obj.Value
						VB6.SetItemData(lstProjects, lstProjects.Items.Count - 1, iObj)
						If sLangProject = .Fields!txt.Value Then
							lstProjects.SelectedIndex = lstProjects.Items.Count - 1
						End If
					End If
					.MoveNext()
				End While
				
			End With
		End With
		'if we didn't select the previously selected one, select the first one
		If lstProjects.SelectedIndex = -1 Then
			lstProjects.SelectedIndex = 0
		End If
		UpdateButtons()
        Me.Cursor = Windows.Forms.Cursors.Default
        Exit Sub
catchOpen:
        Me.Cursor = Windows.Forms.Cursors.Default
        MsgBox("Problem opening database:" & vbCrLf & Err.Description)
        On Error GoTo 0
		Exit Sub
catchLookup: 
        Me.Cursor = Windows.Forms.Cursors.Default
        MsgBox("Problem looking up projects:" & vbCrLf & Err.Description)
        On Error GoTo 0
	End Sub
	
	Private Sub btnLookupProjects_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles btnLookupProjects.Click
		LoadProjList()
	End Sub
	
	
	Private Sub FWDataSource_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		bDidOK = False
		LoadFromRegistry()
		LoadProjList()
	End Sub
	Private Sub CancelButton_Renamed_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CancelButton_Renamed.Click
		sServer.Text = ""
		SDB.Text = ""
		Me.Hide()
	End Sub
	
	
	
	Public Function LangProjID() As Integer
		LangProjID = lLangProjID 'LangProjID = lstProjects.ItemData(lstProjects.ListIndex)  ' obj id is item data of selected project
	End Function
	
	'UPGRADE_WARNING: Event lstProjects.SelectedIndexChanged may fire when form is intialized. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub lstProjects_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstProjects.SelectedIndexChanged
        sLangProject = VB6.GetItemString(lstProjects, lstProjects.SelectedIndex)
		lLangProjID = VB6.GetItemData(lstProjects, lstProjects.SelectedIndex) ' have to store it now 'cause later the listindex goes to zero(while dlg is hidden?)
	End Sub
	
	Private Sub OKButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles OKButton.Click
		bDidOK = True
		Me.Hide()
	End Sub
	
	'UPGRADE_WARNING: Event SDB.TextChanged may fire when form is intialized. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub SDB_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles SDB.TextChanged
		lstProjects.Items.Clear()
		UpdateButtons()
	End Sub
	
	Private Sub SDB_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles SDB.Leave
		If lstProjects.Items.Count = 0 Then
			LoadProjList()
		End If
	End Sub
	
	'UPGRADE_WARNING: Event sServer.TextChanged may fire when form is intialized. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub sServer_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles sServer.TextChanged
        If sServer.Text = "(local)" Then
            sServerPath = System.Windows.Forms.SystemInformation.ComputerName & "\SILFW"
        Else
            sServerPath = sServer.Text & "\SILFW"
        End If
        lstProjects.Items.Clear()
        UpdateButtons()
	End Sub
	
	Public Sub SaveInRegistry()
		SaveSetting("Fieldworks", "DataSource", "Server", sServer.Text)
		SaveSetting("Fieldworks", "DataSource", "Database", SDB.Text)
		SaveSetting("fieldworks", "DataSource", "LanguageProject", sLangProject)
	End Sub
	
	Public Sub LoadFromRegistry()
        sServer.Text = GetSetting("Fieldworks", "DataSource", "Server", "(local)")
		SDB.Text = GetSetting("Fieldworks", "DataSource", "Database", "TestLangProj")
		sLangProject = GetSetting("Fieldworks", "DataSource", "LanguageProject", "DEB-Debug")
	End Sub
	
	Public Function GotSource() As Boolean
		GotSource = (lstProjects.Items.Count > 0 And lstProjects.SelectedIndex > -1)
	End Function
	Public Function GetDataSourceXMLString() As String
		GetDataSourceXMLString = "<DataAccessSetup Server= '" & sServerPath & "'  DB= '" & SDB.Text & "' LangProj='" & LangProjID() & "'/>"
	End Function
	Public Function GetDataSourceString() As String
		GetDataSourceString = "Server= '" & sServerPath & "'  DB= '" & SDB.Text & "' LangProj=" & LangProjID()
	End Function
	Private Sub UpdateButtons()
		OKButton.Enabled = lstProjects.SelectedIndex > -1
        'VB6.SetDefault(OKButton, OKButton.Enabled)
	End Sub
End Class