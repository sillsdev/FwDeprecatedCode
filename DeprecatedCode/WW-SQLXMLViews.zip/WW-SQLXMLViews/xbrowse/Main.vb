Option Strict Off
Option Explicit On
Module MainMod
	Public fMainForm As frmMain
	
	
	Public Sub Main()
		fMainForm = New frmMain
		System.Windows.Forms.Application.Run(fMainForm)
	End Sub
End Module