Option Strict Off
Option Explicit On
Friend Class dlgListSetup
    Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
    Public Sub New()
        MyBase.New()
        If m_vb6FormDefInstance Is Nothing Then
            If m_InitializingDefInstance Then
                m_vb6FormDefInstance = Me
            Else
                Try
                    'For the start-up form, the first instance created is the default instance.
                    If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
                        m_vb6FormDefInstance = Me
                    End If
                Catch
                End Try
            End If
        End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents btnDefaults As System.Windows.Forms.Button
    Public WithEvents sItemQuery As System.Windows.Forms.TextBox
    Public WithEvents sListQuery As System.Windows.Forms.TextBox
    Public WithEvents CancelButton_Renamed As System.Windows.Forms.Button
    Public WithEvents OKButton As System.Windows.Forms.Button
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label1 As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(dlgListSetup))
        Me.components = New System.ComponentModel.Container()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
        Me.ToolTip1.Active = True
        Me.btnDefaults = New System.Windows.Forms.Button()
        Me.sItemQuery = New System.Windows.Forms.TextBox()
        Me.sListQuery = New System.Windows.Forms.TextBox()
        Me.CancelButton_Renamed = New System.Windows.Forms.Button()
        Me.OKButton = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Text = "Setup List..."
        Me.ClientSize = New System.Drawing.Size(421, 300)
        Me.Location = New System.Drawing.Point(184, 250)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.ShowInTaskbar = False
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ControlBox = True
        Me.Enabled = True
        Me.KeyPreview = False
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.HelpButton = False
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal
        Me.Name = "dlgListSetup"
        Me.btnDefaults.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnDefaults.Text = "Restore Defaults"
        Me.btnDefaults.Size = New System.Drawing.Size(129, 25)
        Me.btnDefaults.Location = New System.Drawing.Point(16, 264)
        Me.btnDefaults.TabIndex = 7
        Me.btnDefaults.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDefaults.BackColor = System.Drawing.SystemColors.Control
        Me.btnDefaults.CausesValidation = True
        Me.btnDefaults.Enabled = True
        Me.btnDefaults.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDefaults.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnDefaults.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnDefaults.TabStop = True
        Me.btnDefaults.Name = "btnDefaults"
        Me.sItemQuery.AutoSize = False
        Me.sItemQuery.Size = New System.Drawing.Size(337, 25)
        Me.sItemQuery.Location = New System.Drawing.Point(48, 216)
        Me.sItemQuery.TabIndex = 3
        Me.sItemQuery.Text = "sItemQuery"
        Me.sItemQuery.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sItemQuery.AcceptsReturn = True
        Me.sItemQuery.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.sItemQuery.BackColor = System.Drawing.SystemColors.Window
        Me.sItemQuery.CausesValidation = True
        Me.sItemQuery.Enabled = True
        Me.sItemQuery.ForeColor = System.Drawing.SystemColors.WindowText
        Me.sItemQuery.HideSelection = True
        Me.sItemQuery.ReadOnly = False
        Me.sItemQuery.MaxLength = 0
        Me.sItemQuery.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.sItemQuery.Multiline = False
        Me.sItemQuery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.sItemQuery.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.sItemQuery.TabStop = True
        Me.sItemQuery.Visible = True
        Me.sItemQuery.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.sItemQuery.Name = "sItemQuery"
        Me.sListQuery.AutoSize = False
        Me.sListQuery.Size = New System.Drawing.Size(337, 73)
        Me.sListQuery.Location = New System.Drawing.Point(48, 40)
        Me.sListQuery.TabIndex = 2
        Me.sListQuery.Text = "sListQuery"
        Me.sListQuery.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sListQuery.AcceptsReturn = True
        Me.sListQuery.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.sListQuery.BackColor = System.Drawing.SystemColors.Window
        Me.sListQuery.CausesValidation = True
        Me.sListQuery.Enabled = True
        Me.sListQuery.ForeColor = System.Drawing.SystemColors.WindowText
        Me.sListQuery.HideSelection = True
        Me.sListQuery.ReadOnly = False
        Me.sListQuery.MaxLength = 0
        Me.sListQuery.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.sListQuery.Multiline = False
        Me.sListQuery.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.sListQuery.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.sListQuery.TabStop = True
        Me.sListQuery.Visible = True
        Me.sListQuery.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.sListQuery.Name = "sListQuery"
        Me.CancelButton_Renamed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CancelButton = Me.CancelButton_Renamed
        Me.CancelButton_Renamed.Text = "&Cancel"
        Me.CancelButton_Renamed.Size = New System.Drawing.Size(81, 25)
        Me.CancelButton_Renamed.Location = New System.Drawing.Point(304, 264)
        Me.CancelButton_Renamed.TabIndex = 1
        Me.CancelButton_Renamed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CancelButton_Renamed.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton_Renamed.CausesValidation = True
        Me.CancelButton_Renamed.Enabled = True
        Me.CancelButton_Renamed.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CancelButton_Renamed.Cursor = System.Windows.Forms.Cursors.Default
        Me.CancelButton_Renamed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CancelButton_Renamed.TabStop = True
        Me.CancelButton_Renamed.Name = "CancelButton_Renamed"
        Me.OKButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.OKButton.Text = "&OK"
        Me.AcceptButton = Me.OKButton
        Me.OKButton.Size = New System.Drawing.Size(81, 25)
        Me.OKButton.Location = New System.Drawing.Point(208, 264)
        Me.OKButton.TabIndex = 0
        Me.OKButton.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OKButton.BackColor = System.Drawing.SystemColors.Control
        Me.OKButton.CausesValidation = True
        Me.OKButton.Enabled = True
        Me.OKButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OKButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.OKButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OKButton.TabStop = True
        Me.OKButton.Name = "OKButton"
        Me.Label3.Text = "(READUNCOMMITTED) is automatically appended to the sql query."
        Me.Label3.Size = New System.Drawing.Size(329, 17)
        Me.Label3.Location = New System.Drawing.Point(48, 128)
        Me.Label3.TabIndex = 6
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Enabled = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.UseMnemonic = True
        Me.Label3.Visible = True
        Me.Label3.AutoSize = False
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Label3.Name = "Label3"
        Me.Label2.Text = "XPath Query using column one in place of $id (e.g. Wordform[@Id=""$id""] )."
        Me.Label2.Size = New System.Drawing.Size(425, 25)
        Me.Label2.Location = New System.Drawing.Point(8, 192)
        Me.Label2.TabIndex = 5
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Enabled = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.UseMnemonic = True
        Me.Label2.Visible = True
        Me.Label2.AutoSize = False
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Label2.Name = "Label2"
        Me.Label1.Text = "Sql Query.  First column must be an id string, second column must be a label string."
        Me.Label1.Size = New System.Drawing.Size(409, 17)
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.TabIndex = 4
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Enabled = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.UseMnemonic = True
        Me.Label1.Visible = True
        Me.Label1.AutoSize = False
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Label1.Name = "Label1"
        Me.Controls.Add(btnDefaults)
        Me.Controls.Add(sItemQuery)
        Me.Controls.Add(sListQuery)
        Me.Controls.Add(CancelButton_Renamed)
        Me.Controls.Add(OKButton)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Label1)
    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As dlgListSetup
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As dlgListSetup
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New dlgListSetup()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set(ByVal Value As dlgListSetup)
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region
    Public bDidOK As Boolean
    Public Shared s_DefaultItemQry As String = "WfiWordform[@Id='$id']"
    Public Shared s_DefaultListQry As String = "select  Obj, Txt from WfiWordform_form"

    Public Sub FillInBlanks()
        If sListQuery.Text = "" Then btnDefaults_Click(btnDefaults, New System.EventArgs())
    End Sub
    Private Sub btnDefaults_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles btnDefaults.Click
        sListQuery.Text = s_DefaultListQry
        sItemQuery.Text = s_DefaultItemQry
    End Sub




    Private Sub CancelButton_Renamed_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CancelButton_Renamed.Click
        Me.Hide()
    End Sub

    Private Sub dlgListSetup_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        bDidOK = False
        If sListQuery.Text = "" Then
            btnDefaults_Click(btnDefaults, New System.EventArgs())
        End If
    End Sub

    Private Sub OKButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles OKButton.Click
        bDidOK = True
        Me.Hide()
    End Sub
End Class