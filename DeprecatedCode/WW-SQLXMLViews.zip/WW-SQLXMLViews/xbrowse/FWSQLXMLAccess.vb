Option Strict Off
Option Explicit On
Module FWSQLXMLAccess
	
	Const kDialectForTemplateCmd As String = "{5d531cb2-e6ed-11d2-b252-00c04f681b71}"
	Const kDialectForXPathCmd As String = "{ec2a4293-e898-11d2-b1b7-00c04f680c56}"
	Public glExecuteQueryTime As Integer
	Private Declare Function GetTickCount Lib "kernel32" () As Integer
	
	
	Public Function QueryDBToHTML(ByRef adoConn As ADODB.Connection, ByVal sMappingSchemaPath As String, ByVal sXMLQuery As String, ByVal sXSLTViewPath As String, ByRef sInOutHTMLPath As String, ByVal bDontCache As Boolean) As Boolean
		
		Dim strm As ADODB.Stream
		
		On Error GoTo CatchError
		strm = QueryDBToStream(adoConn, sMappingSchemaPath, sXMLQuery, bDontCache)
		
		Dim dom As MSXML2.DOMDocument30
		dom = StreamToDOM(strm)
		
		'UPGRADE_NOTE: Object strm may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup1029"'
		strm = Nothing
		QueryDBToHTML = DOMToHTML(dom, sXSLTViewPath, sInOutHTMLPath)
		
		'UPGRADE_NOTE: Object dom may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup1029"'
		dom = Nothing
		Exit Function
		
CatchError: 
		Dim fs As New Scripting.FileSystemObject
		sInOutHTMLPath = fs.GetSpecialFolder(2).Path & "/xbrowse_error.txt" 'temp folder
		Dim fOut As Scripting.TextStream
		fOut = fs.CreateTextFile(sInOutHTMLPath)
		fOut.WriteLine(Err.Source)
		fOut.WriteLine(Err.Description)
		fOut.Close()
		QueryDBToHTML = False
	End Function
	
	
	'On input, if sInOutHTMLPath is empty, then the file will be stored in a temporary directory.
	'Otherwise, the HTML file will be stored in a given location.
	Public Function DOMToHTML(ByRef dom As MSXML2.DOMDocument30, ByRef sXSLTPath As String, ByRef sInOutHTMLPath As String) As Boolean
		Dim fs As New Scripting.FileSystemObject
		
		Dim styleSheet As New MSXML2.FreeThreadedDOMDocument30
		Dim t As New MSXML2.XSLTemplate30
		Dim xslproc As MSXML2.IXSLProcessor
		Dim strm As New ADODB.Stream ' DOMDocument30
		If sXSLTPath = "Raw XML" Then
			If sInOutHTMLPath = "" Then
				sInOutHTMLPath = fs.GetSpecialFolder(2).Path & "\xbrowse_TempOutput.xml"
			End If
			dom.Save(sInOutHTMLPath)
		Else
			If sInOutHTMLPath = "" Then
				sInOutHTMLPath = fs.GetSpecialFolder(2).Path & "\xbrowse_TempOutput.htm"
			End If
			'load in the style sheet
			
			styleSheet.async = False
			styleSheet.Load(sXSLTPath)
			If styleSheet.parseError.errorCode <> 0 Then
				MsgBox(styleSheet.parseError.reason)
				Exit Function
			End If
			
			'create an XSLT processor
			
			t.styleSheet = styleSheet
			xslproc = t.createProcessor
			xslproc.input = dom
			'Dim domOutput As New DOMDocument  'MSXML2.DOMDocument30
			
			' process the wfi
			'xslproc.output = domOutput  '!!!!!this could be faster by giving it a stream obj and saving to a file, saving a parse
			
			
			'    domOutput.Save sInOutHTMLPath
			strm.Open()
			xslproc.output = strm
			xslproc.Transform()
			strm.Position = 0
			strm.SaveToFile(sInOutHTMLPath, ADODB.SaveOptionsEnum.adSaveCreateOverWrite)
		End If
		DOMToHTML = True
	End Function
	
	Public Function StreamToDOM(ByRef streamXML As ADODB.Stream) As MSXML2.DOMDocument30
		'   Assign the stream's output to the temp string to format.
		streamXML.Position = 0
		streamXML.Charset = "utf-8"
		
		Dim sXML As String
		sXML = "<root> " & streamXML.ReadText(-1) & "</root>"
		
		Dim dom As MSXML2.DOMDocument30
		dom = New MSXML2.DOMDocument30
		dom.loadXML(sXML)
		
		StreamToDOM = dom
	End Function
	
	Public Function QueryDBToStream(ByRef adoConn As ADODB.Connection, ByVal sMappingSchemaPath As String, ByVal sXMLQuery As String, ByVal bDontCache As Boolean) As ADODB.Stream
		Const STREAM_FLAGS_DONTCACHEMAPPINGSCHEMA As Short = 8
		Const STREAM_FLAGS_DONTCACHETEMPLATE As Short = 16
		Const STREAM_FLAGS_DONTCACHEXSL As Short = 32
		
		Dim strm As New ADODB.Stream
		Dim cmd As New ADODB.Command
		
		cmd.let_ActiveConnection(adoConn) ' oTestConnection
		cmd.Properties("ClientSideXML").Value = "False"
		
		
		Dim f As New Scripting.FileSystemObject
		cmd.Properties("Mapping Schema").Value = f.GetBaseName(sMappingSchemaPath) & "." & f.GetExtensionName(sMappingSchemaPath)
		
		
		strm.Open()
		
		Dim fTemplate As Scripting.TextStream
		If InStr(1, sXMLQuery, ".xml") > 0 Then
			cmd.Dialect = kDialectForTemplateCmd
			fTemplate = f.OpenTextFile(sXMLQuery, Scripting.IOMode.ForReading)
			
			
			
			cmd.CommandText = fTemplate.ReadAll
			
			' cmd.CommandText = "<ROOT xmlns:sql='urn:schemas-microsoft-com:xml-sql'> " & _
			''       " <sql:xpath-query mapping-schema='" & cmd.Properties("Mapping Schema").Value & "' > " & _
			''      "   MoMorphType " & _
			''     "   </sql:xpath-query> " & _
			''    " </ROOT> "
			
		Else
			cmd.CommandText = sXMLQuery ' an xpath
			cmd.Dialect = kDialectForXPathCmd
		End If
		
		'UPGRADE_WARNING: Couldn't resolve default property of object strm. Click for more: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="vbup1037"'
		cmd.Properties("Output Stream").Value = strm
		
		cmd.Properties("Base Path").Value = f.GetParentFolderName(sMappingSchemaPath) '"E:\dev\ww\code\ww xml Query Tester\xdr schemas\"
		cmd.Properties("Mapping Schema").Value = f.GetBaseName(sMappingSchemaPath) & "." & f.GetExtensionName(sMappingSchemaPath)
		cmd.Properties("Output Encoding").Value = "utf-8"
		If bDontCache Then 'this is helpful during development of map or xslt
			cmd.Properties("ss Stream Flags").Value = STREAM_FLAGS_DONTCACHEMAPPINGSCHEMA + STREAM_FLAGS_DONTCACHETEMPLATE + STREAM_FLAGS_DONTCACHEXSL
		Else
			cmd.Properties("ss Stream Flags").Value = 0
		End If
		
		glExecuteQueryTime = GetTickCount
		cmd.Execute( ,  , ADODB.ExecuteOptionEnum.adExecuteStream)
		
		glExecuteQueryTime = GetTickCount - glExecuteQueryTime
		
		
		QueryDBToStream = strm
		Exit Function
	End Function
End Module