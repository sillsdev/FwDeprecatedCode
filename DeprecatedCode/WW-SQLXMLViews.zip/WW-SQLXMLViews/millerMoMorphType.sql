��if object_id('Manna') is not null begin
	print 'removing proc Manna'
	drop proc [Manna]
end
go
print 'creating proc Manna'
go
create proc [Manna]
	--( If parameters, like this:
	--(    @param1 int,
	--(    @prama2 int
as
	
	--( Query here, like so:

	select 1 as TAG,0 as parent,_Q48.A143 as [MoMorphType!1!Id!id],_Q48.A144 as [MoMorphType!1!Postfix],_Q48.A145 as [MoMorphType!1!Prefix],_Q48.A146 as [MoMorphType!1!SecondaryOrder],_Q48._TBCIKBGMJEA as [MoMorphType!1!id!hide],NULL as [CmPossibility!2!Id!id],NULL as [CmPossibility!2!id!hide],NULL as [CmPossibility_Name!3!ws],NULL as [CmPossibility_Name!3!txt],NULL as [CmPossibility_SubPossibilities!4!dst],NULL as [CmPossibility_SubPossibilities!4!ord] from (select _QB0.Id AS A143,_QB0.Postfix AS A144,_QB0.Prefix AS A145,_QB0.SecondaryOrder AS A146,_QB0.id AS _TBCIKBGMJEA,_QB0.SecondaryOrder AS _TBCAHLEHHCA,_QB0.Prefix AS _TBCIDIPGICA,_QB0.Postfix AS _TBCAAINJHCA,_QB0.Id AS _TBCIOIPGICA from MoMorphType _QB0) _Q48 union all select 2,1,NULL,NULL,NULL,NULL,_Q48._TBCIKBGMJEA,_Q49.A1752,_Q49._TFAFIKBGMJEA,NULL,NULL,NULL,NULL from (select _QB0.Id AS A1752,_QB0.id AS _TFAFIKBGMJEA,_QB0.Id AS _TFAFIOIPGICA from CmPossibility _QB0) _Q49,(select _QB0.Id AS A143,_QB0.Postfix AS A144,_QB0.Prefix AS A145,_QB0.SecondaryOrder AS A146,_QB0.id AS _TBCIKBGMJEA,_QB0.SecondaryOrder AS _TBCAHLEHHCA,_QB0.Prefix AS _TBCIDIPGICA,_QB0.Postfix AS _TBCAAINJHCA,_QB0.Id AS _TBCIOIPGICA from MoMorphType _QB0) _Q48 where _Q48._TBCIKBGMJEA=_Q49._TFAFIKBGMJEA union all select 3,2,NULL,NULL,NULL,NULL,_Q48._TBCIKBGMJEA,NULL,_Q49._TFAFIKBGMJEA,_Q50.A1753,_Q50.A1754,NULL,NULL from (select _QB0.ws AS A1753,_QB0.txt AS A1754,_QB0.txt AS _TGAFIMOPJHCA,_QB0.ws AS _TGAFAFIBJHCA,_QB0.obj AS _TGAFIPCPGICA from CmPossibility_Name _QB0) _Q50,(select _QB0.Id AS A1752,_QB0.id AS _TFAFIKBGMJEA,_QB0.Id AS _TFAFIOIPGICA from CmPossibility _QB0) _Q49,(select _QB0.Id AS A143,_QB0.Postfix AS A144,_QB0.Prefix AS A145,_QB0.SecondaryOrder AS A146,_QB0.id AS _TBCIKBGMJEA,_QB0.SecondaryOrder AS _TBCAHLEHHCA,_QB0.Prefix AS _TBCIDIPGICA,_QB0.Postfix AS _TBCAAINJHCA,_QB0.Id AS _TBCIOIPGICA from MoMorphType _QB0) _Q48 where _Q49._TFAFIKBGMJEA=_Q50._TGAFIPCPGICA and _Q48._TBCIKBGMJEA=_Q49._TFAFIKBGMJEA union all select 4,2,NULL,NULL,NULL,NULL,_Q48._TBCIKBGMJEA,NULL,_Q49._TFAFIKBGMJEA,NULL,NULL,_Q51.A1755,_Q51.A1756 from (select _QB0.dst AS A1755,_QB0.ord AS A1756,_QB0.ord AS _THAFICNFIHCA,_QB0.dst AS _THAFIOJJHHCA,_QB0.src AS _THAFINIPGICA from CmPossibility_SubPossibilities _QB0) _Q51,(select _QB0.Id AS A1752,_QB0.id AS _TFAFIKBGMJEA,_QB0.Id AS _TFAFIOIPGICA from CmPossibility _QB0) _Q49,(select _QB0.Id AS A143,_QB0.Postfix AS A144,_QB0.Prefix AS A145,_QB0.SecondaryOrder AS A146,_QB0.id AS _TBCIKBGMJEA,_QB0.SecondaryOrder AS _TBCAHLEHHCA,_QB0.Prefix AS _TBCIDIPGICA,_QB0.Postfix AS _TBCAAINJHCA,_QB0.Id AS _TBCIOIPGICA from MoMorphType _QB0) _Q48 where _Q49._TFAFIKBGMJEA=_Q51._THAFINIPGICA and _Q48._TBCIKBGMJEA=_Q49._TFAFIKBGMJEA order by 7,9,2 for xml explicit, binary base64

go
