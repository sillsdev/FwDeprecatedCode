// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2002, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: FxApp.cs
// Responsibility: 
// Last reviewed: 
// 
// <remarks>
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Win32;

using XCore;

namespace SIL.FieldWorks.XWorks.LexEd
{
	/// <summary>
	/// Summary description for LexApp.
	/// </summary>
	public class LexApp : FwXApp
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Application entry point. If LexApp isn't already running, an instance of the app is
		/// created.
		/// </summary>
		/// 
		/// <param name="rgArgs">Command-line arguments</param>
		/// 
		/// <returns>0</returns>
		/// -----------------------------------------------------------------------------------
		[STAThread]
		public static int Main(string[] rgArgs)
		{
			using(LexApp application = new LexApp(rgArgs))
			{
				application.Run();
			}
			return 0;
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="arguments">Command line arguments.</param>
		protected LexApp(string[] arguments) : base(arguments)
		{
		}

		/// <summary>
		/// needed for automated tests
		/// </summary>
		/// <param name="arguments"></param>
		public LexApp() : base()
		{
		}
	
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Guid for the application (used for uniquely identifying DB items that "belong" to
		///		this app.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public static Guid AppGuid
		{
			get
			{
				return new Guid("7418389E-F79B-4fdd-A654-56E6FBE12734");
			}
		}

		/// <summary>
		/// This application processes DB sync records.
		/// </summary>
		public override Guid SyncGuid
		{
			get { return AppGuid; }
		}

		public override string ProductName
		{
			get { return "Lexical Database Editor"; }
		}

		public override string DefaultConfigurationPathname
		{
			get { return @"LexEd\LexEd.xml"; }
		}

		/// <summary>
		/// Gets the registry settings key name for the application.
		/// </summary>
		/// <remarks>Subclasses should override this, or all its settings will go in "FwXapp".</remarks>
		protected override string SettingsKeyName
		{
			get { return "LexEd"; }
		}

		/// <summary>
		/// override this with the name of your icon
		/// This icon file should be included in the assembly, and its "build action" should be set to "embedded resource"
		/// </summary>
		protected override string ApplicationIconName
		{
			get { return "lexed.ico"; }
		}
	}
}

