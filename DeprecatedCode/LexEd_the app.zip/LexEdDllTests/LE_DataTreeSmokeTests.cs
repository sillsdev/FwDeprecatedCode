using System;
using NUnit.Framework;
using SIL.FieldWorks.Common.Framework.TreeForms;


namespace SIL.FieldWorks.XWorks.LexEd
{
	/// <summary>
	/// Summary description for LE_DataTreeSmokeTests.
	/// </summary>
	public class LE_DataTreeSmokeTests : SIL.FieldWorks.XWorks.DataTreeSmokeTests
	{
		public LE_DataTreeSmokeTests()
		{
		}

		protected override void Init()
		{
			m_application =new LexApp();
		}

		[Test]
		public void Smoke()
		{
			StandardViewTest();
		}

		//MoAffixForm.inflection classes are only relevant if the MSAs of the 
		// entry includes an inflectional affix MSA.
		[Test]
		public void MoAffixFormInflectionFieldVisibility ()
		{
			DataTree tree = DatTree;
			tree.GotoFirstSlice();
			if(tree.CurrentSlice.Expansion == DataTree.TreeItemState.ktisCollapsed)
				tree.CurrentSlice.Expand();

		}
	}
}
