// SCTextEnumEx.h : Declaration of the CSCTextEnumEx


#ifndef __SCTextEnumEx_H_
#define __SCTextEnumEx_H_

#include "resource.h"		    // main symbols
#include "SCScriptureText.h"	// MarkerInfo


/////////////////////////////////////////////////////////////////////////////
// CSCTextEnumEx
class ATL_NO_VTABLE CSCTextEnumEx : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSCTextEnumEx, &CLSID_SCTextEnumEx>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISCTextEnumEx, &IID_ISCTextEnumEx, &LIBID_TESOLib>,
	public CTraceCreation
{
public:
	CSCTextEnumEx(): CTraceCreation( "CSCTextEnumEx" )
	{
///		m_pstss = NULL;
///		m_MarkerTextProp = NULL;
		m_qstrText = NULL;
		m_qstrToken = NULL;
		m_strStream = NULL;
	}

	~CSCTextEnumEx()
	{
		if ( m_qstrText )
			delete [] m_qstrText;

		if ( m_qstrToken )
			delete [] m_qstrToken;

	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCTEXTENUMEX)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSCTextEnumEx)
	COM_INTERFACE_ENTRY(ISCTextEnumEx)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISCTextEnumEx
public:
	STDMETHOD(NextToken)(
		/*[out]*/ int *piTagIndex, 
		/*[out,retval]*/ BSTR *pbstr);

	STDMETHOD(Next)(
//		/*[out]*/ int *piTagIndex, 
		/*[out]*/ BSTR *pbstr,
		/*[out]*/ ISCReference** pSCReference,
		/*[out]*/ BSTR *pxbstr );

///	STDMETHOD(SetText)(
///			/*[in]*/ BSTR bstrText, 
///			/*[in]*/ ISCScriptureText *pscr,
///			/*[in]*/ BSTR bstrComment);
	
	void FinalRelease();
///	void Init( BSTR inText );
	void AddTextMarkerProps( std::map<_TSTRING, MarkerInfo> m_MarkerTextProp );

	void AddMarkerAndConverter( _TSTRING marker, CTKAndCodePageWrapper* converter );
	void SetText( char* text, BSTR bstrComment );	// comment has to come from the Scripture TExt obj...


//	CComBSTR bstrBaseGetNextToken(ScrTokenType& tt, bool bAsteriskIsMarker);
	char *strBaseGetNextToken(ScrTokenType& tt, bool bAsteriskIsMarker, bool & bLastWasChapOrVerseNumber);

	CComPtr<ISCScriptureText> m_qScriptureText;
		// We directly set this from SCScriptureText - so it is public

private:
	std::map<_TSTRING, MarkerInfo> m_MarkerTextProp;	// passed from the ScriptureText map of same name and info...
//	MarkerInfo	GetMarkerProps( _TSTRING key );

///	ScriptureTextSegmentStream * m_pstss;
///	ScriptureReference m_srfFirst;
///	ScriptureReference m_srfLast;
///	SCTextType m_sttFilter;
///	SCTextProperties m_stpSmushing;

///	ScriptureReference m_srfCur;
///	ScriptureTextSegment m_sts;
///	ScriptureTextSegment m_stsNext;
///	bool m_bFirst;
	    // Becomes false as soon as we have passed the milestone that defines
        // the start of the smushing unit we are using.  If not smushing
        // this becomes false as soon as we see the first segment.  This allows
        // us to avoid stopping the process when we hit the first smushing boundary
		// because we want to continue until we see the second one.
///	bool m_bGotNextSegmentAlready;
///	bool m_fUpdateable;
		// True if the user is allowed to update the original text by
		// making an assignement to the Text property.

//	CComBSTR m_qbstrText;
//	CComBSTR m_qbstrToken;
	char*	m_qstrText;
	char*	m_qstrToken;
	char*	m_strStream;	
//	wchar_t m_wchComment;
	char	m_chComment;
//	BSTR m_bstrStream;

	TMapIDToConverter	m_ConverterMap;

};

#endif //__SCTextEnumEx_H_
