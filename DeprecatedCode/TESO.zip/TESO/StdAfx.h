// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__834609A3_B1E8_11D2_97E6_0020182BE646__INCLUDED_)
#define AFX_STDAFX_H__834609A3_B1E8_11D2_97E6_0020182BE646__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define STRICT
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0400
#endif
#define _ATL_APARTMENT_THREADED

#include <atlbase.h>
//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module
extern CComModule _Module;
#include <atlcom.h>

//+ESCES

#include "ccdll.h"

// -------------------------------------------------------------------
//	Interface headers
// -------------------------------------------------------------------
//#include "ScriptureObjects.h"	// ScriptureObjects.dll types
#include "TESO.h"				// TESO.dll types
// -------------------------------------------------------------------


//#import "c:\dev\fw\distfiles\scriptureobjects.dll" include("SCTextType") 
#include "esces.h"
#include "srftok.h"
#include "srflib.h"
#include <ocidl.h>	// Added by ClassView

#include <sstream>

#include "ScriptureTextSegment.h"
#include "ScriptureRawTextStream.h"
#include "ScriptureTextSegmentStream.h"
#include "SCScriptureText.h"
#include "RangeToFile.h"
//moved up #include "SCScriptureText.h"
#include "xmlparse.h"
#include "CExPat.h"
#include "CXMLDataRec.h"

void bTrimWSEnds(_TSTRING& s);

void SetReference(ISCReference *pRef, ScriptureReference srf);
char* MySettingsDirectory(void);

char* RunCC(HANDLE h, char* pszIn);

// Warning: The following slow things down a lot,
// and are includede in release versions.

//#define EXTENSIVE_DEBUGGING 1

#ifdef EXTENSIVE_DEBUGGING
#define DD(x) x
#define DD1(x, y) ATLTRACE(x, y)
#else
#define DD(x)
#define DD1(x,y)
#endif



void DumpMarkerInfo(char* hdg, MarkerInfo& mi);


#define PROTECTION_BEGIN try {

#define PROTECTION_END } catch (...) { return(E_UNEXPECTED); }





//-ESCES

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__834609A3_B1E8_11D2_97E6_0020182BE646__INCLUDED)
