#include "stdafx.h"

namespace StrUtil
{
	extern void InitIcuDataDir();	// ICU functions are used by Utf8NumberToInt.
};
extern int Utf8NumberToInt(const char * pch, int cch);


// constructor
RangeToFile::RangeToFile()
	: m_cbstrFileName(CComBSTR())
{
	m_writeTime.dwLowDateTime = 0;
	m_writeTime.dwHighDateTime = 0;
	m_iChapterOffsetStatus = notDone;
	StrUtil::InitIcuDataDir();
}

// destructor
RangeToFile::~RangeToFile()
{
}

bool RangeToFile::FileChanged(void)
{
	BY_HANDLE_FILE_INFORMATION fileData;
	HANDLE hFile;

	USES_CONVERSION;

	hFile = CreateFile(OLE2A(m_cbstrFileName),  
					GENERIC_READ,              // open for reading 
					FILE_SHARE_READ,           // share for reading 
					NULL,                      // no security 
					OPEN_EXISTING,             // existing file only 
					FILE_ATTRIBUTE_NORMAL,     // normal file 
					NULL);                     // no attr. template 
 
	if (hFile == INVALID_HANDLE_VALUE) {
		int lastError = GetLastError();
		return true;
	}

	if (! GetFileInformationByHandle(hFile, &fileData)) {
		CloseHandle(hFile); 
		return true;
	}

	CloseHandle(hFile); 

	if (m_writeTime.dwLowDateTime != fileData.ftLastWriteTime.dwLowDateTime ||
			m_writeTime.dwHighDateTime != fileData.ftLastWriteTime.dwHighDateTime) {
		m_writeTime.dwLowDateTime = fileData.ftLastWriteTime.dwLowDateTime;
		m_writeTime.dwHighDateTime = fileData.ftLastWriteTime.dwHighDateTime;
		return true;
	}

	return false;
}


int RangeToFile::iSize(void)
{
	BY_HANDLE_FILE_INFORMATION fileData;
	HANDLE hFile;

	USES_CONVERSION;

	hFile = CreateFile(OLE2A(m_cbstrFileName),  
					GENERIC_READ,              // open for reading 
					FILE_SHARE_READ,           // share for reading 
					NULL,                      // no security 
					OPEN_EXISTING,             // existing file only 
					FILE_ATTRIBUTE_NORMAL,     // normal file 
					NULL);                     // no attr. template 
 
	if (hFile == INVALID_HANDLE_VALUE) 
		return 0;

	if (! GetFileInformationByHandle(hFile, &fileData)) {
		CloseHandle(hFile); 
		return 0;
	}

	CloseHandle(hFile); 

	return (int)fileData.nFileSizeLow;
}


char* RangeToFile::ChapterError(void)
{
	static char errMsg[128];

	strcpy(errMsg, "NO ERROR");

	if (m_iChapterOffsetStatus == duplicate)
		sprintf(errMsg, "Duplicate chapter number (%d)", m_iBadChapter);

	else if (m_iChapterOffsetStatus == outOfOrder)
		sprintf(errMsg, "Out of order chapter number (%d)", m_iBadChapter);

	else if (m_iChapterOffsetStatus < 0)
		sprintf(errMsg, "Could not find chapter (%d)", m_iBadChapter);

	return errMsg;
}


char* RangeToFile::Read(int iOffset, int iLen, char* outBuf)
{
	ifstream srts;

	ATLTRACE(" Read Offset:%6d  Length:%6d\n", iOffset, iLen );

	USES_CONVERSION;
	srts.open(OLE2A(m_cbstrFileName), ios::binary | ios::in  );
	if (!srts.is_open()) 
		return NULL;

	char* p = outBuf;
	*p = 0;

	if (iLen > 0) {
		srts.seekg(iOffset);
		srts.read( p, iLen);
		if (srts.fail()) {
			delete[] p;
			srts.close();
			return NULL;
		}
		p[iLen] = 0;
	}
	srts.close();

	return p;
}


char* RangeToFile::Read(int iOffset, int iLen)
{
	ifstream srts;

	USES_CONVERSION;
	srts.open(OLE2A(m_cbstrFileName), ios::binary | ios::in  );
	if (!srts.is_open()) 
		return NULL;

	char* p = new char[iLen+1];
	*p = 0;

	if (iLen > 0) {
		srts.seekg(iOffset);
		srts.read( p, iLen);
		if (srts.fail()) {
			delete[] p;
			srts.close();
			return NULL;
		}
		p[iLen] = 0;
	}
	srts.close();

	return p;
}

T_LPVI RangeToFile::GetChaptersForBook( int iBook )
{
	T_MI::iterator mi = m_miBookChapterOffset.find( iBook );
	if ( mi == m_miBookChapterOffset.end() )
		return NULL;
	return mi->second;
}


int RangeToFile::iChapterOffset(int iChapter)
{
	if (FileChanged())
		m_iChapterOffsetStatus = BuildViChapterOffset(); 
			// Build offsets to start of chapters.

	if (m_iChapterOffsetStatus != allOk)
		return m_iChapterOffsetStatus;

	if (iChapter == 0 || iChapter == 1)
		return 0;

	if ((unsigned int)iChapter > m_viChapterOffset.size()) {
		m_iBadChapter = iChapter;
		return notFound;
	}

	int iOffset = m_viChapterOffset[iChapter-1];
	if (iOffset == notFound)
		m_iBadChapter = iChapter;

	return iOffset;
}


int RangeToFile::iBookChapterOffset(int iBook, int iChapter)
{
	if (FileChanged())
		m_iChapterOffsetStatus = BuildViChapterOffset(); 
			// Build offsets to start of chapters.

	if (m_iChapterOffsetStatus != allOk)
		return m_iChapterOffsetStatus;

	// get the chapter offsets for this book
	T_LPVI chapters = GetChaptersForBook( iBook );
	if ( !chapters )
	{
		m_iBadBook = iBook;
		m_iBadChapter = 0;
		return notFound;
	}
	
	if ( (unsigned int)iChapter > chapters->size() )
	{
		m_iBadBook = iBook;
		m_iBadChapter = iChapter;
		return notFound;
	}

	int iOffset = chapters->at(iChapter-1);	// allow zero as start of book DIFFERENT FROM PREVIOUS BEHAVIOUR
	if ( iOffset == notFound )
	{
		m_iBadBook = iBook;
		m_iBadChapter = iChapter;
		return notFound;
	}

	return iOffset;
}


int RangeToFile::iBookChapterEndOffset(int iBook, int iChapter)
{
	if (FileChanged())
		m_iChapterOffsetStatus = BuildViChapterOffset(); 
			// Build offsets to start of chapters.

	if (m_iChapterOffsetStatus == duplicate || m_iChapterOffsetStatus == outOfOrder)
		return m_iChapterOffsetStatus;

	// get the chapter offsets for this book
	T_LPVI chapters = GetChaptersForBook( iBook );
	if ( !chapters )
	{
		m_iBadBook = iBook;
		m_iBadChapter = 0;
		return notFound;
	}

	// Find the start of the following chapter.
	// If not found, assume the chapter ends at the end of the file.
	int rval = iSize();
	if ( (unsigned int)iChapter < chapters->size() )
		rval = chapters->at( iChapter );

	return rval;
}


int RangeToFile::iChapterEndOffset(int iChapter)
{
	if (FileChanged())
		m_iChapterOffsetStatus = BuildViChapterOffset(); 
			// Build offsets to start of chapters.

	if (m_iChapterOffsetStatus == duplicate || m_iChapterOffsetStatus == outOfOrder)
		return m_iChapterOffsetStatus;

	// Find the start of the following chapter.
	// If not found, assume the chapter ends at the end of the file.
	for (unsigned int i=iChapter; i<m_viChapterOffset.size(); ++i) {
		if (m_viChapterOffset[i] >= 0) {
			return m_viChapterOffset[i];
		}
	}

	return iSize();
}

int ConvertBookNameToValue( char* name )
{
	const char *ppszBookNamesx[] = {"", 
	"GEN","EXO","LEV","NUM","DEU","JOS","JDG","RUT","1SA","2SA",
	"1KI","2KI","1CH","2CH","EZR","NEH","EST","JOB","PSA","PRO",
	"ECC","SNG","ISA","JER","LAM","EZK","DAN","HOS","JOL","AMO",
	"OBA","JON","MIC","NAM","HAB","ZEP","HAG","ZEC","MAL","MAT",
	"MRK","LUK","JHN","ACT","ROM","1CO","2CO","GAL","EPH","PHP",
	"COL","1TH","2TH","1TI","2TI","TIT","PHM","HEB","JAS","1PE",
	"2PE","1JN","2JN","3JN","JUD","REV","TOB","JDT","ESG","WIS",
	"SIR","BAR","LJE","S3Y","SUS","BEL","1MA","2MA","3MA","4MA",
	"1ES","2ES","MAN","PS2","ODA","PSS","JSA","JDB","TBS","SST",
	"DNT","BLT","XXA","XXB","XXC","XXD","XXE","XXF","XXG",
	"" };

	int rval = -1;
	for ( int i=1; i<100; i++ )
		if ( strcmp( name, ppszBookNamesx[i] ) == 0 )
			return i;

	return rval;
}


// Construct the vector which gives the offset to the beginning of each
// chapter in the file.
ChapterStatus RangeToFile::BuildViChapterOffset(void)
{
	ifstream ifs;
	ChapterStatus iErrorLevel = allOk;
	HANDLE hFile;
	BY_HANDLE_FILE_INFORMATION fileData;

	ATLTRACE("BuildViChapterOffset\n");

	USES_CONVERSION;

	hFile = CreateFile(OLE2A(m_cbstrFileName),  
					GENERIC_READ,              // open for reading 
					FILE_SHARE_READ,           // share for reading 
					NULL,                      // no security 
					OPEN_EXISTING,             // existing file only 
					FILE_ATTRIBUTE_NORMAL,     // normal file 
					NULL);                     // no attr. template 
 
	if (hFile == INVALID_HANDLE_VALUE) 
		return notFound;

	if (! GetFileInformationByHandle(hFile, &fileData)) {
		CloseHandle(hFile);
		return notFound;
	}

	int nFileSize = (int)fileData.nFileSizeLow;

	// If file is zero size then it clearly contains no chapter markers.
	if (nFileSize == 0) {
		CloseHandle(hFile);
		return allOk;
	}
	
	HANDLE hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
	if (hFileMapping == NULL) {
		CloseHandle(hFile);
		return notFound;
	}

	char* pFile = (char*)MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
	if (pFile == NULL) {
		CloseHandle(hFileMapping);
		CloseHandle(hFile);
		return notFound;
	}

	char* pEnd = pFile + nFileSize - 1;

	m_viChapterOffset.clear();

	iErrorLevel = ScanForChapterOffsets(m_viChapterOffset, pFile, pEnd, m_iBadChapter);

	UnmapViewOfFile(pFile);
	CloseHandle(hFileMapping);
	CloseHandle(hFile);

	return iErrorLevel;
}


ChapterStatus RangeToFile::ScanForChapterOffsets(vector<int>& viChapterOffset, char* pFile, char* pEnd, 
						  int& iBadChapter)
{
	ChapterStatus iErrorLevel = allOk;
	char *p;

	const char* pChapterMarker = m_sChapterMarker.c_str();
	int iChapterMarkerLen = strlen(pChapterMarker);
	
	for (p = pFile; p<pEnd; ++p) {
		if (p[0] != '\\') continue;
		if (strncmp(p+1, pChapterMarker, iChapterMarkerLen) != 0) continue;
		if (p[iChapterMarkerLen+1] != ' ') continue;

		int iOffset = p-pFile;

		p = p + (iChapterMarkerLen+2);
		for (; *p == ' '; ++p) {}
		// Handle vernacular chapter digits.
		int iChapter = Utf8NumberToInt(p, pEnd - p);
		if (iChapter > 0) {
			// By definition we start chapter 1 at the beginning of the file
			if (iChapter == 1)
				iOffset = 0;
			
			// Check for duplicate or out of order chapter numbers
			if (viChapterOffset.size() >= (unsigned int)iChapter) {
				if (viChapterOffset[iChapter-1] == (int)notFound) {
					viChapterOffset[iChapter-1] = (int)outOfOrder;
					if (iErrorLevel == allOk) {
						iErrorLevel = outOfOrder;
						iBadChapter = iChapter;
					}
				}
				else {
					viChapterOffset[iChapter-1] = (int)duplicate;
					iErrorLevel = duplicate;
					iBadChapter = iChapter;
				}
			}
			else {
				while (viChapterOffset.size()+1 < (unsigned int)iChapter) {
					viChapterOffset.push_back((int)notFound);
					//if (iErrorLevel == allOk)
					//	iErrorLevel = notFound;
				}

				ATLTRACE("Offset %d:%d\n", iChapter, iOffset);

				viChapterOffset.push_back(iOffset);
			}
		}
	}

	return iErrorLevel;
}

#if 0
// Add an offset for a chapter which must be greater than any existing
// chapter number in the file.  This will prevent the chapter offsets
// from being unnecessarily rescanned.

ChapterStatus RangeToFile::AddChapterOffset(int iChapter, int iOffset)
{
	//ATLTRACE("AddChapterOffset %d:%d size=%d\n", iChapter, iOffset, m_viChapterOffset.size());

	if (iChapter <= m_viChapterOffset.size())
		return duplicate;

	FileChanged(); // reset file changed flag

	while (m_viChapterOffset.size()+1 < iChapter) 
		m_viChapterOffset.push_back((int)notFound);

	m_viChapterOffset.push_back(iOffset);

	return allOk;
}
#endif


ChapterStatus RangeToFile::ReplaceChapterOffset(int iChapter, int iOffset, int iOldLen, int iNewLen)
{
	FileChanged(); // reset file changed flag

	while ((unsigned int)iChapter > m_viChapterOffset.size()) 
		m_viChapterOffset.push_back((int)notFound);

	m_viChapterOffset[iChapter-1] = iOffset;

	for (unsigned int i=iChapter; i < m_viChapterOffset.size(); ++i)
		if (m_viChapterOffset[i] > 0) 
			m_viChapterOffset[i] += (iNewLen - iOldLen);

	return allOk;
}

// Method to the the offset within a file of the passed in "ref".  This will
// also accumulate future information related to context: sections, paragraphs, ...
// This is a work in progress...
//
int	RangeToFile::GetOffset( ScriptureReference *ref, CSCScriptureText* scText, bool first/*=true*/, int startPos/*=0*/ )
{
	ATLTRACE("Get%sOffset of %s\n", first?"Start":"End", ref->sAsString().c_str() );

	int rval = -1;		// not found

//	long startOffset, endOffset;
	bool bFoundBook = false;
	bool bFoundChap = false;
	bool bFoundVerse= false;
	bool bFoundLastVerse = false;
	bool bOnlyOneBook = ( m_srfFirst.iBook() == m_srfLast.iBook() );

	bool done = false;
	long fPos = 0;
	ifstream InputFile;

	USES_CONVERSION;
	InputFile.open(OLE2A(this->m_cbstrFileName), ios::binary | ios::in  );
	if (!InputFile.is_open()) 
		return NULL;

	if ( startPos > 0 )					// start at given file offset
	{
		// also need to be passed the ref information: book, chapter, verse
		// this is needed so that the pointer knows where it is in the data
		//
		// InputFile.seekg( startPos );

	}

	_TSTRING sToken;
	ScrTokenType tt = text;
	
	while ( !done )
	{
		while (tt == text)
		{
			fPos = InputFile.tellg();
			if ( fPos > 43700 )
				int qwerwe = 1234;
///			ATLTRACE(" +++ File Pos = %d +++\n", fPos);
			sToken = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
///			sToken = this->  SFMScriptureTextSegmentStream::sGetNextToken(tt, '#');			// 10/16/02 trying...
		}
		
		if ( tt == unknowntt )
			break;

		CComBSTR qbstrToken = CComBSTR(sToken.c_str());
		int piTagIndex;
		if (tt == tag) 
		{
			HRESULT hr = scText->TagIndex((BSTR)qbstrToken, &piTagIndex);
			CComPtr<ISCTag> pTag;
			scText->NthTag( piTagIndex, &pTag );

			SCTextProperties props;
			pTag->get_TextProperties( &props );

			if ( bFoundLastVerse && ( props & (scBook | scChapter | scVerse) ) )
			{
				bFoundVerse = true;
			}
			else if ( props & scBook )
			{
				sToken = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
				sToken = sToken.substr(0,3);
				ATLTRACE("Found Book <%s>\n", sToken.c_str() );

				int foundBook = ref->iLookupBook( sToken.c_str() );
				if ( foundBook == ref->iBook() )
				{
//					ATLTRACE("Found the correct book<%d - %d>\n", foundBook , fPos);
					bFoundBook = true;

					/// dlh added 9/17/02
					if ( ref->iChapter() == 0 )	// start at begining of book
					{
						bFoundChap  = true;
						bFoundVerse = true;
					}
				}
				else
				{
					bFoundBook = false;
				}
			}
			else if ( (bOnlyOneBook || bFoundBook) && props & scChapter )
			{
				sToken = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
				ATLTRACE("Found Chapter %s\n", sToken.c_str() );

				int foundChap = Utf8NumberToInt(sToken.c_str(), strlen(sToken.c_str()));
				if ( foundChap == ref->iChapter() )
				{
//					ATLTRACE("Found the correct Chapter <%d> at %d\n", foundChap, fPos);
					bFoundChap = true;

					if ( ref->iVerse() == 0 && first)	// start at begining of chapter ONLY IF FIRST REF...
						bFoundVerse = true;
				}
				else
				{
					bFoundChap = false;
				}
			}
			else if ( (bOnlyOneBook || bFoundBook) && bFoundChap && props & scVerse )
			{
				ATLTRACE("Found Verse marker.\n" );
				sToken = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');

				ScriptureReference::FoundVerseRef match;
				match = ScriptureReference::ContainsVerse( sToken.c_str(), ref->iVerse() );

				if ( match == ScriptureReference::VR_ALL )
				{
					if ( !first )
						fPos = InputFile.tellg();	// use the end of the verse text as pos

//					ATLTRACE("Found the correct Verse<%d - %d>\n", ref->iVerse(), fPos);
					bFoundVerse = true;
				}
				else if ( match == ScriptureReference::VR_PORTION )
				{
//					ATLTRACE("Found the correct Verse<%d> pos -> %d\n", ref->iVerse(), fPos);
					bFoundVerse = true;
				}
				else if ( match == ScriptureReference::VR_SMALLER && ref->iVerse() == 0 )
				{
					bFoundVerse = true;
				}
				else
				{
					bFoundVerse = false;
				}

				// go to the end of the verse if last ref
				if ( bFoundVerse && !first )
				{
					bFoundLastVerse = true;
					bFoundVerse = false;
				}
				else if ( bFoundLastVerse )
				{
					int asdf = 12341234;
				}
			}

			if ( (bOnlyOneBook || bFoundBook) && bFoundChap && bFoundVerse )
			{
				done = true;
				ATLTRACE("Found Book, Chapter, Verse - offset %d\n", fPos );
//				rval = fPos;
				break;
			}
			tt = text;
		}
	}


	if ( !done )	// ref not found
	{
		ATLTRACE(" Get%sOffset of %s was not found in this reference (RTF).\n", first?"Start":"End", ref->sAsString().c_str() );
		ATLTRACE(" FoundBook = %c\n",	bFoundBook ?'T':'F' );
		ATLTRACE(" FoundChap = %c\n",	bFoundChap ?'T':'F' );
		ATLTRACE(" FoundVers = %c\n",	bFoundVerse?'T':'F' );
		return -1;
	}

	ATLTRACE("++++++++++++++++++++++++++++++++++++++++\n");
	ATLTRACE("+++ %d %5s: %6d\n", ref->iBBCCCVVV(), first?"Start":"End", fPos );
	ATLTRACE("++++++++++++++++++++++++++++++++++++++++\n");

	InputFile.close();



	return fPos;
}
