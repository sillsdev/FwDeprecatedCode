//-----------------------------------------------------
// ScriptureTextSegmentStream
//-----------------------------------------------------


// identifies a token returned as being either a tag or text (or unkown - only before first token read)
enum ScrTokenType {tag, text, unknowntt};

// Used to distinguish style types and to determine where embedding
// begins and ends.

enum ScriptureStyleType{ 
	characterstyle = 1,     // A string embedded in a note or pargraph
	notestyle = 2,          // A note embedded in a paragraph
	paragraphstyle = 3
	}; // hungarian: sst

class MarkerInfo;
#include "SCScriptureText.h"


//--------------------------------------------------------------
// This class has been added to pull out the verse handling code
// from the abstract class (ScriptureTextSegmentStream) so that 
// it can be used during checking.  Again: now we are using the 
// actual parsing code for checking.  Finding parsing errors
// before we enter the parsing phase was a primary goal.
//--------------------------------------------------------------
class ScriptureCheckHelper
{
public:
	ScriptureCheckHelper() {}
    // makes appropriate changes in references based on TokenStream 
    // (bridge, segments, etc.)
	void GetSRFNums(TokenStream &ts, ScriptureReference &srfFirst, ScriptureReference &srfLast, _TSTRING &tsVerseRef);

    // handles the segmentation incrementing for GetSRFNums
    void GetSRFSeg(TokenStream &ts, ScriptureReference &srf);
};

//--------------------------------------------------------------
//:> ScriptureTextSegmentStream
// An abstract class used to define a readable stream of
// ScriptureTextSegment's.  Has concrete subclasses for SFM
// based files and (maybe someday) XML based files
//--------------------------------------------------------------

class ScriptureTextSegmentStream : public ScriptureRawTextStream, public ScriptureCheckHelper
{
public:
	// used to bind text (perhaps the tag name) and its token type
	class TextAndTokenType { 
	public:
		TextAndTokenType(ScrTokenType tt, _TSTRING sText): 
				m_tt(tt), m_sText(sText) {;}
		TextAndTokenType(): 
				m_tt(unknowntt), m_sText(_TSTRING()) {;}

		ScrTokenType m_tt;
		_TSTRING m_sText; //hungarian: tatt
	};

	// @param srf Reference to start at.
	// @param mapMarkerTextProp Properties for each marker.
	// @param vTags All the SCTag tag definition objects for this text.
	// @param vecrtf Table mapping references to file names for this text/
	// @param iVersification Versification for this text, e.g. Vulgate.
	// @param hCCTable Compiled version of mapin.cct.
    ScriptureTextSegmentStream(
		ScriptureReference srf,
		map<_TSTRING, MarkerInfo>& mapMarkerTextProp,
		vector<CComPtr<ISCTag> >& vTags,
		vector<RangeToFile>& vecrtf,
		SCVersification iVersification,
		HANDLE hCCTable,
		bool fAsteriskIsMarker,
		bool bEatEscapeBackslashes = false
	);
    ~ScriptureTextSegmentStream(void);

    // signals end reached of all files in assocaited scr.
    const bool bEndOfStream();

	friend ScriptureTextSegment;

    // gets the next unfiltered, unsmushed "raw" segment and updates the current 
    // ScriptureRef.  srfCur = ScriptureReference::end if no next segment
    void stsGetNextRawSegment(ScriptureReference &srfCur, ScriptureTextSegment &sts);

    // the basic sGetNextToken for getting each tag or associated text: 
    // pure virtual function
    virtual _TSTRING sGetNextToken(ScrTokenType& tt, _TCHAR chCommentMarker=0, bool bAsteriskIsMarker=false)=0;

    //virtual _TSTRING sGetNextTokenAndTag(int *piTagIndex)=0;

//protected:
    // makes appropriate changes in references based on TokenStream 
    // (bridge, segments, etc.)
//    static void GetSRFNums(TokenStream &ts, ScriptureReference &srfFirst, ScriptureReference &srfLast, _TSTRING &tsVerseRef);

    // handles the segmentation incrementing for GetSRFNums
//    static void GetSRFSeg(TokenStream &ts, ScriptureReference &srf);

protected:
    virtual bool bNotHigherLevelStyle(ScriptureStyleType sstA, ScriptureStyleType sstB)=0;

    // keeps track of the current tag/text and associated tag-type
    TextAndTokenType m_tatt;

    // stack of currently active markers
    deque<MarkerInfo> m_miStack;

	// properties of each marker
	map<_TSTRING, MarkerInfo>& m_mapMarkerTextProp;

	// All the SCTag marker descriptions for this text
	vector<CComPtr<ISCTag> >& m_vTags;

	// Versification of this text
	SCVersification m_iVersification;

	// True if an asterisk all by itself is a marker.
	bool m_fAsteriskIsMarker;

	bool m_bEatEscapeBackslashes;	// comes from the project file
//	bool m_bLastCharWasNewLine;			// based on last data parsed

}; // hungarian: stss
    
int const BUFF_SIZE=100;


//--------------------------------------------------------------
//:> SFMScriptureTextSegmentStream
//     A concrete class used to define a readable stream of
//     scripture text segments from an SFM file.
//--------------------------------------------------------------

class SFMScriptureTextSegmentStream: public ScriptureTextSegmentStream
{    
public:
	// @param srf Reference to start at.
	// @param mapMarkerTextProp Properties for each marker.
	// @param vTags All the SCTag tag definition objects for this text.
	// @param vecrtf Table mapping references to file names for this text/
	// @param iVersification Versification for this text, e.g. Vulgate.
	// @param hCCTable Compiled version of mapin.cct.
    SFMScriptureTextSegmentStream(
		ScriptureReference srf,
		map<_TSTRING, MarkerInfo>& mapMarkerTextProp,
		vector<CComPtr<ISCTag> >& vTags,
		vector<RangeToFile>& vecrtf,
		SCVersification iVersification,
		HANDLE hCCTable,
		bool fAsteriskIsMarker,
		bool fEatEscapeBackslashes = false)
			:ScriptureTextSegmentStream(
				srf, mapMarkerTextProp, vTags, vecrtf, iVersification, hCCTable, fAsteriskIsMarker, fEatEscapeBackslashes) 
					{;}

	// Get text and type (marker or content string) of next token
	// from this ScriptureTextSegmentStream.
	// A token is either a marker or all the text between two markers.
	// Multiple whitespaces (including cr/lf) are collapsed into a single space.
	// @return Text of next token (either a marker or a content text string found).
    _TSTRING sGetNextToken(
        ScrTokenType& tt, 
        _TCHAR chCommentMarker=0, 
        bool bAsteriskIsMarker=false);

    // Extract the next token from the passed stream, but don't replace the newline with space - break instead
    static _TSTRING sBaseGetNextTokenToEndOfLine(
        ScrTokenType& tt, 
        istream& iInput, 
        _TCHAR chCommentMarker=0)
	{
		return sBaseGetNextToken(tt, iInput, chCommentMarker, false, false, true);	// defaults except last parm 
	}

    // Extract the next token from the passed stream.
    static _TSTRING sBaseGetNextToken(
        ScrTokenType& tt, 
        istream& iInput, 
        _TCHAR chCommentMarker=0, 
        bool bAsteriskIsMarker=false,
		bool bEatEscapeBackslashes=false,
		bool bEndOnEndOfLine=false);

    // Extract to the end of the line
    static _TSTRING sGetToEndOfLine( 
		istream& iInput, 
        _TCHAR chCommentMarker=0 );

    // For SFM files we must keep popping properties until we get back to
    // the same level of style type.
    bool bNotHigherLevelStyle(ScriptureStyleType sstA, ScriptureStyleType sstB) 
        { return sstA <= sstB; }
}; // hungarian: stss



#ifdef CAN_READ_XML_FILES
// This was a first attempt to read XML files.
// It is not in use and no doubt out of date.

//--------------------------------------------------------------
// XMLScriptureTextSegmentStream
//     A concrete class used to define a readable stream of
//     scripture text segments from an XML file.
//--------------------------------------------------------------

class XMLScriptureTextSegmentStream: public ScriptureTextSegmentStream{
public:
    class TokenData{
        friend XMLScriptureTextSegmentStream;
    public:
        TokenData(void): m_iErrLineNum(0) {;}

    private:
        int m_iErrLineNum;
        // when non-zero, an error has been found at the specified line number
        // by the parsing routines
        deque<TextAndTokenType> m_tattStack;
        // a deque of the tokens seen at a particular point
        _TSTRING m_sData;
        // all of the data we have seen so far for this tag
        _TSTRING m_sErrorMessage;
    }; // hungarian: td

    XMLScriptureTextSegmentStream(SCScriptureText *pscr, ScriptureReference srf);
    XMLScriptureTextSegmentStream(const XMLScriptureTextSegmentStream &xmlstss): ScriptureTextSegmentStream(xmlstss), m_td(xmlstss.m_td), m_parser(xmlstss.m_parser) {;}
    ~XMLScriptureTextSegmentStream(void){;}

    static void StartElement(void *pTokenData, const XML_Char *pszName, const XML_Char **ppcAtts);
        // pushes text and tag onto token stack

    static void EndElement(void *pTokenData, const XML_Char *pszName);
        // pushes text and tag onto token stack

    static void CharacterDataHandler(void *pTokenData, const XML_Char *psz, int iLen);
        // appends char to current text

    _TSTRING sGetNextToken(ScrTokenType& tt, _TCHAR chCommentMarker=0, 
                bool bAsteriskIsMarker=false);
        // fills virtual function in stss ensures deque is nonempty and gets first in

    bool bNotHigherLevelStyle(ScriptureStyleType sstA, ScriptureStyleType sstB) 
        { return false; }
        // In XML style properties are always determined by marker containment,
        // so the level does not matter.

private:    
    TokenData m_td;
        // user data for XML_parser (specifics above)

    XML_Parser m_parser;
        // XML parser used on file
};

#endif // CAN_READ_XML_FILES
