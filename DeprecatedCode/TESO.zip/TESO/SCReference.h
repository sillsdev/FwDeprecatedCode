// SCReference.h : Declaration of the CSCReference

//:> See ScriptureObjects.idl for interface information about this class

#ifndef __SCREFERENCE_H_
#define __SCREFERENCE_H_

#include "resource.h"       // main symbols

static bool m_fInitial = true;

/////////////////////////////////////////////////////////////////////////////
// CSCReference
class ATL_NO_VTABLE CSCReference : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSCReference, &CLSID_SCReference>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISCReference2, &IID_ISCReference2, &LIBID_TESOLib>
{

public:
	CSCReference()
	{
		m_cbstrErrMsg="";
		if (m_fInitial) {
			ATLTRACE("hi mom");
			ScriptureReference::ReadAllVersificationFiles(MySettingsDirectory());
			m_fInitial = false;
		}
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCREFERENCE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSCReference)
	COM_INTERFACE_ENTRY(ISCReference)
	COM_INTERFACE_ENTRY(ISCReference2)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

public:
// ISCReference2
	STDMETHOD(get_ErrorDataString)(/*[out,retval]*/BSTR* bstr);
	STDMETHOD(IsValidVerseNumberText)(
		/*[in]*/ VARIANT pSafeArrayOfBytes, 
		/*[out]*/ BOOL *isValid,
		/*[out]*/ int *numBytes,
		/*[out]*/ int *firstVerseNum,
		/*[out]*/ int *lastVerseNum
		);

	STDMETHOD(IsValidBookName)(
		/*[in]*/ VARIANT pSafeArrayOfBytes, 
		/*[out]*/ BOOL *isValid,
		/*[out]*/ int *numBytes);

// ISCReference
	STDMETHOD(SetToEnd)();
	STDMETHOD(get_BBCCCVVV)(/*[out, retval]*/ long *pVal);
	STDMETHOD(ChangeVersification)(/*[in]*/ SCVersification NewVersification);
	STDMETHOD(get_Valid)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(get_Versification)(/*[out, retval]*/ SCVersification *pVal);
	STDMETHOD(put_Versification)(/*[in]*/ SCVersification newVal);
	STDMETHOD(get_AsString)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_VersificationsPresent)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(PreviousVerse)();
	STDMETHOD(NextVerse)();
	STDMETHOD(Parse)(/*[in]*/ BSTR val);
	STDMETHOD(get_LastVerse)(/*[out, retval]*/ short *pVal);
	STDMETHOD(get_LastChapter)(/*[out, retval]*/ short *pVal);
	STDMETHOD(get_LastBook)(/*[out, retval]*/ short *pVal);
	STDMETHOD(get_Segment)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_Segment)(/*[in]*/ short newVal);
	STDMETHOD(get_Verse)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_Verse)(/*[in]*/ short newVal);
	STDMETHOD(get_Chapter)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_Chapter)(/*[in]*/ short newVal);
	STDMETHOD(get_Book)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_Book)(/*[in]*/ short newVal);

private:
	ScriptureReference m_srf;
	CComBSTR m_cbstrErrMsg;
};

#endif //__SCREFERENCE_H_
