// SCTag.cpp : Implementation of CSCTag
#include "stdafx.h"
#include "SCTag.h"

/////////////////////////////////////////////////////////////////////////////
// CSCTag

STDMETHODIMP CSCTag::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISCTag
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


STDMETHODIMP CSCTag::get_StyleType(SCStyleType *pVal)
{
	*pVal = m_iStyleType;
	return S_OK;
}

STDMETHODIMP CSCTag::put_StyleType(SCStyleType newVal)
{
	m_iStyleType = newVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_JustificationType(SCJustificationType *pVal)
{
	*pVal = m_iJustificationType;
	return S_OK;
}

STDMETHODIMP CSCTag::put_JustificationType(SCJustificationType newVal)
{
	m_iJustificationType = newVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_TextProperties(SCTextProperties *pVal)
{
	*pVal = m_stp;
	//ATLTRACE("get_TextProperties marker = /%S/ stp = %x\n", (BSTR)m_cbstrMarker, m_stp);
	return S_OK;
}

STDMETHODIMP CSCTag::put_TextProperties(SCTextProperties newVal)
{
	m_stp = newVal;
	//ATLTRACE("set_TextProperties marker = /%S/ stp = %x\n", (BSTR)m_cbstrMarker, m_stp);
	return S_OK;
}

STDMETHODIMP CSCTag::get_TextType(SCTextType *pVal)
{
	*pVal = m_stt;
	return S_OK;
}

STDMETHODIMP CSCTag::put_TextType(SCTextType newVal)
{
	m_stt = newVal;
	return S_OK;
}


// ----- string values -----

STDMETHODIMP CSCTag::get_Marker(BSTR *pbstr)
{
    *pbstr = m_cbstrMarker.Copy();
    return S_OK;
}

STDMETHODIMP CSCTag::put_Marker(BSTR bstrNewVal)
{
    m_cbstrMarker = bstrNewVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Endmarker(BSTR *pbstr)
{
    *pbstr = m_cbstrEndmarker.Copy();
    return S_OK;
}

STDMETHODIMP CSCTag::put_Endmarker(BSTR bstrNewVal)
{
    m_cbstrEndmarker = bstrNewVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Name(BSTR *pbstr)
{
    *pbstr = m_cbstrName.Copy();
    return S_OK;
}

STDMETHODIMP CSCTag::put_Name(BSTR bstrNewVal)
{
    m_cbstrName = bstrNewVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_TeStyleName(BSTR *pbstr)
{
    *pbstr = m_cbstrTeStyleName.Copy();
    return S_OK;
}

STDMETHODIMP CSCTag::put_TeStyleName(BSTR bstrNewVal)
{
    m_cbstrTeStyleName = bstrNewVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Description(BSTR *pbstr)
{
    *pbstr = m_cbstrDescription.Copy();
    return S_OK;
}

STDMETHODIMP CSCTag::put_Description(BSTR bstrNewVal)
{
    m_cbstrDescription = bstrNewVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Fontname(BSTR *pbstr)
{
    *pbstr = m_cbstrFontname.Copy();
    return S_OK;
}

STDMETHODIMP CSCTag::put_Fontname(BSTR bstrNewVal)
{
    m_cbstrFontname = bstrNewVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_OccursUnder(BSTR *pbstr)
{
    *pbstr = m_cbstrOccursUnder.Copy();
    return S_OK;
}

STDMETHODIMP CSCTag::put_OccursUnder(BSTR bstrNewVal)
{
    m_cbstrOccursUnder = bstrNewVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_XMLTag(BSTR *pbstr)
{
    *pbstr = m_cbstrXMLTag.Copy();
    return S_OK;
}

STDMETHODIMP CSCTag::put_XMLTag(BSTR bstrNewVal)
{
    m_cbstrXMLTag = bstrNewVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Encoding(BSTR *pbstr)
{
    *pbstr = m_cbstrEncoding.Copy();
    return S_OK;
}

STDMETHODIMP CSCTag::put_Encoding(BSTR bstrNewVal)
{
    m_cbstrEncoding = bstrNewVal;
	return S_OK;
}



// ----- integer values -----

STDMETHODIMP CSCTag::get_FontSize(int *piVal)
{
    *piVal = m_iFontSize;
    return S_OK;
}

STDMETHODIMP CSCTag::put_FontSize(int iVal)
{
    m_iFontSize = iVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_LineSpacing(int *piVal)
{
    *piVal = m_iLineSpacing;
    return S_OK;
}

STDMETHODIMP CSCTag::put_LineSpacing(int iVal)
{
    m_iLineSpacing = iVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_SpaceBefore(int *piVal)
{
    *piVal = m_iSpaceBefore;
    return S_OK;
}

STDMETHODIMP CSCTag::put_SpaceBefore(int iVal)
{
    m_iSpaceBefore = iVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_SpaceAfter(int *piVal)
{
    *piVal = m_iSpaceAfter;
    return S_OK;
}

STDMETHODIMP CSCTag::put_SpaceAfter(int iVal)
{
    m_iSpaceAfter = iVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_LeftMargin(int *piVal)
{
    *piVal = m_iLeftMargin;
    return S_OK;
}

STDMETHODIMP CSCTag::put_LeftMargin(int iVal)
{
    m_iLeftMargin = iVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_FirstLineIndent(int *piVal)
{
    *piVal = m_iFirstLineIndent;
    return S_OK;
}

STDMETHODIMP CSCTag::put_FirstLineIndent(int iVal)
{
    m_iFirstLineIndent = iVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_RightMargin(int *piVal)
{
    *piVal = m_iRightMargin;
    return S_OK;
}

STDMETHODIMP CSCTag::put_RightMargin(int iVal)
{
    m_iRightMargin = iVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Color(int *piVal)
{
    *piVal = m_iColor;
    return S_OK;
}

STDMETHODIMP CSCTag::put_Color(int iVal)
{
    m_iColor = iVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Rank(int *piVal)
{
    *piVal = m_iRank;
    return S_OK;
}

STDMETHODIMP CSCTag::put_Rank(int iVal)
{
    m_iRank = iVal;
	return S_OK;
}




STDMETHODIMP CSCTag::get_IsEndMarker(BOOL *pfVal)
{
    *pfVal = m_fIsEndMarker;
    return S_OK;
}

STDMETHODIMP CSCTag::put_IsEndMarker(BOOL fVal)
{
    m_fIsEndMarker = fVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Bold(BOOL *pfVal)
{
    *pfVal = m_fBold;
    return S_OK;
}

STDMETHODIMP CSCTag::put_Bold(BOOL fVal)
{
    m_fBold = fVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Italic(BOOL *pfVal)
{
    *pfVal = m_fItalic;
    return S_OK;
}

STDMETHODIMP CSCTag::put_Italic(BOOL fVal)
{
    m_fItalic = fVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Underline(BOOL *pfVal)
{
    *pfVal = m_fUnderline;
    return S_OK;
}

STDMETHODIMP CSCTag::put_Underline(BOOL fVal)
{
    m_fUnderline = fVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Superscript(BOOL *pfVal)
{
    *pfVal = m_fSuperscript;
    return S_OK;
}

STDMETHODIMP CSCTag::put_Superscript(BOOL fVal)
{
    m_fSuperscript = fVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_NotRepeatable(BOOL *pfVal)
{
    *pfVal = m_fNotRepeatable;
    return S_OK;
}

STDMETHODIMP CSCTag::put_NotRepeatable(BOOL fVal)
{
    m_fNotRepeatable = fVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_SmallCaps(BOOL *pfVal)
{
    *pfVal = m_fSmallCaps;
    return S_OK;
}

STDMETHODIMP CSCTag::put_SmallCaps(BOOL fVal)
{
    m_fSmallCaps = fVal;
	return S_OK;
}

STDMETHODIMP CSCTag::get_Subscript(BOOL *pfVal)
{
    *pfVal = m_fSubscript;
    return S_OK;
}

STDMETHODIMP CSCTag::put_Subscript(BOOL fVal)
{
    m_fSubscript = fVal;
	return S_OK;
}

