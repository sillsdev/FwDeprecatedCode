// SCScriptureText.cpp : Implementation of CSCScriptureText
#include "stdafx.h"
#include "TESO.h"
#include "SCScriptureText.h"
#include "SCTextEnum.h"
//#include "SCTextEnumEx.h"
#include "io.h"
#include "direct.h"

#include "shlobj.h"	// shell call

//// #import "..\..\..\..\ECObjects\Debug\ECObjects.dll" no_namespace
//#import "c:\dev\fw\distfiles\ECObjects.dll" no_namespace
//#import "c:\dev\fw\distfiles\ScriptureObjects.dll" namespace(XYZ)


//#import "..\..\Common\LanguageTlb.tlb" \
//	exclude("IRenderEngine", "ILgSegment", "ILgLineBreakEngine", "ILgInputMethodEditor", \
//	"ILgWritingSystem", "ILgEncoding", "ILgEncodingFactory") \
//	no_namespace, named_guids

//#import "..\..\output\Common\LanguageEngine.tlb"  no_namespace 

/////////////////////////////////////////////////////////////////////////////
// CSCScriptureText

STDMETHODIMP CSCScriptureText::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISCScriptureText
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


#if 0

For now I think we will disconnect all the language
related stuff from the ScriptureObjects
because it make it is easier if they do not depend on eacn other.

STDMETHODIMP CSCScriptureText::get_CharacterPropertyEngine(			
	/*[out,retval]*/ /*ILgCharacterPropertyEngine*/ IUnknown **ppCharacterPropertyEngine
	)
{
	// To Do: Make it possible for the user to get either the 1) Paratext
	//     or 2) fieldworks engine

	ISCLanguageEnginePtr q;

	if (m_qSCLanguageEngine == NULL) {
		q.CreateInstance(__uuidof(SCLanguageEngine));
		m_qSCLanguageEngine = q;
		if (m_qSCLanguageEngine == NULL)
			return E_FAIL;
	}

	//! need to catch exception if signaled
	*ppCharacterPropertyEngine = m_qSCLanguageEngine;

	(*ppCharacterPropertyEngine)->AddRef();

	return S_OK;
}


STDMETHODIMP CSCScriptureText::get_CollatingEngine(			
	/*[out,retval]*/ /*ILgCollatingEngine*/ IUnknown **ppCollatingEngine
	)
{
	// To Do: Make it possible for the user to get either the 1) Paratext
	//     or 2) fieldworks engine

	ISCLanguageEnginePtr q;

	if (m_qSCLanguageEngine == NULL) {
		q.CreateInstance(__uuidof(SCLanguageEngine));
		m_qSCLanguageEngine = q;
		if (m_qSCLanguageEngine == NULL)
			return E_FAIL;
	}

	*ppCollatingEngine = m_qSCLanguageEngine;
	(*ppCollatingEngine)->AddRef();

	return S_OK;
}

#endif

// We to find some custom macros to allow specifying
// the code page used for the conversion operation

#define USES_CONVERSION_CP(x) int _convert; _convert; UINT _acp = x; _acp; \
			LPCWSTR _lpw; _lpw; LPCSTR _lpa; _lpa

#undef A2W
#define A2W(lpa) (\
		((_lpa = lpa) == NULL) ? NULL : (\
			_convert = (lstrlenA(_lpa)+1),\
			ATLA2WHELPER((LPWSTR) alloca(_convert*2), _lpa, _convert, _acp)))

#undef W2A
#define W2A(lpw) (\
		((_lpw = lpw) == NULL) ? NULL : (\
			_convert = (lstrlenW(_lpw)+1)*5,\
			ATLW2AHELPER((LPSTR) alloca(_convert), _lpw, _convert, _acp)))

char* CombineCharPtrs( char *a, char *b )
{
	int len = strlen( a );
	len += strlen( b );
	len += 2;
	char *rval = new char[len];
	strcpy( rval, a );
	strcat( rval, b );

	delete [] a;
	delete [] b;

	return rval;
}


char * CSCScriptureText::GetCharText( ISCReference *pSCFirstReference, ISCReference *pSCLastReference)
{
	char *rval=NULL;

///	bool fOneChapterPerFile = (m_cbstrChapterNumberForm.Length() > 0);
	bool bHasExtFile = HasExtFile();

    short iBook, iLastBook;
    short iChapter, iLastChapter;
    short iVerse, iLastVerse;

	SCVersification iVersification;

	pSCFirstReference->get_Book(&iBook);
	pSCFirstReference->get_Chapter(&iChapter);
	pSCFirstReference->get_Verse(&iVerse);
	pSCFirstReference->get_Versification(&iVersification);

	pSCLastReference->get_Book(&iLastBook);
	pSCLastReference->get_Chapter(&iLastChapter);
	pSCLastReference->get_Verse(&iLastVerse);

	ScriptureReference srfFirst(iBook, iChapter, iVerse, ScriptureVersificationType(iVersification));
	ScriptureReference srfLast(iLastBook, iLastChapter, iLastVerse, ScriptureVersificationType(iVersification));
	
	ATLTRACE("GetCharText from %s - %s\n", srfFirst.sAsString().c_str(), srfLast.sAsString().c_str());

	// Find table entry for this reference
	RangeToFile *rtfFirst, *rtfLast, *rtfTemp;
	bool foundFirst = false, foundLast = false;
	vector<RangeToFile>::iterator rtfiFirst;
	vector<RangeToFile>::iterator rtfi = m_vecrtf.begin();

	while (rtfi != m_vecrtf.end()) 
	{
		rtfTemp = &(*rtfi);
		ATLTRACE("RTF - %d %d %s\n", rtfTemp->m_srfFirst.iBBCCCVVV(), rtfTemp->m_srfLast.iBBCCCVVV(), rtfTemp->m_cbstrFileName );
		if ( !foundFirst )	// && bHasExtFile )
		{
			if (srfFirst >= rtfi->m_srfFirst && srfFirst <= rtfi->m_srfLast )	// found first ref
			{
				rtfiFirst = rtfi;
				foundFirst = true;
				rtfFirst = &(*rtfi);
			}
		}

		if ( foundFirst )	// && bHasExtFile )
		{
			if (srfLast >= rtfi->m_srfFirst && srfLast <= rtfi->m_srfLast )	// found last ref
			{
				rtfLast = &(*rtfi);
				break;
			}
		}
		++rtfi;
	}

	bool refFound = true;

	if (rtfi == m_vecrtf.end()) 
	{
		refFound = false;
///
///		ATLTRACE("----------------------------------------\n");
///		ATLTRACE("Couldn't find reference.\n");
///		ATLTRACE("----------------------------------------\n");
///		
///		Error("File not present");
///		return NULL;	// E_FAIL;
	}

	long startOffset, endOffset;

	if ( refFound )
	{
		startOffset = rtfFirst->GetStartOffset( &srfFirst, this );
	}

	if ( startOffset < 0 )		// not found
	{
		refFound = false;
	}

	if ( refFound )
	{
		if ( rtfLast->m_srfLast.iBBCCCVVV() == srfLast.iBBCCCVVV() )	// end ref is last in file
		{
			endOffset = rtfLast->iSize();	// takes it to the end of the file
		}
		else
			endOffset = rtfLast->GetEndOffset( &srfLast, this );
	}

	if ( endOffset < 0 || refFound == false )		// not found
	{
		ATLTRACE("----------------------------------------\n");
		ATLTRACE("Couldn't find reference.\n");
		ATLTRACE("----------------------------------------\n");
		
		return NULL;	// E_FAIL;
	}

	
	long middleSize = 0;
	if ( rtfFirst != rtfLast )
	{
		ATLTRACE("Start Size<%d>\n", rtfFirst->iSize() - startOffset);
		rtfi = rtfFirst;
		rtfi++;

		while( rtfi != rtfLast )	// m_vecrtf.end() )
		{
			ATLTRACE("RTF - %s size<%d>\n", (*rtfi).m_cbstrFileName, (*rtfi).iSize() );
			middleSize += (*rtfi).iSize();
			rtfi++;
		}

		ATLTRACE("End   Size<%d>\n", endOffset);
	}

	long ttlSize = 0;
	if ( rtfFirst == rtfLast )
	{
		// just read from one file
		ttlSize = endOffset - startOffset;
		rval = rtfFirst->Read( startOffset, ttlSize );
	}
	else
	{
		ttlSize += rtfFirst->iSize() - startOffset;		// portion of first file
		ttlSize += endOffset;							// portion of last file
		ttlSize += middleSize + 1;						// any files in the middle

		// allocate memory for the whole text
		ATLTRACE(" Allocating buffer: %d bytes\n", ttlSize );
		rval = new char[ttlSize];
		int pos = 0;

		// read first: offset -> end
		pos = rtfFirst->iSize()-startOffset;
		ATLTRACE(" Reading at Buf Pos[%d]\n", pos );
		rtfFirst->Read( startOffset, pos, &rval[0] );

		// read last : begin  -> offset
		ATLTRACE(" Reading at Buf Pos[%d]\n", ttlSize-endOffset-1 );
		rtfLast->Read( 0, endOffset, &rval[ttlSize-endOffset-1] );
//			pos += endOffset;

		rtfi = rtfFirst;
		rtfi++;

		while( rtfi != rtfLast )	// m_vecrtf.end() )
		{
			ATLTRACE(" Reading at Buf Pos[%d]\n", pos );
			(*rtfi).Read( 0, (*rtfi).iSize(), &rval[pos] );	// now read from the middle files in their entirity
			pos += (*rtfi).iSize();
			rtfi++;
		}
	}


	return rval;

}



STDMETHODIMP CSCScriptureText::GetText(
			/*[in]*/ ISCReference *pSCReference,
			/*[in]*/ BOOL fSingleChapter,
			/*[in]*/ BOOL fDoMapin,  
			/*[out, retval]*/ BSTR *pbstrText
			)
{
	PROTECTION_BEGIN

	bool fOneChapterPerFile = (m_cbstrChapterNumberForm.Length() > 0);
	bool bHasExtFile = HasExtFile();

	int iOffset;   // Offset to start of this chapter
	int iOffset2;  // Offset to start of next chapter
	int iSize;
	CComBSTR qbstrEmpty("");

    short iBook;
    short iChapter;
    short iVerse;
	SCVersification iVersification;

	if (fOneChapterPerFile && !fSingleChapter) {
		Error("Cannot read multiple chapters from a single chapter file");
		return E_NOTIMPL;
	}

	pSCReference->get_Book(&iBook);
	pSCReference->get_Chapter(&iChapter);
	pSCReference->get_Verse(&iVerse);
	pSCReference->get_Versification(&iVersification);
	ScriptureReference srf(iBook, iChapter, iVerse, ScriptureVersificationType(iVersification));
	ATLTRACE("GetText from %s\n", srf.sAsString().c_str());

	// Find table entry for this reference
	vector<RangeToFile>::iterator rtfi = m_vecrtf.begin();
	while (rtfi != m_vecrtf.end()) {
		if ( bHasExtFile ) {
			if (srf.iBook() >= rtfi->m_srfFirst.iBook() && srf.iBook() <= rtfi->m_srfLast.iBook() &&
				srf.iChapter() >= rtfi->m_srfFirst.iChapter() && srf.iChapter() <= rtfi->m_srfLast.iChapter() )
				break;
		}
		else if (!fOneChapterPerFile) {
			if (srf.iBook() == rtfi->m_srfFirst.iBook())
				break;
		}
		else if (srf >= rtfi->m_srfFirst && srf <= rtfi->m_srfLast)
			break;
		++rtfi;
	}

	if (rtfi == m_vecrtf.end()) {
		Error("File not present");
		return E_FAIL;
	}

	if (1) {	// !fOneChapterPerFile && fSingleChapter) {
		iOffset = rtfi->iChapterOffset(iChapter);

		if (iOffset == duplicate || iOffset == outOfOrder) {
			Error(rtfi->ChapterError());
			return E_ABORT;
		}

		if (iOffset == notFound) {
			*pbstrText = qbstrEmpty.Copy();
			ATLTRACE("Chapter number not found\n");
			return S_OK;
		}

		if (iOffset < 0) {
			Error(rtfi->ChapterError());
			return E_FAIL;
		}

		iOffset2 = rtfi->iChapterEndOffset(iChapter);
		if (iOffset2 < 0) {
			Error(rtfi->ChapterError());
			return E_FAIL;
		}
		iSize = iOffset2 - iOffset;
	}
	else {
		iOffset = 0;
		iSize = rtfi->iSize();
	}

	char* p = rtfi->Read(iOffset, iSize);
	if (p == NULL) {
		Error("Could not read file");
		ATLTRACE("Could not read file\n");
		return E_FAIL;
	}

	char* q = p;
	if (fDoMapin)
		q = Mapin(p);

	ATLTRACE("GetText %d bytes\n", strlen(q));

	CharToWChar((unsigned char*)q, pbstrText);

	if (q != p)
		delete[] q;
	delete[] p;

	return S_OK;

	PROTECTION_END
}


bool FExists(char *p)
{
	HANDLE hFile;

	hFile = CreateFile(p,  
					GENERIC_READ,              // open for reading 
					FILE_SHARE_READ,           // share for reading 
					NULL,                      // no security 
					OPEN_EXISTING,             // existing file only 
					FILE_ATTRIBUTE_NORMAL,     // normal file 
					NULL);                     // no attr. template 
 
	if (hFile == INVALID_HANDLE_VALUE) 
		return false;

	CloseHandle(hFile); 

	return true;
}


STDMETHODIMP CSCScriptureText::PutText(
			/*[in]*/ ISCReference *pSCReference,
			/*[in]*/ BOOL fSingleChapter,
			/*[in]*/ BOOL fDoMapout,  
			/*[in]*/ BSTR bstrText
			)
{
	PROTECTION_BEGIN

	bool fOneChapterPerFile = (m_cbstrChapterNumberForm.Length() > 0);

	int iOffset;
	int iOffset2;
	int iSize;
	int iTotalSize;
	int iNewLen;

    short iBook;
    short iChapter;
    short iVerse;
	SCVersification iVersification;

	char szFileName[256];
	char szBackupFileName[280];
	char* pPrePart = NULL;
	char* pPostPart = NULL;
	char* pNewPart = NULL;
	char* pMapoutResult = NULL;

	HANDLE hFile = INVALID_HANDLE_VALUE;
	DWORD lBytes;
	bool fFailed = false;
	int iLen;
	HRESULT hr = S_OK;
	int i;

	USES_CONVERSION_CP(0);


	if (fOneChapterPerFile && !fSingleChapter) {
		Error("Cannot write multiple chapters to a single chapter file");
		return E_NOTIMPL;
	}
	ATLTRACE("HERE\n");

	pSCReference->get_Book(&iBook);
	pSCReference->get_Chapter(&iChapter);
	pSCReference->get_Verse(&iVerse);
	pSCReference->get_Versification(&iVersification);
	ScriptureReference srf(iBook, iChapter, iVerse, ScriptureVersificationType(iVersification));

	ATLTRACE("PutText %s (SingleChapter = %c)\n", srf.sAsString().c_str(),
		fSingleChapter ? 'T' : 'F');


	// Find table entry for this reference
	vector<RangeToFile>::iterator rtfi = m_vecrtf.begin();
	while (rtfi != m_vecrtf.end()) {
		if (!fOneChapterPerFile) {
			if (srf.iBook() == rtfi->m_srfFirst.iBook())
				break;
		}
		else if (srf >= rtfi->m_srfFirst && srf <= rtfi->m_srfLast)
			break;
		++rtfi;
	}

	if (rtfi == m_vecrtf.end()) {
		Error("File not present");
		return E_FAIL;
	}

	if (!fOneChapterPerFile && fSingleChapter) {
		iOffset = rtfi->iChapterOffset(iChapter);

		if (iOffset == duplicate || iOffset == outOfOrder) {
			Error(rtfi->ChapterError());
			return E_ABORT;
		}

		if (iOffset == notFound) {
			for (int iTmp=iChapter; iOffset == notFound  && iTmp <= rtfi->iMaxChapter(); ++iTmp)
				iOffset = rtfi->iChapterOffset(iTmp);
			if (iOffset == notFound)
				iOffset = rtfi->iSize();
		}
		else if (iOffset < 0) {
			Error(rtfi->ChapterError());
			return E_FAIL;
		}

		iOffset2 = rtfi->iChapterEndOffset(iChapter);
		if (iOffset2 < 0) {
			Error("Could not find end of chapter");
			return E_FAIL;
		}

		iSize = iOffset2 - iOffset;
		iTotalSize = rtfi->iSize();

		//==============================================================================
		// Take a shortcut if we are writing to the end of an existing
		// file.  This is to prevent Import File from rewriting the
		// the entire file a zillion times.

		if (iOffset != 0 && iOffset == iOffset2 && iOffset == iTotalSize) {
			ATLTRACE("puttext shortcut\n");
			// Write before part, new data, after part
			hFile = CreateFile(OLE2A((BSTR)rtfi->m_cbstrFileName),  
							GENERIC_WRITE,    
							0,						   // dont share
							NULL,                      // no security 
							OPEN_EXISTING,         
							FILE_ATTRIBUTE_NORMAL,      
							NULL);                     // no attr. template 
 
			if (hFile == INVALID_HANDLE_VALUE) {
				ATLTRACE("err=%lx\n", GetLastError());
				Error("Cannot create file");
				hr = E_FAIL;
				goto cleanup;
			}

			SetFilePointer(hFile, 0, 0, FILE_END);

			pNewPart = WCharToChar(bstrText);
			pMapoutResult = pNewPart;
			if (fDoMapout)
				pMapoutResult = Mapout(pNewPart);

			iLen = strlen(pMapoutResult);
			if (iLen)
				if (WriteFile(hFile, pMapoutResult, iLen, &lBytes, NULL) == 0) {
					Error("Cannot write file");
					CloseHandle(hFile); 
					hr = E_FAIL;
					goto cleanup;
				}

			CloseHandle(hFile);
			hFile = INVALID_HANDLE_VALUE; 

			// Update chapter offset table
			rtfi->ReplaceChapterOffset(iChapter, iOffset, 0, iLen);

			goto cleanup;
		}
		//================================END OF SHORTCUT============================

		ATLTRACE("puttext slow way\n");
		ATLTRACE("PutText iOffset=%d iOffset2=%d\n", iOffset, iOffset2);

		// Read part of file before this chapter
		if (iOffset > 0) {
			pPrePart = rtfi->Read(0, iOffset);
			if (pPrePart == NULL) {
				Error("Could not read file");
				hr = E_FAIL;
				goto cleanup;
			}
		}
		else {
			pPrePart = new char[1];
			*pPrePart = 0;
		}

		// Read part of file after this chapter
		int iPostPartSize = iTotalSize-(iSize+iOffset);

		if (iPostPartSize > 0) {
			pPostPart = rtfi->Read(iOffset+iSize, iPostPartSize);
			if (pPostPart == NULL) {
				Error("Could not read file");
				hr = E_FAIL;
				goto cleanup;
			}
		}
		else {
			pPostPart = new char[iPostPartSize+1];
			*pPostPart = 0;
		}
	}
 
	else {
		pPrePart = new char[1];
		*pPrePart = 0;
		pPostPart = new char[1];
		*pPostPart = 0;
	}

	pNewPart = WCharToChar(bstrText);

	pMapoutResult = pNewPart;

	if (fDoMapout)
		pMapoutResult = Mapout(pNewPart);

	hr = ValidateChapterNumbers(pPrePart, pMapoutResult, pPostPart, rtfi);
	if (hr != S_OK)
		goto cleanup;

	// Delete old copy (if any)
	// Rename current file as old copy, create new file
	sprintf(szFileName, "%.255s", OLE2A((BSTR)rtfi->m_cbstrFileName));
	strcpy(szBackupFileName, szFileName);

	for (i=0; (unsigned int)i<strlen(szBackupFileName); ++i)
		if (szBackupFileName[i] == '.')
			szBackupFileName[i] = 0;

	strcat(szBackupFileName, ".BAK");

	ATLTRACE("PutText: %s (%s)\n", szFileName, szBackupFileName);
	ATLASSERT(FExists(szFileName /*pre*/));

	remove(szBackupFileName);   // OK if this fails.
	ATLASSERT(!FExists(szBackupFileName));

	if (rename(szFileName, szBackupFileName) != 0) {
		ATLTRACE("errno = %d\n", errno);
		Error("Could not create backup copy of file");
		hr = E_FAIL;
		goto cleanup;
	}

	ATLASSERT(FExists(szBackupFileName));

	// Write before part, new data, after part
///
///	pNewPart = WCharToChar(bstrText);
///
///	pMapoutResult = pNewPart;
///
///	if (fDoMapout)
///		pMapoutResult = Mapout(pNewPart);
///

	hFile = CreateFile(szFileName,  
					GENERIC_WRITE,    
					0,						   // dont share
					NULL,                      // no security 
					CREATE_ALWAYS,         
					FILE_ATTRIBUTE_NORMAL,      
					NULL);                     // no attr. template 
 
	if (hFile == INVALID_HANDLE_VALUE) {
		ATLTRACE("err=%lx\n", GetLastError());
		fFailed = true;
	}

	iLen = strlen(pPrePart);
	if (iLen && !fFailed)
		if (WriteFile(hFile, pPrePart, iLen, &lBytes, NULL) == 0)
			fFailed = true;

	iLen = strlen(pMapoutResult);
	if (iLen && !fFailed)
		if (WriteFile(hFile, pMapoutResult, iLen, &lBytes, NULL) == 0)
			fFailed = true;
	iNewLen = iLen;

	iLen = strlen(pPostPart);
	if (iLen && !fFailed)
		if (WriteFile(hFile, pPostPart, iLen, &lBytes, NULL) == 0)
			fFailed = true;

	// Could not perform the output operation.  Revert to previous file.
	// To Do: Test this
	if (fFailed) {
		remove(szFileName); 
		rename(szBackupFileName, szFileName);
		Error("Could not write new copy of file");
		hr = E_FAIL;
		goto cleanup;
	}

	CloseHandle(hFile);
	hFile = INVALID_HANDLE_VALUE;
	ATLASSERT(FExists(szFileName));

	// Update chapter offset table
	rtfi->ReplaceChapterOffset(iChapter, iOffset, iSize, iNewLen);


cleanup:
	// delete work areas
	if (pMapoutResult != NULL && pMapoutResult != pNewPart)	delete[] pMapoutResult;
	if (pNewPart != NULL) delete[] pNewPart;
	if (pPrePart != NULL) delete[] pPrePart;
	if (pPostPart != NULL) delete[] pPostPart;
	if (hFile != INVALID_HANDLE_VALUE) CloseHandle(hFile);

	return hr;

	PROTECTION_END
}

 

STDMETHODIMP CSCScriptureText::ValidateChapterNumbers(
						char* pPrePart, char* pMapoutResult, char* pPostPart,
						vector<RangeToFile>::iterator rtfi)
{
	vector<int> viChapterOffset;
	int iBadChapter;
	ChapterStatus status;

	status = rtfi->ScanForChapterOffsets(
		viChapterOffset, pPrePart, pPrePart+strlen(pPrePart), iBadChapter);

	if (status == allOk)
		status = rtfi->ScanForChapterOffsets(
			viChapterOffset, pMapoutResult, pMapoutResult+strlen(pMapoutResult), iBadChapter);

	if (status == allOk)
		status = rtfi->ScanForChapterOffsets(
			viChapterOffset, pPostPart, pPostPart+strlen(pPostPart), iBadChapter);

	if (status != allOk) {
		char err[128];
		sprintf(err, "Chapter %d duplicated or out of order; text not written.", iBadChapter);
		Error(err);
		return E_FAIL;
	}

	return S_OK;
}

#if 0
int CALLBACK BrowseCallbackProc( HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM lpData )
{
	if ( uMsg == BFFM_SELCHANGED )
	{
		struct _finddata_t c_file;
		long hFile;

		TCHAR szPath[MAX_PATH];
		BOOL success = SHGetPathFromIDList( (LPCITEMIDLIST) lParam, (LPTSTR) &szPath );

		CComBSTR cbstr = szPath;
		cbstr.Append("\\*.ssf");

		USES_CONVERSION;
		hFile = _findfirst(OLE2A((BSTR)cbstr), &c_file);

		int hasFiles = 0;
		if (hFile != -1)
			hasFiles = 1;
		
		_findclose( hFile );
		PostMessage( hwnd, BFFM_ENABLEOK, 0, hasFiles );
	}

	return 0;
}


short ScanForBooks( char* pStart, char* pEnd, const char* bookMarker, vector<short>& vsiBooks )
{
	short rval = 0;
	char *p;
	char bookName[4];	// three char code plus null

	vsiBooks.clear();

	int bookMarkerLen = strlen(bookMarker);
	
	for (p = pStart; p<pEnd; ++p) {
		if (strncmp(p, bookMarker, bookMarkerLen) != 0) continue;	// look for complete marker

		p += bookMarkerLen;									// update pointer
		if (*p != ' ' && *p != '\t ') continue;				// look for white space
		for (p++; *p == ' ' || *p == '\t'; ++p) {}			// eat any additional white space

		if ( *(p+3) != ' '  && *(p+3) != '\t' &&			// need ws after found book name
			 *(p+3) != 0x0d && *(p+3) != 0x0a ) continue;	//  OR possibly and end of line

		strncpy( bookName, p, bookMarkerLen);
		bookName[3] = '\0';

		int id = ScriptureReference::iLookupBook( bookName );
		
		ATLTRACE("Book Offset %s:%d\n", bookName, id);

		if ( id )
		{
			rval++;
			vsiBooks.push_back( id );
		}
	}

	return rval;
}


STDMETHODIMP CSCScriptureText::GetBooksForFile( 
			/*[in]*/ BSTR bstrFileName,			// "fullpath and filename of file"
			/*[in]*/ BSTR bstrBookMarker,		// "\id"
			/*[out,retval]*/ VARIANT* pSafeArray
			)
{
	// Show the Browse window looking for ssf files
	//
	if ( 0 )		
	{
		BROWSEINFO bi;
		memset( &bi, 0, sizeof( bi ) );

		TCHAR folder[MAX_PATH];
		TCHAR title[] = {"Here's some help text..."};

		bi.pszDisplayName = folder;
		bi.lpszTitle = title;
		bi.ulFlags = BIF_DONTGOBELOWDOMAIN;	// | BIF_NONEWFOLDERBUTTON | ;
		bi.lpfn = BrowseCallbackProc;

		LPITEMIDLIST idl = SHBrowseForFolder( &bi );
	}

	vector<short> vsiBooks;
	HRESULT hr = 0;

	while (1)
	{
		HANDLE hFile;
		BY_HANDLE_FILE_INFORMATION fileData;

		USES_CONVERSION;

		char bookMarker[128];
		strcpy(bookMarker, OLE2A(bstrBookMarker) );

		hFile = CreateFile(OLE2A(bstrFileName),  
						GENERIC_READ,              // open for reading 
						FILE_SHARE_READ,           // share for reading 
						NULL,                      // no security 
						OPEN_EXISTING,             // existing file only 
						FILE_ATTRIBUTE_NORMAL,     // normal file 
						NULL);                     // no attr. template 
 
		if (hFile == INVALID_HANDLE_VALUE) 
			break;

		if (! GetFileInformationByHandle(hFile, &fileData)) {
			CloseHandle(hFile);
			break;
		}

		int nFileSize = (int)fileData.nFileSizeLow;

		// If file is zero size then it clearly contains no markers.
		if (nFileSize == 0) {
			CloseHandle(hFile);
			break;
		}
		
		HANDLE hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
		if (hFileMapping == NULL) {
			CloseHandle(hFile);
			break;
		}

		char* pFile = (char*)MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
		if (pFile == NULL) {
			CloseHandle(hFileMapping);
			CloseHandle(hFile);
			break;
		}

		char* pEnd = pFile + nFileSize - 1;
		short numbooks = ScanForBooks( pFile, pEnd, bookMarker, vsiBooks );

		UnmapViewOfFile(pFile);
		CloseHandle(hFileMapping);
		CloseHandle(hFile);

		break;
	}

	try
	{
		const int numItems = vsiBooks.size();

		SAFEARRAY FAR* psa;
		SAFEARRAYBOUND rgsabound[1];
		rgsabound[0].lLbound = 0;
		rgsabound[0].cElements = numItems;
		psa = SafeArrayCreate(VT_I2, 1, rgsabound);

		short sVal;
		LONG lIndex = 0;

		// Fill the safe array with the short value for the book
		//
		for( lIndex = 0 ; lIndex < numItems ;lIndex++)
		{
			sVal = (short) vsiBooks.at(lIndex);
			hr  = SafeArrayPutElement(psa, &lIndex, &sVal);
		}

		pSafeArray->vt = VT_I2 | VT_ARRAY;
		V_ARRAY(pSafeArray) = psa;

	}
	catch(_com_error &e)
	{
		e;
		// DumpError(e);
	}

	return hr;
}

#endif

/*
      // Utility function that gets error information from _com_error and
      // displays an error message box.
      void DumpError(_com_error &e)
      {
         _bstr_t bstrSource(e.Source());
         _bstr_t bstrDescription(e.Description());
         CString str;
         str.Format("\tCode = %08lx", e.Error());
         str += " Msg: ";   str += e.ErrorMessage();
         str += " Source: "; str += bstrSource;
         str += " Description: "; str += bstrDescription;
         AfxMessageBox(str);
      }
*/

#if 0
STDMETHODIMP CSCScriptureText::TextEnumEx(			
	/*[in]*/ ISCReference *pSCReferenceFirst,
	/*[in]*/ ISCReference *pSCReferenceLast,
	/*[out,retval]*/ ISCTextEnumEx **ppSCTextEnumEx
	)
{
	PROTECTION_BEGIN

///	BSTR bstrText;
///	HRESULT hResult = GetTextEx( pSCReferenceFirst, pSCReferenceLast, false, &bstrText );

	//
	// Get the text from the start to end ref, or text that contains those verses...
	//
	char * cpText;		// will be removed in the TextEnumEx object...
	cpText = GetCharText( pSCReferenceFirst, pSCReferenceLast);

///	ATLTRACE("Text Read= [%200s]\n", cpText );

	// Create TextEnumEx object
	CComObject<CSCTextEnumEx> *pste;
	HRESULT hResult = CComObject<CSCTextEnumEx>::CreateInstance(&pste);
	if (FAILED(hResult))
		return hResult;

    pste->AddRef();
///	pste->SetText( bstrText, this, NULL );
	
	pste->m_qScriptureText = this;

	// already handled by the CComPtr type in <pste>
	// pste->m_qScriptureText.p->AddRef();		// release when we're done 

	pste->SetText( cpText, NULL );

	pste->AddTextMarkerProps( this->m_MarkerTextProp );	// >m_PropMap

	//
	// Walk through the list of markers and pass on any that have converters associated with them
	//
	//	m_IDMap : Marker	 Encoding
	//			 -------	------------
	//				aaa	->	 EncodingA
	//				bbb ->	 EncodingA
	//				ccc ->	 EncodingZ
	//
	//	m_ConverterMap:
	//				Encoding	 Converter Object
	//				---------	 -----------------------
	//				EncodingA -> CTKAndCodePageWrapperA
	//				EncodingZ -> CTKAndCodePageWrapperZ
	//
	TMapMarkerToID::iterator iti = m_IDMap.begin();
	while ( iti != m_IDMap.end() )
	{
		_TSTRING marker = (*iti).first;
		_TSTRING key = (*iti).second;

		TMapIDToConverter::iterator itc = m_ConverterMap.find( key );
		if ( itc == m_ConverterMap.end() )
		{
			ATLTRACE("Error in ScriptureText::TextEnum - no converter in map.\n");
			break;
		}

		CTKAndCodePageWrapper *conv = (CTKAndCodePageWrapper *) (*itc).second;
		pste->AddMarkerAndConverter( marker, conv );

		iti++;
	}

/////////////////////

	*ppSCTextEnumEx = pste;

	return S_OK;

	PROTECTION_END
}
#endif

STDMETHODIMP CSCScriptureText::TextEnum(			
	/*[in]*/ ISCReference *pSCReferenceFirst,
	/*[in]*/ ISCReference *pSCReferenceLast,
	/*[in]*/ SCTextType sttFilter,
	/*[in]*/ SCTextProperties stpSmushing,
	/*[out,retval]*/ ISCTextEnum **ppSCTextEnum
	)
{
	PROTECTION_BEGIN

	ScriptureTextSegmentStream * pstss;
    short iBook;
    short iChapter;
    short iVerse;
	SCVersification iVersification;

	pSCReferenceFirst->get_Book(&iBook);
	pSCReferenceFirst->get_Chapter(&iChapter);
	pSCReferenceFirst->get_Verse(&iVerse);
	//ATLTRACE("fetch %d %d:%d\n", iBook, iChapter, iVerse);
	pSCReferenceFirst->get_Versification(&iVersification);
	ScriptureReference srfFirst(iBook, iChapter, iVerse, ScriptureVersificationType(iVersification));

	pSCReferenceLast->get_Book(&iBook);
	pSCReferenceLast->get_Chapter(&iChapter);
	pSCReferenceLast->get_Verse(&iVerse);
	pSCReferenceLast->get_Versification(&iVersification);
	ScriptureReference srfLast(iBook, iChapter, iVerse, ScriptureVersificationType(iVersification));

	if (m_iMyVersification == 0) {
		Error("Must Load() text first", IID_ISCTextEnum);
		return E_FAIL;
	}

	//To Do: convert srfFirst, srfLast to MyVersification

	// setup appropriate ScriptureTextSegmentStream

#ifdef CAN_READ_XML_FILES
	_TSTRING sFileFormat = pscr->sGetParameterValue(pParameterNames[FILE_FORMAT_INDEX]);
	if (sFileFormat.compare(_TSTRING("SFM")) == 0)
		pstss = new SFMScriptureTextSegmentStream(pscr, srf);
	else if (sFileFormat.compare(_TSTRING("XML")) == 0)
		pstss = new XMLScriptureTextSegmentStream(pscr, srf);
#else

	pstss = new SFMScriptureTextSegmentStream(
					srfFirst, m_MarkerTextProp, m_vTags, m_vecrtf, m_iMyVersification, m_hMapin, m_fAsteriskIsMarker, EatEscapeBackslashes() );
#endif

	// Create TextEnum object
	CComObject<CSCTextEnum> *pste;
	HRESULT hResult = CComObject<CSCTextEnum>::CreateInstance(&pste);
	if (FAILED(hResult))
		return hResult;
    pste->AddRef();
	*ppSCTextEnum = pste;

	// Copy SegmentStream to object
	// This is not really kosher -- calling another COM object thru a non COM ifc.
	// If we don't do this what then?
	CSCTextEnum *p = pste;
	p->Init(pstss, srfFirst, srfLast, sttFilter, stpSmushing);
	p->m_qScriptureText = this;

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCScriptureText::FileName(
	ISCReference *pSCReference, 
	ISCReference *pSCReferenceFirst, 
	ISCReference *pSCReferenceLast, 
	BOOL fAlwaysReturnName,
	BSTR *pbstrFileName)
{
	PROTECTION_BEGIN

    short iBook;
    short iChapter;
    short iVerse;
	SCVersification iVersification;
	CComBSTR cbstrValue = "";

	if (pSCReference == NULL)
		return E_POINTER;

	pSCReference->get_Book(&iBook);
	pSCReference->get_Chapter(&iChapter);

	pSCReference->get_Verse(&iVerse);
	//ATLTRACE("fetch %d %d:%d\n", iBook, iChapter, iVerse);
	pSCReference->get_Versification(&iVersification);
	ScriptureReference srf(iBook, iChapter, iVerse, ScriptureVersificationType(iVersification));

	// Find table entry for this reference
	vector<RangeToFile>::iterator rtfi = m_vecrtf.begin();
	while (rtfi != m_vecrtf.end()) {
		if (srf >= rtfi->m_srfFirst && srf <= rtfi->m_srfLast)
			break;
		++rtfi;
	}

	// If a book matching this reference is found,
	// copy the file name and first and last references.
	if (rtfi != m_vecrtf.end()) {
		cbstrValue = rtfi->m_cbstrFileName;
		if (pSCReferenceFirst != NULL)
			SetReference(pSCReferenceFirst, rtfi->m_srfFirst);
		if (pSCReferenceLast != NULL)
			SetReference(pSCReferenceLast, rtfi->m_srfLast);
	}

	// If we did not find an existing file but the user
	// always wants a name returned, figure out what
	// the name should be.
	if (fAlwaysReturnName && cbstrValue == "") {
		CComBSTR cbstrDirectory = TextDirectory();

		cbstrValue = cbstrDirectory;
		cbstrValue.Append(cbstrTextFileName(iBook, iChapter));
	}

	*pbstrFileName = cbstrValue.Copy();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCScriptureText::NthFileName(
	int iFileNumber, 
	ISCReference *pSCReferenceFirst, 
	ISCReference *pSCReferenceLast, 
	BSTR *pbstrFileName)
{
	PROTECTION_BEGIN

	if (iFileNumber <= 0)
		return E_INVALIDARG;

    vector<RangeToFile>::iterator rtfi;
	int i = iFileNumber-1;

	// Advanced to i'th table entry
    rtfi = m_vecrtf.begin();
	while (rtfi != m_vecrtf.end() && i) {
		--i;
		++rtfi;
	}

	// If a book matching this reference is found,
	// copy the file name and first and last references.
	CComBSTR cbstrValue = "";
	if (rtfi != m_vecrtf.end()) {
		cbstrValue = rtfi->m_cbstrFileName;
		if (pSCReferenceFirst != NULL)
			SetReference(pSCReferenceFirst, rtfi->m_srfFirst);
		if (pSCReferenceLast != NULL)
			SetReference(pSCReferenceLast, rtfi->m_srfLast);
	}
	*pbstrFileName = cbstrValue.Copy();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCScriptureText::NthTag(
	int iTagNumber, 
	ISCTag **ppTag)
{
	PROTECTION_BEGIN

	if (iTagNumber < 0 || iTagNumber >= (int)m_vTags.size())
		*ppTag = NULL;
	else {
		//ATLTRACE("NthTag = %d\n", iTagNumber);
		*ppTag = m_vTags[iTagNumber];
		(*ppTag)->AddRef();
	}

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCScriptureText::TagIndex(
			/*[in]*/ BSTR bstrTagName,
			/*[out, retval]*/ int *piNth)
{
	PROTECTION_BEGIN

	CComBSTR qbstr(bstrTagName);
	CComBSTR qbstrMarker;
	unsigned int i;

	for (i=0; i<m_vTags.size(); ++i) {
		qbstrMarker.Empty();
		m_vTags[i]->get_Marker(&qbstrMarker);
		if (qbstr == qbstrMarker) {
			*piNth = i;
			return S_OK;
		}
	}

	// If no tag with this name found, create one
	CComPtr<ISCTag> qTag;
	qTag.CoCreateInstance(_uuidof(SCTag),NULL,CLSCTX_INPROC_SERVER);
	qTag->put_Marker(qbstr);
	m_vTags.push_back(qTag);
	qTag->put_Color(255 * 65536  /* red */);
	*piNth = i;

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCScriptureText::GetParameterValue(BSTR bstrName, BSTR *pbstrValue)
{
	PROTECTION_BEGIN

	CComBSTR cbstrName = bstrName;	
	CComBSTR cbstrValue = m_PropMap[cbstrName];	

	*pbstrValue = cbstrValue.Copy();

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCScriptureText::SetParameterValue(BSTR bstrName, BSTR bstrValue)
{
	PROTECTION_BEGIN

	CComBSTR cbstrName = bstrName;	
	CComBSTR cbstrValue = bstrValue;	
	m_PropMap[cbstrName] = bstrValue;

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCScriptureText::get_SettingsDirectory(BSTR *pVal)
{
	PROTECTION_BEGIN

	*pVal = SettingsDirectory().Copy();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCScriptureText::get_TextsPresent(BSTR *pVal)
{
	PROTECTION_BEGIN

	struct _finddata_t c_file;
    long hFile;
	int fDone = 0;
	CComBSTR qbstr;

	typedef basic_string<char> CFileName;

	// NT sorts directories but Win95 doesn't so we need to order
	// the returned project names.
	// To Do ought to use case insensitive compare for this set
	set<CFileName> setProjects;

	USES_CONVERSION;

	CComBSTR cbstr = SettingsDirectory();
	cbstr.Append("*.ssf");
	hFile = _findfirst(OLE2A((BSTR)cbstr), &c_file);

	if (hFile != -1) {
		while (fDone == 0) {
			c_file.name[strlen(c_file.name)-4] = 0;
			setProjects.insert(c_file.name);

			fDone = _findnext( hFile, &c_file );
		}
		_findclose( hFile );
	}

	set<CFileName>::iterator p;
	for (p = setProjects.begin(); p!= setProjects.end(); ++p) {
		qbstr += CComBSTR(p->c_str());
		qbstr += "\r\n";
	}

	*pVal = qbstr.Copy();
   
	return S_OK;

	PROTECTION_END
}


// Return the directory name for the settings file directory.

char* MySettingsDirectory(void) 
{
	char *strSubkey = "Software\\ScrChecks\\1.0\\Settings_Directory";
	static char strResult[256];
	long iResultLength = sizeof(strResult);

	if (RegQueryValue(HKEY_LOCAL_MACHINE, strSubkey, strResult, &iResultLength) ==
			ERROR_SUCCESS) {
		if (strResult[strlen(strResult)-1] != '\\')
			strcat(strResult, "\\");
		return strResult;
	}

	return "";
}


CComBSTR CSCScriptureText::SettingsDirectory(void) 
{
	return CComBSTR(MySettingsDirectory());
}


CComBSTR CSCScriptureText::TextDirectory(void) 
{
	CComBSTR cbstrDirectory = m_PropMap["Directory"];
	if (cbstrDirectory.Length() == 0) {
		cbstrDirectory = SettingsDirectory();
		if (cbstrDirectory[cbstrDirectory.Length()-1] != '\\')
			cbstrDirectory.Append("\\");
		CComBSTR cbstrName;
		get_Name(&cbstrName);
		cbstrDirectory.Append(cbstrName);
	}

	if (cbstrDirectory[cbstrDirectory.Length()-1] != '\\')
		cbstrDirectory.Append("\\");

	//ATLTRACE("TextDirectory = %s\n", (BSTR)cbstrDirectory);

	return cbstrDirectory;
}



// Create a full path name for a .ssf file by
// prefixing the settings directory if no directory specified
// and by adding .ssf if no suffix present.

CComBSTR CSCScriptureText::FullPathName(BSTR bstrFileName)
{
	CComBSTR cbstr;

	if (wcschr(bstrFileName, '\\')) {
		cbstr = bstrFileName;
	}
	else {
		cbstr = SettingsDirectory();
		cbstr.AppendBSTR(bstrFileName);
	}

	if (! wcschr(bstrFileName, '.')) 
		cbstr.Append(".ssf");

	return cbstr;
}


HRESULT CSCScriptureText::InsertRangeToFile(RangeToFile &rtfToInsert)
{
	//ATLTRACE("Book found %d\n", rtfToInsert.m_srfFirst.iBBCCCVVV());
	rtfToInsert.m_sChapterMarker = m_sChapterMarker;
	m_vecrtf.push_back(rtfToInsert);

	return S_OK;
}



HRESULT CSCScriptureText::SetNaming(
		CComBSTR cbstrPrePart, 
		CComBSTR cbstrPostPart, 
		CComBSTR cbstrBookNameForm, 
			// Must be MAT, 40, or 40MAT
		CComBSTR cbstrChapterNumberForm
			// Must be "", "1", or "01"
		)
{
	//m_cbstrPrePart = cbstrPrePart;
	//m_cbstrPostPart = cbstrPostPart;
	//m_cbstrBookNameForm = cbstrBookNameForm;
	//m_cbstrChapterNumberForm = cbstrChapterNumberForm;

	put_FileNamePrePart((BSTR)cbstrPrePart);
	put_FileNamePostPart((BSTR)cbstrPostPart);
	put_FileNameForm((BSTR)cbstrBookNameForm);
	put_FileNameChapterNumberForm((BSTR)cbstrChapterNumberForm);

	return S_OK;
}


STDMETHODIMP CSCScriptureText::get_BooksPresent(BSTR *pbstr)
{
	CComBSTR cbstrName = L"BooksPresent";	
	CComBSTR cbstrValue = m_PropMap[cbstrName];	

	while (cbstrValue.Length() < NUM_BOOKS)
		cbstrValue.Append(" ");

	*pbstr = cbstrValue.Copy();

	return S_OK;
}
STDMETHODIMP CSCScriptureText::put_BooksPresent(BSTR bstrNewVal)
{
    return SetParameterValue(L"BooksPresent", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_Encoding(BSTR *pbstr)
{
	// If encoding is present use that.

	CComBSTR cbstrName = L"Encoding";	
	CComBSTR cbstrValue = m_PropMap[cbstrName];	

	if (cbstrValue.Length()) {
		*pbstr = cbstrValue.Copy();
		return S_OK;
	}

	// If not encoding present use value of obsolete CodePage
	// parameter if present.
    return GetParameterValue(L"CodePage", pbstr);
}
STDMETHODIMP CSCScriptureText::put_Encoding(BSTR bstrNewVal)
{
    return SetParameterValue(L"Encoding", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_CodePage(int *pVal)
{
	PROTECTION_BEGIN

	USES_CONVERSION;

	CComBSTR cbstrName = L"Encoding";	
	CComBSTR cbstrValue = m_PropMap[cbstrName];	
	*pVal = atoi(OLE2A((BSTR)cbstrValue));

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCScriptureText::put_CodePage(int newVal)
{
	PROTECTION_BEGIN

	char cp[16];
	sprintf(cp, "%d", newVal);
	CComBSTR tmp(cp);

	return put_Encoding(tmp);

	PROTECTION_END
}


STDMETHODIMP CSCScriptureText::get_DefaultFont(BSTR *pbstr)
{
    return GetParameterValue(L"DefaultFont", pbstr);
}
STDMETHODIMP CSCScriptureText::put_DefaultFont(BSTR bstrNewVal)
{
    return SetParameterValue(L"DefaultFont", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_DefaultFontSize(int *piVal)
{
	CComBSTR cbstrValue = m_PropMap["DefaultFontSize"];	
	*piVal = _wtoi((BSTR)cbstrValue);

    return S_OK;
}
STDMETHODIMP CSCScriptureText::put_DefaultFontSize(int iVal)
{
	wchar_t tmp[30];
	swprintf(tmp, L"%d", iVal);
    return SetParameterValue(L"DefaultFontSize", tmp);
}


STDMETHODIMP CSCScriptureText::get_Directory(BSTR *pbstr)
{
    return GetParameterValue(L"Directory", pbstr);
}
STDMETHODIMP CSCScriptureText::put_Directory(BSTR bstrNewVal)
{
    return SetParameterValue(L"Directory", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_Editable(BOOL *pfVal)
{
	CComBSTR cbstrValue = m_PropMap["Editable"];	
	*pfVal = (cbstrValue == "T") ? -1 : 0;
	return S_OK;
}
STDMETHODIMP CSCScriptureText::put_Editable(BOOL fVal)
{
    return SetParameterValue(L"Editable", fVal ? CComBSTR("T") : CComBSTR("F"));
}


STDMETHODIMP CSCScriptureText::get_FileNameForm(BSTR *pbstr)
{
    return GetParameterValue(L"FileNameForm", pbstr);
}
STDMETHODIMP CSCScriptureText::put_FileNameForm(BSTR bstrNewVal)
{
	m_cbstrBookNameForm = bstrNewVal;
    return SetParameterValue(L"FileNameForm", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_FileNamePostPart(BSTR *pbstr)
{
    return GetParameterValue(L"FileNamePostPart", pbstr);
}
STDMETHODIMP CSCScriptureText::put_FileNamePostPart(BSTR bstrNewVal)
{
	m_cbstrPostPart = bstrNewVal; 
    return SetParameterValue(L"FileNamePostPart", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_FileNamePrePart(BSTR *pbstr)
{
    return GetParameterValue(L"FileNamePrePart", pbstr);
}
STDMETHODIMP CSCScriptureText::put_FileNamePrePart(BSTR bstrNewVal)
{
	m_cbstrPrePart = bstrNewVal;  
	return SetParameterValue(L"FileNamePrePart", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_FileNameChapterNumberForm(BSTR *pbstr)
{
    return GetParameterValue(L"FileNameChapterNumberForm", pbstr);
}
STDMETHODIMP CSCScriptureText::put_FileNameChapterNumberForm(BSTR bstrNewVal)
{
	m_cbstrChapterNumberForm = bstrNewVal;
    return SetParameterValue(L"FileNameChapterNumberForm", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_FullName(BSTR *pbstr)
{
    return GetParameterValue(L"FullName", pbstr);
}
STDMETHODIMP CSCScriptureText::put_FullName(BSTR bstrNewVal)
{
    return SetParameterValue(L"FullName", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_Language(BSTR *pbstr)
{
    return GetParameterValue(L"Language", pbstr);
}
STDMETHODIMP CSCScriptureText::put_Language(BSTR bstrNewVal)
{
    return SetParameterValue(L"Language", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_LeftToRight(BOOL *pfVal)
{
	CComBSTR cbstrValue = m_PropMap["LeftToRight"];	
	*pfVal = (cbstrValue == "T") ? -1 : 0;
	return S_OK;
}
STDMETHODIMP CSCScriptureText::put_LeftToRight(BOOL fVal)
{
    return SetParameterValue(L"LeftToRight", fVal ? CComBSTR("T") : CComBSTR("F"));
}


STDMETHODIMP CSCScriptureText::get_Name(BSTR *pbstr)
{
    return GetParameterValue(L"Name", pbstr);
}
STDMETHODIMP CSCScriptureText::put_Name(BSTR bstrNewVal)
{
    return SetParameterValue(L"Name", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_StyleSheet(BSTR *pbstr)
{
    return GetParameterValue(L"StyleSheet", pbstr);
}
STDMETHODIMP CSCScriptureText::put_StyleSheet(BSTR bstrNewVal)
{
    return SetParameterValue(L"StyleSheet", bstrNewVal);
}


STDMETHODIMP CSCScriptureText::get_Versification(SCVersification *pVal)
{
	*pVal = m_iMyVersification;
    return S_OK;
}
STDMETHODIMP CSCScriptureText::put_Versification(SCVersification newVal)
{
	wchar_t tmp[30];
	swprintf(tmp, L"%d", (int)newVal);
	m_iMyVersification = newVal;
    return SetParameterValue(L"Versification", tmp);
}

// IErrorInfo
STDMETHODIMP CSCScriptureText::GetGUID(GUID *guid)
{
	*guid = m_ErrorGuid;
	return S_OK;
}

STDMETHODIMP CSCScriptureText::GetSource(BSTR *bstrVal)
{
	*bstrVal = m_cbstrErrorSource.Copy();
	return S_OK;
}

STDMETHODIMP CSCScriptureText::GetDescription(BSTR *bstrVal)
{
	*bstrVal = m_cbstrErrorDescription.Copy();
	return S_OK;
}

STDMETHODIMP CSCScriptureText::GetHelpFile(BSTR *bstrVal)
{
	*bstrVal = m_cbstrHelpFile.Copy();
	return S_OK;
}

STDMETHODIMP CSCScriptureText::GetHelpContext(DWORD *dwVal)
{
	*dwVal = m_ErrorHelpContext;
	return S_OK;
}


STDMETHODIMP CSCScriptureText::get_AsteriskIsMarker(BOOL *pVal)
{
	if (m_fAsteriskIsMarker)
		*pVal = -1;
	else
		*pVal = 0;

    return S_OK;
}


HRESULT CSCScriptureText::CharToWChar(unsigned char* pszIn, BSTR* pbstr)
{
	return m_TEC.Convert(pszIn, pbstr);
}


char* CSCScriptureText::WCharToChar(BSTR bstrIn)
{
	return m_TEC.Convert(bstrIn);
}



int g_nCCMsgIndex;
int g_lCCParam; 

int WINAPI localCCErrorCallback(short nMsgIndex, 
								short unsigned wParam, 
								long unsigned lParam, 
								long *lpUserData)
{
	g_nCCMsgIndex = nMsgIndex;
	g_lCCParam = lParam; 

	return 1;
}


char* RunCC(HANDLE h, char* pszIn)
{
	char *lpOutputBuffer = NULL;

	// If m_hMapin is not zero, process the input characters
	//    thru the referenced CC table.
	//    Return the result as string created with new char[].

	if (h == 0) return pszIn;

	CCSetErrorCallBack(h, localCCErrorCallback);

	int nInBufLen = strlen(pszIn);
	int npOutBufLen;

	for(int i=1; i<=5; ++i) {
		g_nCCMsgIndex = 0;
		g_lCCParam = 0; 

		if (lpOutputBuffer)
			delete lpOutputBuffer;
		npOutBufLen = (i+1)*nInBufLen + 10;
		lpOutputBuffer = new char[npOutBufLen + 1];

		CCReinitializeTable(h);
		int iResult = CCProcessBuffer (h,
                            pszIn, nInBufLen,
                            lpOutputBuffer, &npOutBufLen);

		if (g_nCCMsgIndex == 0)
			break;

		ATLTRACE("CC err=%d\n", g_nCCMsgIndex);

		// Here we had an error.
		// If we are out of space in buffer, just try again with bigger buffer.
		// Otherwise, run cc again without the error handler so the
		// user can see the error message. 
		// Note: w/o error handler g_nCCMsgIndex will not change and the
		// loop will terminate.
		if (g_nCCMsgIndex != 83) {
			CCSetErrorCallBack(h, NULL);
		}
	}

	lpOutputBuffer[npOutBufLen] = 0;
	return lpOutputBuffer;
}


char* CSCScriptureText::Mapin(char* pszIn)
{
	// If m_hMapin is not zero, process the input characters
	//    thru the referenced CC table.
	//    Return the result as string created with new char[].

	if (m_hMapin == 0) return pszIn;

	return RunCC(m_hMapin, pszIn);
}


char* CSCScriptureText::Mapout(char* pszIn)
{
	// To Do: If m_hMapout is not zero, process the input characters
	//    thru the referenced CC table.
	//    Return the result as string created with new char[].

	if (m_hMapout == 0) return pszIn;

	return RunCC(m_hMapout, pszIn);
}


STDMETHODIMP CSCScriptureText::get_ErrorDataString(/*[out,retval]*/BSTR* bstr)
{
	return GetDescription(bstr);	// call method that's part of IErrorInfo
}


//#include "c:\dev\fw\lib\src\ecobjects\ECObjects.h"		// types...

STDMETHODIMP CSCScriptureText::LoadECObjectDataForSOReading(VARIANT pSafeArrayOfBytes)
{
	HRESULT hr;
	if ( !m_ecProject )
		m_ecProject.CoCreateInstance(_uuidof(ECProject),NULL,CLSCTX_INPROC_SERVER);

    if (m_ecProject == NULL) 
	{
        Error(L"Unable to create ECProject COM Object."); 
        return E_FAIL;
    }
	

	// validate the passed in data
	int isValid = false;
	try
	{
		hr = m_ecProject->ValidateSafeArray( pSafeArrayOfBytes, &isValid );
		if ( FAILED(hr) )
		{
			OutputDebugString("*** ERROR : m_ecProject->ValidateSafeArray() failed\n");
			return hr;
		}
	}
	catch(...)
	{
		OutputDebugString("Error validating the safe array passed in!!! ---------\n" );
	}

	if ( !isValid )
		return E_INVALIDARG;


	// initialize the ECProject object

	hr = m_ecProject->InitializeFromSafeArray( pSafeArrayOfBytes );
	if ( FAILED(hr) )
	{
		OutputDebugString("*** ERROR : m_ecProject->ValidateSafeArray() failed\n");
		return hr;
	}

	// preform the encoding step

	BSTR bstrDoneEventName = NULL;
	hr = m_ecProject->ConvertProject( &bstrDoneEventName );
	::SysFreeString( bstrDoneEventName );
	if ( FAILED(hr) )
	{
		OutputDebugString("*** ERROR : m_ecProject->ConvertProject() failed\n");
		return hr;
	}

	// preform the tranformation step

	// make sure there are entries for the sty and ssf files
	BSTR ssfName, styName;

	hr = m_ecProject->get_DefaultSSFFileName( &ssfName );
	if ( !ssfName || ::SysStringLen( ssfName ) <= 0 )
	{
		ssfName = ::SysAllocString( L"c:\\ECProjectCreated.ssf" );
		hr = m_ecProject->put_DefaultSSFFileName( ssfName );
	}
	::SysFreeString( ssfName );

	hr = m_ecProject->get_DefaultSTYFileName( &styName );
	if ( !styName || ::SysStringLen( styName ) <= 0 )
	{
		styName = ::SysAllocString( L"c:\\ECProjectCreated.sty" );
		hr = m_ecProject->put_DefaultSTYFileName( styName );
	}
	::SysFreeString( styName );


	// build the SO files
	hr = m_ecProject->BuildSOProjectFiles();
	if ( FAILED(hr) )
	{
		OutputDebugString("*** ERROR : m_ecProject->BuildSOProjectFiles() failed\n");

		HRESULT hrTemp;
//		ISupportErrorInfoPtr qsei;
		IErrorInfoPtr qei;

//		hrTemp = m_ECLibrary->QueryInterface(IID_ISupportErrorInfo, (void **)&qsei);
//		if (SUCCEEDED(hrTemp) && qsei->InterfaceSupportsErrorInfo(IID_IECLibrary) == S_OK)
//		{

		hrTemp = GetErrorInfo(0, &qei);
		if (hrTemp != S_FALSE)
		{
			BSTR bstr;
			
			hrTemp = qei->GetDescription(&bstr);
			m_cbstrErrorDescription = bstr;
			::SysFreeString(bstr);
				
			hrTemp = qei->GetSource(&bstr);
			m_cbstrErrorSource = bstr;
			::SysFreeString(bstr);
				
			hrTemp = qei->GetHelpFile(&bstr);
			m_cbstrHelpFile = bstr;
			::SysFreeString(bstr);
				
			hrTemp = qei->GetGUID(&m_ErrorGuid);
			hrTemp = qei->GetHelpContext(&m_ErrorHelpContext);

			SetErrorInfo(0, qei);
		}

//		}
		return hr;
	}

	// then use the SO load method to get created project read in
	BSTR bstrProjectName;
	hr = m_ecProject->get_DefaultSSFFileName( &bstrProjectName );
//	m_ecProject = NULL;

	hr = this->Load( bstrProjectName );
	::SysFreeString( bstrProjectName );
	if ( FAILED(hr) )
	{
		OutputDebugString("*** ERROR : CSCScriptureText->Load() failed\n");
		return hr;
	}
	
	return hr;
}
