#include "stdafx.h"
#include "SimpleTKWrapper.h"
#include "TKAndCodePageWrapper.h"
#include "TECkit_Compiler.h"



CTKAndCodePageWrapper::CTKAndCodePageWrapper() // : CTraceCreation( "CTKAndCodePageWrapper" )
{
	m_Valid = false;
	m_iCodePage = 0;
	m_pTEC = NULL;
}


CTKAndCodePageWrapper::CTKAndCodePageWrapper( const CTKAndCodePageWrapper& other )	// : CTraceCreation("CTKAndCodePageWrapper" )
{
	m_Valid = other.m_Valid;
	m_iCodePage = other.m_iCodePage;
	m_pTEC = other.m_pTEC;
}



void CTKAndCodePageWrapper::Load( char* encoding )
{
	if (m_pTEC) {
		delete m_pTEC;
		m_pTEC = NULL;
	}
	m_iCodePage = 0;
	m_Valid = false;

	char* p = encoding;
	while (*p == ' ' || (*p >= '0' && *p <= '9'))
		++p;

	if (*p == 0) {
		m_iCodePage = atoi(encoding);
		m_Valid = (m_iCodePage == 65002) || IsValidCodePage(m_iCodePage);
		return;
	}

	// not a code page, try to create a TECKit

	char fileName[512];

	if (encoding[0] != '\\' && encoding[1] != ':') {
		char *strSubkey = "Software\\ScrChecks\\1.0\\Settings_Directory";
		static char strResult[256];
		long iResultLength = sizeof(strResult);

		if (RegQueryValue(HKEY_LOCAL_MACHINE, strSubkey, strResult, &iResultLength) ==
				ERROR_SUCCESS) {
			if (strResult[strlen(strResult)-1] != '\\')
				strcat(strResult, "\\");
		}
		else
			strcpy(strResult, "");

		strcpy(fileName, strResult);
		strcat(fileName, encoding);
	}
	else {
		strcpy(fileName, encoding);
	}

	m_pTEC = new CSimpleTKWrapper(fileName);

	m_Valid = m_pTEC->IsValid();
}


// go from Bytes to UTF16LE

HRESULT CTKAndCodePageWrapper::Convert( unsigned char* in, BSTR* pbstr )	
{
	CComBSTR qbstr;

	if (m_pTEC)
		return m_pTEC->Convert(in, pbstr);

	// not a TECkit, so convert using codepage

	int _convert = lstrlenA((char *)in)+1;
	WCHAR* pc = new wchar_t[_convert];
	ATLA2WHELPER(pc, (char *)in, _convert, m_iCodePage);

	qbstr = pc;

	delete[] pc;

	*pbstr = (BSTR)qbstr.Copy();

	return S_OK;
}


// go from UTF16LE to Bytes

char* CTKAndCodePageWrapper::Convert( BSTR bstrIn )	
{
	char* pReturned;

	if (m_pTEC)
		return m_pTEC->Convert(&bstrIn);

	int nCharsOut = WideCharToMultiByte(m_iCodePage, 0, bstrIn, -1, NULL, 0, NULL, NULL);
	
	pReturned = new char[nCharsOut+1];
	*pReturned = '\0';

	WideCharToMultiByte(
					m_iCodePage, 0, bstrIn, -1, pReturned, nCharsOut+1, NULL, NULL);

	return pReturned;
}
