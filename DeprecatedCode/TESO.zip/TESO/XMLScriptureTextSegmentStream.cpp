#include "stdafx.h"

#ifdef CAN_READ_XML_FILES

This XML code was partially developed and debugged.


// void XMLScriptureTextSegmentStream::StartElement(void *pTokenData, const XML_Char *pszName)
//   This routine every time a start tag is recognized

void XMLScriptureTextSegmentStream::StartElement(void *pTokenData, const XML_Char *pszName, const XML_Char **ppcAtts)
{
	// get a handle on the Token Data
	TokenData* ptd = (TokenData*)pTokenData;
	// if there was data since last tag.
	ptd->m_tattStack.push_back(TextAndTokenType(text,_TSTRING(ptd->m_sData)));
	ptd->m_sData = EMPTY_STRING;
	ptd->m_tattStack.push_back(TextAndTokenType(tag,_TSTRING(pszName)));
}


// void XMLScriptureTextSegmentStream::EndElement(void *pTokenData, const XML_Char *pszName)
//   This routine every time an end tag is recognized

void XMLScriptureTextSegmentStream::EndElement(void *pTokenData, const XML_Char *pszName)
{
	// get a handle on the Token Data
	TokenData* ptd = (TokenData*)pTokenData;
	ptd->m_tattStack.push_back(TextAndTokenType(text,_TSTRING(ptd->m_sData)));
	ptd->m_sData=EMPTY_STRING;
	// this isn't a good way to do end marker !!
	_TSTRING sTmp=_TSTRING(pszName)+_TSTRING("*");
	ptd->m_tattStack.push_back(TextAndTokenType(tag,sTmp));
}


// void XMLScriptureTextSegmentStream::CharacterDataHandler(void *pTokenData, const XML_Char *psz, int iLen)
//   this adds each char read to the current data psz is not 0 terminated

void XMLScriptureTextSegmentStream::CharacterDataHandler(void *pTokenData, const XML_Char *psz, int iLen)
{
	TokenData *ptd=(TokenData*)pTokenData;
	ptd->m_sData+= _TSTRING(psz, iLen);
}


// constructor: initializes XML parser and gives it the functions to use..

XMLScriptureTextSegmentStream::XMLScriptureTextSegmentStream(ScriptureText *pscr, ScriptureReference srf):ScriptureTextSegmentStream(pscr, srf)
{
	m_parser=XML_ParserCreate(NULL);
	XML_SetUserData(m_parser, &m_td);
	XML_SetElementHandler(m_parser, XMLScriptureTextSegmentStream::StartElement, XMLScriptureTextSegmentStream::EndElement);
	XML_SetCharacterDataHandler(m_parser, XMLScriptureTextSegmentStream::CharacterDataHandler);
}


// _TSTRING sGetNextToken(ScrTokenType& tt, _TCHAR chCommentMarker, bool bAsteriskIsMarker)
//   Integrates getting the next token from the stream "*this" with advancing to the next file if possible.

_TSTRING XMLScriptureTextSegmentStream::sGetNextToken(ScrTokenType& tt, _TCHAR chCommentMarker, bool bAsteriskIsMarker)
{
	while(m_td.m_tattStack.empty())
	{
		char cBuf[BUFF_SIZE];
		read(cBuf, sizeof(cBuf));
		size_t len=gcount();
		int iFailed=XML_Parse(m_parser, cBuf, len, int(len < sizeof(cBuf)));
		if(iFailed==0)
		{
			sprintf(cBuf, "#=%d %s\n", XML_GetCurrentLineNumber(m_parser),
				XML_ErrorString(XML_GetErrorCode(m_parser)));
			tt=unknowntt;
			return EMPTY_STRING;
		}
		if(m_td.m_iErrLineNum!=0)
		{
			sprintf(cBuf, "#=%d ", m_td.m_iErrLineNum);
			tt=unknowntt;
			return EMPTY_STRING;
		}
		while(eof())
		{
			if(m_rtfi==m_pscr->lrtfFileList.end())
			{	
				m_bEOS=true;
				return EMPTY_STRING;
			}
			close();
			clear();
			while((m_rtfi!=m_pscr->lrtfFileList.end()) && (is_open()==0))
			{
				m_rtfi++;
				if(m_rtfi!=m_pscr->lrtfFileList.end())
					open(m_rtfi->m_sFileName.data());
			}
		}
	}

    deque<TextAndTokenType>::iterator tattIterator;
   	tattIterator=m_td.m_tattStack.begin();
	tt=tattIterator->m_tt;
	_TSTRING sToReturn=tattIterator->m_sText;
	m_td.m_tattStack.pop_front();
	return sToReturn;
}

#endif // CAN_READ_XML_FILES


