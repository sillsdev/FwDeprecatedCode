// SCTag.h : Declaration of the CSCTag

//:> See ScriptureObjects.idl for interface information about this class


#ifndef __SCTAG_H_
#define __SCTAG_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSCTag
class ATL_NO_VTABLE CSCTag : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSCTag, &CLSID_SCTag>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISCTag, &IID_ISCTag, &LIBID_TESOLib>
{
public:
	CSCTag()
	{
		m_fBold = 0;
		m_iColor = 0;
		m_iFirstLineIndent = 0;
		m_iFontSize = 0;
		m_fIsEndMarker = 0;
		m_fItalic = 0;
		m_iJustificationType = scLeft;
		m_iLeftMargin = 0;
		m_iLineSpacing = 0;
		m_fNotRepeatable = 0;
		m_iRank = 0;
		m_iRightMargin = 0;
		m_iSpaceAfter = 0;
		m_iSpaceBefore = 0;
		m_fSuperscript = 0;
		m_iStyleType = SCStyleType(0);
		m_fUnderline = 0;
		m_stp = SCTextProperties(0);
		m_stt = SCTextType(0);
		m_fUnderline = 0;
		m_fSmallCaps = 0;
		m_fSubscript = 0;

		m_cbstrDescription = "";
		m_cbstrEndmarker = "";
		m_cbstrFontname = "";
		m_cbstrMarker = "";
		m_cbstrName = "";
		m_cbstrTeStyleName = "";
		m_cbstrOccursUnder = "";
		m_cbstrXMLTag = "";
		m_cbstrEncoding = "";
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCTAG)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSCTag)
	COM_INTERFACE_ENTRY(ISCTag)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISCTag
public:
	STDMETHOD(get_Bold)(BOOL *pfVal);
	STDMETHOD(put_Bold)(BOOL fVal);

	STDMETHOD(get_Color)(int *piVal);
	STDMETHOD(put_Color)(int iVal);

	STDMETHOD(get_Description)(BSTR *pbstr);
	STDMETHOD(put_Description)(BSTR bstr);

	STDMETHOD(get_Endmarker)(BSTR *pbstr);
	STDMETHOD(put_Endmarker)(BSTR bstr);

	STDMETHOD(get_FirstLineIndent)(int *piVal);
	STDMETHOD(put_FirstLineIndent)(int iVal);

	STDMETHOD(get_Fontname)(BSTR *pbstr);
	STDMETHOD(put_Fontname)(BSTR bstr);

	STDMETHOD(get_FontSize)(int *piVal);
	STDMETHOD(put_FontSize)(int iVal);

	STDMETHOD(get_IsEndMarker)(BOOL *pfVal);
	STDMETHOD(put_IsEndMarker)(BOOL fVal);

	STDMETHOD(get_Italic)(BOOL *pfVal);
	STDMETHOD(put_Italic)(BOOL fVal);

	STDMETHOD(get_JustificationType)(SCJustificationType *pVal);
	STDMETHOD(put_JustificationType)(SCJustificationType Val);

	STDMETHOD(get_LeftMargin)(int *piVal);
	STDMETHOD(put_LeftMargin)(int iVal);

	STDMETHOD(get_LineSpacing)(int *piVal);
	STDMETHOD(put_LineSpacing)(int iVal);

	STDMETHOD(get_Marker)(BSTR *pbstr);
	STDMETHOD(put_Marker)(BSTR bstr);

	STDMETHOD(get_Name)(BSTR *pbstr);
	STDMETHOD(put_Name)(BSTR bstr);

	STDMETHOD(get_TeStyleName)(BSTR *pbstr);
	STDMETHOD(put_TeStyleName)(BSTR bstr);

	STDMETHOD(get_NotRepeatable)(BOOL *pfVal);
	STDMETHOD(put_NotRepeatable)(BOOL fVal);

	STDMETHOD(get_OccursUnder)(BSTR *pbstr);
	STDMETHOD(put_OccursUnder)(BSTR bstr);

	STDMETHOD(get_Rank)(int *piVal);
	STDMETHOD(put_Rank)(int iVal);

	STDMETHOD(get_RightMargin)(int *piVal);
	STDMETHOD(put_RightMargin)(int iVal);

	STDMETHOD(get_SpaceAfter)(int *piVal);
	STDMETHOD(put_SpaceAfter)(int iVal);

	STDMETHOD(get_SpaceBefore)(int *piVal);
	STDMETHOD(put_SpaceBefore)(int iVal);

	STDMETHOD(get_StyleType)(SCStyleType *pVal);
	STDMETHOD(put_StyleType)(SCStyleType Val);

	STDMETHOD(get_Superscript)(BOOL *pfVal);
	STDMETHOD(put_Superscript)(BOOL fVal);

	STDMETHOD(get_TextProperties)(SCTextProperties *pVal);
	STDMETHOD(put_TextProperties)(SCTextProperties Val);

	STDMETHOD(get_TextType)(SCTextType *pVal);
	STDMETHOD(put_TextType)(SCTextType Val);

	STDMETHOD(get_Underline)(BOOL *pfVal);
	STDMETHOD(put_Underline)(BOOL fVal);

	STDMETHOD(get_XMLTag)(BSTR *pbstr);
	STDMETHOD(put_XMLTag)(BSTR bstr);

	STDMETHOD(get_Encoding)(BSTR *pbstr);
	STDMETHOD(put_Encoding)(BSTR bstr);

	STDMETHOD(get_SmallCaps)(BOOL *pfVal);
	STDMETHOD(put_SmallCaps)(BOOL fVal);

	STDMETHOD(get_Subscript)(BOOL *pfVal);
	STDMETHOD(put_Subscript)(BOOL fVal);

private:
    BOOL m_fBold;
    int m_iColor;
    CComBSTR m_cbstrDescription;
    CComBSTR m_cbstrEndmarker;
    int m_iFirstLineIndent;
    CComBSTR m_cbstrFontname;
    int m_iFontSize;
    BOOL m_fIsEndMarker;
    BOOL m_fItalic;
    SCJustificationType m_iJustificationType;
    int m_iLeftMargin;
    int m_iLineSpacing;
    CComBSTR m_cbstrMarker;
    CComBSTR m_cbstrName;
    CComBSTR m_cbstrTeStyleName;
    BOOL m_fNotRepeatable;
    CComBSTR m_cbstrOccursUnder;
    int m_iRank;
    int m_iRightMargin;
    int m_iSpaceAfter;
    int m_iSpaceBefore;
    BOOL m_fSuperscript;
    SCStyleType m_iStyleType;
    SCTextProperties m_stp;
    SCTextType m_stt;
    BOOL m_fUnderline;
    CComBSTR m_cbstrXMLTag;
    CComBSTR m_cbstrEncoding;
	BOOL m_fSmallCaps;
	BOOL m_fSubscript;
};

#endif //__SCTAG_H_
