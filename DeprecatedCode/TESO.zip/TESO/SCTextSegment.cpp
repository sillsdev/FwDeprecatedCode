// SCTextSegment.cpp : Implementation of CSCTextSegment
#include "stdafx.h"
#include "TESO.h"
#include "SCTextSegment.h"
#include "SCReference.h"

/////////////////////////////////////////////////////////////////////////////
// CSCTextSegment

STDMETHODIMP CSCTextSegment::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISCTextSegment
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSCTextSegment::get_FirstReference(ISCReference **pVal)
{
	PROTECTION_BEGIN

	*pVal = m_pISCReferenceFirst;
	if (*pVal)
		(*pVal)->AddRef();

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::put_FirstReference(ISCReference *newVal)
{
	PROTECTION_BEGIN

	m_pISCReferenceFirst = newVal;

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::get_LastReference(ISCReference **pVal)
{
	PROTECTION_BEGIN

	*pVal = m_pISCReferenceLast;
	if (*pVal)
		(*pVal)->AddRef();

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::put_LastReference(ISCReference *newVal)
{
	PROTECTION_BEGIN

	m_pISCReferenceLast = newVal;
	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::get_TextType(SCTextType *pVal)
{
	PROTECTION_BEGIN

	*pVal = m_stt;
	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::put_TextType(SCTextType newVal)
{
	PROTECTION_BEGIN

	m_stt = newVal;
	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::get_TextProperties(SCTextProperties *pVal)
{
	PROTECTION_BEGIN

	*pVal = m_stp;
	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::put_TextProperties(SCTextProperties newVal)
{
	PROTECTION_BEGIN

	m_stp = newVal;
	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::get_Text(BSTR *pbstr)
{
	PROTECTION_BEGIN

    *pbstr = m_cbstrText.Copy();
    return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::put_Text(BSTR bstrNewVal)
{
	PROTECTION_BEGIN

    m_cbstrText = bstrNewVal;
	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::get_Tag(ISCTag **pVal)
{
	PROTECTION_BEGIN

	*pVal = m_pISCTag;
	if (*pVal)
		(*pVal)->AddRef();

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::put_Tag(ISCTag *newVal)
{
	PROTECTION_BEGIN

	m_pISCTag = newVal;

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::put_LiteralVerseNum(BSTR newVal)
{
	PROTECTION_BEGIN

	m_cbstrLitVerse = newVal;
    return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::get_LiteralVerseNum(BSTR *pbstr)
{
	PROTECTION_BEGIN

	*pbstr = m_cbstrLitVerse.Copy(); // TE-844
    return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCTextSegment::Clone(/*[out, retval]*/ ISCTextSegment **ppTextSegment)
{
	// TODO: Add your implementation code here

	return E_NOTIMPL;
}


HRESULT CSCTextSegment::FinalConstruct()
{
	CComObject<CSCReference> *p;

	HRESULT hResult = CComObject<CSCReference>::CreateInstance(&p);
	if (FAILED(hResult))
		return hResult;
	m_pISCReferenceFirst = p;

	hResult = CComObject<CSCReference>::CreateInstance(&p);
	if (FAILED(hResult))
		return hResult;
	m_pISCReferenceLast = p;

	m_stp = SCTextProperties(0);
	m_stt = SCTextType(0);

	return S_OK;
}



