#ifndef SRFTOK_H
#define SRFTOK_H

#include "IcuCommon.h"		// ICU header file

class ScriptureCheckHelper;	// forward declaration for friend usage

namespace StrUtil
{
	extern void InitIcuDataDir();
};

// srftok.h - TokenStream for Scripture Reference object
// ESCES: External Scripture Checking Exchange Standard

// TokenStream is a class used by ScriptureReference and ScriptureReferenceVector
// to parse the reference data given them in String form.  
//
// All tokens are ended by white space which is ignored.
// Tokens may also be terminated by:
//      Tokens which begin with a letter or digit are terminated by the first character
//      which is not a letter or a digit.
//      Tokens which do not start with a letter or digit are terminated by the first character
//      which is a letter or a digit.
//
// If a comment character has been specified, all characters from the comment character
// to the new line inclusive are treated as a single white space.


class TokenStream
{
	friend class ScriptureCheckHelper;

public:
	TokenStream(const _TCHAR * pszTokenChars, _TCHAR cComment = 0, int iCurIndex = 0)
		: m_pszTokenChars(pszTokenChars), m_cComment(cComment), m_iCurIndex(iCurIndex)
	{
		// Needs to be called at least once, so let's be safe.
		StrUtil::InitIcuDataDir();
		m_cchStream = pszTokenChars ? strlen(pszTokenChars) : 0;
	}

	// Gets the string that lives from pos 0 to m_iCurIndex
	_TSTRING sToCur();

	// Gets next token in string form.
	// Returns empty stream if none.
	_TSTRING sNext();

	// Gets next token in string form.
	// Returns empty stream if none.
	// Different from 'sNext' in that it includes period chars at end
	_TSTRING sNextAndPeriod();

	// Peeks ahead (without advancing through stream) for next token and 
	// returns it in string form.
	_TSTRING sPeek();

	// Peeks ahead (without advancing through stream) for next token and 
	// returns it in string form.
	// Different from 'sPeek' in that it includes period chars at end
	_TSTRING sPeekAndPeriod();

	// Return a numeric value for the next token or TokenStream::Invalid if not number.
	int iNext();
	
	// Peeks ahead (without advancing through stream) for next token and returns 
	// it in int form.
	// Returns INVALID if next token is not an integer.
	int iPeek(bool bLookingForVerseNumber=false);

    // returns current position.
	int iPos()
	{
		return m_iCurIndex;
	}

    // Determines if at end of stream.
	bool bAtEnd()
	{
		return (m_pszTokenChars[m_iCurIndex] == 0);
	}

	// Gives next meaningful char.
	_TCHAR cCur()
	{
		return (sPeek().c_str())[0];
	}
	// Gives next meaningful Unicode (UCS-4) character.
	long chwCur();

	// Gives next char regardless
	_TCHAR cRawCur()
	{
		return m_pszTokenChars[m_iCurIndex];
	}
	long chwRawCur();

	const _TCHAR * pcRest()
	{
		return &m_pszTokenChars[m_iCurIndex];
	}

	// constant used for signaling invalid integer found in iPeek()
	static int INVALID;

	static bool IsPeriod(UChar32 ch);

private:
	const _TCHAR * m_pszTokenChars;		// _TCHAR array holding stream
	int m_iCurIndex;					// current positing in m_pszTokenChars
	int m_cchStream;
	_TCHAR m_cComment;					// comment character, 0 if non, applies to end of line

};

#endif // SRFTOK
