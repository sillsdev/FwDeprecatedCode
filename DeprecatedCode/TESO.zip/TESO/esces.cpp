#include "stdafx.h"
#include "esces.h"

// A misc collection of routine used by a variety of ESCES objects.


// These are the default locations for ESCES files and objects which
// are shared among multiple projects.  This would inlude
// language encoding definition files (*.lng).   The objects which are specific
// to ESCES will always be in the first directory returned i.e.:
// versification definition file, parameter definition files (*.prd),
// parameter value files (*.prv).

vector<_TSTRING> sBaseDirectories(void) {
    static vector<_TSTRING> sCache; 

    if (sCache.size() == 0) {
        char szDirectory[128];
        long cLength = sizeof(szDirectory);
        if (RegQueryValue(HKEY_LOCAL_MACHINE, "SOFTWARE\\ESCES\\Base_Directory", 
                szDirectory, &cLength) == ERROR_SUCCESS) {
			int i = strlen(szDirectory);
			if (i > 0 && szDirectory[i-1] != '/')
				strcat(szDirectory, "/");
            sCache.push_back(szDirectory);
        }
        else
            sCache.push_back("");
    }

    return sCache;
}

//! Is there some way we can use standard library routines
//  here and still automatically adapt to unicode/non-unicode versions of TCHAR?

bool bIsWS(const _TCHAR c)
{
	return ((c==' ') || (c=='	') || (c=='\n') || (c==char(13)));
}

	
bool bIsDigit(const _TCHAR c)
{
	return ((c>='0') && (c<='9'));
}


bool bIsAlpha(const _TCHAR c)
{
	return (((c>='A') && (c<='Z')) || ((c>='a') && (c<='z')) || (c == '_'));
}


