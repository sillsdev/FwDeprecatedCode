/*--------------------------------------------------------------------*//*:Ignore this sentence.
Copyright (C) 2004 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: DecodeUtf8.cpp
Responsibility: Steve McConnel
Last reviewed: Not yet.

Description:
	
----------------------------------------------------------------------------------------------*/
#include "stdafx.h"

#include "IcuCommon.h"
typedef wchar_t wchar;
typedef unsigned long ulong;
#define AssertArray(v,c)
#define Assert(x)

// This adds some utility functions from the Generic library.
#include "DecodeUtf8_i.c"

// This is the easiest way of including these utility functions from ECObjects.
#include "ECUtil.cpp"
