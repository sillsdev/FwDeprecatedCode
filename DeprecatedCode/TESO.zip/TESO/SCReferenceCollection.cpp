// SCReferenceCollection.cpp : Implementation of CSCReferenceCollection

//:> See ScriptureObjects.idl for interface information about this class

#include "stdafx.h"
#include "TESO.h"
#include "srflib.h"
#include "SCReference.h"
#include "SCReferenceCollection.h"

/////////////////////////////////////////////////////////////////////////////
// CSCReferenceCollection

//! need to validate all arguments, especically pointers.

STDMETHODIMP CSCReferenceCollection::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISCReferenceCollection
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSCReferenceCollection::get_Count(long *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	*pVal = m_vec.size();

	return S_OK;
}

STDMETHODIMP CSCReferenceCollection::Item(long index, LPVARIANT pItem)
{
	PROTECTION_BEGIN

	VariantInit(pItem);

	if (index < 1 || index > (long)m_vec.size()) {
		// Can't find it
		Error("Index out of range", IID_ISCReferenceCollection);
		return E_INVALIDARG;
	}

	pItem->vt = VT_DISPATCH;
	ISCReference* pReference;
	pReference = m_vec[index-1];

	// Copy the item's IDispatch into pItem (also implicit AddRef())
	return pReference->QueryInterface(IID_IDispatch, (void**) &(pItem->pdispVal));

	PROTECTION_END
}

STDMETHODIMP CSCReferenceCollection::Parse(BSTR bstrReferences, BSTR bstrCommentCharacter)
{
	PROTECTION_BEGIN

	ScriptureReferenceVector srv;
	HRESULT hResult;

	ReleaseAllReferences();

	USES_CONVERSION;
	TCHAR* pszReferences = OLE2T(bstrReferences);
	if (pszReferences == NULL)
		pszReferences = "";
	TCHAR* pszCommentCharacter = OLE2T(bstrCommentCharacter);
	if (pszCommentCharacter == NULL)
		pszCommentCharacter = "[";


	// To Do: there should be some way to insert an indication in the string
	//        been parsed the diversification is not 'English'.

	char err[4096];

	int iPos = srv.iParse(pszReferences, err, sizeof(err), english, *pszCommentCharacter);
	if (iPos != ScriptureReferenceVector::PARSE_SUCCESS) {
		Error(err, IID_ISCReferenceCollection);
		return E_INVALIDARG;
	}

	for (unsigned int i=0; i<srv.size(); ++i) {
		CComBSTR bstrReference(srv[i].sAsString().c_str());
		CComObject<CSCReference> *pReference;

		hResult = CComObject<CSCReference>::CreateInstance(&pReference);
		if (FAILED(hResult)) {
			Error("Could not create a SCReference", IID_ISCReferenceCollection);
			return hResult;
		}
		// Note that at this point that the ref count for the object is 0

		hResult = pReference->Parse(bstrReference);
		if (FAILED(hResult)) {
			Error("Could not reparse reference", IID_ISCReferenceCollection);
			return hResult;
		}

		hResult = Add(pReference);
		if (FAILED(hResult))
			return hResult;
	}

	return S_OK;

	PROTECTION_END
}

void CSCReferenceCollection::ReleaseAllReferences(void)
{
    // Remove any previous reference objects
    std::vector<ISCReference*>::iterator it;
    for(it = m_vec.begin(); it != m_vec.end(); it++)
        (*it)->Release();
	m_vec.clear();
}


STDMETHODIMP CSCReferenceCollection::get_AsString(BSTR *pVal)
{
	PROTECTION_BEGIN

	HRESULT hResult;
	CComBSTR bstrList("");
	CComBSTR bstrSpace(" ");
	char err[4096];

    std::vector<ISCReference*>::iterator it;
    for(it = m_vec.begin(); it != m_vec.end(); it++) {
		BSTR bstr;
		hResult = (*it)->get_AsString(&bstr);
		if (FAILED(hResult)) {
			Error("Could not covert reference", IID_ISCReferenceCollection);
			return E_FAIL;
		}
		bstrList += bstr;
		bstrList += bstrSpace;
		SysFreeString(bstr);
	}

	USES_CONVERSION;
	TCHAR* pszReferences = OLE2T(bstrList);
	ScriptureReferenceVector srv;
	int iPos = srv.iParse(pszReferences, err, sizeof(err));
	if (iPos != ScriptureReferenceVector::PARSE_SUCCESS) {
		Error(err, IID_ISCReferenceCollection);
		return E_INVALIDARG;
	}

	CComBSTR bstrResult(srv.sAsString().c_str());
	*pVal = bstrResult.Copy();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCReferenceCollection::Add(ISCReference *pSCReference)
{
	PROTECTION_BEGIN

	m_vec.push_back(pSCReference);
	pSCReference->AddRef();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCReferenceCollection::Insert(ISCReference *pSCReference)
{
	PROTECTION_BEGIN

	HRESULT hResult;

    std::vector<ISCReference*>::iterator it;
	long iNewVerse;
	hResult = pSCReference->get_BBCCCVVV(&iNewVerse);
	if (FAILED(hResult)) {
		Error("Could not BBCCCVVV reference", IID_ISCReferenceCollection);
		return E_FAIL;
	}

	for (it = m_vec.begin(); it != m_vec.end(); it++) {
		long iCurrentVerse;
		hResult = (*it)->get_BBCCCVVV(&iCurrentVerse);
		if (FAILED(hResult)) {
			Error("Could not BBCCCVVV reference", IID_ISCReferenceCollection);
			return E_FAIL;
		}
		if (iNewVerse <= iCurrentVerse)
			break;
	}

	m_vec.insert(it, pSCReference);
	pSCReference->AddRef();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCReferenceCollection::Remove(long index)
{
	PROTECTION_BEGIN

	if (index < 1 || index > (long)m_vec.size()) {
		// Can't find it
		Error("Index out of range", IID_ISCReferenceCollection);
		return E_INVALIDARG;
	}

	m_vec.erase(m_vec.begin() + (index-1));
	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCReferenceCollection::get__NewEnum(LPUNKNOWN *pVal)
{
	PROTECTION_BEGIN

    long lCount = m_vec.size();

    // Temporary array to hold the objects
    VARIANT* var = new VARIANT[lCount];
    std::vector<ISCReference*>::iterator it;
    int i = 0;

    // Fill the temporary array with the objects
    for (it = m_vec.begin(); it != m_vec.end(); it++, i++) {
        ISCReference* pReference = *it;

        VariantInit(&var[i])                                                                                                                                                                                        ;
        var[i].vt = VT_DISPATCH;

        // VARIANT holds IDispatch pointer, also QI AddRef()s the objects
        pReference->QueryInterface(IID_IDispatch, (void**)&(var[i].pdispVal));
    }

    // Do this typedef to make the following code readable!
    // We need a VARIANT enumerator
    typedef CComObject< CComEnum< IEnumVARIANT, &IID_IEnumVARIANT, VARIANT, _Copy<VARIANT> > > EnumVar;

    // Create a new instance of the object
    EnumVar* pVar = new EnumVar;

    // Initialize it with the objects, a copy will be made
    pVar->Init(&var[0], &var[i], NULL, AtlFlagCopy);

    // Now release the objects put in the temporary array
    while(lCount-- > 0) {
        VariantClear(&var[lCount]);
    }
    delete [] var;

    // Return the IUnknown for the enumerator
    pVar->QueryInterface(IID_IUnknown, (void**)pVal);

    // We do not delete pVar, this is not a leak!

    return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCReferenceCollection::Includes(ISCReference *pSCReference, BOOL *fVal)
{
	PROTECTION_BEGIN

	HRESULT hResult;

	*fVal = 0;

	if (m_vec.size() & 1) {
		Error("Odd number of references", IID_ISCReferenceCollection);
		return E_INVALIDARG;
	};

    std::vector<ISCReference*>::iterator it;
	long iNewVerse;
	hResult = pSCReference->get_BBCCCVVV(&iNewVerse);
	if (FAILED(hResult)) {
		Error("Could not BBCCCVVV reference", IID_ISCReferenceCollection);
		return E_FAIL;
	}

	for (it = m_vec.begin(); it != m_vec.end(); it++) {
		long iFirst, iLast;
		hResult = (*it)->get_BBCCCVVV(&iFirst);
		if (SUCCEEDED(hResult)) {
			++it;
			hResult = (*it)->get_BBCCCVVV(&iLast);
		}
		if (FAILED(hResult)) {
			Error("Could not BBCCCVVV reference", IID_ISCReferenceCollection);
			return E_FAIL;
		}
		if (iNewVerse < iFirst)
			break;
		if (iNewVerse >= iFirst && iNewVerse <= iLast) {
			*fVal = -1;
			break;
		}
	}

	return S_OK;

	PROTECTION_END
}


void CSCReferenceCollection::FinalRelease()
{
	ReleaseAllReferences();
}

