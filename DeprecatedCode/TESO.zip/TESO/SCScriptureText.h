// SCScriptureText.h : Declaration of the CSCScriptureText

#ifndef __SCSCRIPTURETEXT_H_
#define __SCSCRIPTURETEXT_H_

#include "resource.h"       // main symbols
#include "SimpleTKWrapper.h"
#include "TKAndCodePageWrapper.h"
#include "ExtFileInfo.h"
//#include "c:\dev\fw\lib\src\ecobjects\ECObjects.h"		// types...
#include "../ECObjects/ECObjects.h"		// types...
//#include "c:\Dev\Projects\NewEscesWork_VS7_Attempt\Shared\Src\ScriptureObjects\TESO.h"		// types...
//#import "c:\dev\fw\distfiles\scriptureobjects.dll" no_namespace raw_interfaces_only
//#include "scriptureobjects.h"


typedef std::map< _TSTRING, _TSTRING>				TMapMarkerToID;
typedef std::map< _TSTRING, CTKAndCodePageWrapper*> TMapIDToConverter;


// Holds all types of information about markers/tags defined in the
// style sheet.
class MarkerInfo{ 
public:
	// Text of marker, e.g. ID
    _TSTRING m_sMarker; 

	// Text type, e.g. VerseText
    SCTextType m_stt;  

	// Text properties, e.g., vernacular, publishable.
    SCTextProperties m_stp;

	// Style types, e.g. paragraph, character, note.
	ScriptureStyleType m_sst;
 
	// Mathing marker "Note" <-> "EndNote"
	_TSTRING m_sAssocMarker;       

	// This is begin marker and there is an associate end marker.
    bool m_bIsEnd;                 

	// Default constructor.
	MarkerInfo() {
		m_stt = (SCTextType)0;  
		m_stp = (SCTextProperties)0;
		m_sst = (ScriptureStyleType)0;
		m_bIsEnd = false;
	}

    }; // hungarian: mi




/////////////////////////////////////////////////////////////////////////////
// CSCScriptureText
class ATL_NO_VTABLE CSCScriptureText : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSCScriptureText, &CLSID_SCScriptureText>,
	public ISupportErrorInfo,
	public IErrorInfo,
	public IDispatchImpl<ISCScriptureText4, &IID_ISCScriptureText4, &LIBID_TESOLib>
{
public:
	CSCScriptureText()
	{
		m_hMapin = 0;
	    m_hMapout = 0;
		m_ecProject = 0;
		m_fAsteriskIsMarker = false;
		m_bHasExtFile = false;
		m_bNewBooksPresent = false;
		m_EatEscapeBackslash = false;			// default behaviour for PT
		m_LastTokenType = unknowntt;			// not known yet...

//		m_ErrorGuid = 0;
		m_cbstrErrorSource = "";
		m_cbstrErrorDescription = "";
		m_cbstrHelpFile = "";
		m_ErrorHelpContext = 0;
	}

	~CSCScriptureText()
	{
		if (m_hMapin)
			CCUnloadTable(m_hMapin);

		if (m_hMapout)
			CCUnloadTable(m_hMapout);

		if ( HasNewBooksPresentChanged() )
			Save( m_cbstrXMLFileName );

		if ( m_ecProject )					// remove the ECProject pointer
			m_ecProject = NULL;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCSCRIPTURETEXT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSCScriptureText)
	COM_INTERFACE_ENTRY(ISCScriptureText)
	COM_INTERFACE_ENTRY(ISCScriptureText2)
	COM_INTERFACE_ENTRY(ISCScriptureText3)
	COM_INTERFACE_ENTRY(ISCScriptureText4)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IErrorInfo)
END_COM_MAP()

public:
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IErrorInfo
	STDMETHOD(GetGUID)(GUID *guid);
	STDMETHOD(GetSource)(BSTR* bstr);
	STDMETHOD(GetDescription)(BSTR* bstr);
	STDMETHOD(GetHelpFile)(BSTR* bstr);
	STDMETHOD(GetHelpContext)(DWORD *dwContext);

// ISCScriptureText
public:
	STDMETHOD(get_ErrorDataString)(/*[out,retval]*/BSTR* bstr);
	STDMETHOD(LoadECObjectDataForSOReading)(/*[in]*/ VARIANT pSafeArrayOfBytes );
	STDMETHOD(SetParameterValue)(/*[in]*/ BSTR bstrName, /*[in]*/ BSTR bstrValue);
	STDMETHOD(GetParameterValue)(/*[in]*/ BSTR bstrName, /*[out, retval]*/ BSTR *pbstrValue);
	STDMETHOD(FileName)(
		/*[in]*/ ISCReference *pSCReference, 
		/*[in]*/ ISCReference *pSCReferenceFirst, 
		/*[in]*/ ISCReference *pSCReferenceLast, 
		/*[in]*/ int fAlwaysReturnName,  
		/*[out, retval]*/ BSTR *bstrFileName);
	STDMETHOD(NthFileName)(
		/*[in]*/ int iFileNumber, 
		/*[in]*/ ISCReference *pSCReferenceFirst, 
		/*[in]*/ ISCReference *pSCReferenceLast, 
		/*[out, retval]*/ BSTR *bstrFileName);
	STDMETHOD(NthTag)(
		/*[in]*/ int iTagNumber, 
		/*[out,retval]*/ ISCTag **ppTag);
	STDMETHOD(TagIndex)(
			/*[in]*/ BSTR bstrTagName,
			/*[out, retval]*/ int *piNth);

	STDMETHOD(Save)(BSTR bstrFileName);
	STDMETHOD(Load)(BSTR bstrFileName);

	STDMETHOD(get_TextsPresent)(/*[out, retval]*/ BSTR *pVal);

#if 0
	STDMETHOD(TextEnumEx)(
			/*[in]*/ ISCReference *pSCReferenceFirst,
			/*[in]*/ ISCReference *pSCReferenceLast,
			/*[out,retval]*/ ISCTextEnumEx **ppISCTextEnumEx
			);
#endif

#if 0
	STDMETHOD(GetBooksForFile)(
			/*[in]*/ BSTR bstrFileName,			// "fullpath and filename of file"
			/*[in]*/ BSTR bstrBookMarker,		// "\id"
			/*[out,retval]*/ VARIANT* pSafeArray
////			/*[out]*/ SAFEARRAY * shortArray		// safearray of shorts
///			/*[out]*/ BSTR* pbstrBookIDs,	// all of the books...
///			/*[in,out]*/ short* psBookIDs,		// all of the books
///			/*[out]*/ short* psNumBooks		// number of books in psBookIDs
			);
#endif

	STDMETHOD(TextEnum)(
			/*[in]*/ ISCReference *pSCReferenceFirst,
			/*[in]*/ ISCReference *pSCReferenceLast,
			/*[in]*/ SCTextType sttFilter,
			/*[in]*/ SCTextProperties stpSmushing,
			/*[out,retval]*/ ISCTextEnum **ppISCTextEnum
			);

	STDMETHOD(GetText)(
			/*[in]*/ ISCReference *pSCReferenceFirstChapter,
			/*[in]*/ BOOL fSingleChapter,
			/*[in]*/ BOOL fDoMapin,  
			/*[out, retval]*/ BSTR *pbstrText
			);
	STDMETHOD(PutText)(
			/*[in]*/ ISCReference *pSCReferenceFirstChapter,
			/*[in]*/ BOOL fSingleChapter,
			/*[in]*/ BOOL fDoMapout,  
			/*[in]*/ BSTR bstrText
			);

	//STDMETHOD(LockText)(
	//		/*[in]*/ ISCReference *pSCReferenceFirstChapter,
	//		/*[in]*/ BOOL fSingleChapter,
	//				// True - Lock a single chapter
	//				// False - Lock entire book
	//		/*[in]*/ BOOL fWaitForLock
	//		);
	//STDMETHOD(UnlockText)(
	//		/*[in]*/ ISCReference *pSCReferenceFirstChapter,
	//		/*[in]*/ BOOL fSingleChapter
	//				// True - Lock a single chapter
	//				// False - Lock entire book
	//		);

	HRESULT SetNaming(
		CComBSTR cbstrPrePart, 
		CComBSTR cbstrPostPart, 
		CComBSTR cbstrBookNameForm, 
			// Must be MAT, 40, or 40MAT
		CComBSTR cbstrChapterNumberForm
			// Must be "", "1", or "01"
		);

	HRESULT SetHasExtFile( bool hasExtFile=true ) { m_bHasExtFile = hasExtFile; return S_OK; }
	HRESULT SaveExtFileInfo( CExtFileInfo *pefi ) { m_vecEFI.push_back(pefi); return S_OK; }


	HRESULT InsertRangeToFile(RangeToFile &rtfToInsert);
		// places the parameter in the lrtfFileList for this text,
		// returns false if unsuccessful (e.g. if overlapping sections)

#if 0

For now I think we will disconnect all the language
related stuff from the ScriptureObjects
because it make it is easier if they do not depend on eacn other.

	STDMETHOD(get_CharacterPropertyEngine)(
			/*[out,retval]*/ /*ILgCharacterPropertyEngine*/ IUnknown **pp
			);
	STDMETHOD(get_CollatingEngine)(
			/*[out,retval]*/ /*ILgCollatingEngine*/ IUnknown **pp
			);
#endif

	STDMETHOD(CharToWChar)(unsigned char* pszIn, BSTR* pbstr);
		// Convert 8-bit encoded string to Unicode.
		// Based on Encoding parameter of Scripture Text.

	STDMETHOD(get_BooksPresent)(BSTR *pbstr);
	STDMETHOD(put_BooksPresent)(BSTR bstr);

	STDMETHOD(get_CodePage)(int *piVal);
	STDMETHOD(put_CodePage)(int iVal);

	STDMETHOD(get_Encoding)(BSTR *pbstr);
	STDMETHOD(put_Encoding)(BSTR bstr);

	STDMETHOD(get_DefaultFont)(BSTR *pbstr);
	STDMETHOD(put_DefaultFont)(BSTR bstr);

	STDMETHOD(get_DefaultFontSize)(int *piVal);
	STDMETHOD(put_DefaultFontSize)(int iVal);

	STDMETHOD(get_Directory)(BSTR *pbstr);
	STDMETHOD(put_Directory)(BSTR bstr);

	STDMETHOD(get_Editable)(BOOL *pfVal);
	STDMETHOD(put_Editable)(BOOL fVal);

	STDMETHOD(get_FileNameForm)(BSTR *pbstr);
	STDMETHOD(put_FileNameForm)(BSTR bstr);

	STDMETHOD(get_FileNamePostPart)(BSTR *pbstr);
	STDMETHOD(put_FileNamePostPart)(BSTR bstr);

	STDMETHOD(get_FileNamePrePart)(BSTR *pbstr);
	STDMETHOD(put_FileNamePrePart)(BSTR bstr);

	STDMETHOD(get_FileNameChapterNumberForm)(BSTR *pbstr);
	STDMETHOD(put_FileNameChapterNumberForm)(BSTR bstr);

	STDMETHOD(get_FullName)(BSTR *pbstr);
	STDMETHOD(put_FullName)(BSTR bstr);

	STDMETHOD(get_Language)(BSTR *pbstr);
	STDMETHOD(put_Language)(BSTR bstr);

	STDMETHOD(get_LeftToRight)(BOOL *pfVal);
	STDMETHOD(put_LeftToRight)(BOOL fVal);

	STDMETHOD(get_Name)(BSTR *pbstr);
	STDMETHOD(put_Name)(BSTR bstr);

	STDMETHOD(get_SettingsDirectory)(BSTR *pbstr);

	STDMETHOD(get_StyleSheet)(BSTR *pbstr);
	STDMETHOD(put_StyleSheet)(BSTR bstr);

	STDMETHOD(get_Versification)(SCVersification *pVal);
	STDMETHOD(put_Versification)(SCVersification newVal);

	STDMETHOD(get_AsteriskIsMarker)(BOOL *pfVal);

	// Convert Unicode string to  8 bit string
	// Based on Encoding parameter of Scripture Text.
	// Returned string must be freed like:
	//
	//       char* p = WCharToChar(qbstr);
	//       ...
	//	     free[] p;
	char* WCharToChar(BSTR bstrIn);
	char* GetCharText( ISCReference *pSCReferenceFirst, ISCReference *pSCReferenceLast);

	// If no mapout.cct file present for this text,
	// return pszIn.
	// Otherwise, return the result of processing the pszIn
	// string thru mapout.cct.
	// Returned string [if not pszIn] must be freed like:
	//
	//       char* p = WCharToChar(qbstr);
	//       ...
	//	     free[] p;
	//
	char* Mapout(char* pszIn);
	char* Mapin(char* pszIn);

	bool EatEscapeBackslashes()	{ return m_EatEscapeBackslash; }

private:
	// Build maps which met text strings to property values e.g. "title" -> scTitle
	void InitPropertyMaps();

	// IErrorInfo data
	GUID m_ErrorGuid;
    CComBSTR m_cbstrErrorSource;
    CComBSTR m_cbstrErrorDescription;
    CComBSTR m_cbstrHelpFile;
	DWORD m_ErrorHelpContext;

	//:> These variables hold the information that determines how text files
	//:>  are named.

	// Text of Scripture filename appearing before the book identifier
	CComBSTR m_cbstrPrePart; 

	// Text of Scripture filename appearing after book identifier
	CComBSTR m_cbstrPostPart; 

	// Form of book identifier i.e., MAT, 40, or 40MAT
	CComBSTR m_cbstrBookNameForm; 

	// Form of chapter number, must be "", "1", or "01"
	CComBSTR m_cbstrChapterNumberForm;

	// Full paths name of .ssf file
	CComBSTR m_cbstrXMLFileName;

	// Boolean set based on the use of the ExtFile attributes
	bool m_bHasExtFile;
	bool HasExtFile() { return m_bHasExtFile; }

	// Boolean set based on the books present varaible and if it is changed: allows
	// the file to auto maintain that list based on the contents of the extfile vars
	bool m_bNewBooksPresent;
	bool HasNewBooksPresentChanged() { return m_bNewBooksPresent; }

	// Encoding used for .ssf file
	enum EncodingName m_enEncoding;

	// map containing property names and values from this .scr file.
    // Used by sGetParameterValue().
	map<CComBSTR, CComBSTR> m_PropMap;	

	// this text's versification
	SCVersification m_iMyVersification;

	// Handle to compiled CC tables for Mapin, 0 if not present.
	HANDLE m_hMapin;

	// Handle to compiled CC tables for Mapin, 0 if not present.
	HANDLE m_hMapout;

	// TECkit table or CodePage
	CTKAndCodePageWrapper m_TEC;

	//:> Cached values for related objects.
    //:> LanguageEncoding* m_plng;
    //:> WordList* m_pwdl;
	//:> LexicalRenderingMap* m_plex;
	
	// map from marker (e.g. ID) to associated marker info 
    // (including associated attributes)
	map<_TSTRING, MarkerInfo> m_MarkerTextProp;

	// Tag definitions read from .sty file
	vector<CComPtr<ISCTag> > m_vTags;

	// Table mapping references to filenames.
	vector<RangeToFile> m_vecrtf;

	// SFM markers for chapters and verses.  Does not include \.
	_TSTRING m_sChapterMarker;
	_TSTRING m_sVerseMarker;

	// True if an asterisk occuring all by itself should be considered a marker
	bool m_fAsteriskIsMarker;

    //------------------------------------------------------------------
    //:> Private data and functions for manipulating stylesheets and DTD's
    //------------------------------------------------------------------

	// Read the Partext .sty style sheet using three maps immediately below.
    // Construct the m_MarkerTextProp map based on the style sheet.
    HRESULT ReadSTY(const char *pchFileName);

	// Compute the name of the file containing the specified book and chapter reference
	CComBSTR cbstrTextFileName(int iBook, int iChapter);

	// Info on external files and what scripture references are in them
	vector<CExtFileInfo*> m_vecEFI;

	// Fill table (m_vecrtf) which maps references to filenames
	HRESULT SetupFileInfo(CComBSTR cbstrDirectory);

	// Read the definition for a single style sheet marker
	HRESULT ReadSTYMarkerEntry(_TSTRING& sToken, ScrTokenType& tt, ifstream& InputFile);

	// Compute pathname for the settings directory based on registry settings
	CComBSTR SettingsDirectory(void);

	// Compute pathname for the text directory based on registry settings
	// and text name.
	CComBSTR TextDirectory(void);

	// Compute full pathname for .ssf supplying name of settings directory and .ssf extension as needed.
	CComBSTR FullPathName(BSTR bstrFileName);

	// Compile mapin.cct and mapout.cct if present.
	HRESULT CompileMapFiles();

	STDMETHODIMP ValidateChapterNumbers(
						char* pPrePart, char* pMapoutResult, char* pPostPart,
						vector<RangeToFile>::iterator rtfi);

	TMapMarkerToID		m_IDMap;
	TMapIDToConverter	m_ConverterMap;

	bool m_EatEscapeBackslash;		// set in the .ssf file and used in the parser to not 
										//  interpret "\" as a marker in the middle of lines

	ScrTokenType m_LastTokenType;		// keep the previous token type for processing.

//	CComPtr<IUnknown> m_ecProject;	// TE : future pointer to ECProject for reading from byte array
	CComPtr<IECProject> m_ecProject;	// TE : future pointer to ECProject for reading from byte array

#if 0
	//------------------------------------------------------------------
    //:>  Private data and functions for manipulating languages
    //------------------------------------------------------------------

	// Language engine for the scripture text
	CComPtr<IUnknown> m_qSCLanguageEngine;
#endif
};

#endif //__SCSCRIPTURETEXT_H_
