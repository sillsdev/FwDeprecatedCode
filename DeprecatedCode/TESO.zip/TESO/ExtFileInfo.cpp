//	ExtFileInfo.h : Declaration of the CExtFileInfo class
//
//	Used to contain file data from the .SSF file and to be inserted
//	into the range to file structure in the Scripture Objects.
//
//	Created 7/1/02
//
#include "stdafx.h"
#include "ExtFileInfo.h"

#if 0 //def _DEBUG

CExtFileInfo::CExtFileInfo() :  DEBUG_TRACECREATION_IMPLEMENT( "CExtFileInfo" ),
 mFirst(NULL), mLast(NULL), mPath(NULL),
	mFirstRefType(EFI_Unknown), mLastRefType(EFI_Unknown), mAllTypeInfo(0)
{
	mID = rand();
///	ATLTRACE("== <%5d> CExtFileInfo::CExtFileInfo()\n", mID);
}
CExtFileInfo::CExtFileInfo( const CExtFileInfo & other ) : DEBUG_TRACECREATION_IMPLEMENT( "CExtFileInfo" ),
	mID(0)
{
	mID = rand();
	ATLTRACE("== <%5d> CExtFileInfo::CExtFileInfo( copy - Shouldn't be here...! )\n", mID);
}

#else

CExtFileInfo::CExtFileInfo() : mFirst(NULL), mLast(NULL), mPath(NULL),
	mFirstRefType(EFI_Unknown), mLastRefType(EFI_Unknown), mAllTypeInfo(0)
{
	mID = rand();
///	ATLTRACE("== <%5d> CExtFileInfo::CExtFileInfo()\n", mID);
}
CExtFileInfo::CExtFileInfo( const CExtFileInfo & other )
{
	mID = rand();
	ATLTRACE("== <%5d> CExtFileInfo::CExtFileInfo( copy - Shouldn't be here...! )\n", mID);
}

#endif

CExtFileInfo::~CExtFileInfo()
{
	::SysFreeString( mFirst ); 
	::SysFreeString( mLast );
	::SysFreeString( mPath );

///	ATLTRACE("== <%5d> CExtFileInfo::~CExtFileInfo()\n", mID);
}

void CExtFileInfo::SetRef ( EFI_TYPES firstlast, EFI_TYPES refinfo, const wchar_t *ref )
{ 
	mAllTypeInfo |= firstlast;
	mAllTypeInfo |= refinfo;

	if ( firstlast & EFI_First )
	{
		if ( mFirst ) ::SysFreeString( mFirst );
		mFirst = ::SysAllocString( ref );
		mFirstRefType = refinfo;
	}
	else
	{
		if ( mLast ) ::SysFreeString( mLast );
		mLast = ::SysAllocString( ref );
		mLastRefType = refinfo;
	}
}


