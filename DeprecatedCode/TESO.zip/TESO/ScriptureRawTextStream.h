
//:> ScriptureRawTextStream

/*
Allow the user to sequentially access the contents of text files in this scripture text
as a series of input streams.
If a mapin.cct file is present, apply this mapping to the characters in the files before
the user reads them.

@code{
	ScriptureRawTextStream srts(vecrtf, 0);
	ScriptureReference srf;

	... set srf to desired starting reference, e.g. GEN 1:1

	// output all characters in scripture text to standard output
	srts.OpenFile(srf, true);
	while (!srts.m_bEOS) {
		char c;
		while (srts.get(c)) cout.put(c);
		srts.OpenNextFile();
	}
}

*/

class RangeToFile;

class ScriptureRawTextStream: public istringstream {

	bool m_fIsOpen;
		// True if the last attempt to open a file suceeded

	HANDLE m_hCCTable;
		// Handle to compiled CC table, 0 if none.

	void open(char*, int);
		// Open the named file with the specified input mode.
	
	vector<RangeToFile>& m_vecrtf;
		// Info on what scripture references are in each file.


	int iSize();

private:
	char * ProcessInlineFootNotes( char * inBuf );

public:
    vector<RangeToFile>::iterator m_rtfi;
        // pointer to current file in list of files in this text.

	// @param vecrtf Table mapping references to file names.
	// @param hCCTable Compiled CC table used to preprocess text, 0 if none.
	ScriptureRawTextStream(vector<RangeToFile>& vecrtf, HANDLE hCCTable);


	// Open the file from the scripture text containing the specified reference.
	// When fFirstAvailable true we are looking for first text at or beyond
	// specified reference, otherwise we must find a file that explicitly
	// includes the reference in order to succeed.
	void OpenFile(ScriptureReference srf, bool fFirstAvailable);

	// Open the next file in canonical order.
	void OpenNextFile(void);

	// @return The name of the most recently opened file
	CComBSTR CurrentFileName(void);

    bool m_bEOS;
        // True when end of all files in text reached.

	void close(void) {}

	// @return True when the last OpenFile/OpenNextFile succeeded.
	bool is_open(void) {return m_fIsOpen;}
	
}; // hungarian: srts

