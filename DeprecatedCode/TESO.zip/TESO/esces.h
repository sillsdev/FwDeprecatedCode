#ifndef ESCES_H
#define ESCES_H

// esces.h -- Exteral Scripture Checking Exchange Standard
//
// This is the standard header file for ESCES.  It includes all the files
// necessary to use the ESCES checking routines.

#pragma warning(disable : 4786)
#pragma warning(disable : 4800)
#pragma warning(disable : 4530)     // !! can this be ignored???

#include <string>
#include <set>
#include <vector>   
#include <map>
#include <deque>
#include <fstream>
#include <list>
#include <cassert>


// Setup basic typedefs which determine whether we are operating
// in a UNICODE environment.

#include <TCHAR.H>

using namespace std;

typedef basic_string<_TCHAR> _TSTRING;

// Error Codes

#define ESCES_E_SYNTAX_ERROR           MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 513)


// Common routines not associated with any single object
// Code for these is in esces.cpp

vector<_TSTRING> sBaseDirectories(void);
    // These are the default locations for ESCES files and objects which
    // are shared among multiple projects.  This would inlude
    // language encoding definition files (*.lng).   The objects which are specific
    // to ESCES will always be in the first directory returned i.e.:
    // versification definition file (*.vrs), parameter definition files (*.prd),
    // parameter value files (*.prv).

#endif // ESCES_H
