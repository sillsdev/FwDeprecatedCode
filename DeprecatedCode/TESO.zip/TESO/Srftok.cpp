#include "stdafx.h"
#include "esces.h"
#include "srftok.h"
// functions from the FieldWorks Generic library
extern long DecodeUtf8(const char * rgchUtf8, int cchUtf8, int & cbOut);
extern int Utf8NumberToInt(const char * pch, int cch);
///#include "IcuCommon.h"		// ICU header file

// srftok.cpp - Implemenation of Token Stream object
// ESCES: External Scripture Checking Exchange Standard

int TokenStream::INVALID = -1;

#if defined(_UNICODE) || defined(UNICODE)
#error roll over and die
#endif

// void IsPeriod(UChar32 ch)
//	This method would be beter if it could use a binary property, but none has
//	been found for the period.
//	This function returns true if the passed in character is a 'period' character:
//	as defined by the code points in this method.

bool TokenStream::IsPeriod(UChar32 ch)
{
	int periods[] = { 0x2e,		// period, full stop, dot, decimal point
					  0x6d4,	// arabic full stop
					  0x3002,	// idographic full stop
					  0 };
	for (int i=0; periods[i] != 0; i++)
		if (ch == periods[i])
			return true;

	return false;
}


/*----------------------------------------------------------------------------------------------
	_TSTRING sToCur();
	sToCur():Gets the string that lives from pos 0 to m_iCurIndex.
----------------------------------------------------------------------------------------------*/
_TSTRING TokenStream::sToCur()
{
	_TSTRING sBuf = _T("");
	for (int ich = 0; ich < m_iCurIndex; ++ich)
		sBuf += m_pszTokenChars[ich];

	return sBuf;
}

/*----------------------------------------------------------------------------------------------
	sNext():Gets next token in string form.
	Returns empty string at end.
----------------------------------------------------------------------------------------------*/
_TSTRING TokenStream::sNext()
{
	_TSTRING sBuf;
	bool bInComment = false;

	UChar32 ch = 0;
	int cchUsed;

	// read through whitespace and comments
	while (m_iCurIndex < m_cchStream)
	{
		if (m_pszTokenChars[m_iCurIndex] == 0)	// probably redundant now...
			return sBuf;

		ch = DecodeUtf8(m_pszTokenChars + m_iCurIndex, m_cchStream - m_iCurIndex, cchUsed);
		if (bInComment)
		{
			if (ch == '\n')
				bInComment = false;
		}
		else
		{
			if (ch == m_cComment)
				bInComment = true;
			else if (!u_isspace(ch))
				break;
		}
		m_iCurIndex += cchUsed;

//-		if (bInComment)
//-		{
//-			if (cRawCur() == '\n')
//-				bInComment = false;
//-		}
//-		else
//-		{
//-			if (cRawCur() == m_cComment)
//-				bInComment = true;
//-			else if (!isascii(cRawCur()) || !isspace(cRawCur()))
//-				break;
//-		}
//-		++m_iCurIndex;
	}

    // TokenStream behavior: if initial character is alpha numeric, get alphanumerics.
	//                       if initial character is not alphanum, get non alphanums

#define ALPHNUM(x) (u_isalnum(x) || (x) == '_')

	if (ALPHNUM(ch))
	{
		while (m_iCurIndex < m_cchStream)
		{
			ch = DecodeUtf8(m_pszTokenChars + m_iCurIndex, m_cchStream - m_iCurIndex, cchUsed);
			if (!cchUsed || !ALPHNUM(ch))
				break;
			for (int ich = 0; ich < cchUsed; ++ich)
				sBuf += m_pszTokenChars[m_iCurIndex + ich];
			m_iCurIndex += cchUsed;
		}
	}
	else
	{
		while (m_iCurIndex < m_cchStream)
		{
			ch = DecodeUtf8(m_pszTokenChars + m_iCurIndex, m_cchStream - m_iCurIndex, cchUsed);
			if (!cchUsed || u_isspace(ch) || ALPHNUM(ch))
				break;
			for (int ich = 0; ich < cchUsed; ++ich)
				sBuf += m_pszTokenChars[m_iCurIndex + ich];

///			// treat peroid chars specially (8/04), just eat them
///			if (IsPeriod(ch))
///				break;
			
			m_iCurIndex += cchUsed;
		}
	}

//-#define ALPHNUM(x) (isdigit(x) || isalpha(x) || (x) == '_')
//-
//-	if (ALPHNUM(cRawCur()))
//-	{
//-		while ((! bAtEnd()) && (! isspace(cRawCur())) && (ALPHNUM(cRawCur())))
//-			sBuf += m_pszTokenChars[m_iCurIndex++];
//-	}
//-	else
//-	{
//-		while ((! bAtEnd()) && (! isspace(cRawCur())) && (!ALPHNUM(cRawCur())))
//-			sBuf += m_pszTokenChars[m_iCurIndex++];
//-	}

    return sBuf;
}

// Peeks ahead (without advancing through stream) for next token and returns it in string form.
_TSTRING TokenStream::sPeek()
{
	int iSaveIndex = m_iCurIndex;
	_TSTRING sToReturn = sNext();
	m_iCurIndex = iSaveIndex;
	return sToReturn;
}

// Peeks ahead (without advancing through stream) for next token and returns it in string form.
_TSTRING TokenStream::sPeekAndPeriod()
{
	int iSaveIndex = m_iCurIndex;
	_TSTRING sToReturn = sNextAndPeriod();
	m_iCurIndex = iSaveIndex;
	return sToReturn;
}

// returns number only
int TokenStream::iNext()
{
	int iToReturn = iPeek();
	if (iToReturn != INVALID)
        sNext();
	return iToReturn;
}

// Peeks ahead (without advancing through stream) for next token and returns it in int form.
int TokenStream::iPeek(bool bLookingForVerseNumber/*=false*/)
{
	_TSTRING sPeeked = bLookingForVerseNumber ? sPeekAndPeriod() : sPeek();

	// if is empty or contains non digit characters, then it's invalid
    if (!sPeeked[0])
        return INVALID;
	const char * pch = sPeeked.data();
	int cch = sPeeked.length();
	int cchUsed;
	for (int i = 0; i < cch; i += cchUsed)
	{
		UChar32 ch = DecodeUtf8(pch + i, cch - i, cchUsed);
		if (!cchUsed)
			break;
		if (!u_isdigit(ch))
			return INVALID;
	}
	return Utf8NumberToInt(sPeeked.data(), sPeeked.length());
}

/*----------------------------------------------------------------------------------------------
	Return the next "meaningful" Unicode (UCS-4) character.
----------------------------------------------------------------------------------------------*/
long TokenStream::chwCur()
{
	_TSTRING sPeeked = sPeek();
	if (!sPeeked[0])
		return 0;
	int cchUsed;
	UChar32 ch = DecodeUtf8(sPeeked.data(), sPeeked.length(), cchUsed);
	if (!cchUsed)
		return 0;
	else
		return ch;
}

/*----------------------------------------------------------------------------------------------
	Return the next Unicode (UCS-4) character.
----------------------------------------------------------------------------------------------*/
long TokenStream::chwRawCur()
{
	int cchUsed;
	UChar32 ch = DecodeUtf8(m_pszTokenChars + m_iCurIndex, m_cchStream - m_iCurIndex, cchUsed);
	if (!cchUsed)
		return 0;
	else
		return ch;
}

/*----------------------------------------------------------------------------------------------
	sNext():Gets next token in string form.
	Returns empty string at end.
----------------------------------------------------------------------------------------------*/
_TSTRING TokenStream::sNextAndPeriod()
{
	_TSTRING sBuf;
	bool bInComment = false;

	UChar32 ch = 0;
	int cchUsed;

	// read through whitespace and comments
	while (m_iCurIndex < m_cchStream)
	{
		if (m_pszTokenChars[m_iCurIndex] == 0)	// probably redundant now...
			return sBuf;

		ch = DecodeUtf8(m_pszTokenChars + m_iCurIndex, m_cchStream - m_iCurIndex, cchUsed);
		if (bInComment)
		{
			if (ch == '\n')
				bInComment = false;
		}
		else
		{
			if (ch == m_cComment)
				bInComment = true;
			else if (!u_isspace(ch))
				break;
		}
		m_iCurIndex += cchUsed;
	}

    // TokenStream behavior: if initial character is alpha numeric, get alphanumerics and period.
	//                       if initial character is not alphanum, get non alphanums

#define ALPHNUM(x) (u_isalnum(x) || (x) == '_')

	if (ALPHNUM(ch))
	{
		while (m_iCurIndex < m_cchStream)
		{
			ch = DecodeUtf8(m_pszTokenChars + m_iCurIndex, m_cchStream - m_iCurIndex, cchUsed);
			if (!cchUsed || (!ALPHNUM(ch) && !IsPeriod(ch)))
				break;
			for (int ich = 0; ich < cchUsed; ++ich)
				sBuf += m_pszTokenChars[m_iCurIndex + ich];
			m_iCurIndex += cchUsed;
		}
	}
	else
	{
		while (m_iCurIndex < m_cchStream)
		{
			ch = DecodeUtf8(m_pszTokenChars + m_iCurIndex, m_cchStream - m_iCurIndex, cchUsed);
			if (!cchUsed || u_isspace(ch) || ALPHNUM(ch))
				break;
			for (int ich = 0; ich < cchUsed; ++ich)
				sBuf += m_pszTokenChars[m_iCurIndex + ich];

			// treat peroid chars specially (8/04), just eat them
			if (IsPeriod(ch))
				break;
			
			m_iCurIndex += cchUsed;
		}
	}

    return sBuf;
}

