// SCTextEnum.h : Declaration of the CSCTextEnum

//:> See ScriptureObjects.idl for interface information about this class


#ifndef __SCTEXTENUM_H_
#define __SCTEXTENUM_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSCTextEnum
class ATL_NO_VTABLE CSCTextEnum : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSCTextEnum, &CLSID_SCTextEnum>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISCTextEnum, &IID_ISCTextEnum, &LIBID_TESOLib>
{
public:
	CSCTextEnum()
	{
		m_pstss = NULL;
	}

	~CSCTextEnum()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCTEXTENUM)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSCTextEnum)
	COM_INTERFACE_ENTRY(ISCTextEnum)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISCTextEnum
public:
	STDMETHOD(NextToken)(
		/*[out]*/ int *piTagIndex, 
		/*[out,retval]*/ BSTR *pbstr);

	STDMETHOD(Next)(
///		/*[in, out]*/ ISCTextSegment **pVal, 
		/*[in]*/ ISCTextSegment *pVal, 
		/*[out, retval]*/ BOOL *fVal);

	STDMETHOD(Update)(
		/*[in]*/ ISCTextSegment *pVal);

	STDMETHOD(SetText)(
			/*[in]*/ BSTR bstrText, 
			/*[in]*/ ISCScriptureText4 *pscr,
			/*[in]*/ BSTR bstrComment);
	
	void FinalRelease();

	void Init(
		ScriptureTextSegmentStream * pstss,
		ScriptureReference srfFirst, 
		ScriptureReference srfLast,
		SCTextType sttFilter,
		SCTextProperties stpSmushing
		)
	{
		m_fUpdateable = false;

		m_pstss  = pstss;
		m_srfFirst = srfFirst;
		m_srfLast = srfLast;
		m_sttFilter = sttFilter;
		m_stpSmushing = stpSmushing;
		m_bFirst = true;
		m_bGotNextSegmentAlready = false;
		m_fAsteriskIsMarker = false;

		if (pstss->m_bEOS) {
			// We didn't find a file containing a reference at or beyond the
			// one we were looking for.  I don't think it matters
			// what goes in the current reference in this case but
			// I will default it to the reference we were searching for.
			m_srfCur.Book(srfFirst.iBook());
			m_srfCur.Chapter(srfFirst.iChapter());
			m_srfCur.Verse(srfFirst.iVerse());
		}
		else {
			// We found a reference at or or beyond the point we were looking
			// for.  Use the first reference found as the default reference.
			m_srfCur.Book(pstss->m_rtfi->m_srfFirst.iBook());
			m_srfCur.Chapter(pstss->m_rtfi->m_srfFirst.iChapter());
			m_srfCur.Verse(pstss->m_rtfi->m_srfFirst.iVerse());
		}
	}

	CComBSTR bstrBaseGetNextToken(ScrTokenType& tt, bool bAsteriskIsMarker);

	CComPtr<ISCScriptureText4> m_qScriptureText;
		// We directly set this from SCScriptureText - so it is public

private:
	ScriptureTextSegmentStream * m_pstss;
	ScriptureReference m_srfFirst;
	ScriptureReference m_srfLast;
	SCTextType m_sttFilter;
	SCTextProperties m_stpSmushing;

	ScriptureReference m_srfCur;
	ScriptureTextSegment m_sts;
	ScriptureTextSegment m_stsNext;
	bool m_bFirst;
	    // Becomes false as soon as we have passed the milestone that defines
        // the start of the smushing unit we are using.  If not smushing
        // this becomes false as soon as we see the first segment.  This allows
        // us to avoid stopping the process when we hit the first smushing boundary
		// because we want to continue until we see the second one.
	bool m_bGotNextSegmentAlready;
	bool m_fUpdateable;
		// True if the user is allowed to update the original text by
		// making an assignement to the Text property.
	int m_fAsteriskIsMarker;

	CComBSTR m_qbstrText;
	CComBSTR m_qbstrToken;
	wchar_t m_wchComment;
	BSTR m_bstrStream;

};

#endif //__SCTEXTENUM_H_
