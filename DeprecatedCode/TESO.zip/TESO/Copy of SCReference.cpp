// SCReference.cpp : Implementation of CSCReference

//:> See ScriptureObjects.idl for interface information about this class

#include "stdafx.h"
#include "TESO.h"
#include "SCReference.h"
#include "srflib.h"
#include "ECUtil.h"
#include "time.h"		// for time in log msg

/////////////////////////////////////////////////////////////////////////////
// CSCReference

STDMETHODIMP CSCReference::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISCReference
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


STDMETHODIMP CSCReference::IsValidVerseNumberText(/*[in]*/ VARIANT pSafeArrayOfBytes,
												  /*[out]*/ BOOL *isValid, 
												  /*[out]*/ int *numBytes,
												  /*[out]*/ int *firstVerseNum,
                                                  /*[out]*/ int *lastVerseNum)
{
	*numBytes = 0;
	*firstVerseNum = 0;
	*lastVerseNum = 0;
	_TSTRING sLitVerseText;
	int currentLine = __LINE__;

	long LBnd, UBnd;
	long lsize = 0;
	char *data;
	unsigned char *pData;
	bool hadException = true;
currentLine = __LINE__;
	try
	{
currentLine = __LINE__;
		SafeArrayGetLBound(V_ARRAY(&pSafeArrayOfBytes), 1, &LBnd);
currentLine = __LINE__;
		SafeArrayGetUBound(V_ARRAY(&pSafeArrayOfBytes), 1, &UBnd);
currentLine = __LINE__;
		lsize = UBnd-LBnd+1;
currentLine = __LINE__;
		data = new char[lsize+1];		// add another for null termination
		data[lsize] = 0;				// just make sure it is null terminated
currentLine = __LINE__;
		pData = (unsigned char*)data;
currentLine = __LINE__;
		for (long li = LBnd; li <= UBnd; li++, pData++ )
		{
currentLine = __LINE__;
			SafeArrayGetElement(V_ARRAY(&pSafeArrayOfBytes), &li, pData );
		}
currentLine = __LINE__;

		// using 'unknown' versification scheme at this point
		ScriptureReference srfFirst(1), srfLast(1);
currentLine = __LINE__;
		TokenStream ts(data);
currentLine = __LINE__;
		ScriptureCheckHelper helper;
currentLine = __LINE__;
		helper.GetSRFNums(ts, srfFirst, srfLast, sLitVerseText);
currentLine = __LINE__;
		*numBytes = sLitVerseText.length();
currentLine = __LINE__;
		if (srfFirst.bValid() && srfLast.bValid())
		{
currentLine = __LINE__;
			// make sure it's not an invalid range  "4-1"
			if (srfFirst.iVerse() <= srfLast.iVerse())
			{
currentLine = __LINE__;
				*firstVerseNum = srfFirst.iVerse();
				*lastVerseNum = srfLast.iVerse();
				*isValid = true;
			}
			else
				*isValid = false;
		}
		else
			*isValid = false;

currentLine = __LINE__;
		hadException = false;
	}
	catch (_com_error& e) 
	{
		HRESULT hr = e.Error();
		std::string ErrorMsg;
		
		IErrorInfo* einfo = e.ErrorInfo();
		if (einfo)
		{
			BSTR bstr;
			einfo->GetDescription(&bstr);
			::MessageBoxW(NULL,bstr,L"ErrorInfo", MB_OK);
			::SysFreeString(bstr);
		}

		IErrorInfoPtr qerrinfo;
		GetErrorInfo(0, &qerrinfo);
		if (qerrinfo)
		{
			BSTR bstr;
			qerrinfo->GetDescription(&bstr);
			::MessageBoxW(NULL,bstr,L"ErrorInfo", MB_OK);
			::SysFreeString(bstr);
		}			//	throw hr;
	}
	catch(...)
	{
	}

	if (hadException)
	{
		FILE *fLog = fopen("c:\\SCReference.txt", "a+");
		char buff[256];
		buff[0] = '<';
		_strdate(&buff[1]);
		buff[9] = '_';
		_strtime(&buff[10]);
		buff[18] = '>';
		buff[19] = ' ';
		buff[20] = '\0';

		sprintf(&buff[20],"** Had exception in CSCReference::IsValidVerseNumberText.\n");
		fwrite(buff, strlen(buff), sizeof(char), fLog);
		sprintf(buff, "size of data = %d\n", lsize);
		fwrite(buff, strlen(buff), sizeof(char), fLog);
		strncpy(buff,data,255);
		buff[255] = 0;
		sprintf(buff, "Last line = %d\n", currentLine);
		fwrite(buff, strlen(buff), sizeof(char), fLog);
		fclose(fLog);
	}


//	if (data)
	delete [] data;
	return S_OK;
}


STDMETHODIMP CSCReference::IsValidBookName(/*[in]*/ VARIANT pSafeArrayOfBytes, /*[out]*/ BOOL *isValid, /*[out]*/ int *numBytes)
{
	long LBnd, UBnd;
	SafeArrayGetLBound(V_ARRAY(&pSafeArrayOfBytes), 1, &LBnd);
	SafeArrayGetUBound(V_ARRAY(&pSafeArrayOfBytes), 1, &UBnd);
	*numBytes = 0;
	long lsize = UBnd-LBnd+1;
	*numBytes = lsize;

	// can only be 3 characters
	if (lsize != 3)
	{
		*isValid = false;
		return S_OK;
	}

	#define MaxBookNameLen 3+3		// include enough
	char data[MaxBookNameLen];
	memset(data,0,sizeof(data));
	unsigned char *pData = (unsigned char*)data;
	for (long li = LBnd; li <= UBnd && li<MaxBookNameLen-1; li++, pData++ )
	{
		SafeArrayGetElement(V_ARRAY(&pSafeArrayOfBytes), &li, pData );
	}
	int bookNum = ScriptureReference::iLookupBook(data);
	if (bookNum > 0 )
	{
		*isValid = true;
		*numBytes = 3;
	}
	else
		*isValid = false;

	return S_OK;
}


STDMETHODIMP CSCReference::get_ErrorDataString(/*[out,retval]*/BSTR* bstr)
{
	*bstr = m_cbstrErrMsg.Copy();
	return S_OK;
}


STDMETHODIMP CSCReference::get_Book(short *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	*pVal = m_srf.iBook();

	return S_OK;
}

STDMETHODIMP CSCReference::put_Book(short newVal)
{
	m_srf.Book(newVal);

	return S_OK;
}

STDMETHODIMP CSCReference::get_Chapter(short *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	*pVal = m_srf.iChapter();

	return S_OK;
}

STDMETHODIMP CSCReference::put_Chapter(short newVal)
{
	m_srf.Chapter(newVal);

	return S_OK;
}

STDMETHODIMP CSCReference::get_Verse(short *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	*pVal = m_srf.iVerse();

	return S_OK;
}

STDMETHODIMP CSCReference::put_Verse(short newVal)
{
	m_srf.Verse(newVal);

	return S_OK;
}

STDMETHODIMP CSCReference::get_Segment(short *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	*pVal = m_srf.iSegment();

	return S_OK;
}

STDMETHODIMP CSCReference::put_Segment(short newVal)
{
	m_srf.Segment(int(newVal));

	return S_OK;
}

STDMETHODIMP CSCReference::get_LastBook(short *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	PROTECTION_BEGIN

	*pVal = m_srf.iLastBook();

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCReference::get_LastChapter(short *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	PROTECTION_BEGIN

	*pVal = m_srf.iLastChapter();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCReference::get_LastVerse(short *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	PROTECTION_BEGIN

	*pVal = m_srf.iLastVerse();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCReference::get_VersificationsPresent(BSTR *pVal)
{
	CComBSTR q = VERSIFICATION_NAMES;
	*pVal = q.Copy();

	return S_OK;
}


// If the parse fails we return S_OK but the Valid will
// return false when applied to the object.

STDMETHODIMP CSCReference::Parse(BSTR val)
{
	PROTECTION_BEGIN

	if (NULL == val)
		return E_POINTER;

	char * tmp = ECUtil::WideToMultiByte(val);	// converts UTF-16 to UTF-8
	ScriptureReference srfTmp(tmp, english);
	free(tmp);

	m_srf = srfTmp;
	if (m_srf.ErrorStatus() == sre_none)	// no error
		return S_OK;
	else
	{
		int scode = 0xF400 | m_srf.ErrorStatus();
		return MAKE_HRESULT(1 , FACILITY_WIN32 , scode);
		// hresult is F4XX where XX is the combination of current error codes
	}

	PROTECTION_END
}

STDMETHODIMP CSCReference::NextVerse()
{
	PROTECTION_BEGIN

	++m_srf;

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCReference::PreviousVerse()
{
	PROTECTION_BEGIN

	--m_srf;

	return S_OK;

	PROTECTION_END
}


// This method will return the reference string using ASCII 'digit' code points (0030-0039).
// If the original data contains digit code points that are from different scripts, you lose.
STDMETHODIMP CSCReference::get_AsString(BSTR *pVal)
{
	PROTECTION_BEGIN

	CComBSTR bstr;

	if (NULL == pVal)
		return E_POINTER;

	bstr = m_srf.sAsString().c_str();
	*pVal = bstr.Copy();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCReference::get_Versification(SCVersification *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	*pVal = (SCVersification)m_srf.svtVersification();

	return S_OK;
}

STDMETHODIMP CSCReference::put_Versification(SCVersification newVal)
{
	m_srf.Versification((ScriptureVersificationType)newVal);

	return S_OK;
}

STDMETHODIMP CSCReference::get_Valid(BOOL *pVal)
{
	if (NULL == pVal)
		return E_POINTER;

	PROTECTION_BEGIN

	// VB wants a true value to be all 1's

	m_cbstrErrMsg = L"";
	*pVal = m_srf.bValidSVT() ? -1 : 0;
	if (m_srf.ErrorStatus() == sre_none)	// no error
		return S_OK;
	else
	{
		m_cbstrErrMsg = m_srf.GetErrorDesc();
		int scode = 0xF400 | m_srf.ErrorStatus();
		return MAKE_HRESULT(1 , FACILITY_WIN32 , scode);
		// hresult is F4XX where XX is the combination of current error codes
	}

	PROTECTION_END
}

STDMETHODIMP CSCReference::ChangeVersification(SCVersification NewVersification)
{
	PROTECTION_BEGIN

	m_srf = m_srf.srfChangeVersification((ScriptureVersificationType)NewVersification);

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCReference::get_BBCCCVVV(long *pVal)
{
	PROTECTION_BEGIN

	if (NULL == pVal)
		return E_POINTER;

	//if (m_srf.bValid()) {
		*pVal = 1000000L * m_srf.iBook() + 1000L * m_srf.iChapter() + m_srf.iVerse();
	//}
	//else {
	//	*pVal = 0;
	//}

	return S_OK;

	PROTECTION_END
}

STDMETHODIMP CSCReference::SetToEnd()
{
	PROTECTION_BEGIN

	m_srf = m_srf.end();

	return S_OK;

	PROTECTION_END
}
