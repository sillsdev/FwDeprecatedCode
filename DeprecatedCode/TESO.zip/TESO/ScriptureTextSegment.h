//-----------------------------------------------------
//:> ScriptureTextSegment
// This is a chunk of text from a scripture along with
// its associated properties.
// Potentially several verse segments or verse may be "smushed"
// together to create this segment.
// It is mostly a data-only class. The code for non-data members
// are included in this file.
//-----------------------------------------------------

class ScriptureTextSegmentStream;

class ScriptureTextSegment {   // hungarian: sts   
private:
    ScriptureReference m_srfFirst;
		// Reference for first (inclusive) verse present in the segment.

    ScriptureReference m_srfLast;
		// Reference for last (inclusive) verse present in the segment.
        
    SCTextType m_stt;         
        // Text type of returned text item.

    SCTextProperties m_stp;         
        // Sum of properties for this segment.

    // Text of segment.
    // Does not contain any CR or LF's.
    // Length is zero when no matching segment found.
    _TSTRING m_sText;

    // Markup tag associated with this segment.
    _TSTRING m_sMarker;

	// Literal Verse Text string data
	_TSTRING m_sLitVerseText;

	friend ScriptureTextSegmentStream;

public:

	// Construct an empty segment.
	ScriptureTextSegment(void) 
	{
		m_srfFirst.Book(0);
		m_srfLast.Book(0);
		m_stt = SCTextType(0);         
		m_stp = SCTextProperties(0);  
	}

	// Element-wise constructor
    ScriptureTextSegment(
        ScriptureReference srfFirst,
        ScriptureReference srfLast,
        SCTextType stt,
        SCTextProperties stp,
        const _TSTRING sText,
        const _TSTRING sMarker): m_srfFirst(srfFirst), m_srfLast(srfLast), 
		m_stt(stt), m_stp(stp), 
		m_sText(sText), m_sMarker(sMarker), m_sLitVerseText(_T("")) {;}

	// Smushes sts into this segment, 
	//   It orders by first and last ScriptureReference, and 
	//   appends sts.m_sText appropriately.  Although SCTextType,
	//   SCTextProperties, and sMarker are not guarenteed to be meaningful after smushing,
	//   SCTextType and sMarker are retained if they are the same (otherwise undefined
	//   and EMPTY_STRING) and SCTextProperties is or'd together.
	void Smush(const ScriptureTextSegment& sts) {
			// Trace("Pre Smush");

			if (m_sText.length() == 0) {
				m_srfFirst = sts.m_srfFirst;
				m_srfLast = sts.m_srfLast;
			}

			// Don't change the limits unless there is actually some text found.
			if (sts.m_sText.length()) {
				if (m_srfFirst > sts.m_srfFirst)
					m_srfFirst = sts.m_srfFirst;
				
				if (m_srfLast < sts.m_srfLast)
					m_srfLast = sts.m_srfLast;
				
				m_sText.append(sts.m_sText);
			}

			m_sMarker = sts.m_sMarker;

			m_stt = SCTextType((int)sts.m_stt | (int)sts.m_stt);
			m_stp = SCTextProperties((int)m_stp | (int)sts.m_stp);
			//Trace("Post Smush");
		}



	// @return First reference present
    inline ScriptureReference srfFirst(void) const {return  m_srfFirst;}

	// @return Last reference present
    inline ScriptureReference srfLast(void) const {return  m_srfLast;}

	// @return Text type (e.g. verse text, note text, ...)
    inline SCTextType sttTextType(void) const {return  m_stt;}         

	// @return Text properties (e.g. publishable, vernacular, ...)
    inline SCTextProperties stpProperties(void) const {return  m_stp;}        

	// @return Content text
    inline _TSTRING sText(void) const {return  m_sText;}    

	// @return Marker text
    inline _TSTRING sMarker(void) const {return  m_sMarker;}    

	// @return Marker text
    inline _TSTRING sLitVerseText(void) const {return  m_sLitVerseText;}    

    // Set first reference
    inline void First(const ScriptureReference srf) {m_srfFirst=srf;}

    // Set last reference    
	inline void Last(const ScriptureReference srf) {m_srfLast=srf;}

    // Set text type
    inline void TextType(const SCTextType stt){m_stt=stt;}         

    // Set text properties
    inline void TextProperty(const SCTextProperties stp) {m_stp=stp;}         

    // Set content text    
    inline void Text(const _TSTRING s) {m_sText=s;}

    // Set marker text
    inline void Marker(const _TSTRING s) {m_sMarker=s;}

	// Output trace of contents of segment
	void Trace(char* sz) const
	{
		//! shouldn't do all this if not tracing
		_TSTRING s;
		if ((int)sttTextType() & (int)scTitle) s += "Title ";
		if ((int)sttTextType() & (int)scSection) s += "Section ";
		if ((int)sttTextType() & (int)scVerseText) s += "VTxt ";
		if ((int)sttTextType() & (int)scNoteText) s += "NoteText ";
		if ((int)sttTextType() & (int)scOther) s += "Other ";

		if ((int)stpProperties() & (int)scBook) s += "Book ";
		if ((int)stpProperties() & (int)scVerse) s += "Verse ";
		if ((int)stpProperties() & (int)scChapter) s += "Chapter ";
		if ((int)stpProperties() & (int)scParagraph) s += "Para ";
		if ((int)stpProperties() & (int)scPublishable) s += "Pub ";
		if ((int)stpProperties() & (int)scVernacular) s += "Vern ";
		if ((int)stpProperties() & (int)scPoetic) s += "Poetic ";
		if ((int)stpProperties() & (int)scLevel_1) s += "1 ";
		if ((int)stpProperties() & (int)scLevel_2) s += "2 ";
		if ((int)stpProperties() & (int)scLevel_3) s += "3 ";
		if ((int)stpProperties() & (int)scLevel_4) s += "4 ";
		if ((int)stpProperties() & (int)scLevel_5) s += "5 ";
		if ((int)stpProperties() & (int)scCrossReference) s += "CrossReference ";
		if ((int)stpProperties() & (int)scNonpublishable) s += "Nonpub ";
		if ((int)stpProperties() & (int)scNonvernacular) s += "Nonvern ";

		ATLTRACE("%s <\\%s> %s %d:%d(%d)-%d(%d) %s, <%.128s%s>\n", sz, sMarker().data(), \
				ScriptureReference::cGetBookName(srfFirst().iBook()), \
				srfFirst().iChapter(), srfFirst().iVerse(), srfFirst().iSegment(), \
				srfLast().iVerse(), srfLast().iSegment(), \
				s.data(), sText().data(), sText().length() > 128 ? "..." : "");
	}



	void Clear()
	{
		ScriptureReference srf;
		m_srfFirst = srf;
		m_srfLast = srf;
		m_stt = SCTextType(0);
		m_stp = SCTextProperties(0);
		m_sText = "";
		m_sMarker = "";
		m_sLitVerseText = _T("");
	}

	// Element-wise equality comparison
	bool operator==(const ScriptureTextSegment& sts) const
	{
		return ((m_srfFirst==sts.m_srfFirst) && (m_srfLast==sts.m_srfLast)
			&& (m_stt==sts.m_stt) && (m_stp==sts.m_stp) && (m_sText.compare(sts.m_sText)==0)
			&& (m_sMarker.compare(sts.m_sMarker)==0));
	}

	bool operator!=(const ScriptureTextSegment& sts) const { return !(*this==sts);}

    // Copy and assignment operators - using member-wise defaults
    //  ScriptureTextSegment(const ScriptureTextSegment& sts);
    //  void operator=(const ScriptureTextSegment& sts);

};

