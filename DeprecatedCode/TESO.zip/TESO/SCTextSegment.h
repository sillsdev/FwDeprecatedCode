// SCTextSegment.h : Declaration of the CSCTextSegment

//:> See ScriptureObjects.idl for interface information about this class


#ifndef __SCTEXTSEGMENT_H_
#define __SCTEXTSEGMENT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSCTextSegment
class ATL_NO_VTABLE CSCTextSegment : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSCTextSegment, &CLSID_SCTextSegment>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISCTextSegment, &IID_ISCTextSegment, &LIBID_TESOLib>
{
public:
	CSCTextSegment()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCTEXTSEGMENT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSCTextSegment)
	COM_INTERFACE_ENTRY(ISCTextSegment)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISCTextSegment
public:
	STDMETHOD(Clone)(/*[out, retval]*/ ISCTextSegment **ppTextSegment);
	STDMETHOD(get_Text)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Text)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_TextProperties)(/*[out, retval]*/ SCTextProperties *pVal);
	STDMETHOD(put_TextProperties)(/*[in]*/ SCTextProperties newVal);
	STDMETHOD(get_TextType)(/*[out, retval]*/ SCTextType *pVal);
	STDMETHOD(put_TextType)(/*[in]*/ SCTextType newVal);
	STDMETHOD(get_LastReference)(/*[out, retval]*/ ISCReference **pVal);
	STDMETHOD(put_LastReference)(/*[in]*/ ISCReference *newVal);
	STDMETHOD(get_FirstReference)(/*[out, retval]*/ ISCReference **pVal);
	STDMETHOD(put_FirstReference)(/*[in]*/ ISCReference *newVal);
	STDMETHOD(get_Tag)(/*[out, retval]*/ ISCTag **pVal);
	STDMETHOD(put_Tag)(/*[in]*/ ISCTag *newVal);
	STDMETHOD(get_LiteralVerseNum)(/*[out, retval]*/ BSTR *pbstr);
	STDMETHOD(put_LiteralVerseNum)(/*[in]*/ BSTR newVal);

	STDMETHOD(FinalConstruct)();
private:

	CComBSTR m_cbstrLitVerse;
	CComBSTR m_cbstrMarker;
	CComBSTR m_cbstrText;
	SCTextProperties m_stp;
	SCTextType m_stt;
	CComPtr<ISCReference> m_pISCReferenceFirst;
	CComPtr<ISCReference> m_pISCReferenceLast;
	CComPtr<ISCTag> m_pISCTag;
};


#endif //__SCTEXTSEGMENT_H_
