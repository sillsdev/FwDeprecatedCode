#include "stdafx.h"
#include "srftok.h"
#include "SCScriptureText.h"
#include "SCTextSegment.h"
// function from UtilXml.h in FieldWorks Generic folder
extern long DecodeUtf8(const char * rgchUtf8, int cchUtf8, int & cbOut);
#include "IcuCommon.h"		// ICU header file
namespace StrUtil
{
	extern void InitIcuDataDir();
};


// void IsPeriod(UChar32 ch)
//	This method would be beter if it could use a binary property, but none has
//	been found for the period.
//	This function returns true if the passed in character is a 'period' character:
//	as defined by the code points in this method.

bool IsPeriod(UChar32 ch)
{
	int periods[] = { 0x2e,		// period, full stop, dot, decimal point
					  0x6d4,	// arabic full stop
					  0x3002,	// idographic full stop
					  0 };
	for (int i=0; periods[i] != 0; i++)
		if (ch == periods[i])
			return true;

	return false;
}


// void IsComma(UChar32 ch)
//	This function returns true if the passed in character is a 'comma' character.

bool IsComma(UChar32 ch)
{
	int commas[] = { 0x2c,		// COMMA
					 0x60c,		// Arabic comma
					 0x201a,	// Single low-9 quotation mark
					 0x3001,	// idographic comma
					 0 };
	for (int i=0; commas[i] != 0; i++)
		if (ch == commas[i])
			return true;

	return false;
}

void DumpMarkerInfo(char* hdg, MarkerInfo& mi);

void bTrimWSEnds(_TSTRING & s)
{	
	// TODO: use DecodeUtf8() and u_isspace() instead of _istspace() and *sIter.
	_TSTRING::iterator sIter = s.end();
	sIter--;
	while (_istspace(*sIter)) {
		s.erase(sIter);
		sIter--;
	}
	sIter = s.begin();
	while (_istspace(*sIter))
		s.erase(sIter);
}


// ScriptureTextSegmentStream::ScriptureTextSegmentStream(const SCScriptureText *pscr, ScriptureReference srf):
//   constructor which, given a reference, attempts to open the file in the SCScriptureText containing that reference

ScriptureTextSegmentStream::ScriptureTextSegmentStream(ScriptureReference srf,
	map<_TSTRING, MarkerInfo> & mapMarkerTextProp, vector<CComPtr<ISCTag> > & vTags,
	vector<RangeToFile> & vecrtf, SCVersification iVersification, HANDLE hCCTable,
	bool fAsteriskIsMarker, bool bEatEscapeBackslashes)
	: ScriptureRawTextStream(vecrtf, hCCTable), m_mapMarkerTextProp(mapMarkerTextProp),
	  m_vTags(vTags), m_iVersification(iVersification), m_fAsteriskIsMarker(fAsteriskIsMarker),
	  m_bEatEscapeBackslashes(bEatEscapeBackslashes)
{
	_TSTRING sTemp;
	ATLTRACE("Create ScriptureTextSegmentStream\n");

	// Open the first file at or beyond the point srf.
	// When we get back m_rtfi will point to the info for this file.
	OpenFile(srf, true);

	// Push a dummy marker description onto the stack so that
	// we can inherit defaults from it if necessary.
	MarkerInfo mi;
	mi.m_stt = scOther;
	mi.m_stp = SCTextProperties((int)scPublishable + (int)scVernacular);
	mi.m_sst = paragraphstyle;
	mi.m_bIsEnd = false;
	m_miStack.push_back(mi);
	StrUtil::InitIcuDataDir();
}


ScriptureTextSegmentStream::~ScriptureTextSegmentStream(void){
	ATLTRACE("Destroy ScriptureTextSegment\n");
}


const bool ScriptureTextSegmentStream::bEndOfStream(){ return m_bEOS; }


void DumpMarkerStack(deque<MarkerInfo>& miStack) 
{
	deque<MarkerInfo>::iterator miIterator;

	ATLTRACE("Marker Stack...\n");
	for (miIterator = miStack.begin(); miIterator != miStack.end(); ++miIterator)
		DumpMarkerInfo("     ", *miIterator);
	ATLTRACE("...\n");
}

// stsGetNextRawSegment(ScriptureReference & srfCur)
// logic:
//   (1) find the next marker (or End)
//   (2) look it up, 
//   (3) if you didn't find it, keep the text [with the properties already seen]
//   (4) remove all appropriate begin marker properties off the stack
//   (5) if it's an end, get previous properties off stack
//       (a) blank out milestone markers
//   (6) inherit vernacular, publishable, and text type from greater style type
//   (7) if begin, push properties onto stack.
//   (8) check if milestone [book, chapter, verse] and record this fact
//   (9) return raw segment

void ScriptureTextSegmentStream::stsGetNextRawSegment(
	ScriptureReference & srfCur,
	ScriptureTextSegment & sts)
{
	sts.m_srfFirst = ScriptureReference::end();
	int fposPrev;

	//   (1) find the next marker (or End)
    //   If there is text before the first tag, flush it.

    // If there is a tag in m_tt then it has not been processed yet.
    // If there is text in m_tt it has already been processed and we need
    // to flush it and replace it with the next tag.
    while (m_tatt.m_tt != tag && !bEndOfStream())
	{
		fposPrev = tellg();
		m_tatt.m_sText = sGetNextToken(m_tatt.m_tt, 0, m_fAsteriskIsMarker);
	}

    if (bEndOfStream())
		return;

	//   (2) look it up, 
	map<_TSTRING, MarkerInfo>::iterator p = m_mapMarkerTextProp.find(m_tatt.m_sText.data());
	
	DD( p != m_mapMarkerTextProp.end() ? DumpMarkerInfo("======= Token=======> ", p->second) : ""; )
	DD( DumpMarkerStack(m_miStack); )


	_TSTRING sToken;
	MarkerInfo mi;
	_TSTRING sLitVerseText;

	if (p == m_mapMarkerTextProp.end())  
	{   
		// TE-1856 Start
		// Check to see if this is an inline marker ending with a space
		std::string strMarker = m_tatt.m_sText.data();
		strMarker += ' ';
		p = m_mapMarkerTextProp.find(strMarker.c_str());
		if (p != m_mapMarkerTextProp.end()) 
		{
			mi = p->second;
			m_tatt.m_sText = strMarker.c_str();
		}
		else
		{
			// Check to see if this contains an inline marker, before creating a new 'default' marker
			bool foundMarker = false;
			std::string strData;
			strMarker = m_tatt.m_sText.data();
			int strMarkerLen = strMarker.length();
			if (strMarkerLen > 0)
			{
				strData = strMarker.substr(strMarkerLen-1, 1).c_str();	// strMarker[strMarkerLen-1];
				strMarker.erase(strMarkerLen-1);
			}
			while (strMarkerLen > 0 && !foundMarker)
			{
				p = m_mapMarkerTextProp.find(strMarker.c_str());
				if (p != m_mapMarkerTextProp.end())  
					foundMarker = true;
				else
				{
					strMarkerLen--;
					if (strMarkerLen <= 0)
						break;
					strData = strMarker[strMarkerLen-1] + strData;	// .insert(strMarker.substr(strMarkerLen-1, 1).c_str());	//  strMarker[strMarkerLen-1]);
					strMarker.erase(strMarkerLen-1);
				}
			}
			if (foundMarker)
			{
				mi = p->second;
				m_tatt.m_sText = strMarker.c_str();	// strData.c_str();
	//			istringstream inputStream = (istringstream)(*this);
	//			while (strData.length() > 0)
	//			{
	//				putback((char)strData[strData.length()-1]);
	//				strData.erase(strData.length()-1);
	//			}
///				ios_base::seekdir refPoint = ios_base::cur;
				int fpos = fposPrev + strMarker.length() + 1;	// add in marker // tellg();
				seekg(fpos);
///				if (fpos == -1)
///					   refPoint = ios_base::end;
///				seekg(-strData.length(), refPoint);
			}
			else
			{
				// TE-1856  End

				// If we can't find this marker, treat it as a default paragraph type
				mi.m_sMarker = "p";
				mi.m_stp = (SCTextProperties)((int)scPublishable + (int)scVernacular);
				mi.m_sst = paragraphstyle;
				mi.m_stt = scVerseText;


	#ifdef OLD_ERROR_HANDLING_METHOD
				//   (3) if you didn't find it, keep the text, with the properties of the previous MarkerInfo
			DD( ATLTRACE("Unknown marker!\n"); )
			sToken = sGetNextToken(m_tatt.m_tt);
			deque<MarkerInfo>::iterator miIterator;
			MarkerInfo mi;
			if (!m_miStack.empty()) {
				DD( ATLTRACE("User properties of previous marker\n"); )
				miIterator = m_miStack.end();
				miIterator--;
				mi.m_stt = miIterator->m_stt;
				mi.m_stp = miIterator->m_stp;
				DD( DumpMarkerInfo("mi: ", mi); )
			}
			else {
				DD( ATLTRACE("No previous marker\n"); )
				mi.m_stt = SCTextType(0);
				mi.m_stp = SCTextProperties(0);
				DD( DumpMarkerInfo("mi: ", mi); )
			}

			if (m_tatt.m_tt == text) {
				DD( ATLTRACE("Unknown marker has text\n"); )
				sts.m_srfFirst = srfCur; 
				sts.m_srfLast = srfCur;
				sts.m_stt = mi.m_stt;   
				sts.m_stp = mi.m_stp;       
				sts.m_sText = sToken;
				sts.m_sMarker = m_tatt.m_sText;
			}
			else {
				DD( ATLTRACE("Unknown marker has NO text\n"); )
				// m_tt is already 'tag'
				_TSTRING sTmp = m_tatt.m_sText;
				m_tatt.m_sText = sToken;

				sts.m_srfFirst = srfCur; 
				sts.m_srfLast = srfCur;
				sts.m_stt = mi.m_stt;   
				sts.m_stp = mi.m_stp;       
				sts.m_sText = EMPTY_STRING;
				sts.m_sMarker = sTmp;
			}

			return;
	#endif
			}
		}
	}
	else
		mi = p->second;

	// TE-1856 Start, if an inline marker ends with space - eat it from input
	// otherwise if it did eat a space, put it back.
	if (mi.m_sAssocMarker.length() > 0)
	{
		// see if the marker ends with a space
		if (mi.m_sMarker[mi.m_sMarker.length()-1] == ' ')	// space char only
		{
			char ctmp;
			get(ctmp);
			if (ctmp == ' ')
				;	// just eat it
			else
				putback(ctmp);	// put non-space char back : TODO case
		}
		else if (mi.m_sMarker[mi.m_sMarker.length()-1] != '*')	// * is special terminator
		{
			// see if last was space, if so put it back
			int fpos = tellg();
			seekg(fpos-1);
			char ctmp;
			get(ctmp);
			if (ctmp == ' ')
				seekg(fpos-1);
		}
	}
	// TE-1856 End

    deque<MarkerInfo>::iterator miIterator;

	if (!m_miStack.empty())
	{	//   (4) remove all appropriate begins off the stack

		// Patch up case where their is no paragraph marker before \v
		// or this is a note opened but not closed before \v
		if ((int)mi.m_stp & (int)scVerse) {
			// Remove any open notes or phrase from the stack
			// This should only happen if the user has failed to terminate
			// a note or a phrase.
			while (m_miStack.size() > 2) {
				miIterator = m_miStack.end(); 
				miIterator--;
				m_miStack.erase(miIterator);
			}

			MarkerInfo miPara;
			miPara.m_sMarker = "p";
			miPara.m_stp = (SCTextProperties)((int)scPublishable + (int)scVernacular);
			miPara.m_sst = paragraphstyle;
			miPara.m_stt = scVerseText;

			if (m_miStack.size() == 1) {
				// if no open marker before \v supply info as if \p were present
				DD( ATLTRACE("!! Missing \\c\n"); )
				m_miStack.push_back(miPara);
			}
			else {
				// If the top level guy is not verse text (e.g. \p missing after \c)
				// change the top level guy to be a paragraph.
				if (m_miStack.at(1).m_stt != scVerseText)  {
					DD( ATLTRACE("!! Missing \\p\n"); )
					m_miStack.pop_back(); 
					m_miStack.push_back(miPara);
				}
			}
		}

		miIterator = m_miStack.end(); 
		miIterator--;
		while (miIterator !=m_miStack.begin()) {
            // In SFM we must ensure that character style properties go away at the
            // end of the pargraph or note.  In XML or SFM properties go away when the end
            // marker is seen.

			if (bNotHigherLevelStyle(miIterator->m_sst, mi.m_sst) || 
				((mi.m_bIsEnd) && (miIterator->m_sMarker==mi.m_sAssocMarker)))
				// end markers don't have sst's so give separate check
				m_miStack.erase(miIterator);
			DD( ATLTRACE("Pop\n"); )
			miIterator--;
		}
		DD( DumpMarkerStack(m_miStack); )
	}

    assert(! m_miStack.empty());

    if (mi.m_bIsEnd) {
		DD( ATLTRACE("End Marker\n"); )
		//   (5) if it's an end, get previous off stack
		miIterator = m_miStack.end();
		miIterator--;
		mi = *miIterator;
		//       (a) blank out milestone markers
		int iMask =	~((int)scVerse + (int)scChapter + (int)scBook + (int)scParagraph + (int)scNote);
		mi.m_stp = SCTextProperties((int)mi.m_stp & iMask);
        //! what if there missing or extra end markers
		DD( DumpMarkerInfo("mi: ", mi); )
	}
	else { 
		DD( ATLTRACE("NOT End Marker\n"); )
		//   (6) inherit vernacular, publishable, and text type from greater style type
		miIterator = m_miStack.end();
		miIterator--;

        // If current text type is underfined OR
		// current style type is Character, THEN
		// inherit text type
        if (mi.m_stt == SCTextType(0) || mi.m_sst == characterstyle)
			mi.m_stt = miIterator->m_stt;

        // If vernacular or publishable attributes are not set, inherit
		int iVernacularField = (int)scVernacular | (int)scNonvernacular;
        if (((int)mi.m_stp & iVernacularField) == 0)
		    mi.m_stp = SCTextProperties(
				(int)mi.m_stp | ((int)miIterator->m_stp & iVernacularField));

		int iPublishableField = (int)scPublishable | (int)scNonpublishable;
        if (((int)mi.m_stp & iPublishableField) == 0)
		    mi.m_stp = SCTextProperties(
				(int)mi.m_stp | ((int)miIterator->m_stp & iPublishableField));

		//   (7) if begin, push last onto stack.
		m_miStack.push_back(mi);
		DD( DumpMarkerStack(m_miStack); )
	}

    sToken = sGetNextToken(m_tatt.m_tt, 0, m_fAsteriskIsMarker);
	DD( ATLTRACE("token={%.50s}\n", sToken.data()); );

	if (m_tatt.m_tt==text) {
		DD( ATLTRACE("Marker followed by text\n"); )
		ScriptureReference srfFirst, srfLast;
		// make sure proper versification is set
		srfCur.Versification(ScriptureVersificationType((int)m_iVersification));
		srfFirst = srfCur;
		srfLast = srfCur;
		TokenStream ts(sToken.data());
		//   (8) check if first in book, chapter, verse
		if ((int)mi.m_stp & (int)scBook) {
			DD( ATLTRACE("Book start\n"); )
			srfFirst.Book(ScriptureReference::iLookupBook(ts.sPeek().data()));
			srfFirst.Chapter(1);
			srfFirst.Verse(0);
			srfLast = srfFirst;
		}
		else if ((int)mi.m_stp & (int)scChapter) {
			DD( ATLTRACE("Chapter start\n"); )
			srfFirst.Chapter(ts.iNext());
			srfLast.Chapter(srfFirst.iChapter());
			srfFirst.Verse(0);
			srfLast.Verse(0);
		}
		else if ((int)mi.m_stp & (int)scVerse) {
			if (srfFirst.iChapter() == 0) {
				DD( ATLTRACE("Missing chapater number, 1 supplied\n"); )
				srfFirst.Chapter(1);
				srfLast.Chapter(1);	
			}
			GetSRFNums(ts, srfFirst, srfLast, sLitVerseText);
			sts.m_sLitVerseText = sLitVerseText;
			DD( ATLTRACE("Verse start\n"); )
		}

		
		srfCur = srfLast;
		//   (9) return raw segment
		sts.m_srfFirst = srfFirst; 
		sts.m_srfLast = srfLast;
		sts.m_stt = mi.m_stt;   
		sts.m_stp = mi.m_stp;       
		sts.m_sText = ts.pcRest();
		sts.m_sMarker = m_tatt.m_sText;
	}
    else {  // for Markers with no corresponding text.
        // m_tt is already 'tag'
        _TSTRING sTmp = m_tatt.m_sText;
		m_tatt.m_sText = sToken;

		//   (9) return raw segment
		sts.m_srfFirst = srfCur; 
		sts.m_srfLast = srfCur;
		sts.m_stt = mi.m_stt;   
		sts.m_stp = mi.m_stp;       
		sts.m_sText = EMPTY_STRING;
		sts.m_sMarker = sTmp;
		// am putting EMPTY_STRING in to enable filters to check for this sort of thing.
	}
}


// GetSRFSeg(TokenStream &ts, ScriptureReference &srf)
//   Sets verse number and possibly segment info of reference.
//	 Also handles punctuation related data.
void ScriptureCheckHelper::GetSRFSeg(TokenStream &ts, ScriptureReference &srf)
{
	int oldTSIndex = ts.m_iCurIndex;	// save for possible future use
	_TSTRING sWhole = ts.sNextAndPeriod();
	int iIndex = 0;
	const char * pchWhole = sWhole.c_str();
	int cchWhole = sWhole.length();
	int cchSegments = 0;
	int cchPeriods = 0;
	bool bValid = true;
	while (iIndex < cchWhole)
	{
		int cchUsed;
		UChar32 ch = DecodeUtf8(pchWhole + iIndex, cchWhole - iIndex, cchUsed);
		if (ch == 0 || cchUsed == 0 || (!u_isdigit(ch) && !IsPeriod(ch)))	// !u_isdigit(ch))
		{
//			if (cchSegments == 0 && u_hasBinaryProperty(ch, UCHAR_ALPHABETIC))	// segemnt
			if (ch >= 0x61 && ch <= 0x7a)	// valid segemnt code points a-z
			{
				cchSegments++;				// bump the segment count
				if ( cchSegments > 1)		// shouldn't find two here
				{
					iIndex += cchUsed;		// bump the index for future use
					break;					// Found an invalid sequence, stop at verse number
				}
			}
			else
			{
				bValid = false;		// found some invalid data, go back to verse number
				break;
			}
		}
		else
		{
			if (IsPeriod(ch))			// only allow 1 period
			{
				cchPeriods++;			// bump the count, this is a terminating character
				iIndex += cchUsed;		// bump the index for future use
				break;
			}
		}
		iIndex += cchUsed;			// move index to next character and repeat
	}

	_TSTRING sTest = sWhole.substr(0,iIndex-cchSegments-cchPeriods);	// just numeric portion

	TokenStream tsInt(sTest.data());
	srf.Verse(tsInt.iPeek());				// set verse based on numeric portion

	if (bValid && cchSegments == 1)			// valid data and only one segment character
		srf.Segment(srf.iSegment() + 1);	// bump segment count

	if ((unsigned int)(iIndex) < sWhole.length())	// if didn't use the whole stream
	{
		if (cchSegments > 1 || !bValid)		// if to many segments or invalid data seen
			ts.m_iCurIndex = oldTSIndex+iIndex-cchSegments-cchPeriods;	// reset the cur pos [Even if space missing]
		else
			ts.m_iCurIndex = oldTSIndex+iIndex;	// reset the cur pos [Even if space missing]
	}
}


// void ScriptureTextIterator::GetSRFNums(TokenStream &ts, ScriptureReference &srfFirst, ScriptureReference &srfLast, const bool bIsFirst, const int iLevel)
//   This function is a rather complicated way of placing the current numerical input into the appropriate
//   ScriptureReference for the current Segment.
//   
//   
void ScriptureCheckHelper::GetSRFNums(TokenStream &ts,	// stream of [future] tokens
									  ScriptureReference &srfFirst,	// first ref of range
									  ScriptureReference &srfLast,	// last ref of range
									  _TSTRING &tsVerseRef)	// literal verse number data
{
	int iFirst = ts.iPeek(true);
	if ((iFirst == TokenStream::INVALID) && u_isdigit(ts.chwCur()))
	{
		// contains non-digit but starts with digit -> check for segment
		GetSRFSeg(ts, srfFirst);
		iFirst = srfFirst.iVerse();
	}
	else
    {
		srfFirst.Verse(iFirst);
		srfFirst.Segment(0);
        iFirst = ts.iNext();
		// need to eat period  (case of '4.-5.')
    }
    
	bool bBridge = false;
	UChar32 ch = ts.chwRawCur();	// handle 6,7 and 3-5 and 3a.-4b.
	if (u_hasBinaryProperty(ch, UCHAR_DASH) || IsComma(ch))	// dash or comma
	{
		// get token containing range marker
		_TSTRING sNextToken = ts.sNext();
		// and is followed by a digit
		if (u_isdigit(ts.chwRawCur()))
			bBridge = true;
		else if (!u_isspace(ts.chwRawCur()))		// 8/5 put dash back out for verse text processing
		{											// if not followed by space char
			ts.m_iCurIndex -= sNextToken.length();
		}
	}	

	if (bBridge)
	{
		srfLast = srfFirst;		// start with same verse and segment
		// get second verse number
		int iLast = ts.iPeek(true);
		if ((iLast == TokenStream::INVALID) && (u_isdigit(ts.chwCur())))
		{
			// contains non-digit but starts with digit -> check for segment
			GetSRFSeg(ts, srfLast);
			// if we move to a different verse, reset the segment count
			if (srfLast.iVerse() != srfFirst.iVerse())
				if (srfLast.iSegment() > 0)
					srfLast.Segment(1);		// this is the first one
		}
		else
        {
			srfLast.Verse(iLast);
			srfLast.Segment(0);
            iLast = ts.iNext();
        }
	}
	else
	{
#if 1
		srfLast = srfFirst;
		srfLast.Verse(iFirst);
#else
		srfLast.Verse(iFirst);
		srfLast.Segment(0);
#endif
	}
	tsVerseRef = ts.sToCur();	// get the characters that make up the verse ref
}


// _TSTRING sGetNextToken(ScrTokenType& tt, _TCHAR chCommentMarker, bool bAsteriskIsMarker)
//   Integrates getting the next token from the stream "*this" with advancing to the next file if possible.

_TSTRING SFMScriptureTextSegmentStream::sGetNextToken(
	ScrTokenType& tt, _TCHAR chCommentMarker, bool bAsteriskIsMarker)
{
	_TSTRING s;

	while (eof()) {
		OpenNextFile();
		if (m_bEOS)
			return EMPTY_STRING;

		//! if the newly opened file does not contain an ID line it
		// will be invalidly treated as a continuation of the
		// previous file.  I think this is a bug but maybe it is
		// a feature if we are not requiring that each chapter in 
		// a Bible organzied by chapter contain an ID line??!!
	}

	s = sBaseGetNextToken(tt, *this, chCommentMarker, bAsteriskIsMarker, m_bEatEscapeBackslashes );

	// token trap - for setting a breakpoint at a specific token when debugging
	//static bool fFound = false;
	//if (s == "id") {
	//	fFound = true;
	//	return s;
	//}
	//if (s == "x*" && fFound) {
	//	return s;
	//}

	return s;
}


// Basic Token getter for a file in SFM, has an input stream as an argument for flexibility.
// Returns empty string on end of file.
//  an adaption of pre-existing code.

_TSTRING SFMScriptureTextSegmentStream::sBaseGetNextToken(ScrTokenType& tt,  istream& iInput, _TCHAR chCommentMarker, bool bAsteriskIsMarker, 
														  bool bEatEscapeBackslashes, bool bEndOnEndOfLine )
{
	_TCHAR chBAD = (_TCHAR)0xcc;
    _TCHAR ch = chBAD;
    _TCHAR chPrevious = 0;
	_TSTRING sTok = "";

	sTok.reserve(128);
    tt = unknowntt;
		// tt starts at unknowntt and becomes 'text' or 'tag' as soon as we know
		// what kind of token we have.

	int fpos = iInput.tellg();

    while (!iInput.eof()) {

		iInput.get(ch);
		fpos++;

		if ( iInput.eof() || iInput.fail() )
			break;
        
        // Comment Handler
		// This assumes that the comment character cannot be newline 
        if (ch == chCommentMarker) {
#if 0
			OutputDebugString("COMMENT: ");
#endif
			_TCHAR chbuf[2];
			chbuf[1] = '\0';
            while (!iInput.eof() && ch != '\n' ) { 
                iInput.get(ch);    // trash everything from the comment character until the newline 
            }
        }
		fpos = iInput.tellg();

        if (iInput.eof())
            break;

		// Ignore \r
		if (ch == '\r') {
			iInput.get(ch);
		}

        if (iInput.eof())
            break; // Break out of the loop since we hit the end of the file. 

        switch (ch) {
        case '\\' : // SFM 
            switch (tt) {
                case text: 
					// if the following character isn't a '\', then this data has ended,
					//  otherwise this is part of the data and continue processing.
					iInput.get(ch);

					if ( iInput.eof() )	
						goto done;
	
					if ( ch == '\\' )	// continue with data
					{
						sTok += ch;
						if ( !bEatEscapeBackslashes )
							sTok += '\\';	// add the other backslash character
						break;
					}
					
					fpos = iInput.tellg();
					iInput.seekg(fpos-1);
					fpos = iInput.tellg();
						
					// Fall through on purpose , end of text

                case tag:
					// handle the case where we are reading two slash markers together '\\ blah blah'
					//  this is the case where the is possibly a marker in the data but it is to be 
					//  ignored and just treated as data.  (dlh 5/05)
					if (chPrevious == ch)
					{
						tt = text;		// not a marker anymore, data
						sTok += ch;
						if ( !bEatEscapeBackslashes )
							sTok += '\\';	// add the other backslash character
						break;
					}

					
					// If we are getting a tag or Text 
                    // move our current position in the file back one to get this tag
                    // the next time we get a token 

					fpos = iInput.tellg();
					iInput.seekg(fpos-1);
					fpos = iInput.tellg();

					if ( iInput.fail() )
						break;
					
					goto done;
                default:
                    // Otherwise, we are getting an tag
                    tt = tag;
            }
            break;

        case '\t': // tabs are considered to be spaces.           
			// Fall through on purpose
        case '\n': // new lines are considered to be spaces.
			// TE-1856 - Start
			if (bEndOnEndOfLine)
			{
				goto done;
			}
			// TE-1856 - End
            ch = ' ';
            // Fall through on purpose
        case ' ' :
            if (tt == tag)
				goto done; // We got our tag
            if (chPrevious == ' ')
                break;  // do not allow double spaces.
            // Fall through on purpose

        default:
            // If bare asterisks are allowed as markers mark them so and
            // make them terminate text tokens without being consumed.
            if (bAsteriskIsMarker && ch == '*') {
                if (tt == unknowntt)
                    tt = tag;
                else if (tt == text) {
                    iInput.putback(ch);
                    goto done;
                }
            }

            if (tt != tag)
                tt = text;                            

            // Store character into buffer.

			// DONT Lower case any tags #1163
			//if (tt == tag)
			//	sTok += tolower(ch);
			//else
				sTok += ch;

            // '*' always terminates a tag in order to allow us to distinguish
            // whether the space following a tag is significant.
            if (tt == tag && ch == '*')
				goto done; // We got our tag
            break;
        } // switch ch
        
		chPrevious = ch;
    } // loop

done:
	//ATLTRACE("tok={%s}\n", sTok.c_str());
	if (sTok == "x*") {
		ch = 0;
	}

    return sTok;
}




