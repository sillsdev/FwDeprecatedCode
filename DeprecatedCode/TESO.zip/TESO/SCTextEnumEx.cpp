// SCTextEnumEx.cpp : Implementation of CSCTextEnumEx
#include "stdafx.h"
#include "TESO.h"
#include "SCTextEnumEx.h"


#define TRY_START	try { 
#define TRY_STOP	} catch (...) { AtlTrace("**-- Exception in SCTextEnumEx**\n"); } 

/////////////////////////////////////////////////////////////////////////////
// CSCTextEnumEx

STDMETHODIMP CSCTextEnumEx::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISCTextEnumEx
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


void CSCTextEnumEx::FinalRelease()
{
}

void CSCTextEnumEx::AddTextMarkerProps( std::map<_TSTRING, MarkerInfo> inMarkers )
{
	m_MarkerTextProp = inMarkers;

	MarkerInfo m = m_MarkerTextProp[_T("v")];
	int asdf = 1234;
}


void CSCTextEnumEx::SetText( char* text, BSTR bstrComment )	// comment has to come from the Scripture TExt obj...
{
	TRY_START

	if (bstrComment && *bstrComment)
		m_chComment = (*bstrComment) & 0xff;
	else
		m_chComment = 0;

	if ( text )
		m_qstrText = text;
	else
	{
		m_qstrText = new char[1];
		m_qstrText[0] = '\0';
	}

	m_qstrToken = new char[strlen(m_qstrText)+1];	// CComBSTR(m_qbstrText.Length());
	m_strStream = m_qstrText;

	TRY_STOP
}


void CSCTextEnumEx::AddMarkerAndConverter( _TSTRING marker, CTKAndCodePageWrapper* converter )
{
	m_ConverterMap[ marker ] = converter;
}



STDMETHODIMP CSCTextEnumEx::Next(
//		/*[out]*/ int *piTagIndex, 
		/*[out]*/ BSTR *pbstrTag,
		/*[out]*/ ISCReference** ref,
		/*[out]*/ BSTR *text )
{
	PROTECTION_BEGIN

	if (!m_qstrText)
		return E_FAIL;

	HRESULT hr = S_OK;
	static CTKAndCodePageWrapper *conv = NULL;
	bool junk = false;

	int iTagIndex;
	ScrTokenType tt;
	char * qstrToken = strBaseGetNextToken(tt, true, junk);
	CComBSTR qbstrToken = CComBSTR(qstrToken);

	if (tt == tag) 
	{
		hr = m_qScriptureText->TagIndex((BSTR)qbstrToken, &iTagIndex);
		CComPtr<ISCTag> pTag;
		m_qScriptureText->NthTag( iTagIndex, &pTag );

		CComBSTR bstrEncodingName;
		pTag->get_Encoding( &bstrEncodingName );

		if ( bstrEncodingName.Length() == 0 )		// no tag level encoding 
		{
		}
		else										// get the converter for future use
		{
			CComBSTR bstrName;
			pTag->get_Marker( &bstrName );

			char dest[256];
			WideCharToMultiByte( CP_ACP, 0, bstrName, -1, dest, 256, NULL, NULL );
			
			TMapIDToConverter::iterator it = m_ConverterMap.find( dest );
			if ( it == m_ConverterMap.end() )
			{
				ATLTRACE("Error in SCTextEnumEx: NextToken has invalid converter.\n");
				ATLTRACE("Turning the Encoding off.\n");
				conv = NULL;	// 
			}
			else
			{
				conv = (CTKAndCodePageWrapper *) (*it).second;
			}
		}

	    *pbstrTag = qbstrToken.Copy();
	}

	if ( tt == tag )
	{
	    *pbstrTag = qbstrToken.Copy();
		ATLTRACE("marker=Index<%d> %.50S\n", iTagIndex, *pbstrTag );
	}
	else
	{
		if ( conv )
		{
			*pbstrTag = qbstrToken.Copy();
//			conv->Convert( (unsigned char*)qbstrToken, pbstr );
		}
		else
		{
			*pbstrTag = qbstrToken.Copy();
		}
		
		ATLTRACE("data=%.50S\n", *pbstrTag);
	}

	return hr;

	PROTECTION_END
}



STDMETHODIMP CSCTextEnumEx::NextToken(
		/*[out]*/ int *piTagIndex, 
		/*[out,retval]*/ BSTR *pbstr)
{
	PROTECTION_BEGIN

	HRESULT hr = S_OK;
	static CTKAndCodePageWrapper *conv = NULL;
	static bool bLastMarkerWasChapOrVerseNumber = false;

	ScrTokenType tt;

	if (!m_qstrText)
		return E_FAIL;

	*piTagIndex = -1;
//	CComBSTR qbstrToken = bstrBaseGetNextToken(tt, true);
	char * qstrToken = strBaseGetNextToken(tt, true, bLastMarkerWasChapOrVerseNumber);
	CComBSTR qbstrToken = CComBSTR(qstrToken);
//	BSTR token = SysAllocString( (OLECHAR*)(qstrToken));
	if (tt == tag) 
	{
//		hr = m_qScriptureText->TagIndex(token, piTagIndex);
		hr = m_qScriptureText->TagIndex((BSTR)qbstrToken, piTagIndex);
		CComPtr<ISCTag> pTag;
		m_qScriptureText->NthTag( *piTagIndex, &pTag );

		SCTextProperties scTProps;
		pTag->get_TextProperties( &scTProps );

		SCStyleType scSType;
		pTag->get_StyleType( &scSType );

		SCTextType scTType;
		pTag->get_TextType( &scTType );


		if ( scTProps & scChapter || scTProps & scVerse )	//this->GetParameter qbstrToken == VerseMarker   // scTType & scVerseNumber || scTType & scChapterNumber )
		{
			ATLTRACE("**TAG: Setting last chap/verse to TRUE\n");
			bLastMarkerWasChapOrVerseNumber = true;
		}

		// count sections
		if ( scTType & scSection )
		{
			ATLTRACE("**TAG: Found Section Tag\n");
		}

		// count paragraphs
		if ( scTType & scVerseText && scSType & scParagraphStyle)
		{
			ATLTRACE("**TAG: Found Paragraph Tag\n");
		}
		
		CComBSTR bstrEncodingName;
		pTag->get_Encoding( &bstrEncodingName );
		if ( bstrEncodingName.Length() == 0 )
		{
/////			ATLTRACE("No special encoding for this TAG.\n");
		}
		else
		{
//			CSCScriptureText *scText = (CSCScriptureText *) m_qScriptureText;
/////			ATLTRACE("Changing to the following Encoding.<%S>\n", bstrEncodingName );
			CComBSTR bstrName;
			pTag->get_Marker( &bstrName );

			char dest[256];
			WideCharToMultiByte( CP_ACP, 0, bstrName, -1, dest, 256, NULL, NULL );
			
//			MarkerInfo *mInfo = GetMarkerProps( dest );
			TMapIDToConverter::iterator it = m_ConverterMap.find( dest );
			if ( it == m_ConverterMap.end() )
			{
				ATLTRACE("Error in SCTextEnumEx: NextToken has invalid converter.\n");
				ATLTRACE("Turning the Encoding off.\n");
				conv = NULL;	// 
			}
			else
			{
				conv = (CTKAndCodePageWrapper *) (*it).second;

				// save this converter on some type of state stack and use on text until new tag is found

///				// just testing it for fun!!  CODE TO REMOVE
///				BSTR bout;
///				conv->Convert( (unsigned char*)dest, &bout );
///				SysFreeString( bout );
			}
		}
	}

//    *pbstr = qbstrToken.Copy();
	
	if ( tt == tag )
	{
	    *pbstr = qbstrToken.Copy();
		ATLTRACE("marker=Index<%d> %.50S\n", *piTagIndex, *pbstr );
	}
	else
	{
		if ( conv )
		{
//			*pbstr = qbstrToken.Copy();
			ATLTRACE("Using converter on data=%.50S\n", qbstrToken.m_str );

			conv->Convert( (unsigned char*)qstrToken, pbstr );
		}
		else
		{
			*pbstr = qbstrToken.Copy();
		}
		
		ATLTRACE("data=<%.50S>\n", *pbstr);
	}

	return hr;

	PROTECTION_END
}


//CComBSTR CSCTextEnumEx::bstrBaseGetNextToken(ScrTokenType& tt, bool bAsteriskIsMarker)
char *CSCTextEnumEx::strBaseGetNextToken(ScrTokenType& tt, bool bAsteriskIsMarker, bool & bLastWasChapOrVerseNumber)
{
    char ch;
    char chPrevious = 0;
    char *pToken = m_qstrToken;	// (BSTR)m_qbstrToken;
	*pToken = 0;

    tt = unknowntt; 
		// tt starts at unknowntt and becomes 'text' or 'tag' as soon as we know
		// what kind of token we have.

    while (*m_strStream) {
		ch = *m_strStream++;

        // Comment Handler
		// This assumes that the comment character cannot be newline 
        if (ch == m_chComment) {
            while (*m_strStream && ch != '\n' ) { 
                ch = *m_strStream++;    // trash everything from the comment character until the newline 
            }
        }

		if (ch == '\r')
			ch = *m_strStream++;   // Ignore \r
        
        if (! ch)
            break; // Break out of the loop since we hit the end of the file. 
        
		if ( bLastWasChapOrVerseNumber )
		{
			if ( chPrevious != 0 && chPrevious != ' ' &&		// have seen something besides spaces
				 ch == ' ' )									// and we're currently on the ws after a number
			{
				int asdfasdf = 134;
				m_strStream--;
				bLastWasChapOrVerseNumber = false;
				return m_qstrToken;
			}
		}

        switch (ch) {
        case '\\' : // SFM 
            switch (tt) {
                case text: // Fall through on purpose 
                case tag:
                    // If we are getting a tag or Text 
                    // move our current position in the file back one to get this tag
                    // the next time we get a token 
                    m_strStream--;
					return m_qstrToken;	// CComBSTR(wcslen((BSTR)m_qbstrToken), (BSTR)m_qbstrToken);
                default:
                    // Otherwise, we are getting an tag
                    tt = tag;
            }
            break;

		case '\t': // tabs are considered to be spaces.           
/////			ch = ' ';
				// Fall through on purpose
		case '\n': // New lines are considered to be spaces.
//		case '\r': // Carriage returns are considered to be spaces.
//		case '\f': // Formfeeds are considered to be spaces.
/////			ch = ' ';
            // Fall through on purpose
        case ' ' :
			// ch = ch;
            if (tt == tag)
			{
				m_strStream--;	// don't consume the character, leave for text
				return m_qstrToken;	// CComBSTR(wcslen((BSTR)m_qbstrToken), (BSTR)m_qbstrToken);
            }
			if (chPrevious == ' ')
                break;  // do not allow double spaces.
            // Fall through on purpose
        default:
            // If bare asterisks are allowed as markers mark them so and
            // make them terminate text tokens without being consumed.
            if (bAsteriskIsMarker && ch == '*') {
                if (tt == unknowntt)
                    tt = tag;
                else if (tt == text) {
                    m_strStream--;
                    goto done;
                }
            }

            if (tt == unknowntt) {
				//ATLTRACE("ch=%c\n", ch);
                tt = text;      
			}

			// Store character into buffer.
			*pToken++ = ch;
			*pToken = 0;

            // '*' always terminates a tag in order to allow us to distinguish
            // whether the space following a tag is significant.
            if (tt == tag && ch == '*')
				return m_qstrToken;	// CComBSTR(wcslen((BSTR)m_qbstrToken), (BSTR)m_qbstrToken);
            break;
        } // switch ch
        chPrevious = ch;
    } // loop

done:
	//ATLTRACE("tok=xx{%S}\n",(BSTR)m_qbstrToken);
	return m_qstrToken;	// CComBSTR(wcslen((BSTR)m_qbstrToken), (BSTR)m_qbstrToken);
}
