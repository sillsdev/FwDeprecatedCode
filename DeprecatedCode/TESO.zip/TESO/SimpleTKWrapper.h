#ifndef __SimpleTKWrapper_H__
#define __SimpleTKWrapper_H__

#include <comdef.h>
#include "teckit_engine.h"		// use the "kForm" encoding constants...

class CSimpleTKWrapper
{
public:

	enum EncodingForm { EF_Bytes		= kForm_Bytes, 
						EF_UTF8			= kForm_UTF8, 
						EF_UTF16BE		= kForm_UTF16BE, 
						EF_UTF16LE		= kForm_UTF16LE, 
						EF_UTF32BE		= kForm_UTF32BE, 
						EF_UTF32LE		= kForm_UTF32LE,
						EF_Unknown		= kForm_Unspecified,
	};

private:
	CSimpleTKWrapper();

public:
	CSimpleTKWrapper( char* fname, EncodingForm inForm = EF_Bytes, EncodingForm outForm = EF_UTF16LE );
	~CSimpleTKWrapper();

	bool IsValid()	{ return m_Valid; }
	
	HRESULT	Convert( unsigned char* in, BSTR* outBuff );	// inform to outform //go from Bytes to UTF16LE
	char*	Convert( BSTR* in );							// outform to inform //go from UTF16LE to Bytes

private:
	HRESULT ConvertBuffer(EncodingForm inForm, unsigned char* inBuffer, UInt32 inSize, EncodingForm outForm, char** out, UInt32 &outSize);

	TECkit_Converter	m_Converter;
	TECkit_Converter	m_ReverseConverter;
	UInt32				m_fSrc, m_fTarget, m_rSrc, m_rTarget;	// converter flags...
	bool m_Valid;
	EncodingForm		m_inForm, m_outForm;
};

#endif
