#include "stdafx.h"
#include "SimpleTKWrapper.h"
#include "TECkit_Compiler.h"


CSimpleTKWrapper::CSimpleTKWrapper( char* fileName, EncodingForm inForm/*=EF_Bytes*/, EncodingForm outForm/*=EF_UTF16LE*/) 
	:  m_Valid(false), m_Converter(0), m_ReverseConverter(0), m_fSrc(0), m_fTarget(0), m_rSrc(0), m_rTarget(0),
	  m_inForm(inForm), m_outForm(outForm)
{
	FILE*	tecFile = fopen( fileName, "rb");
	bool	srcBinary = false;					// by defult, file is thought to be a map file
	long	len;
	char*	text;
	Byte*	table;

	if (tecFile == 0) 
	{
		ATLTRACE( "** (%4d) File Error: unable to open Map file<%s>.\n", __LINE__, fileName );
		return;
	}

	fseek(tecFile, 0, SEEK_END);
	len = ftell(tecFile);
	fseek(tecFile, 0, SEEK_SET);

	text = (char*)malloc(len);
	if (text == 0) 
	{
		fclose(tecFile);
		return;	// return E_OUTOFMEMORY;
	}

	fread(text, 1, len, tecFile);
	fclose(tecFile);
	TECkit_Status status;

	///////////////////////////////////////////////////////////////////////
	//	File is in memory now, see if it's a map or tec file
	//
	char regSig[] = {"qMap"};
	char compSig[] = {"zQmp"};
	if ( !memcmp( text, regSig, sizeof( regSig )) || !memcmp( text, compSig, sizeof( compSig )))
	{
		ATLTRACE( "** (%4d) Passed Binary map file<%ld bytes> <%s>.\n", __LINE__, len, fileName );

		table = (Byte*)text;			// binary file already
		srcBinary = true;				// input file is a binary map
	}
	else
	{
		ATLTRACE( "** (%4d) Passed Text map file<%s>.\n", __LINE__, fileName );
		char	compress = 1;
		Byte*	compiledTable;
		UInt32	compiledSize;
		
		status = TECkit_Compile(text, len, compress, NULL, 0, &compiledTable, &compiledSize);
		free(text);
		
		if (status != kStatus_NoError) 
		{
			ATLTRACE( "** (%4d) Compile Error<%d>: unable to produce binary map file.\n", __LINE__, status );
			return;						// unsuccessful compile, file not valid...
		}
		else
		{
			ATLTRACE( "** (%4d) Compiled(%c) to make Binary Map: size<%ld bytes>.\n", __LINE__ , compress?'C':'R', compiledSize );
		}

		table = compiledTable;
		len = compiledSize;
	}

	m_Valid = true;						// return S_OK;

	while ( 1 )
	{
		///////////////////////////////////////////////////////////////////////
		//	Create forward converter
		//
		TECkit_Status	status = TECkit_CreateConverter((Byte*)table, len, 1, m_inForm, m_outForm, &m_Converter);
		if (status != kStatus_NoError) 
		{
			m_Converter = 0;
			m_Valid = false;	
			break;	//return;	// return AtlReportError( CLSID_ATLClass, "Invalid Mapping File Contents", 0, NULL, IID_IATLClassInt2, E_FAIL );
		}
		else
		{
			TECkit_GetConverterFlags( m_Converter, &m_fSrc, &m_fTarget );
///			ATLTRACE( "** (%4d) Created Forward Converter.\n", __LINE__ );
		}

		///////////////////////////////////////////////////////////////////////
		//	Create reverse converter
		//
		status = TECkit_CreateConverter((Byte*)table, len, 0, m_outForm, m_inForm, &m_ReverseConverter);
		if (status != kStatus_NoError) 
		{
			m_ReverseConverter = 0;
			m_Valid = false;	
		}
		else
		{
			TECkit_GetConverterFlags( m_ReverseConverter, &m_rSrc, &m_rTarget );
///			ATLTRACE( "** (%4d) Created Reverse Converter.\n", __LINE__ );
		}
		break;	// return;	
	}

	if ( srcBinary )
		free( table );
	else
		TECkit_DisposeCompiled( table );

}


CSimpleTKWrapper::~CSimpleTKWrapper()
{
	if ( m_Converter )
	{
		TECkit_DisposeConverter( m_Converter );
		m_Converter = NULL;
	}

	if ( m_ReverseConverter )
	{
		TECkit_DisposeConverter( m_ReverseConverter );
		m_ReverseConverter = NULL;
	}
}

void LogMsg( char* msg, int lineNum, TECkit_Status errorCode, UInt32 inSize, UInt32 inUsed, UInt32 outSize, UInt32 outUsed )
{
	ATLTRACE( "** (%4d) %16s<%d>: ", lineNum, msg, errorCode );
	ATLTRACE( " inSize =%6ld, inUsed =%6ld, ", inSize, inUsed);
	ATLTRACE( " outSize=%6ld, outUsed=%6ld\n", outSize, outUsed);
}

void ShowError( int lineNum, TECkit_Status errorCode, UInt32 inUsed, UInt32 outUsed )
{
	ATLTRACE( "** (%4d) ConvertError<%d>: ", lineNum, errorCode );
	ATLTRACE( " inUsed=%ld, outUsed=%ld\n", inUsed, outUsed);	///
}

void ShowError( int lineNum, TECkit_Status errorCode, UInt32 inSize, UInt32 inUsed, UInt32 outSize, UInt32 outUsed )
{
#ifdef _DEBUG
	LogMsg( "ConvertError", lineNum, errorCode, inSize, inUsed, outSize, outUsed );
#endif
}


HRESULT CSimpleTKWrapper::ConvertBuffer(EncodingForm inForm, unsigned char* inBuffer, UInt32 inSize, EncodingForm outForm, char** out, UInt32 &outSize)
{
	if ( inSize == 0 || !this->IsValid() )
	{
		ShowError( __LINE__, 0, 0, 0 );
		return E_INVALIDARG;
	}

	///////////////////////////////////////////////////////////////////////
	//	establish data multipliers and converter direction
	//
	TECkit_Converter* pConverter = &m_Converter;	// use forward converter by default
///	ATLTRACE( "** (%4d) Defaulting to the forward Converter: initially\n", __LINE__ );
	
	// code to handle special case where mapping file is going different ways
	// from the standard understanding of LHS and RHS (Byte->Unicode)
	//
	if ( inForm == EF_Bytes )					// src is Bytes
	{
		if ( !(m_fSrc & kFlags_Unicode))		// forward LHS is Bytes
			;									// use the Forward Converter
		else if ( !(m_rSrc & kFlags_Unicode))	// reverse LHS is Bytes
		{
			pConverter = &m_ReverseConverter;	// have to use the reverse converter
			ATLTRACE( "** (%4d) Using Reverse Converter\n", __LINE__ );
		}
	}
	else										// src is Unicode
	{
		if ( m_fSrc & kFlags_Unicode )			// forward LHS is Unicode
			;									// use the Forward Converter
		else if ( m_rSrc & kFlags_Unicode )		// reverse LHS is Unicode
		{
			pConverter = &m_ReverseConverter;	// have to use the reverse converter
			ATLTRACE( "** (%4d) Using Reverse Converter\n", __LINE__ );
		}
	}

	short mul, inMul = 0, outMul = 0;
	struct {
		EncodingForm c;
		short m;
	} EncodingValues[] = {	{ EF_Bytes	, 1 }, { EF_UTF8   , 2 }, { EF_UTF16LE, 2 }, { EF_UTF16BE, 2 }, 
							{ EF_UTF32LE, 4 }, { EF_UTF32BE, 4 }, { EF_Unknown, 0 }
	};

	for( int i=0; EncodingValues[i].c != EF_Unknown; i++ )
		if ( EncodingValues[i].c == inForm )
		{
			inMul = EncodingValues[i].m;
			break;
		}

	for( i=0; EncodingValues[i].c != EF_Unknown; i++ )
		if ( EncodingValues[i].c == outForm )
		{
			outMul = EncodingValues[i].m;
			break;
		}
	
	mul = outMul / inMul;
	if ( mul < 1 )
		mul = 1;
	mul += (mul >> 1 );			// add an extra half on
	outSize = inSize * mul;		// for testing reallocation...

	///////////////////////////////////////////////////////////////////////
	//	allocate the output buffer
	//
	unsigned char* outBuffer = (unsigned char*)malloc( outSize );					// allocate the buffer
	if (outBuffer == 0) 
	{
		ShowError( __LINE__, 0, 0, 0 );
		return E_OUTOFMEMORY;
	}

///	LogMsg( "Before Convert", __LINE__, 0, inSize, 0, outSize, 0 );

	TECkit_Status errorCode;
	UInt32 inUsed, outUsed;
	bool done = false;
	bool success = false;

	unsigned char * inPos  = inBuffer;
	unsigned char * outPos = outBuffer;
	UInt32 inRemaining = inSize, outRemaining = outSize;
	UInt32 ttlInUsed = 0, ttlOutUsed = 0;

	while( !done )
	{
		errorCode = TECkit_ConvertBuffer( *pConverter, (const byte *)inPos, inRemaining, &inUsed,
											(unsigned char*)outPos, outRemaining, &outUsed, 0);
		ttlOutUsed += outUsed;
		ttlInUsed += inUsed;
		outPos += outUsed;
		inPos += inUsed;
		outRemaining -= outUsed;

///		LogMsg( "After Convert", __LINE__, errorCode, inSize, ttlInUsed, outSize, ttlOutUsed );

		switch (errorCode)
		{
			case kStatus_NeedMoreInput:		// parsed the whole input string
				done = true;
				success = true;
				break;

			case kStatus_OutputBufferFull:	// increase the output buffer size
				ShowError( __LINE__, errorCode, inRemaining, inUsed, outRemaining, outUsed );
				ATLTRACE("** (%4d) Increasing buffer size: from<%ld> by <%ld>\n", __LINE__, outSize, inSize );
				outSize += inSize;
				outRemaining += inSize;
				outBuffer = (unsigned char*)realloc( outBuffer, outSize );
				inRemaining = inSize - ttlInUsed;
				break;

			case kStatus_NoError:			// ??, should get need more input for a successfull pass
			default:						// some unhandled error
				done = true;
				break;
		}
	}
	inUsed = ttlInUsed;
	outUsed = ttlOutUsed;

	if ( !success )
	{
		free( outBuffer );
		ShowError( __LINE__, errorCode, inUsed, outUsed );
		return HRESULT_FROM_WIN32( errorCode );
	}

	///////////////////////////////////////////////////////////////////////
	// flush the converter
	//
	unsigned long usedMore;
	do 
	{
		errorCode = TECkit_Flush( *pConverter, (unsigned char*)outPos, outRemaining, &usedMore );
		outPos += usedMore;
		outUsed += usedMore;
		outRemaining -= usedMore;
		// 7/17 added
		if ( errorCode == kStatus_OutputBufferFull ) // && outRemaining == 0 )		// no more room in output
		{
			ATLTRACE("** (%4d) Flushing buffer: Increasing buffer size: from<%ld> by <%ld>\n", __LINE__, outSize, inSize );
			outSize += inSize;
			outRemaining += inSize;
			outBuffer = (unsigned char*)realloc( outBuffer, outSize );
			inRemaining = inSize - ttlInUsed;

		}
		// 7/17 end
	} while (errorCode == kStatus_OutputBufferFull);

	if ( errorCode != kStatus_NoError)
	{
		ShowError( __LINE__, errorCode, inUsed, outUsed );
		return E_FAIL;
	}

	///////////////////////////////////////////////////////////////////////
	// Reset the converter
	//
	errorCode = TECkit_ResetConverter( *pConverter );

	if ( outForm == EF_Bytes )	// add zero byte at end of string
		(*(outBuffer+outUsed)) = '\0';

//	LogMsg( "--Finished-- ",  __LINE__, errorCode, inSize, inUsed, outSize, outUsed );

	outSize = outUsed;
	*out = (char*)outBuffer;

	return S_OK;
}


HRESULT CSimpleTKWrapper::Convert( unsigned char* in, BSTR* outBuff )	// go from Bytes to UTF16LE
{
	char* out=NULL;
	UInt32 inLen = (UInt32)strlen( (const char*)in );
	UInt32 outLen;

	// handle special case where there is no string passed in
	if ( inLen == 0 )
	{
		*outBuff = SysAllocString( L"" );
		return S_OK;
	}

	HRESULT hr = ConvertBuffer(m_inForm, in, inLen, m_outForm, &out, outLen);
	if ( hr != S_OK )
		return hr;

	long outUsed = outLen;	// strlen( out );
	long numChars = outUsed >> 1;	// convert from bytes to int
	BSTR b = SysAllocStringByteLen( (const char*)out, outUsed );
	CComBSTR toReturn( b );
	*outBuff = toReturn.Copy();	// Detach();	// Copy();
	free(out);

	return S_OK;
}


char* CSimpleTKWrapper::Convert( BSTR* in )	// go from UTF16LE to Bytes
{
	char* out=NULL;
	UInt32 outLen, inLen = SysStringByteLen( *in );

	HRESULT hr = ConvertBuffer(m_outForm, (unsigned char*)(*in), inLen, m_inForm, &out, outLen);
	if ( hr != S_OK )
		return NULL;	// hr;

	return out;	// S_OK;
}
