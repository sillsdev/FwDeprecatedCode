#include "stdafx.h"


ScriptureRawTextStream::ScriptureRawTextStream(
		vector<RangeToFile>& vecrtf,		
		HANDLE hCCTable   // Handle to Compiled CC table, 0 if none.
	) : m_vecrtf(vecrtf)
{
	m_fIsOpen = false;   
	m_hCCTable = hCCTable;
}


char* ScriptureRawTextStream::ProcessInlineFootNotes( char * inBuf )
{
	return inBuf;
}

void ScriptureRawTextStream::open(char* pszFileName, int iMode)
{
	HANDLE hFile;
	BY_HANDLE_FILE_INFORMATION fileData;

	m_fIsOpen = false;

	USES_CONVERSION;

	// Open file, get its size info, create buffer to hold contents
	hFile = CreateFile(pszFileName,  
					GENERIC_READ,              // open for reading 
					FILE_SHARE_READ,           // share for reading 
					NULL,                      // no security 
					OPEN_EXISTING,             // existing file only 
					FILE_ATTRIBUTE_NORMAL,     // normal file 
					NULL);                     // no attr. template 
	if (hFile == INVALID_HANDLE_VALUE) 
		return;
	if (! GetFileInformationByHandle(hFile, &fileData)) {
		CloseHandle(hFile); 
		return;
	}
	int nFileSize = (int)fileData.nFileSizeLow;
	char* pBuf = new char[nFileSize + 10];

	// Read file and run it thru mapin.cct (if present)
	DWORD nRead = 0;
	ReadFile(hFile, (LPVOID)pBuf, nFileSize, &nRead, NULL);
	if (nRead != nFileSize)
		return;
	pBuf[nFileSize] = 0;
	char* pBuf2 = pBuf;
	if (m_hCCTable) 
		pBuf2 = RunCC(m_hCCTable, pBuf);

	// Add embedded footnote processing
	char* pBuf3 = pBuf2;
	bool bSomeOtherFlagSetToCheckForInLineFootNotes = false;
	if ( bSomeOtherFlagSetToCheckForInLineFootNotes )
		pBuf3 = ProcessInlineFootNotes( pBuf2 );
	// End embedded footnote processing

	// Assign the mapped string to this stream.
	str(string(pBuf3)); // Create a stream based on this string

	ATLTRACE("%d bytes read from %s\n", strlen(pBuf3), pszFileName);

	m_fIsOpen = true;

	if (pBuf3 != pBuf2)
		delete pBuf3;
	if (pBuf2 != pBuf)
		delete pBuf2;
	delete pBuf;

	CloseHandle(hFile); 
}


void ScriptureRawTextStream::OpenFile(ScriptureReference srf, bool fFirstAvailable)
{
	m_bEOS = true;

	// Look for file whose reference range begins at or after this reference
	m_rtfi = m_vecrtf.begin();
	while (m_rtfi != m_vecrtf.end()) {
		// If looking for first available material at or past this point
		// it is enough if the end of the range is past the selected point
		if (fFirstAvailable && (m_rtfi->m_srfLast >= srf))
			break;

		// Other wise the reference must lie entirely in the range.
		if ((srf >= m_rtfi->m_srfFirst) && (srf <= m_rtfi->m_srfLast))
			break;
		++m_rtfi;
	}

	// If no such file found, return
	if (m_rtfi == m_vecrtf.end())
		return;

	// Otherwise, opened the file
	USES_CONVERSION;
	open(OLE2A(m_rtfi->m_cbstrFileName), ios::binary | ios::in  );
	if (is_open()) {
		m_bEOS = false;
		return;
	}

	if (m_rtfi->m_srfFirst.iBook() == srf.iBook()) {
		// We actually found the book we were looking for
		// so seek to the beginning of the requested chapter.
		int iOffset = m_rtfi->iChapterOffset(srf.iChapter());

		// If we didn't find the chapter we are looking for,
		// keep looking until we find one.
		int iChapter = srf.iChapter();
		while (iOffset == notFound  && iChapter <= 151)
			iOffset = m_rtfi->iChapterOffset(++iChapter);
		if (iOffset < 0) {
			m_bEOS = true;
			return;
		}

		seekg(iOffset);
	}
}



int ScriptureRawTextStream::iSize()
{
	int iSave = tellg();
	seekg(0, ios::end);
	int iOffset = tellg();
	seekg(iSave);
	return iOffset;
}


CComBSTR ScriptureRawTextStream::CurrentFileName()
{
	return m_rtfi->m_cbstrFileName;
}


void ScriptureRawTextStream::OpenNextFile()
{
	m_rtfi++;

	if (m_rtfi == m_vecrtf.end()) {
		m_bEOS = true;
		return;
	}

	close();
	clear();

	USES_CONVERSION;
	open(OLE2A(m_rtfi->m_cbstrFileName), ios::binary | ios::in);
}
