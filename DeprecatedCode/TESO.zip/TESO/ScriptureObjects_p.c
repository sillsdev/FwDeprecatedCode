

/* this ALWAYS GENERATED file contains the proxy stub code */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Fri May 21 13:32:49 2004
 */
/* Compiler settings for ScriptureObjects.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if !defined(_M_IA64) && !defined(_M_AMD64)


#pragma warning( disable: 4049 )  /* more than 64k source lines */
#if _MSC_VER >= 1200
#pragma warning(push)
#endif
#pragma warning( disable: 4100 ) /* unreferenced arguments in x86 call */
#pragma warning( disable: 4211 )  /* redefine extent to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/
#define USE_STUBLESS_PROXY


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 475
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif // __RPCPROXY_H_VERSION__


#include "ScriptureObjects.h"

#define TYPE_FORMAT_STRING_SIZE   1273                              
#define PROC_FORMAT_STRING_SIZE   5857                              
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   2            

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


static RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCReference_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCReference_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCReferenceCollection_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCReferenceCollection_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCTag_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCTag_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCTextSegment_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCTextSegment_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCTextEnum_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCTextEnum_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCTextEnumEx_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCTextEnumEx_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCScriptureText_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCScriptureText_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCScriptureText2_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCScriptureText2_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCScriptureText3_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCScriptureText3_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCScriptureText4_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCScriptureText4_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IPreSO_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IPreSO_ProxyInfo;


extern const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ];

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT50_OR_LATER)
#error You need a Windows 2000 or later to run this stub because it uses these features:
#error   /robust command line switch.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will die there with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure get_Book */

			0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x7 ),	/* 7 */
/*  8 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 10 */	NdrFcShort( 0x0 ),	/* 0 */
/* 12 */	NdrFcShort( 0x22 ),	/* 34 */
/* 14 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 16 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 18 */	NdrFcShort( 0x0 ),	/* 0 */
/* 20 */	NdrFcShort( 0x0 ),	/* 0 */
/* 22 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 24 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 26 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 28 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 30 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 32 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 34 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Book */

/* 36 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 38 */	NdrFcLong( 0x0 ),	/* 0 */
/* 42 */	NdrFcShort( 0x8 ),	/* 8 */
/* 44 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 46 */	NdrFcShort( 0x6 ),	/* 6 */
/* 48 */	NdrFcShort( 0x8 ),	/* 8 */
/* 50 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 52 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 54 */	NdrFcShort( 0x0 ),	/* 0 */
/* 56 */	NdrFcShort( 0x0 ),	/* 0 */
/* 58 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 60 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 62 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 64 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 66 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 68 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 70 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Chapter */

/* 72 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 74 */	NdrFcLong( 0x0 ),	/* 0 */
/* 78 */	NdrFcShort( 0x9 ),	/* 9 */
/* 80 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 82 */	NdrFcShort( 0x0 ),	/* 0 */
/* 84 */	NdrFcShort( 0x22 ),	/* 34 */
/* 86 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 88 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 90 */	NdrFcShort( 0x0 ),	/* 0 */
/* 92 */	NdrFcShort( 0x0 ),	/* 0 */
/* 94 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 96 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 98 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 100 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 102 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 104 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 106 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Chapter */

/* 108 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 110 */	NdrFcLong( 0x0 ),	/* 0 */
/* 114 */	NdrFcShort( 0xa ),	/* 10 */
/* 116 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 118 */	NdrFcShort( 0x6 ),	/* 6 */
/* 120 */	NdrFcShort( 0x8 ),	/* 8 */
/* 122 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 124 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 126 */	NdrFcShort( 0x0 ),	/* 0 */
/* 128 */	NdrFcShort( 0x0 ),	/* 0 */
/* 130 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 132 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 134 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 136 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 138 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 140 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 142 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Verse */

/* 144 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 146 */	NdrFcLong( 0x0 ),	/* 0 */
/* 150 */	NdrFcShort( 0xb ),	/* 11 */
/* 152 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 154 */	NdrFcShort( 0x0 ),	/* 0 */
/* 156 */	NdrFcShort( 0x22 ),	/* 34 */
/* 158 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 160 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 162 */	NdrFcShort( 0x0 ),	/* 0 */
/* 164 */	NdrFcShort( 0x0 ),	/* 0 */
/* 166 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 168 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 170 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 172 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 174 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 176 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 178 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Verse */

/* 180 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 182 */	NdrFcLong( 0x0 ),	/* 0 */
/* 186 */	NdrFcShort( 0xc ),	/* 12 */
/* 188 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 190 */	NdrFcShort( 0x6 ),	/* 6 */
/* 192 */	NdrFcShort( 0x8 ),	/* 8 */
/* 194 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 196 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 198 */	NdrFcShort( 0x0 ),	/* 0 */
/* 200 */	NdrFcShort( 0x0 ),	/* 0 */
/* 202 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 204 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 206 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 208 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 210 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 212 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 214 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Segment */

/* 216 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 218 */	NdrFcLong( 0x0 ),	/* 0 */
/* 222 */	NdrFcShort( 0xd ),	/* 13 */
/* 224 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 226 */	NdrFcShort( 0x0 ),	/* 0 */
/* 228 */	NdrFcShort( 0x22 ),	/* 34 */
/* 230 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 232 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 234 */	NdrFcShort( 0x0 ),	/* 0 */
/* 236 */	NdrFcShort( 0x0 ),	/* 0 */
/* 238 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 240 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 242 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 244 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 246 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 248 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 250 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Segment */

/* 252 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 254 */	NdrFcLong( 0x0 ),	/* 0 */
/* 258 */	NdrFcShort( 0xe ),	/* 14 */
/* 260 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 262 */	NdrFcShort( 0x6 ),	/* 6 */
/* 264 */	NdrFcShort( 0x8 ),	/* 8 */
/* 266 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 268 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 270 */	NdrFcShort( 0x0 ),	/* 0 */
/* 272 */	NdrFcShort( 0x0 ),	/* 0 */
/* 274 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 276 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 278 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 280 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 282 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 284 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 286 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LastBook */

/* 288 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 290 */	NdrFcLong( 0x0 ),	/* 0 */
/* 294 */	NdrFcShort( 0xf ),	/* 15 */
/* 296 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 298 */	NdrFcShort( 0x0 ),	/* 0 */
/* 300 */	NdrFcShort( 0x22 ),	/* 34 */
/* 302 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 304 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 306 */	NdrFcShort( 0x0 ),	/* 0 */
/* 308 */	NdrFcShort( 0x0 ),	/* 0 */
/* 310 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 312 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 314 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 316 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 318 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 320 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 322 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LastChapter */

/* 324 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 326 */	NdrFcLong( 0x0 ),	/* 0 */
/* 330 */	NdrFcShort( 0x10 ),	/* 16 */
/* 332 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 334 */	NdrFcShort( 0x0 ),	/* 0 */
/* 336 */	NdrFcShort( 0x22 ),	/* 34 */
/* 338 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 340 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 342 */	NdrFcShort( 0x0 ),	/* 0 */
/* 344 */	NdrFcShort( 0x0 ),	/* 0 */
/* 346 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 348 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 350 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 352 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 354 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 356 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 358 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LastVerse */

/* 360 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 362 */	NdrFcLong( 0x0 ),	/* 0 */
/* 366 */	NdrFcShort( 0x11 ),	/* 17 */
/* 368 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 370 */	NdrFcShort( 0x0 ),	/* 0 */
/* 372 */	NdrFcShort( 0x22 ),	/* 34 */
/* 374 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 376 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 378 */	NdrFcShort( 0x0 ),	/* 0 */
/* 380 */	NdrFcShort( 0x0 ),	/* 0 */
/* 382 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 384 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 386 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 388 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 390 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 392 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 394 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Fontname */


	/* Procedure Parse */

/* 396 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 398 */	NdrFcLong( 0x0 ),	/* 0 */
/* 402 */	NdrFcShort( 0x12 ),	/* 18 */
/* 404 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 406 */	NdrFcShort( 0x0 ),	/* 0 */
/* 408 */	NdrFcShort( 0x8 ),	/* 8 */
/* 410 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 412 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 414 */	NdrFcShort( 0x0 ),	/* 0 */
/* 416 */	NdrFcShort( 0x1 ),	/* 1 */
/* 418 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */


	/* Parameter val */

/* 420 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 422 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 424 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */


	/* Return value */

/* 426 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 428 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 430 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NextVerse */

/* 432 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 434 */	NdrFcLong( 0x0 ),	/* 0 */
/* 438 */	NdrFcShort( 0x13 ),	/* 19 */
/* 440 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 442 */	NdrFcShort( 0x0 ),	/* 0 */
/* 444 */	NdrFcShort( 0x8 ),	/* 8 */
/* 446 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x1,		/* 1 */
/* 448 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 450 */	NdrFcShort( 0x0 ),	/* 0 */
/* 452 */	NdrFcShort( 0x0 ),	/* 0 */
/* 454 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Return value */

/* 456 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 458 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 460 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure PreviousVerse */

/* 462 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 464 */	NdrFcLong( 0x0 ),	/* 0 */
/* 468 */	NdrFcShort( 0x14 ),	/* 20 */
/* 470 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 472 */	NdrFcShort( 0x0 ),	/* 0 */
/* 474 */	NdrFcShort( 0x8 ),	/* 8 */
/* 476 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x1,		/* 1 */
/* 478 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 480 */	NdrFcShort( 0x0 ),	/* 0 */
/* 482 */	NdrFcShort( 0x0 ),	/* 0 */
/* 484 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Return value */

/* 486 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 488 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 490 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_AsString */

/* 492 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 494 */	NdrFcLong( 0x0 ),	/* 0 */
/* 498 */	NdrFcShort( 0x15 ),	/* 21 */
/* 500 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 502 */	NdrFcShort( 0x0 ),	/* 0 */
/* 504 */	NdrFcShort( 0x8 ),	/* 8 */
/* 506 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 508 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 510 */	NdrFcShort( 0x1 ),	/* 1 */
/* 512 */	NdrFcShort( 0x0 ),	/* 0 */
/* 514 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 516 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 518 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 520 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 522 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 524 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 526 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_VersificationsPresent */

/* 528 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 530 */	NdrFcLong( 0x0 ),	/* 0 */
/* 534 */	NdrFcShort( 0x16 ),	/* 22 */
/* 536 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 538 */	NdrFcShort( 0x0 ),	/* 0 */
/* 540 */	NdrFcShort( 0x8 ),	/* 8 */
/* 542 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 544 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 546 */	NdrFcShort( 0x1 ),	/* 1 */
/* 548 */	NdrFcShort( 0x0 ),	/* 0 */
/* 550 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 552 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 554 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 556 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 558 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 560 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 562 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_JustificationType */


	/* Procedure get_Versification */

/* 564 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 566 */	NdrFcLong( 0x0 ),	/* 0 */
/* 570 */	NdrFcShort( 0x17 ),	/* 23 */
/* 572 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 574 */	NdrFcShort( 0x0 ),	/* 0 */
/* 576 */	NdrFcShort( 0x22 ),	/* 34 */
/* 578 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 580 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 582 */	NdrFcShort( 0x0 ),	/* 0 */
/* 584 */	NdrFcShort( 0x0 ),	/* 0 */
/* 586 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 588 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 590 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 592 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */


	/* Return value */

/* 594 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 596 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 598 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_JustificationType */


	/* Procedure put_Versification */

/* 600 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 602 */	NdrFcLong( 0x0 ),	/* 0 */
/* 606 */	NdrFcShort( 0x18 ),	/* 24 */
/* 608 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 610 */	NdrFcShort( 0x6 ),	/* 6 */
/* 612 */	NdrFcShort( 0x8 ),	/* 8 */
/* 614 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 616 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 618 */	NdrFcShort( 0x0 ),	/* 0 */
/* 620 */	NdrFcShort( 0x0 ),	/* 0 */
/* 622 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 624 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 626 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 628 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 630 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 632 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 634 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LeftMargin */


	/* Procedure get_Valid */

/* 636 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 638 */	NdrFcLong( 0x0 ),	/* 0 */
/* 642 */	NdrFcShort( 0x19 ),	/* 25 */
/* 644 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 646 */	NdrFcShort( 0x0 ),	/* 0 */
/* 648 */	NdrFcShort( 0x24 ),	/* 36 */
/* 650 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 652 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 654 */	NdrFcShort( 0x0 ),	/* 0 */
/* 656 */	NdrFcShort( 0x0 ),	/* 0 */
/* 658 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */


	/* Parameter pVal */

/* 660 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 662 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 664 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 666 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 668 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 670 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure ChangeVersification */

/* 672 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 674 */	NdrFcLong( 0x0 ),	/* 0 */
/* 678 */	NdrFcShort( 0x1a ),	/* 26 */
/* 680 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 682 */	NdrFcShort( 0x6 ),	/* 6 */
/* 684 */	NdrFcShort( 0x8 ),	/* 8 */
/* 686 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 688 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 690 */	NdrFcShort( 0x0 ),	/* 0 */
/* 692 */	NdrFcShort( 0x0 ),	/* 0 */
/* 694 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter NewVersification */

/* 696 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 698 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 700 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 702 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 704 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 706 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LineSpacing */


	/* Procedure get_BBCCCVVV */

/* 708 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 710 */	NdrFcLong( 0x0 ),	/* 0 */
/* 714 */	NdrFcShort( 0x1b ),	/* 27 */
/* 716 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 718 */	NdrFcShort( 0x0 ),	/* 0 */
/* 720 */	NdrFcShort( 0x24 ),	/* 36 */
/* 722 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 724 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 726 */	NdrFcShort( 0x0 ),	/* 0 */
/* 728 */	NdrFcShort( 0x0 ),	/* 0 */
/* 730 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */


	/* Parameter pVal */

/* 732 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 734 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 736 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 738 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 740 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 742 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure SetToEnd */

/* 744 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 746 */	NdrFcLong( 0x0 ),	/* 0 */
/* 750 */	NdrFcShort( 0x1c ),	/* 28 */
/* 752 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 754 */	NdrFcShort( 0x0 ),	/* 0 */
/* 756 */	NdrFcShort( 0x8 ),	/* 8 */
/* 758 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x1,		/* 1 */
/* 760 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 762 */	NdrFcShort( 0x0 ),	/* 0 */
/* 764 */	NdrFcShort( 0x0 ),	/* 0 */
/* 766 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Return value */

/* 768 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 770 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 772 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Bold */


	/* Procedure get_Count */

/* 774 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 776 */	NdrFcLong( 0x0 ),	/* 0 */
/* 780 */	NdrFcShort( 0x7 ),	/* 7 */
/* 782 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 784 */	NdrFcShort( 0x0 ),	/* 0 */
/* 786 */	NdrFcShort( 0x24 ),	/* 36 */
/* 788 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 790 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 792 */	NdrFcShort( 0x0 ),	/* 0 */
/* 794 */	NdrFcShort( 0x0 ),	/* 0 */
/* 796 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */


	/* Parameter pVal */

/* 798 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 800 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 802 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 804 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 806 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 808 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Item */

/* 810 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 812 */	NdrFcLong( 0x0 ),	/* 0 */
/* 816 */	NdrFcShort( 0x8 ),	/* 8 */
/* 818 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 820 */	NdrFcShort( 0x8 ),	/* 8 */
/* 822 */	NdrFcShort( 0x8 ),	/* 8 */
/* 824 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 826 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 828 */	NdrFcShort( 0x20 ),	/* 32 */
/* 830 */	NdrFcShort( 0x0 ),	/* 0 */
/* 832 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter index */

/* 834 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 836 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 838 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pItem */

/* 840 */	NdrFcShort( 0x4113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=16 */
/* 842 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 844 */	NdrFcShort( 0x42c ),	/* Type Offset=1068 */

	/* Return value */

/* 846 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 848 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 850 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Parse */

/* 852 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 854 */	NdrFcLong( 0x0 ),	/* 0 */
/* 858 */	NdrFcShort( 0x9 ),	/* 9 */
/* 860 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 862 */	NdrFcShort( 0x0 ),	/* 0 */
/* 864 */	NdrFcShort( 0x8 ),	/* 8 */
/* 866 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 868 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 870 */	NdrFcShort( 0x0 ),	/* 0 */
/* 872 */	NdrFcShort( 0x2 ),	/* 2 */
/* 874 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrReferences */

/* 876 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 878 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 880 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter bstrCommentCharacter */

/* 882 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 884 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 886 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 888 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 890 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 892 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_AsString */

/* 894 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 896 */	NdrFcLong( 0x0 ),	/* 0 */
/* 900 */	NdrFcShort( 0xa ),	/* 10 */
/* 902 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 904 */	NdrFcShort( 0x0 ),	/* 0 */
/* 906 */	NdrFcShort( 0x8 ),	/* 8 */
/* 908 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 910 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 912 */	NdrFcShort( 0x1 ),	/* 1 */
/* 914 */	NdrFcShort( 0x0 ),	/* 0 */
/* 916 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 918 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 920 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 922 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 924 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 926 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 928 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Add */

/* 930 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 932 */	NdrFcLong( 0x0 ),	/* 0 */
/* 936 */	NdrFcShort( 0xb ),	/* 11 */
/* 938 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 940 */	NdrFcShort( 0x0 ),	/* 0 */
/* 942 */	NdrFcShort( 0x8 ),	/* 8 */
/* 944 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 946 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 948 */	NdrFcShort( 0x0 ),	/* 0 */
/* 950 */	NdrFcShort( 0x0 ),	/* 0 */
/* 952 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReference */

/* 954 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 956 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 958 */	NdrFcShort( 0x436 ),	/* Type Offset=1078 */

	/* Return value */

/* 960 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 962 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 964 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Insert */

/* 966 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 968 */	NdrFcLong( 0x0 ),	/* 0 */
/* 972 */	NdrFcShort( 0xc ),	/* 12 */
/* 974 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 976 */	NdrFcShort( 0x0 ),	/* 0 */
/* 978 */	NdrFcShort( 0x8 ),	/* 8 */
/* 980 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 982 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 984 */	NdrFcShort( 0x0 ),	/* 0 */
/* 986 */	NdrFcShort( 0x0 ),	/* 0 */
/* 988 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReference */

/* 990 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 992 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 994 */	NdrFcShort( 0x436 ),	/* Type Offset=1078 */

	/* Return value */

/* 996 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 998 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1000 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Remove */

/* 1002 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1004 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1008 */	NdrFcShort( 0xd ),	/* 13 */
/* 1010 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1012 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1014 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1016 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1018 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1020 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1022 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1024 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter index */

/* 1026 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1028 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1030 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1032 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1034 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1036 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Includes */

/* 1038 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1040 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1044 */	NdrFcShort( 0xe ),	/* 14 */
/* 1046 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1048 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1050 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1052 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 1054 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1056 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1058 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1060 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReference */

/* 1062 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 1064 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1066 */	NdrFcShort( 0x436 ),	/* Type Offset=1078 */

	/* Parameter fVal */

/* 1068 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1070 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1072 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1074 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1076 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1078 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get__NewEnum */

/* 1080 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1082 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1086 */	NdrFcShort( 0xf ),	/* 15 */
/* 1088 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1090 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1092 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1094 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1096 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1098 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1100 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1102 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 1104 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 1106 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1108 */	NdrFcShort( 0x448 ),	/* Type Offset=1096 */

	/* Return value */

/* 1110 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1112 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1114 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Bold */

/* 1116 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1118 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1122 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1124 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1126 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1128 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1130 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1132 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1134 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1136 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1138 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 1140 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1142 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1144 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1146 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1148 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1150 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Color */

/* 1152 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1154 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1158 */	NdrFcShort( 0x9 ),	/* 9 */
/* 1160 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1162 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1164 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1166 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1168 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1170 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1172 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1174 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 1176 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1178 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1180 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1182 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1184 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1186 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Color */

/* 1188 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1190 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1194 */	NdrFcShort( 0xa ),	/* 10 */
/* 1196 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1198 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1200 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1202 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1204 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1206 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1208 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1210 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1212 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1214 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1216 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1218 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1220 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1222 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Text */


	/* Procedure get_Description */

/* 1224 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1226 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1230 */	NdrFcShort( 0xb ),	/* 11 */
/* 1232 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1234 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1236 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1238 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1240 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1242 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1244 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1246 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */


	/* Parameter pbstr */

/* 1248 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1250 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1252 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */


	/* Return value */

/* 1254 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1256 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1258 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Text */


	/* Procedure put_Description */

/* 1260 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1262 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1266 */	NdrFcShort( 0xc ),	/* 12 */
/* 1268 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1270 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1272 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1274 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1276 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1278 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1280 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1282 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */


	/* Parameter bstr */

/* 1284 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1286 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1288 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */


	/* Return value */

/* 1290 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1292 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1294 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Endmarker */

/* 1296 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1298 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1302 */	NdrFcShort( 0xd ),	/* 13 */
/* 1304 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1306 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1308 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1310 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1312 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1314 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1316 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1318 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1320 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1322 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1324 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1326 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1328 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1330 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Endmarker */

/* 1332 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1334 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1338 */	NdrFcShort( 0xe ),	/* 14 */
/* 1340 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1342 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1344 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1346 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1348 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1350 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1352 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1354 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 1356 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1358 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1360 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 1362 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1364 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1366 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FirstLineIndent */

/* 1368 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1370 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1374 */	NdrFcShort( 0xf ),	/* 15 */
/* 1376 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1378 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1380 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1382 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1384 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1386 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1388 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1390 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 1392 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1394 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1396 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1398 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1400 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1402 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FirstLineIndent */

/* 1404 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1406 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1410 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1412 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1414 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1416 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1418 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1420 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1422 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1424 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1426 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1428 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1430 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1432 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1434 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1436 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1438 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Fontname */

/* 1440 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1442 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1446 */	NdrFcShort( 0x11 ),	/* 17 */
/* 1448 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1450 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1452 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1454 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1456 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1458 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1460 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1462 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1464 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1466 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1468 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1470 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1472 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1474 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FontSize */

/* 1476 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1478 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1482 */	NdrFcShort( 0x13 ),	/* 19 */
/* 1484 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1486 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1488 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1490 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1492 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1494 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1496 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1498 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 1500 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1502 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1504 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1506 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1508 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1510 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FontSize */

/* 1512 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1514 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1518 */	NdrFcShort( 0x14 ),	/* 20 */
/* 1520 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1522 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1524 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1526 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1528 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1530 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1532 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1534 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1536 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1538 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1540 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1542 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1544 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1546 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Italic */

/* 1548 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1550 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1554 */	NdrFcShort( 0x15 ),	/* 21 */
/* 1556 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1558 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1560 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1562 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1564 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1566 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1568 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1570 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 1572 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1574 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1576 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1578 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1580 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1582 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Italic */

/* 1584 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1586 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1590 */	NdrFcShort( 0x16 ),	/* 22 */
/* 1592 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1594 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1596 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1598 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1600 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1602 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1604 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1606 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 1608 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1610 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1612 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1614 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1616 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1618 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_LeftMargin */

/* 1620 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1622 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1626 */	NdrFcShort( 0x1a ),	/* 26 */
/* 1628 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1630 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1632 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1634 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1636 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1638 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1640 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1642 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1644 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1646 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1648 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1650 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1652 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1654 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_LineSpacing */

/* 1656 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1658 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1662 */	NdrFcShort( 0x1c ),	/* 28 */
/* 1664 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1666 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1668 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1670 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1672 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1674 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1676 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1678 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1680 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1682 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1684 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1686 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1688 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1690 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Marker */

/* 1692 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1694 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1698 */	NdrFcShort( 0x1d ),	/* 29 */
/* 1700 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1702 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1704 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1706 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1708 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1710 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1712 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1714 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1716 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1718 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1720 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1722 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1724 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1726 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Marker */

/* 1728 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1730 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1734 */	NdrFcShort( 0x1e ),	/* 30 */
/* 1736 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1738 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1740 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1742 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1744 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1746 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1748 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1750 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 1752 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1754 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1756 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 1758 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1760 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1762 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Name */

/* 1764 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1766 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1770 */	NdrFcShort( 0x1f ),	/* 31 */
/* 1772 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1774 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1776 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1778 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1780 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1782 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1784 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1786 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1788 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1790 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1792 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1794 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1796 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1798 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Name */

/* 1800 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1802 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1806 */	NdrFcShort( 0x20 ),	/* 32 */
/* 1808 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1810 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1812 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1814 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1816 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1818 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1820 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1822 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 1824 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1826 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1828 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 1830 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1832 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1834 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TeStyleName */

/* 1836 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1838 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1842 */	NdrFcShort( 0x21 ),	/* 33 */
/* 1844 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1846 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1848 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1850 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1852 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1854 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1856 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1858 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1860 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1862 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1864 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1866 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1868 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1870 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_TeStyleName */

/* 1872 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1874 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1878 */	NdrFcShort( 0x22 ),	/* 34 */
/* 1880 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1882 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1884 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1886 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1888 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1890 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1892 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1894 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 1896 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1898 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1900 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 1902 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1904 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1906 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_NotRepeatable */

/* 1908 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1910 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1914 */	NdrFcShort( 0x23 ),	/* 35 */
/* 1916 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1918 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1920 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1922 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1924 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1926 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1928 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1930 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 1932 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1934 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1936 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1938 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1940 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1942 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_NotRepeatable */

/* 1944 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1946 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1950 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1952 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1954 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1956 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1958 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1960 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1962 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1964 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1966 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 1968 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1970 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1972 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1974 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1976 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1978 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_OccursUnder */

/* 1980 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1982 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1986 */	NdrFcShort( 0x25 ),	/* 37 */
/* 1988 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1990 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1992 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1994 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1996 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1998 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2000 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2002 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 2004 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2006 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2008 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 2010 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2012 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2014 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_OccursUnder */

/* 2016 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2018 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2022 */	NdrFcShort( 0x26 ),	/* 38 */
/* 2024 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2026 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2028 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2030 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 2032 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 2034 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2036 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2038 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 2040 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2042 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2044 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 2046 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2048 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2050 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Rank */

/* 2052 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2054 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2058 */	NdrFcShort( 0x27 ),	/* 39 */
/* 2060 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2062 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2064 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2066 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2068 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2070 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2072 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2074 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 2076 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2078 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2080 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2082 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2084 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2086 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Rank */

/* 2088 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2090 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2094 */	NdrFcShort( 0x28 ),	/* 40 */
/* 2096 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2098 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2100 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2102 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2104 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2106 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2108 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2110 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 2112 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2114 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2116 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2118 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2120 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2122 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_RightMargin */

/* 2124 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2126 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2130 */	NdrFcShort( 0x29 ),	/* 41 */
/* 2132 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2134 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2136 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2138 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2140 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2142 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2144 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2146 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 2148 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2150 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2152 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2154 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2156 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2158 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_RightMargin */

/* 2160 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2162 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2166 */	NdrFcShort( 0x2a ),	/* 42 */
/* 2168 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2170 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2172 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2174 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2176 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2178 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2180 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2182 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 2184 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2186 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2188 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2190 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2192 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2194 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_SpaceAfter */

/* 2196 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2198 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2202 */	NdrFcShort( 0x2b ),	/* 43 */
/* 2204 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2206 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2208 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2210 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2212 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2214 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2216 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2218 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 2220 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2222 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2224 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2226 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2228 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2230 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_SpaceAfter */

/* 2232 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2234 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2238 */	NdrFcShort( 0x2c ),	/* 44 */
/* 2240 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2242 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2244 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2246 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2248 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2250 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2252 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2254 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 2256 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2258 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2260 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2262 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2264 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2266 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_SpaceBefore */

/* 2268 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2270 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2274 */	NdrFcShort( 0x2d ),	/* 45 */
/* 2276 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2278 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2280 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2282 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2284 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2286 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2288 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2290 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 2292 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2294 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2296 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2298 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2300 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2302 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_SpaceBefore */

/* 2304 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2306 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2310 */	NdrFcShort( 0x2e ),	/* 46 */
/* 2312 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2314 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2316 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2318 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2320 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2322 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2324 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2326 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 2328 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2330 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2332 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2334 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2336 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2338 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_StyleType */

/* 2340 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2342 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2346 */	NdrFcShort( 0x2f ),	/* 47 */
/* 2348 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2350 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2352 */	NdrFcShort( 0x22 ),	/* 34 */
/* 2354 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2356 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2358 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2360 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2362 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 2364 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 2366 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2368 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */

/* 2370 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2372 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2374 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_StyleType */

/* 2376 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2378 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2382 */	NdrFcShort( 0x30 ),	/* 48 */
/* 2384 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2386 */	NdrFcShort( 0x6 ),	/* 6 */
/* 2388 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2390 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2392 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2394 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2396 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2398 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 2400 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2402 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2404 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 2406 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2408 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2410 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Superscript */

/* 2412 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2414 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2418 */	NdrFcShort( 0x31 ),	/* 49 */
/* 2420 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2422 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2424 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2426 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2428 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2430 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2432 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2434 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 2436 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2438 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2440 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2442 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2444 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2446 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Superscript */

/* 2448 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2450 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2454 */	NdrFcShort( 0x32 ),	/* 50 */
/* 2456 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2458 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2460 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2462 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2464 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2466 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2468 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2470 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 2472 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2474 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2476 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2478 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2480 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2482 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Versification */


	/* Procedure get_TextProperties */

/* 2484 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2486 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2490 */	NdrFcShort( 0x33 ),	/* 51 */
/* 2492 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2494 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2496 */	NdrFcShort( 0x22 ),	/* 34 */
/* 2498 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2500 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2502 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2504 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2506 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pvVal */


	/* Parameter pVal */

/* 2508 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 2510 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2512 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */


	/* Return value */

/* 2514 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2516 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2518 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Versification */


	/* Procedure put_TextProperties */

/* 2520 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2522 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2526 */	NdrFcShort( 0x34 ),	/* 52 */
/* 2528 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2530 */	NdrFcShort( 0x6 ),	/* 6 */
/* 2532 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2534 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2536 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2538 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2540 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2542 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter vVal */


	/* Parameter newVal */

/* 2544 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2546 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2548 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 2550 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2552 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2554 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TextType */

/* 2556 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2558 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2562 */	NdrFcShort( 0x35 ),	/* 53 */
/* 2564 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2566 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2568 */	NdrFcShort( 0x22 ),	/* 34 */
/* 2570 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2572 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2574 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2576 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2578 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 2580 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 2582 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2584 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */

/* 2586 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2588 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2590 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_TextType */

/* 2592 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2594 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2598 */	NdrFcShort( 0x36 ),	/* 54 */
/* 2600 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2602 */	NdrFcShort( 0x6 ),	/* 6 */
/* 2604 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2606 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2608 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2610 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2612 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2614 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 2616 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2618 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2620 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 2622 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2624 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2626 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_AsteriskIsMarker */


	/* Procedure get_Underline */

/* 2628 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2630 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2634 */	NdrFcShort( 0x37 ),	/* 55 */
/* 2636 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2638 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2640 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2642 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2644 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2646 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2648 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2650 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */


	/* Parameter pfVal */

/* 2652 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2654 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2656 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 2658 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2660 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2662 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Underline */

/* 2664 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2666 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2670 */	NdrFcShort( 0x38 ),	/* 56 */
/* 2672 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2674 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2676 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2678 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2680 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2682 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2684 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2686 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 2688 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2690 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2692 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2694 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2696 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2698 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_XMLTag */

/* 2700 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2702 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2706 */	NdrFcShort( 0x39 ),	/* 57 */
/* 2708 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2710 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2712 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2714 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 2716 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 2718 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2720 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2722 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 2724 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2726 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2728 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 2730 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2732 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2734 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_XMLTag */

/* 2736 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2738 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2742 */	NdrFcShort( 0x3a ),	/* 58 */
/* 2744 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2746 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2748 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2750 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 2752 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 2754 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2756 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2758 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 2760 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2762 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2764 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 2766 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2768 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2770 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Encoding */

/* 2772 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2774 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2778 */	NdrFcShort( 0x3b ),	/* 59 */
/* 2780 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2782 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2784 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2786 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 2788 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 2790 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2792 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2794 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 2796 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2798 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2800 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 2802 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2804 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2806 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Encoding */

/* 2808 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2810 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2814 */	NdrFcShort( 0x3c ),	/* 60 */
/* 2816 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2818 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2820 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2822 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 2824 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 2826 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2828 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2830 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 2832 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2834 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2836 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 2838 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2840 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2842 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_SmallCaps */

/* 2844 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2846 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2850 */	NdrFcShort( 0x3d ),	/* 61 */
/* 2852 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2854 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2856 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2858 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2860 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2862 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2864 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2866 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 2868 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2870 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2872 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2874 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2876 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2878 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_SmallCaps */

/* 2880 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2882 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2886 */	NdrFcShort( 0x3e ),	/* 62 */
/* 2888 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2890 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2892 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2894 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2896 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2898 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2900 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2902 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 2904 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2906 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2908 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2910 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2912 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2914 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Subscript */

/* 2916 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2918 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2922 */	NdrFcShort( 0x3f ),	/* 63 */
/* 2924 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2926 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2928 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2930 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2932 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2934 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2936 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2938 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 2940 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2942 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2944 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2946 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2948 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2950 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Subscript */

/* 2952 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2954 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2958 */	NdrFcShort( 0x40 ),	/* 64 */
/* 2960 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2962 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2964 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2966 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2968 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2970 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2972 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2974 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 2976 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2978 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2980 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2982 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2984 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2986 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FirstReference */

/* 2988 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2990 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2994 */	NdrFcShort( 0x7 ),	/* 7 */
/* 2996 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2998 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3000 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3002 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3004 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3006 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3008 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3010 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3012 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3014 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3016 */	NdrFcShort( 0x44c ),	/* Type Offset=1100 */

	/* Return value */

/* 3018 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3020 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3022 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FirstReference */

/* 3024 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3026 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3030 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3032 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3034 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3036 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3038 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3040 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3042 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3044 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3046 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3048 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3050 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3052 */	NdrFcShort( 0x436 ),	/* Type Offset=1078 */

	/* Return value */

/* 3054 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3056 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3058 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LastReference */

/* 3060 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3062 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3066 */	NdrFcShort( 0x9 ),	/* 9 */
/* 3068 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3070 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3072 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3074 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3076 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3078 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3080 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3082 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3084 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3086 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3088 */	NdrFcShort( 0x44c ),	/* Type Offset=1100 */

	/* Return value */

/* 3090 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3092 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3094 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_LastReference */

/* 3096 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3098 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3102 */	NdrFcShort( 0xa ),	/* 10 */
/* 3104 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3106 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3108 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3110 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3112 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3114 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3116 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3118 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3120 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3122 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3124 */	NdrFcShort( 0x436 ),	/* Type Offset=1078 */

	/* Return value */

/* 3126 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3128 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3130 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TextType */

/* 3132 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3134 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3138 */	NdrFcShort( 0xd ),	/* 13 */
/* 3140 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3142 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3144 */	NdrFcShort( 0x22 ),	/* 34 */
/* 3146 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3148 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3150 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3152 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3154 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3156 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 3158 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3160 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */

/* 3162 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3164 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3166 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_TextType */

/* 3168 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3170 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3174 */	NdrFcShort( 0xe ),	/* 14 */
/* 3176 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3178 */	NdrFcShort( 0x6 ),	/* 6 */
/* 3180 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3182 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3184 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3186 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3188 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3190 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3192 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3194 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3196 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 3198 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3200 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3202 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TextProperties */

/* 3204 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3206 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3210 */	NdrFcShort( 0xf ),	/* 15 */
/* 3212 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3214 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3216 */	NdrFcShort( 0x22 ),	/* 34 */
/* 3218 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3220 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3222 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3224 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3226 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3228 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 3230 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3232 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */

/* 3234 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3236 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3238 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_TextProperties */

/* 3240 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3242 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3246 */	NdrFcShort( 0x10 ),	/* 16 */
/* 3248 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3250 */	NdrFcShort( 0x6 ),	/* 6 */
/* 3252 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3254 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3256 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3258 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3260 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3262 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3264 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3266 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3268 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 3270 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3272 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3274 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Tag */

/* 3276 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3278 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3282 */	NdrFcShort( 0x11 ),	/* 17 */
/* 3284 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3286 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3288 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3290 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3292 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3294 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3296 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3298 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3300 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3302 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3304 */	NdrFcShort( 0x450 ),	/* Type Offset=1104 */

	/* Return value */

/* 3306 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3308 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3310 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Tag */

/* 3312 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3314 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3318 */	NdrFcShort( 0x12 ),	/* 18 */
/* 3320 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3322 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3324 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3326 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3328 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3330 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3332 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3334 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3336 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3338 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3340 */	NdrFcShort( 0x454 ),	/* Type Offset=1108 */

	/* Return value */

/* 3342 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3344 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3346 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Clone */

/* 3348 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3350 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3354 */	NdrFcShort( 0x13 ),	/* 19 */
/* 3356 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3358 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3360 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3362 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3364 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3366 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3368 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3370 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter ppTextSegment */

/* 3372 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3374 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3376 */	NdrFcShort( 0x466 ),	/* Type Offset=1126 */

	/* Return value */

/* 3378 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3380 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3382 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NextToken */


	/* Procedure NextToken */

/* 3384 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3386 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3390 */	NdrFcShort( 0x7 ),	/* 7 */
/* 3392 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 3394 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3396 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3398 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 3400 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3402 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3404 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3406 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piTagIndex */


	/* Parameter piTagIndex */

/* 3408 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3410 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3412 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstr */


	/* Parameter pbstr */

/* 3414 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3416 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3418 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */


	/* Return value */

/* 3420 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3422 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3424 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Next */

/* 3426 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3428 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3432 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3434 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 3436 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3438 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3440 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 3442 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3444 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3446 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3448 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3450 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3452 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3454 */	NdrFcShort( 0x46a ),	/* Type Offset=1130 */

	/* Parameter fVal */

/* 3456 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3458 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3460 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3462 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3464 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3466 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Update */

/* 3468 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3470 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3474 */	NdrFcShort( 0x9 ),	/* 9 */
/* 3476 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3478 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3480 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3482 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3484 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3486 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3488 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3490 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3492 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3494 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3496 */	NdrFcShort( 0x46a ),	/* Type Offset=1130 */

	/* Return value */

/* 3498 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3500 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3502 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure SetText */

/* 3504 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3506 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3510 */	NdrFcShort( 0xa ),	/* 10 */
/* 3512 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 3514 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3516 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3518 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x4,		/* 4 */
/* 3520 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 3522 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3524 */	NdrFcShort( 0x2 ),	/* 2 */
/* 3526 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrText */

/* 3528 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3530 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3532 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter pscr */

/* 3534 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3536 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3538 */	NdrFcShort( 0x47c ),	/* Type Offset=1148 */

	/* Parameter bstrComment */

/* 3540 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3542 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3544 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 3546 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3548 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 3550 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Next */

/* 3552 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3554 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3558 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3560 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 3562 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3564 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3566 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x4,		/* 4 */
/* 3568 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3570 */	NdrFcShort( 0x2 ),	/* 2 */
/* 3572 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3574 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 3576 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3578 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3580 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter pSCReference */

/* 3582 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3584 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3586 */	NdrFcShort( 0x48e ),	/* Type Offset=1166 */

	/* Parameter pxbstr */

/* 3588 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3590 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3592 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 3594 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3596 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 3598 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TextsPresent */

/* 3600 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3602 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3606 */	NdrFcShort( 0x7 ),	/* 7 */
/* 3608 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3610 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3612 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3614 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3616 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3618 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3620 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3622 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 3624 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3626 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3628 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 3630 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3632 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3634 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Load */

/* 3636 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3638 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3642 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3644 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3646 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3648 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3650 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3652 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 3654 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3656 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3658 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrFileName */

/* 3660 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3662 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3664 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 3666 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3668 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3670 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure AddFile */


	/* Procedure Save */

/* 3672 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3674 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3678 */	NdrFcShort( 0x9 ),	/* 9 */
/* 3680 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3682 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3684 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3686 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3688 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 3690 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3692 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3694 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrFileName */


	/* Parameter bstrFileName */

/* 3696 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3698 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3700 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */


	/* Return value */

/* 3702 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3704 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3706 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure TextEnum */

/* 3708 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3710 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3714 */	NdrFcShort( 0xa ),	/* 10 */
/* 3716 */	NdrFcShort( 0x1c ),	/* x86 Stack size/offset = 28 */
/* 3718 */	NdrFcShort( 0xc ),	/* 12 */
/* 3720 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3722 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 3724 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3726 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3728 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3730 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReferenceFirst */

/* 3732 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3734 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3736 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter pSCReferenceLast */

/* 3738 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3740 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3742 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter sttFilter */

/* 3744 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3746 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3748 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Parameter stpSmushing */

/* 3750 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3752 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 3754 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Parameter ppTextEnum */

/* 3756 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3758 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 3760 */	NdrFcShort( 0x4a4 ),	/* Type Offset=1188 */

	/* Return value */

/* 3762 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3764 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 3766 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetText */

/* 3768 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3770 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3774 */	NdrFcShort( 0xb ),	/* 11 */
/* 3776 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 3778 */	NdrFcShort( 0x10 ),	/* 16 */
/* 3780 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3782 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 3784 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3786 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3788 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3790 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReferenceFirstChapter */

/* 3792 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3794 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3796 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter fSingleChapter */

/* 3798 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3800 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3802 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter fDoMapin */

/* 3804 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3806 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3808 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstrText */

/* 3810 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3812 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 3814 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 3816 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3818 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 3820 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure PutText */

/* 3822 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3824 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3828 */	NdrFcShort( 0xc ),	/* 12 */
/* 3830 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 3832 */	NdrFcShort( 0x10 ),	/* 16 */
/* 3834 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3836 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 3838 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 3840 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3842 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3844 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReferenceFirstChapter */

/* 3846 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3848 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3850 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter fSingleChapter */

/* 3852 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3854 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3856 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter fDoMapout */

/* 3858 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3860 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3862 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter bstrText */

/* 3864 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3866 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 3868 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 3870 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3872 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 3874 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure FileName */

/* 3876 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3878 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3882 */	NdrFcShort( 0xd ),	/* 13 */
/* 3884 */	NdrFcShort( 0x1c ),	/* x86 Stack size/offset = 28 */
/* 3886 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3888 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3890 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 3892 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3894 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3896 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3898 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReference */

/* 3900 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3902 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3904 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter pSCReferenceFirst */

/* 3906 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3908 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3910 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter pSCReferenceLast */

/* 3912 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3914 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3916 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter fAlwaysReturnName */

/* 3918 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3920 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 3922 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter bstrFileName */

/* 3924 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3926 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 3928 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 3930 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3932 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 3934 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NthFileName */

/* 3936 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3938 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3942 */	NdrFcShort( 0xe ),	/* 14 */
/* 3944 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 3946 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3948 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3950 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 3952 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3954 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3956 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3958 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iFileNumber */

/* 3960 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3962 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 3964 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pSCReferenceFirst */

/* 3966 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3968 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 3970 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter pSCReferenceLast */

/* 3972 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3974 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 3976 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter bstrFileName */

/* 3978 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3980 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 3982 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 3984 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3986 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 3988 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NthTag */

/* 3990 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3992 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3996 */	NdrFcShort( 0xf ),	/* 15 */
/* 3998 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 4000 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4002 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4004 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 4006 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4008 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4010 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4012 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iTagNumber */

/* 4014 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4016 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4018 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter ppTag */

/* 4020 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 4022 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4024 */	NdrFcShort( 0x4ba ),	/* Type Offset=1210 */

	/* Return value */

/* 4026 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4028 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4030 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure TagIndex */

/* 4032 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4034 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4038 */	NdrFcShort( 0x10 ),	/* 16 */
/* 4040 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 4042 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4044 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4046 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 4048 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4050 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4052 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4054 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrTagName */

/* 4056 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4058 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4060 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter piNth */

/* 4062 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4064 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4066 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4068 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4070 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4072 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure CharToWChar */

/* 4074 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4076 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4080 */	NdrFcShort( 0x11 ),	/* 17 */
/* 4082 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 4084 */	NdrFcShort( 0x19 ),	/* 25 */
/* 4086 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4088 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 4090 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4092 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4094 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4096 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pszIn */

/* 4098 */	NdrFcShort( 0x148 ),	/* Flags:  in, base type, simple ref, */
/* 4100 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4102 */	0x2,		/* FC_CHAR */
			0x0,		/* 0 */

	/* Parameter pbstr */

/* 4104 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4106 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4108 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4110 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4112 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4114 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetParameterValue */

/* 4116 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4118 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4122 */	NdrFcShort( 0x12 ),	/* 18 */
/* 4124 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 4126 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4128 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4130 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 4132 */	0x8,		/* 8 */
			0x7,		/* Ext Flags:  new corr desc, clt corr check, srv corr check, */
/* 4134 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4136 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4138 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrName */

/* 4140 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4142 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4144 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter pbstrValue */

/* 4146 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4148 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4150 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4152 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4154 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4156 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure SetParameterValue */

/* 4158 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4160 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4164 */	NdrFcShort( 0x13 ),	/* 19 */
/* 4166 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 4168 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4170 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4172 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 4174 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4176 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4178 */	NdrFcShort( 0x2 ),	/* 2 */
/* 4180 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrName */

/* 4182 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4184 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4186 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter bstrValue */

/* 4188 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4190 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4192 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4194 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4196 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4198 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_BooksPresent */

/* 4200 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4202 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4206 */	NdrFcShort( 0x14 ),	/* 20 */
/* 4208 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4210 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4212 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4214 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4216 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4218 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4220 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4222 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4224 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4226 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4228 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4230 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4232 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4234 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_BooksPresent */

/* 4236 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4238 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4242 */	NdrFcShort( 0x15 ),	/* 21 */
/* 4244 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4246 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4248 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4250 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4252 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4254 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4256 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4258 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4260 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4262 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4264 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4266 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4268 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4270 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_CodePage */

/* 4272 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4274 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4278 */	NdrFcShort( 0x16 ),	/* 22 */
/* 4280 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4282 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4284 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4286 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4288 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4290 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4292 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4294 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piCodePage */

/* 4296 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4298 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4300 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4302 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4304 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4306 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_CodePage */

/* 4308 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4310 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4314 */	NdrFcShort( 0x17 ),	/* 23 */
/* 4316 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4318 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4320 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4322 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4324 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4326 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4328 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4330 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iCodePage */

/* 4332 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4334 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4336 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4338 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4340 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4342 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_DefaultFont */

/* 4344 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4346 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4350 */	NdrFcShort( 0x18 ),	/* 24 */
/* 4352 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4354 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4356 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4358 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4360 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4362 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4364 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4366 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4368 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4370 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4372 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4374 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4376 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4378 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_DefaultFont */

/* 4380 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4382 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4386 */	NdrFcShort( 0x19 ),	/* 25 */
/* 4388 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4390 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4392 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4394 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4396 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4398 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4400 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4402 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4404 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4406 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4408 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4410 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4412 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4414 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_DefaultFontSize */

/* 4416 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4418 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4422 */	NdrFcShort( 0x1a ),	/* 26 */
/* 4424 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4426 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4428 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4430 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4432 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4434 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4436 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4438 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 4440 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4442 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4444 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4446 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4448 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4450 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_DefaultFontSize */

/* 4452 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4454 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4458 */	NdrFcShort( 0x1b ),	/* 27 */
/* 4460 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4462 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4464 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4466 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4468 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4470 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4472 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4474 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 4476 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4478 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4480 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4482 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4484 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4486 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Directory */

/* 4488 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4490 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4494 */	NdrFcShort( 0x1c ),	/* 28 */
/* 4496 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4498 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4500 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4502 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4504 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4506 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4508 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4510 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4512 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4514 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4516 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4518 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4520 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4522 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Directory */

/* 4524 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4526 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4530 */	NdrFcShort( 0x1d ),	/* 29 */
/* 4532 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4534 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4536 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4538 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4540 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4542 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4544 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4546 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4548 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4550 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4552 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4554 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4556 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4558 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Editable */

/* 4560 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4562 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4566 */	NdrFcShort( 0x1e ),	/* 30 */
/* 4568 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4570 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4572 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4574 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4576 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4578 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4580 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4582 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 4584 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4586 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4588 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4590 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4592 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4594 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Editable */

/* 4596 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4598 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4602 */	NdrFcShort( 0x1f ),	/* 31 */
/* 4604 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4606 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4608 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4610 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4612 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4614 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4616 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4618 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 4620 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4622 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4624 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4626 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4628 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4630 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FileNameForm */

/* 4632 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4634 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4638 */	NdrFcShort( 0x20 ),	/* 32 */
/* 4640 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4642 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4644 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4646 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4648 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4650 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4652 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4654 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4656 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4658 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4660 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4662 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4664 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4666 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FileNameForm */

/* 4668 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4670 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4674 */	NdrFcShort( 0x21 ),	/* 33 */
/* 4676 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4678 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4680 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4682 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4684 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4686 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4688 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4690 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4692 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4694 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4696 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4698 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4700 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4702 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FileNamePostPart */

/* 4704 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4706 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4710 */	NdrFcShort( 0x22 ),	/* 34 */
/* 4712 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4714 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4716 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4718 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4720 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4722 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4724 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4726 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4728 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4730 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4732 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4734 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4736 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4738 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FileNamePostPart */

/* 4740 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4742 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4746 */	NdrFcShort( 0x23 ),	/* 35 */
/* 4748 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4750 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4752 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4754 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4756 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4758 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4760 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4762 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4764 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4766 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4768 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4770 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4772 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4774 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FileNamePrePart */

/* 4776 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4778 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4782 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4784 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4786 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4788 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4790 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4792 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4794 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4796 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4798 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4800 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4802 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4804 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4806 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4808 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4810 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FileNamePrePart */

/* 4812 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4814 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4818 */	NdrFcShort( 0x25 ),	/* 37 */
/* 4820 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4822 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4824 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4826 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4828 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4830 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4832 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4834 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4836 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4838 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4840 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4842 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4844 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4846 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FileNameChapterNumberForm */

/* 4848 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4850 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4854 */	NdrFcShort( 0x26 ),	/* 38 */
/* 4856 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4858 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4860 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4862 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4864 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4866 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4868 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4870 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4872 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4874 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4876 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4878 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4880 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4882 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FileNameChapterNumberForm */

/* 4884 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4886 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4890 */	NdrFcShort( 0x27 ),	/* 39 */
/* 4892 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4894 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4896 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4898 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4900 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4902 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4904 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4906 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4908 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4910 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4912 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4914 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4916 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4918 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FullName */

/* 4920 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4922 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4926 */	NdrFcShort( 0x28 ),	/* 40 */
/* 4928 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4930 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4932 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4934 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4936 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4938 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4940 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4942 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4944 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4946 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4948 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4950 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4952 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4954 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FullName */

/* 4956 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4958 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4962 */	NdrFcShort( 0x29 ),	/* 41 */
/* 4964 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 4966 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4968 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4970 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4972 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4974 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4976 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4978 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4980 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4982 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 4984 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4986 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4988 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 4990 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Language */

/* 4992 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4994 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4998 */	NdrFcShort( 0x2a ),	/* 42 */
/* 5000 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5002 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5004 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5006 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5008 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5010 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5012 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5014 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5016 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5018 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5020 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5022 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5024 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5026 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Language */

/* 5028 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5030 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5034 */	NdrFcShort( 0x2b ),	/* 43 */
/* 5036 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5038 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5040 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5042 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5044 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5046 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5048 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5050 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5052 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5054 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5056 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5058 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5060 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5062 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LeftToRight */

/* 5064 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5066 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5070 */	NdrFcShort( 0x2c ),	/* 44 */
/* 5072 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5074 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5076 */	NdrFcShort( 0x24 ),	/* 36 */
/* 5078 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 5080 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 5082 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5084 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5086 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 5088 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 5090 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5092 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 5094 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5096 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5098 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_LeftToRight */

/* 5100 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5102 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5106 */	NdrFcShort( 0x2d ),	/* 45 */
/* 5108 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5110 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5112 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5114 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 5116 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 5118 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5120 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5122 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 5124 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 5126 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5128 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 5130 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5132 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5134 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Name */

/* 5136 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5138 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5142 */	NdrFcShort( 0x2e ),	/* 46 */
/* 5144 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5146 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5148 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5150 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5152 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5154 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5156 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5158 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5160 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5162 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5164 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5166 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5168 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5170 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Name */

/* 5172 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5174 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5178 */	NdrFcShort( 0x2f ),	/* 47 */
/* 5180 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5182 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5184 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5186 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5188 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5190 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5192 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5194 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5196 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5198 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5200 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5202 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5204 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5206 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_SettingsDirectory */

/* 5208 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5210 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5214 */	NdrFcShort( 0x30 ),	/* 48 */
/* 5216 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5218 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5220 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5222 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5224 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5226 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5228 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5230 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5232 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5234 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5236 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5238 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5240 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5242 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_StyleSheet */

/* 5244 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5246 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5250 */	NdrFcShort( 0x31 ),	/* 49 */
/* 5252 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5254 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5256 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5258 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5260 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5262 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5264 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5266 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5268 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5270 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5272 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5274 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5276 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5278 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_StyleSheet */

/* 5280 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5282 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5286 */	NdrFcShort( 0x32 ),	/* 50 */
/* 5288 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5290 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5292 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5294 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5296 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5298 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5300 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5302 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5304 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5306 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5308 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5310 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5312 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5314 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Encoding */

/* 5316 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5318 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5322 */	NdrFcShort( 0x35 ),	/* 53 */
/* 5324 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5326 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5328 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5330 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5332 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5334 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5336 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5338 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstrEncoding */

/* 5340 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5342 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5344 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5346 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5348 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5350 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Encoding */

/* 5352 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5354 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5358 */	NdrFcShort( 0x36 ),	/* 54 */
/* 5360 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5362 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5364 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5366 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5368 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5370 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5372 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5374 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrEncoding */

/* 5376 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5378 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5380 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5382 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5384 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5386 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure TextEnumEx */

/* 5388 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5390 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5394 */	NdrFcShort( 0x38 ),	/* 56 */
/* 5396 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 5398 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5400 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5402 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x4,		/* 4 */
/* 5404 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 5406 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5408 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5410 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReferenceFirst */

/* 5412 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 5414 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5416 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter pSCReferenceLast */

/* 5418 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 5420 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5422 */	NdrFcShort( 0x492 ),	/* Type Offset=1170 */

	/* Parameter ppTextEnumEx */

/* 5424 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 5426 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5428 */	NdrFcShort( 0x4d4 ),	/* Type Offset=1236 */

	/* Return value */

/* 5430 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5432 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 5434 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure LoadECObjectDataForSOReading */

/* 5436 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5438 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5442 */	NdrFcShort( 0x39 ),	/* 57 */
/* 5444 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 5446 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5448 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5450 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5452 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5454 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5456 */	NdrFcShort( 0x20 ),	/* 32 */
/* 5458 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSafeArrayOfBytes */

/* 5460 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5462 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5464 */	NdrFcShort( 0x4ee ),	/* Type Offset=1262 */

	/* Return value */

/* 5466 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5468 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 5470 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Initialize */

/* 5472 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5474 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5478 */	NdrFcShort( 0x7 ),	/* 7 */
/* 5480 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5482 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5484 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5486 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5488 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5490 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5492 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5494 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrBlob */

/* 5496 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5498 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5500 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5502 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5504 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5506 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Save */

/* 5508 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5510 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5514 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5516 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 5518 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5520 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5522 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 5524 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5526 */	NdrFcShort( 0x2 ),	/* 2 */
/* 5528 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5530 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrBlob */

/* 5532 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5534 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5536 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter bstrToken */

/* 5538 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5540 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5542 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5544 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5546 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5548 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure RemoveFile */

/* 5550 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5552 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5556 */	NdrFcShort( 0xa ),	/* 10 */
/* 5558 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5560 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5562 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5564 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5566 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5568 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5570 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5572 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrFileName */

/* 5574 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5576 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5578 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5580 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5582 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5584 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Files */

/* 5586 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5588 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5592 */	NdrFcShort( 0xb ),	/* 11 */
/* 5594 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5596 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5598 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5600 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5602 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5604 */	NdrFcShort( 0x20 ),	/* 32 */
/* 5606 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5608 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSafeArray */

/* 5610 */	NdrFcShort( 0x4113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=16 */
/* 5612 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5614 */	NdrFcShort( 0x42c ),	/* Type Offset=1068 */

	/* Return value */

/* 5616 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5618 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5620 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_BookMarker */

/* 5622 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5624 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5628 */	NdrFcShort( 0xc ),	/* 12 */
/* 5630 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5632 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5634 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5636 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5638 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5640 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5642 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5644 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrBookMarker */

/* 5646 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5648 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5650 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5652 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5654 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5656 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_BookMarker */

/* 5658 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5660 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5664 */	NdrFcShort( 0xd ),	/* 13 */
/* 5666 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5668 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5670 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5672 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5674 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5676 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5678 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5680 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrBookMarker */

/* 5682 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5684 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5686 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5688 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5690 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5692 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NthMapping */

/* 5694 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5696 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5700 */	NdrFcShort( 0xe ),	/* 14 */
/* 5702 */	NdrFcShort( 0x20 ),	/* x86 Stack size/offset = 32 */
/* 5704 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5706 */	NdrFcShort( 0x40 ),	/* 64 */
/* 5708 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x7,		/* 7 */
/* 5710 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5712 */	NdrFcShort( 0x3 ),	/* 3 */
/* 5714 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5716 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iIndex */

/* 5718 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 5720 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5722 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstrMarker */

/* 5724 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5726 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5728 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter piDomain */

/* 5730 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 5732 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5734 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstrTeStyleName */

/* 5736 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5738 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 5740 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter pbstrEncoding */

/* 5742 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5744 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 5746 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter bConfirmed */

/* 5748 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 5750 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 5752 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 5754 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5756 */	NdrFcShort( 0x1c ),	/* x86 Stack size/offset = 28 */
/* 5758 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure SetMapping */

/* 5760 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5762 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5766 */	NdrFcShort( 0xf ),	/* 15 */
/* 5768 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 5770 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5772 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5774 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 5776 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5778 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5780 */	NdrFcShort( 0x3 ),	/* 3 */
/* 5782 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstrMarker */

/* 5784 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5786 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5788 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter piDomain */

/* 5790 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 5792 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5794 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstrTeStyleName */

/* 5796 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5798 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5800 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter pbstrEncoding */

/* 5802 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5804 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 5806 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5808 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5810 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 5812 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetBooksForFile */

/* 5814 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5816 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5820 */	NdrFcShort( 0x10 ),	/* 16 */
/* 5822 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 5824 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5826 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5828 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 5830 */	0x8,		/* 8 */
			0x7,		/* Ext Flags:  new corr desc, clt corr check, srv corr check, */
/* 5832 */	NdrFcShort( 0x20 ),	/* 32 */
/* 5834 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5836 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrFileName */

/* 5838 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5840 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 5842 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter pSafeArray */

/* 5844 */	NdrFcShort( 0x4113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=16 */
/* 5846 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 5848 */	NdrFcShort( 0x42c ),	/* Type Offset=1068 */

	/* Return value */

/* 5850 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5852 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 5854 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/*  4 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/*  6 */	
			0x12, 0x0,	/* FC_UP */
/*  8 */	NdrFcShort( 0xe ),	/* Offset= 14 (22) */
/* 10 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 12 */	NdrFcShort( 0x2 ),	/* 2 */
/* 14 */	0x9,		/* Corr desc: FC_ULONG */
			0x0,		/*  */
/* 16 */	NdrFcShort( 0xfffc ),	/* -4 */
/* 18 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 20 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 22 */	
			0x17,		/* FC_CSTRUCT */
			0x3,		/* 3 */
/* 24 */	NdrFcShort( 0x8 ),	/* 8 */
/* 26 */	NdrFcShort( 0xfff0 ),	/* Offset= -16 (10) */
/* 28 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 30 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 32 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 34 */	NdrFcShort( 0x0 ),	/* 0 */
/* 36 */	NdrFcShort( 0x4 ),	/* 4 */
/* 38 */	NdrFcShort( 0x0 ),	/* 0 */
/* 40 */	NdrFcShort( 0xffde ),	/* Offset= -34 (6) */
/* 42 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 44 */	NdrFcShort( 0x6 ),	/* Offset= 6 (50) */
/* 46 */	
			0x13, 0x0,	/* FC_OP */
/* 48 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (22) */
/* 50 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 52 */	NdrFcShort( 0x0 ),	/* 0 */
/* 54 */	NdrFcShort( 0x4 ),	/* 4 */
/* 56 */	NdrFcShort( 0x0 ),	/* 0 */
/* 58 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (46) */
/* 60 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 62 */	0xd,		/* FC_ENUM16 */
			0x5c,		/* FC_PAD */
/* 64 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 66 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 68 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 70 */	NdrFcShort( 0x3e6 ),	/* Offset= 998 (1068) */
/* 72 */	
			0x13, 0x0,	/* FC_OP */
/* 74 */	NdrFcShort( 0x3ce ),	/* Offset= 974 (1048) */
/* 76 */	
			0x2b,		/* FC_NON_ENCAPSULATED_UNION */
			0x9,		/* FC_ULONG */
/* 78 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 80 */	NdrFcShort( 0xfff8 ),	/* -8 */
/* 82 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 84 */	NdrFcShort( 0x2 ),	/* Offset= 2 (86) */
/* 86 */	NdrFcShort( 0x10 ),	/* 16 */
/* 88 */	NdrFcShort( 0x2f ),	/* 47 */
/* 90 */	NdrFcLong( 0x14 ),	/* 20 */
/* 94 */	NdrFcShort( 0x800b ),	/* Simple arm type: FC_HYPER */
/* 96 */	NdrFcLong( 0x3 ),	/* 3 */
/* 100 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 102 */	NdrFcLong( 0x11 ),	/* 17 */
/* 106 */	NdrFcShort( 0x8001 ),	/* Simple arm type: FC_BYTE */
/* 108 */	NdrFcLong( 0x2 ),	/* 2 */
/* 112 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 114 */	NdrFcLong( 0x4 ),	/* 4 */
/* 118 */	NdrFcShort( 0x800a ),	/* Simple arm type: FC_FLOAT */
/* 120 */	NdrFcLong( 0x5 ),	/* 5 */
/* 124 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 126 */	NdrFcLong( 0xb ),	/* 11 */
/* 130 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 132 */	NdrFcLong( 0xa ),	/* 10 */
/* 136 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 138 */	NdrFcLong( 0x6 ),	/* 6 */
/* 142 */	NdrFcShort( 0xe8 ),	/* Offset= 232 (374) */
/* 144 */	NdrFcLong( 0x7 ),	/* 7 */
/* 148 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 150 */	NdrFcLong( 0x8 ),	/* 8 */
/* 154 */	NdrFcShort( 0xff94 ),	/* Offset= -108 (46) */
/* 156 */	NdrFcLong( 0xd ),	/* 13 */
/* 160 */	NdrFcShort( 0xdc ),	/* Offset= 220 (380) */
/* 162 */	NdrFcLong( 0x9 ),	/* 9 */
/* 166 */	NdrFcShort( 0xe8 ),	/* Offset= 232 (398) */
/* 168 */	NdrFcLong( 0x2000 ),	/* 8192 */
/* 172 */	NdrFcShort( 0xf4 ),	/* Offset= 244 (416) */
/* 174 */	NdrFcLong( 0x24 ),	/* 36 */
/* 178 */	NdrFcShort( 0x31c ),	/* Offset= 796 (974) */
/* 180 */	NdrFcLong( 0x4024 ),	/* 16420 */
/* 184 */	NdrFcShort( 0x316 ),	/* Offset= 790 (974) */
/* 186 */	NdrFcLong( 0x4011 ),	/* 16401 */
/* 190 */	NdrFcShort( 0x314 ),	/* Offset= 788 (978) */
/* 192 */	NdrFcLong( 0x4002 ),	/* 16386 */
/* 196 */	NdrFcShort( 0x312 ),	/* Offset= 786 (982) */
/* 198 */	NdrFcLong( 0x4003 ),	/* 16387 */
/* 202 */	NdrFcShort( 0x310 ),	/* Offset= 784 (986) */
/* 204 */	NdrFcLong( 0x4014 ),	/* 16404 */
/* 208 */	NdrFcShort( 0x30e ),	/* Offset= 782 (990) */
/* 210 */	NdrFcLong( 0x4004 ),	/* 16388 */
/* 214 */	NdrFcShort( 0x30c ),	/* Offset= 780 (994) */
/* 216 */	NdrFcLong( 0x4005 ),	/* 16389 */
/* 220 */	NdrFcShort( 0x30a ),	/* Offset= 778 (998) */
/* 222 */	NdrFcLong( 0x400b ),	/* 16395 */
/* 226 */	NdrFcShort( 0x2f4 ),	/* Offset= 756 (982) */
/* 228 */	NdrFcLong( 0x400a ),	/* 16394 */
/* 232 */	NdrFcShort( 0x2f2 ),	/* Offset= 754 (986) */
/* 234 */	NdrFcLong( 0x4006 ),	/* 16390 */
/* 238 */	NdrFcShort( 0x2fc ),	/* Offset= 764 (1002) */
/* 240 */	NdrFcLong( 0x4007 ),	/* 16391 */
/* 244 */	NdrFcShort( 0x2f2 ),	/* Offset= 754 (998) */
/* 246 */	NdrFcLong( 0x4008 ),	/* 16392 */
/* 250 */	NdrFcShort( 0x2f4 ),	/* Offset= 756 (1006) */
/* 252 */	NdrFcLong( 0x400d ),	/* 16397 */
/* 256 */	NdrFcShort( 0x2f2 ),	/* Offset= 754 (1010) */
/* 258 */	NdrFcLong( 0x4009 ),	/* 16393 */
/* 262 */	NdrFcShort( 0x2f0 ),	/* Offset= 752 (1014) */
/* 264 */	NdrFcLong( 0x6000 ),	/* 24576 */
/* 268 */	NdrFcShort( 0x2ee ),	/* Offset= 750 (1018) */
/* 270 */	NdrFcLong( 0x400c ),	/* 16396 */
/* 274 */	NdrFcShort( 0x2ec ),	/* Offset= 748 (1022) */
/* 276 */	NdrFcLong( 0x10 ),	/* 16 */
/* 280 */	NdrFcShort( 0x8002 ),	/* Simple arm type: FC_CHAR */
/* 282 */	NdrFcLong( 0x12 ),	/* 18 */
/* 286 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 288 */	NdrFcLong( 0x13 ),	/* 19 */
/* 292 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 294 */	NdrFcLong( 0x15 ),	/* 21 */
/* 298 */	NdrFcShort( 0x800b ),	/* Simple arm type: FC_HYPER */
/* 300 */	NdrFcLong( 0x16 ),	/* 22 */
/* 304 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 306 */	NdrFcLong( 0x17 ),	/* 23 */
/* 310 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 312 */	NdrFcLong( 0xe ),	/* 14 */
/* 316 */	NdrFcShort( 0x2ca ),	/* Offset= 714 (1030) */
/* 318 */	NdrFcLong( 0x400e ),	/* 16398 */
/* 322 */	NdrFcShort( 0x2ce ),	/* Offset= 718 (1040) */
/* 324 */	NdrFcLong( 0x4010 ),	/* 16400 */
/* 328 */	NdrFcShort( 0x2cc ),	/* Offset= 716 (1044) */
/* 330 */	NdrFcLong( 0x4012 ),	/* 16402 */
/* 334 */	NdrFcShort( 0x288 ),	/* Offset= 648 (982) */
/* 336 */	NdrFcLong( 0x4013 ),	/* 16403 */
/* 340 */	NdrFcShort( 0x286 ),	/* Offset= 646 (986) */
/* 342 */	NdrFcLong( 0x4015 ),	/* 16405 */
/* 346 */	NdrFcShort( 0x284 ),	/* Offset= 644 (990) */
/* 348 */	NdrFcLong( 0x4016 ),	/* 16406 */
/* 352 */	NdrFcShort( 0x27a ),	/* Offset= 634 (986) */
/* 354 */	NdrFcLong( 0x4017 ),	/* 16407 */
/* 358 */	NdrFcShort( 0x274 ),	/* Offset= 628 (986) */
/* 360 */	NdrFcLong( 0x0 ),	/* 0 */
/* 364 */	NdrFcShort( 0x0 ),	/* Offset= 0 (364) */
/* 366 */	NdrFcLong( 0x1 ),	/* 1 */
/* 370 */	NdrFcShort( 0x0 ),	/* Offset= 0 (370) */
/* 372 */	NdrFcShort( 0xffff ),	/* Offset= -1 (371) */
/* 374 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 376 */	NdrFcShort( 0x8 ),	/* 8 */
/* 378 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 380 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 382 */	NdrFcLong( 0x0 ),	/* 0 */
/* 386 */	NdrFcShort( 0x0 ),	/* 0 */
/* 388 */	NdrFcShort( 0x0 ),	/* 0 */
/* 390 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 392 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 394 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 396 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 398 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 400 */	NdrFcLong( 0x20400 ),	/* 132096 */
/* 404 */	NdrFcShort( 0x0 ),	/* 0 */
/* 406 */	NdrFcShort( 0x0 ),	/* 0 */
/* 408 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 410 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 412 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 414 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 416 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 418 */	NdrFcShort( 0x2 ),	/* Offset= 2 (420) */
/* 420 */	
			0x13, 0x0,	/* FC_OP */
/* 422 */	NdrFcShort( 0x216 ),	/* Offset= 534 (956) */
/* 424 */	
			0x2a,		/* FC_ENCAPSULATED_UNION */
			0x49,		/* 73 */
/* 426 */	NdrFcShort( 0x18 ),	/* 24 */
/* 428 */	NdrFcShort( 0xa ),	/* 10 */
/* 430 */	NdrFcLong( 0x8 ),	/* 8 */
/* 434 */	NdrFcShort( 0x5a ),	/* Offset= 90 (524) */
/* 436 */	NdrFcLong( 0xd ),	/* 13 */
/* 440 */	NdrFcShort( 0x7e ),	/* Offset= 126 (566) */
/* 442 */	NdrFcLong( 0x9 ),	/* 9 */
/* 446 */	NdrFcShort( 0x9e ),	/* Offset= 158 (604) */
/* 448 */	NdrFcLong( 0xc ),	/* 12 */
/* 452 */	NdrFcShort( 0xc8 ),	/* Offset= 200 (652) */
/* 454 */	NdrFcLong( 0x24 ),	/* 36 */
/* 458 */	NdrFcShort( 0x124 ),	/* Offset= 292 (750) */
/* 460 */	NdrFcLong( 0x800d ),	/* 32781 */
/* 464 */	NdrFcShort( 0x140 ),	/* Offset= 320 (784) */
/* 466 */	NdrFcLong( 0x10 ),	/* 16 */
/* 470 */	NdrFcShort( 0x15a ),	/* Offset= 346 (816) */
/* 472 */	NdrFcLong( 0x2 ),	/* 2 */
/* 476 */	NdrFcShort( 0x174 ),	/* Offset= 372 (848) */
/* 478 */	NdrFcLong( 0x3 ),	/* 3 */
/* 482 */	NdrFcShort( 0x18e ),	/* Offset= 398 (880) */
/* 484 */	NdrFcLong( 0x14 ),	/* 20 */
/* 488 */	NdrFcShort( 0x1a8 ),	/* Offset= 424 (912) */
/* 490 */	NdrFcShort( 0xffff ),	/* Offset= -1 (489) */
/* 492 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 494 */	NdrFcShort( 0x4 ),	/* 4 */
/* 496 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 498 */	NdrFcShort( 0x0 ),	/* 0 */
/* 500 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 502 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 504 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 506 */	NdrFcShort( 0x4 ),	/* 4 */
/* 508 */	NdrFcShort( 0x0 ),	/* 0 */
/* 510 */	NdrFcShort( 0x1 ),	/* 1 */
/* 512 */	NdrFcShort( 0x0 ),	/* 0 */
/* 514 */	NdrFcShort( 0x0 ),	/* 0 */
/* 516 */	0x13, 0x0,	/* FC_OP */
/* 518 */	NdrFcShort( 0xfe10 ),	/* Offset= -496 (22) */
/* 520 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 522 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 524 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 526 */	NdrFcShort( 0x8 ),	/* 8 */
/* 528 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 530 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 532 */	NdrFcShort( 0x4 ),	/* 4 */
/* 534 */	NdrFcShort( 0x4 ),	/* 4 */
/* 536 */	0x11, 0x0,	/* FC_RP */
/* 538 */	NdrFcShort( 0xffd2 ),	/* Offset= -46 (492) */
/* 540 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 542 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 544 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 546 */	NdrFcShort( 0x0 ),	/* 0 */
/* 548 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 550 */	NdrFcShort( 0x0 ),	/* 0 */
/* 552 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 554 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 558 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 560 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 562 */	NdrFcShort( 0xff4a ),	/* Offset= -182 (380) */
/* 564 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 566 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 568 */	NdrFcShort( 0x8 ),	/* 8 */
/* 570 */	NdrFcShort( 0x0 ),	/* 0 */
/* 572 */	NdrFcShort( 0x6 ),	/* Offset= 6 (578) */
/* 574 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 576 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 578 */	
			0x11, 0x0,	/* FC_RP */
/* 580 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (544) */
/* 582 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 584 */	NdrFcShort( 0x0 ),	/* 0 */
/* 586 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 588 */	NdrFcShort( 0x0 ),	/* 0 */
/* 590 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 592 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 596 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 598 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 600 */	NdrFcShort( 0xff36 ),	/* Offset= -202 (398) */
/* 602 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 604 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 606 */	NdrFcShort( 0x8 ),	/* 8 */
/* 608 */	NdrFcShort( 0x0 ),	/* 0 */
/* 610 */	NdrFcShort( 0x6 ),	/* Offset= 6 (616) */
/* 612 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 614 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 616 */	
			0x11, 0x0,	/* FC_RP */
/* 618 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (582) */
/* 620 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 622 */	NdrFcShort( 0x4 ),	/* 4 */
/* 624 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 626 */	NdrFcShort( 0x0 ),	/* 0 */
/* 628 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 630 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 632 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 634 */	NdrFcShort( 0x4 ),	/* 4 */
/* 636 */	NdrFcShort( 0x0 ),	/* 0 */
/* 638 */	NdrFcShort( 0x1 ),	/* 1 */
/* 640 */	NdrFcShort( 0x0 ),	/* 0 */
/* 642 */	NdrFcShort( 0x0 ),	/* 0 */
/* 644 */	0x13, 0x0,	/* FC_OP */
/* 646 */	NdrFcShort( 0x192 ),	/* Offset= 402 (1048) */
/* 648 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 650 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 652 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 654 */	NdrFcShort( 0x8 ),	/* 8 */
/* 656 */	NdrFcShort( 0x0 ),	/* 0 */
/* 658 */	NdrFcShort( 0x6 ),	/* Offset= 6 (664) */
/* 660 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 662 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 664 */	
			0x11, 0x0,	/* FC_RP */
/* 666 */	NdrFcShort( 0xffd2 ),	/* Offset= -46 (620) */
/* 668 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 670 */	NdrFcLong( 0x2f ),	/* 47 */
/* 674 */	NdrFcShort( 0x0 ),	/* 0 */
/* 676 */	NdrFcShort( 0x0 ),	/* 0 */
/* 678 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 680 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 682 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 684 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 686 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 688 */	NdrFcShort( 0x1 ),	/* 1 */
/* 690 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 692 */	NdrFcShort( 0x4 ),	/* 4 */
/* 694 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 696 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 698 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 700 */	NdrFcShort( 0x10 ),	/* 16 */
/* 702 */	NdrFcShort( 0x0 ),	/* 0 */
/* 704 */	NdrFcShort( 0xa ),	/* Offset= 10 (714) */
/* 706 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 708 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 710 */	NdrFcShort( 0xffd6 ),	/* Offset= -42 (668) */
/* 712 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 714 */	
			0x13, 0x0,	/* FC_OP */
/* 716 */	NdrFcShort( 0xffe2 ),	/* Offset= -30 (686) */
/* 718 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 720 */	NdrFcShort( 0x4 ),	/* 4 */
/* 722 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 724 */	NdrFcShort( 0x0 ),	/* 0 */
/* 726 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 728 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 730 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 732 */	NdrFcShort( 0x4 ),	/* 4 */
/* 734 */	NdrFcShort( 0x0 ),	/* 0 */
/* 736 */	NdrFcShort( 0x1 ),	/* 1 */
/* 738 */	NdrFcShort( 0x0 ),	/* 0 */
/* 740 */	NdrFcShort( 0x0 ),	/* 0 */
/* 742 */	0x13, 0x0,	/* FC_OP */
/* 744 */	NdrFcShort( 0xffd2 ),	/* Offset= -46 (698) */
/* 746 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 748 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 750 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 752 */	NdrFcShort( 0x8 ),	/* 8 */
/* 754 */	NdrFcShort( 0x0 ),	/* 0 */
/* 756 */	NdrFcShort( 0x6 ),	/* Offset= 6 (762) */
/* 758 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 760 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 762 */	
			0x11, 0x0,	/* FC_RP */
/* 764 */	NdrFcShort( 0xffd2 ),	/* Offset= -46 (718) */
/* 766 */	
			0x1d,		/* FC_SMFARRAY */
			0x0,		/* 0 */
/* 768 */	NdrFcShort( 0x8 ),	/* 8 */
/* 770 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 772 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 774 */	NdrFcShort( 0x10 ),	/* 16 */
/* 776 */	0x8,		/* FC_LONG */
			0x6,		/* FC_SHORT */
/* 778 */	0x6,		/* FC_SHORT */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 780 */	0x0,		/* 0 */
			NdrFcShort( 0xfff1 ),	/* Offset= -15 (766) */
			0x5b,		/* FC_END */
/* 784 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 786 */	NdrFcShort( 0x18 ),	/* 24 */
/* 788 */	NdrFcShort( 0x0 ),	/* 0 */
/* 790 */	NdrFcShort( 0xa ),	/* Offset= 10 (800) */
/* 792 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 794 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 796 */	NdrFcShort( 0xffe8 ),	/* Offset= -24 (772) */
/* 798 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 800 */	
			0x11, 0x0,	/* FC_RP */
/* 802 */	NdrFcShort( 0xfefe ),	/* Offset= -258 (544) */
/* 804 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 806 */	NdrFcShort( 0x1 ),	/* 1 */
/* 808 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 810 */	NdrFcShort( 0x0 ),	/* 0 */
/* 812 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 814 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 816 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 818 */	NdrFcShort( 0x8 ),	/* 8 */
/* 820 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 822 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 824 */	NdrFcShort( 0x4 ),	/* 4 */
/* 826 */	NdrFcShort( 0x4 ),	/* 4 */
/* 828 */	0x13, 0x0,	/* FC_OP */
/* 830 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (804) */
/* 832 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 834 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 836 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 838 */	NdrFcShort( 0x2 ),	/* 2 */
/* 840 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 842 */	NdrFcShort( 0x0 ),	/* 0 */
/* 844 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 846 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 848 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 850 */	NdrFcShort( 0x8 ),	/* 8 */
/* 852 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 854 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 856 */	NdrFcShort( 0x4 ),	/* 4 */
/* 858 */	NdrFcShort( 0x4 ),	/* 4 */
/* 860 */	0x13, 0x0,	/* FC_OP */
/* 862 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (836) */
/* 864 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 866 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 868 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 870 */	NdrFcShort( 0x4 ),	/* 4 */
/* 872 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 874 */	NdrFcShort( 0x0 ),	/* 0 */
/* 876 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 878 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 880 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 882 */	NdrFcShort( 0x8 ),	/* 8 */
/* 884 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 886 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 888 */	NdrFcShort( 0x4 ),	/* 4 */
/* 890 */	NdrFcShort( 0x4 ),	/* 4 */
/* 892 */	0x13, 0x0,	/* FC_OP */
/* 894 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (868) */
/* 896 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 898 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 900 */	
			0x1b,		/* FC_CARRAY */
			0x7,		/* 7 */
/* 902 */	NdrFcShort( 0x8 ),	/* 8 */
/* 904 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 906 */	NdrFcShort( 0x0 ),	/* 0 */
/* 908 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 910 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 912 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 914 */	NdrFcShort( 0x8 ),	/* 8 */
/* 916 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 918 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 920 */	NdrFcShort( 0x4 ),	/* 4 */
/* 922 */	NdrFcShort( 0x4 ),	/* 4 */
/* 924 */	0x13, 0x0,	/* FC_OP */
/* 926 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (900) */
/* 928 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 930 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 932 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 934 */	NdrFcShort( 0x8 ),	/* 8 */
/* 936 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 938 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 940 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 942 */	NdrFcShort( 0x8 ),	/* 8 */
/* 944 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 946 */	NdrFcShort( 0xffd8 ),	/* -40 */
/* 948 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 950 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 952 */	NdrFcShort( 0xffec ),	/* Offset= -20 (932) */
/* 954 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 956 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 958 */	NdrFcShort( 0x28 ),	/* 40 */
/* 960 */	NdrFcShort( 0xffec ),	/* Offset= -20 (940) */
/* 962 */	NdrFcShort( 0x0 ),	/* Offset= 0 (962) */
/* 964 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 966 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 968 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 970 */	NdrFcShort( 0xfdde ),	/* Offset= -546 (424) */
/* 972 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 974 */	
			0x13, 0x0,	/* FC_OP */
/* 976 */	NdrFcShort( 0xfeea ),	/* Offset= -278 (698) */
/* 978 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 980 */	0x1,		/* FC_BYTE */
			0x5c,		/* FC_PAD */
/* 982 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 984 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/* 986 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 988 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 990 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 992 */	0xb,		/* FC_HYPER */
			0x5c,		/* FC_PAD */
/* 994 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 996 */	0xa,		/* FC_FLOAT */
			0x5c,		/* FC_PAD */
/* 998 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 1000 */	0xc,		/* FC_DOUBLE */
			0x5c,		/* FC_PAD */
/* 1002 */	
			0x13, 0x0,	/* FC_OP */
/* 1004 */	NdrFcShort( 0xfd8a ),	/* Offset= -630 (374) */
/* 1006 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 1008 */	NdrFcShort( 0xfc3e ),	/* Offset= -962 (46) */
/* 1010 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 1012 */	NdrFcShort( 0xfd88 ),	/* Offset= -632 (380) */
/* 1014 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 1016 */	NdrFcShort( 0xfd96 ),	/* Offset= -618 (398) */
/* 1018 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 1020 */	NdrFcShort( 0xfda4 ),	/* Offset= -604 (416) */
/* 1022 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 1024 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1026) */
/* 1026 */	
			0x13, 0x0,	/* FC_OP */
/* 1028 */	NdrFcShort( 0x14 ),	/* Offset= 20 (1048) */
/* 1030 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 1032 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1034 */	0x6,		/* FC_SHORT */
			0x1,		/* FC_BYTE */
/* 1036 */	0x1,		/* FC_BYTE */
			0x8,		/* FC_LONG */
/* 1038 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 1040 */	
			0x13, 0x0,	/* FC_OP */
/* 1042 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (1030) */
/* 1044 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 1046 */	0x2,		/* FC_CHAR */
			0x5c,		/* FC_PAD */
/* 1048 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x7,		/* 7 */
/* 1050 */	NdrFcShort( 0x20 ),	/* 32 */
/* 1052 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1054 */	NdrFcShort( 0x0 ),	/* Offset= 0 (1054) */
/* 1056 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 1058 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 1060 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 1062 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 1064 */	NdrFcShort( 0xfc24 ),	/* Offset= -988 (76) */
/* 1066 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 1068 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 1070 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1072 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1074 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1076 */	NdrFcShort( 0xfc14 ),	/* Offset= -1004 (72) */
/* 1078 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1080 */	NdrFcLong( 0x2c3c484e ),	/* 742148174 */
/* 1084 */	NdrFcShort( 0x8ad0 ),	/* -30000 */
/* 1086 */	NdrFcShort( 0x442e ),	/* 17454 */
/* 1088 */	0x8d,		/* 141 */
			0xac,		/* 172 */
/* 1090 */	0x24,		/* 36 */
			0x8f,		/* 143 */
/* 1092 */	0xcf,		/* 207 */
			0x55,		/* 85 */
/* 1094 */	0xf5,		/* 245 */
			0xee,		/* 238 */
/* 1096 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1098 */	NdrFcShort( 0xfd32 ),	/* Offset= -718 (380) */
/* 1100 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1102 */	NdrFcShort( 0xffe8 ),	/* Offset= -24 (1078) */
/* 1104 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1106 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1108) */
/* 1108 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1110 */	NdrFcLong( 0xaee2bf36 ),	/* -1360871626 */
/* 1114 */	NdrFcShort( 0x4b0 ),	/* 1200 */
/* 1116 */	NdrFcShort( 0x4586 ),	/* 17798 */
/* 1118 */	0x88,		/* 136 */
			0x3,		/* 3 */
/* 1120 */	0x13,		/* 19 */
			0xf2,		/* 242 */
/* 1122 */	0xaa,		/* 170 */
			0xdb,		/* 219 */
/* 1124 */	0xeb,		/* 235 */
			0xbb,		/* 187 */
/* 1126 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1128 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1130) */
/* 1130 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1132 */	NdrFcLong( 0x809fd5b3 ),	/* -2137008717 */
/* 1136 */	NdrFcShort( 0x5278 ),	/* 21112 */
/* 1138 */	NdrFcShort( 0x4719 ),	/* 18201 */
/* 1140 */	0xb9,		/* 185 */
			0xc7,		/* 199 */
/* 1142 */	0x9e,		/* 158 */
			0xb,		/* 11 */
/* 1144 */	0x2d,		/* 45 */
			0xe2,		/* 226 */
/* 1146 */	0x6d,		/* 109 */
			0xe8,		/* 232 */
/* 1148 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1150 */	NdrFcLong( 0x12aad383 ),	/* 313185155 */
/* 1154 */	NdrFcShort( 0x2909 ),	/* 10505 */
/* 1156 */	NdrFcShort( 0x4a14 ),	/* 18964 */
/* 1158 */	0xad,		/* 173 */
			0xa9,		/* 169 */
/* 1160 */	0xc7,		/* 199 */
			0x3d,		/* 61 */
/* 1162 */	0xc2,		/* 194 */
			0x31,		/* 49 */
/* 1164 */	0xa1,		/* 161 */
			0x8d,		/* 141 */
/* 1166 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1168 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1170) */
/* 1170 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1172 */	NdrFcLong( 0x2c3c484e ),	/* 742148174 */
/* 1176 */	NdrFcShort( 0x8ad0 ),	/* -30000 */
/* 1178 */	NdrFcShort( 0x442e ),	/* 17454 */
/* 1180 */	0x8d,		/* 141 */
			0xac,		/* 172 */
/* 1182 */	0x24,		/* 36 */
			0x8f,		/* 143 */
/* 1184 */	0xcf,		/* 207 */
			0x55,		/* 85 */
/* 1186 */	0xf5,		/* 245 */
			0xee,		/* 238 */
/* 1188 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1190 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1192) */
/* 1192 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1194 */	NdrFcLong( 0x47dff751 ),	/* 1205860177 */
/* 1198 */	NdrFcShort( 0xa138 ),	/* -24264 */
/* 1200 */	NdrFcShort( 0x44b8 ),	/* 17592 */
/* 1202 */	0x8e,		/* 142 */
			0x1c,		/* 28 */
/* 1204 */	0xfd,		/* 253 */
			0xcb,		/* 203 */
/* 1206 */	0x2e,		/* 46 */
			0xd,		/* 13 */
/* 1208 */	0xc2,		/* 194 */
			0xc7,		/* 199 */
/* 1210 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1212 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1214) */
/* 1214 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1216 */	NdrFcLong( 0xaee2bf36 ),	/* -1360871626 */
/* 1220 */	NdrFcShort( 0x4b0 ),	/* 1200 */
/* 1222 */	NdrFcShort( 0x4586 ),	/* 17798 */
/* 1224 */	0x88,		/* 136 */
			0x3,		/* 3 */
/* 1226 */	0x13,		/* 19 */
			0xf2,		/* 242 */
/* 1228 */	0xaa,		/* 170 */
			0xdb,		/* 219 */
/* 1230 */	0xeb,		/* 235 */
			0xbb,		/* 187 */
/* 1232 */	
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/* 1234 */	0x2,		/* FC_CHAR */
			0x5c,		/* FC_PAD */
/* 1236 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1238 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1240) */
/* 1240 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1242 */	NdrFcLong( 0x8329961f ),	/* -2094426593 */
/* 1246 */	NdrFcShort( 0x757b ),	/* 30075 */
/* 1248 */	NdrFcShort( 0x450c ),	/* 17676 */
/* 1250 */	0x83,		/* 131 */
			0x3,		/* 3 */
/* 1252 */	0x2d,		/* 45 */
			0x3a,		/* 58 */
/* 1254 */	0x94,		/* 148 */
			0xcb,		/* 203 */
/* 1256 */	0xd8,		/* 216 */
			0xf7,		/* 247 */
/* 1258 */	
			0x12, 0x0,	/* FC_UP */
/* 1260 */	NdrFcShort( 0xff2c ),	/* Offset= -212 (1048) */
/* 1262 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 1264 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1266 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1268 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1270 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (1258) */

			0x0
        }
    };

static const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ] = 
        {
            
            {
            BSTR_UserSize
            ,BSTR_UserMarshal
            ,BSTR_UserUnmarshal
            ,BSTR_UserFree
            },
            {
            VARIANT_UserSize
            ,VARIANT_UserMarshal
            ,VARIANT_UserUnmarshal
            ,VARIANT_UserFree
            }

        };



/* Standard interface: __MIDL_itf_ScriptureObjects_0000, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: ISCReference, ver. 0.0,
   GUID={0x2C3C484E,0x8AD0,0x442e,{0x8D,0xAC,0x24,0x8F,0xCF,0x55,0xF5,0xEE}} */

#pragma code_seg(".orpc")
static const unsigned short ISCReference_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0,
    36,
    72,
    108,
    144,
    180,
    216,
    252,
    288,
    324,
    360,
    396,
    432,
    462,
    492,
    528,
    564,
    600,
    636,
    672,
    708,
    744
    };

static const MIDL_STUBLESS_PROXY_INFO ISCReference_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCReference_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCReference_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCReference_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(29) _ISCReferenceProxyVtbl = 
{
    &ISCReference_ProxyInfo,
    &IID_ISCReference,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Book */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Book */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Chapter */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Chapter */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Verse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Verse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Segment */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Segment */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_LastBook */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_LastChapter */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_LastVerse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::Parse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::NextVerse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::PreviousVerse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_AsString */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_VersificationsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Valid */ ,
    (void *) (INT_PTR) -1 /* ISCReference::ChangeVersification */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_BBCCCVVV */ ,
    (void *) (INT_PTR) -1 /* ISCReference::SetToEnd */
};


static const PRPC_STUB_FUNCTION ISCReference_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCReferenceStubVtbl =
{
    &IID_ISCReference,
    &ISCReference_ServerInfo,
    29,
    &ISCReference_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCReferenceCollection, ver. 0.0,
   GUID={0x4E207059,0xA0AF,0x485c,{0xBD,0xFC,0xC6,0xB1,0x97,0x17,0x19,0x09}} */

#pragma code_seg(".orpc")
static const unsigned short ISCReferenceCollection_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    774,
    810,
    852,
    894,
    930,
    966,
    1002,
    1038,
    1080
    };

static const MIDL_STUBLESS_PROXY_INFO ISCReferenceCollection_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCReferenceCollection_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCReferenceCollection_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCReferenceCollection_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(16) _ISCReferenceCollectionProxyVtbl = 
{
    &ISCReferenceCollection_ProxyInfo,
    &IID_ISCReferenceCollection,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::get_Count */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Item */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Parse */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::get_AsString */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Add */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Insert */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Remove */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Includes */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::get__NewEnum */
};


static const PRPC_STUB_FUNCTION ISCReferenceCollection_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCReferenceCollectionStubVtbl =
{
    &IID_ISCReferenceCollection,
    &ISCReferenceCollection_ServerInfo,
    16,
    &ISCReferenceCollection_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCTag, ver. 0.0,
   GUID={0xAEE2BF36,0x04B0,0x4586,{0x88,0x03,0x13,0xF2,0xAA,0xDB,0xEB,0xBB}} */

#pragma code_seg(".orpc")
static const unsigned short ISCTag_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    774,
    1116,
    1152,
    1188,
    1224,
    1260,
    1296,
    1332,
    1368,
    1404,
    1440,
    396,
    1476,
    1512,
    1548,
    1584,
    564,
    600,
    636,
    1620,
    708,
    1656,
    1692,
    1728,
    1764,
    1800,
    1836,
    1872,
    1908,
    1944,
    1980,
    2016,
    2052,
    2088,
    2124,
    2160,
    2196,
    2232,
    2268,
    2304,
    2340,
    2376,
    2412,
    2448,
    2484,
    2520,
    2556,
    2592,
    2628,
    2664,
    2700,
    2736,
    2772,
    2808,
    2844,
    2880,
    2916,
    2952
    };

static const MIDL_STUBLESS_PROXY_INFO ISCTag_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCTag_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCTag_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCTag_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(65) _ISCTagProxyVtbl = 
{
    &ISCTag_ProxyInfo,
    &IID_ISCTag,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Bold */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Bold */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Color */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Color */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Description */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Description */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Endmarker */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Endmarker */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_FirstLineIndent */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_FirstLineIndent */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Fontname */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Fontname */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_FontSize */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_FontSize */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Italic */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Italic */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_JustificationType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_JustificationType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_LeftMargin */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_LeftMargin */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_LineSpacing */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_LineSpacing */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Marker */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Marker */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_TeStyleName */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_TeStyleName */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_NotRepeatable */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_NotRepeatable */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_OccursUnder */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_OccursUnder */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Rank */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Rank */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_RightMargin */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_RightMargin */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_SpaceAfter */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_SpaceAfter */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_SpaceBefore */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_SpaceBefore */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_StyleType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_StyleType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Superscript */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Superscript */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_TextProperties */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_TextProperties */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_TextType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_TextType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Underline */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Underline */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_XMLTag */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_XMLTag */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_SmallCaps */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_SmallCaps */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Subscript */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Subscript */
};


static const PRPC_STUB_FUNCTION ISCTag_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCTagStubVtbl =
{
    &IID_ISCTag,
    &ISCTag_ServerInfo,
    65,
    &ISCTag_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCTextSegment, ver. 0.0,
   GUID={0x809FD5B3,0x5278,0x4719,{0xB9,0xC7,0x9E,0x0B,0x2D,0xE2,0x6D,0xE8}} */

#pragma code_seg(".orpc")
static const unsigned short ISCTextSegment_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    2988,
    3024,
    3060,
    3096,
    1224,
    1260,
    3132,
    3168,
    3204,
    3240,
    3276,
    3312,
    3348
    };

static const MIDL_STUBLESS_PROXY_INFO ISCTextSegment_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCTextSegment_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCTextSegment_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCTextSegment_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(20) _ISCTextSegmentProxyVtbl = 
{
    &ISCTextSegment_ProxyInfo,
    &IID_ISCTextSegment,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_FirstReference */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_FirstReference */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_LastReference */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_LastReference */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_Text */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_Text */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_TextType */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_TextType */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_TextProperties */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_TextProperties */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_Tag */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_Tag */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::Clone */
};


static const PRPC_STUB_FUNCTION ISCTextSegment_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCTextSegmentStubVtbl =
{
    &IID_ISCTextSegment,
    &ISCTextSegment_ServerInfo,
    20,
    &ISCTextSegment_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCTextEnum, ver. 0.0,
   GUID={0x47DFF751,0xA138,0x44b8,{0x8E,0x1C,0xFD,0xCB,0x2E,0x0D,0xC2,0xC7}} */

#pragma code_seg(".orpc")
static const unsigned short ISCTextEnum_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3384,
    3426,
    3468,
    3504
    };

static const MIDL_STUBLESS_PROXY_INFO ISCTextEnum_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCTextEnum_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCTextEnum_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCTextEnum_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(11) _ISCTextEnumProxyVtbl = 
{
    &ISCTextEnum_ProxyInfo,
    &IID_ISCTextEnum,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnum::NextToken */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnum::Next */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnum::Update */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnum::SetText */
};


static const PRPC_STUB_FUNCTION ISCTextEnum_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCTextEnumStubVtbl =
{
    &IID_ISCTextEnum,
    &ISCTextEnum_ServerInfo,
    11,
    &ISCTextEnum_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCTextEnumEx, ver. 0.0,
   GUID={0x8329961F,0x757B,0x450c,{0x83,0x03,0x2D,0x3A,0x94,0xCB,0xD8,0xF7}} */

#pragma code_seg(".orpc")
static const unsigned short ISCTextEnumEx_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3384,
    3552
    };

static const MIDL_STUBLESS_PROXY_INFO ISCTextEnumEx_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCTextEnumEx_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCTextEnumEx_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCTextEnumEx_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(9) _ISCTextEnumExProxyVtbl = 
{
    &ISCTextEnumEx_ProxyInfo,
    &IID_ISCTextEnumEx,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnumEx::NextToken */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnumEx::Next */
};


static const PRPC_STUB_FUNCTION ISCTextEnumEx_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCTextEnumExStubVtbl =
{
    &IID_ISCTextEnumEx,
    &ISCTextEnumEx_ServerInfo,
    9,
    &ISCTextEnumEx_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCScriptureText, ver. 0.0,
   GUID={0xE36624CE,0x5A21,0x458e,{0x8F,0x3B,0x97,0x23,0xCE,0xDD,0x45,0x30}} */

#pragma code_seg(".orpc")
static const unsigned short ISCScriptureText_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3600,
    3636,
    3672,
    3708,
    3768,
    3822,
    3876,
    3936,
    3990,
    4032,
    4074,
    4116,
    4158,
    4200,
    4236,
    4272,
    4308,
    4344,
    4380,
    4416,
    4452,
    4488,
    4524,
    4560,
    4596,
    4632,
    4668,
    4704,
    4740,
    4776,
    4812,
    4848,
    4884,
    4920,
    4956,
    4992,
    5028,
    5064,
    5100,
    5136,
    5172,
    5208,
    5244,
    5280,
    2484,
    2520
    };

static const MIDL_STUBLESS_PROXY_INFO ISCScriptureText_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCScriptureText_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(53) _ISCScriptureTextProxyVtbl = 
{
    &ISCScriptureText_ProxyInfo,
    &IID_ISCScriptureText,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_TextsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Load */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Save */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TextEnum */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::PutText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::FileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthFileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthTag */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TagIndex */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::CharToWChar */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::SetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_SettingsDirectory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Versification */
};


static const PRPC_STUB_FUNCTION ISCScriptureText_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCScriptureTextStubVtbl =
{
    &IID_ISCScriptureText,
    &ISCScriptureText_ServerInfo,
    53,
    &ISCScriptureText_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCScriptureText2, ver. 0.0,
   GUID={0x9B2DA462,0xACDA,0x48c2,{0x9D,0x23,0xA6,0x52,0xF0,0x6E,0xC7,0xFA}} */

#pragma code_seg(".orpc")
static const unsigned short ISCScriptureText2_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3600,
    3636,
    3672,
    3708,
    3768,
    3822,
    3876,
    3936,
    3990,
    4032,
    4074,
    4116,
    4158,
    4200,
    4236,
    4272,
    4308,
    4344,
    4380,
    4416,
    4452,
    4488,
    4524,
    4560,
    4596,
    4632,
    4668,
    4704,
    4740,
    4776,
    4812,
    4848,
    4884,
    4920,
    4956,
    4992,
    5028,
    5064,
    5100,
    5136,
    5172,
    5208,
    5244,
    5280,
    2484,
    2520,
    5316,
    5352
    };

static const MIDL_STUBLESS_PROXY_INFO ISCScriptureText2_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText2_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCScriptureText2_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText2_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(55) _ISCScriptureText2ProxyVtbl = 
{
    &ISCScriptureText2_ProxyInfo,
    &IID_ISCScriptureText2,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_TextsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Load */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Save */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TextEnum */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::PutText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::FileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthFileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthTag */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TagIndex */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::CharToWChar */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::SetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_SettingsDirectory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::get_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::put_Encoding */
};


static const PRPC_STUB_FUNCTION ISCScriptureText2_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCScriptureText2StubVtbl =
{
    &IID_ISCScriptureText2,
    &ISCScriptureText2_ServerInfo,
    55,
    &ISCScriptureText2_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCScriptureText3, ver. 0.0,
   GUID={0xDCAC5534,0x8CC8,0x4b91,{0xBC,0x3C,0x41,0x8B,0x91,0x5D,0xA7,0x8C}} */

#pragma code_seg(".orpc")
static const unsigned short ISCScriptureText3_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3600,
    3636,
    3672,
    3708,
    3768,
    3822,
    3876,
    3936,
    3990,
    4032,
    4074,
    4116,
    4158,
    4200,
    4236,
    4272,
    4308,
    4344,
    4380,
    4416,
    4452,
    4488,
    4524,
    4560,
    4596,
    4632,
    4668,
    4704,
    4740,
    4776,
    4812,
    4848,
    4884,
    4920,
    4956,
    4992,
    5028,
    5064,
    5100,
    5136,
    5172,
    5208,
    5244,
    5280,
    2484,
    2520,
    5316,
    5352,
    2628
    };

static const MIDL_STUBLESS_PROXY_INFO ISCScriptureText3_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText3_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCScriptureText3_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText3_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(56) _ISCScriptureText3ProxyVtbl = 
{
    &ISCScriptureText3_ProxyInfo,
    &IID_ISCScriptureText3,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_TextsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Load */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Save */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TextEnum */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::PutText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::FileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthFileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthTag */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TagIndex */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::CharToWChar */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::SetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_SettingsDirectory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::get_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::put_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText3::get_AsteriskIsMarker */
};


static const PRPC_STUB_FUNCTION ISCScriptureText3_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCScriptureText3StubVtbl =
{
    &IID_ISCScriptureText3,
    &ISCScriptureText3_ServerInfo,
    56,
    &ISCScriptureText3_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCScriptureText4, ver. 0.0,
   GUID={0x12AAD383,0x2909,0x4a14,{0xAD,0xA9,0xC7,0x3D,0xC2,0x31,0xA1,0x8D}} */

#pragma code_seg(".orpc")
static const unsigned short ISCScriptureText4_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3600,
    3636,
    3672,
    3708,
    3768,
    3822,
    3876,
    3936,
    3990,
    4032,
    4074,
    4116,
    4158,
    4200,
    4236,
    4272,
    4308,
    4344,
    4380,
    4416,
    4452,
    4488,
    4524,
    4560,
    4596,
    4632,
    4668,
    4704,
    4740,
    4776,
    4812,
    4848,
    4884,
    4920,
    4956,
    4992,
    5028,
    5064,
    5100,
    5136,
    5172,
    5208,
    5244,
    5280,
    2484,
    2520,
    5316,
    5352,
    2628,
    5388,
    5436
    };

static const MIDL_STUBLESS_PROXY_INFO ISCScriptureText4_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText4_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCScriptureText4_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText4_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(58) _ISCScriptureText4ProxyVtbl = 
{
    &ISCScriptureText4_ProxyInfo,
    &IID_ISCScriptureText4,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_TextsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Load */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Save */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TextEnum */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::PutText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::FileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthFileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthTag */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TagIndex */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::CharToWChar */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::SetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_SettingsDirectory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::get_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::put_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText3::get_AsteriskIsMarker */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText4::TextEnumEx */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText4::LoadECObjectDataForSOReading */
};


static const PRPC_STUB_FUNCTION ISCScriptureText4_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCScriptureText4StubVtbl =
{
    &IID_ISCScriptureText4,
    &ISCScriptureText4_ServerInfo,
    58,
    &ISCScriptureText4_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IPreSO, ver. 0.0,
   GUID={0x936CB9E1,0x4EE8,0x4c8e,{0x85,0xB8,0x68,0x19,0x8B,0x89,0xF1,0xBA}} */

#pragma code_seg(".orpc")
static const unsigned short IPreSO_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    5472,
    5508,
    3672,
    5550,
    5586,
    5622,
    5658,
    5694,
    5760,
    5814
    };

static const MIDL_STUBLESS_PROXY_INFO IPreSO_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IPreSO_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IPreSO_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IPreSO_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(17) _IPreSOProxyVtbl = 
{
    &IPreSO_ProxyInfo,
    &IID_IPreSO,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* IPreSO::Initialize */ ,
    (void *) (INT_PTR) -1 /* IPreSO::Save */ ,
    (void *) (INT_PTR) -1 /* IPreSO::AddFile */ ,
    (void *) (INT_PTR) -1 /* IPreSO::RemoveFile */ ,
    (void *) (INT_PTR) -1 /* IPreSO::get_Files */ ,
    (void *) (INT_PTR) -1 /* IPreSO::get_BookMarker */ ,
    (void *) (INT_PTR) -1 /* IPreSO::put_BookMarker */ ,
    (void *) (INT_PTR) -1 /* IPreSO::NthMapping */ ,
    (void *) (INT_PTR) -1 /* IPreSO::SetMapping */ ,
    (void *) (INT_PTR) -1 /* IPreSO::GetBooksForFile */
};


static const PRPC_STUB_FUNCTION IPreSO_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _IPreSOStubVtbl =
{
    &IID_IPreSO,
    &IPreSO_ServerInfo,
    17,
    &IPreSO_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x50002, /* Ndr library version */
    0,
    0x6000169, /* MIDL Version 6.0.361 */
    0,
    UserMarshalRoutines,
    0,  /* notify & notify_flag routine table */
    0x1, /* MIDL flag */
    0, /* cs routines */
    0,   /* proxy/server info */
    0   /* Reserved5 */
    };

const CInterfaceProxyVtbl * _ScriptureObjects_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_ISCTextEnumExProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCScriptureText3ProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCTagProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCReferenceProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCTextEnumProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCReferenceCollectionProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCScriptureText2ProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCScriptureText4ProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCTextSegmentProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCScriptureTextProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IPreSOProxyVtbl,
    0
};

const CInterfaceStubVtbl * _ScriptureObjects_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_ISCTextEnumExStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCScriptureText3StubVtbl,
    ( CInterfaceStubVtbl *) &_ISCTagStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCReferenceStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCTextEnumStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCReferenceCollectionStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCScriptureText2StubVtbl,
    ( CInterfaceStubVtbl *) &_ISCScriptureText4StubVtbl,
    ( CInterfaceStubVtbl *) &_ISCTextSegmentStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCScriptureTextStubVtbl,
    ( CInterfaceStubVtbl *) &_IPreSOStubVtbl,
    0
};

PCInterfaceName const _ScriptureObjects_InterfaceNamesList[] = 
{
    "ISCTextEnumEx",
    "ISCScriptureText3",
    "ISCTag",
    "ISCReference",
    "ISCTextEnum",
    "ISCReferenceCollection",
    "ISCScriptureText2",
    "ISCScriptureText4",
    "ISCTextSegment",
    "ISCScriptureText",
    "IPreSO",
    0
};

const IID *  _ScriptureObjects_BaseIIDList[] = 
{
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    0
};


#define _ScriptureObjects_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _ScriptureObjects, pIID, n)

int __stdcall _ScriptureObjects_IID_Lookup( const IID * pIID, int * pIndex )
{
    IID_BS_LOOKUP_SETUP

    IID_BS_LOOKUP_INITIAL_TEST( _ScriptureObjects, 11, 8 )
    IID_BS_LOOKUP_NEXT_TEST( _ScriptureObjects, 4 )
    IID_BS_LOOKUP_NEXT_TEST( _ScriptureObjects, 2 )
    IID_BS_LOOKUP_NEXT_TEST( _ScriptureObjects, 1 )
    IID_BS_LOOKUP_RETURN_RESULT( _ScriptureObjects, 11, *pIndex )
    
}

const ExtendedProxyFileInfo ScriptureObjects_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _ScriptureObjects_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _ScriptureObjects_StubVtblList,
    (const PCInterfaceName * ) & _ScriptureObjects_InterfaceNamesList,
    (const IID ** ) & _ScriptureObjects_BaseIIDList,
    & _ScriptureObjects_IID_Lookup, 
    11,
    2,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};
#if _MSC_VER >= 1200
#pragma warning(pop)
#endif


#endif /* !defined(_M_IA64) && !defined(_M_AMD64)*/



/* this ALWAYS GENERATED file contains the proxy stub code */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Fri May 21 13:32:49 2004
 */
/* Compiler settings for ScriptureObjects.idl:
    Oicf, W1, Zp8, env=Win64 (32b run,appending)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if defined(_M_IA64) || defined(_M_AMD64)


#pragma warning( disable: 4049 )  /* more than 64k source lines */
#if _MSC_VER >= 1200
#pragma warning(push)
#endif

#pragma warning( disable: 4211 )  /* redefine extent to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/
#define USE_STUBLESS_PROXY


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 475
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif // __RPCPROXY_H_VERSION__


#include "ScriptureObjects.h"

#define TYPE_FORMAT_STRING_SIZE   1223                              
#define PROC_FORMAT_STRING_SIZE   6169                              
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   2            

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


static RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCReference_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCReference_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCReferenceCollection_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCReferenceCollection_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCTag_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCTag_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCTextSegment_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCTextSegment_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCTextEnum_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCTextEnum_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCTextEnumEx_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCTextEnumEx_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCScriptureText_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCScriptureText_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCScriptureText2_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCScriptureText2_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCScriptureText3_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCScriptureText3_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISCScriptureText4_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISCScriptureText4_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IPreSO_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IPreSO_ProxyInfo;


extern const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ];

#if !defined(__RPC_WIN64__)
#error  Invalid build platform for this stub.
#endif

static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure get_Book */

			0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x7 ),	/* 7 */
/*  8 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 10 */	NdrFcShort( 0x0 ),	/* 0 */
/* 12 */	NdrFcShort( 0x22 ),	/* 34 */
/* 14 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 16 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 18 */	NdrFcShort( 0x0 ),	/* 0 */
/* 20 */	NdrFcShort( 0x0 ),	/* 0 */
/* 22 */	NdrFcShort( 0x0 ),	/* 0 */
/* 24 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 26 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 28 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 30 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 32 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 34 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 36 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Book */

/* 38 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 40 */	NdrFcLong( 0x0 ),	/* 0 */
/* 44 */	NdrFcShort( 0x8 ),	/* 8 */
/* 46 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 48 */	NdrFcShort( 0x6 ),	/* 6 */
/* 50 */	NdrFcShort( 0x8 ),	/* 8 */
/* 52 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 54 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 56 */	NdrFcShort( 0x0 ),	/* 0 */
/* 58 */	NdrFcShort( 0x0 ),	/* 0 */
/* 60 */	NdrFcShort( 0x0 ),	/* 0 */
/* 62 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 64 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 66 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 68 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 70 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 72 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 74 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Chapter */

/* 76 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 78 */	NdrFcLong( 0x0 ),	/* 0 */
/* 82 */	NdrFcShort( 0x9 ),	/* 9 */
/* 84 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 86 */	NdrFcShort( 0x0 ),	/* 0 */
/* 88 */	NdrFcShort( 0x22 ),	/* 34 */
/* 90 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 92 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 94 */	NdrFcShort( 0x0 ),	/* 0 */
/* 96 */	NdrFcShort( 0x0 ),	/* 0 */
/* 98 */	NdrFcShort( 0x0 ),	/* 0 */
/* 100 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 102 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 104 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 106 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 108 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 110 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 112 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Chapter */

/* 114 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 116 */	NdrFcLong( 0x0 ),	/* 0 */
/* 120 */	NdrFcShort( 0xa ),	/* 10 */
/* 122 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 124 */	NdrFcShort( 0x6 ),	/* 6 */
/* 126 */	NdrFcShort( 0x8 ),	/* 8 */
/* 128 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 130 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 132 */	NdrFcShort( 0x0 ),	/* 0 */
/* 134 */	NdrFcShort( 0x0 ),	/* 0 */
/* 136 */	NdrFcShort( 0x0 ),	/* 0 */
/* 138 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 140 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 142 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 144 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 146 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 148 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 150 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Verse */

/* 152 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 154 */	NdrFcLong( 0x0 ),	/* 0 */
/* 158 */	NdrFcShort( 0xb ),	/* 11 */
/* 160 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 162 */	NdrFcShort( 0x0 ),	/* 0 */
/* 164 */	NdrFcShort( 0x22 ),	/* 34 */
/* 166 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 168 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 170 */	NdrFcShort( 0x0 ),	/* 0 */
/* 172 */	NdrFcShort( 0x0 ),	/* 0 */
/* 174 */	NdrFcShort( 0x0 ),	/* 0 */
/* 176 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 178 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 180 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 182 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 184 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 186 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 188 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Verse */

/* 190 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 192 */	NdrFcLong( 0x0 ),	/* 0 */
/* 196 */	NdrFcShort( 0xc ),	/* 12 */
/* 198 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 200 */	NdrFcShort( 0x6 ),	/* 6 */
/* 202 */	NdrFcShort( 0x8 ),	/* 8 */
/* 204 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 206 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 208 */	NdrFcShort( 0x0 ),	/* 0 */
/* 210 */	NdrFcShort( 0x0 ),	/* 0 */
/* 212 */	NdrFcShort( 0x0 ),	/* 0 */
/* 214 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 216 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 218 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 220 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 222 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 224 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 226 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Segment */

/* 228 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 230 */	NdrFcLong( 0x0 ),	/* 0 */
/* 234 */	NdrFcShort( 0xd ),	/* 13 */
/* 236 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 238 */	NdrFcShort( 0x0 ),	/* 0 */
/* 240 */	NdrFcShort( 0x22 ),	/* 34 */
/* 242 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 244 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 246 */	NdrFcShort( 0x0 ),	/* 0 */
/* 248 */	NdrFcShort( 0x0 ),	/* 0 */
/* 250 */	NdrFcShort( 0x0 ),	/* 0 */
/* 252 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 254 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 256 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 258 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 260 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 262 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 264 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Segment */

/* 266 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 268 */	NdrFcLong( 0x0 ),	/* 0 */
/* 272 */	NdrFcShort( 0xe ),	/* 14 */
/* 274 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 276 */	NdrFcShort( 0x6 ),	/* 6 */
/* 278 */	NdrFcShort( 0x8 ),	/* 8 */
/* 280 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 282 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 284 */	NdrFcShort( 0x0 ),	/* 0 */
/* 286 */	NdrFcShort( 0x0 ),	/* 0 */
/* 288 */	NdrFcShort( 0x0 ),	/* 0 */
/* 290 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 292 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 294 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 296 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 298 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 300 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 302 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LastBook */

/* 304 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 306 */	NdrFcLong( 0x0 ),	/* 0 */
/* 310 */	NdrFcShort( 0xf ),	/* 15 */
/* 312 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 314 */	NdrFcShort( 0x0 ),	/* 0 */
/* 316 */	NdrFcShort( 0x22 ),	/* 34 */
/* 318 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 320 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 322 */	NdrFcShort( 0x0 ),	/* 0 */
/* 324 */	NdrFcShort( 0x0 ),	/* 0 */
/* 326 */	NdrFcShort( 0x0 ),	/* 0 */
/* 328 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 330 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 332 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 334 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 336 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 338 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 340 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LastChapter */

/* 342 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 344 */	NdrFcLong( 0x0 ),	/* 0 */
/* 348 */	NdrFcShort( 0x10 ),	/* 16 */
/* 350 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 352 */	NdrFcShort( 0x0 ),	/* 0 */
/* 354 */	NdrFcShort( 0x22 ),	/* 34 */
/* 356 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 358 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 360 */	NdrFcShort( 0x0 ),	/* 0 */
/* 362 */	NdrFcShort( 0x0 ),	/* 0 */
/* 364 */	NdrFcShort( 0x0 ),	/* 0 */
/* 366 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 368 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 370 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 372 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 374 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 376 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 378 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LastVerse */

/* 380 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 382 */	NdrFcLong( 0x0 ),	/* 0 */
/* 386 */	NdrFcShort( 0x11 ),	/* 17 */
/* 388 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 390 */	NdrFcShort( 0x0 ),	/* 0 */
/* 392 */	NdrFcShort( 0x22 ),	/* 34 */
/* 394 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 396 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 398 */	NdrFcShort( 0x0 ),	/* 0 */
/* 400 */	NdrFcShort( 0x0 ),	/* 0 */
/* 402 */	NdrFcShort( 0x0 ),	/* 0 */
/* 404 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 406 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 408 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 410 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 412 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 414 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 416 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Fontname */


	/* Procedure Parse */

/* 418 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 420 */	NdrFcLong( 0x0 ),	/* 0 */
/* 424 */	NdrFcShort( 0x12 ),	/* 18 */
/* 426 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 428 */	NdrFcShort( 0x0 ),	/* 0 */
/* 430 */	NdrFcShort( 0x8 ),	/* 8 */
/* 432 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 434 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 436 */	NdrFcShort( 0x0 ),	/* 0 */
/* 438 */	NdrFcShort( 0x1 ),	/* 1 */
/* 440 */	NdrFcShort( 0x0 ),	/* 0 */
/* 442 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */


	/* Parameter val */

/* 444 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 446 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 448 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */


	/* Return value */

/* 450 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 452 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 454 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NextVerse */

/* 456 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 458 */	NdrFcLong( 0x0 ),	/* 0 */
/* 462 */	NdrFcShort( 0x13 ),	/* 19 */
/* 464 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 466 */	NdrFcShort( 0x0 ),	/* 0 */
/* 468 */	NdrFcShort( 0x8 ),	/* 8 */
/* 470 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x1,		/* 1 */
/* 472 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 474 */	NdrFcShort( 0x0 ),	/* 0 */
/* 476 */	NdrFcShort( 0x0 ),	/* 0 */
/* 478 */	NdrFcShort( 0x0 ),	/* 0 */
/* 480 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Return value */

/* 482 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 484 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 486 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure PreviousVerse */

/* 488 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 490 */	NdrFcLong( 0x0 ),	/* 0 */
/* 494 */	NdrFcShort( 0x14 ),	/* 20 */
/* 496 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 498 */	NdrFcShort( 0x0 ),	/* 0 */
/* 500 */	NdrFcShort( 0x8 ),	/* 8 */
/* 502 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x1,		/* 1 */
/* 504 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 506 */	NdrFcShort( 0x0 ),	/* 0 */
/* 508 */	NdrFcShort( 0x0 ),	/* 0 */
/* 510 */	NdrFcShort( 0x0 ),	/* 0 */
/* 512 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Return value */

/* 514 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 516 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 518 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_AsString */

/* 520 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 522 */	NdrFcLong( 0x0 ),	/* 0 */
/* 526 */	NdrFcShort( 0x15 ),	/* 21 */
/* 528 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 530 */	NdrFcShort( 0x0 ),	/* 0 */
/* 532 */	NdrFcShort( 0x8 ),	/* 8 */
/* 534 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 536 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 538 */	NdrFcShort( 0x1 ),	/* 1 */
/* 540 */	NdrFcShort( 0x0 ),	/* 0 */
/* 542 */	NdrFcShort( 0x0 ),	/* 0 */
/* 544 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 546 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 548 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 550 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 552 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 554 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 556 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_VersificationsPresent */

/* 558 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 560 */	NdrFcLong( 0x0 ),	/* 0 */
/* 564 */	NdrFcShort( 0x16 ),	/* 22 */
/* 566 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 568 */	NdrFcShort( 0x0 ),	/* 0 */
/* 570 */	NdrFcShort( 0x8 ),	/* 8 */
/* 572 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 574 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 576 */	NdrFcShort( 0x1 ),	/* 1 */
/* 578 */	NdrFcShort( 0x0 ),	/* 0 */
/* 580 */	NdrFcShort( 0x0 ),	/* 0 */
/* 582 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 584 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 586 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 588 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 590 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 592 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 594 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_JustificationType */


	/* Procedure get_Versification */

/* 596 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 598 */	NdrFcLong( 0x0 ),	/* 0 */
/* 602 */	NdrFcShort( 0x17 ),	/* 23 */
/* 604 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 606 */	NdrFcShort( 0x0 ),	/* 0 */
/* 608 */	NdrFcShort( 0x22 ),	/* 34 */
/* 610 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 612 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 614 */	NdrFcShort( 0x0 ),	/* 0 */
/* 616 */	NdrFcShort( 0x0 ),	/* 0 */
/* 618 */	NdrFcShort( 0x0 ),	/* 0 */
/* 620 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 622 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 624 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 626 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */


	/* Return value */

/* 628 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 630 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 632 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_JustificationType */


	/* Procedure put_Versification */

/* 634 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 636 */	NdrFcLong( 0x0 ),	/* 0 */
/* 640 */	NdrFcShort( 0x18 ),	/* 24 */
/* 642 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 644 */	NdrFcShort( 0x6 ),	/* 6 */
/* 646 */	NdrFcShort( 0x8 ),	/* 8 */
/* 648 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 650 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 652 */	NdrFcShort( 0x0 ),	/* 0 */
/* 654 */	NdrFcShort( 0x0 ),	/* 0 */
/* 656 */	NdrFcShort( 0x0 ),	/* 0 */
/* 658 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 660 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 662 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 664 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 666 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 668 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 670 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LeftMargin */


	/* Procedure get_Valid */

/* 672 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 674 */	NdrFcLong( 0x0 ),	/* 0 */
/* 678 */	NdrFcShort( 0x19 ),	/* 25 */
/* 680 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 682 */	NdrFcShort( 0x0 ),	/* 0 */
/* 684 */	NdrFcShort( 0x24 ),	/* 36 */
/* 686 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 688 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 690 */	NdrFcShort( 0x0 ),	/* 0 */
/* 692 */	NdrFcShort( 0x0 ),	/* 0 */
/* 694 */	NdrFcShort( 0x0 ),	/* 0 */
/* 696 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */


	/* Parameter pVal */

/* 698 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 700 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 702 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 704 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 706 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 708 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure ChangeVersification */

/* 710 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 712 */	NdrFcLong( 0x0 ),	/* 0 */
/* 716 */	NdrFcShort( 0x1a ),	/* 26 */
/* 718 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 720 */	NdrFcShort( 0x6 ),	/* 6 */
/* 722 */	NdrFcShort( 0x8 ),	/* 8 */
/* 724 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 726 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 728 */	NdrFcShort( 0x0 ),	/* 0 */
/* 730 */	NdrFcShort( 0x0 ),	/* 0 */
/* 732 */	NdrFcShort( 0x0 ),	/* 0 */
/* 734 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter NewVersification */

/* 736 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 738 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 740 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 742 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 744 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 746 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LineSpacing */


	/* Procedure get_BBCCCVVV */

/* 748 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 750 */	NdrFcLong( 0x0 ),	/* 0 */
/* 754 */	NdrFcShort( 0x1b ),	/* 27 */
/* 756 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 758 */	NdrFcShort( 0x0 ),	/* 0 */
/* 760 */	NdrFcShort( 0x24 ),	/* 36 */
/* 762 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 764 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 766 */	NdrFcShort( 0x0 ),	/* 0 */
/* 768 */	NdrFcShort( 0x0 ),	/* 0 */
/* 770 */	NdrFcShort( 0x0 ),	/* 0 */
/* 772 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */


	/* Parameter pVal */

/* 774 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 776 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 778 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 780 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 782 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 784 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure SetToEnd */

/* 786 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 788 */	NdrFcLong( 0x0 ),	/* 0 */
/* 792 */	NdrFcShort( 0x1c ),	/* 28 */
/* 794 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 796 */	NdrFcShort( 0x0 ),	/* 0 */
/* 798 */	NdrFcShort( 0x8 ),	/* 8 */
/* 800 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x1,		/* 1 */
/* 802 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 804 */	NdrFcShort( 0x0 ),	/* 0 */
/* 806 */	NdrFcShort( 0x0 ),	/* 0 */
/* 808 */	NdrFcShort( 0x0 ),	/* 0 */
/* 810 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Return value */

/* 812 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 814 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 816 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Bold */


	/* Procedure get_Count */

/* 818 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 820 */	NdrFcLong( 0x0 ),	/* 0 */
/* 824 */	NdrFcShort( 0x7 ),	/* 7 */
/* 826 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 828 */	NdrFcShort( 0x0 ),	/* 0 */
/* 830 */	NdrFcShort( 0x24 ),	/* 36 */
/* 832 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 834 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 836 */	NdrFcShort( 0x0 ),	/* 0 */
/* 838 */	NdrFcShort( 0x0 ),	/* 0 */
/* 840 */	NdrFcShort( 0x0 ),	/* 0 */
/* 842 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */


	/* Parameter pVal */

/* 844 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 846 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 848 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 850 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 852 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 854 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Item */

/* 856 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 858 */	NdrFcLong( 0x0 ),	/* 0 */
/* 862 */	NdrFcShort( 0x8 ),	/* 8 */
/* 864 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 866 */	NdrFcShort( 0x8 ),	/* 8 */
/* 868 */	NdrFcShort( 0x8 ),	/* 8 */
/* 870 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 872 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 874 */	NdrFcShort( 0x20 ),	/* 32 */
/* 876 */	NdrFcShort( 0x0 ),	/* 0 */
/* 878 */	NdrFcShort( 0x0 ),	/* 0 */
/* 880 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter index */

/* 882 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 884 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 886 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pItem */

/* 888 */	NdrFcShort( 0x6113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=24 */
/* 890 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 892 */	NdrFcShort( 0x3fa ),	/* Type Offset=1018 */

	/* Return value */

/* 894 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 896 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 898 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Parse */

/* 900 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 902 */	NdrFcLong( 0x0 ),	/* 0 */
/* 906 */	NdrFcShort( 0x9 ),	/* 9 */
/* 908 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 910 */	NdrFcShort( 0x0 ),	/* 0 */
/* 912 */	NdrFcShort( 0x8 ),	/* 8 */
/* 914 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 916 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 918 */	NdrFcShort( 0x0 ),	/* 0 */
/* 920 */	NdrFcShort( 0x2 ),	/* 2 */
/* 922 */	NdrFcShort( 0x0 ),	/* 0 */
/* 924 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrReferences */

/* 926 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 928 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 930 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter bstrCommentCharacter */

/* 932 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 934 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 936 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 938 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 940 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 942 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_AsString */

/* 944 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 946 */	NdrFcLong( 0x0 ),	/* 0 */
/* 950 */	NdrFcShort( 0xa ),	/* 10 */
/* 952 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 954 */	NdrFcShort( 0x0 ),	/* 0 */
/* 956 */	NdrFcShort( 0x8 ),	/* 8 */
/* 958 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 960 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 962 */	NdrFcShort( 0x1 ),	/* 1 */
/* 964 */	NdrFcShort( 0x0 ),	/* 0 */
/* 966 */	NdrFcShort( 0x0 ),	/* 0 */
/* 968 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 970 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 972 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 974 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 976 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 978 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 980 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Add */

/* 982 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 984 */	NdrFcLong( 0x0 ),	/* 0 */
/* 988 */	NdrFcShort( 0xb ),	/* 11 */
/* 990 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 992 */	NdrFcShort( 0x0 ),	/* 0 */
/* 994 */	NdrFcShort( 0x8 ),	/* 8 */
/* 996 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 998 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1000 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1002 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1004 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1006 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReference */

/* 1008 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 1010 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1012 */	NdrFcShort( 0x404 ),	/* Type Offset=1028 */

	/* Return value */

/* 1014 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1016 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1018 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Insert */

/* 1020 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1022 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1026 */	NdrFcShort( 0xc ),	/* 12 */
/* 1028 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1030 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1032 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1034 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1036 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1038 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1040 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1042 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1044 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReference */

/* 1046 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 1048 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1050 */	NdrFcShort( 0x404 ),	/* Type Offset=1028 */

	/* Return value */

/* 1052 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1054 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1056 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Remove */

/* 1058 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1060 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1064 */	NdrFcShort( 0xd ),	/* 13 */
/* 1066 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1068 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1070 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1072 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1074 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1076 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1078 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1080 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1082 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter index */

/* 1084 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1086 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1088 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1090 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1092 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1094 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Includes */

/* 1096 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1098 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1102 */	NdrFcShort( 0xe ),	/* 14 */
/* 1104 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 1106 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1108 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1110 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 1112 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1114 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1116 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1118 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1120 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReference */

/* 1122 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 1124 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1126 */	NdrFcShort( 0x404 ),	/* Type Offset=1028 */

	/* Parameter fVal */

/* 1128 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1130 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1132 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1134 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1136 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1138 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get__NewEnum */

/* 1140 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1142 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1146 */	NdrFcShort( 0xf ),	/* 15 */
/* 1148 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1150 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1152 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1154 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1156 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1158 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1160 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1162 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1164 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 1166 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 1168 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1170 */	NdrFcShort( 0x416 ),	/* Type Offset=1046 */

	/* Return value */

/* 1172 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1174 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1176 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Bold */

/* 1178 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1180 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1184 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1186 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1188 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1190 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1192 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1194 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1196 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1198 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1200 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1202 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 1204 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1206 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1208 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1210 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1212 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1214 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Color */

/* 1216 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1218 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1222 */	NdrFcShort( 0x9 ),	/* 9 */
/* 1224 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1226 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1228 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1230 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1232 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1234 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1236 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1238 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1240 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 1242 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1244 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1246 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1248 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1250 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1252 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Color */

/* 1254 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1256 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1260 */	NdrFcShort( 0xa ),	/* 10 */
/* 1262 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1264 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1266 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1268 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1270 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1272 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1274 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1276 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1278 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1280 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1282 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1284 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1286 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1288 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1290 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Text */


	/* Procedure get_Description */

/* 1292 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1294 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1298 */	NdrFcShort( 0xb ),	/* 11 */
/* 1300 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1302 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1304 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1306 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1308 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1310 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1312 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1314 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1316 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */


	/* Parameter pbstr */

/* 1318 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1320 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1322 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */


	/* Return value */

/* 1324 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1326 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1328 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Text */


	/* Procedure put_Description */

/* 1330 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1332 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1336 */	NdrFcShort( 0xc ),	/* 12 */
/* 1338 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1340 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1342 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1344 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1346 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1348 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1350 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1352 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1354 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */


	/* Parameter bstr */

/* 1356 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1358 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1360 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */


	/* Return value */

/* 1362 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1364 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1366 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Endmarker */

/* 1368 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1370 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1374 */	NdrFcShort( 0xd ),	/* 13 */
/* 1376 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1378 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1380 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1382 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1384 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1386 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1388 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1390 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1392 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1394 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1396 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1398 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1400 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1402 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1404 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Endmarker */

/* 1406 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1408 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1412 */	NdrFcShort( 0xe ),	/* 14 */
/* 1414 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1416 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1418 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1420 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1422 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1424 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1426 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1428 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1430 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 1432 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1434 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1436 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 1438 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1440 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1442 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FirstLineIndent */

/* 1444 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1446 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1450 */	NdrFcShort( 0xf ),	/* 15 */
/* 1452 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1454 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1456 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1458 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1460 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1462 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1464 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1466 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1468 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 1470 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1472 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1474 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1476 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1478 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1480 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FirstLineIndent */

/* 1482 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1484 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1488 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1490 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1492 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1494 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1496 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1498 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1500 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1502 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1504 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1506 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1508 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1510 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1512 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1514 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1516 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1518 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Fontname */

/* 1520 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1522 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1526 */	NdrFcShort( 0x11 ),	/* 17 */
/* 1528 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1530 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1532 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1534 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1536 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1538 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1540 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1542 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1544 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1546 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1548 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1550 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1552 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1554 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1556 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FontSize */

/* 1558 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1560 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1564 */	NdrFcShort( 0x13 ),	/* 19 */
/* 1566 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1568 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1570 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1572 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1574 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1576 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1578 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1580 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1582 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 1584 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1586 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1588 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1590 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1592 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1594 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FontSize */

/* 1596 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1598 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1602 */	NdrFcShort( 0x14 ),	/* 20 */
/* 1604 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1606 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1608 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1610 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1612 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1614 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1616 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1618 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1620 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1622 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1624 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1626 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1628 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1630 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1632 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Italic */

/* 1634 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1636 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1640 */	NdrFcShort( 0x15 ),	/* 21 */
/* 1642 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1644 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1646 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1648 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1650 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1652 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1654 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1656 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1658 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 1660 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1662 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1664 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1666 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1668 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1670 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Italic */

/* 1672 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1674 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1678 */	NdrFcShort( 0x16 ),	/* 22 */
/* 1680 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1682 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1684 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1686 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1688 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1690 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1692 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1694 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1696 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 1698 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1700 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1702 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1704 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1706 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1708 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_LeftMargin */

/* 1710 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1712 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1716 */	NdrFcShort( 0x1a ),	/* 26 */
/* 1718 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1720 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1722 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1724 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1726 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1728 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1730 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1732 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1734 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1736 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1738 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1740 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1742 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1744 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1746 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_LineSpacing */

/* 1748 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1750 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1754 */	NdrFcShort( 0x1c ),	/* 28 */
/* 1756 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1758 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1760 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1762 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 1764 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 1766 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1768 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1770 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1772 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 1774 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1776 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1778 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1780 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1782 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1784 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Marker */

/* 1786 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1788 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1792 */	NdrFcShort( 0x1d ),	/* 29 */
/* 1794 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1796 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1798 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1800 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1802 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1804 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1806 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1808 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1810 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1812 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1814 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1816 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1818 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1820 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1822 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Marker */

/* 1824 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1826 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1830 */	NdrFcShort( 0x1e ),	/* 30 */
/* 1832 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1834 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1836 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1838 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1840 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1842 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1844 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1846 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1848 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 1850 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1852 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1854 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 1856 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1858 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1860 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Name */

/* 1862 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1864 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1868 */	NdrFcShort( 0x1f ),	/* 31 */
/* 1870 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1872 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1874 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1876 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1878 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1880 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1882 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1884 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1886 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1888 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1890 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1892 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1894 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1896 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1898 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Name */

/* 1900 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1902 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1906 */	NdrFcShort( 0x20 ),	/* 32 */
/* 1908 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1910 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1912 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1914 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1916 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1918 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1920 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1922 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1924 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 1926 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1928 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1930 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 1932 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1934 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1936 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TeStyleName */

/* 1938 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1940 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1944 */	NdrFcShort( 0x21 ),	/* 33 */
/* 1946 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1948 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1950 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1952 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 1954 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 1956 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1958 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1960 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1962 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 1964 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1966 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 1968 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 1970 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1972 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 1974 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_TeStyleName */

/* 1976 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1978 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1982 */	NdrFcShort( 0x22 ),	/* 34 */
/* 1984 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 1986 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1988 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1990 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 1992 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 1994 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1996 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1998 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2000 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 2002 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2004 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2006 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 2008 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2010 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2012 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_NotRepeatable */

/* 2014 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2016 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2020 */	NdrFcShort( 0x23 ),	/* 35 */
/* 2022 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2024 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2026 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2028 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2030 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2032 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2034 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2036 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2038 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 2040 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2042 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2044 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2046 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2048 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2050 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_NotRepeatable */

/* 2052 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2054 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2058 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2060 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2062 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2064 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2066 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2068 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2070 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2072 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2074 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2076 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 2078 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2080 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2082 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2084 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2086 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2088 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_OccursUnder */

/* 2090 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2092 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2096 */	NdrFcShort( 0x25 ),	/* 37 */
/* 2098 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2100 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2102 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2104 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 2106 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 2108 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2110 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2112 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2114 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 2116 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2118 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2120 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 2122 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2124 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2126 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_OccursUnder */

/* 2128 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2130 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2134 */	NdrFcShort( 0x26 ),	/* 38 */
/* 2136 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2138 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2140 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2142 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 2144 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 2146 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2148 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2150 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2152 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 2154 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2156 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2158 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 2160 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2162 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2164 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Rank */

/* 2166 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2168 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2172 */	NdrFcShort( 0x27 ),	/* 39 */
/* 2174 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2176 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2178 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2180 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2182 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2184 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2186 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2188 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2190 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 2192 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2194 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2196 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2198 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2200 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2202 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Rank */

/* 2204 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2206 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2210 */	NdrFcShort( 0x28 ),	/* 40 */
/* 2212 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2214 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2216 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2218 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2220 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2222 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2224 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2226 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2228 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 2230 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2232 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2234 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2236 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2238 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2240 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_RightMargin */

/* 2242 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2244 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2248 */	NdrFcShort( 0x29 ),	/* 41 */
/* 2250 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2252 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2254 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2256 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2258 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2260 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2262 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2264 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2266 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 2268 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2270 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2272 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2274 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2276 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2278 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_RightMargin */

/* 2280 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2282 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2286 */	NdrFcShort( 0x2a ),	/* 42 */
/* 2288 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2290 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2292 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2294 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2296 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2298 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2300 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2302 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2304 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 2306 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2308 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2310 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2312 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2314 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2316 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_SpaceAfter */

/* 2318 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2320 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2324 */	NdrFcShort( 0x2b ),	/* 43 */
/* 2326 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2328 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2330 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2332 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2334 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2336 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2338 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2340 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2342 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 2344 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2346 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2348 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2350 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2352 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2354 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_SpaceAfter */

/* 2356 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2358 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2362 */	NdrFcShort( 0x2c ),	/* 44 */
/* 2364 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2366 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2368 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2370 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2372 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2374 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2376 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2378 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2380 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 2382 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2384 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2386 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2388 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2390 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2392 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_SpaceBefore */

/* 2394 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2396 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2400 */	NdrFcShort( 0x2d ),	/* 45 */
/* 2402 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2404 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2406 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2408 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2410 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2412 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2414 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2416 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2418 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 2420 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2422 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2424 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2426 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2428 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2430 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_SpaceBefore */

/* 2432 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2434 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2438 */	NdrFcShort( 0x2e ),	/* 46 */
/* 2440 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2442 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2444 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2446 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2448 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2450 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2452 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2454 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2456 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 2458 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2460 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2462 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2464 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2466 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2468 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_StyleType */

/* 2470 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2472 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2476 */	NdrFcShort( 0x2f ),	/* 47 */
/* 2478 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2480 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2482 */	NdrFcShort( 0x22 ),	/* 34 */
/* 2484 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2486 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2488 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2490 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2492 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2494 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 2496 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 2498 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2500 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */

/* 2502 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2504 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2506 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_StyleType */

/* 2508 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2510 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2514 */	NdrFcShort( 0x30 ),	/* 48 */
/* 2516 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2518 */	NdrFcShort( 0x6 ),	/* 6 */
/* 2520 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2522 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2524 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2526 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2528 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2530 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2532 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 2534 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2536 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2538 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 2540 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2542 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2544 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Superscript */

/* 2546 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2548 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2552 */	NdrFcShort( 0x31 ),	/* 49 */
/* 2554 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2556 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2558 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2560 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2562 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2564 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2566 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2568 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2570 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 2572 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2574 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2576 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2578 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2580 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2582 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Superscript */

/* 2584 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2586 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2590 */	NdrFcShort( 0x32 ),	/* 50 */
/* 2592 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2594 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2596 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2598 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2600 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2602 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2604 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2606 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2608 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 2610 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2612 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2614 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2616 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2618 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2620 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Versification */


	/* Procedure get_TextProperties */

/* 2622 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2624 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2628 */	NdrFcShort( 0x33 ),	/* 51 */
/* 2630 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2632 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2634 */	NdrFcShort( 0x22 ),	/* 34 */
/* 2636 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2638 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2640 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2642 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2644 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2646 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pvVal */


	/* Parameter pVal */

/* 2648 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 2650 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2652 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */


	/* Return value */

/* 2654 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2656 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2658 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Versification */


	/* Procedure put_TextProperties */

/* 2660 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2662 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2666 */	NdrFcShort( 0x34 ),	/* 52 */
/* 2668 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2670 */	NdrFcShort( 0x6 ),	/* 6 */
/* 2672 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2674 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2676 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2678 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2680 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2682 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2684 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter vVal */


	/* Parameter newVal */

/* 2686 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2688 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2690 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 2692 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2694 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2696 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TextType */

/* 2698 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2700 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2704 */	NdrFcShort( 0x35 ),	/* 53 */
/* 2706 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2708 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2710 */	NdrFcShort( 0x22 ),	/* 34 */
/* 2712 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2714 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2716 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2718 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2720 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2722 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 2724 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 2726 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2728 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */

/* 2730 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2732 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2734 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_TextType */

/* 2736 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2738 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2742 */	NdrFcShort( 0x36 ),	/* 54 */
/* 2744 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2746 */	NdrFcShort( 0x6 ),	/* 6 */
/* 2748 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2750 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2752 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2754 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2756 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2758 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2760 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 2762 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2764 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2766 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 2768 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2770 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2772 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_AsteriskIsMarker */


	/* Procedure get_Underline */

/* 2774 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2776 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2780 */	NdrFcShort( 0x37 ),	/* 55 */
/* 2782 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2784 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2786 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2788 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2790 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2792 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2794 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2796 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2798 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */


	/* Parameter pfVal */

/* 2800 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2802 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2804 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 2806 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2808 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2810 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Underline */

/* 2812 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2814 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2818 */	NdrFcShort( 0x38 ),	/* 56 */
/* 2820 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2822 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2824 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2826 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 2828 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 2830 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2832 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2834 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2836 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 2838 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2840 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2842 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2844 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2846 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2848 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_XMLTag */

/* 2850 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2852 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2856 */	NdrFcShort( 0x39 ),	/* 57 */
/* 2858 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2860 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2862 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2864 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 2866 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 2868 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2870 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2872 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2874 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 2876 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2878 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2880 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 2882 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2884 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2886 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_XMLTag */

/* 2888 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2890 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2894 */	NdrFcShort( 0x3a ),	/* 58 */
/* 2896 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2898 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2900 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2902 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 2904 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 2906 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2908 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2910 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2912 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 2914 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2916 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2918 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 2920 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2922 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2924 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Encoding */

/* 2926 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2928 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2932 */	NdrFcShort( 0x3b ),	/* 59 */
/* 2934 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2936 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2938 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2940 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 2942 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 2944 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2946 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2948 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2950 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 2952 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2954 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2956 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 2958 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2960 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 2962 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Encoding */

/* 2964 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2966 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2970 */	NdrFcShort( 0x3c ),	/* 60 */
/* 2972 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 2974 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2976 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2978 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 2980 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 2982 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2984 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2986 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2988 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 2990 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2992 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 2994 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 2996 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2998 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3000 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_SmallCaps */

/* 3002 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3004 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3008 */	NdrFcShort( 0x3d ),	/* 61 */
/* 3010 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3012 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3014 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3016 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3018 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3020 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3022 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3024 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3026 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 3028 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3030 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3032 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3034 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3036 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3038 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_SmallCaps */

/* 3040 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3042 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3046 */	NdrFcShort( 0x3e ),	/* 62 */
/* 3048 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3050 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3052 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3054 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3056 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3058 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3060 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3062 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3064 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 3066 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3068 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3070 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3072 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3074 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3076 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Subscript */

/* 3078 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3080 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3084 */	NdrFcShort( 0x3f ),	/* 63 */
/* 3086 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3088 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3090 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3092 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3094 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3096 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3098 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3100 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3102 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 3104 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3106 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3108 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3110 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3112 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3114 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Subscript */

/* 3116 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3118 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3122 */	NdrFcShort( 0x40 ),	/* 64 */
/* 3124 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3126 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3128 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3130 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3132 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3134 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3136 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3138 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3140 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 3142 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3144 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3146 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3148 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3150 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3152 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FirstReference */

/* 3154 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3156 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3160 */	NdrFcShort( 0x7 ),	/* 7 */
/* 3162 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3164 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3166 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3168 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3170 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3172 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3174 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3176 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3178 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3180 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3182 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3184 */	NdrFcShort( 0x41a ),	/* Type Offset=1050 */

	/* Return value */

/* 3186 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3188 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3190 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FirstReference */

/* 3192 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3194 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3198 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3200 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3202 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3204 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3206 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3208 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3210 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3212 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3214 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3216 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3218 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3220 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3222 */	NdrFcShort( 0x404 ),	/* Type Offset=1028 */

	/* Return value */

/* 3224 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3226 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3228 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LastReference */

/* 3230 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3232 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3236 */	NdrFcShort( 0x9 ),	/* 9 */
/* 3238 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3240 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3242 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3244 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3246 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3248 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3250 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3252 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3254 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3256 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3258 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3260 */	NdrFcShort( 0x41a ),	/* Type Offset=1050 */

	/* Return value */

/* 3262 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3264 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3266 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_LastReference */

/* 3268 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3270 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3274 */	NdrFcShort( 0xa ),	/* 10 */
/* 3276 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3278 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3280 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3282 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3284 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3286 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3288 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3290 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3292 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3294 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3296 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3298 */	NdrFcShort( 0x404 ),	/* Type Offset=1028 */

	/* Return value */

/* 3300 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3302 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3304 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TextType */

/* 3306 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3308 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3312 */	NdrFcShort( 0xd ),	/* 13 */
/* 3314 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3316 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3318 */	NdrFcShort( 0x22 ),	/* 34 */
/* 3320 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3322 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3324 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3326 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3328 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3330 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3332 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 3334 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3336 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */

/* 3338 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3340 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3342 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_TextType */

/* 3344 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3346 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3350 */	NdrFcShort( 0xe ),	/* 14 */
/* 3352 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3354 */	NdrFcShort( 0x6 ),	/* 6 */
/* 3356 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3358 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3360 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3362 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3364 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3366 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3368 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3370 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3372 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3374 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 3376 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3378 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3380 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TextProperties */

/* 3382 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3384 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3388 */	NdrFcShort( 0xf ),	/* 15 */
/* 3390 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3392 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3394 */	NdrFcShort( 0x22 ),	/* 34 */
/* 3396 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3398 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3400 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3402 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3404 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3406 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3408 */	NdrFcShort( 0x2010 ),	/* Flags:  out, srv alloc size=8 */
/* 3410 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3412 */	NdrFcShort( 0x3c ),	/* Type Offset=60 */

	/* Return value */

/* 3414 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3416 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3418 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_TextProperties */

/* 3420 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3422 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3426 */	NdrFcShort( 0x10 ),	/* 16 */
/* 3428 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3430 */	NdrFcShort( 0x6 ),	/* 6 */
/* 3432 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3434 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 3436 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3438 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3440 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3442 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3444 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3446 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3448 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3450 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Return value */

/* 3452 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3454 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3456 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Tag */

/* 3458 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3460 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3464 */	NdrFcShort( 0x11 ),	/* 17 */
/* 3466 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3468 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3470 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3472 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3474 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3476 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3478 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3480 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3482 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3484 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3486 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3488 */	NdrFcShort( 0x41e ),	/* Type Offset=1054 */

	/* Return value */

/* 3490 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3492 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3494 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Tag */

/* 3496 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3498 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3502 */	NdrFcShort( 0x12 ),	/* 18 */
/* 3504 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3506 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3508 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3510 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3512 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3514 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3516 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3518 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3520 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter newVal */

/* 3522 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3524 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3526 */	NdrFcShort( 0x422 ),	/* Type Offset=1058 */

	/* Return value */

/* 3528 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3530 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3532 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Clone */

/* 3534 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3536 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3540 */	NdrFcShort( 0x13 ),	/* 19 */
/* 3542 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3544 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3546 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3548 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3550 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3552 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3554 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3556 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3558 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter ppTextSegment */

/* 3560 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3562 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3564 */	NdrFcShort( 0x434 ),	/* Type Offset=1076 */

	/* Return value */

/* 3566 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3568 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3570 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NextToken */


	/* Procedure NextToken */

/* 3572 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3574 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3578 */	NdrFcShort( 0x7 ),	/* 7 */
/* 3580 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 3582 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3584 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3586 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 3588 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3590 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3592 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3594 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3596 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piTagIndex */


	/* Parameter piTagIndex */

/* 3598 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3600 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3602 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstr */


	/* Parameter pbstr */

/* 3604 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3606 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3608 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */


	/* Return value */

/* 3610 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3612 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3614 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Next */

/* 3616 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3618 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3622 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3624 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 3626 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3628 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3630 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 3632 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3634 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3636 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3638 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3640 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3642 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3644 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3646 */	NdrFcShort( 0x438 ),	/* Type Offset=1080 */

	/* Parameter fVal */

/* 3648 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3650 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3652 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3654 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3656 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3658 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Update */

/* 3660 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3662 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3666 */	NdrFcShort( 0x9 ),	/* 9 */
/* 3668 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3670 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3672 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3674 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3676 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3678 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3680 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3682 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3684 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pVal */

/* 3686 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3688 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3690 */	NdrFcShort( 0x438 ),	/* Type Offset=1080 */

	/* Return value */

/* 3692 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3694 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3696 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure SetText */

/* 3698 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3700 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3704 */	NdrFcShort( 0xa ),	/* 10 */
/* 3706 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 3708 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3710 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3712 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x4,		/* 4 */
/* 3714 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 3716 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3718 */	NdrFcShort( 0x2 ),	/* 2 */
/* 3720 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3722 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrText */

/* 3724 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3726 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3728 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter pscr */

/* 3730 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3732 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3734 */	NdrFcShort( 0x44a ),	/* Type Offset=1098 */

	/* Parameter bstrComment */

/* 3736 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3738 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3740 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 3742 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3744 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 3746 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Next */

/* 3748 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3750 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3754 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3756 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 3758 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3760 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3762 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x4,		/* 4 */
/* 3764 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3766 */	NdrFcShort( 0x2 ),	/* 2 */
/* 3768 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3770 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3772 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 3774 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3776 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3778 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter pSCReference */

/* 3780 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3782 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3784 */	NdrFcShort( 0x45c ),	/* Type Offset=1116 */

	/* Parameter pxbstr */

/* 3786 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3788 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3790 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 3792 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3794 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 3796 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TextsPresent */

/* 3798 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3800 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3804 */	NdrFcShort( 0x7 ),	/* 7 */
/* 3806 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3808 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3810 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3812 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 3814 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3816 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3818 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3820 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3822 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 3824 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 3826 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3828 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 3830 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3832 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3834 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Load */

/* 3836 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3838 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3842 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3844 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3846 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3848 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3850 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3852 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 3854 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3856 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3858 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3860 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrFileName */

/* 3862 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3864 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3866 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 3868 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3870 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3872 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure AddFile */


	/* Procedure Save */

/* 3874 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3876 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3880 */	NdrFcShort( 0x9 ),	/* 9 */
/* 3882 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3884 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3886 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3888 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 3890 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 3892 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3894 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3896 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3898 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrFileName */


	/* Parameter bstrFileName */

/* 3900 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3902 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3904 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */


	/* Return value */

/* 3906 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3908 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3910 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure TextEnum */

/* 3912 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3914 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3918 */	NdrFcShort( 0xa ),	/* 10 */
/* 3920 */	NdrFcShort( 0x38 ),	/* ia64 Stack size/offset = 56 */
/* 3922 */	NdrFcShort( 0xc ),	/* 12 */
/* 3924 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3926 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 3928 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 3930 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3932 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3934 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3936 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReferenceFirst */

/* 3938 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3940 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 3942 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter pSCReferenceLast */

/* 3944 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 3946 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 3948 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter sttFilter */

/* 3950 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3952 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 3954 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Parameter stpSmushing */

/* 3956 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3958 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 3960 */	0xd,		/* FC_ENUM16 */
			0x0,		/* 0 */

	/* Parameter ppTextEnum */

/* 3962 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 3964 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 3966 */	NdrFcShort( 0x472 ),	/* Type Offset=1138 */

	/* Return value */

/* 3968 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3970 */	NdrFcShort( 0x30 ),	/* ia64 Stack size/offset = 48 */
/* 3972 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetText */

/* 3974 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 3976 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3980 */	NdrFcShort( 0xb ),	/* 11 */
/* 3982 */	NdrFcShort( 0x30 ),	/* ia64 Stack size/offset = 48 */
/* 3984 */	NdrFcShort( 0x10 ),	/* 16 */
/* 3986 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3988 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 3990 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 3992 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3994 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3996 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3998 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReferenceFirstChapter */

/* 4000 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 4002 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4004 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter fSingleChapter */

/* 4006 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4008 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4010 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter fDoMapin */

/* 4012 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4014 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4016 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstrText */

/* 4018 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4020 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 4022 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4024 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4026 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 4028 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure PutText */

/* 4030 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4032 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4036 */	NdrFcShort( 0xc ),	/* 12 */
/* 4038 */	NdrFcShort( 0x30 ),	/* ia64 Stack size/offset = 48 */
/* 4040 */	NdrFcShort( 0x10 ),	/* 16 */
/* 4042 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4044 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 4046 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4048 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4050 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4052 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4054 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReferenceFirstChapter */

/* 4056 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 4058 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4060 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter fSingleChapter */

/* 4062 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4064 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4066 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter fDoMapout */

/* 4068 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4070 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4072 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter bstrText */

/* 4074 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4076 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 4078 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4080 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4082 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 4084 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure FileName */

/* 4086 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4088 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4092 */	NdrFcShort( 0xd ),	/* 13 */
/* 4094 */	NdrFcShort( 0x38 ),	/* ia64 Stack size/offset = 56 */
/* 4096 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4098 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4100 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 4102 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4104 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4106 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4108 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4110 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReference */

/* 4112 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 4114 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4116 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter pSCReferenceFirst */

/* 4118 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 4120 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4122 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter pSCReferenceLast */

/* 4124 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 4126 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4128 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter fAlwaysReturnName */

/* 4130 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4132 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 4134 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter bstrFileName */

/* 4136 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4138 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 4140 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4142 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4144 */	NdrFcShort( 0x30 ),	/* ia64 Stack size/offset = 48 */
/* 4146 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NthFileName */

/* 4148 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4150 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4154 */	NdrFcShort( 0xe ),	/* 14 */
/* 4156 */	NdrFcShort( 0x30 ),	/* ia64 Stack size/offset = 48 */
/* 4158 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4160 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4162 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 4164 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4166 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4168 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4170 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4172 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iFileNumber */

/* 4174 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4176 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4178 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pSCReferenceFirst */

/* 4180 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 4182 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4184 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter pSCReferenceLast */

/* 4186 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 4188 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4190 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter bstrFileName */

/* 4192 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4194 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 4196 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4198 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4200 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 4202 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NthTag */

/* 4204 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4206 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4210 */	NdrFcShort( 0xf ),	/* 15 */
/* 4212 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 4214 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4216 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4218 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 4220 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4222 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4224 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4226 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4228 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iTagNumber */

/* 4230 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4232 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4234 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter ppTag */

/* 4236 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 4238 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4240 */	NdrFcShort( 0x488 ),	/* Type Offset=1160 */

	/* Return value */

/* 4242 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4244 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4246 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure TagIndex */

/* 4248 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4250 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4254 */	NdrFcShort( 0x10 ),	/* 16 */
/* 4256 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 4258 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4260 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4262 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 4264 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4266 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4268 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4270 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4272 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrTagName */

/* 4274 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4276 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4278 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter piNth */

/* 4280 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4282 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4284 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4286 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4288 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4290 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure CharToWChar */

/* 4292 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4294 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4298 */	NdrFcShort( 0x11 ),	/* 17 */
/* 4300 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 4302 */	NdrFcShort( 0x19 ),	/* 25 */
/* 4304 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4306 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 4308 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4310 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4312 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4314 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4316 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pszIn */

/* 4318 */	NdrFcShort( 0x148 ),	/* Flags:  in, base type, simple ref, */
/* 4320 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4322 */	0x2,		/* FC_CHAR */
			0x0,		/* 0 */

	/* Parameter pbstr */

/* 4324 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4326 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4328 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4330 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4332 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4334 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetParameterValue */

/* 4336 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4338 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4342 */	NdrFcShort( 0x12 ),	/* 18 */
/* 4344 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 4346 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4348 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4350 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 4352 */	0xa,		/* 10 */
			0x7,		/* Ext Flags:  new corr desc, clt corr check, srv corr check, */
/* 4354 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4356 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4358 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4360 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrName */

/* 4362 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4364 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4366 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter pbstrValue */

/* 4368 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4370 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4372 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4374 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4376 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4378 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure SetParameterValue */

/* 4380 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4382 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4386 */	NdrFcShort( 0x13 ),	/* 19 */
/* 4388 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 4390 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4392 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4394 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 4396 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4398 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4400 */	NdrFcShort( 0x2 ),	/* 2 */
/* 4402 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4404 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrName */

/* 4406 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4408 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4410 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter bstrValue */

/* 4412 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4414 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4416 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4418 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4420 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4422 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_BooksPresent */

/* 4424 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4426 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4430 */	NdrFcShort( 0x14 ),	/* 20 */
/* 4432 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4434 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4436 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4438 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4440 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4442 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4444 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4446 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4448 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4450 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4452 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4454 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4456 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4458 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4460 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_BooksPresent */

/* 4462 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4464 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4468 */	NdrFcShort( 0x15 ),	/* 21 */
/* 4470 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4472 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4474 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4476 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4478 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4480 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4482 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4484 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4486 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4488 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4490 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4492 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4494 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4496 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4498 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_CodePage */

/* 4500 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4502 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4506 */	NdrFcShort( 0x16 ),	/* 22 */
/* 4508 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4510 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4512 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4514 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4516 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4518 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4520 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4522 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4524 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piCodePage */

/* 4526 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4528 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4530 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4532 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4534 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4536 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_CodePage */

/* 4538 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4540 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4544 */	NdrFcShort( 0x17 ),	/* 23 */
/* 4546 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4548 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4550 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4552 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4554 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4556 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4558 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4560 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4562 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iCodePage */

/* 4564 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4566 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4568 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4570 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4572 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4574 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_DefaultFont */

/* 4576 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4578 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4582 */	NdrFcShort( 0x18 ),	/* 24 */
/* 4584 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4586 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4588 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4590 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4592 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4594 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4596 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4598 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4600 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4602 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4604 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4606 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4608 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4610 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4612 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_DefaultFont */

/* 4614 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4616 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4620 */	NdrFcShort( 0x19 ),	/* 25 */
/* 4622 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4624 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4626 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4628 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4630 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4632 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4634 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4636 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4638 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4640 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4642 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4644 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4646 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4648 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4650 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_DefaultFontSize */

/* 4652 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4654 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4658 */	NdrFcShort( 0x1a ),	/* 26 */
/* 4660 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4662 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4664 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4666 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4668 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4670 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4672 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4674 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4676 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter piVal */

/* 4678 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4680 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4682 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4684 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4686 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4688 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_DefaultFontSize */

/* 4690 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4692 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4696 */	NdrFcShort( 0x1b ),	/* 27 */
/* 4698 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4700 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4702 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4704 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4706 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4708 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4710 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4712 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4714 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iVal */

/* 4716 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4718 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4720 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4722 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4724 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4726 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Directory */

/* 4728 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4730 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4734 */	NdrFcShort( 0x1c ),	/* 28 */
/* 4736 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4738 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4740 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4742 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4744 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4746 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4748 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4750 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4752 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4754 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4756 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4758 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4760 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4762 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4764 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Directory */

/* 4766 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4768 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4772 */	NdrFcShort( 0x1d ),	/* 29 */
/* 4774 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4776 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4778 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4780 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4782 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4784 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4786 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4788 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4790 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4792 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4794 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4796 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4798 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4800 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4802 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Editable */

/* 4804 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4806 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4810 */	NdrFcShort( 0x1e ),	/* 30 */
/* 4812 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4814 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4816 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4818 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4820 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4822 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4824 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4826 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4828 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 4830 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4832 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4834 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4836 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4838 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4840 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Editable */

/* 4842 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4844 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4848 */	NdrFcShort( 0x1f ),	/* 31 */
/* 4850 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4852 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4854 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4856 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 4858 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 4860 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4862 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4864 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4866 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 4868 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4870 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4872 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4874 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4876 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4878 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FileNameForm */

/* 4880 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4882 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4886 */	NdrFcShort( 0x20 ),	/* 32 */
/* 4888 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4890 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4892 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4894 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4896 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4898 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4900 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4902 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4904 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4906 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4908 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4910 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4912 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4914 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4916 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FileNameForm */

/* 4918 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4920 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4924 */	NdrFcShort( 0x21 ),	/* 33 */
/* 4926 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4928 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4930 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4932 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 4934 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 4936 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4938 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4940 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4942 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 4944 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4946 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4948 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 4950 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4952 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4954 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FileNamePostPart */

/* 4956 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4958 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4962 */	NdrFcShort( 0x22 ),	/* 34 */
/* 4964 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 4966 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4968 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4970 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 4972 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 4974 */	NdrFcShort( 0x1 ),	/* 1 */
/* 4976 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4978 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4980 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 4982 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4984 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 4986 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 4988 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4990 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 4992 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FileNamePostPart */

/* 4994 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 4996 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5000 */	NdrFcShort( 0x23 ),	/* 35 */
/* 5002 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5004 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5006 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5008 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5010 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5012 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5014 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5016 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5018 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5020 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5022 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5024 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5026 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5028 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5030 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FileNamePrePart */

/* 5032 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5034 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5038 */	NdrFcShort( 0x24 ),	/* 36 */
/* 5040 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5042 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5044 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5046 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5048 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5050 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5052 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5054 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5056 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5058 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5060 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5062 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5064 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5066 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5068 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FileNamePrePart */

/* 5070 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5072 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5076 */	NdrFcShort( 0x25 ),	/* 37 */
/* 5078 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5080 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5082 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5084 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5086 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5088 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5090 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5092 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5094 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5096 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5098 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5100 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5102 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5104 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5106 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FileNameChapterNumberForm */

/* 5108 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5110 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5114 */	NdrFcShort( 0x26 ),	/* 38 */
/* 5116 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5118 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5120 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5122 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5124 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5126 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5128 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5130 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5132 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5134 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5136 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5138 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5140 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5142 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5144 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FileNameChapterNumberForm */

/* 5146 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5148 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5152 */	NdrFcShort( 0x27 ),	/* 39 */
/* 5154 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5156 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5158 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5160 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5162 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5164 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5166 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5168 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5170 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5172 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5174 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5176 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5178 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5180 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5182 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_FullName */

/* 5184 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5186 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5190 */	NdrFcShort( 0x28 ),	/* 40 */
/* 5192 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5194 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5196 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5198 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5200 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5202 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5204 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5206 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5208 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5210 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5212 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5214 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5216 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5218 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5220 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_FullName */

/* 5222 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5224 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5228 */	NdrFcShort( 0x29 ),	/* 41 */
/* 5230 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5232 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5234 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5236 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5238 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5240 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5242 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5244 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5246 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5248 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5250 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5252 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5254 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5256 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5258 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Language */

/* 5260 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5262 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5266 */	NdrFcShort( 0x2a ),	/* 42 */
/* 5268 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5270 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5272 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5274 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5276 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5278 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5280 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5282 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5284 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5286 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5288 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5290 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5292 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5294 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5296 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Language */

/* 5298 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5300 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5304 */	NdrFcShort( 0x2b ),	/* 43 */
/* 5306 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5308 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5310 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5312 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5314 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5316 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5318 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5320 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5322 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5324 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5326 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5328 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5330 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5332 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5334 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_LeftToRight */

/* 5336 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5338 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5342 */	NdrFcShort( 0x2c ),	/* 44 */
/* 5344 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5346 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5348 */	NdrFcShort( 0x24 ),	/* 36 */
/* 5350 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 5352 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 5354 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5356 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5358 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5360 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pfVal */

/* 5362 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 5364 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5366 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 5368 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5370 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5372 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_LeftToRight */

/* 5374 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5376 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5380 */	NdrFcShort( 0x2d ),	/* 45 */
/* 5382 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5384 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5386 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5388 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 5390 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 5392 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5394 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5396 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5398 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter fVal */

/* 5400 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 5402 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5404 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 5406 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5408 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5410 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Name */

/* 5412 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5414 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5418 */	NdrFcShort( 0x2e ),	/* 46 */
/* 5420 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5422 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5424 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5426 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5428 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5430 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5432 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5434 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5436 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5438 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5440 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5442 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5444 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5446 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5448 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Name */

/* 5450 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5452 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5456 */	NdrFcShort( 0x2f ),	/* 47 */
/* 5458 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5460 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5462 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5464 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5466 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5468 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5470 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5472 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5474 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5476 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5478 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5480 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5482 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5484 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5486 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_SettingsDirectory */

/* 5488 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5490 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5494 */	NdrFcShort( 0x30 ),	/* 48 */
/* 5496 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5498 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5500 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5502 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5504 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5506 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5508 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5510 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5512 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5514 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5516 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5518 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5520 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5522 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5524 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_StyleSheet */

/* 5526 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5528 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5532 */	NdrFcShort( 0x31 ),	/* 49 */
/* 5534 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5536 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5538 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5540 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5542 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5544 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5546 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5548 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5550 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstr */

/* 5552 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5554 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5556 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5558 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5560 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5562 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_StyleSheet */

/* 5564 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5566 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5570 */	NdrFcShort( 0x32 ),	/* 50 */
/* 5572 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5574 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5576 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5578 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5580 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5582 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5584 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5586 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5588 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstr */

/* 5590 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5592 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5594 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5596 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5598 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5600 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Encoding */

/* 5602 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5604 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5608 */	NdrFcShort( 0x35 ),	/* 53 */
/* 5610 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5612 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5614 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5616 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5618 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5620 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5622 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5624 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5626 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstrEncoding */

/* 5628 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5630 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5632 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5634 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5636 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5638 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Encoding */

/* 5640 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5642 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5646 */	NdrFcShort( 0x36 ),	/* 54 */
/* 5648 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5650 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5652 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5654 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5656 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5658 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5660 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5662 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5664 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrEncoding */

/* 5666 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5668 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5670 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5672 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5674 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5676 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure TextEnumEx */

/* 5678 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5680 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5684 */	NdrFcShort( 0x38 ),	/* 56 */
/* 5686 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 5688 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5690 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5692 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x4,		/* 4 */
/* 5694 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 5696 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5698 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5700 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5702 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSCReferenceFirst */

/* 5704 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 5706 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5708 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter pSCReferenceLast */

/* 5710 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 5712 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5714 */	NdrFcShort( 0x460 ),	/* Type Offset=1120 */

	/* Parameter ppTextEnumEx */

/* 5716 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 5718 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5720 */	NdrFcShort( 0x4a2 ),	/* Type Offset=1186 */

	/* Return value */

/* 5722 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5724 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 5726 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure LoadECObjectDataForSOReading */

/* 5728 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5730 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5734 */	NdrFcShort( 0x39 ),	/* 57 */
/* 5736 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 5738 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5740 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5742 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5744 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5746 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5748 */	NdrFcShort( 0x20 ),	/* 32 */
/* 5750 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5752 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSafeArrayOfBytes */

/* 5754 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5756 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5758 */	NdrFcShort( 0x4bc ),	/* Type Offset=1212 */

	/* Return value */

/* 5760 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5762 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 5764 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Initialize */

/* 5766 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5768 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5772 */	NdrFcShort( 0x7 ),	/* 7 */
/* 5774 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5776 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5778 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5780 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5782 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5784 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5786 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5788 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5790 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrBlob */

/* 5792 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5794 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5796 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5798 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5800 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5802 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Save */

/* 5804 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5806 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5810 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5812 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 5814 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5816 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5818 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 5820 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5822 */	NdrFcShort( 0x2 ),	/* 2 */
/* 5824 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5826 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5828 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrBlob */

/* 5830 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5832 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5834 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter bstrToken */

/* 5836 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5838 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5840 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5842 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5844 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5846 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure RemoveFile */

/* 5848 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5850 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5854 */	NdrFcShort( 0xa ),	/* 10 */
/* 5856 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5858 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5860 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5862 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5864 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5866 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5868 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5870 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5872 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrFileName */

/* 5874 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5876 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5878 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5880 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5882 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5884 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Files */

/* 5886 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5888 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5892 */	NdrFcShort( 0xb ),	/* 11 */
/* 5894 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5896 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5898 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5900 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5902 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5904 */	NdrFcShort( 0x20 ),	/* 32 */
/* 5906 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5908 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5910 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pSafeArray */

/* 5912 */	NdrFcShort( 0x6113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=24 */
/* 5914 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5916 */	NdrFcShort( 0x3fa ),	/* Type Offset=1018 */

	/* Return value */

/* 5918 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5920 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5922 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_BookMarker */

/* 5924 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5926 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5930 */	NdrFcShort( 0xc ),	/* 12 */
/* 5932 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5934 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5936 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5938 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 5940 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 5942 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5944 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5946 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5948 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrBookMarker */

/* 5950 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 5952 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5954 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Return value */

/* 5956 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5958 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5960 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_BookMarker */

/* 5962 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 5964 */	NdrFcLong( 0x0 ),	/* 0 */
/* 5968 */	NdrFcShort( 0xd ),	/* 13 */
/* 5970 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 5972 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5974 */	NdrFcShort( 0x8 ),	/* 8 */
/* 5976 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 5978 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 5980 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5982 */	NdrFcShort( 0x1 ),	/* 1 */
/* 5984 */	NdrFcShort( 0x0 ),	/* 0 */
/* 5986 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrBookMarker */

/* 5988 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 5990 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 5992 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 5994 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 5996 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 5998 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure NthMapping */

/* 6000 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 6002 */	NdrFcLong( 0x0 ),	/* 0 */
/* 6006 */	NdrFcShort( 0xe ),	/* 14 */
/* 6008 */	NdrFcShort( 0x40 ),	/* ia64 Stack size/offset = 64 */
/* 6010 */	NdrFcShort( 0x8 ),	/* 8 */
/* 6012 */	NdrFcShort( 0x40 ),	/* 64 */
/* 6014 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x7,		/* 7 */
/* 6016 */	0xa,		/* 10 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 6018 */	NdrFcShort( 0x3 ),	/* 3 */
/* 6020 */	NdrFcShort( 0x0 ),	/* 0 */
/* 6022 */	NdrFcShort( 0x0 ),	/* 0 */
/* 6024 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter iIndex */

/* 6026 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 6028 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 6030 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstrMarker */

/* 6032 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 6034 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 6036 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter piDomain */

/* 6038 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 6040 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 6042 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstrTeStyleName */

/* 6044 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 6046 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 6048 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter pbstrEncoding */

/* 6050 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 6052 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 6054 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */

	/* Parameter bConfirmed */

/* 6056 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 6058 */	NdrFcShort( 0x30 ),	/* ia64 Stack size/offset = 48 */
/* 6060 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 6062 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 6064 */	NdrFcShort( 0x38 ),	/* ia64 Stack size/offset = 56 */
/* 6066 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure SetMapping */

/* 6068 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 6070 */	NdrFcLong( 0x0 ),	/* 0 */
/* 6074 */	NdrFcShort( 0xf ),	/* 15 */
/* 6076 */	NdrFcShort( 0x30 ),	/* ia64 Stack size/offset = 48 */
/* 6078 */	NdrFcShort( 0x8 ),	/* 8 */
/* 6080 */	NdrFcShort( 0x8 ),	/* 8 */
/* 6082 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 6084 */	0xa,		/* 10 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 6086 */	NdrFcShort( 0x0 ),	/* 0 */
/* 6088 */	NdrFcShort( 0x3 ),	/* 3 */
/* 6090 */	NdrFcShort( 0x0 ),	/* 0 */
/* 6092 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter pbstrMarker */

/* 6094 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 6096 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 6098 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter piDomain */

/* 6100 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 6102 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 6104 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pbstrTeStyleName */

/* 6106 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 6108 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 6110 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter pbstrEncoding */

/* 6112 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 6114 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 6116 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 6118 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 6120 */	NdrFcShort( 0x28 ),	/* ia64 Stack size/offset = 40 */
/* 6122 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetBooksForFile */

/* 6124 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 6126 */	NdrFcLong( 0x0 ),	/* 0 */
/* 6130 */	NdrFcShort( 0x10 ),	/* 16 */
/* 6132 */	NdrFcShort( 0x20 ),	/* ia64 Stack size/offset = 32 */
/* 6134 */	NdrFcShort( 0x0 ),	/* 0 */
/* 6136 */	NdrFcShort( 0x8 ),	/* 8 */
/* 6138 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 6140 */	0xa,		/* 10 */
			0x7,		/* Ext Flags:  new corr desc, clt corr check, srv corr check, */
/* 6142 */	NdrFcShort( 0x20 ),	/* 32 */
/* 6144 */	NdrFcShort( 0x1 ),	/* 1 */
/* 6146 */	NdrFcShort( 0x0 ),	/* 0 */
/* 6148 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter bstrFileName */

/* 6150 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 6152 */	NdrFcShort( 0x8 ),	/* ia64 Stack size/offset = 8 */
/* 6154 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Parameter pSafeArray */

/* 6156 */	NdrFcShort( 0x6113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=24 */
/* 6158 */	NdrFcShort( 0x10 ),	/* ia64 Stack size/offset = 16 */
/* 6160 */	NdrFcShort( 0x3fa ),	/* Type Offset=1018 */

	/* Return value */

/* 6162 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 6164 */	NdrFcShort( 0x18 ),	/* ia64 Stack size/offset = 24 */
/* 6166 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/*  4 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/*  6 */	
			0x12, 0x0,	/* FC_UP */
/*  8 */	NdrFcShort( 0xe ),	/* Offset= 14 (22) */
/* 10 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 12 */	NdrFcShort( 0x2 ),	/* 2 */
/* 14 */	0x9,		/* Corr desc: FC_ULONG */
			0x0,		/*  */
/* 16 */	NdrFcShort( 0xfffc ),	/* -4 */
/* 18 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 20 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 22 */	
			0x17,		/* FC_CSTRUCT */
			0x3,		/* 3 */
/* 24 */	NdrFcShort( 0x8 ),	/* 8 */
/* 26 */	NdrFcShort( 0xfff0 ),	/* Offset= -16 (10) */
/* 28 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 30 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 32 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 34 */	NdrFcShort( 0x0 ),	/* 0 */
/* 36 */	NdrFcShort( 0x8 ),	/* 8 */
/* 38 */	NdrFcShort( 0x0 ),	/* 0 */
/* 40 */	NdrFcShort( 0xffde ),	/* Offset= -34 (6) */
/* 42 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 44 */	NdrFcShort( 0x6 ),	/* Offset= 6 (50) */
/* 46 */	
			0x13, 0x0,	/* FC_OP */
/* 48 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (22) */
/* 50 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 52 */	NdrFcShort( 0x0 ),	/* 0 */
/* 54 */	NdrFcShort( 0x8 ),	/* 8 */
/* 56 */	NdrFcShort( 0x0 ),	/* 0 */
/* 58 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (46) */
/* 60 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 62 */	0xd,		/* FC_ENUM16 */
			0x5c,		/* FC_PAD */
/* 64 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 66 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 68 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 70 */	NdrFcShort( 0x3b4 ),	/* Offset= 948 (1018) */
/* 72 */	
			0x13, 0x0,	/* FC_OP */
/* 74 */	NdrFcShort( 0x39c ),	/* Offset= 924 (998) */
/* 76 */	
			0x2b,		/* FC_NON_ENCAPSULATED_UNION */
			0x9,		/* FC_ULONG */
/* 78 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 80 */	NdrFcShort( 0xfff8 ),	/* -8 */
/* 82 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 84 */	NdrFcShort( 0x2 ),	/* Offset= 2 (86) */
/* 86 */	NdrFcShort( 0x10 ),	/* 16 */
/* 88 */	NdrFcShort( 0x2f ),	/* 47 */
/* 90 */	NdrFcLong( 0x14 ),	/* 20 */
/* 94 */	NdrFcShort( 0x800b ),	/* Simple arm type: FC_HYPER */
/* 96 */	NdrFcLong( 0x3 ),	/* 3 */
/* 100 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 102 */	NdrFcLong( 0x11 ),	/* 17 */
/* 106 */	NdrFcShort( 0x8001 ),	/* Simple arm type: FC_BYTE */
/* 108 */	NdrFcLong( 0x2 ),	/* 2 */
/* 112 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 114 */	NdrFcLong( 0x4 ),	/* 4 */
/* 118 */	NdrFcShort( 0x800a ),	/* Simple arm type: FC_FLOAT */
/* 120 */	NdrFcLong( 0x5 ),	/* 5 */
/* 124 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 126 */	NdrFcLong( 0xb ),	/* 11 */
/* 130 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 132 */	NdrFcLong( 0xa ),	/* 10 */
/* 136 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 138 */	NdrFcLong( 0x6 ),	/* 6 */
/* 142 */	NdrFcShort( 0xe8 ),	/* Offset= 232 (374) */
/* 144 */	NdrFcLong( 0x7 ),	/* 7 */
/* 148 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 150 */	NdrFcLong( 0x8 ),	/* 8 */
/* 154 */	NdrFcShort( 0xff94 ),	/* Offset= -108 (46) */
/* 156 */	NdrFcLong( 0xd ),	/* 13 */
/* 160 */	NdrFcShort( 0xdc ),	/* Offset= 220 (380) */
/* 162 */	NdrFcLong( 0x9 ),	/* 9 */
/* 166 */	NdrFcShort( 0xe8 ),	/* Offset= 232 (398) */
/* 168 */	NdrFcLong( 0x2000 ),	/* 8192 */
/* 172 */	NdrFcShort( 0xf4 ),	/* Offset= 244 (416) */
/* 174 */	NdrFcLong( 0x24 ),	/* 36 */
/* 178 */	NdrFcShort( 0x2ea ),	/* Offset= 746 (924) */
/* 180 */	NdrFcLong( 0x4024 ),	/* 16420 */
/* 184 */	NdrFcShort( 0x2e4 ),	/* Offset= 740 (924) */
/* 186 */	NdrFcLong( 0x4011 ),	/* 16401 */
/* 190 */	NdrFcShort( 0x2e2 ),	/* Offset= 738 (928) */
/* 192 */	NdrFcLong( 0x4002 ),	/* 16386 */
/* 196 */	NdrFcShort( 0x2e0 ),	/* Offset= 736 (932) */
/* 198 */	NdrFcLong( 0x4003 ),	/* 16387 */
/* 202 */	NdrFcShort( 0x2de ),	/* Offset= 734 (936) */
/* 204 */	NdrFcLong( 0x4014 ),	/* 16404 */
/* 208 */	NdrFcShort( 0x2dc ),	/* Offset= 732 (940) */
/* 210 */	NdrFcLong( 0x4004 ),	/* 16388 */
/* 214 */	NdrFcShort( 0x2da ),	/* Offset= 730 (944) */
/* 216 */	NdrFcLong( 0x4005 ),	/* 16389 */
/* 220 */	NdrFcShort( 0x2d8 ),	/* Offset= 728 (948) */
/* 222 */	NdrFcLong( 0x400b ),	/* 16395 */
/* 226 */	NdrFcShort( 0x2c2 ),	/* Offset= 706 (932) */
/* 228 */	NdrFcLong( 0x400a ),	/* 16394 */
/* 232 */	NdrFcShort( 0x2c0 ),	/* Offset= 704 (936) */
/* 234 */	NdrFcLong( 0x4006 ),	/* 16390 */
/* 238 */	NdrFcShort( 0x2ca ),	/* Offset= 714 (952) */
/* 240 */	NdrFcLong( 0x4007 ),	/* 16391 */
/* 244 */	NdrFcShort( 0x2c0 ),	/* Offset= 704 (948) */
/* 246 */	NdrFcLong( 0x4008 ),	/* 16392 */
/* 250 */	NdrFcShort( 0x2c2 ),	/* Offset= 706 (956) */
/* 252 */	NdrFcLong( 0x400d ),	/* 16397 */
/* 256 */	NdrFcShort( 0x2c0 ),	/* Offset= 704 (960) */
/* 258 */	NdrFcLong( 0x4009 ),	/* 16393 */
/* 262 */	NdrFcShort( 0x2be ),	/* Offset= 702 (964) */
/* 264 */	NdrFcLong( 0x6000 ),	/* 24576 */
/* 268 */	NdrFcShort( 0x2bc ),	/* Offset= 700 (968) */
/* 270 */	NdrFcLong( 0x400c ),	/* 16396 */
/* 274 */	NdrFcShort( 0x2ba ),	/* Offset= 698 (972) */
/* 276 */	NdrFcLong( 0x10 ),	/* 16 */
/* 280 */	NdrFcShort( 0x8002 ),	/* Simple arm type: FC_CHAR */
/* 282 */	NdrFcLong( 0x12 ),	/* 18 */
/* 286 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 288 */	NdrFcLong( 0x13 ),	/* 19 */
/* 292 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 294 */	NdrFcLong( 0x15 ),	/* 21 */
/* 298 */	NdrFcShort( 0x800b ),	/* Simple arm type: FC_HYPER */
/* 300 */	NdrFcLong( 0x16 ),	/* 22 */
/* 304 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 306 */	NdrFcLong( 0x17 ),	/* 23 */
/* 310 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 312 */	NdrFcLong( 0xe ),	/* 14 */
/* 316 */	NdrFcShort( 0x298 ),	/* Offset= 664 (980) */
/* 318 */	NdrFcLong( 0x400e ),	/* 16398 */
/* 322 */	NdrFcShort( 0x29c ),	/* Offset= 668 (990) */
/* 324 */	NdrFcLong( 0x4010 ),	/* 16400 */
/* 328 */	NdrFcShort( 0x29a ),	/* Offset= 666 (994) */
/* 330 */	NdrFcLong( 0x4012 ),	/* 16402 */
/* 334 */	NdrFcShort( 0x256 ),	/* Offset= 598 (932) */
/* 336 */	NdrFcLong( 0x4013 ),	/* 16403 */
/* 340 */	NdrFcShort( 0x254 ),	/* Offset= 596 (936) */
/* 342 */	NdrFcLong( 0x4015 ),	/* 16405 */
/* 346 */	NdrFcShort( 0x252 ),	/* Offset= 594 (940) */
/* 348 */	NdrFcLong( 0x4016 ),	/* 16406 */
/* 352 */	NdrFcShort( 0x248 ),	/* Offset= 584 (936) */
/* 354 */	NdrFcLong( 0x4017 ),	/* 16407 */
/* 358 */	NdrFcShort( 0x242 ),	/* Offset= 578 (936) */
/* 360 */	NdrFcLong( 0x0 ),	/* 0 */
/* 364 */	NdrFcShort( 0x0 ),	/* Offset= 0 (364) */
/* 366 */	NdrFcLong( 0x1 ),	/* 1 */
/* 370 */	NdrFcShort( 0x0 ),	/* Offset= 0 (370) */
/* 372 */	NdrFcShort( 0xffff ),	/* Offset= -1 (371) */
/* 374 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 376 */	NdrFcShort( 0x8 ),	/* 8 */
/* 378 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 380 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 382 */	NdrFcLong( 0x0 ),	/* 0 */
/* 386 */	NdrFcShort( 0x0 ),	/* 0 */
/* 388 */	NdrFcShort( 0x0 ),	/* 0 */
/* 390 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 392 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 394 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 396 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 398 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 400 */	NdrFcLong( 0x20400 ),	/* 132096 */
/* 404 */	NdrFcShort( 0x0 ),	/* 0 */
/* 406 */	NdrFcShort( 0x0 ),	/* 0 */
/* 408 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 410 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 412 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 414 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 416 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 418 */	NdrFcShort( 0x2 ),	/* Offset= 2 (420) */
/* 420 */	
			0x13, 0x0,	/* FC_OP */
/* 422 */	NdrFcShort( 0x1e4 ),	/* Offset= 484 (906) */
/* 424 */	
			0x2a,		/* FC_ENCAPSULATED_UNION */
			0x89,		/* 137 */
/* 426 */	NdrFcShort( 0x20 ),	/* 32 */
/* 428 */	NdrFcShort( 0xa ),	/* 10 */
/* 430 */	NdrFcLong( 0x8 ),	/* 8 */
/* 434 */	NdrFcShort( 0x50 ),	/* Offset= 80 (514) */
/* 436 */	NdrFcLong( 0xd ),	/* 13 */
/* 440 */	NdrFcShort( 0x70 ),	/* Offset= 112 (552) */
/* 442 */	NdrFcLong( 0x9 ),	/* 9 */
/* 446 */	NdrFcShort( 0x90 ),	/* Offset= 144 (590) */
/* 448 */	NdrFcLong( 0xc ),	/* 12 */
/* 452 */	NdrFcShort( 0xb0 ),	/* Offset= 176 (628) */
/* 454 */	NdrFcLong( 0x24 ),	/* 36 */
/* 458 */	NdrFcShort( 0x102 ),	/* Offset= 258 (716) */
/* 460 */	NdrFcLong( 0x800d ),	/* 32781 */
/* 464 */	NdrFcShort( 0x11e ),	/* Offset= 286 (750) */
/* 466 */	NdrFcLong( 0x10 ),	/* 16 */
/* 470 */	NdrFcShort( 0x138 ),	/* Offset= 312 (782) */
/* 472 */	NdrFcLong( 0x2 ),	/* 2 */
/* 476 */	NdrFcShort( 0x14e ),	/* Offset= 334 (810) */
/* 478 */	NdrFcLong( 0x3 ),	/* 3 */
/* 482 */	NdrFcShort( 0x164 ),	/* Offset= 356 (838) */
/* 484 */	NdrFcLong( 0x14 ),	/* 20 */
/* 488 */	NdrFcShort( 0x17a ),	/* Offset= 378 (866) */
/* 490 */	NdrFcShort( 0xffff ),	/* Offset= -1 (489) */
/* 492 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 494 */	NdrFcShort( 0x0 ),	/* 0 */
/* 496 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 498 */	NdrFcShort( 0x0 ),	/* 0 */
/* 500 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 502 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 506 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 508 */	
			0x13, 0x0,	/* FC_OP */
/* 510 */	NdrFcShort( 0xfe18 ),	/* Offset= -488 (22) */
/* 512 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 514 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 516 */	NdrFcShort( 0x10 ),	/* 16 */
/* 518 */	NdrFcShort( 0x0 ),	/* 0 */
/* 520 */	NdrFcShort( 0x6 ),	/* Offset= 6 (526) */
/* 522 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 524 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 526 */	
			0x11, 0x0,	/* FC_RP */
/* 528 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (492) */
/* 530 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 532 */	NdrFcShort( 0x0 ),	/* 0 */
/* 534 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 536 */	NdrFcShort( 0x0 ),	/* 0 */
/* 538 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 540 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 544 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 546 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 548 */	NdrFcShort( 0xff58 ),	/* Offset= -168 (380) */
/* 550 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 552 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 554 */	NdrFcShort( 0x10 ),	/* 16 */
/* 556 */	NdrFcShort( 0x0 ),	/* 0 */
/* 558 */	NdrFcShort( 0x6 ),	/* Offset= 6 (564) */
/* 560 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 562 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 564 */	
			0x11, 0x0,	/* FC_RP */
/* 566 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (530) */
/* 568 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 570 */	NdrFcShort( 0x0 ),	/* 0 */
/* 572 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 574 */	NdrFcShort( 0x0 ),	/* 0 */
/* 576 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 578 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 582 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 584 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 586 */	NdrFcShort( 0xff44 ),	/* Offset= -188 (398) */
/* 588 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 590 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 592 */	NdrFcShort( 0x10 ),	/* 16 */
/* 594 */	NdrFcShort( 0x0 ),	/* 0 */
/* 596 */	NdrFcShort( 0x6 ),	/* Offset= 6 (602) */
/* 598 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 600 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 602 */	
			0x11, 0x0,	/* FC_RP */
/* 604 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (568) */
/* 606 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 608 */	NdrFcShort( 0x0 ),	/* 0 */
/* 610 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 612 */	NdrFcShort( 0x0 ),	/* 0 */
/* 614 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 616 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 620 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 622 */	
			0x13, 0x0,	/* FC_OP */
/* 624 */	NdrFcShort( 0x176 ),	/* Offset= 374 (998) */
/* 626 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 628 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 630 */	NdrFcShort( 0x10 ),	/* 16 */
/* 632 */	NdrFcShort( 0x0 ),	/* 0 */
/* 634 */	NdrFcShort( 0x6 ),	/* Offset= 6 (640) */
/* 636 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 638 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 640 */	
			0x11, 0x0,	/* FC_RP */
/* 642 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (606) */
/* 644 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 646 */	NdrFcLong( 0x2f ),	/* 47 */
/* 650 */	NdrFcShort( 0x0 ),	/* 0 */
/* 652 */	NdrFcShort( 0x0 ),	/* 0 */
/* 654 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 656 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 658 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 660 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 662 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 664 */	NdrFcShort( 0x1 ),	/* 1 */
/* 666 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 668 */	NdrFcShort( 0x4 ),	/* 4 */
/* 670 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 672 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 674 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 676 */	NdrFcShort( 0x18 ),	/* 24 */
/* 678 */	NdrFcShort( 0x0 ),	/* 0 */
/* 680 */	NdrFcShort( 0xa ),	/* Offset= 10 (690) */
/* 682 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 684 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 686 */	NdrFcShort( 0xffd6 ),	/* Offset= -42 (644) */
/* 688 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 690 */	
			0x13, 0x0,	/* FC_OP */
/* 692 */	NdrFcShort( 0xffe2 ),	/* Offset= -30 (662) */
/* 694 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 696 */	NdrFcShort( 0x0 ),	/* 0 */
/* 698 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 700 */	NdrFcShort( 0x0 ),	/* 0 */
/* 702 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 704 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 708 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 710 */	
			0x13, 0x0,	/* FC_OP */
/* 712 */	NdrFcShort( 0xffda ),	/* Offset= -38 (674) */
/* 714 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 716 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 718 */	NdrFcShort( 0x10 ),	/* 16 */
/* 720 */	NdrFcShort( 0x0 ),	/* 0 */
/* 722 */	NdrFcShort( 0x6 ),	/* Offset= 6 (728) */
/* 724 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 726 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 728 */	
			0x11, 0x0,	/* FC_RP */
/* 730 */	NdrFcShort( 0xffdc ),	/* Offset= -36 (694) */
/* 732 */	
			0x1d,		/* FC_SMFARRAY */
			0x0,		/* 0 */
/* 734 */	NdrFcShort( 0x8 ),	/* 8 */
/* 736 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 738 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 740 */	NdrFcShort( 0x10 ),	/* 16 */
/* 742 */	0x8,		/* FC_LONG */
			0x6,		/* FC_SHORT */
/* 744 */	0x6,		/* FC_SHORT */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 746 */	0x0,		/* 0 */
			NdrFcShort( 0xfff1 ),	/* Offset= -15 (732) */
			0x5b,		/* FC_END */
/* 750 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 752 */	NdrFcShort( 0x20 ),	/* 32 */
/* 754 */	NdrFcShort( 0x0 ),	/* 0 */
/* 756 */	NdrFcShort( 0xa ),	/* Offset= 10 (766) */
/* 758 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 760 */	0x36,		/* FC_POINTER */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 762 */	0x0,		/* 0 */
			NdrFcShort( 0xffe7 ),	/* Offset= -25 (738) */
			0x5b,		/* FC_END */
/* 766 */	
			0x11, 0x0,	/* FC_RP */
/* 768 */	NdrFcShort( 0xff12 ),	/* Offset= -238 (530) */
/* 770 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 772 */	NdrFcShort( 0x1 ),	/* 1 */
/* 774 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 776 */	NdrFcShort( 0x0 ),	/* 0 */
/* 778 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 780 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 782 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 784 */	NdrFcShort( 0x10 ),	/* 16 */
/* 786 */	NdrFcShort( 0x0 ),	/* 0 */
/* 788 */	NdrFcShort( 0x6 ),	/* Offset= 6 (794) */
/* 790 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 792 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 794 */	
			0x13, 0x0,	/* FC_OP */
/* 796 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (770) */
/* 798 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 800 */	NdrFcShort( 0x2 ),	/* 2 */
/* 802 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 804 */	NdrFcShort( 0x0 ),	/* 0 */
/* 806 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 808 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 810 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 812 */	NdrFcShort( 0x10 ),	/* 16 */
/* 814 */	NdrFcShort( 0x0 ),	/* 0 */
/* 816 */	NdrFcShort( 0x6 ),	/* Offset= 6 (822) */
/* 818 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 820 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 822 */	
			0x13, 0x0,	/* FC_OP */
/* 824 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (798) */
/* 826 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 828 */	NdrFcShort( 0x4 ),	/* 4 */
/* 830 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 832 */	NdrFcShort( 0x0 ),	/* 0 */
/* 834 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 836 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 838 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 840 */	NdrFcShort( 0x10 ),	/* 16 */
/* 842 */	NdrFcShort( 0x0 ),	/* 0 */
/* 844 */	NdrFcShort( 0x6 ),	/* Offset= 6 (850) */
/* 846 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 848 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 850 */	
			0x13, 0x0,	/* FC_OP */
/* 852 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (826) */
/* 854 */	
			0x1b,		/* FC_CARRAY */
			0x7,		/* 7 */
/* 856 */	NdrFcShort( 0x8 ),	/* 8 */
/* 858 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 860 */	NdrFcShort( 0x0 ),	/* 0 */
/* 862 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 864 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 866 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 868 */	NdrFcShort( 0x10 ),	/* 16 */
/* 870 */	NdrFcShort( 0x0 ),	/* 0 */
/* 872 */	NdrFcShort( 0x6 ),	/* Offset= 6 (878) */
/* 874 */	0x8,		/* FC_LONG */
			0x40,		/* FC_STRUCTPAD4 */
/* 876 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 878 */	
			0x13, 0x0,	/* FC_OP */
/* 880 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (854) */
/* 882 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 884 */	NdrFcShort( 0x8 ),	/* 8 */
/* 886 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 888 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 890 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 892 */	NdrFcShort( 0x8 ),	/* 8 */
/* 894 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 896 */	NdrFcShort( 0xffc8 ),	/* -56 */
/* 898 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 900 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 902 */	NdrFcShort( 0xffec ),	/* Offset= -20 (882) */
/* 904 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 906 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 908 */	NdrFcShort( 0x38 ),	/* 56 */
/* 910 */	NdrFcShort( 0xffec ),	/* Offset= -20 (890) */
/* 912 */	NdrFcShort( 0x0 ),	/* Offset= 0 (912) */
/* 914 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 916 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 918 */	0x40,		/* FC_STRUCTPAD4 */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 920 */	0x0,		/* 0 */
			NdrFcShort( 0xfe0f ),	/* Offset= -497 (424) */
			0x5b,		/* FC_END */
/* 924 */	
			0x13, 0x0,	/* FC_OP */
/* 926 */	NdrFcShort( 0xff04 ),	/* Offset= -252 (674) */
/* 928 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 930 */	0x1,		/* FC_BYTE */
			0x5c,		/* FC_PAD */
/* 932 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 934 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/* 936 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 938 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 940 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 942 */	0xb,		/* FC_HYPER */
			0x5c,		/* FC_PAD */
/* 944 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 946 */	0xa,		/* FC_FLOAT */
			0x5c,		/* FC_PAD */
/* 948 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 950 */	0xc,		/* FC_DOUBLE */
			0x5c,		/* FC_PAD */
/* 952 */	
			0x13, 0x0,	/* FC_OP */
/* 954 */	NdrFcShort( 0xfdbc ),	/* Offset= -580 (374) */
/* 956 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 958 */	NdrFcShort( 0xfc70 ),	/* Offset= -912 (46) */
/* 960 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 962 */	NdrFcShort( 0xfdba ),	/* Offset= -582 (380) */
/* 964 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 966 */	NdrFcShort( 0xfdc8 ),	/* Offset= -568 (398) */
/* 968 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 970 */	NdrFcShort( 0xfdd6 ),	/* Offset= -554 (416) */
/* 972 */	
			0x13, 0x10,	/* FC_OP [pointer_deref] */
/* 974 */	NdrFcShort( 0x2 ),	/* Offset= 2 (976) */
/* 976 */	
			0x13, 0x0,	/* FC_OP */
/* 978 */	NdrFcShort( 0x14 ),	/* Offset= 20 (998) */
/* 980 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 982 */	NdrFcShort( 0x10 ),	/* 16 */
/* 984 */	0x6,		/* FC_SHORT */
			0x1,		/* FC_BYTE */
/* 986 */	0x1,		/* FC_BYTE */
			0x8,		/* FC_LONG */
/* 988 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 990 */	
			0x13, 0x0,	/* FC_OP */
/* 992 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (980) */
/* 994 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 996 */	0x2,		/* FC_CHAR */
			0x5c,		/* FC_PAD */
/* 998 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x7,		/* 7 */
/* 1000 */	NdrFcShort( 0x20 ),	/* 32 */
/* 1002 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1004 */	NdrFcShort( 0x0 ),	/* Offset= 0 (1004) */
/* 1006 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 1008 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 1010 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 1012 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 1014 */	NdrFcShort( 0xfc56 ),	/* Offset= -938 (76) */
/* 1016 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 1018 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 1020 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1022 */	NdrFcShort( 0x18 ),	/* 24 */
/* 1024 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1026 */	NdrFcShort( 0xfc46 ),	/* Offset= -954 (72) */
/* 1028 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1030 */	NdrFcLong( 0x2c3c484e ),	/* 742148174 */
/* 1034 */	NdrFcShort( 0x8ad0 ),	/* -30000 */
/* 1036 */	NdrFcShort( 0x442e ),	/* 17454 */
/* 1038 */	0x8d,		/* 141 */
			0xac,		/* 172 */
/* 1040 */	0x24,		/* 36 */
			0x8f,		/* 143 */
/* 1042 */	0xcf,		/* 207 */
			0x55,		/* 85 */
/* 1044 */	0xf5,		/* 245 */
			0xee,		/* 238 */
/* 1046 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1048 */	NdrFcShort( 0xfd64 ),	/* Offset= -668 (380) */
/* 1050 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1052 */	NdrFcShort( 0xffe8 ),	/* Offset= -24 (1028) */
/* 1054 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1056 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1058) */
/* 1058 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1060 */	NdrFcLong( 0xaee2bf36 ),	/* -1360871626 */
/* 1064 */	NdrFcShort( 0x4b0 ),	/* 1200 */
/* 1066 */	NdrFcShort( 0x4586 ),	/* 17798 */
/* 1068 */	0x88,		/* 136 */
			0x3,		/* 3 */
/* 1070 */	0x13,		/* 19 */
			0xf2,		/* 242 */
/* 1072 */	0xaa,		/* 170 */
			0xdb,		/* 219 */
/* 1074 */	0xeb,		/* 235 */
			0xbb,		/* 187 */
/* 1076 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1078 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1080) */
/* 1080 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1082 */	NdrFcLong( 0x809fd5b3 ),	/* -2137008717 */
/* 1086 */	NdrFcShort( 0x5278 ),	/* 21112 */
/* 1088 */	NdrFcShort( 0x4719 ),	/* 18201 */
/* 1090 */	0xb9,		/* 185 */
			0xc7,		/* 199 */
/* 1092 */	0x9e,		/* 158 */
			0xb,		/* 11 */
/* 1094 */	0x2d,		/* 45 */
			0xe2,		/* 226 */
/* 1096 */	0x6d,		/* 109 */
			0xe8,		/* 232 */
/* 1098 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1100 */	NdrFcLong( 0x12aad383 ),	/* 313185155 */
/* 1104 */	NdrFcShort( 0x2909 ),	/* 10505 */
/* 1106 */	NdrFcShort( 0x4a14 ),	/* 18964 */
/* 1108 */	0xad,		/* 173 */
			0xa9,		/* 169 */
/* 1110 */	0xc7,		/* 199 */
			0x3d,		/* 61 */
/* 1112 */	0xc2,		/* 194 */
			0x31,		/* 49 */
/* 1114 */	0xa1,		/* 161 */
			0x8d,		/* 141 */
/* 1116 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1118 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1120) */
/* 1120 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1122 */	NdrFcLong( 0x2c3c484e ),	/* 742148174 */
/* 1126 */	NdrFcShort( 0x8ad0 ),	/* -30000 */
/* 1128 */	NdrFcShort( 0x442e ),	/* 17454 */
/* 1130 */	0x8d,		/* 141 */
			0xac,		/* 172 */
/* 1132 */	0x24,		/* 36 */
			0x8f,		/* 143 */
/* 1134 */	0xcf,		/* 207 */
			0x55,		/* 85 */
/* 1136 */	0xf5,		/* 245 */
			0xee,		/* 238 */
/* 1138 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1140 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1142) */
/* 1142 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1144 */	NdrFcLong( 0x47dff751 ),	/* 1205860177 */
/* 1148 */	NdrFcShort( 0xa138 ),	/* -24264 */
/* 1150 */	NdrFcShort( 0x44b8 ),	/* 17592 */
/* 1152 */	0x8e,		/* 142 */
			0x1c,		/* 28 */
/* 1154 */	0xfd,		/* 253 */
			0xcb,		/* 203 */
/* 1156 */	0x2e,		/* 46 */
			0xd,		/* 13 */
/* 1158 */	0xc2,		/* 194 */
			0xc7,		/* 199 */
/* 1160 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1162 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1164) */
/* 1164 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1166 */	NdrFcLong( 0xaee2bf36 ),	/* -1360871626 */
/* 1170 */	NdrFcShort( 0x4b0 ),	/* 1200 */
/* 1172 */	NdrFcShort( 0x4586 ),	/* 17798 */
/* 1174 */	0x88,		/* 136 */
			0x3,		/* 3 */
/* 1176 */	0x13,		/* 19 */
			0xf2,		/* 242 */
/* 1178 */	0xaa,		/* 170 */
			0xdb,		/* 219 */
/* 1180 */	0xeb,		/* 235 */
			0xbb,		/* 187 */
/* 1182 */	
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/* 1184 */	0x2,		/* FC_CHAR */
			0x5c,		/* FC_PAD */
/* 1186 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 1188 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1190) */
/* 1190 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1192 */	NdrFcLong( 0x8329961f ),	/* -2094426593 */
/* 1196 */	NdrFcShort( 0x757b ),	/* 30075 */
/* 1198 */	NdrFcShort( 0x450c ),	/* 17676 */
/* 1200 */	0x83,		/* 131 */
			0x3,		/* 3 */
/* 1202 */	0x2d,		/* 45 */
			0x3a,		/* 58 */
/* 1204 */	0x94,		/* 148 */
			0xcb,		/* 203 */
/* 1206 */	0xd8,		/* 216 */
			0xf7,		/* 247 */
/* 1208 */	
			0x12, 0x0,	/* FC_UP */
/* 1210 */	NdrFcShort( 0xff2c ),	/* Offset= -212 (998) */
/* 1212 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 1214 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1216 */	NdrFcShort( 0x18 ),	/* 24 */
/* 1218 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1220 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (1208) */

			0x0
        }
    };

static const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ] = 
        {
            
            {
            BSTR_UserSize
            ,BSTR_UserMarshal
            ,BSTR_UserUnmarshal
            ,BSTR_UserFree
            },
            {
            VARIANT_UserSize
            ,VARIANT_UserMarshal
            ,VARIANT_UserUnmarshal
            ,VARIANT_UserFree
            }

        };



/* Standard interface: __MIDL_itf_ScriptureObjects_0000, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: ISCReference, ver. 0.0,
   GUID={0x2C3C484E,0x8AD0,0x442e,{0x8D,0xAC,0x24,0x8F,0xCF,0x55,0xF5,0xEE}} */

#pragma code_seg(".orpc")
static const unsigned short ISCReference_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0,
    38,
    76,
    114,
    152,
    190,
    228,
    266,
    304,
    342,
    380,
    418,
    456,
    488,
    520,
    558,
    596,
    634,
    672,
    710,
    748,
    786
    };

static const MIDL_STUBLESS_PROXY_INFO ISCReference_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCReference_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCReference_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCReference_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(29) _ISCReferenceProxyVtbl = 
{
    &ISCReference_ProxyInfo,
    &IID_ISCReference,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Book */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Book */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Chapter */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Chapter */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Verse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Verse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Segment */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Segment */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_LastBook */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_LastChapter */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_LastVerse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::Parse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::NextVerse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::PreviousVerse */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_AsString */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_VersificationsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCReference::put_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_Valid */ ,
    (void *) (INT_PTR) -1 /* ISCReference::ChangeVersification */ ,
    (void *) (INT_PTR) -1 /* ISCReference::get_BBCCCVVV */ ,
    (void *) (INT_PTR) -1 /* ISCReference::SetToEnd */
};


static const PRPC_STUB_FUNCTION ISCReference_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCReferenceStubVtbl =
{
    &IID_ISCReference,
    &ISCReference_ServerInfo,
    29,
    &ISCReference_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCReferenceCollection, ver. 0.0,
   GUID={0x4E207059,0xA0AF,0x485c,{0xBD,0xFC,0xC6,0xB1,0x97,0x17,0x19,0x09}} */

#pragma code_seg(".orpc")
static const unsigned short ISCReferenceCollection_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    818,
    856,
    900,
    944,
    982,
    1020,
    1058,
    1096,
    1140
    };

static const MIDL_STUBLESS_PROXY_INFO ISCReferenceCollection_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCReferenceCollection_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCReferenceCollection_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCReferenceCollection_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(16) _ISCReferenceCollectionProxyVtbl = 
{
    &ISCReferenceCollection_ProxyInfo,
    &IID_ISCReferenceCollection,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::get_Count */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Item */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Parse */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::get_AsString */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Add */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Insert */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Remove */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::Includes */ ,
    (void *) (INT_PTR) -1 /* ISCReferenceCollection::get__NewEnum */
};


static const PRPC_STUB_FUNCTION ISCReferenceCollection_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCReferenceCollectionStubVtbl =
{
    &IID_ISCReferenceCollection,
    &ISCReferenceCollection_ServerInfo,
    16,
    &ISCReferenceCollection_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCTag, ver. 0.0,
   GUID={0xAEE2BF36,0x04B0,0x4586,{0x88,0x03,0x13,0xF2,0xAA,0xDB,0xEB,0xBB}} */

#pragma code_seg(".orpc")
static const unsigned short ISCTag_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    818,
    1178,
    1216,
    1254,
    1292,
    1330,
    1368,
    1406,
    1444,
    1482,
    1520,
    418,
    1558,
    1596,
    1634,
    1672,
    596,
    634,
    672,
    1710,
    748,
    1748,
    1786,
    1824,
    1862,
    1900,
    1938,
    1976,
    2014,
    2052,
    2090,
    2128,
    2166,
    2204,
    2242,
    2280,
    2318,
    2356,
    2394,
    2432,
    2470,
    2508,
    2546,
    2584,
    2622,
    2660,
    2698,
    2736,
    2774,
    2812,
    2850,
    2888,
    2926,
    2964,
    3002,
    3040,
    3078,
    3116
    };

static const MIDL_STUBLESS_PROXY_INFO ISCTag_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCTag_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCTag_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCTag_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(65) _ISCTagProxyVtbl = 
{
    &ISCTag_ProxyInfo,
    &IID_ISCTag,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Bold */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Bold */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Color */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Color */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Description */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Description */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Endmarker */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Endmarker */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_FirstLineIndent */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_FirstLineIndent */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Fontname */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Fontname */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_FontSize */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_FontSize */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Italic */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Italic */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_JustificationType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_JustificationType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_LeftMargin */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_LeftMargin */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_LineSpacing */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_LineSpacing */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Marker */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Marker */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_TeStyleName */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_TeStyleName */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_NotRepeatable */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_NotRepeatable */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_OccursUnder */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_OccursUnder */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Rank */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Rank */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_RightMargin */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_RightMargin */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_SpaceAfter */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_SpaceAfter */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_SpaceBefore */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_SpaceBefore */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_StyleType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_StyleType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Superscript */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Superscript */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_TextProperties */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_TextProperties */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_TextType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_TextType */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Underline */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Underline */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_XMLTag */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_XMLTag */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_SmallCaps */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_SmallCaps */ ,
    (void *) (INT_PTR) -1 /* ISCTag::get_Subscript */ ,
    (void *) (INT_PTR) -1 /* ISCTag::put_Subscript */
};


static const PRPC_STUB_FUNCTION ISCTag_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCTagStubVtbl =
{
    &IID_ISCTag,
    &ISCTag_ServerInfo,
    65,
    &ISCTag_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCTextSegment, ver. 0.0,
   GUID={0x809FD5B3,0x5278,0x4719,{0xB9,0xC7,0x9E,0x0B,0x2D,0xE2,0x6D,0xE8}} */

#pragma code_seg(".orpc")
static const unsigned short ISCTextSegment_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3154,
    3192,
    3230,
    3268,
    1292,
    1330,
    3306,
    3344,
    3382,
    3420,
    3458,
    3496,
    3534
    };

static const MIDL_STUBLESS_PROXY_INFO ISCTextSegment_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCTextSegment_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCTextSegment_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCTextSegment_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(20) _ISCTextSegmentProxyVtbl = 
{
    &ISCTextSegment_ProxyInfo,
    &IID_ISCTextSegment,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_FirstReference */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_FirstReference */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_LastReference */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_LastReference */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_Text */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_Text */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_TextType */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_TextType */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_TextProperties */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_TextProperties */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::get_Tag */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::put_Tag */ ,
    (void *) (INT_PTR) -1 /* ISCTextSegment::Clone */
};


static const PRPC_STUB_FUNCTION ISCTextSegment_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCTextSegmentStubVtbl =
{
    &IID_ISCTextSegment,
    &ISCTextSegment_ServerInfo,
    20,
    &ISCTextSegment_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCTextEnum, ver. 0.0,
   GUID={0x47DFF751,0xA138,0x44b8,{0x8E,0x1C,0xFD,0xCB,0x2E,0x0D,0xC2,0xC7}} */

#pragma code_seg(".orpc")
static const unsigned short ISCTextEnum_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3572,
    3616,
    3660,
    3698
    };

static const MIDL_STUBLESS_PROXY_INFO ISCTextEnum_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCTextEnum_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCTextEnum_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCTextEnum_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(11) _ISCTextEnumProxyVtbl = 
{
    &ISCTextEnum_ProxyInfo,
    &IID_ISCTextEnum,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnum::NextToken */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnum::Next */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnum::Update */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnum::SetText */
};


static const PRPC_STUB_FUNCTION ISCTextEnum_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCTextEnumStubVtbl =
{
    &IID_ISCTextEnum,
    &ISCTextEnum_ServerInfo,
    11,
    &ISCTextEnum_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCTextEnumEx, ver. 0.0,
   GUID={0x8329961F,0x757B,0x450c,{0x83,0x03,0x2D,0x3A,0x94,0xCB,0xD8,0xF7}} */

#pragma code_seg(".orpc")
static const unsigned short ISCTextEnumEx_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3572,
    3748
    };

static const MIDL_STUBLESS_PROXY_INFO ISCTextEnumEx_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCTextEnumEx_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCTextEnumEx_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCTextEnumEx_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(9) _ISCTextEnumExProxyVtbl = 
{
    &ISCTextEnumEx_ProxyInfo,
    &IID_ISCTextEnumEx,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnumEx::NextToken */ ,
    (void *) (INT_PTR) -1 /* ISCTextEnumEx::Next */
};


static const PRPC_STUB_FUNCTION ISCTextEnumEx_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCTextEnumExStubVtbl =
{
    &IID_ISCTextEnumEx,
    &ISCTextEnumEx_ServerInfo,
    9,
    &ISCTextEnumEx_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCScriptureText, ver. 0.0,
   GUID={0xE36624CE,0x5A21,0x458e,{0x8F,0x3B,0x97,0x23,0xCE,0xDD,0x45,0x30}} */

#pragma code_seg(".orpc")
static const unsigned short ISCScriptureText_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3798,
    3836,
    3874,
    3912,
    3974,
    4030,
    4086,
    4148,
    4204,
    4248,
    4292,
    4336,
    4380,
    4424,
    4462,
    4500,
    4538,
    4576,
    4614,
    4652,
    4690,
    4728,
    4766,
    4804,
    4842,
    4880,
    4918,
    4956,
    4994,
    5032,
    5070,
    5108,
    5146,
    5184,
    5222,
    5260,
    5298,
    5336,
    5374,
    5412,
    5450,
    5488,
    5526,
    5564,
    2622,
    2660
    };

static const MIDL_STUBLESS_PROXY_INFO ISCScriptureText_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCScriptureText_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(53) _ISCScriptureTextProxyVtbl = 
{
    &ISCScriptureText_ProxyInfo,
    &IID_ISCScriptureText,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_TextsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Load */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Save */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TextEnum */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::PutText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::FileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthFileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthTag */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TagIndex */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::CharToWChar */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::SetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_SettingsDirectory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Versification */
};


static const PRPC_STUB_FUNCTION ISCScriptureText_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCScriptureTextStubVtbl =
{
    &IID_ISCScriptureText,
    &ISCScriptureText_ServerInfo,
    53,
    &ISCScriptureText_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCScriptureText2, ver. 0.0,
   GUID={0x9B2DA462,0xACDA,0x48c2,{0x9D,0x23,0xA6,0x52,0xF0,0x6E,0xC7,0xFA}} */

#pragma code_seg(".orpc")
static const unsigned short ISCScriptureText2_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3798,
    3836,
    3874,
    3912,
    3974,
    4030,
    4086,
    4148,
    4204,
    4248,
    4292,
    4336,
    4380,
    4424,
    4462,
    4500,
    4538,
    4576,
    4614,
    4652,
    4690,
    4728,
    4766,
    4804,
    4842,
    4880,
    4918,
    4956,
    4994,
    5032,
    5070,
    5108,
    5146,
    5184,
    5222,
    5260,
    5298,
    5336,
    5374,
    5412,
    5450,
    5488,
    5526,
    5564,
    2622,
    2660,
    5602,
    5640
    };

static const MIDL_STUBLESS_PROXY_INFO ISCScriptureText2_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText2_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCScriptureText2_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText2_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(55) _ISCScriptureText2ProxyVtbl = 
{
    &ISCScriptureText2_ProxyInfo,
    &IID_ISCScriptureText2,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_TextsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Load */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Save */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TextEnum */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::PutText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::FileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthFileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthTag */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TagIndex */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::CharToWChar */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::SetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_SettingsDirectory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::get_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::put_Encoding */
};


static const PRPC_STUB_FUNCTION ISCScriptureText2_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCScriptureText2StubVtbl =
{
    &IID_ISCScriptureText2,
    &ISCScriptureText2_ServerInfo,
    55,
    &ISCScriptureText2_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCScriptureText3, ver. 0.0,
   GUID={0xDCAC5534,0x8CC8,0x4b91,{0xBC,0x3C,0x41,0x8B,0x91,0x5D,0xA7,0x8C}} */

#pragma code_seg(".orpc")
static const unsigned short ISCScriptureText3_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3798,
    3836,
    3874,
    3912,
    3974,
    4030,
    4086,
    4148,
    4204,
    4248,
    4292,
    4336,
    4380,
    4424,
    4462,
    4500,
    4538,
    4576,
    4614,
    4652,
    4690,
    4728,
    4766,
    4804,
    4842,
    4880,
    4918,
    4956,
    4994,
    5032,
    5070,
    5108,
    5146,
    5184,
    5222,
    5260,
    5298,
    5336,
    5374,
    5412,
    5450,
    5488,
    5526,
    5564,
    2622,
    2660,
    5602,
    5640,
    2774
    };

static const MIDL_STUBLESS_PROXY_INFO ISCScriptureText3_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText3_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCScriptureText3_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText3_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(56) _ISCScriptureText3ProxyVtbl = 
{
    &ISCScriptureText3_ProxyInfo,
    &IID_ISCScriptureText3,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_TextsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Load */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Save */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TextEnum */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::PutText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::FileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthFileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthTag */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TagIndex */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::CharToWChar */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::SetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_SettingsDirectory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::get_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::put_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText3::get_AsteriskIsMarker */
};


static const PRPC_STUB_FUNCTION ISCScriptureText3_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCScriptureText3StubVtbl =
{
    &IID_ISCScriptureText3,
    &ISCScriptureText3_ServerInfo,
    56,
    &ISCScriptureText3_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISCScriptureText4, ver. 0.0,
   GUID={0x12AAD383,0x2909,0x4a14,{0xAD,0xA9,0xC7,0x3D,0xC2,0x31,0xA1,0x8D}} */

#pragma code_seg(".orpc")
static const unsigned short ISCScriptureText4_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    3798,
    3836,
    3874,
    3912,
    3974,
    4030,
    4086,
    4148,
    4204,
    4248,
    4292,
    4336,
    4380,
    4424,
    4462,
    4500,
    4538,
    4576,
    4614,
    4652,
    4690,
    4728,
    4766,
    4804,
    4842,
    4880,
    4918,
    4956,
    4994,
    5032,
    5070,
    5108,
    5146,
    5184,
    5222,
    5260,
    5298,
    5336,
    5374,
    5412,
    5450,
    5488,
    5526,
    5564,
    2622,
    2660,
    5602,
    5640,
    2774,
    5678,
    5728
    };

static const MIDL_STUBLESS_PROXY_INFO ISCScriptureText4_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText4_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISCScriptureText4_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISCScriptureText4_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(58) _ISCScriptureText4ProxyVtbl = 
{
    &ISCScriptureText4_ProxyInfo,
    &IID_ISCScriptureText4,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_TextsPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Load */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::Save */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TextEnum */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::PutText */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::FileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthFileName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::NthTag */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::TagIndex */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::CharToWChar */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::GetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::SetParameterValue */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_BooksPresent */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_CodePage */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFont */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_DefaultFontSize */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Directory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Editable */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePostPart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNamePrePart */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FileNameChapterNumberForm */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_FullName */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Language */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_LeftToRight */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Name */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_SettingsDirectory */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_StyleSheet */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::get_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText::put_Versification */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::get_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText2::put_Encoding */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText3::get_AsteriskIsMarker */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText4::TextEnumEx */ ,
    (void *) (INT_PTR) -1 /* ISCScriptureText4::LoadECObjectDataForSOReading */
};


static const PRPC_STUB_FUNCTION ISCScriptureText4_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISCScriptureText4StubVtbl =
{
    &IID_ISCScriptureText4,
    &ISCScriptureText4_ServerInfo,
    58,
    &ISCScriptureText4_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IPreSO, ver. 0.0,
   GUID={0x936CB9E1,0x4EE8,0x4c8e,{0x85,0xB8,0x68,0x19,0x8B,0x89,0xF1,0xBA}} */

#pragma code_seg(".orpc")
static const unsigned short IPreSO_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    5766,
    5804,
    3874,
    5848,
    5886,
    5924,
    5962,
    6000,
    6068,
    6124
    };

static const MIDL_STUBLESS_PROXY_INFO IPreSO_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IPreSO_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IPreSO_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IPreSO_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(17) _IPreSOProxyVtbl = 
{
    &IPreSO_ProxyInfo,
    &IID_IPreSO,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* IPreSO::Initialize */ ,
    (void *) (INT_PTR) -1 /* IPreSO::Save */ ,
    (void *) (INT_PTR) -1 /* IPreSO::AddFile */ ,
    (void *) (INT_PTR) -1 /* IPreSO::RemoveFile */ ,
    (void *) (INT_PTR) -1 /* IPreSO::get_Files */ ,
    (void *) (INT_PTR) -1 /* IPreSO::get_BookMarker */ ,
    (void *) (INT_PTR) -1 /* IPreSO::put_BookMarker */ ,
    (void *) (INT_PTR) -1 /* IPreSO::NthMapping */ ,
    (void *) (INT_PTR) -1 /* IPreSO::SetMapping */ ,
    (void *) (INT_PTR) -1 /* IPreSO::GetBooksForFile */
};


static const PRPC_STUB_FUNCTION IPreSO_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _IPreSOStubVtbl =
{
    &IID_IPreSO,
    &IPreSO_ServerInfo,
    17,
    &IPreSO_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x50002, /* Ndr library version */
    0,
    0x6000169, /* MIDL Version 6.0.361 */
    0,
    UserMarshalRoutines,
    0,  /* notify & notify_flag routine table */
    0x1, /* MIDL flag */
    0, /* cs routines */
    0,   /* proxy/server info */
    0   /* Reserved5 */
    };

const CInterfaceProxyVtbl * _ScriptureObjects_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_ISCTextEnumExProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCScriptureText3ProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCTagProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCReferenceProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCTextEnumProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCReferenceCollectionProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCScriptureText2ProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCScriptureText4ProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCTextSegmentProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISCScriptureTextProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IPreSOProxyVtbl,
    0
};

const CInterfaceStubVtbl * _ScriptureObjects_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_ISCTextEnumExStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCScriptureText3StubVtbl,
    ( CInterfaceStubVtbl *) &_ISCTagStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCReferenceStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCTextEnumStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCReferenceCollectionStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCScriptureText2StubVtbl,
    ( CInterfaceStubVtbl *) &_ISCScriptureText4StubVtbl,
    ( CInterfaceStubVtbl *) &_ISCTextSegmentStubVtbl,
    ( CInterfaceStubVtbl *) &_ISCScriptureTextStubVtbl,
    ( CInterfaceStubVtbl *) &_IPreSOStubVtbl,
    0
};

PCInterfaceName const _ScriptureObjects_InterfaceNamesList[] = 
{
    "ISCTextEnumEx",
    "ISCScriptureText3",
    "ISCTag",
    "ISCReference",
    "ISCTextEnum",
    "ISCReferenceCollection",
    "ISCScriptureText2",
    "ISCScriptureText4",
    "ISCTextSegment",
    "ISCScriptureText",
    "IPreSO",
    0
};

const IID *  _ScriptureObjects_BaseIIDList[] = 
{
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    0
};


#define _ScriptureObjects_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _ScriptureObjects, pIID, n)

int __stdcall _ScriptureObjects_IID_Lookup( const IID * pIID, int * pIndex )
{
    IID_BS_LOOKUP_SETUP

    IID_BS_LOOKUP_INITIAL_TEST( _ScriptureObjects, 11, 8 )
    IID_BS_LOOKUP_NEXT_TEST( _ScriptureObjects, 4 )
    IID_BS_LOOKUP_NEXT_TEST( _ScriptureObjects, 2 )
    IID_BS_LOOKUP_NEXT_TEST( _ScriptureObjects, 1 )
    IID_BS_LOOKUP_RETURN_RESULT( _ScriptureObjects, 11, *pIndex )
    
}

const ExtendedProxyFileInfo ScriptureObjects_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _ScriptureObjects_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _ScriptureObjects_StubVtblList,
    (const PCInterfaceName * ) & _ScriptureObjects_InterfaceNamesList,
    (const IID ** ) & _ScriptureObjects_BaseIIDList,
    & _ScriptureObjects_IID_Lookup, 
    11,
    2,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};
#if _MSC_VER >= 1200
#pragma warning(pop)
#endif


#endif /* defined(_M_IA64) || defined(_M_AMD64)*/

