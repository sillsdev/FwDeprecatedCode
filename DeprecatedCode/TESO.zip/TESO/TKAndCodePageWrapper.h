#ifndef __TKAndCodePageWrapper_H__
#define __TKAndCodePageWrapper_H__

#include <comdef.h>
#include "teckit_engine.h"		// use the "kForm" encoding constants...
#include "SimpleTKWrapper.h"
//#include "TraceCreation.h"


class CTKAndCodePageWrapper	//: public CTraceCreation
{
public:
	CTKAndCodePageWrapper();

	~CTKAndCodePageWrapper() {
		if (m_pTEC)
			delete m_pTEC;
	};

	CTKAndCodePageWrapper( const CTKAndCodePageWrapper& other );

	void Load( char* fname );

	bool IsValid()	{ return m_Valid; }
	
	HRESULT	Convert( unsigned char* in, BSTR* outBuff );	// go from Bytes to UTF16LE
	char*	Convert( BSTR in );							// go from UTF16LE to Bytes

	int CodePage() { return m_pTEC ? -1 : m_iCodePage; }

private:
	CSimpleTKWrapper* m_pTEC;
	int m_iCodePage;
		// Number of code page. Not used if m_pTEC is non-null.

	bool m_Valid;
};

#endif
