/*-------------------------------------------------------------------*//*:Ignore these comments.
Copyright (C) 2004 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: TestSCScriptureText.h
Responsibility:
Last reviewed:

	Unit tests for the ISCScriptureText4 implementation
----------------------------------------------------------------------------------------------*/
#ifndef TESTSCSCRIPTURETEXT_H_INCLUDED
#define TESTSCSCRIPTURETEXT_H_INCLUDED

#pragma once

#include "testTESO.h"
#include "comutil.h"
#include "..\\TESO.h"	// TESO com stuff
#include "..\\..\\ECObjects\\ECObjects.h"	// ECObjects com stuff

extern long GetFWROOTDirectory(char* strResult, long len); // in Srflib.cpp

namespace TestTESO
{
	class TestSCScriptureText : public unitpp::suite
	{
		CComPtr<IECProject> m_qecproj;
		char m_rgchDir[1024];

		void testBasicSFMImport()
		{
			HRESULT hr;
			unitpp::assert_true("test0: IECProject object created", m_qecproj.p != NULL);

			// Add the test input file to the ECProject.
			CComBSTR sbstrName(m_rgchDir);
			sbstrName += L"test0.sfm";
			long percent;
			EC_FileEncoding fileEC;
			hr = m_qecproj->AddFileGetEncoding(sbstrName, &fileEC, &percent);
			unitpp::assert_eq("test0: m_qecproj->AddFileGetEncoding() [hr]", S_OK, hr);
			unitpp::assert_eq("Test file is BYTES (plain ASCII)", FE_BYTES, fileEC);
			_variant_t vData;
			hr = m_qecproj.p->get_AsSafeArray(&vData);
			unitpp::assert_eq("test0: m_qecproj->get_AsSafeArray() [hr]", S_OK, hr);
			int numFiles;
			hr = m_qecproj->get_NumberOfFiles( &numFiles );
			unitpp::assert_eq("test0: m_qecproj->get_NumberOfFiles() [hr]", S_OK, hr);
			unitpp::assert_eq("test0: only one input file", 1, numFiles);

			// Load the ECProject data into TESO.
			CComPtr<ISCScriptureText4> qscrtxt;
			hr = qscrtxt.CoCreateInstance(__uuidof(SCScriptureText), NULL,
				CLSCTX_INPROC_SERVER);
			unitpp::assert_eq("test0: ISCScriptureText4 object created [hr]", S_OK, hr);
			unitpp::assert_true("test0: ISCScriptureText4 object created", qscrtxt.p != NULL);
			hr = qscrtxt->LoadECObjectDataForSOReading(vData);
			unitpp::assert_eq("test0: qscrtxt->LoadECObjectDataForSOReading() [hr]", S_OK, hr);

			CComPtr<ISCReference> qrefFirst, qrefLast;
			hr = qrefFirst.CoCreateInstance(__uuidof(SCReference), NULL,
				CLSCTX_INPROC_SERVER);
			unitpp::assert_eq("test0: first ISCReference object created [hr]", S_OK, hr);
			hr = qrefLast.CoCreateInstance(__uuidof(SCReference), NULL,
				CLSCTX_INPROC_SERVER);
			unitpp::assert_eq("test0: second ISCReference object created [hr]", S_OK, hr);

			// Get the temp file name, and finish initializing reference objects. (?)
			hr = qscrtxt->NthFileName(1, qrefFirst, qrefLast, &sbstrName);
			unitpp::assert_eq("test0: qscrtxt->get_NthFileName() [hr]", S_OK, hr);

			CComBSTR sbstr;
			hr = qrefFirst->get_AsString(&sbstr);
			unitpp::assert_eq("test0: qrefFirst->get_AsString() [hr]", S_OK, hr);
			unitpp::assert_true("test0: qrefFirst->get_AsString() value",
				wcscmp(L"EXO 0:0", sbstr.m_str) == 0);

			hr = qrefLast->get_AsString(&sbstr);
			unitpp::assert_eq("test0: qrefLast->get_AsString() [hr]", S_OK, hr);
			unitpp::assert_true("test0: qrefLast->get_AsString() value",
				wcscmp(L"EXO 3:8", sbstr.m_str) == 0);

			CComPtr<ISCTextEnum> qscte;

			hr = qscrtxt->TextEnum(qrefFirst, qrefLast,
				(SCTextType)0, (SCTextProperties)0, &qscte);
			unitpp::assert_eq("test0: qscrtxt->get_TextEnum() [hr]", S_OK, hr);

			CComPtr<ISCTextSegment> qsctseg;
			qsctseg.CoCreateInstance(__uuidof(SCTextSegment), NULL, CLSCTX_INPROC_SERVER);
			unitpp::assert_eq("test0: ISCTextSegment object created [hr]", S_OK, hr);
			BOOL fSeg;
			char rgchMsg[512];
			short iBook;
			short iChapter;
			short iVerse;
			// marker position values (we assume book 1 for this test)
			short rgiChapters[]   = { 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3 };
			short rgiVerses[]     = { 0, 0, 1, 2, 3, 4, 0, 1, 2, 3, 0, 1, 2, 4, 6 };
			short rgiLastVerses[] = { 0, 0, 1, 2, 3, 4, 0, 1, 2, 3, 0, 1, 3, 5, 8 };
			const int kcSegs = sizeof(rgiChapters) / sizeof(rgiChapters[0]);
			for (int cseg = 1; ; ++cseg)
			{
				hr = qscte->Next(qsctseg, &fSeg);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qscte->Next() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				if (!fSeg)
					break;
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] Test data parsed correctly", cseg);
				unitpp::assert_true(rgchMsg, cseg <= kcSegs);

				CComPtr<ISCTag> qsctag;
				hr = qsctseg->get_Tag(&qsctag);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qsctseg->get_Tag() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);

				hr = qsctag->get_Marker(&sbstr);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qsctag->get_Marker() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);

				qrefFirst.Release();
				hr = qsctseg->get_FirstReference(&qrefFirst);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] get_FirstReference() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);

				hr = qrefFirst->get_Book(&iBook);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefFirst->get_Book() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefFirst->get_Book() value", cseg);
				unitpp::assert_eq(rgchMsg, 2, iBook);

				hr = qrefFirst->get_Chapter(&iChapter);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefFirst->get_Chapter() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefFirst->get_Chapter() value", cseg);
				unitpp::assert_eq(rgchMsg, rgiChapters[cseg-1], iChapter);

				hr = qrefFirst->get_Verse(&iVerse);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefFirst->get_Verse() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefFirst->get_Verse() value", cseg);
				unitpp::assert_eq(rgchMsg, rgiVerses[cseg-1], iVerse);

				qrefLast.Release();
				hr = qsctseg->get_LastReference(&qrefLast);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] get_LastReference() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);

				hr = qrefLast->get_Book(&iBook);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefLast->get_Book() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefLast->get_Book() value", cseg);
				unitpp::assert_eq(rgchMsg, 2, iBook);

				hr = qrefLast->get_Chapter(&iChapter);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefLast->get_Chapter() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefLast->get_Chapter() value", cseg);
				unitpp::assert_eq(rgchMsg, rgiChapters[cseg-1], iChapter);

				hr = qrefLast->get_Verse(&iVerse);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefLast->get_Verse() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg),
					"test0: [Pass %d] qrefLast->get_Verse() value", cseg);
				unitpp::assert_eq(rgchMsg, rgiLastVerses[cseg-1], iVerse);
			}
			unitpp::assert_eq("test0: Test data parsed correctly", kcSegs + 1, cseg);
		}

		/*--------------------------------------------------------------------------------------
			Test that we can import vernacular (non-ASCII) chapter and verse numbers.
		--------------------------------------------------------------------------------------*/
		void testVernacularNumberImport()
		{
			HRESULT hr;
			unitpp::assert_true("IECProject object created", m_qecproj.p != NULL);

			// Add the test input file to the ECProject.
			CComBSTR sbstrName(m_rgchDir);
			sbstrName += L"test1.sfm";
			long percent;
			EC_FileEncoding fileEC;
			hr = m_qecproj->AddFileGetEncoding(sbstrName, &fileEC, &percent);
			unitpp::assert_eq("m_qecproj->AddFileGetEncoding() [hr]", S_OK, hr);
			unitpp::assert_eq("Test file is UTF8", FE_UTF8, fileEC);
			_variant_t vData;
			hr = m_qecproj.p->get_AsSafeArray(&vData);
			unitpp::assert_eq("m_qecproj->get_AsSafeArray() [hr]", S_OK, hr);
			int numFiles;
			hr = m_qecproj->get_NumberOfFiles( &numFiles );
			unitpp::assert_eq("m_qecproj->get_NumberOfFiles() [hr]", S_OK, hr);
			unitpp::assert_eq("only one input file", 1, numFiles);

			// Load the ECProject data into TESO.
			CComPtr<ISCScriptureText4> qscrtxt;
			hr = qscrtxt.CoCreateInstance(__uuidof(SCScriptureText), NULL,
				CLSCTX_INPROC_SERVER);
			unitpp::assert_eq("ISCScriptureText4 object created [hr]", S_OK, hr);
			unitpp::assert_true("ISCScriptureText4 object created", qscrtxt.p != NULL);
			hr = qscrtxt->LoadECObjectDataForSOReading(vData);
			unitpp::assert_eq("qscrtxt->LoadECObjectDataForSOReading() [hr]", S_OK, hr);

			CComPtr<ISCReference> qrefFirst, qrefLast;
			hr = qrefFirst.CoCreateInstance(__uuidof(SCReference), NULL,
				CLSCTX_INPROC_SERVER);
			unitpp::assert_eq("first ISCReference object created [hr]", S_OK, hr);
			hr = qrefLast.CoCreateInstance(__uuidof(SCReference), NULL,
				CLSCTX_INPROC_SERVER);
			unitpp::assert_eq("second ISCReference object created [hr]", S_OK, hr);

			// Get the temp file name, and finish initializing reference objects. (?)
			hr = qscrtxt->NthFileName(1, qrefFirst, qrefLast, &sbstrName);
			unitpp::assert_eq("qscrtxt->get_NthFileName() [hr]", S_OK, hr);

			CComBSTR sbstr;
			hr = qrefFirst->get_AsString(&sbstr);
			unitpp::assert_eq("qrefFirst->get_AsString() [hr]", S_OK, hr);
			unitpp::assert_true("qrefFirst->get_AsString() value",
				wcscmp(L"GEN 0:0", sbstr.m_str) == 0);

			hr = qrefLast->get_AsString(&sbstr);
			unitpp::assert_eq("qrefLast->get_AsString() [hr]", S_OK, hr);
			unitpp::assert_true("qrefLast->get_AsString() value",
				wcscmp(L"GEN 3:14", sbstr.m_str) == 0);

			CComPtr<ISCTextEnum> qscte;

			hr = qscrtxt->TextEnum(qrefFirst, qrefLast,
				(SCTextType)0, (SCTextProperties)0, &qscte);
			unitpp::assert_eq("qscrtxt->get_TextEnum() [hr]", S_OK, hr);

			CComPtr<ISCTextSegment> qsctseg;
			qsctseg.CoCreateInstance(__uuidof(SCTextSegment), NULL, CLSCTX_INPROC_SERVER);
			unitpp::assert_eq("ISCTextSegment object created [hr]", S_OK, hr);
			BOOL fSeg;
			char rgchMsg[512];
			short iBook;
			short iChapter;
			short iVerse;
			// marker position values (we assume book 1 for this test)
			short rgiChapters[]   = { 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3,  3,  3,  3 };
			short rgiVerses[]     = { 0, 0, 1, 2, 3, 4, 0, 1, 2, 3, 0, 1, 3, 5, 7, 10, 11, 12 };
			short rgiLastVerses[] = { 0, 0, 1, 2, 3, 4, 0, 1, 2, 3, 0, 2, 4, 6, 9, 10, 11, 14 };
			const int kcSegs = sizeof(rgiChapters) / sizeof(rgiChapters[0]);
			for (int cseg = 1; ; ++cseg)
			{
				hr = qscte->Next(qsctseg, &fSeg);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qscte->Next() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				if (!fSeg)
					break;
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] Test data parsed correctly",
					cseg);
				unitpp::assert_true(rgchMsg, cseg <= kcSegs);

				CComPtr<ISCTag> qsctag;
				hr = qsctseg->get_Tag(&qsctag);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qsctseg->get_Tag() [hr]", cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);

				hr = qsctag->get_Marker(&sbstr);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qsctag->get_Marker() [hr]",
					cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);

				qrefFirst.Release();
				hr = qsctseg->get_FirstReference(&qrefFirst);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] get_FirstReference() [hr]",
					cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);

				hr = qrefFirst->get_Book(&iBook);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefFirst->get_Book() [hr]",
					cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefFirst->get_Book() value",
					cseg);
				unitpp::assert_eq(rgchMsg, 1, iBook);

				hr = qrefFirst->get_Chapter(&iChapter);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefFirst->get_Chapter() [hr]",
					cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefFirst->get_Chapter() value",
					cseg);
				unitpp::assert_eq(rgchMsg, rgiChapters[cseg-1], iChapter);

				hr = qrefFirst->get_Verse(&iVerse);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefFirst->get_Verse() [hr]",
					cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefFirst->get_Verse() value",
					cseg);
				unitpp::assert_eq(rgchMsg, rgiVerses[cseg-1], iVerse);

				qrefLast.Release();
				hr = qsctseg->get_LastReference(&qrefLast);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] get_LastReference() [hr]",
					cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);

				hr = qrefLast->get_Book(&iBook);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefLast->get_Book() [hr]",
					cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefLast->get_Book() value",
					cseg);
				unitpp::assert_eq(rgchMsg, 1, iBook);

				hr = qrefLast->get_Chapter(&iChapter);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefLast->get_Chapter() [hr]",
					cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefLast->get_Chapter() value",
					cseg);
				unitpp::assert_eq(rgchMsg, rgiChapters[cseg-1], iChapter);

				hr = qrefLast->get_Verse(&iVerse);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefLast->get_Verse() [hr]",
					cseg);
				unitpp::assert_eq(rgchMsg, S_OK, hr);
				_snprintf(rgchMsg, sizeof(rgchMsg), "[Pass %d] qrefLast->get_Verse() value",
					cseg);
				unitpp::assert_eq(rgchMsg, rgiLastVerses[cseg-1], iVerse);
			}
			unitpp::assert_eq("Test data parsed correctly", kcSegs + 1, cseg);
		}

	public:
		TestSCScriptureText();

		/*--------------------------------------------------------------------------------------
			
		--------------------------------------------------------------------------------------*/
		virtual void Setup()
		{
			m_qecproj.CoCreateInstance(_uuidof(ECProject), NULL, CLSCTX_INPROC_SERVER);
		}

		/*--------------------------------------------------------------------------------------
			
		--------------------------------------------------------------------------------------*/
		virtual void Teardown()
		{
			m_qecproj.Release();
		}

		/*--------------------------------------------------------------------------------------
			
		--------------------------------------------------------------------------------------*/
		virtual void SuiteSetup()
		{
			// Get the directory where the test files live.
			long lRet = GetFWROOTDirectory(m_rgchDir, sizeof(m_rgchDir));
			if (lRet == ERROR_SUCCESS)
			{
				m_rgchDir[sizeof(m_rgchDir) - 1] = 0;	// be very paranoid.
				int ich = strlen(m_rgchDir) - 11;
				if (_stricmp("\\distfiles\\", m_rgchDir + ich) == 0)
				{
					strncpy(m_rgchDir + ich, "\\Src\\TESO\\Test\\", sizeof(m_rgchDir) - ich);
					m_rgchDir[sizeof(m_rgchDir) - 1] = 0;	// be very paranoid again.
				}
			}
		}

		/*--------------------------------------------------------------------------------------
			
		--------------------------------------------------------------------------------------*/
		virtual void SuiteTeardown()
		{
		}
	};
}

#endif /*TESTSCSCRIPTURETEXT_H_INCLUDED*/

// Local Variables:
// mode:C++
// compile-command:"cmd.exe /e:4096 /c c:\\FW\\Bin\\mkteso-tst.bat DONTRUN"
// End: (These 4 lines are useful to Steve McConnel.)
/*:End Ignore*/
