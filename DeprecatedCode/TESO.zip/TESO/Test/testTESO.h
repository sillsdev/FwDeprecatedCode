/*
1. create ECProject
2. add file to ECProject (->AddFileGetEncoding)
3. get safe array from ECProject (->GetAsSafeArray)
4. create ISCScriptureText4 object
5. load ECProject data (->LoadECObjectDataForSOReading)
6. use import sample code to walk through the data
 */
/*--------------------------------------------------------------------*//*:Ignore this sentence.
Copyright (C) 2004 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: testTESO.h
Responsibility:
Last reviewed:

	Global header for unit testing the TESO DLL classes.
-------------------------------------------------------------------------------*//*:End Ignore*/
#ifndef TESTTESO_H_INCLUDED
#define TESTTESO_H_INCLUDED

#pragma once
//#include "stdafx.h"

#define STRICT
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0400
#endif
#define _ATL_APARTMENT_THREADED

#include <atlbase.h>
//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module
extern CComModule _Module;
#include <atlcom.h>

#include <windows.h>

#include <unit++.h>

// Static data shared by various test suites.
//namespace TestFwKernel
//{
//}

// Local Variables:
// mode:C++
// compile-command:"cmd.exe /e:4096 /c c:\\FW\\Bin\\mkteso-tst.bat DONTRUN"
// End: (These 4 lines are useful to Steve McConnel.)

#endif /*TESTTESO_H_INCLUDED*/
