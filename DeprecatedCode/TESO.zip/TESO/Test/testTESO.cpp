/*--------------------------------------------------------------------*//*:Ignore this sentence.
Copyright (C) 2004 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: testTESO.cpp
Responsibility:
Last reviewed:

	Global initialization/cleanup for unit testing the FwKernel DLL classes.
-------------------------------------------------------------------------------*//*:End Ignore*/
#include "testTESO.h"

namespace unitpp
{
	void GlobalSetup(bool verbose)
	{
//		ModuleEntry::DllMain(0, DLL_PROCESS_ATTACH);
		::OleInitialize(NULL);
		// make the compiler happy that there isn't an "unreferenced formal parameter"
		if (verbose)
		{
		}
	}
	void GlobalTeardown()
	{
//		ModuleEntry::DllMain(0, DLL_PROCESS_DETACH);
		::OleUninitialize();
	}
}
