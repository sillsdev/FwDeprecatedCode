//	ExtFileInfo.h : Declaration of the CExtFileInfo class
//
//	Used to contain file data from the .SSF file and to be inserted
//	into the range to file structure in the Scripture Objects.
//
//	Created 7/1/02
//

#ifndef __ExtFileInfo_h__
#define __ExtFileInfo_h__

#include "TraceCreation.h"


DEBUG_TRACECREATION_DECLARE( CExtFileInfo ) //class CExtFileInfo : public CTraceCreation
{
private:
	enum EFI_TYPES { EFI_Unknown=0, EFI_First=0x1, EFI_Last=0x2, 
					 EFI_File=0x4, EFI_Book=0x10, EFI_Chapter=0x20, EFI_Verse=0x40 };

public:

	CExtFileInfo();
	CExtFileInfo( const CExtFileInfo & other );
	~CExtFileInfo();

//	short	IsFirstRefVerse()		{ if ( mFirstRefType == EFI_Verse) return 1; return 0;  }
	bool	IsFirstRefVerse()	{ return mFirstRefType == EFI_Verse; }
	bool	IsFirstRefChapter()	{ return mFirstRefType == EFI_Chapter;  }
	bool	IsFirstRefBook()	{ return mFirstRefType == EFI_Book; }

	bool	IsLastRefVerse()	{ return mLastRefType == EFI_Verse; }
	bool	IsLastRefChapter()	{ return mLastRefType == EFI_Chapter; }
	bool	IsLastRefBook()		{ return mLastRefType == EFI_Book; }

	bool	HasFirstRef()		{ return mAllTypeInfo & EFI_First; }
	bool	HasLastRef()		{ return mAllTypeInfo & EFI_Last; }
	bool	HasFile()			{ return mAllTypeInfo & EFI_File; }

	void	SetFirstVerse	( const wchar_t *ref )	{ SetRef( EFI_First, EFI_Verse	, ref ); }
	void	SetLastVerse	( const wchar_t *ref )	{ SetRef( EFI_Last , EFI_Verse	, ref ); }
	void	SetFirstChapter	( const wchar_t *ref )	{ SetRef( EFI_First, EFI_Chapter, ref ); }
	void	SetLastChapter	( const wchar_t *ref )	{ SetRef( EFI_Last , EFI_Chapter, ref ); }
	void	SetFirstBook	( const wchar_t *ref )	{ SetRef( EFI_First, EFI_Book	, ref ); }
	void	SetLastBook		( const wchar_t *ref )	{ SetRef( EFI_Last , EFI_Book	, ref ); }
	void	SetFile			( const wchar_t *ref )	{ mPath = ::SysAllocString( ref ); mAllTypeInfo |= EFI_File; }

	BSTR	FirstRef()			{ return ::SysAllocString( mFirst ); }
	BSTR	LastRef()			{ return ::SysAllocString( mLast  ); }
	BSTR	File()				{ return ::SysAllocString( mPath  ); }

private:
	void SetRef ( EFI_TYPES firstlast, EFI_TYPES refinfo, const wchar_t *ref );

	BSTR			mFirst, mLast, mPath;
	EFI_TYPES		mFirstRefType, mLastRefType;
	unsigned int	mAllTypeInfo;
	int				mID;
};


#endif
