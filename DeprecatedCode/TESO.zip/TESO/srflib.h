#ifndef SRFLIB_H
#define SRFLIB_H
//#include "esces.h"

// srflib.h - Scripture Reference object
// ESCES: External Scripture Checking Exchange Standard

// A scripture reference is a point in a scripture text.

	enum ScriptureVersificationType {
			unknown, original, septuagint, vulgate, english, 
			russianCanonical, russianOrthodox, svt_other, svt_max};
        // Versification scheme used.
        // New items added to this enumeration should be added at the end to
        // avoid any problems due to previously created persistent data.
		// This data type must be accessible by srfVector too.
		// svt_other maps to SCVersification of scCustom
 
			enum ScriptureReferenceError {
				sre_none = 0, 
				sre_book = 1, 
				sre_chapter = 2, 
				sre_verse = 4, 
				sre_versification = 8, 
				sre_unknown = 16 };
		// Error types for scripture reference types


// ******* Order is important for the following #define statements *******
#define VERSIFICATION_FILES "org.vrs", "lxx.vrs", "vul.vrs", "eng.vrs", "rsc.vrs", "rso.vrs", "oth.vrs"
#define VERSIFICATION_NAMES "Original\r\nSeptuagint\r\nVulgate\r\nEnglish\r\nRussian Cannonical\r\nRussian Orthodox\r\nOther\r\n"
#define VERSIFICATION_TYPES original, septuagint, vulgate, english, russianCanonical, russianOrthodox, svt_other

static int const NUM_VERSIFICATIONS=7;
static int const NUM_BOOKS=99;
static int const SIZE_BOOK_NAME=3;
static int const MAX_SIZE_CHAPTER_NUM=3;
static int const MAX_SIZE_VERSE_NUM=3;
static int const BASE=10;

//#define VERSIF_INDEX_FILE _TSTRING("Cv.ptt")
//#define VERSIF_DATA_FILE _TSTRING("Cvchange.ptt")
#define REFERENCE_SEPARATOR_STRING _TSTRING(":")
static char * const REFERENCE_SEPARATOR = ":";
static char const REFERENCE_SEPARATOR_CHAR = ':';
#define EMPTY_STRING _TSTRING("")
#define RANGE_SEPARATOR_STRING _TSTRING(RANGE_SEPARATOR)
static int const RESIZE=2;



static int const BOOK=0;
static int const CHAPTER=1;
static int const VERSE=2;


static char* const SECONDARY_REFERENCE_SEPARATOR=".";
static char const SECONDARY_REFERENCE_SEPARATOR_CHAR='.';

static char* const CHAPTER_END=";";
static char const CHAPTER_END_CHAR=';';

static char* const VERSE_SEPARATOR=",";
static char const VERSE_SEPARATOR_CHAR=',';

static char* const RANGE_SEPARATOR="-";
static char const RANGE_SEPARATOR_CHAR='-';


class ScriptureReference  {

	friend class ScriptureReferenceVector;

public:
	enum FoundVerseRef { VR_INVALID, VR_NONE, VR_PORTION, VR_ALL, VR_SMALLER, VR_LARGER };

private:
    unsigned char m_cBook;        // GEN = 1, EXO = 2, ... BLT=92=NUM_BOOKS
    unsigned char m_cChapter;     // 0, [material before first chapter], 1, 2, ...
    unsigned char m_cVerse;       // 0 [material before first verse], 1, ...
    unsigned char m_cSegmentAndVersification;
        // Most significant 5 bits = segment number
        //    0..31 Used by the scripture text object to track the individual
        //    segments that a verse may be broken into [heading, verse text, notes].
        // Least significant 3 bits = versification scheme
        //    See ScriptureVersificationType

	unsigned char m_Error;
	// cumalative errors after passing through 'valid' methods

	CComBSTR m_ErrorDesc;
	// string of error descriptions

	bool bSimpleLessThan(const ScriptureReference& srf) const;
	// precedential book, chapter, verse comparison

	int iLastChapter(int iBook, ScriptureVersificationType iVers) const;
	// Answers the last chapter for the specified book and versification
	int iLastVerse(int iBook, int iChapter, ScriptureVersificationType iVers) const;

	ScriptureReference srfMapVersification(
		ScriptureReference srf,
		const ScriptureVersificationType svtTo) const;

public:
	static void ReadAllVersificationFiles(char* pszBaseDirectory);

	static void ReadVersificationFile(
								char* pszFileName,
								ScriptureVersificationType svtVersification,
								char* perrors,
								int perrorsSize);
    ScriptureReference(
        const char* pszRefernce, 
        ScriptureVersificationType svtVersification = unknown);
        // Generate a scripture reference point from a string
        // of the form 
        //    [ ]*[1-4A-Za-z][3A-Za-z][2A-Za-z][ ]+[0-9]*[ ]*([<punctuation]+[ ]*[0-9]*)
        // where "*" means "0 or more" and "+" means "1 or more"
        // following each type of character in brackets.
        // (e.g. "  GeN  12 : 34 ")
        // Conversion stops at last digit of verse number.
        // Any punctuation(s) may separate chapter number from verse number. 
        // ? we should more clearly enumerate punctuation?

        // If the chapter is not specified, it will be set to 1, if the verse is not 
        // specified it will be set to 1.  For books with only 1 chapter the
        // chapter number will always be 1 (not 0).  When only 1 number is present
        // and the book only has one chapter, we interpret the number as a verse
        // number.
        
        // If there string does not have valid format, all fields are set to 0
        // and bValid() will answer false.

        // Examples:
        //      GEN 3:11
        //      JUD 5          (= JUD 1:5)
        //      GEN 3          (= GEN 3:1)
        //        S3Y  5 . 3

        // To find the index for a book you can use ScriptureReference("PSA").iBook()

    ScriptureReference(
            int iBook = 0, 
            int iChapter = 1, 
            int iVerse = 1,
            int iSegment = 0,
		    ScriptureVersificationType svtVersification = unknown);
        // The default values specified (iBook==0) give an invalid reference.

	static bool bLoadBookInfo(void);
		// initializes book names as well as chapter and verse limits for the books

	static int iLookupBook(const char* cBookName);
		// given a three-character bookname, it returns the number of that book	

    static const ScriptureReference end(void);
        // creates a valid ScriptureReference representing the end of the text.
        // This reference is greater than any other valid reference.

    // Accessors (Selectors)
    inline int iBook(void) const { return m_cBook; }
    inline int iChapter(void) const { return m_cChapter; }
    inline int iVerse(void) const { return m_cVerse; }
    inline int iSegment(void) const { return (m_cSegmentAndVersification>>3); }
	
	inline unsigned char ErrorStatus(void) const { return m_Error; }
	inline CComBSTR GetErrorDesc() { return m_ErrorDesc; }

		// return the error status

    inline SCTextType sttTextType(void) const 
        { return SCTextType(m_cSegmentAndVersification & 0x07); } 

    inline ScriptureVersificationType svtVersification(void) const 
        { return ScriptureVersificationType(m_cSegmentAndVersification & 0x07); } 

    int iBBCCCVVV(void) { return 1000000*m_cBook + 1000*m_cChapter + m_cVerse; }


    // Modifiers 
    inline void Book(int iBook) {m_cBook=static_cast<unsigned char>(iBook);}
    inline void Chapter(int iChapter) {m_cChapter=static_cast<unsigned char>(iChapter);} 
    inline void Verse(int iVerse) {m_cVerse=static_cast<unsigned char>(iVerse);}
    void Segment(int iSegment);

    void TextType(SCTextType stt);
        // No validity checking is done for performance reasons.
        // bValid() below may be used to check object.
    void Versification(ScriptureVersificationType svt);
        // No validity checking is done for performance reasons.
        // bValid() below may be used to check object.

    // If the two references differ in their versification,
    // the reference of the lower versification (in the enum type) will be converted
    // to that of the upper.  No conversion is done if either versification is unknown
    // or is other and there has been no table provided for other.  In this case of no
    // conversion, the ordering will be a raw comparison of book, chapter, and verse.
    // Less than means "precedes in the canonically ordered text".

    bool operator==(const ScriptureReference& srf) const;
    bool operator!=(const ScriptureReference& srf) const;
    bool operator<(const ScriptureReference& srf) const;
    bool operator<=(const ScriptureReference& srf) const { return ! (srf<*this); }
    bool operator>(const ScriptureReference& srf) const { return (srf<*this); }
    bool operator>=(const ScriptureReference& srf) const { return ! (*this<srf); }

    ScriptureReference& operator++();
	ScriptureReference& operator++(int) {return ++(*this);}
    // Increments reference by one verse.
    // Incrementing past end of text will yield the end() reference
    // Incrementing past end of chapter or book will cause
    // value to be incremented to first verse of next chapter
    // or book.
    // We never increment to a value containing chapter 0 or verse 0.
	
	// ?ScriptureReference& operator++(int post_fix);?
	ScriptureReference& operator--();
    ScriptureReference& operator--(int) {return --(*this);}
    // Decrements reference by one verse.
    // Decrementing past beginning of text will yeild the 0 book value
    // and cause bValid to return false.
    // Decrementing past beginning of chapter or book will cause
    // value to be decremented to last verse of previous chapter
    // or book.
	// Decrementing End gives End.
    // We never decrement to a value containing chapter 0 or verse 0.
  

    _TSTRING sAsString(char cSeparator=REFERENCE_SEPARATOR_CHAR) const;
        // Convert a scripture reference point to a string of the form
        // GEN 5:13.  Use argument as chapter/verse separator.

    ScriptureReference srfChangeVersification(ScriptureVersificationType iToVersification) const;
        // Create a new scripture reference mapping from the existing to the specified
        // versification.  The segment of the newly created reference will be 0.
		// If either the source or destination is unknown or undefined other a simple
		// mapping will be done. ?check this?

    int iLastBook(void) const;
        // Answers last book number present in current versification scheme.
    int iLastChapter(void) const;
        // Answers last chapter in current book.
		// if Reference is Invalid returns 0
    int iLastVerse(void) const;
        // Answers last verse in current chapter.
		// if Reference is Invalid returns 0
	
	bool bValidSVT(void);
		// True if file for this versification type was read and parsed.

    bool bValid(void) const;
        // True if reference is valid, i.e. has a non zero book number
        // less than or equal iLastBook
        // and chapter/verse exists for current book or is end().

	static const char *cGetBookName(const int iBook);
		// return the three-char equivalent of book number iBook

    static int PARSE_SUCCESS;  // iParse returns this on success

	void trace(char* label) {
		ATLTRACE("srf %s %s(%d)\n", label,
			sAsString().c_str(), svtVersification());
	}

	static const char* GetVerse( const char* txt, int *verse, char *sub );
	static FoundVerseRef ContainsVerse( const char* txt, int verse );

};



// This is a vector of scripture reference points stored in ascending order.
// This is primarily used to create an internal form of the references
// from a word list.

class ScriptureReferenceVector : public vector<ScriptureReference>
{

public:
    ScriptureReferenceVector(void) {;}

    int iParse(const char* pszReferences,  
			char* perrors, // place error message (if any) here.
			int perrorsSize, // length of error buffer.
            ScriptureVersificationType iVersification = english,
            char cComment = '[');
        // Remove any members currently present in vector making vector empty.
        // Parse the string and add verse references found to vector.
        //
        // sReferences syntax:
        //   * = 0 or more, + = 1 or more, ? = 0 or 1
        //   refs := (bookref)+
        //   bookref := XXX (NUM:verserefs)+(;)?
        //   verserefs := verseref ("," verseref)*
        //   verseref := 
        //       NUM |
        //       NUM "-" NUM
        //
        // Whitespace, except that separating bookname and chapter, is ignored.
        // Overlapping intervals (e.g. "GEN 1:3-5,4-7") violate the ascending ordering
        // requirement and are invalid.
        // Chapter and verse numbers may be separated by colons or periods.
        // All other non-letters, non-digits are ignored.
        // If cComment is nonzero, all input characters starting with the 
        // specified character and going to the next newline will be treated
        // as commments and ignored.
        // Returns zero if conversion done successfully.
		// clear operation before adding, only number


    _TSTRING sAsString(void) const;
        // Convert to a text string in above format using ranges to minimize
        // length of string.

    // Rather than provide Set functions for computing Shared References,
    // Adding References, and Removing References (Intersection, Union, and Difference respectively),
    // the user should convert the ScriptureReferenceVector to an STL Set and use
    // the provided functions.

	static int PARSE_SUCCESS;
	// constant to indicate sucess of iParse, public so someone using a ScriptureReference Vetor
	// can tell if their parsing worked.

private:
	bool bParseBookRef(TokenStream &tsRefs, ScriptureVersificationType const iVersification);
	// Extracts book information from the TokenStream and sets up a ScriptureReference to add based on this.

	bool bParseChapterInfo(TokenStream &tsRefs, ScriptureReference &srfToAdd);
	// Extracts Chapter information from TokenStream, eats separating punctuation, and calls
	// parse verse reference...
	
	bool bParseVerseRefs(TokenStream &tsRefs, ScriptureReference &srfToAdd);
	// extracts verse information

};


// Create a predicate to test if a reference has a specified
// text type.  If type is 0, always true.

class TextType_eq: public unary_function<ScriptureReference,bool> {
	SCTextType m_stt;
public:
	explicit TextType_eq(SCTextType stt) : m_stt(stt) {}
	bool operator() (const ScriptureReference& srf) const
	{ if (m_stt == 0) return true; return m_stt & srf.sttTextType(); }
};


#endif  // SRFLIB

