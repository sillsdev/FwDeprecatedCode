// xmlobstr.h  Interface for textual iostreams of objects 

#ifndef XMLOBJIO_H
#define XMLOBJIO_H


#include <string>
#include <cstring>
// ISSUE: I am not supposed to do this here but I don't
// yet understand the alternatives
using namespace std;

typedef int Length;

// This class is derived [aka 'stolen'] from an earlier version written by JAARS to
// work with objects encoded as SFM files.

// These routines are used for persistence, for reading and writing settings files.
// They are designed to make it easy to load and save the variables of an object.
// An object provides a WriteProperties function to write its member variables and 
// bReadProperties routine to read its member variables.

// **************************************************************************

class XMLObjectWriter // Hungarian: obw
{
private:
    ostream& m_ios;  // iostream to which output is written

public:
    XMLObjectWriter(ostream& ios) : m_ios(ios) {}
    ~XMLObjectWriter() {}

    void WriteBeginMarker(const char* pszMarker, 
        bool bWithNL = true, const char* pszName = "");
    void WriteEndMarker(const char* pszMarker);
    void WriteString(const char* pszMarker, const _TSTRING& s);
    void WriteObligatoryString(const char* pszMarker, const _TSTRING& s);
    void WriteChar(const char* pszMarker, char c);
    void Writebool(const char* pszMarker, bool b);
    void WriteInteger(const char* pszMarker, int i);
    
    void WriteNewline();
    void WriteContents(const char* pszContents);
}; // class XMLObjectWriter


// ==========================================================================

// Exception thown by bReadProperties.
class XMLObjectReaderError {
public:
    int m_iLineNum;
    _TSTRING m_sMessage;
};

class XMLObjectReader // Hungarian: obr
{
private:
    istream& m_ios;  // iostream from which input is read
    
    _TSTRING m_sMarker; // beginning of unread marker
    _TSTRING m_sString; // beginning of unread string
    _TSTRING m_sName; // beginning of unread name parameter value

    bool m_bUnRead; // buffer contains a marked string which has been "unread"
    char m_chEndOfLine;  // delimiter for the get-one-line function
    bool m_bStringTooLong;  // 07-26-1997 - TRUE if size of String bigger than 32001 Bytes
    bool bReadMarker(char cFirstChar, const char* pszMarker,
        char cLastChar = 0); // low level read begin or end marker

    int m_iLineNum;  // Line number;
public:
    XMLObjectReader(istream& ios);
    ~XMLObjectReader();

    bool bAtEnd();

    // Read the desired marker followed by the parameter value
    bool bReadMarker(const char* pszMarker, _TSTRING& sName); 
	bool bReadMarkerNameString(const char* pszMarker, _TSTRING &sName, _TSTRING& s);
    bool bReadMarker(const char* pszMarker);
    bool bReadEndMarker(const char* pszMarker);

    bool bReadString(const char* pszMarker, _TSTRING& s); // Read a string

    // Read a boolean. The presence of the marker means TRUE
    bool bReadBool(const char* pszMarker, bool& b); 

    bool bReadInteger(const char* pszMarker, int& i); // Read an integer
    bool bReadDecimal(const char* pszMarker, double& d);
    
    // Read given end marker, stop any begin marker, 
    // for error recovery on objects with unrecognized names AB 1-18-95
    bool bEnd( const char* pszMarker ); 

    void ReadMarkedString(); // Generic eat of one marker and its string
    void UnReadMarkedString(); // Store most recently read marked string for next read

    void ThrowError(const char* pszMessage);

private:
    void Skip(const char* pszChars, bool bInvert = false);
    void GetUpTo(_TSTRING& sString, const char* pszChars);
    bool bEqual(const char* pszMarker);
}; // class XMLObjectReader

#endif // XMOBJIO_H

