// srflib.cpp - Implemenation of Scripture Reference object
// ESCES: External Scripture Checking Exchange Standard

// Revision History
//   CREATED 5/12/98 Dave Murgatroyd
//   REVISED 6/10/98 Dave Murgatroyd
//			Made changes after first implementation review.

#include "stdafx.h"
// function from UtilXml.h in FieldWorks Generic folder
extern long DecodeUtf8(const char * rgchUtf8, int cchUtf8, int & cbOut);
#include "IcuCommon.h"		// ICU header file
namespace StrUtil
{
	extern void InitIcuDataDir();
};

// Standard book name abbreviations

const char *ppszBookNames[] = {"", 
"GEN","EXO","LEV","NUM","DEU","JOS","JDG","RUT","1SA","2SA",
"1KI","2KI","1CH","2CH","EZR","NEH","EST","JOB","PSA","PRO",
"ECC","SNG","ISA","JER","LAM","EZK","DAN","HOS","JOL","AMO",
"OBA","JON","MIC","NAM","HAB","ZEP","HAG","ZEC","MAL","MAT",
"MRK","LUK","JHN","ACT","ROM","1CO","2CO","GAL","EPH","PHP",
"COL","1TH","2TH","1TI","2TI","TIT","PHM","HEB","JAS","1PE",
"2PE","1JN","2JN","3JN","JUD","REV","TOB","JDT","ESG","WIS",
"SIR","BAR","LJE","S3Y","SUS","BEL","1MA","2MA","3MA","4MA",
"1ES","2ES","MAN","PS2","ODA","PSS","JSA","JDB","TBS","SST",
"DNT","BLT","XXA","XXB","XXC","XXD","XXE","XXF","XXG",
"" };

//! add code to ook doe these when parsing 
//const char *ppszVersifcationNames[] = {"",
//"Org ", "LXX ", "Vul ", "Eng ", "Oth ", ""};


// Use to order all references in the LastVerse and LastChapter maps.

class CReferenceLess
{
public:
	bool operator()(const ScriptureReference& a, const ScriptureReference& b) const
	{
		if (a.svtVersification() < b.svtVersification()) return true;
		if (a.svtVersification() > b.svtVersification()) return false;

		if (a.iBook() < b.iBook()) return true;
		if (a.iBook() > b.iBook()) return false;

		if (a.iChapter() < b.iChapter()) return true;
		if (a.iChapter() > b.iChapter()) return false;

		if (a.iVerse() < b.iVerse()) return true;
		return false;
	}
};

// Contains one entry for each book in each versification.
// Chapter 1, verse 1 for each book is present.
// Value is number of chapters in the book.
map<ScriptureReference,int,CReferenceLess> g_mLastChapter;

// Contains one entry for each chapter in each versification.
// Verse 1 for each chapter is present.
// Value is number of verses in the chapter.
map<ScriptureReference,int,CReferenceLess> g_mLastVerse;

// Contains one entry for each "ScriptureVersificationType".
// True if the versification file was successfully read and parsed,
// Fasle otherwise.
std::map<ScriptureVersificationType, bool> g_mValidVersificationFile;


// This is a utility class used to construct the versification
// equivalance mapping.
class ScriptureRange
{
public:
	ScriptureRange() {}
	ScriptureRange(ScriptureReference srf) 
		{ srfFirst = srf; srfLast = srf; }
	ScriptureRange(ScriptureReference srf1, ScriptureReference srf2)
		{ srfFirst = srf1; srfLast = srf2; };

	ScriptureReference srfFirst;
	ScriptureReference srfLast;

	bool operator<(const ScriptureRange& srg) const { 
		if (srfFirst.svtVersification() < srg.srfFirst.svtVersification()) return true;
		if (srfFirst.svtVersification() > srg.srfFirst.svtVersification()) return false;
		return srg.srfLast < srfFirst;
	}

	bool Includes(ScriptureReference srf) { 
		if (srfFirst.svtVersification() != srf.svtVersification()) return false;
		if (srf < srfFirst) return false;
		if (srf > srfLast) return false;
		return true; 
	}

	void trace(char* label) {
		ATLTRACE("srg %s %s(%d) - %s(%d)\n", label,
			srfFirst.sAsString().c_str(), srfFirst.svtVersification(),
			srfLast.sAsString().c_str(), srfLast.svtVersification());
	}
};



typedef multimap<ScriptureRange,ScriptureReference> Versification;
typedef multimap<ScriptureRange,ScriptureReference>::iterator VersificationIterator;

// Map from a range of verses in one versifcation to the start
// of a matching consecutive range of verses in another versification.
// We keep one entry to map from each versifcation to the standard
// versification and a separate entry to map from the standard versification
// to each specific versification.

Versification g_mVers;


// initialize statics for the status of the verse reference parser
int ScriptureReferenceVector::PARSE_SUCCESS=-1;

// ------- Statics--------
static bool const OTHER_UNDEFINED=false;
static int const END_BOOK=NUM_BOOKS+1;

#define SECONDARY_REFERENCE_SEPARATOR_STRING _TSTRING(SECONDARY_REFERENCE_SEPARATOR)
#define CHAPTER_END_STRING _TSTRING(CHAPTER_END)
#define VERSE_SEPARATOR_STRING _TSTRING(VERSE_SEPARATOR)
#define SPACE_STRING _TSTRING(" ");


// Return the directory name for the {FWROOT} settings directory.

long GetFWROOTDirectory(char* strResult, long len) 
{
	// pull out the fieldworks directory
	//  HKEY_LOCAL_MACHINE\SOFTWARE\SIL\FieldWorks the RootDir key. 
	char *strSubkey = "SOFTWARE\\SIL\\FieldWorks";

//	char strResult[256] = {""};
	DWORD iResultLength = len;	// sizeof(strResult);

    HKEY hKey;
    LONG lRet;

    lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE, strSubkey, 0, KEY_QUERY_VALUE, &hKey );
    if ( lRet == ERROR_SUCCESS )
	{
	    lRet = RegQueryValueEx(hKey, "RootDir", NULL, NULL, (LPBYTE) strResult, &iResultLength);
		if ( (lRet == ERROR_SUCCESS) && (iResultLength < (DWORD)len) )
		{
			if (strResult[strlen(strResult)-1] != '\\')
				strcat(strResult, "\\");
		}
	    RegCloseKey( hKey );
	}
	return lRet;
}



// Read the versification information info from all .vrs files.

void ScriptureReference::ReadAllVersificationFiles(char* pszBaseDirectory)
{
	char errorList[18000];
	char perror[4096];
	char name[256];

	char* fileName[] = {VERSIFICATION_FILES , ""};
	ScriptureVersificationType svtNames[] = {VERSIFICATION_TYPES};

	//! add other versifications -- as soon as we know what they are

	perror[0] = 0;
	errorList[0] = 0;

	for (int i=0; *fileName[i]; ++i) {
		strcpy(name, pszBaseDirectory);
		strcat(name, fileName[i]);
		ScriptureReference::ReadVersificationFile(
									name,
									(ScriptureVersificationType)(i+1),
									perror,
									sizeof(perror));

		if (*perror) {		// check and see if it's in the {FWROOT}\Translation Editor" path
			long ret = GetFWROOTDirectory(name, 256);
			if ( !ret ) {
				strcat(name, "Translation editor\\");
				strcat(name, fileName[i]);
				ScriptureReference::ReadVersificationFile(
											name,
											(ScriptureVersificationType)(i+1),
											perror,
											sizeof(perror));
			}
		}

		if (*perror) {
			strcat(errorList, name);
			strcat(errorList, "\n");
			strcat(errorList, perror);
			g_mValidVersificationFile[svtNames[i]] = false;
		}
		else
		{
			g_mValidVersificationFile[svtNames[i]] = true;
		}
	}

	// If any errors, write them to text file.
	if (*errorList) {
		strcpy(name, pszBaseDirectory);
		strcat(name, "versification_file_errors.txt");
		FILE* fp = fopen(name, "w");
		if ( fp )
			fputs(errorList, fp);
		else {
			long ret = GetFWROOTDirectory(name, 256);
			if ( !ret ) {
				strcat(name, "Translation editor\\");
				strcat(name, "versification_file_errors.txt");
				fp = fopen(name, "w");
				if ( fp )
					fputs(errorList, fp);
			}
		}
		if ( fp )
			fclose(fp);
	}

#ifdef _MAXDEBUG
	ScriptureReference srfT(1,1,1,0,septuagint);
	ATLASSERT(srfT.iLastChapter() == 50);
	srfT.Chapter(3);
	ATLASSERT(srfT.iLastVerse() == 24);

	ScriptureReference srfA("PSA 20:2", english);
	ScriptureReference srfB("PSA 19:3", septuagint);
	srfA = srfA.srfChangeVersification(septuagint);
	ATLASSERT(srfA == srfB);
#endif
}


void ScriptureReference::ReadVersificationFile(
								char* pszFileName,
								ScriptureVersificationType svtVersification,
								char* perrors,
								int perrorsSize)
{
	char inp[4096];
	ScriptureReferenceVector srv1;
	ScriptureReferenceVector srv2;
	ScriptureReference srf;
	char err[4096];
	unsigned int i;
	ScriptureRange srg;

#define ERR(x) if (strlen(perrors) + strlen(x) < (unsigned int)perrorsSize) strcat(perrors, x)

	*perrors = 0;

	FILE* fp = fopen(pszFileName, "r");
	if (fp == NULL) { ERR("Cant open: "); ERR(pszFileName); return; }

	while (fgets(inp, sizeof(inp), fp) != NULL) {
		if (inp[0] == '#') continue;

		char* p = strchr(inp, '=');
		if (p == NULL) {
			// This is a book/chapter/verse line
			srv1.iParse(inp, err, sizeof(err), svtVersification, '#');
			if (*err) { ERR("Could not parse line:\n"); ERR(err); continue; }
			for (i=0; i<srv1.size(); ++i) {
				srf = srv1[i];
				srf.Verse(1);
				g_mLastVerse[srf] = srv1[i].iVerse();

				if (i == srv1.size()-1) {
					srf.Chapter(1);
					g_mLastChapter[srf] = srv1[i].iChapter();
					//ATLTRACE("LastChapter %s = %d\n", srf.sAsString().c_str(), srv1[i].iChapter());
				}
			}
		}
		else {
			// This is a versification mapping line
			*p = 0;
			srv1.iParse(inp, err, sizeof(err), svtVersification, '#');
			//ATLTRACE("srv1 = %s\n", srv1.sAsString().c_str());
			*p = '=';
			if (*err) { ERR("Could not parse line:\n"); ERR(inp); continue; }
			srv2.iParse(p+1, err, sizeof(err), unknown, '#');
			//ATLTRACE("srv2 = %s\n", srv2.sAsString().c_str());
			if (*err) { ERR("Could not parse line:\n"); ERR(inp); continue; }
			if (srv1.size() != srv2.size())
				{ ERR("Unequal number of verses:\n"); ERR(inp); continue; }
			if (srv1.size() == 0)
				{ ERR("No verses found:\n"); ERR(inp); continue; }

			srg.srfFirst = srv1[0];
			srg.srfLast = srv1[srv1.size()-1];

#ifdef _MAXDEBUG
			if (srg.srfLast.iVerse() > srg.srfLast.iLastVerse()) {
				srg.srfLast.trace("");
				int n = srg.srfLast.iLastVerse();
				ATLTRACE("line = %s\n", inp);
				ATLTRACE("%s n=%d\n", pszFileName, n);
				ATLASSERT(false);
			}
#endif

			g_mVers.insert(multimap<ScriptureRange,ScriptureReference>::value_type(srg, srv2[0]));
			//srg.trace("from"); srv2[0].trace("to");

			srg.srfFirst = srv2[0];
			srg.srfLast = srv2[srv2.size()-1];

			//srg.trace("from"); srv1[0].trace("to");
			multimap<ScriptureRange,ScriptureReference>::value_type abc(srg, srv1[0]);
			g_mVers.insert(abc);
		}
	}

	fclose(fp);
}


ScriptureReference ScriptureReference::srfMapVersification(
	ScriptureReference srf,
	const ScriptureVersificationType svtTo) const
{
	VersificationIterator p;
	ScriptureReference srfOut;

	// Look for an entry with the specified range.
	p = g_mVers.find(srf);
	while (p != g_mVers.end()) {
		ScriptureRange srg = p->first;
		ScriptureReference srfTo = p->second;
		if (!srg.Includes(srf)) break;

		if (srfTo.svtVersification() == svtTo) {
			// We found the versification we were looking for.
			// Adjust the verse number based on difference between
			// input and start of this range.
			srfOut = srfTo;
			srfOut.Verse(srfTo.iVerse() + srf.iVerse() - srg.srfFirst.iVerse());
			return srfOut;
		}
		++p;
	}

	// Nothing found, output = input with new versification
	srfOut = srf;
	srfOut.Versification(svtTo);
	return srfOut;
}


// Create a new scripture reference mapping from the existing to the specified
// versification.  The segment of the newly created reference will be 0.
ScriptureReference ScriptureReference::srfChangeVersification(const ScriptureVersificationType svtTo) const
{
	ScriptureVersificationType svtFrom=svtVersification();
	if (svtTo == svtFrom)
		return *this;

	// Map to the default versification and then from the default 
	// to the desired versification
	ScriptureReference srfTemp = srfMapVersification(*this, unknown);
	ScriptureReference srfOut = srfMapVersification(srfTemp, svtTo);

	return srfOut;
}
	
	

// The default values specified for this constructor (iBook==0) give an invalid reference.

ScriptureReference::ScriptureReference(int iBook, int iChapter, int iVerse, 
	int iSegment, ScriptureVersificationType iVersification)
	: m_cBook(iBook), m_cChapter(iChapter), m_cVerse(iVerse), m_Error(sre_none)
{
	StrUtil::InitIcuDataDir();
	Segment(iSegment);
	Versification(iVersification);
}

// Generate a scripture reference point from a string
// of the form 
//    [ ]*[1-4A-Z,a-z][3A-Z,a-z][2A-Z,a-z][ ]+[0-9]*[ ]*([<punctuation]+[ ]*[0-9]*)
// where "*" means "0 or more" and "+" means "1 or more"
// following each type of character in brackets.
ScriptureReference::ScriptureReference(const char * pszReference,  
									   ScriptureVersificationType svtVersification) 
									   : m_Error(sre_none)
{	
	StrUtil::InitIcuDataDir();
	Segment(0);
	Versification(svtVersification);
	TokenStream tsRefs(pszReference);
	Book(0);
	Chapter(0);
	Verse(0);
		
	// get book
	_TSTRING sBook = tsRefs.sPeek();
	int iBookNum = ScriptureReference::iLookupBook(sBook.data());
	if (iBookNum == 0)
		return;
	sBook = tsRefs.sNext();
	m_cBook = iBookNum;

	int iChap = tsRefs.iPeek();
	if (iChap == TokenStream::INVALID)
	{
		// if no chapter is specified -> chapter=1
		m_cChapter = 1;
	}
	else
	{
		m_cChapter = iChap;
		_TSTRING sTemp = tsRefs.sNext();
	}

	_TSTRING sPunct = tsRefs.sPeek();
	int iPunct = 0;
	if (sPunct[iPunct] != 0)
		sPunct = tsRefs.sNext();
	const char * pchPunct = sPunct.c_str();
	int cchPunct = sPunct.length();
	while (iPunct < cchPunct)
	{
		int cchUsed;
		UChar32 ch = DecodeUtf8(pchPunct + iPunct, cchPunct - iPunct, cchUsed);
		if (ch == 0 || cchUsed == 0)
			break;
		if (!u_ispunct(ch))
		{
			m_cVerse = 1;
			return;
		}
		iPunct += cchUsed;
	}

	int iVerse = tsRefs.iPeek(true);	// should pass bool true as parameter value
	if (iVerse == TokenStream::INVALID)
	{
		// if no chapter is specified -> chapter=1
		if (iLastChapter(m_cBook, svtVersification) != 1)
		{
			// if no verse is specified and there is no versification or 
			// more than one chapter -> verse=1
			m_cVerse = 1;
		}
		else
		{
			// if there is only one chapter, then the verse is what we thought the chapter
			// number was
			m_cVerse = m_cChapter;
			m_cChapter = 1;
			_TSTRING sTemp = tsRefs.sNext();
		}
	}
	else
	{
		m_cVerse = iVerse;
		_TSTRING sTemp = tsRefs.sNext();
	}

	// If there string does not have valid format, all fields are set to 0
	// and bValid() will answer false.
	if (!bValid())
	{
		m_cBook = 0;
		m_cChapter = 0;
		m_cVerse = 0;
		// Segmentation is already 0.
		Versification(unknown);
	}

}
    
// the lone distinguishing feature of end is that the book is END_BOOK
const ScriptureReference ScriptureReference::end(void)
{
	return ScriptureReference(END_BOOK);
}

int ScriptureReference::iLookupBook(const char* pszBookName)
{    // GEN indexed at book 1
	int j=0;

	// passed in length is not of the correct length
	if (SIZE_BOOK_NAME != strlen(pszBookName))
		return 0;

	// put book name in buffer to ensure upper case
	char *pszTemp=new char[strlen(pszBookName)+1];
	_tcscpy(pszTemp, pszBookName);
	_tcsupr(pszTemp);

	for (int i=1; i<=NUM_BOOKS; i++)
		if (strcmp(ppszBookNames[i], pszTemp)==0) {
			delete [] pszTemp;
			return i;
		}

	delete [] pszTemp;
	return 0;
}

// No validity checking is done for performance reasons.
// bValid() may be used to check object.
void ScriptureReference::Segment(int iSegment)
{
	ScriptureVersificationType svtThis=this->svtVersification();
	m_cSegmentAndVersification=(iSegment<<3)+int(svtThis & 0x07);
}

void ScriptureReference::Versification(ScriptureVersificationType svtNew)
{
	int iThisSegment=this->iSegment();
	m_cSegmentAndVersification=(iThisSegment<<3)+int(svtNew & 0x07);
}
   
void ScriptureReference::TextType(SCTextType sttNew)
{
	int iThisSegment=this->iSegment();
	m_cSegmentAndVersification=(iThisSegment<<3)+int(sttNew & 0x07);
}
   
// bSimpleLessThan used to do versification-blind comparison of two 
// Scirpture References.  Called after Versifications have been aligned.
bool ScriptureReference::bSimpleLessThan(const ScriptureReference& srf) const
{
	if (m_cBook < srf.m_cBook)
		return true;

	if (m_cBook > srf.m_cBook)
		return false;

	// at this point books are equal

	if (m_cChapter < srf.m_cChapter)
		return true;

	if (m_cChapter > srf.m_cChapter)
		return false;

	// at this point chapters are equal

	if (m_cVerse < srf.m_cVerse)
		return true;

	return false;
}

// If the two references differ in their versification,
// they are mapped to the higher versification before the
// comparison is made.  Less than means "precedes in the
// canonically ordered text".
bool ScriptureReference::operator<(const ScriptureReference& srf) const
{ 
	ScriptureVersificationType svtRightVers=srf.svtVersification();
	ScriptureVersificationType svtLeftVers=svtVersification();

	if (svtLeftVers==svtRightVers)
		return bSimpleLessThan(srf);

	// if either versification is unkown, or an undefined svt_other do a simple less than
	if (((svtLeftVers==unknown) || (svtRightVers==unknown)) ||
		(OTHER_UNDEFINED && ((svtLeftVers==svt_other) || (svtRightVers==svt_other))))
		return bSimpleLessThan(srf);
	//otherwise map the lower to the higher versification and compare
	if (svtLeftVers>svtRightVers)
		{
			ScriptureReference srfTemp=srf.srfChangeVersification(svtLeftVers);
			return bSimpleLessThan(srfTemp);
		}
	else
		{
			ScriptureReference srfTemp=srfChangeVersification(svtRightVers);
			return srfTemp.bSimpleLessThan(*this);
		}
}

 // Convert a scripture reference point to a string of the form
 // GEN 5:13.  Use argument as chapter/verse separator.
_TSTRING ScriptureReference::sAsString(const char cSeparator) const
{
	//if (!bValid())
	//	return EMPTY_STRING;
	int iIndex=0;

	char cReturn[32]; // This can get big if chapter/verse is bad

	if (m_cBook >= 1 && m_cBook <= NUM_BOOKS)
		strncpy(cReturn,ppszBookNames[m_cBook],SIZE_BOOK_NAME);
	else
		strcpy(cReturn, "***");

	iIndex=SIZE_BOOK_NAME;
	cReturn[iIndex++]=' ';
	char chap[16];
	char verse[16];
	_itot((m_cChapter), chap, BASE);
	_itot((m_cVerse), verse, BASE);

	strncpy(&cReturn[iIndex], chap, strlen(chap));
	iIndex+=strlen(chap);
	cReturn[iIndex++]=cSeparator;

	strcpy(&cReturn[iIndex], verse);
	iIndex+=strlen(verse);
	return _TSTRING(cReturn);
}



bool ScriptureReference::operator==(const ScriptureReference& srf) const
{
	ScriptureVersificationType svtLeftVers = svtVersification();
	ScriptureVersificationType svtRightVers = srf.svtVersification();
	// if either versification is unkown, or an undefined svt_other do a simple less than
	if (((svtLeftVers==unknown) || (svtRightVers==unknown)) ||
		(OTHER_UNDEFINED && 
		((svtLeftVers==svt_other) || (svtRightVers==svt_other))))
		return ((m_cBook==srf.m_cBook) && (m_cChapter==srf.m_cChapter) && (m_cVerse==srf.m_cVerse));
	ScriptureReference srfA(*this), srfB(srf);
	if (svtLeftVers!=svtRightVers)
		if (svtLeftVers>svtRightVers)
			srfB=srf.srfChangeVersification(svtLeftVers);
		else
			srfA=srfChangeVersification(svtRightVers);
	return ((srfA.m_cBook==srfB.m_cBook) && (srfA.m_cChapter==srfB.m_cChapter) &&
			(srfA.m_cVerse==srfB.m_cVerse) && (srfA.m_cSegmentAndVersification==srfB.m_cSegmentAndVersification));
}

bool ScriptureReference::operator!=(const ScriptureReference& srf) const
{
	ScriptureVersificationType svtLeftVers = svtVersification();
	ScriptureVersificationType svtRightVers = srf.svtVersification();
	if (((svtLeftVers==unknown) || (svtRightVers==unknown)) ||
		(OTHER_UNDEFINED && 
		((svtLeftVers==svt_other) || (svtRightVers==svt_other))))
		return ((m_cBook!=srf.m_cBook) || (m_cChapter!=srf.m_cChapter) || (m_cVerse!=srf.m_cVerse));
	if (svtLeftVers!=svtRightVers)
		if (svtLeftVers>svtRightVers)
			srf.srfChangeVersification(svtLeftVers);
		else
			srfChangeVersification(svtRightVers);
	return ((m_cBook!=srf.m_cBook) || (m_cChapter!=srf.m_cChapter) ||
			(m_cVerse!=srf.m_cVerse));
	// no segment comparison
}

// Increments verse in current chapter based on srt.
// Incrementing past end of text will yeild the End reference
// Incrementing past end of chapter or book will cause
// value to be incremented to first verse of next chapter
// or book.
ScriptureReference& ScriptureReference::operator++()
{ 
	
	if (!bValid()) {
		ATLASSERT(false /* versification not set */);
		return *this;
	}

	ScriptureVersificationType svtThisVers = svtVersification();
	if (m_cVerse >= iLastVerse(m_cBook, m_cChapter, svtThisVers))
	{
		if (m_cChapter<iLastChapter(m_cBook, svtThisVers))
		{
			m_cVerse=1;
			m_cChapter++;
		}
		else 
			if (m_cBook<NUM_BOOKS)
			{
		  		m_cVerse=1;
				m_cChapter=1; // we're guarteened no 0 chapter
				m_cBook++;
			}
			else 
				*this=end();	
	}
	else	
		m_cVerse++;

	return *this;
}

// Decrements reference by one verse.
// Decrementing past beginning of text will yeild the 0 book value
// and cause bValid to return false.
// Decrementing past beginning of chapter or book will cause
// value to be decremented to last verse of previous chapter
// or book.
// We never decrement to a value containing chapter 0 or verse 0.
ScriptureReference& ScriptureReference::operator--()
{ 
	if (!bValid())
		return *this;
	if (m_cBook==END_BOOK)
	{
		m_cBook=NUM_BOOKS;
		m_cChapter=iLastChapter(m_cBook, svtVersification());
		m_cVerse=iLastVerse(m_cBook, m_cChapter, svtVersification());
		return *this;
	}
	if (m_cVerse <= 1)
	{
		if (m_cChapter>1)
		{
			m_cChapter--;
			m_cVerse=iLastVerse(m_cBook, m_cChapter, svtVersification());
		}
		else 
			if (m_cBook>1)
			{
				m_cBook--;
				m_cChapter=iLastChapter(m_cBook, svtVersification()); 
				m_cVerse=iLastVerse(m_cBook, m_cChapter, svtVersification());
			}
			else
				m_cBook=0; // have tried to decrement past beginning
	}
	else	
		m_cVerse--;
	return *this;
}
 
  
int ScriptureReference::iLastBook() const
{
	return NUM_BOOKS;
}


int ScriptureReference::iLastChapter() const
{
	// If not valid -- assume only 1 chapter
	if (!bValid())
		return 1;   

	return iLastChapter(m_cBook, svtVersification());
}


int ScriptureReference::iLastChapter(int iBook, ScriptureVersificationType iVers) const
{
	int n = g_mLastChapter[ScriptureReference(iBook, 1, 1, 0, iVers)];
	// Always answer that at least 1 chapter is present
	return n > 0 ? n : 1;
}



int ScriptureReference::iLastVerse() const
{
	// If not valid -- assume only 1 verse
	if (!bValid())
		return 1;
	return iLastVerse(m_cBook, m_cChapter, svtVersification());
}

    // Answers last book number present in current text,
    // last chapter in current book, or
    // last verse in current chapter based on srt.
    // Ex: srfStart.Last(ScriptureReferenceType::verse);


int ScriptureReference::iLastVerse(int iBook, int iChapter, ScriptureVersificationType iVers) const
{
	ScriptureReference srf(iBook, iChapter, 1, 0, iVers);
	int n = g_mLastVerse[srf];

	// Always answer that at least 1 verse is present
	return n > 0 ? n : 1;
}


bool ScriptureReference::bValidSVT(void)
{
	m_Error = sre_none;
	m_ErrorDesc = L"";
	ScriptureVersificationType svt=svtVersification();

	if (svt >= svt_max || !g_mValidVersificationFile[svt])
	{
		ATLTRACE("ScriptureReference::bValidSVT --> svt=[%d] ", svt );
		if ( svt < svt_max )
			ATLTRACE(" ValidVersificationFile=[%d]", g_mValidVersificationFile[svt]);
		
		ATLTRACE("\n");
		m_Error |= sre_versification;
		
		// get the versification file name for the error description
		{
			int index = -1;
			ScriptureVersificationType svtNames[] = {VERSIFICATION_TYPES};
			for (int i=0; i<NUM_VERSIFICATIONS; i++)
			{
				if (svtNames[i] == svt)
				{
					index = i;
					break;
				}
			}
			ATLASSERT(index != -1);
				
			char* fileName[] = {VERSIFICATION_FILES , ""};
			m_ErrorDesc += fileName[index];
		}
	}
	m_ErrorDesc += L",";

	if ((m_cBook<=0) ||	((m_cBook>NUM_BOOKS) && (*this!=end())))
		m_Error |= sre_book;
	m_ErrorDesc += L",";

	if (m_cChapter<0)
		m_Error |= sre_chapter;
	m_ErrorDesc += L",";

	if (m_cVerse<0)
		m_Error |= sre_verse;

	return m_Error == sre_none;
}


bool ScriptureReference::bValid(void) const
{
	ScriptureVersificationType svt=svtVersification();
	if (svt >= svt_max)
		return false;

	if (m_cBook==0 || m_cBook==0xff)
		return false;

	if ((m_cBook>NUM_BOOKS) && (*this!=end()))
		return false;

	if (m_cChapter==0xff)
		return false;

	if (m_cVerse==0xff)
		return false;

	//The following lines cause trouble whenever the versification info
	//is not exacly right.  Should we include them?
	//if (m_cChapter>iLastChapter(m_cBook, iVers))
	//	return false;
	//if (m_cVerse>iLastVerse(m_cBook, m_cChapter, iVers))
	//	return false;
	return true;
}
    // True if reference is valid, i.e. has a non zero book number
    // and chapter/verse exists for book.

 // Remove any members currently present in vector making vector empty.
 // Parse the string and add verse references found to vector.
 //
 // sReferences syntax:
 //   * = 0 or more, + = 1 or more, ? = 0 or 1
 //   refs := (bookref)+
 //   bookref := XXX (NUM:verserefs)+
 //   verserefs := verseref ("," verseref)*
 //   verseref := 
 //       NUM |
 //       NUM "-" NUM
 //

// PARSE_CONT - try to find another one
// PARSE_STOP - end of element reached
// otherwise - position of error

class ParseError {
public:
	char* m_pMsg;

	ParseError(char* pMsg) {
		m_pMsg = pMsg;
	}
};

int ScriptureReferenceVector::iParse(
                                     const char* pszReferences, 
									 char* perrors,
									 int perrorsSize,
                                     ScriptureVersificationType iVersification, 
                                     char cComment)
// Answer PARSE_SUCCESS or position of error.
{
	clear();
	TokenStream tsRefs(pszReferences, cComment);
	int i;

    //! parse the optional versification word
    //! also add this code single verse reference parser

	*perrors = 0;

    try {
        while (bParseBookRef(tsRefs, iVersification)) {}
    } 
    catch(ParseError e) {
		i = tsRefs.iPos();
		ERR(e.m_pMsg);
		goto ReportError;
	}

    // If we made it all the way to the end the parse was successful,
    // otherwise there was an error: return the index...
    if (tsRefs.bAtEnd())
		return PARSE_SUCCESS;

	i = tsRefs.iPos();
	ERR("Could not complete parse ");

ReportError:
	ERR("(Error is near -$-)");
	_TSTRING s = pszReferences;
	ERR(s.substr(0,i).c_str());
	ERR("$");
	if ((unsigned int)i < s.length())
		ERR(s.substr(i).c_str());

	return i;
}


bool ScriptureReferenceVector::bParseBookRef(TokenStream &tsRefs, ScriptureVersificationType const iVersification)
    // Parse all the entries for a single book.
    // Answer true if any found.
    // Answer false if we are at the end of the string.
    // Otherwise throw an error.
{
	ScriptureReference srfToAdd;
	srfToAdd.Versification(iVersification);

	// If no more text, we are done.
	_TSTRING sBook=tsRefs.sPeek();
    if (sBook == EMPTY_STRING) {
	    tsRefs.sNext();
		return false;
    }

    // Get the book name, throw an error if invalid
    int iBookNum=ScriptureReference::iLookupBook(sBook.data());
	if (iBookNum==0)
		throw ParseError("Invalid book name");
	tsRefs.sNext();
	srfToAdd.Book(iBookNum);

    // Parse chapter/verse entries, must be at least one.
    if (! bParseChapterInfo(tsRefs, srfToAdd))
        throw ParseError("Book name without any chapter/verse references");
    do {
        // Skip chapter end string if present
	    if (tsRefs.sPeek()==_TSTRING(CHAPTER_END))
		    tsRefs.sNext();
    }
    while ( bParseChapterInfo(tsRefs, srfToAdd) );

    return true;
}

/*----------------------------------------------------------------------------------------------
	Parse entry of form -- CCC:VVV[-VVV],VVV[-VVV] ...
	If string does not begin with CCC, answer false.
	Otherwise, if string does not have at least CCC:VVV throw an error.
	Answer true if at least CCC:VVV found
----------------------------------------------------------------------------------------------*/
bool ScriptureReferenceVector::bParseChapterInfo(TokenStream & tsRefs,
	ScriptureReference & srfToAdd)
{
	// get chapter
	int iChap = tsRefs.iPeek();
	if (iChap == TokenStream::INVALID)
		return false;
	tsRefs.sNext();

    srfToAdd.Chapter(iChap);

	// get punctuation
	_TSTRING sPunct = tsRefs.sNext();
	if (sPunct[0] == 0)
		throw ParseError("Punctuation missing following chapter number");

    int iPunct = 0;
	const char * pchPunct = sPunct.c_str();
	int cchPunct = sPunct.length();
	while (iPunct < cchPunct)
	{
		int cchUsed;
		UChar32 ch = DecodeUtf8(pchPunct + iPunct, cchPunct - iPunct, cchUsed);
		if (ch == 0 || cchUsed == 0)
			break;
		if (!u_ispunct(ch))
			throw ParseError("Invalid punctuation after chapter number");
		iPunct += cchUsed;
	}

    // There must be at least one verse or verse range.
	if (!bParseVerseRefs(tsRefs, srfToAdd))
        throw ParseError("No verses present after chapter number");

    // As long as there is another ',' there must be another verse or verse range.
    while (tsRefs.sPeek() == VERSE_SEPARATOR_STRING) 
	{
		tsRefs.sNext();
        if (!bParseVerseRefs(tsRefs, srfToAdd))
            throw ParseError("No verse number following verse number separator");
    }

    return true;
}

/*----------------------------------------------------------------------------------------------
	Parse entry of form -- VVV[-VVV]
----------------------------------------------------------------------------------------------*/
bool ScriptureReferenceVector::bParseVerseRefs(TokenStream & tsRefs,
	ScriptureReference & srfToAdd)
{
	int iTo;

	// get verse
	int iVerse = tsRefs.iPeek();
	if (iVerse == TokenStream::INVALID)
		return false;
	tsRefs.sNext();

	srfToAdd.Verse(iVerse);

	push_back(srfToAdd);
	
	// insert verse if it is valid and in ascending sequence.
	//if ((srfToAdd.bValid()) && (empty() || true /* (back() <= srfToAdd) */ ))
	//	push_back(srfToAdd);
	//else
	//	throw ParseError();

	// check for range
	_TSTRING s = tsRefs.sPeek();
	int cchUsed;
	long ch = DecodeUtf8(s.data(), s.length(), cchUsed);
	if (cchUsed == s.length() && u_hasBinaryProperty(ch, UCHAR_DASH))
	{ // interval
		tsRefs.sNext();  // move past RANGE_SEPARATOR
		ScriptureReference srf = srfToAdd;
		srf.Verse(srf.iVerse() + 1);
		ScriptureReference srfLimit = srfToAdd;

		iTo = tsRefs.iPeek();
		if (iTo == TokenStream::INVALID)
			throw ParseError("Invalid verse number");
		tsRefs.sNext();    // consume chapter or verse number

		if (tsRefs.sPeek() == REFERENCE_SEPARATOR)
		{   // if we just saw a chapter number
			tsRefs.sNext();  // consume :
			srfLimit.Chapter(iTo);  // set chapter and verse numbers
			iTo=tsRefs.iPeek();
			if (iTo==TokenStream::INVALID)
				throw ParseError("Invalid verse number");
			srfLimit.Verse(iTo);
			tsRefs.sNext();   // consume verse number
		}
		else
		{
			srfLimit.Verse(iTo);   // no chapter number, just set verse
		}

		if (srf > srfLimit /*|| !srf.bValid()*/)
		{
			throw ParseError("Range is backward, e.g. 10-8");
		}

		while (srf.iVerse() <= srfLimit.iVerse())
		{ // insert the verses in the interval
			push_back(srf);
			//if (empty() || (back() <= srf))
			//	push_back(srf);
			//else // out of order or invalid
			//	throw ParseError();
			srf.Verse(srf.iVerse() + 1);
		}
	}
	
    return true;
}

// Convert to a text string in above format using ranges to minimize
// length of string.
_TSTRING ScriptureReferenceVector::sAsString(void) const
{
	long iSize=size();
	_TSTRING sToReturn;
	int iCurBook=0;
	int iPrevBook=0;
	int iCurChap=0;
	int iPrevChap=0;
	int iCurVerse=0;
	int iPrevVerse=0;
	bool bInSeq=false;
	bool bPrevInSeq=false;
	bool bInChap=false;
	bool bInBook=false;
	char chap[MAX_SIZE_CHAPTER_NUM+1];
	char verse[MAX_SIZE_VERSE_NUM+1];
	
	for (long i=0; i<iSize; i++)
	{
		iCurBook=(*this)[i].iBook();
		iCurChap=(*this)[i].iChapter();
		iCurVerse=(*this)[i].iVerse();
		
		// check properties as compared to previous
		bInBook=(iCurBook==iPrevBook);
		bInChap=(bInBook && (iCurChap==iPrevChap));
		bInSeq=(bInChap && (iCurVerse==(iPrevVerse+1)));
		
		// insert verse delimiter
		if (bPrevInSeq && !bInSeq) // coming out of sequence
		{
			sToReturn += RANGE_SEPARATOR;
			_itot(iPrevVerse, verse, BASE);
			sToReturn.append(verse);
		}
		if (bInChap && !bInSeq) // separating nonsequenial verses
			sToReturn.append(VERSE_SEPARATOR_STRING);
		if (!bInChap)
		{
				if (bInBook) //separating chapters in the same book
					sToReturn.append(CHAPTER_END_STRING);
				else
				{
					// new book
					if (i!=0)
						sToReturn += ' ';
					sToReturn.append(_TSTRING(ppszBookNames[iCurBook]));
				}
				sToReturn += ' ';
				_itot(iCurChap, chap, BASE);
				sToReturn.append(chap);
				sToReturn.append(REFERENCE_SEPARATOR_STRING);
		}
		if (!bInSeq) 
		{
			_itot(iCurVerse, verse, BASE);
			sToReturn.append(verse);
		}
		iPrevBook=iCurBook;
		iPrevChap=iCurChap;
		iPrevVerse=iCurVerse;
		bPrevInSeq=bInSeq;
	}
	if (bPrevInSeq) // coming out of sequence
	{
			sToReturn += RANGE_SEPARATOR;
			_itot(iCurVerse, verse, BASE);
			sToReturn.append(verse);
	}
	return sToReturn;
}

const char *ScriptureReference::cGetBookName(const int iBook)
{
	return ppszBookNames[iBook];
}


const char * ScriptureReference::GetVerse(const char * txt, int * verse, char * sub)
{
	*verse = -1;
	*sub = '\0';
	int rval = 1;
	// skip white space
	// TODO: HANDLE Unicode/UTF8 properly.
	while ( *txt == ' ' || *txt == '\t' )
		txt++;

	// count the digits
	int ncount = 0;

	// int32_t u_charDigitValue(UChar32 c) returns -1 if invalid, decimal number value otherwise
	const char * pchEnd = txt + strlen(txt);
	int nVerse = 0;
	const char * pch = txt;
	int cchUsed = 0;
	UChar32 ch = 0;
	while (pch && pch < pchEnd && *pch)
	{
		ch = DecodeUtf8(pch, pchEnd - pch, cchUsed);
		pch += cchUsed;
		int32_t nDigit = u_charDigitValue(ch);
		if (nDigit < 0 || nDigit > 9)
			break;
		nVerse = nVerse * 10 + nDigit;
		++ncount;
	}

	if ( ncount == 0 )
	{
//		ATLTRACE("Not numeric verse data <%s>\n", txt);
		return NULL;
	}

	*verse = nVerse;

	ch = DecodeUtf8(pch, pchEnd - pch, cchUsed);
	if (u_isalpha(ch))
	{
		// TODO: handle Unicode/UTF8 chars (that aren't ASCII) properly.
		*sub = static_cast<char>(ch);
		pch += cchUsed;
	}

	return pch;
}

// ContainsVerse( const char* txt, int verse )
// Desc:
//	Look through the 'txt' which should be a verse string and return a value
//	based on if the 'verse' is in the 'txt'.
//
// Return Values: ScriptureReference::FoundVerseRef
//	VR_INVALID	- the 'txt' is invalid in that it desn't define any verses.
//	VR_NONE		- the verse is not contained in any way in the passed in verses
//	VR_PORTION	- the verse is contained in portion, but not in its entirety
//	VR_ALL		- the verse is contained in the passed in verse text
//	VR_SMALLER	- the desired verse is smaller than all the references
//	VR_LARGER	- the desired verse is larger than all the references
//
ScriptureReference::FoundVerseRef ScriptureReference::ContainsVerse(const char* txt, int verse)
{

	ATLTRACE(" -- Looking for verse<%d> in Verse Text<%s> --\n", verse, txt );

	FoundVerseRef rval = VR_INVALID;

	// used for previous sub matches, EX: "5,6a,6b,7,8" looking for v6
	FoundVerseRef history = VR_NONE;

	const char* datap = txt;
	int firstVerse;
	char firstSubVerse;

	bool done = false;
	bool firstTime = true;

	while ( !done )
	{
		datap = GetVerse( datap, &firstVerse, &firstSubVerse );
		
		if ( datap == NULL )
		{
			if ( firstTime )
			{
				ATLTRACE(" -- Not a valid verse --\n" );
				rval = VR_INVALID;		// not a valid verse!!!
			}
			else
			{
				if ( history == VR_SMALLER )
					rval = VR_NONE;
				else if ( history != VR_NONE )
					rval = VR_PORTION;
				else
				{
					ATLTRACE(" -- No match found , INVESTIGATE THIS !! --\n" );
					rval = VR_NONE;			// found verse is to small
				}
			}

			break;
		}

		firstTime = false;

		// ****************************************************************
		// See if the verse in question is less than the first verse
		//
		if ( verse < firstVerse )
		{
			if ( history == VR_ALL )
			{
				rval = VR_ALL;				// found smaller, match(sub) and bigger verses
				break;
			}
			else
			{
				rval = VR_SMALLER;	// NONE;				// found verse is to big
				break;
			}
		}
		// ****************************************************************
		// See if the verse in question is > than the first verse
		//
		else if ( verse > firstVerse )
		{
			history = VR_SMALLER;				// found verse is to small
		}
		// ****************************************************************
		// See if the verse in question equals the found verse
		//
		else if ( firstVerse == verse )
		{
			if ( firstSubVerse == '\0' )	// clean match
			{
				rval = VR_ALL;				// found match
				break;
			}
			else	// check the history of previous possible sub matches
			{
				if ( history == VR_SMALLER )		// last ref was small, could be 'all' 
					history = VR_ALL;		// could be all if ends with > ref
				else if ( history == VR_ALL )
				{
					// alread have seen smaller and previous sub ref
				}
				else
				{
					rval = VR_PORTION;	// best it could be is portion
					break;
				}
			}
		}

		// ****************************************************************
		// keep parsing and looking for more data, need to find valid seperator
		//
		// skip white space
		while ( *datap == ' ' || *datap == '\t' )
			datap++;

		if ( *datap == '\0' )
		{
			rval = VR_LARGER;	// NONE;				// found verse is too small
			break;
		}
		int cchUsed;
		long ch = DecodeUtf8(datap, strlen(datap), cchUsed);
		if (u_hasBinaryProperty(ch, UCHAR_DASH))
		{
			datap += cchUsed;
			int rangeVerse;
			char rangeSubVerse;

			datap = GetVerse( datap, &rangeVerse, &rangeSubVerse );
			if ( rangeSubVerse == '\0' )
			{
				// see if the verse is in the range
				if ( verse >= firstVerse && verse <= rangeVerse )	// in the range
				{
					rval = VR_ALL;
					break;
				}
			}
			else
			{
				// see if the verse is in the range
				if ( verse >= firstVerse && verse < rangeVerse )	// in the range
				{
					rval = VR_ALL;
					break;
				}
			}
		}
		/*else*/	// allow the range to benefit from this if one following a range
		if ( *datap == VERSE_SEPARATOR_CHAR )
		{
			datap++;		// just eat the seperator
		}
	}



	ATLTRACE(" -- Returning ");
	switch ( rval )
	{
	case VR_INVALID:	ATLTRACE(" VR_INVALID\n"); break;
	case VR_NONE:		ATLTRACE(" VR_NONE\n"); break;
	case VR_PORTION:	ATLTRACE(" VR_PORTION\n"); break;
	case VR_ALL:		ATLTRACE(" VR_ALL\n"); break;
	case VR_SMALLER:	ATLTRACE(" VR_SMALLER\n"); break;
	case VR_LARGER:		ATLTRACE(" VR_LARGER\n"); break;
	}

	return rval;
}


