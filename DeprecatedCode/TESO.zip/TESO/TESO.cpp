// TESO.cpp : Implementation of DLL Exports.


// Note: Proxy/Stub Information
//      To build a separate proxy/stub DLL, 
//      run nmake -f TESO.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include "TESO.h"

#include "TESO_i.c"
#include "SCReferenceCollection.h"
#include "SCReference.h"
#include "SCTag.h"
#include "SCTextSegment.h"
#include "SCTextEnum.h"
//#include "SCTextEnumEx.h"
#include "SCScriptureText.h"


CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_SCReferenceCollection, CSCReferenceCollection)
OBJECT_ENTRY(CLSID_SCReference, CSCReference)
OBJECT_ENTRY(CLSID_SCTag, CSCTag)
OBJECT_ENTRY(CLSID_SCTextSegment, CSCTextSegment)
OBJECT_ENTRY(CLSID_SCTextEnum, CSCTextEnum)
//OBJECT_ENTRY(CLSID_SCTextEnumEx, CSCTextEnumEx)
OBJECT_ENTRY(CLSID_SCScriptureText, CSCScriptureText)
END_OBJECT_MAP()

/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        _Module.Init(ObjectMap, hInstance, &LIBID_TESOLib);	// SCRIPTUREOBJECTSLib);
        DisableThreadLibraryCalls(hInstance);
    }
    else if (dwReason == DLL_PROCESS_DETACH)
        _Module.Term();
    return TRUE;    // ok
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
    return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
	ATLTRACE("Here\n");
    return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
    return _Module.UnregisterServer(TRUE);
}


