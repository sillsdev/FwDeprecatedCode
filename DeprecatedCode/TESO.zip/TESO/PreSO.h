// PreSO.h : Declaration of the CPreSO

//:> See ScriptureObjects.idl for interface information about this class


#ifndef __PreSO_H_
#define __PreSO_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CPreSO
class ATL_NO_VTABLE CPreSO : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CPreSO, &CLSID_PreSO>,
	public ISupportErrorInfo,
	public IDispatchImpl<IPreSO, &IID_IPreSO, &LIBID_SCRIPTUREOBJECTSLib>
{
public:
	CPreSO()
	{
		m_cbstrBookMarker = TEXT("\\id");
//		m_stp = SCTextProperties(0);
//		m_stt = SCTextType(0);
//		m_fUnderline = 0;
//		m_fSmallCaps = 0;
//		m_fSubscript = 0;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_PRESO)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CPreSO)
	COM_INTERFACE_ENTRY(IPreSO)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IPreSO
public:

	void FinalRelease() {};

	STDMETHOD(Initialize)(/*[in]*/ BSTR bstrBlob);
	STDMETHOD(Save)(/*[out]*/ BSTR* bstrBlob, /*[out]*/ BSTR* bstrToken);

	STDMETHOD(AddFile)(/*[in]*/ BSTR bstrFileName);			// "fullpath and filename of file"
	
	STDMETHOD(RemoveFile)(/*[in]*/ BSTR bstrFileName);		// "fullpath and filename of file"

	STDMETHOD(get_Files)(/*[out,retval]*/ VARIANT* pSafeArray);	// safearray of strings

	STDMETHOD(get_BookMarker)(/*[out,retval]*/ BSTR* bstrBookMarker);		// "\id"
	STDMETHOD(put_BookMarker)(/*[in]*/ BSTR bstrBookMarker);				// "\id"

	STDMETHOD(NthMapping)(
		/*[in] */ int iIndex, 
		/*[out]*/ BSTR* pbstrMarker,
		/*[out]*/ int* piDomain,
		/*[out]*/ BSTR* pbstrTeStyleName,
		/*[out]*/ BSTR* pbstrEncoding,
		/*[out]*/ boolean* bConfirmed
		);

	STDMETHOD(SetMapping)(
		/*[in]*/ BSTR pbstrMarker,
		/*[in]*/ int piDomain,
		/*[in]*/ BSTR pbstrTeStyleName,
		/*[in]*/ BSTR pbstrEncoding
		);

	STDMETHOD(GetBooksForFile)( 
		/*[in]*/ BSTR bstrFileName,				// "fullpath and filename of file"
		/*[out,retval]*/ VARIANT* pSafeArray	// safearray of shorts where 1 == GEN
		);

private:
	CComBSTR m_cbstrBookMarker;

//    BOOL m_fBold;
//    int m_iColor;
//    CComBSTR m_cbstrDescription;
//    CComBSTR m_cbstrEndmarker;
//    BOOL m_fSuperscript;
//    SCStyleType m_iStyleType;
//    SCTextProperties m_stp;
//    SCTextType m_stt;
};

#endif //__PreSO_H_
