// PreSO.cpp : Implementation of CPreSO
#include "stdafx.h"
#include "PreSO.h"

#include <vector>

/////////////////////////////////////////////////////////////////////////////
// CPreSO

STDMETHODIMP CPreSO::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IPreSO
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


STDMETHODIMP CPreSO::Initialize(/*[in]*/ BSTR bstrBlob)
{
	return S_OK;
}

STDMETHODIMP CPreSO::Save(/*[out]*/ BSTR* bstrBlob, /*[out]*/ BSTR* bstrToken)
{
	CComBSTR tmpBlob = "This will be the blob data in the future...";
	CComBSTR tmpToken = "And this is will be a token...";

	*bstrBlob = tmpBlob.Copy();
	*bstrToken = tmpToken.Copy();

	return S_OK;
}

STDMETHODIMP CPreSO::AddFile(/*[in]*/ BSTR bstrFileName)
{
	CComBSTR tmp;
	tmp = bstrFileName;		// will be put in a map or vector

	return S_OK;
}
	
STDMETHODIMP CPreSO::RemoveFile(/*[in]*/ BSTR bstrFileName)
{
	CComBSTR tmp;
	tmp = bstrFileName;		// will be put removed from internal map or vector

	return S_OK;
}

STDMETHODIMP CPreSO::get_Files(/*[out,retval]*/ VARIANT* pSafeArray)	// safe array of bstrs
{
	return S_OK;
}

STDMETHODIMP CPreSO::get_BookMarker(/*[out,retval]*/ BSTR* bstrBookMarker)
{
	*bstrBookMarker = m_cbstrBookMarker.Copy();
	return S_OK;
}

STDMETHODIMP CPreSO::put_BookMarker(/*[in]*/ BSTR bstrBookMarker)
{
	m_cbstrBookMarker = bstrBookMarker;
	return S_OK;
}

STDMETHODIMP CPreSO::NthMapping(
		/*[in] */ int iIndex, 
		/*[out]*/ BSTR* pbstrMarker,
		/*[out]*/ int* piDomain,
		/*[out]*/ BSTR* pbstrTeStyleName,
		/*[out]*/ BSTR* pbstrEncoding,
		/*[out]*/ boolean* bConfirmed
		)
{
	return S_OK;
}


STDMETHODIMP CPreSO::SetMapping(
		/*[in]*/ BSTR pbstrMarker,
		/*[in]*/ int piDomain,
		/*[in]*/ BSTR pbstrTeStyleName,
		/*[in]*/ BSTR pbstrEncoding
		)
{
	return S_OK;
}


short ScanForBooks( char* pStart, char* pEnd, const char* bookMarker, std::vector<short>& vsiBooks )
{
	short rval = 0;
	char *p;
	char bookName[4];	// three char code plus null

	vsiBooks.clear();

	int bookMarkerLen = strlen(bookMarker);
	
	for (p = pStart; p<pEnd; ++p) {
		if (strncmp(p, bookMarker, bookMarkerLen) != 0) continue;	// look for complete marker

		p += bookMarkerLen;									// update pointer
		if (*p != ' ' && *p != '\t ') continue;				// look for white space
		for (p++; *p == ' ' || *p == '\t'; ++p) {}			// eat any additional white space

		if ( *(p+3) != ' '  && *(p+3) != '\t' &&			// need ws after found book name
			 *(p+3) != 0x0d && *(p+3) != 0x0a ) continue;	//  OR possibly and end of line

		strncpy( bookName, p, bookMarkerLen);
		bookName[3] = '\0';

		int id = ScriptureReference::iLookupBook( bookName );
		
		ATLTRACE("Book Offset %s:%d\n", bookName, id);

		if ( id )
		{
			rval++;
			vsiBooks.push_back( id );
		}
	}

	return rval;
}


STDMETHODIMP CPreSO::GetBooksForFile( 
			/*[in]*/ BSTR bstrFileName,			// "fullpath and filename of file"
			/*[out,retval]*/ VARIANT* pSafeArray
			)
{
	// Show the Browse window looking for ssf files
	//
#if 0
	if ( 0 )		
	{
		BROWSEINFO bi;
		memset( &bi, 0, sizeof( bi ) );

		TCHAR folder[MAX_PATH];
		TCHAR title[] = {"Here's some help text..."};

		bi.pszDisplayName = folder;
		bi.lpszTitle = title;
		bi.ulFlags = BIF_DONTGOBELOWDOMAIN;	// | BIF_NONEWFOLDERBUTTON | ;
		bi.lpfn = BrowseCallbackProc;

		LPITEMIDLIST idl = SHBrowseForFolder( &bi );
	}
#endif

	std::vector<short> vsiBooks;
	HRESULT hr = 0;

	while (1)
	{
		HANDLE hFile;
		BY_HANDLE_FILE_INFORMATION fileData;

		USES_CONVERSION;

		char bookMarker[128];
		strcpy(bookMarker, OLE2A(m_cbstrBookMarker) );

		hFile = CreateFile(OLE2A(bstrFileName),  
						GENERIC_READ,              // open for reading 
						FILE_SHARE_READ,           // share for reading 
						NULL,                      // no security 
						OPEN_EXISTING,             // existing file only 
						FILE_ATTRIBUTE_NORMAL,     // normal file 
						NULL);                     // no attr. template 
 
		if (hFile == INVALID_HANDLE_VALUE) 
			break;

		if (! GetFileInformationByHandle(hFile, &fileData)) {
			CloseHandle(hFile);
			break;
		}

		int nFileSize = (int)fileData.nFileSizeLow;

		// If file is zero size then it clearly contains no markers.
		if (nFileSize == 0) {
			CloseHandle(hFile);
			break;
		}
		
		HANDLE hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
		if (hFileMapping == NULL) {
			CloseHandle(hFile);
			break;
		}

		char* pFile = (char*)MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
		if (pFile == NULL) {
			CloseHandle(hFileMapping);
			CloseHandle(hFile);
			break;
		}

		char* pEnd = pFile + nFileSize - 1;
		short numbooks = ScanForBooks( pFile, pEnd, bookMarker, vsiBooks );

		UnmapViewOfFile(pFile);
		CloseHandle(hFileMapping);
		CloseHandle(hFile);

		break;
	}

	try
	{
		const int numItems = vsiBooks.size();

		SAFEARRAY FAR* psa;
		SAFEARRAYBOUND rgsabound[1];
		rgsabound[0].lLbound = 0;
		rgsabound[0].cElements = numItems;
		psa = SafeArrayCreate(VT_I2, 1, rgsabound);

		short sVal;
		LONG lIndex = 0;

		// Fill the safe array with the short value for the book
		//
		for( lIndex = 0 ; lIndex < numItems ;lIndex++)
		{
			sVal = (short) vsiBooks.at(lIndex);
			hr  = SafeArrayPutElement(psa, &lIndex, &sVal);
		}

		pSafeArray->vt = VT_I2 | VT_ARRAY;
		V_ARRAY(pSafeArray) = psa;

	}
	catch(_com_error &e)
	{
		e;
		// DumpError(e);
	}

	return hr;
}
