// Beginning and ending scripture reference
// found in each text file which is part of a scripture text.
// Can also answer questions about offsets to beginning and
// endings of chapters in this file.

#ifndef __RangeToFile_H__
#define __RangeToFile_H__

#include "TraceCreation.h"		// CTraceCreation def
#include "SCScriptureText.h"
#include <map>

// Special values for m_viChapterOffset
enum ChapterStatus {notDone = 0, allOk = -1, notFound = -2, 
						duplicate = -3, outOfOrder = -4};

typedef vector<int>	T_VI;
typedef T_VI*		T_LPVI;
typedef std::map< int, T_LPVI> T_MI;


class RangeToFile { //hungarian: rtf
private:
	// Indicates whether chapter numbers are correctly present
	ChapterStatus m_iChapterOffsetStatus;

	// Scan file to find chapter offsets.
	ChapterStatus BuildViChapterOffset(void);

		// i'th entry is offset in bytes to beginning of chapter i+1 in file
	vector<int> m_viChapterOffset; 

	// the key to the map is the book number and the data is the chapter offset
	//	where item '0' is the book offset
	T_MI	m_miBookChapterOffset;

	T_LPVI	GetChaptersForBook( int iBook );
	
	int	GetOffset( ScriptureReference *ref, CSCScriptureText* scText, bool first=true, int startPos = 0 );
//	int	GetOffsetFrom( ScriptureReference *ref, CSCScriptureText* scText, int startPos );


	// Last time file was written to
	FILETIME m_writeTime;

	// Chapter number which is duplicated or out of order.
	int m_iBadChapter;
	int m_iBadBook;

public:
	// Marker indicating chapter boundary
	_TSTRING m_sChapterMarker;

	bool FileChanged(void);
	
	int	GetStartOffset( ScriptureReference *ref, CSCScriptureText* scText )	{ return GetOffset( ref, scText, true ); }
	int	GetEndOffset( ScriptureReference *ref, CSCScriptureText* scText )	{ return GetOffset( ref, scText, false ); }

	// constructor.
	RangeToFile();
	// destructor.
	~RangeToFile();

	int iMaxChapter() { return m_viChapterOffset.size(); }

	// First reference in this file, e.g. REV 1:0.
	ScriptureReference m_srfFirst;

	// Last reference (inclusive) in this file, e.g. REV 22:21.
	ScriptureReference m_srfLast;

	// Name of file.
	CComBSTR m_cbstrFileName;

	// Canonical ordering by first reference.
	bool operator<(const RangeToFile& rtf) const { return this->m_srfFirst < rtf.m_srfFirst; };

	// @return The byte offset to the beginning of the specified chapter, -1 if chapter not found.
	int iChapterOffset(int iChapter);
	int iBookChapterOffset(int iBook, int iChapter);

	// @return The byte offset to the end of the specified chapter,
	// length of file if not found
	int iChapterEndOffset(int iChapter);
	int iBookChapterEndOffset(int iBook, int iChapter);

	// @return Size in bytes of most recently opened file.
	int iSize(void);

	// Error message string for chapter number scan.
	char* ChapterError(void);

	// Read a block of data.
	// Return null on error.
	// Otherwise return a null terminate block allocated via new char[];
	char* Read(int iOffset, int iLen);
	char* Read(int iOffset, int iLen, char* outBuf);
	
	// added 7/22/02 for verse level granularity
	// Read a block that contains the passed in refs...
	char* Read		( ScriptureReference *srfFirst, ScriptureReference *srfLast );
	char* ReadFirst	( ScriptureReference *srfFirst );
	char* ReadLast	( ScriptureReference *srfLast );
	// end new routines

	// Add offset to chapter.  Chapter must be greater than any existing
	// chapter number in the file.
	//ChapterStatus AddChapterOffset(int iChapter, int iOffset);
///
///	ChapterStatus AddChapterOffset(int iChapter, int iOffset);
///	ChapterStatus AddBookChapterOffset(int iBook, int iChapter, int iOffset);
///

	// Update offsets to match new chapter at specified offset.
	ChapterStatus ReplaceChapterOffset(int iChapter, int iOffset, int iOldLen, int iNewLen);

	// Scan for chapter numbers.
	ChapterStatus ScanForChapterOffsets(vector<int>& viChapterOffset, 
				char* pFile, char* pEnd, int& iBadChapter);
};

#endif
