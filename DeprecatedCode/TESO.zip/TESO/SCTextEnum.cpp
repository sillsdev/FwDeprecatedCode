// SCTextEnum.cpp : Implementation of CSCTextEnum
#include "stdafx.h"
#include "TESO.h"
#include "SCTextEnum.h"

/////////////////////////////////////////////////////////////////////////////
// CSCTextEnum

STDMETHODIMP CSCTextEnum::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISCTextEnum
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


STDMETHODIMP CSCTextEnum::Next(
///		/*[in, out]*/ ISCTextSegment **ppISCTextSegment, 
		/*[in]*/ ISCTextSegment *pISCTextSegment, 
		/*[out, retval]*/ BOOL *fVal)
{
	PROTECTION_BEGIN

	DD( ATLTRACE("TextEnum::Next\n"); )

///	ISCTextSegment *pISCTextSegment = *ppISCTextSegment;

    while (true) {	
		// Get the next raw segment if one is not already waiting.
		if (m_bGotNextSegmentAlready) {
			m_bGotNextSegmentAlready = false;
		}
		else {
			m_pstss->stsGetNextRawSegment(m_srfCur, m_stsNext);
		}
		
		DD( m_stsNext.Trace("Raw Segment"); )

		// Quit if at end of scripture text
		if (m_stsNext.srfFirst() == ScriptureReference::end())
			break;

		// Skip this one and get next segment if we have not reached beginning of range
		if (m_stsNext.srfLast() < m_srfFirst)
			continue;

		//ATLTRACE("%s\n", m_stsNext.srfFirst().sAsString().c_str());
		//ATLTRACE("%s\n", m_srfLast.sAsString().c_str());

		if (m_stsNext.srfFirst() > m_srfLast &&
			((int)m_stsNext.stpProperties() & (int)scVerse)  ) {
				// Only quit at the start of a verse if smushing by verse
			DD( ATLTRACE("End of verse\n"); )
			break;
		}

		DD( m_stsNext.Trace("Within verse range"); )

		if (m_stpSmushing) {
		    // If we are at 2nd or later smushing boundary
			// break out of loop and mark this segment to be used as the
			// the first segment in the next smushed segment.
			if (!m_bFirst && ((int)m_stsNext.stpProperties() & (int)m_stpSmushing)) {
				DD( ATLTRACE("Smushing boundary found\n"); )
				m_bGotNextSegmentAlready = true;
				break;
			}

			// Not at smushing boundary.
			// Smush this segment into segment being built if it matches the filtering
			// requirements.
			if (m_sttFilter && ((int)m_stsNext.sttTextType() & (int)m_sttFilter)) {
				DD( ATLTRACE("Matches requirements to smush\n"); )
				m_sts.Smush(m_stsNext);
				DD( m_sts.Trace("Smushed result"); )
				m_bFirst = false;
			}
		}
		else {
			// When not smushing, ignore segments which do not match filter.
			if (m_sttFilter && !((int)m_stsNext.sttTextType() & (int)m_sttFilter)) {
				DD( ATLTRACE("Not required text type\n"); )
				continue;
			}

			// Return segment which matched filter.
			m_sts = m_stsNext;
			m_stsNext.Clear();
			break;
		}
	}	

	// If we found anything in the range, return it
	if (m_sts.srfFirst().bValid() && m_sts.srfFirst() <= m_srfLast) {
		DD( m_sts.Trace("RETURNED"); )

		*fVal = -1;    // VB true, we have something
		ISCReference * pRef;

		pISCTextSegment->get_FirstReference(&pRef);
		SetReference(pRef, m_sts.srfFirst());
		pISCTextSegment->get_LastReference(&pRef);
		SetReference(pRef, m_sts.srfLast());

		pISCTextSegment->put_TextType(m_sts.sttTextType());
		pISCTextSegment->put_TextProperties(m_sts.stpProperties());

		BSTR bstr;
		m_qScriptureText->CharToWChar((unsigned char*)m_sts.sText().c_str(), &bstr);
		pISCTextSegment->put_Text(bstr);
		::SysFreeString(bstr);

		int iTagIndex;
		m_qScriptureText->TagIndex(CComBSTR(m_sts.sMarker().c_str()), &iTagIndex);
		CComPtr<ISCTag> qTag;
		m_qScriptureText->NthTag(iTagIndex, &qTag);
		pISCTextSegment->put_Tag(qTag);

		m_qScriptureText->CharToWChar((unsigned char*)m_sts.sLitVerseText().c_str(), &bstr);
		pISCTextSegment->put_LiteralVerseNum(bstr);
		::SysFreeString(bstr);

		m_bFirst = true;  // we are at first smushing boundary.
	}
	else {
		//ATLASSERT(m_sts.srfFirst().bValid());
		DD( ATLTRACE("END found\n"); )
		*fVal = 0;
	}

	m_sts.Clear();

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCTextEnum::Update(
		/*[in]*/ ISCTextSegment *pISCTextSegment 
		)
{
	//!
	return E_NOTIMPL;
}

// This utility function copies a reference to a COM object reference

void SetReference(ISCReference *pRef, ScriptureReference srf)
{
    pRef->put_Book(srf.iBook());
    pRef->put_Chapter(srf.iChapter());
    pRef->put_Verse(srf.iVerse());
    pRef->put_Segment(srf.iSegment());
    pRef->put_Versification(SCVersification(srf.svtVersification()));
}

void CSCTextEnum::FinalRelease()
{
	if (m_pstss) {
		m_pstss->close();
		delete m_pstss;
	}
}


STDMETHODIMP CSCTextEnum::SetText(
			/*[in]*/ BSTR bstrText, 
			/*[in]*/ ISCScriptureText4 *pscr,
			/*[in]*/ BSTR bstrComment)
{
	PROTECTION_BEGIN

	if (bstrComment && *bstrComment)
		m_wchComment = *bstrComment;
	else
		m_wchComment = 0;

	if (pscr == NULL)
		return E_INVALIDARG;
	m_qScriptureText = pscr;

	if (bstrText != NULL)
		m_qbstrText = CComBSTR(bstrText);
	else
		m_qbstrText = "";


	m_qbstrToken = CComBSTR(m_qbstrText.Length());
	m_bstrStream = m_qbstrText;

	m_qScriptureText->get_AsteriskIsMarker(&m_fAsteriskIsMarker);	// would fail with out ref to current version of interface
///	pscr->get_AsteriskIsMarker(&m_fAsteriskIsMarker);	

	return S_OK;

	PROTECTION_END
}


STDMETHODIMP CSCTextEnum::NextToken(
		/*[out]*/ int *piTagIndex, 
		/*[out,retval]*/ BSTR *pbstr)
{
	PROTECTION_BEGIN

	HRESULT hr = S_OK;

	ScrTokenType tt;

	if (! m_qbstrText)
		return E_FAIL;

	*piTagIndex = -1;
	CComBSTR qbstrToken = bstrBaseGetNextToken(tt, m_fAsteriskIsMarker);
	if (tt == tag) {
		hr = m_qScriptureText->TagIndex((BSTR)qbstrToken, piTagIndex);
	}

    *pbstr = qbstrToken.Copy();
	//ATLTRACE("tok=%.50S\n", *pbstr);

	return hr;

	PROTECTION_END
}


CComBSTR CSCTextEnum::bstrBaseGetNextToken(ScrTokenType& tt, bool bAsteriskIsMarker)
{
    wchar_t ch;
    wchar_t chPrevious = 0;
    wchar_t *pToken = (BSTR)m_qbstrToken;
	*pToken = 0;

    tt = unknowntt; 
		// tt starts at unknowntt and becomes 'text' or 'tag' as soon as we know
		// what kind of token we have.

    while (*m_bstrStream) {
		ch = *m_bstrStream++;

        // Comment Handler
		// This assumes that the comment character cannot be newline 
        if (ch == m_wchComment) {
            while (*m_bstrStream && ch != '\n' ) { 
                ch = *m_bstrStream++;    // trash everything from the comment character until the newline 
            }
        }

		if (ch == '\r')
			ch = *m_bstrStream++;   // Ignore \r
        
        if (! ch)
            break; // Break out of the loop since we hit the end of the file. 
        
        switch (ch) {
        case '\\' : // SFM 
            switch (tt) {
                case text: // Fall through on purpose 
                case tag:
                    // If we are getting a tag or Text 
                    // move our current position in the file back one to get this tag
                    // the next time we get a token 
                    m_bstrStream--;
					return CComBSTR(wcslen((BSTR)m_qbstrToken), (BSTR)m_qbstrToken);
                default:
                    // Otherwise, we are getting an tag
                    tt = tag;
            }
            break;

        case '\t': // tabs are considered to be spaces.           
			// Fall through on purpose
        case '\n': // new lines are considered to be spaces.
            ch = ' ';
            // Fall through on purpose
        case ' ' :
            if (tt == tag)
				return CComBSTR(wcslen((BSTR)m_qbstrToken), (BSTR)m_qbstrToken);
            if (chPrevious == ' ')
                break;  // do not allow double spaces.
            // Fall through on purpose
        default:
            // If bare asterisks are allowed as markers mark them so and
            // make them terminate text tokens without being consumed.
            if (bAsteriskIsMarker && ch == '*') {
                if (tt == unknowntt)
                    tt = tag;
                else if (tt == text) {
                    m_bstrStream--;
                    goto done;
                }
            }

            if (tt == unknowntt) {
				//ATLTRACE("ch=%c\n", ch);
                tt = text;      
			}

			// Store character into buffer.
			*pToken++ = ch;
			*pToken = 0;
            // whether the space following a tag is significant.
            if (tt == tag && ch == '*')
				return CComBSTR(wcslen((BSTR)m_qbstrToken), (BSTR)m_qbstrToken);
            break;
        } // switch ch
        chPrevious = ch;
    } // loop

done:
	//ATLTRACE("tok=xx{%S}\n",(BSTR)m_qbstrToken);
	return CComBSTR(wcslen((BSTR)m_qbstrToken), (BSTR)m_qbstrToken);
}



