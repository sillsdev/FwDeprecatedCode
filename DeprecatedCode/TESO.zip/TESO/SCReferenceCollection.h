// SCReferenceCollection.h : Declaration of the CSCReferenceCollection

//:> See ScriptureObjects.idl for interface information about this class


#ifndef __SCREFERENCECOLLECTION_H_
#define __SCREFERENCECOLLECTION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSCReferenceCollection
class ATL_NO_VTABLE CSCReferenceCollection : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSCReferenceCollection, &CLSID_SCReferenceCollection>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISCReferenceCollection, &IID_ISCReferenceCollection, &LIBID_TESOLib>
{
public:
	CSCReferenceCollection()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCREFERENCECOLLECTION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSCReferenceCollection)
	COM_INTERFACE_ENTRY(ISCReferenceCollection)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISCReferenceCollection
public:
	STDMETHOD(Includes)(/*[in]*/ ISCReference* pSCReference, /*[out, retval]*/ BOOL *fVal);
	STDMETHOD(get__NewEnum)(/*[out, retval]*/ LPUNKNOWN *pVal);
	STDMETHOD(Remove)(/*[in]*/ long index);
	STDMETHOD(Insert)(/*[in]*/ ISCReference* pSCReference);
	STDMETHOD(Add)(/*[in]*/ ISCReference* pSCReference);
	STDMETHOD(get_AsString)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(Parse)(/*[in]*/ BSTR bstrReferences, /*[in]*/BSTR bstrCommentCharacter);
	STDMETHOD(Item)(/*[in]*/ long index, /*[out, retval]*/ LPVARIANT pItem);
	STDMETHOD(get_Count)(/*[out, retval]*/ long *pVal);
    void FinalRelease();

private:
	void ReleaseAllReferences(void);
	std::vector<ISCReference*> m_vec;

};

#endif //__SCREFERENCECOLLECTION_H_
