#include "stdafx.h"
#include <algorithm>
#import "wrtXML.tlb" no_namespace 
#include "SCReference.h"


static map<_TSTRING, SCTextType> g_mapStoSTT;
	    // maps string to ScriputreTextType
        // e.g. "title" -> SCTextType::title

static map<_TSTRING, SCTextProperties> g_mapStoSTP;
	    // maps string to ScriptureTextProperty
        // e.g. "chapter" -> ScriptureTextProperty::chapter

static map<_TSTRING, ScriptureStyleType> g_mapStoSST;
	    // maps string to ScriptureStyleType
        // e.g. "character" -> ScriptureStyleType::characterstyle
	

void ToLower(_TSTRING& s)
{
	for (unsigned int i=0; i<s.length(); ++i)
		s[i] = tolower(s[i]);
}


//--------------------------------------------------------------------
// CCheckReceiver: A local class which parses the .scr xml file
//--------------------------------------------------------------------

class CScriptureTextReceiver:public CXMLDataReceiver
{
public:	
	// Constructors/destructor/assign operators/initializers
	CScriptureTextReceiver (CSCScriptureText * p_inScriptureText);
	void StartElementHandler (CExPatParser * pParser, const wchar_t * szwInName,
		const wchar_t ** pszwInAttribs);
	void EndElementHandler (CExPatParser * pParser, const wchar_t * szwInName);
	void CharacterDataHandler (CExPatParser * pParser, const wchar_t * pchwInData,
		int ctnInLength);

protected:	
	CSCScriptureText * m_pCSCScriptureText;
	CComBSTR m_cbstrParamValue;
};


CScriptureTextReceiver::CScriptureTextReceiver(CSCScriptureText * p_inScriptureText)
{
	m_pCSCScriptureText = p_inScriptureText;
}


void CScriptureTextReceiver::StartElementHandler (CExPatParser * pParser,
	const wchar_t * szwInName, const wchar_t ** pszwInAttribs)
{
	char tmp[512];
	sprintf(tmp,"%x %x %x %x %x", szwInName[0], szwInName[1],szwInName[2],szwInName[3],szwInName[4]);

	OutputDebugString("start tag: ");
	OutputDebugStringW( szwInName );
//	OutputDebugString(tmp);
	OutputDebugString("\n");

	m_cbstrParamValue = "";  // Clear value

	if (wcscmp(szwInName, L"Naming") == 0) { 
		const wchar_t ** pp = pszwInAttribs;
		CComBSTR cbstrPrePart;
		CComBSTR cbstrPostPart;
		CComBSTR cbstrBookNameForm;
		CComBSTR cbstrChapterNumberForm;

		while (*pp) {
			if (wcscmp(*pp, L"PrePart") == 0) {
				cbstrPrePart = *(pp+1);				
			}
			else if (wcscmp(*pp, L"PostPart") == 0) { 
				cbstrPostPart = *(pp+1);				
			}
			else if (wcscmp(*pp, L"BookNameForm") == 0) { 
				cbstrBookNameForm = *(pp+1);				
			}
			else if (wcscmp(*pp, L"ChapterNumberForm") == 0) { 
				cbstrChapterNumberForm = *(pp+1);				
			}
			else {
				//!
			}

			++pp;
			++pp;
		}

		HRESULT hResult = 
			m_pCSCScriptureText->
				SetNaming(cbstrPrePart, cbstrPostPart, cbstrBookNameForm, 
					cbstrChapterNumberForm);
	}
	else if (wcscmp(szwInName, L"ExtFileList") == 0) { 
		int asdfasdf = 1234;
	}
	else if (wcscmp(szwInName, L"ExtFileInfo") == 0) { 
//	else if (wcscmp(szwInName, L"ExtFile") == 0) { 
		const wchar_t ** pp = pszwInAttribs;
		CExtFileInfo *efi = new CExtFileInfo();

//		CComBSTR cbstrFirst	= "";
//		CComBSTR cbstrLast	= "";
//		CComBSTR cbstrFile	= "";
	
		while (*pp) {
			if (wcscmp(*pp, L"FirstRef") == 0) {
				efi->SetFirstVerse( *(pp+1) );
			}
			else if (wcscmp(*pp, L"FirstChapter") == 0) { 
				efi->SetFirstChapter( *(pp+1) );
			}
			else if (wcscmp(*pp, L"FirstBook") == 0) { 
				efi->SetFirstBook( *(pp+1) );
			}
			else if (wcscmp(*pp, L"LastRef") == 0) {
				efi->SetLastVerse( *(pp+1) );
			}
			else if (wcscmp(*pp, L"LastChapter") == 0) { 
				efi->SetLastChapter( *(pp+1) );
			}
			else if (wcscmp(*pp, L"LastBook") == 0) { 
				efi->SetLastBook( *(pp+1) );
			}
			else if (wcscmp(*pp, L"File") == 0) { 
				efi->SetFile( *(pp+1) );
			}
			else {
				//! 
			}
	
			++pp;
			++pp;
		}
	
		if ( efi->HasFirstRef() && efi->HasLastRef() && efi->HasFile() )
		{
			HRESULT hResult = m_pCSCScriptureText->SetHasExtFile();		// boolean saying that external file entries are being used
//			CExtFileInfo *efi = new CExtFileInfo( cbstrFirst, cbstrLast, cbstrFile );
			hResult = m_pCSCScriptureText->SaveExtFileInfo(efi);
		}
		/// delete efi;  HERE IT IS!!!!   
	}

}


void CScriptureTextReceiver::EndElementHandler(CExPatParser * pParser, const wchar_t * szwInName)
{	
	if (wcscmp(szwInName, L"ScriptureText") == 0) { }
	else if (wcscmp(szwInName, L"File") == 0) { }
	else if (wcscmp(szwInName, L"ExtFileInfo") == 0) { }	// don't add to parameter map
	else if (wcscmp(szwInName, L"Naming") == 0) { }
	else {
		CComBSTR cbstrKey(szwInName);
		HRESULT hResult = m_pCSCScriptureText->SetParameterValue(cbstrKey, m_cbstrParamValue);
	}

	m_cbstrParamValue = "";
}


void CScriptureTextReceiver::CharacterDataHandler(CExPatParser * pParser,
	const wchar_t * pchwInData, int ctnInLength)
{
	m_cbstrParamValue.Append(pchwInData, ctnInLength);	// append the param data to temp bstr.
}

//-------------------------------------------------------------------------------------



STDMETHODIMP CSCScriptureText::Load(BSTR bstrFileName)
{

#if 0
	{
		ATLTRACE("____ Testing verse parser _____\n");

////		int fverse, lverse;
////		char fsub, lsub;

//		ScriptureReference::ParseVerseText( "16 this is", fverse, fsub, lverse, lsub );
//		ScriptureReference::ParseVerseText( "16-111 this is", fverse, fsub, lverse, lsub );
//		ScriptureReference::ParseVerseText( "6a - 111b this is", fverse, fsub, lverse, lsub );

		ScriptureReference::ContainsVerse( "1 This is the list of the ancestors of Jesus Christ, a descendant of David, who was a descendant of Abraham.", 22 );

		ScriptureReference::ContainsVerse( "5,6,7", 4 );
		ScriptureReference::ContainsVerse( "5,6,7", 5 );
		ScriptureReference::ContainsVerse( "5,6,7", 6 );
		ScriptureReference::ContainsVerse( "5,6,7", 7 );
		ScriptureReference::ContainsVerse( "5,6,7", 8 );

		ScriptureReference::ContainsVerse( "5,6a,6b,7,8", 6 );
		ScriptureReference::ContainsVerse( "6a-7", 6 );
		ScriptureReference::ContainsVerse( "6b,7-8", 6 );
		ScriptureReference::ContainsVerse( "1-2,6a-6b", 6 );
		ScriptureReference::ContainsVerse( "1,6-7a", 6 );
		ScriptureReference::ContainsVerse( "1-2,3,4a-6a,6b-9", 6 );

		ScriptureReference::ContainsVerse( "1"		, 6 );
		ScriptureReference::ContainsVerse( "1,2-6a"	, 6 );
		ScriptureReference::ContainsVerse( "2-6a"	, 6 );
		ScriptureReference::ContainsVerse( "6b-11"	, 6 );
		ScriptureReference::ContainsVerse( "12-16"	, 6 );
		ScriptureReference::ContainsVerse( "17"		, 6 );
		int asdf = 1234;
	}
#endif

	CTraceCreation::Init();
	CTraceCreation::ShowObjects();


	CExPatParser parser;
	int	errorCode;
	int	lineNum;
	int	columnNum;
	USES_CONVERSION;

	// Force versification information to be loaded
////	CComObject<CSCReference> *p;
////	HRESULT hResult = CComObject<CSCReference>::CreateInstance(&p);

	ATLTRACE("Load(%S)\n", bstrFileName);

	m_bNewBooksPresent = false;
	HRESULT hResult = SetHasExtFile( false );		// at this point don't know, reset it.  Could be second load for object...

	static fFirstTime = true;
	if (fFirstTime) {
		fFirstTime = false;
		InitPropertyMaps();
	}

	if (!bstrFileName) {
		DD( ATLTRACE("No file name passed\n"); )
		Error("No file name passed", IID_ISCScriptureText);
		return(E_INVALIDARG);
	}

	m_cbstrXMLFileName = FullPathName(bstrFileName); //	Make this the current file
	ATLTRACE("Load full path(%S)\n", (BSTR)m_cbstrXMLFileName);

	FinalRelease(); // Clear out the current settings if any
	CScriptureTextReceiver * pScriptureTextRec = new CScriptureTextReceiver(this);
	parser.PushReceiver(pScriptureTextRec);
	if (FAILED(parser.Parse(m_cbstrXMLFileName)))
	{
		ATLTRACE("Parser failed\n");
		wchar_t	szwErrStr[384],
				szwParseErrString[256];
		
		errorCode = parser.GetErrorCode();
		lineNum = parser.GetCurrentLineNumber();
		columnNum = parser.GetCurrentColumnNumber();
		parser.GetErrorString(szwParseErrString, errorCode);
		swprintf(szwErrStr, L"XMLParser Error: Line[%d], Column[%d] - %s",
			lineNum, columnNum, szwParseErrString);
		Error(szwErrStr, IID_ISCScriptureText);
		return E_FAIL;
	} 

	ATLTRACE("Parser succeded\n");


	// Get and Set the "EatEscapeBackslashes" data value if in the project file
	//
	BSTR tbstr;
	GetParameterValue(L"EatEscapeBackslashes", &tbstr);

	CComBSTR trueFlag = L"T";			// true flag contents 'T'

	if ( trueFlag == tbstr )
		m_EatEscapeBackslash = true;		// ignore inline markers and data with back slashes

	::SysFreeString( tbstr );


	// set the internal encoding to 
	m_enEncoding = parser.GetEncodingName();

	CComBSTR cbstrVers = m_PropMap["Versification"];
	if (cbstrVers.Length()) {
		m_iMyVersification = (SCVersification)atoi(OLE2A(cbstrVers));
		if (m_iMyVersification < scOriginal || m_iMyVersification > scCustom) {
			//!
		}
	}
	else {
		m_iMyVersification = scEnglish;
	}


	CComBSTR cbstrFileName = bstrFileName;	
	CComBSTR cbstrDirectory = TextDirectory();

	//CComBSTR cbstrDirectory = m_PropMap["Directory"];
	//if (cbstrDirectory[0] != '\\' && cbstrDirectory[1] != ':') {
	//	CComBSTR cbstrTemp;
	//	//trim off file name
	//	for (int i=cbstrFileName.Length()-1; i>0; --i)
	//		if (cbstrFileName[i] == '\\')
	//			break;
	//	cbstrTemp.Append(bstrFileName, i+1);
	//	cbstrTemp.Append(cbstrDirectory);
	//	cbstrDirectory = cbstrTemp;
	//	m_PropMap["Directory"] = cbstrDirectory;
	//}

	// read style sheet...
	CComBSTR cbstrStyleSheet = m_PropMap["StyleSheet"];
	if (cbstrStyleSheet.Length() == 0)
		cbstrStyleSheet = "default.sty";

	ifstream InputFile;
	CComBSTR cbstrFile;
	if (cbstrStyleSheet[0] != '\\' && cbstrStyleSheet[1] != ':') {
		//cbstrFile = cbstrDirectory.Copy();
		//cbstrFile.Append(cbstrStyleSheet);
		//InputFile.open(OLE2A(cbstrFile));
		//if (!InputFile) {
			cbstrFile = SettingsDirectory();
			cbstrFile.Append(cbstrStyleSheet);
		//}
		//else
		//	InputFile.close();
	}
	else {
		cbstrFile = cbstrStyleSheet;
	}

	// Setup defaults for Chapter/Verse markers
	m_sChapterMarker = "c";
	m_sVerseMarker = "v";
	SetParameterValue(L"ChapterMarker", L"c");
	SetParameterValue(L"VerseMarker", L"v");

	ATLTRACE("Starting to read stylesheet %S\n", (BSTR)cbstrFile);

	hResult = ReadSTY(OLE2A(cbstrFile));
	if (FAILED(hResult)) {
		ATLTRACE("Could not read stylesheet %S\n", (BSTR)cbstrFile);
		return hResult;
	}

	ATLTRACE("Stylesheet read\n");
	
	hResult = SetupFileInfo(cbstrDirectory);
	if (FAILED(hResult))
		return hResult;
	ATLTRACE("SetupFileInfo suceeded\n");

	hResult = CompileMapFiles();
	if (FAILED(hResult)) {
		return hResult;
	}

	//		Load the encoding object
	//
	CComBSTR cbstrEncoding = m_PropMap["Encoding"];

	// Check to see if the obsolete CodePage parameter is present
	if (cbstrEncoding.Length() == 0) 
		cbstrEncoding = m_PropMap["CodePage"];

	if (cbstrEncoding.Length()) {
		m_TEC.Load(OLE2A(cbstrEncoding));

		if (!m_TEC.IsValid()) {
			CComBSTR cbstr = cbstrEncoding;
			cbstr += ": Encoding is missing or invalid.";
			Error( cbstr, IID_ISCScriptureText);
			return E_FAIL;
		}
	}

	CTraceCreation::ShowObjects();
	
	ATLTRACE(" End of Load ssf file\n");

	return S_OK;
}


//		If parameters Mapin or Mapout are present, compile the
//		named CC tables and place their handles in m_hMapin and
//		m_hMapout respectively.

HRESULT CSCScriptureText::CompileMapFiles()
{	
	CComBSTR cbstrDirectory = TextDirectory();
	HANDLE hFile;
	char* pFileName;

	USES_CONVERSION;

	cbstrDirectory = TextDirectory();
	cbstrDirectory.Append("mapin.cct");
	pFileName = OLE2A(cbstrDirectory);

	hFile = CreateFile(pFileName,  
					GENERIC_READ,              // open for reading 
					FILE_SHARE_READ,           // share for reading 
					NULL,                      // no security 
					OPEN_EXISTING,             // existing file only 
					FILE_ATTRIBUTE_NORMAL,     // normal file 
					NULL);                     // no attr. template 
 
	if (hFile != INVALID_HANDLE_VALUE) {
		CloseHandle(hFile); 
		int iResult = CCLoadTable(pFileName, &m_hMapin, _Module.m_hInst);
		if (iResult) {
            Error("Cannot compile Mapin.cct"); 
			return E_FAIL;
		}
	}

	cbstrDirectory = TextDirectory();
	cbstrDirectory.Append("mapout.cct");
	pFileName = OLE2A(cbstrDirectory);

	hFile = CreateFile(pFileName,  
					GENERIC_READ,              // open for reading 
					FILE_SHARE_READ,           // share for reading 
					NULL,                      // no security 
					OPEN_EXISTING,             // existing file only 
					FILE_ATTRIBUTE_NORMAL,     // normal file 
					NULL);                     // no attr. template 
 
	if (hFile != INVALID_HANDLE_VALUE) {
		CloseHandle(hFile); 
		int iResult = CCLoadTable(pFileName, &m_hMapout, _Module.m_hInst);
		if (iResult) {
            Error("Cannot compile Mapout.cct"); 
			return E_FAIL;
		}
	}

	return S_OK; 
}


HRESULT CSCScriptureText::SetupFileInfo(CComBSTR cbstrBaseDirectory)
{	
	if (m_vecEFI.size() )		// there are external file entries
	{
		RangeToFile rtf;
/////		RangeToFile *rtf = NULL;
		ScriptureReference srfFirst;
		ScriptureReference srfLast;
		short book,chap,verse;

		srfFirst.Versification((ScriptureVersificationType)m_iMyVersification);
		srfLast.Versification ((ScriptureVersificationType)m_iMyVersification);

		USES_CONVERSION;

		vector<CExtFileInfo*>::iterator iefi = m_vecEFI.begin();

//		_CrtMemDumpAllObjectsSince( NULL );
		
		while ( iefi != m_vecEFI.end() )
		{
/////			rtf = new RangeToFile();

			rtf.m_cbstrFileName = (*iefi)->File();

			CComObject<CSCReference> *qRef;
			HRESULT hResult = CComObject<CSCReference>::CreateInstance(&qRef);
			ATLASSERT(qRef != NULL);

			BSTR bstrFirst, bstrLast;
			bstrFirst = (*iefi)->FirstRef();
			bstrLast  = (*iefi)->LastRef();

			qRef->Parse( bstrFirst );

			qRef->get_Book( &book );
			qRef->get_Chapter( &chap );
			qRef->get_Verse( &verse );

			ATLTRACE("REF: (%s) %d %d:%d - ", bstrFirst, book, chap, verse);

			srfFirst.Book( book );
			srfFirst.Chapter( chap );
			srfFirst.Verse( verse );		//   no change to the first ref

////		srfFirst.Book( ScriptureReference::iLookupBook( OLE2T(bstrFirst) ));
////		srfLast.Book ( ScriptureReference::iLookupBook( OLE2T(bstrLast) ));

			// now handle the last reference : Book , Chapter or Verse specific
			// Verse, no change: Use as parsed
			// Chapter, go to the last verse of the chapter
			// Book, go to the last chapter in book and last verse in chapter
			//

			qRef->Parse(bstrLast);
			qRef->get_Book( &book );
			qRef->get_Chapter( &chap );
			qRef->get_Verse( &verse );

			ATLTRACE("(%s) %d %d:%d --> ", bstrLast, book, chap, verse);

			srfLast.Book( book );
			srfLast.Chapter( chap );
			srfLast.Verse( verse );	

			if ( (*iefi)->IsLastRefVerse() )
			{
				;	// use it as the parse returns it
			}
			else if ( (*iefi)->IsLastRefChapter() )
			{
				qRef->get_LastVerse( &verse );
				srfLast.Verse( verse );			// go to the last verse of the chapter
			}
			else if ( (*iefi)->IsLastRefBook() )
			{
				qRef->get_LastChapter( &chap );
				srfLast.Chapter( chap );		// go to the last chapter of the book
				verse = srfLast.iLastVerse();
				srfLast.Verse( verse );			// go to the last verse of the chapter
			}

			ATLTRACE("%d %d:%d <%s>\n", book, chap, verse, rtf.m_cbstrFileName );

			rtf.m_srfFirst = srfFirst;
			rtf.m_srfLast = srfLast;
		
//////			InsertRangeToFile(rtf);
			InsertRangeToFile(rtf);

// TODO	
//			delete ( *iefi );			// now free up the data stored in the vector
			
			::SysFreeString( bstrFirst );
			::SysFreeString( bstrLast );

			iefi++;
		}
		
		m_vecEFI.clear();				// clear out the vector

		sort(m_vecrtf.begin(), m_vecrtf.end());	// make sure the entries are sorted

		//
		// set the "BooksPresent" property
		//
//-		short *books = new short[NUM_BOOKS];
		short books[NUM_BOOKS];
		memset( books, 0, sizeof(short)*NUM_BOOKS);

		vector<RangeToFile>::iterator rtfi = m_vecrtf.begin();
		short startBook, endBook;
		int lastRef = 0;
		int curRef;

		while (rtfi != m_vecrtf.end()) 
		{
			curRef = rtfi->m_srfFirst.iBBCCCVVV();
			if ( curRef < lastRef )
			{
				// overlap problem !!!  Now What....??
				ATLTRACE("ERROR NOT HANDLED****\n");
				ATLTRACE("  The sorted references overlap: last %i, cur %i\n", lastRef, curRef );
			}

			lastRef = rtfi->m_srfLast.iBBCCCVVV();

			startBook = rtfi->m_srfFirst.iBook();
			endBook   = rtfi->m_srfLast.iBook();
			for ( int i = startBook; i <= endBook; i++ )
			{
				if (i > 0 && i <= NUM_BOOKS)
					books[i-1] = 1;
			}

			rtfi++;
		}

		// now compare the books just computed with the one from the prop map
		// if they're different then set the flag so that the project file is written out when fininshed
		//

		CComBSTR bstrBooksPresent = m_PropMap["BooksPresent"];
		wchar_t *wcZero = L"0", *wcOne = L"1";
		wchar_t *wcValue;
		bool booksMatch = true;

		for ( int i=0; i<NUM_BOOKS; i++)
		{
			if ( books[i] )
				wcValue = wcOne;
			else
				wcValue = wcZero;

			if ( bstrBooksPresent[i] != *wcValue )
			{
				booksMatch = false;
				break;
			}
		}

		if ( !booksMatch )
		{
			wchar_t newBooksPresent[NUM_BOOKS+1];

			for ( i=0; i<NUM_BOOKS; i++ )
			{
				if ( books[i] )
					newBooksPresent[i] = '1';
				else
					newBooksPresent[i] = '0';
			}
			newBooksPresent[NUM_BOOKS] = '\0';
	
			BSTR nbp = ::SysAllocString( newBooksPresent );
			put_BooksPresent( nbp );
			::SysFreeString( nbp );
			
			m_bNewBooksPresent = true;
		}

//-		delete [] books;

		CComBSTR cbstrBooksPresent = m_PropMap["BooksPresent"];
	
		return S_OK;
	}

	if (m_vecrtf.size()) {
		sort(m_vecrtf.begin(), m_vecrtf.end());
		// To Do: check for overlap
		return S_OK;
	}

	CComBSTR cbstrBooksPresent = m_PropMap["BooksPresent"];
	if (cbstrBooksPresent.Length() == 0) {
		Error("Either <File> or <BooksPresent> must be present", IID_ISCScriptureText);
		return E_FAIL;
	}
	
	CComBSTR cbstrDirectory = TextDirectory();

	int iLength = cbstrBooksPresent.Length();
	RangeToFile rtf;

	for (int iIndex = 1; iIndex <= iLength; ++iIndex) {
		if (cbstrBooksPresent[iIndex-1] == '1') {
			rtf.m_srfFirst.Versification((ScriptureVersificationType)m_iMyVersification);
			rtf.m_srfLast.Versification((ScriptureVersificationType)m_iMyVersification);
			rtf.m_srfLast.Book(iIndex);

			rtf.m_srfFirst.Book(iIndex);
			rtf.m_srfFirst.Chapter(1);
			rtf.m_srfFirst.Verse(0);

			if (m_cbstrChapterNumberForm == "") {
				rtf.m_srfLast.Chapter(rtf.m_srfFirst.iLastChapter());
				rtf.m_srfLast.Verse(1);
				rtf.m_srfLast.Verse(rtf.m_srfLast.iLastVerse());

				rtf.m_cbstrFileName = cbstrDirectory;
				rtf.m_cbstrFileName.Append(cbstrTextFileName(iIndex, 0));
				InsertRangeToFile(rtf);
			}
			else {
				int iLastChapter = rtf.m_srfFirst.iLastChapter();
				for (int iChapter = 1; iChapter <= iLastChapter; ++iChapter) {
					rtf.m_srfFirst.Chapter(iChapter);
					rtf.m_srfFirst.Verse(0);
					rtf.m_srfLast.Chapter(iChapter);
					rtf.m_srfLast.Verse(1);
					rtf.m_srfLast.Verse(rtf.m_srfLast.iLastVerse());

					rtf.m_cbstrFileName = cbstrDirectory;
					rtf.m_cbstrFileName.Append(cbstrTextFileName(iIndex, iChapter));
					InsertRangeToFile(rtf);
				}
			}
		}
	}

	return S_OK;
}


CComBSTR CSCScriptureText::cbstrTextFileName(int iBook, int iChapter)
{
	char buf[10];
	CComBSTR cbstr = "";

	if (iChapter && m_cbstrChapterNumberForm.Length()) {
		cbstr = CComBSTR(ScriptureReference::cGetBookName(iBook));
		cbstr += "\\";
	}

	cbstr += m_cbstrPrePart;

	if (m_cbstrBookNameForm == "MAT") { 
		cbstr += CComBSTR(ScriptureReference::cGetBookName(iBook));
	}
	else if (m_cbstrBookNameForm == "40" || m_cbstrBookNameForm == "41") { 
		sprintf(buf, "%02d", iBook < 40 ? iBook : iBook+1);
		cbstr += CComBSTR(buf);
	}
	else {
		sprintf(buf, "%02d", iBook < 40 ? iBook : iBook+1);
		cbstr += CComBSTR(buf);
		cbstr += CComBSTR(ScriptureReference::cGetBookName(iBook));
	}

	if (iChapter && m_cbstrChapterNumberForm == "01") { 
		sprintf(buf, "%02d", iChapter);
		cbstr += CComBSTR(buf);
	}
	else if (iChapter && m_cbstrChapterNumberForm == "1") { 
		sprintf(buf, "%d", iChapter);
		cbstr += CComBSTR(buf);
	}

	cbstr += m_cbstrPostPart;

	return cbstr;
}


// reads the style file to give properties of SFM tags

void DumpStyleSheet(map<_TSTRING, MarkerInfo>& markers)
{
	map<_TSTRING, MarkerInfo>::iterator p;

	ATLTRACE("STYLESHEET Info\n");
	for (p=markers.begin(); p!=markers.end(); ++p) {
		DumpMarkerInfo("     ", p->second);
	}
}

STDMETHODIMP CSCScriptureText::Save(BSTR bstrFileName)
{
	PROTECTION_BEGIN

    _bstr_t bstrEncoding;   
    IWriteXMLPtr qWrite;
    HRESULT hr = S_OK;

    qWrite.CreateInstance(__uuidof(WriteXML));
    if (qWrite == NULL) {
        Error(L"Unable to create WriteXML COM Object.", IID_ISCScriptureText); 
        return E_FAIL;
    }
        
    bstrEncoding = L"UTF8";

	try {
		// try to open the file
		qWrite->OpenOutputFile((BSTR)FullPathName(bstrFileName), bstrEncoding);
	} catch (_com_error&) {
		wchar_t	szwErrorString[384];
		swprintf(szwErrorString, L"Unable to write to %s", bstrFileName);
		Error(szwErrorString, IID_ISCScriptureText);
		return(E_FAIL);
    }
    
	try {
		map<CComBSTR, CComBSTR>::iterator p;

		qWrite->Tag("ScriptureText", true);

		for (p = m_PropMap.begin(); p != m_PropMap.end(); ++p) {
			qWrite->SingleLineEntity ((BSTR)p->first, (BSTR)p->second, true);
		}
		
		//<Naming PrePart="BIS" PostPart=".SFC" BookNameForm="MAT"/>
		if (m_cbstrPrePart.Length() > 0 ||
				m_cbstrPostPart.Length() > 0 ||
				m_cbstrBookNameForm.Length() > 0 ||
				m_cbstrChapterNumberForm.Length() > 0) {

			qWrite->Tag("Naming", true);
			if (m_cbstrPrePart.Length() > 0)
				qWrite->WriteAttrib("PrePart", (BSTR)m_cbstrPrePart);

			if (m_cbstrPostPart.Length() > 0)
				qWrite->WriteAttrib("PostPart", (BSTR)m_cbstrPostPart);

			if (m_cbstrBookNameForm.Length() > 0)
				qWrite->WriteAttrib("BookNameForm", (BSTR)m_cbstrBookNameForm);

			if (m_cbstrChapterNumberForm.Length() > 0)
				qWrite->WriteAttrib("ChapterNumberForm", (BSTR)m_cbstrChapterNumberForm);

			qWrite->EndTag(false);
		}
		// start 10/14 ExtFileInfo
		if ( HasExtFile() )			// put out the ExtFileInfo data
		{
			vector<RangeToFile>::iterator rtfi = m_vecrtf.begin();

			while (rtfi != m_vecrtf.end()) 
			{
				RangeToFile rtf = *rtfi;
				qWrite->Tag("ExtFileInfo", true);
				qWrite->WriteAttrib("FirstRef"	, rtf.m_srfFirst.sAsString().c_str() );
				qWrite->WriteAttrib("LastRef"	, rtf.m_srfLast.sAsString().c_str()  );
				qWrite->WriteAttrib("File"		, (BSTR)rtf.m_cbstrFileName );

				qWrite->EndTag(false);
				rtfi++;
			}
		}
		//  end
//		qWrite->EndTag(false);
		qWrite->EndTag(true);

		// close the XML file
		qWrite->CloseOutputFile();

		// release the IWriteXML interface pointer
		qWrite = NULL;
	} catch (_com_error& e) {
		ATLTRACE("Save ERROR = %x\n", e.Error());
		hr = e.Error();
	}

    //! check hr
    //ATLASSERT(SUCCEEDED(hr));
    return S_OK;

	PROTECTION_END
}


void CSCScriptureText::InitPropertyMaps()
{
	g_mapStoSTT["title"] = scTitle;
	g_mapStoSTT["section"] = scSection;
	g_mapStoSTT["versetext"] = scVerseText;
	g_mapStoSTT["notetext"] = scNoteText;
	g_mapStoSTT["other"] = scOther;
	g_mapStoSTT["backtranslation"] = scBackTranslation;	// 020625 - added for enhanced reading
	g_mapStoSTT["translationnote"] = scTranslationNote;	// 020625 - added for enhanced reading
	g_mapStoSTT["unknowntype" ] = scUnknownType;		// 020625 - added for enhanced reading
	
	g_mapStoSTP["verse"] = scVerse;
	g_mapStoSTP["chapter"] = scChapter;
	g_mapStoSTP["paragraph"] = scParagraph;
	g_mapStoSTP["publishable"] = scPublishable;
	g_mapStoSTP["vernacular"] = scVernacular;
	g_mapStoSTP["poetic"] = scPoetic;
	g_mapStoSTP["level_1"] = scLevel_1;
	g_mapStoSTP["level_2"] = scLevel_2;
	g_mapStoSTP["level_3"] = scLevel_3;
	g_mapStoSTP["level_4"] = scLevel_4;
	g_mapStoSTP["level_5"] = scLevel_5;
	g_mapStoSTP["crossreference"] = scCrossReference;
	g_mapStoSTP["nonpublishable"] = scNonpublishable;
	g_mapStoSTP["nonvernacular"] = scNonvernacular;
	g_mapStoSTP["book"] = scBook;
	g_mapStoSTP["note"] = scNote;

	g_mapStoSST["character"] = characterstyle;
	g_mapStoSST["paragraph"] = paragraphstyle;
	g_mapStoSST["note"] = notestyle;
}

void DumpMarkerInfo(char* hdg, MarkerInfo& mi)
{
	_TSTRING s;

	s = hdg;
	s = s + mi.m_sMarker; 

	map<_TSTRING, SCTextType>::iterator pstt;
	map<_TSTRING, SCTextProperties>::iterator pstp;
	map<_TSTRING, ScriptureStyleType>::iterator psst;

	s = s + "  type(";
	for (pstt = g_mapStoSTT.begin(); pstt != g_mapStoSTT.end(); ++pstt) {
		if (mi.m_stt == pstt->second) {
			s = s + " ";
			s = s + pstt->first;
		}
	}
	s = s + ")";

	for (psst = g_mapStoSST.begin(); psst != g_mapStoSST.end(); ++psst) {
		if (psst->second == paragraphstyle)
			continue;
		if (mi.m_sst == psst->second) {
			s = s + " ";
			s = s + psst->first;
		}
	}

	s = s + "  prop(";
	for (pstp = g_mapStoSTP.begin(); pstp != g_mapStoSTP.end(); ++pstp) {
		if (mi.m_stp & pstp->second) {
			s = s + " ";
			s = s + pstp->first;
		}
	}
	s = s + ")";

	if (mi.m_sAssocMarker.data() != "") {
		s = s + mi.m_sAssocMarker.data();
		s = s + " ";
	}

    if (mi.m_bIsEnd)
		s = s + "bIsEnd";

	ATLTRACE("%s\n", s.data());
}


HRESULT CSCScriptureText::ReadSTY(const char *pchFileName)
{
	ScrTokenType tt = m_LastTokenType;	// unknowntt;
	_TSTRING sToken;
	ifstream InputFile;
	char tmp[512];

	InputFile.open(pchFileName);
	if (!InputFile) {
		sprintf(tmp, "Could not open stylesheet %s\n", pchFileName);
		ATLTRACE(tmp);
		Error(tmp, IID_ISCScriptureText);
		return E_INVALIDARG;
	}

	while (1) {
		sToken = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
		// Ignore any text at beginning of file.
		if (tt != text)
			break;
	}

	while (sToken != "") {
		ToLower(sToken);
		HRESULT hResult = ReadSTYMarkerEntry(sToken, tt, InputFile);
		if (FAILED(hResult))
			return hResult;
	}

	DD( DumpStyleSheet(m_MarkerTextProp); )

	m_LastTokenType = tt;

	return S_OK;
}



#define USES_CONVERSION_CP(x) int _convert; _convert; UINT _acp = x; _acp; \
			LPCWSTR _lpw; _lpw; LPCSTR _lpa; _lpa

#undef A2W
#define A2W(lpa) (\
		((_lpa = lpa) == NULL) ? NULL : (\
			_convert = (lstrlenA(_lpa)+1),\
			ATLA2WHELPER((LPWSTR) alloca(_convert*2), _lpa, _convert, _acp)))

#undef W2A
#define W2A(lpw) (\
		((_lpw = lpw) == NULL) ? NULL : (\
			_convert = (lstrlenW(_lpw)+1)*5,\
			ATLW2AHELPER((LPSTR) alloca(_convert), _lpw, _convert, _acp)))


HRESULT CSCScriptureText::ReadSTYMarkerEntry(_TSTRING& sToken, ScrTokenType& tt, ifstream& InputFile)
{
	_TSTRING sMarker, sProps, sEndMarker;
	CComPtr<ISCTag> qTag;
	CComPtr<ISCTag> qTagEndMarker;

	if (tt != tag || sToken != "marker") {
		ATLTRACE("\\marker not found\n");
		Error("\\marker not found", IID_ISCScriptureText);
		return E_FAIL;
	}

	MarkerInfo miTemp;
	miTemp.m_stt = scVerseText;
	miTemp.m_stp = scPublishable;
	miTemp.m_sAssocMarker = EMPTY_STRING;

	int numTags = m_vTags.size();

	qTag.CoCreateInstance(_uuidof(SCTag),NULL,CLSCTX_INPROC_SERVER);
	if (qTag == NULL) {
		ATLTRACE("Could not create SCTag\n");
		Error("Could not create SCTag", IID_ISCScriptureText);
		return E_FAIL;
	}
	m_vTags.push_back(qTag);

	// TE-1856 Start
	sMarker = SFMScriptureTextSegmentStream::sBaseGetNextTokenToEndOfLine(tt, InputFile, '#');
	// TE-1856 End
	// sMarker = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
	// bTrimWSEnds(sMarker);
	_TSTRING sTemp;
	sTemp = sMarker;


#ifdef CHECK_FOR_UPPER_CASE
	_TSTRING sError;
	ToLower(sMarker);
	if (sTemp != sMarker) {
		sError = "Marker cannot contain upper case letters: ";
		sError += sTemp;
		Error(sError.c_str(), IID_ISCScriptureText);
		return E_FAIL;
	}
#endif

	qTag->put_Marker(CComBSTR(sMarker.c_str()));

	bool bHasEnd = false;

	// The following items are present for conformance with
	// Paratext release 5.0 stylesheets.  Release 6.0 and later
	// follows the guidelines set in InitPropertyMaps.
	// Make sure \id gets book property

//// 9/28 - pull the setting from the sty file only - no assumptions...
////	if (sMarker == "id")
////		miTemp.m_stp = scBook;

	USES_CONVERSION_CP(65001);   // Setuup for UTF8 conversion

	sToken = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
	// TE-1856
	// Due to the new parsing code to handle a space at the end of a marker, the parsing code
	// will sometimes return a text type that is basically just eating spaces, so here we just
	// go back and get some more until we get the next marker entry.  Have only seen it take one
	// call but added the while loop just to be certian.
	if (tt == text)
	{
		while (tt==text)
		{
			sToken = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
		}
	}
	// TE-1856 end

	while (tt == tag) { //until you get to the next \marker
		ToLower(sToken);

		if (sToken == "marker")
			break;

        else if (sToken == "name") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);
			//ATLTRACE("Name = %s\n", sProps.c_str());

			qTag->put_Name(A2W(sProps.c_str()));
        }

        else if (sToken == "testylename") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_TeStyleName(A2W(sProps.c_str()));
        }

        else if (sToken == "description") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_Description(A2W(sProps.c_str()));
        }

        else if (sToken == "fontname") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_Fontname(A2W(sProps.c_str()));
        }

        else if (sToken == "occursunder") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

#ifdef CHECK_FOR_UPPER_CASE
			sTemp = sProps;
			ToLower(sProps);
			if (sTemp != sProps) {
				sError = "OccursUnder cannot contain upper case letters: ";
				sError += sTemp;
				Error(sError.c_str(), IID_ISCScriptureText);
				return E_FAIL;
			}
#endif

			qTag->put_OccursUnder(A2W(sProps.c_str()));
        }

        else if (sToken == "xmltag") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_XMLTag(A2W(sProps.c_str()));
        }

        else if (sToken == "encoding") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');		// possible changes to do 9/26 - dlh
			bTrimWSEnds(sProps);

			qTag->put_Encoding(A2W(sProps.c_str()));

			// 7/15 adding
			if (sProps.length()) {
				ATLTRACE("Work to do here still: %s %d\n", __FILE__ , __LINE__ );

				// !!!! Strange Things are Happining.... !!!!
				// if I do the convert with teh object, the app will
				//	blow up down stream with a memory problem ... WHY???
				///////////////////////////////////////////////////////////

				// see if the entry already exists, if not, validate and create it
				TMapIDToConverter::iterator itc = m_ConverterMap.find( sProps.c_str() );
				if ( itc == m_ConverterMap.end() ) 
				{
					CTKAndCodePageWrapper *pTec = new CTKAndCodePageWrapper();
					pTec->Load((char*)(sProps.c_str()));

					if (!pTec->IsValid()) {
						delete pTec;
						CComBSTR cbstr = sProps.c_str();
						cbstr += ": Encoding for Marker is invalid.";
						Error( cbstr, IID_ISCScriptureText);
						return E_FAIL;
					}
					else
					{
						m_IDMap[ sMarker ] = sProps.c_str();	// add this marker converter ref
						m_ConverterMap[ sProps.c_str()] = pTec;	// add the converter
//						// test the converter
//						BSTR out;
//						pTec->Convert( (unsigned char*)"abcdef", &out );
//						SysFreeString( out );
					}
				}
			}
		}

        else if (sToken == "fontsize") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_FontSize(atoi(sProps.c_str()));
        }

        else if (sToken == "linespacing") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_LineSpacing(atoi(sProps.c_str()));
        }

        else if (sToken == "spacebefore") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_SpaceBefore(atoi(sProps.c_str()));
        }

        else if (sToken == "spaceafter") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_SpaceAfter(atoi(sProps.c_str()));
        }

        else if (sToken == "leftmargin") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_LeftMargin((int)(1000 * atof(sProps.c_str())));
        }

        else if (sToken == "firstlineindent") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_FirstLineIndent((int)(1000 * atof(sProps.c_str())));
        }

        else if (sToken == "rightmargin") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_RightMargin((int)(1000 * atof(sProps.c_str())));
        }

        else if (sToken == "color") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_Color(atoi(sProps.c_str()));
        }

        else if (sToken == "rank") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);

			qTag->put_Rank(atoi(sProps.c_str()));
        }

        else if (sToken == "justification") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);
			ToLower(sProps);

			if (sProps == "left")
				qTag->put_JustificationType(scLeft);
			else if (sProps == "center")
				qTag->put_JustificationType(scCenter);
			else if (sProps == "right")
				qTag->put_JustificationType(scRight);
			else if (sProps == "both")
				qTag->put_JustificationType(scBoth);
			else {
				ATLTRACE("Invalid justification\n");
				_TSTRING sErr = "Error in .sty file. Invalid JustificationType value: ";
				sErr += sProps;
				Error(sErr.data(), IID_ISCScriptureText);
				return E_FAIL;
			}
        }

        else if (sToken == "bold") {
			qTag->put_Bold(-1);
        }

        else if (sToken == "smallcaps") {
			qTag->put_SmallCaps(-1);
        }

        else if (sToken == "subscript") {
			qTag->put_Subscript(-1);
        }

        else if (sToken == "italic") {
			qTag->put_Italic(-1);
        }

        else if (sToken == "underline") {
			qTag->put_Underline(-1);
        }

        else if (sToken == "superscript") {
			qTag->put_Superscript(-1);
        }

        else if (sToken == "notrepeatable") {
			qTag->put_NotRepeatable(-1);
        }

		else if (sToken == "textproperties") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			TokenStream tsProps(sProps.data());
			_TSTRING sNext = tsProps.sNext();

			while (sNext != EMPTY_STRING) {
				ToLower(sNext);
				SCTextProperties stp = g_mapStoSTP[sNext];
				if (stp == SCTextProperties(0)) {
					_TSTRING sErr = "Error in .sty file. Invalid TextProperties value: ";
					sErr += sNext;
					ATLTRACE("Invalid text property: %s\n", sNext.c_str());
					Error(sErr.data(), IID_ISCScriptureText);
					return E_FAIL;
				}
				else if (stp == scVerse)	// verse marker
				{
					m_sVerseMarker = sMarker;
					SetParameterValue(L"VerseMarker", A2W(sMarker.c_str()));
				}
				else if (stp == scChapter)	// chapter marker
				{
					m_sChapterMarker = sMarker;
					SetParameterValue(L"ChapterMarker", A2W(sMarker.c_str()));
				}

				miTemp.m_stp = SCTextProperties((int)miTemp.m_stp | (int)stp);
	
				sNext = tsProps.sNext();
			}
			//ATLTRACE("TextProperties = %x\n", miTemp.m_stp);

			qTag->put_TextProperties(miTemp.m_stp);
			miTemp.m_bIsEnd = false;
		}

		else if (sToken == "texttype") {
			sProps = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sProps);
			ToLower(sProps);

			miTemp.m_stt = g_mapStoSTT[sProps];
			if (miTemp.m_stt == SCTextType(0)) {
				// The following items are present for conformance with
				// Paratext release 5.0 stylesheets.  Release 6.0 and later
				// follows the guidelines set in InitPropertyMaps.

				
				if (sProps == "nonpublishable") {
					miTemp.m_stt = scOther;
					miTemp.m_stp = SCTextProperties((int)miTemp.m_stp | (int)scNonpublishable);
				}
				
				else if (sProps == "nontext") {
					miTemp.m_stt = scNoteText;
				}
				
				else if (sProps == "text") {
					miTemp.m_stt = scVerseText;
				}
				
				else if (sProps == "versenumber") {
					miTemp.m_stt = scVerseText;
				}
				
				else if (sProps == "chapternumber") {
					miTemp.m_stt = scOther;
				}

				// added for enhanced reading, still needs review
				//	translationnote, backtranslation and unknowntype
				//
				else if (sProps == "translationnote") {
					miTemp.m_stt = scNoteText;
					miTemp.m_stp = scNonpublishable;
				}

				else if (sProps == "backtranslation") {
					miTemp.m_stt = scBackTranslation;
				}

				else if (sProps == "unknowntype") {
					miTemp.m_stt = scUnknownType;
					miTemp.m_stp = scNonpublishable;
				}

				else {
					ATLTRACE("Invalid text type\n");
					_TSTRING sErr = "Error in .sty file. Invalid TextType value: ";
					sErr += sProps;
					Error(sErr.data(), IID_ISCScriptureText);
					return E_FAIL;
				}
			}

			qTag->put_TextProperties(miTemp.m_stp);
			qTag->put_TextType(miTemp.m_stt);
			miTemp.m_bIsEnd = false;
		}

		else if (sToken == "endmarker") {
			bHasEnd = true;
			// get the end marker
			// TE-1856 Start
			sEndMarker = SFMScriptureTextSegmentStream::sBaseGetNextTokenToEndOfLine(tt, InputFile, '#');
			// TE-1856 End
//			sEndMarker = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
//			
//			bTrimWSEnds(sEndMarker);

			if (sEndMarker == "*")
				m_fAsteriskIsMarker = true;

#ifdef CHECK_FOR_UPPER_CASE
			sTemp = sEndMarker;
			ToLower(sEndMarker);
			if (sTemp != sEndMarker) {
				sError = "EndMarker cannot contain upper case letters: ";
				sError += sTemp;
				Error(sError.c_str(), IID_ISCScriptureText);
				return E_FAIL;
			}
#endif

			qTag->put_Endmarker(A2W(sEndMarker.c_str()));

			// Create separate tag for end marker
			qTagEndMarker.CoCreateInstance(_uuidof(SCTag),NULL,CLSCTX_INPROC_SERVER);
			if (qTagEndMarker == NULL) {
				ATLTRACE("Could not create SCTag\n");
				Error("Could not create SCTag", IID_ISCScriptureText);
				return E_FAIL;
			}
			m_vTags.push_back(qTagEndMarker);
			qTagEndMarker->put_Marker(A2W(sEndMarker.c_str()));
			qTagEndMarker->put_StyleType(scEndStyle);
		}

		else if (sToken == "styletype") {
			_TSTRING sStyle = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
			bTrimWSEnds(sStyle);
			ToLower(sStyle);
			miTemp.m_sst = g_mapStoSST[sStyle];
			if (miTemp.m_sst == ScriptureStyleType(0)) {
				_TSTRING sErr = "Error in .sty file. Invalid StyleType value: ";
				sErr += sStyle;
				ATLTRACE("nvalid StyleType value: \n");
				Error(sErr.data(), IID_ISCScriptureText);
				return E_FAIL;
			}

			qTag->put_StyleType((SCStyleType)miTemp.m_sst);
		}

		else {
			ATLTRACE("Unknown marker in stylesheet: %s\n", sToken.c_str());
			_TSTRING sErr = "Unknown marker in stylesheet: ";
			sErr += sToken;
			Error(sErr.data(), IID_ISCScriptureText);
			return E_FAIL;
		}

#if 0
		// dlh testing 8/13...
		ATLTRACE(" -- Marker/Token : %s %s\n", sMarker.c_str(), sToken.c_str());
		if ( sMarker == "ord" )
		{
			int asdf = 1234;
		}
		// dlh testing stop
#endif
		// go to next SFM
		sToken = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
		while (tt == text)
			sToken = SFMScriptureTextSegmentStream::sBaseGetNextToken(tt, InputFile, '#');
	}

	if (bHasEnd) {				// More possible work here 9/26 - dlh
		miTemp.m_sAssocMarker = sEndMarker;
		MarkerInfo miTemp2 = miTemp;
		miTemp2.m_sAssocMarker = sMarker;
		miTemp2.m_bIsEnd = true;
		// put it in with the current Marker as the Associated Marker
		miTemp2.m_sMarker = sEndMarker;
		m_MarkerTextProp.insert(map<_TSTRING, MarkerInfo>::value_type(sEndMarker, miTemp2));
	}

	miTemp.m_sMarker = sMarker;
	m_MarkerTextProp.insert(map<_TSTRING, MarkerInfo>::value_type(sMarker, miTemp));			

	return S_OK;
}



