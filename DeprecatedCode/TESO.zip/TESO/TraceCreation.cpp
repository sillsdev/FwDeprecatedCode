#include "stdafx.h"
#include "TraceCreation.h"


//////////////////////////////////////////////////
// Initialize static members
//////////////////////////////////////////////////
//
TraceCreationMap CTraceCreation::mObjects;
TraceCreationActiveMap CTraceCreation::mActiveObjects;
CRITICAL_SECTION CTraceCreation::mCS;
bool CTraceCreation::mbInitDone = false;
unsigned int  CTraceCreation::mMaxLen = 0;

//////////////////////////////////////////////////
// Define some preprocessor short cuts
//////////////////////////////////////////////////
//
#define TRY_START	try { EnterCriticalSection( &mCS );
#define TRY_STOP	} catch (...) { AtlTrace("__**-- Exception in CTraceCreation **\n"); } LeaveCriticalSection( &mCS );

//////////////////////////////////////////////////
// Test "Leaky" class for memory leaks...
//////////////////////////////////////////////////
//
class CLeaky : public CTraceCreation
{
public:
	CLeaky() : CTraceCreation( "CLeaky" ) { memset( &mLeaky, 0x77, sizeof( mLeaky )); }
	char	mLeaky[10];
};

//////////////////////////////////////////////////
// Static Init Method
//////////////////////////////////////////////////
//
void CTraceCreation::Init()
{
	if ( !mbInitDone )
	{
		InitializeCriticalSection( &mCS );
		mbInitDone = true;
		
///		CLeaky *leak = new CLeaky();	// create a leak!!!
///		_CrtDumpMemoryLeaks();
	}
}

//////////////////////////////////////////////////
// Static Reset method (free up memory for class)
//////////////////////////////////////////////////
//
void CTraceCreation::Reset()
{
	Init();

	TRY_START

	// just need to free up the vector pointers, all else handled automatically
	TraceCreationActiveMap::iterator it = mActiveObjects.begin();
	while ( it != mActiveObjects.end() )
	{
		bVec *active = (*it).second;
		delete active;
	}

	mActiveObjects.clear();
	mObjects.clear();

	TRY_STOP
}

//////////////////////////////////////////////////
// Default Constructor
//////////////////////////////////////////////////
//
CTraceCreation::CTraceCreation()
{
	Init();

	TRY_START

	mCreationType = CT_UNKNOWN;
	Init( "Unknown - defCons" );
	ShowObjects();
	
	TRY_STOP
}

//////////////////////////////////////////////////
// Prefered Constructor with super class name
//////////////////////////////////////////////////
//
CTraceCreation::CTraceCreation( char* name )
{
	Init();

	TRY_START

	mCreationType = CT_CONS;
	Init( name );
	ShowObjects();
	
	TRY_STOP
}

//////////////////////////////////////////////////
// Copy Constructor
//////////////////////////////////////////////////
//
CTraceCreation::CTraceCreation( const CTraceCreation& other)
{
	if ( this == &other )
		return;

	ATLTRACE("*** Copy of ID<%d-%d>\n", other.mID, other.mCreationType );	// .GetCreationString() );
	mCreationType = CT_COPY;
	Init( (char*)other.mName.c_str() );

}

//////////////////////////////////////////////////
// Assignment operator
//////////////////////////////////////////////////
//
CTraceCreation & CTraceCreation::operator=( const CTraceCreation & other)
{
	if ( this == &other )
		return *this;

	ATLTRACE("*** Assignment of ID<%d-%s>\n", other.mID, other.mCreationType );	// .GetCreationString() );
	mCreationType = CT_ASSIGN;
	Init( (char*)other.mName.c_str() );

	return *this;
}

//////////////////////////////////////////////////
// Destructor
//////////////////////////////////////////////////
//
CTraceCreation::~CTraceCreation()
{
	TRY_START


	TraceCreationData data;
	TraceCreationMap::iterator it = mObjects.find( mName );
	if ( it == mObjects.end() )
	{
		// shouldn't ever happen
		std::string name = (std::string)((*it).first);
		AtlTrace("~~~ Error in destructor <%*s>\n", mMaxLen, name.c_str() );
	}
	else
	{
		char* name = (char*) ( ((std::string)((*it).first)).c_str()) ;
		data = (TraceCreationData)((*it).second);

		bool active = IsObjectActive();

		if ( !active )
		{
			AtlTrace("~~~ ERR %*s : deleting object again %d\n", mMaxLen, name, mID );
			assert(true);
		}
		else
		{
			AtlTrace("~~~ %*s ID<%d> being Destroyed.\n", mMaxLen, name, mID);
///			mID *= -1;
			data.active--;
			AtlTrace("~~~ %*s %d active out of %d\n", mMaxLen, name, data.active, data.max );
		}
		mObjects[mName] = data;

		TraceCreationActiveMap::iterator ita = mActiveObjects.find( name );	// begin();
		bVec *activeList = (bVec*)((*ita).second);
		activeList->at( mID ) = false;

//		ShowCount( name );
	}

	ShowObjects();
	
	TRY_STOP
}

//////////////////////////////////////////////////
// Initialize routine
//////////////////////////////////////////////////
//
void CTraceCreation::Init( char * name )
{
	TRY_START

	mName = name;
	if ( mName.length() > mMaxLen )
		mMaxLen = mName.length();

	TraceCreationData data;
	bVec *activeList = NULL;
	TraceCreationMap::iterator it = mObjects.find( name );
	if ( it == mObjects.end() )
	{
		data.active = 1;
		data.max = 1;

		// add entry to the active map as well
		activeList = new bVec;
		activeList->push_back( false );			// zero index is place holder
		mActiveObjects[ name ] = activeList;
	}
	else
	{
		TraceCreationActiveMap::iterator ita = mActiveObjects.find( name );	// begin();
		activeList = (*ita).second;	// mActiveObjects.find( name );
		data = (TraceCreationData)((*it).second);
		data.active++;
		data.max++;
	}
	activeList->push_back( true  );			// this id is active
	
	mID = data.max;
	mObjects[name] = data;	// mID;
	AtlTrace("+++ %*s %d being Created, %d active\n", mMaxLen, name, mID, data.active );
	
	TRY_STOP
}

//////////////////////////////////////////////////
// Static routine to show all objects and counts
//////////////////////////////////////////////////
//
void CTraceCreation::ShowObjects()
{
	TRY_START
	
///	AtlTrace("*** %-*s ********  *****\n", mMaxLen, "*******" );
	AtlTrace("*** %-*s **********  **********\n", mMaxLen, "**********" );

	TraceCreationMap::iterator it = mObjects.begin();
	if ( it == mObjects.end() )
	{
		AtlTrace("*** No Objects currently exist\n" );
	}

	TraceCreationData data;
	std::string name;
	while ( it != mObjects.end() )
	{
		name = (std::string)((*it).first);
		data = (TraceCreationData)((*it).second);
///		AtlTrace("*** %-*s %d active %d max\n", mMaxLen, name.c_str(), data.active, data.max );
		AtlTrace("*** %-*s (%2d of %2d) ", mMaxLen, name.c_str(), data.active, data.max );

		// now show the individual active status
		TraceCreationActiveMap::iterator ita = mActiveObjects.find( name );	// begin();
		bVec *activeStatus = (*ita).second;	// mActiveObjects.find( name );

///		AtlTrace("***  %s ", "Active IDs [" );
		AtlTrace("[ " );
		for ( unsigned int i=1; i<activeStatus->size(); i++)
		{
			if ( activeStatus->at(i) )
			{
				AtlTrace("%d", i);
				if ( i+1 < activeStatus->size() )
					AtlTrace(", ");
			}
		}
		AtlTrace(" ]\n");

		it++;
	}
//	AtlTrace("*** End\n" );
	AtlTrace("*** %-*s ********  *****\n", mMaxLen, "*******" );
	

	TRY_STOP
}

//////////////////////////////////////////////////
// Show the count for the passed in class name
//////////////////////////////////////////////////
//
void CTraceCreation::ShowCount( char* name )
{
	TRY_START

	TraceCreationMap::iterator it = mObjects.find( name );
	if ( it == mObjects.end() )
	{
		AtlTrace("*** No Objects of this type have been created\n" );
	}
	else
	{
		std::string name = (std::string)((*it).first);
		TraceCreationData data = (TraceCreationData)((*it).second);
		AtlTrace("*** %*s has %d active, %d max\n", mMaxLen, name.c_str(), data.active, data.max );
	}
	
	TRY_STOP
}

//////////////////////////////////////////////////
// See if the current object is in an active state
//////////////////////////////////////////////////
//
bool CTraceCreation::IsObjectActive()
{
	bool rval = false;

	TRY_START

	TraceCreationActiveMap::iterator it = mActiveObjects.find( mName );
	if ( it == mActiveObjects.end() )
	{
		AtlTrace("~~~ Error in IsObjectActive<%*s>\n", mMaxLen, mName.c_str() );
	}
	else
	{
		bVec *activeList = (bVec*)((*it).second);
		rval = activeList->at( mID );
	}
	

	TRY_STOP

	return rval;
}

//////////////////////////////////////////////////
// Get the creation string for the type
//////////////////////////////////////////////////
//
char* CTraceCreation::GetCreationString() 
{ 
	switch (mCreationType) 
	{ 
	case CT_COPY: return "copy";
		break;
	case CT_ASSIGN: return "assignment";
		break;
	case CT_CONS: return "constructor";
		break;
	case CT_UNKNOWN: return "unknown";
		break;
	}
	return "unknown";
}