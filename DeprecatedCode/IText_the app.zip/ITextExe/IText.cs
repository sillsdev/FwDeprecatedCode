// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: IText.cs
// Responsibility: JohnT
// Last reviewed: 
// 
// <remarks>
// Based on stuff from LexEdExe and LexEdDll.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using Microsoft.Win32; // for RegistryKey

namespace SIL.FieldWorks.IText
{
	/// <summary>
	/// Summary description for IText.
	/// </summary>
	public class IText
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Application entry point. If IText isn't already running,
		/// an instance of the app is created.
		/// </summary>
		/// <param name="rgArgs">Command-line arguments</param>
		/// <returns>0</returns>
		/// -----------------------------------------------------------------------------------
		[STAThread]
		public static int Main(string[] rgArgs)
		{
			return ITextApp.Main(rgArgs);
		}
	}
}
