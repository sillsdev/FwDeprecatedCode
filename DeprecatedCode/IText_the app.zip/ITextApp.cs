// --------------------------------------------------------------------------------------------
#region // Copyright (c) 2003, SIL International. All Rights Reserved.   
// <copyright from='2003' to='2003' company='SIL International'>
//		Copyright (c) 2003, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: IText.cs
// Responsibility: JohnT
// Last reviewed: 
// 
// <remarks>
// Based on stuff from LexEdExe and LexEdDll.
// </remarks>
// --------------------------------------------------------------------------------------------
using System;
using Microsoft.Win32; // for RegistryKey
using System.Diagnostics;

using XCore;
using SIL.FieldWorks.XWorks;

namespace SIL.FieldWorks.IText
{
	/// <summary>
	/// Summary description for ITextApp.
	/// </summary>
	public class ITextApp : FwXApp
	{
		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Application entry point. If ITextApp isn't already running, an instance of the app is
		/// created.
		/// </summary>
		/// 
		/// <param name="rgArgs">Command-line arguments</param>
		/// 
		/// <returns>0</returns>
		/// -----------------------------------------------------------------------------------
		[STAThread]
		public static int Main(string[] rgArgs)
		{
			using(ITextApp application = new ITextApp(rgArgs))
			{
				application.Run();
			}
			return 0;
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="arguments">Command line arguments.</param>
		protected ITextApp(string[] arguments) : base(arguments)
		{
		}

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// Guid for the application (used for uniquely identifying DB items that "belong" to
		///		this app.
		/// </summary>
		/// -----------------------------------------------------------------------------------
		public static Guid AppGuid
		{
			get
			{
				return new Guid("76A0FFFE-CA07-4042-96E4-A6CC2CA19C1B");
			}
		}

		/// <summary>
		/// This application processes DB sync records (and may send them).
		/// </summary>
		public override Guid SyncGuid
		{
			get { return AppGuid; }
		}

		public override string ProductName
		{
			get { return "IText"; }
		}

		public override string DefaultConfigurationPathname
		{
			get { return @"IText\IText.xml"; }
		}

		#region ISettings implementation

		// Imherited implementation is just fine for: KeepWindowSizePos.

		/// -----------------------------------------------------------------------------------
		/// <summary>
		/// The RegistryKey for this application.
		/// </summary>
		///***********************************************************************************
//		override public RegistryKey SettingsKey
//		{
//			get 
//			{
//				return base.SettingsKey.CreateSubKey("IText");
//			}
//		}
		protected override string SettingsKeyName
		{
			get {return "IText";}
		}

		#endregion // ISettings implementation

		/// <summary>
		/// override this with the name of your icon (Important: all lower case.)
		/// This icon file should be included in the assembly, and its "build action" should be set to "embedded resource"
		/// Review RandyR/JohnH (JohnT): In LexEd, the icon name is LexEd.ico, but the icon I made ends up with
		/// the following name, without the extension. Not sure what is going on.
		/// </summary>
		protected override string ApplicationIconName
		{
			get { return "IText.ico"; }
		}
	}
}
