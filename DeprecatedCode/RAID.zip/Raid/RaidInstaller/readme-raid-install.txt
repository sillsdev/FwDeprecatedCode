This documentation covers the process of regenerating the Raid installer.
For instructions on installing Raid, see \fw\Doc\Raid.htm under source control.


The rest of this README file tells how to recreate the setup program.

You can just copy the Raid executable over to a new machine, but it may take several rounds
of trial and error in which the new machine says "missing file MSXYZ.OCX" and you have to
go find that file on another machine and copy it over too.

To avoid that, we create a package in VB using the Package and Deployment Wizard.
This Wizard determines what files Raid depends on, and packages them with it in a setup file.
The P&D Wizard is on the Add-Ins menu; if it's not there, go to Add-Ins / Add-In Manager,
select Package and Deployment Wizard, and check the Loaded/Unloaded checkbox.

Once you've started the wizard, click on Package.
On the next dialog, for Packaging script, choose Raid Setup Package (not Dep File).
For type of package, choose Standard Setup Package.
When you get a chance to Add files, add these from the bin directory:
about-raid.wav
tink-raid.wav
FwBugList.Bug


3/22/2001, updated 4/11/2002
Lars Huttar
