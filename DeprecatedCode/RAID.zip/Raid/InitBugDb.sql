create table [MetaTblInfo] (
	[ID] int primary key clustered,
	[Name] varchar(20) not null,
	[Fld] varchar(20) not null,
	[Static] bit not null,
	[Ordered] bit not null)

create table [WhoList] (
	[ID] int identity(0, 1) primary key clustered,
	[Who] varchar(50))
insert [MetaTblInfo] values(0, 'WhoList', 'Who', 0, 0)

create table [StatList] (
	[ID] int primary key clustered,
	[Stat] varchar(15))
insert [MetaTblInfo] values(1, 'StatList', 'Stat', 1, 1)

create table [SevList] (
	[ID] int primary key clustered,
	[Sev] varchar(20))
insert [MetaTblInfo] values(2, 'SevList', 'Sev', 1, 1)

create table [PriList] (
	[ID] int primary key clustered,
	[Pri] varchar(20))
insert [MetaTblInfo] values(3, 'PriList', 'Pri', 1, 1)

create table [ResList] (
	[ID] int primary key clustered,
	[Res] varchar(20))
insert [MetaTblInfo] values(4, 'ResList', 'Res', 1, 0)

create table [TypeList] (
	[ID] int primary key clustered,
	[Type] varchar(20))
insert [MetaTblInfo] values(5, 'TypeList', 'Type', 1, 0)

create table [PlatList] (
	[ID] int identity(0, 1) primary key clustered,
	[Plat] varchar(20))
insert [MetaTblInfo] values(6, 'PlatList', 'Plat', 0, 0)

create table [CompList] (
	[ID] int identity(0, 1) primary key clustered,
	[Comp] varchar(20))
insert [MetaTblInfo] values(7, 'CompList', 'Comp', 0, 0)

create table [TSuiteList] (
	[ID] int identity(0, 1) primary key clustered,
	[TSuite] varchar(20))
insert [MetaTblInfo] values(8, 'TSuiteList', 'TSuite', 0, 0)

create table [MetaFldInfo] (
	[ID] int primary key clustered,
	[SortKey] int not null,
	[Name] varchar(10) not null,
	[HistNewName] varchar(10) not null,
	[HistOldName] varchar(20) not null,
	[UserName] varchar(20) not null,
	[HistNewUserName] varchar(20) not null,
	[HistOldUserName] varchar(20) not null,
	[Tip] varchar(60) not null,
	[Table] int null,
	foreign key ([Table]) references [MetaTblInfo] ([ID]),
	[CtlType] int not null,
	[Static] bit not null,
	[Show] bit not null,
	[Required] bit not null,
	[Banner] bit not null,
	[GrfraActive] int not null,
	[ListWidth] int not null,
	[XPos] int not null,
	[YPos] int not null,
	[DetWidth] int not null,
	[InitRules] ntext)
insert [MetaFldInfo] values(1, 100, 'ID', '', '', 'ID', '', '', '', null, 1,
	1, 1, 0, 0,
	0, -1, 0, 0, 1, null)
insert [MetaFldInfo] values(2, 200, 'Stat', 'StatNew', 'StatOld', 'Status', 'Hist.Status', 'Hist.StatusPrev', '', 1, 4,
	1, 1, 1, 1,
	0, -1, 1, 0, 1, null)
insert [MetaFldInfo] values(3, 100000, 'Log', '', '', 'Log', '', '', '', null, 0,
	0, 0, 0, 0,
	0, -1, 0, 9, 1, null)
insert [MetaFldInfo] values(4, 400, 'Type', '', '', 'Type', '', '', '', 5, 4,
	0, 1, 1, 0,
	961, -1, 2, 0, 1, 'i1::2::^1')
insert [MetaFldInfo] values(5, 500, 'ATo', 'AToNew', '', 'Assignee', 'Hist.Assignee', '', 'person to whom the record is assigned', 0, 3,
	0, 1, 1, 1,
	-1, 1500, 0, 1, 1,
'i1::2::^3//i24::2::^${RBy}//i2::8::!
select [EByNew] from [History]
where [RecID]=${id} and [StatNew]=1 and [StatOld]<>1
Order by [ID] desc
//i8::16::^1//i2::4::^2//i4::2::!
select [AToNew] from [History]
where [RecID]=${id} and [StatNew]=1
Order By [ID] Desc')
insert [MetaFldInfo] values(6, 600, 'EBy', 'EByNew', '', 'Editor', 'Hist.Editor', '', 'last person to edit the record', 0, 3,
	0, 0, 1, 1,
	-1, 1500, 1, 1, 1,
'i31::30::!
select [ID]
from [WhoList]
where [Who]=''${#user}''')
insert [MetaFldInfo] values(7, 700, 'EDate', 'EDateNew', '', 'Edit Date', 'Hist.EditDate', '', 'when the record was last edited', null, 2,
	1, 0, 0, 1,
	0, 1500, 2, 1, 1,
'g#
function main(f)
	main = "Convert(nchar(19), " & f & ", 120)"
end function
//f%yyyy-mm-dd Hh:Nn:Ss//l%''yyyy-mm-dd Hh:Nn:Ss''//s31::31::#
function main(d)
	main = d
end function
//m^_####-##-## ##:##:##//u#
function main(v)
	dim d
	on error resume next
	d = DateSerial(CInt(mid(v,1,4)), CInt(mid(v,6,2)), CInt(mid(v,9,2))) + TimeSerial(CInt(mid(v,12,2)), CInt(mid(v,15,2)), CInt(mid(v, 18, 2)))
	on error goto 0
	if vartype(d) = 0 then main = null else main = d
end function
')
insert [MetaFldInfo] values(8, 800, 'Desc', '', '', 'Description', '', '', '', null, 0,
	0, 1, 1, 0,
	965, 4000, 0, 2, 3, null)
insert [MetaFldInfo] values(9, 900, 'MSt', '', '', 'Milestone', '', '', 'first digit is version, second digit is milestone', null, 2,
	0, 0, 1, 0,
	-1, -1, 0, 3, 1,
'i1::2::^11//m^_##//l#
function main(v)
	main = "''" & v & "''"
end function
')
insert [MetaFldInfo] values(10, 1000, 'Sev', '', '', 'Severity', '', '', '', 2, 4,
	0, 0, 1, 0,
	981, -1, 0, 4, 1, 'i1::2::^1')
insert [MetaFldInfo] values(11, 1100, 'Pri', '', '', 'Priority', '', '', '', 3, 4,
	0, 0, 1, 0,
	981, -1, 0, 5, 1, 'i1::2::^1')
insert [MetaFldInfo] values(12, 1200, 'Plat', '', '', 'Platform', '', '', 'OS on which the bug is known to occur', 6, 3,
	0, 0, 0, 0,
	981, -1, 1, 3, 1,
'c31::31::#
function main(d)
	if (${Type}=1) and (${Plat}=0) then
		main=false
	else
		main=true
	end if
end function
')
insert [MetaFldInfo] values(13, 1300, 'Res', '', '', 'Resolution', '', '', '', 4, 4,
	0, 0, 1, 0,
	784, -1, 1, 4, 1, 'i2::8::^1//i31::6::^0')
insert [MetaFldInfo] values(14, 1400, 'Dup', '', '', 'Duplicate', '', '', 'should be empty unless resolution is "Duplicate"', null, 1,
	0, 0, 0, 0,
	784, -1, 1, 5, 1,
'i31::6::^//c31::8::#
function main(d)
	if ${res}<>3 then
		main = isnull(${dup})
	elseif isnull(${dup}) or (${dup} = ${id}) then
		main = false
	end if
end function
//c31::8::!
select count(*)
from [RecList]
where [RecList].[ID]=${dup}
')
insert [MetaFldInfo] values(15, 1500, 'Comp', '', '', 'Component', '', '', '', 7, 3,
	0, 0, 0, 0,
	981, -1, 2, 3, 1, null)
insert [MetaFldInfo] values(16, 1600, 'OBld', '', '', 'OpenBuild', '', '', 'VV.vv.yyyy.mmddx', null, 2,
	0, 0, 0, 0,
	961, -1, 0, 6, 1,
'i1::2::#
function main(d)
	dim sRet
	dim nT
	sRet = "01.00." & Year(d) & "."
	nT = (Month(d) * 100 + Day(d)) * 10
	if nT < 10000 then sRet = sRet & "0"
	main = sRet & nT
end function
//m^_##\.##\.####\.#####//l#
function main(v)
	main = "''" & v & "''"
end function
')
insert [MetaFldInfo] values(17, 1700, 'RBld', '', '', 'ResolveBuild', '', '', 'VV.vv.yyyy.mmddx', null, 2,
	0, 0, 0, 0,
	784, -1, 1, 6, 1,
'i31::6::^//i2::8::#
function main(d)
	dim sRet
	dim nT
	sRet = Left("${OBld}", 6) & Year(d) & "."
	nT = (Month(d) * 100 + Day(d)) * 10 + 9
	if nT < 10000 then sRet = sRet & "0"
	main = sRet & nT
end function
//m^_##\.##\.####\.#####//l#
function main(v)
	main = "''" & v & "''"
end function
')
insert [MetaFldInfo] values(18, 1800, 'CBld', '', '', 'CloseBuild', '', '', 'VV.vv.yyyy.mmddx', null, 2,
	0, 0, 0, 0,
	544, -1, 2, 6, 1,
'i31::14::^//i8::16::#
function main(d)
	dim sRet
	dim nT
	sRet = Left("${OBld}", 6) & Year(d) & "."
	nT = (Month(d) * 100 + Day(d)) * 10
	if nT < 10000 then sRet = sRet & "0"
	main = sRet & nT
end function
//m^_##\.##\.####\.#####//l#
function main(v)
	main = "''" & v & "''"
end function
')
insert [MetaFldInfo] values(19, 1900, 'OBy', '', '', 'Author', '', '', 'person who originally created the record', 0, 3,
	1, 0, 0, 0,
	0, -1, 0, 7, 1, 's1::2::^${EBy}')
insert [MetaFldInfo] values(20, 2000, 'RBy', '', '', 'Resolver', '', '', 'last person to resolve the record', 0, 3,
	1, 0, 0, 0,
	0, 1500, 1, 7, 1, 'i31::6::^0//s23::8::^${EBy}')
insert [MetaFldInfo] values(21, 2100, 'CBy', '', '', 'Closer', '', '', 'last person to close the record', 0, 3,
	1, 0, 0, 0,
	0, -1, 2, 7, 1, 'i31::14::^0//s15::16::^${EBy}')
insert [MetaFldInfo] values(22, 2200, 'ODate', '', '', 'OpenDate', '', '', '', null, 2,
	1, 0, 0, 0,
	0, -1, 0, 8, 1,
'g#
function main(f)
	main = "Convert(nchar(19), " & f & ", 120)"
end function
//f%yyyy-mm-dd Hh:Nn:Ss//l%''yyyy-mm-dd Hh:Nn:Ss''//s1::2::#
function main(d)
	main = d
end function
//m^_####-##-## ##:##:##//u#
function main(v)
	dim d
	on error resume next
	d = DateSerial(CInt(mid(v,1,4)), CInt(mid(v,6,2)), CInt(mid(v,9,2))) + TimeSerial(CInt(mid(v,12,2)), CInt(mid(v,15,2)), CInt(mid(v, 18, 2)))
	on error goto 0
	if vartype(d) = 0 then main = null else main = d
end function
')
insert [MetaFldInfo] values(23, 2300, 'RDate', '', '', 'ResolveDate', '', '', '', null, 2,
	1, 0, 0, 0,
	0, -1, 1, 8, 1,
'g#
function main(f)
	main = "Convert(nchar(19), " & f & ", 120)"
end function
//f%yyyy-mm-dd Hh:Nn:Ss//l%''yyyy-mm-dd Hh:Nn:Ss''//i31::6::^//s23::8::#
function main(d)
	main = d
end function
//m^_####-##-## ##:##:##//u#
function main(v)
	dim d
	on error resume next
	d = DateSerial(CInt(mid(v,1,4)), CInt(mid(v,6,2)), CInt(mid(v,9,2))) + TimeSerial(CInt(mid(v,12,2)), CInt(mid(v,15,2)), CInt(mid(v, 18, 2)))
	on error goto 0
	if vartype(d) = 0 then main = null else main = d
end function
')
insert [MetaFldInfo] values(24, 2400, 'CDate', '', '', 'CloseDate', '', '', '', null, 2,
	1, 0, 0, 0,
	0, -1, 2, 8, 1,
'g#
function main(f)
	main = "Convert(nchar(19), " & f & ", 120)"
end function
//f%yyyy-mm-dd Hh:Nn:Ss//l%''yyyy-mm-dd Hh:Nn:Ss''//i31::14::^//s15::16::#
function main(d)
	main = d
end function
//m^_####-##-## ##:##:##//u#
function main(v)
	dim d
	on error resume next
	d = DateSerial(CInt(mid(v,1,4)), CInt(mid(v,6,2)), CInt(mid(v,9,2))) + TimeSerial(CInt(mid(v,12,2)), CInt(mid(v,15,2)), CInt(mid(v, 18, 2)))
	on error goto 0
	if vartype(d) = 0 then main = null else main = d
end function
')
insert [MetaFldInfo] values(25, 1510, 'TSuite', '', '', 'Test Suite', '', '', 'official test suite name', 8, 3,
	0, 0, 0, 0,
	-1, -1, 2, 4, 1, 'i1::2::^0')
insert [MetaFldInfo] values(26, 1520, 'TNum', '', '', 'Test Number', '', '', 'official test number', null, 1,
	0, 0, 0, 0,
	-1, -1, 2, 5, 1, null)

create table [RecList] (
	[ID] int identity(1, 1) primary key clustered,
	[Stat] int not null,
	foreign key ([Stat]) references [StatList] ([ID]),
	[Log] ntext not null,
	[Type] int not null default 1,
	foreign key ([Type]) references [TypeList] ([ID]),
	[ATo] int not null,
	foreign key ([ATo]) references [WhoList] ([ID]),
	[EBy] int not null,
	foreign key ([EBy]) references [WhoList] ([ID]),
	[EDate] datetime not null,
	[Desc] nvarchar(300) not null,
	[MSt] char(2) not null,
	[Sev] int not null,
	foreign key ([Sev]) references [SevList] ([ID]),
	[Pri] int not null,
	foreign key ([Pri]) references [PriList] ([ID]),
	[Plat] int not null default 0,
	foreign key ([Plat]) references [PlatList] ([ID]),
	[Res] int not null default 0,
	foreign key ([Res]) references [ResList] ([ID]),
	[Dup] int null,
	foreign key ([Dup]) references [RecList] ([ID]),
	[Comp] int not null default 0,
	foreign key ([Comp]) references [CompList] ([ID]),
	[OBld] char(16) not null,
	[RBld] char(16) null,
	[CBld] char(16) null,
	[OBy] int not null default 0,
	foreign key ([OBy]) references [WhoList] ([ID]),
	[RBy] int not null default 0,
	foreign key ([RBy]) references [WhoList] ([ID]),
	[CBy] int not null default 0,
	foreign key ([CBy]) references [WhoList] ([ID]),
	[ODate] datetime not null,
	[RDate] datetime null,
	[CDate] datetime null,
	[TSuite] int not null,
	foreign key ([TSuite]) references [TSuiteList] ([ID]),
	[TNum] int null)

create table [History] (
	[ID] int identity(1, 1) primary key clustered,
	[RecID] int not null,
	foreign key ([RecID]) references [RecList] ([ID]),
	[StatOld] int not null default 0,
	foreign key ([StatOld]) references [StatList] ([ID]),
	[StatNew] int not null,
	foreign key ([StatNew]) references [StatList] ([ID]),
	[AToNew] int not null,
	foreign key ([AToNew]) references [WhoList] ([ID]),
	[EByNew] int not null,
	foreign key ([EByNew]) references [WhoList] ([ID]),
	[EDateNew] datetime not null)

create table [LinkList] (
	[LoID] int not null,
	foreign key ([LoID]) references [RecList] ([ID]),
	[HiID] int not null,
	foreign key ([HiID]) references [RecList] ([ID]),
	primary key clustered ([LoID], [HiID]),
	check ([LoID] < [HiID]),
	[Com] nvarchar(100) null)

create table [AttachList] (
	[ID] int identity(1, 1) primary key clustered,
	[SrcID] int not null,
	foreign key ([SrcID]) references [RecList] ([ID]),
	[FName] nvarchar(100) not null,
	[Com] nvarchar(100) null,
	[Data] image not null)


insert [WhoList]([Who]) values(null)
insert [WhoList]([Who]) values('Closed')
insert [WhoList]([Who]) values('Postponed')
insert [WhoList]([Who]) values('Development')
insert [WhoList]([Who]) values('Testing')
insert [WhoList]([Who]) values('PM')

insert [StatList] values(0, null)
insert [StatList] values(1, 'Active')
insert [StatList] values(2, 'Postponed')
insert [StatList] values(3, 'Resolved')
insert [StatList] values(4, 'Closed')

insert [SevList] values(1, '1 - Fatal')
insert [SevList] values(2, '2 - Serious')
insert [SevList] values(3, '3 - Minor')

insert [PriList] values(1, '1 - Blocking')
insert [PriList] values(2, '2 - High')
insert [PriList] values(3, '3 - Medium')
insert [PriList] values(4, '4 - Low')

insert [ResList] values(0, null)
insert [ResList] values(1, 'Fixed')
insert [ResList] values(2, 'By Design')
insert [ResList] values(3, 'Duplicate')
insert [ResList] values(4, 'Can''t Repro')
insert [ResList] values(5, 'Won''t Fix')

insert [TypeList] values(1, 'Bug')
insert [TypeList] values(2, 'Task')
insert [TypeList] values(3, 'Issue')

insert [PlatList] ([Plat]) values(null)
insert [PlatList] ([Plat]) values('Multiple')
insert [PlatList] ([Plat]) values('NT4.0')
insert [PlatList] ([Plat]) values('Win95')
insert [PlatList] ([Plat]) values('Win98')

insert [CompList] ([Comp]) values(null)

insert [TSuiteList] ([TSuite]) values(null)

