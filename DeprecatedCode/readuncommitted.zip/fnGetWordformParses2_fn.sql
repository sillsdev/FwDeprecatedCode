/********************************************************************
 * Function: fnGetWordformParses2
 *
 * Description: 
 *	Gets different lists of wordforms 
 *
 * Parameters: 
 *	@nNonhumanId = Agent ID of the parser
 *	@nHumanId = Agent ID of the human
 *	@nWritingSysetm = Writing System ID
 *	@cParseType = Type of parse (see below)
 *
 *	Parse Types:
 *	------------
 *	CmAgent --> CmAgentEvals ---set A-->WfiAnalysis --> WfiWordform
 *	CmAgent --> CmAgentEvals ---set P---^
 *
 *		Perfect:	Set A = Set P
 *		Missing:	Set P *doesn't* have 1+ analyses of Set A
 *		Extra:		Set P *has* 1+ analyses of Set A
 *		Problem:	wordforms have analyses approved by the
 *					nonhuman but not approved by the human
 *
 * Returns: 
 *	Table containing WfiWordForm_Form information in the format:
 *		[Id]	INT				= Wordform Id
 *		[Txt]	NVARCHAR(4000)	= Wordform text
 *
 * Sample Call:
 *	SELECT * FROM fnGetWordformParses2 (5885, 7545, 'All')
 *******************************************************************/

IF OBJECT_ID('fnGetWordformParses2') IS NOT NULL BEGIN
	PRINT 'removing function fnGetWordformParses2'
	DROP FUNCTION fnGetWordformParses2
END
GO
PRINT 'creating function fnGetWordformParses2'
GO

-- REVIEW (SteveMiller): the function appears not to be in use. If
-- ever it comes back into use, the unit tests should be activated
-- and updated.

CREATE FUNCTION [fnGetWordformParses2] (
	@nNonhumanId INT,
	@nHumanId INT,
	@nWritingSystem INT,
	@cParseType CHAR(10))
RETURNS @tblWordFormParses TABLE (
	[Id] INT,
	--( See the notes under string tables in FwCore.sql about the 
	--( COLLATE clause.
	Txt NVARCHAR(4000) COLLATE Latin1_General_BIN)
AS
BEGIN
	
	IF @cParseType = 'Problem' BEGIN
		
		--( This query carries the assumption that no human evaluations matching
		--( accepted nonhuman evaluations will be covered in the 'Missing' node.
		
		INSERT INTO @tblWordFormParses
		SELECT DISTINCT wf.Obj, wf.Txt
		FROM wfiWordform_Form wf (READUNCOMMITTED)
		JOIN  WfiWordform_Analyses wa (READUNCOMMITTED) ON wa.Src = wf.Obj
		JOIN CmAgentEvaluation ae_nonhuman (READUNCOMMITTED) ON ae_nonhuman.Target = wa.Dst
			AND ae_nonhuman.Accepted = 1
		JOIN CmObject aeo_nonhuman (READUNCOMMITTED) ON aeo_nonhuman.[Id] = ae_nonhuman.[Id]
			AND aeo_nonhuman.Owner$ = @nNonhumanId
		JOIN CmAgentEvaluation ae_human (READUNCOMMITTED) ON ae_human.Target = wa.Dst
			AND ae_human.Accepted = 0
		JOIN CmObject aeo_human (READUNCOMMITTED) ON aeo_human.[Id] = ae_human.[Id]
			AND aeo_human.Owner$ = @nHumanId
		WHERE ae_nonhuman.Target = ae_human.Target --( helps performance
		ORDER BY Txt
		
	END
	ELSE BEGIN
		
		--( The Perfect, Missing, and Extra nodes are treated here as
		--( mutually exclusive. That is, the Perfect has the same number
		--( evals between the human and nonhuman. The Missing node has
		--( less human evals than nonhuman, and the Extra node has more
		--( human evals than nonhuman.
				
		-- TODO (SteveMiller): This function was redone when ParseBench
		-- was being phased out and LexText was being phased in. Need to 
		-- see this work with all the pieces put together.
		
		-- REVIEW (SteveMiller): This has the potential of being sped up,
		-- possibly by combining two queries into derived tables.
		
		DECLARE @tblHumanCount TABLE (Obj INT, EvalCount INT)
		DECLARE @tblNonHumanCount TABLE (Obj INT, EvalCount INT)
		
		--( Get the count of evals on each wordform made be the human
			
		INSERT INTO @tblHumanCount
		SELECT wf.Obj, COUNT(ae_Human.[Id])
		FROM wfiWordform_Form wf (READUNCOMMITTED)
		JOIN  WfiWordform_Analyses wa (READUNCOMMITTED) ON wa.Src = wf.Obj
		JOIN CmAgentEvaluation ae_Human (READUNCOMMITTED) ON ae_Human.Target = wa.Dst
		JOIN CmObject aeo_Human (READUNCOMMITTED) ON aeo_Human.[Id] = ae_Human.[Id]
			AND aeo_Human.Owner$ = @nHumanId
		WHERE wf.ws = @nWritingSystem
		GROUP BY wf.Obj
		
		--( Get the count of evals on each wordform made be the nonhuman
		
		INSERT INTO @tblNonHumanCount
		SELECT wf.Obj, COUNT(ae_NonHuman.[Id])
		FROM wfiWordform_Form wf (READUNCOMMITTED)
		JOIN  WfiWordform_Analyses wa (READUNCOMMITTED) ON wa.Src = wf.Obj
		JOIN CmAgentEvaluation ae_NonHuman (READUNCOMMITTED) ON ae_NonHuman.Target = wa.Dst
		JOIN CmObject aeo_NonHuman (READUNCOMMITTED) ON aeo_NonHuman.[Id] = ae_NonHuman.[Id]
			AND aeo_NonHuman.Owner$ = @nNonHumanId
		WHERE wf.ws = @nWritingSystem
		GROUP BY wf.Obj
		
		--( See where the human and the nonhuman match/don't match
		
		IF @cParseType = 'Perfect'
			
			-- REVIEW (SteveMiller): Perfect here means that the has
			-- the same number evals by both the human and nonhuman. 
			-- It doesn't take into account whether one is accepted
			-- and the other isn't.
			
			INSERT INTO @tblWordFormParses
			SELECT h.Obj, wf.Txt
			FROM @tblHumanCount h
			JOIN wfiWordform_Form wf (READUNCOMMITTED) ON wf.Obj = h.Obj
			JOIN @tblNonHumanCount n ON n.Obj = h.Obj
			WHERE  h.EvalCount = n.EvalCount
			ORDER BY wf.Txt
		
		ELSE IF @cParseType = 'Missing'
			
			INSERT INTO @tblWordFormParses
			SELECT n.Obj, wf.Txt
			FROM @tblNonHumanCount n
			JOIN wfiWordform_Form wf (READUNCOMMITTED) ON wf.Obj = n.Obj
			LEFT OUTER JOIN @tblHumanCount h ON h.Obj = n.Obj
			WHERE n.EvalCount > COALESCE(h.EvalCount, 0)
			ORDER BY wf.Txt
					
		ELSE IF @cParseType = 'Extra'
					
			INSERT INTO @tblWordFormParses
			SELECT h.Obj, wf.Txt
			FROM @tblHumanCount h
			JOIN wfiWordform_Form wf (READUNCOMMITTED) ON wf.Obj = h.Obj
			LEFT OUTER JOIN @tblNonHumanCount n ON n.Obj = h.Obj
			WHERE h.EvalCount > COALESCE(n.EvalCount, 0)
			ORDER BY wf.Txt
			
		--( END
	END
	RETURN
END
GO
