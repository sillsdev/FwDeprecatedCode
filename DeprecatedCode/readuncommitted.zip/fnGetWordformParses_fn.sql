/********************************************************************
 * Function: fnGetWordformParses
 *
 * Description: 
 *	Gets different lists of wordforms 
 *
 * Parameters: 
 *	@nAgentId = Agent ID
 *	@nWritingSysetm = Writing System ID
 *	@cParseType = Type of parse (see below)
 *
 *	Parse Types:
 *	------------
 *	CmAgent --> CmAgentEvals ---set A-->WfiAnalysis --> WfiWordform
 *	CmAgent --> CmAgentEvals ---set P---^
 *
 *		Perfect:	Set A = Set P (in function fnGetWordformParses2 
 *					below)
 *		Missing:	Set P *doesn't* have 1+ analyses of Set A
 *					(in function fnGetWordformParses2 below)
 *		Extra:		Set P *has* 1+ analyses of Set A (in 
 *					function fnGetWordformParses2 below)
 *		Problem:	wordforms have analyses approved by the
 *					nonhuman but not approved by the human (in
 *					function fnGetWordformParses2 below)
 *		NeedsEval:	Wordforms have analyses which do not have agent
 *					evals (error for nonhuman)
 *		Some:		wordforms have analyses that have evaluations 
 *					by the agent
 *		Never:		wordforms have no evals by the agent (parser).
 *					(error for human)
 *		Don't Parse: Same as 0 (below); drop from the interface
 *		0 Parses:	wordform has an evaluation, but analyses--if
 *					any-- don't have evaluations. (In function
 *					fnGetParseCountRange).
 *
 * Returns: 
 *	Table containing WfiWordForm_Form information in the format:
 *		[Id]	INT				= Wordform Id
 *		[Txt]	NVARCHAR(4000)	= Wordform text
 *
 * Sample Call:
 *	SELECT * FROM fnGetWordformParses (5885, 7545, 'All')
 *******************************************************************/

IF OBJECT_ID('fnGetWordformParses') IS NOT NULL BEGIN
	PRINT 'removing function fnGetWordformParses'
	DROP FUNCTION fnGetWordformParses
END
GO
PRINT 'creating function fnGetWordformParses'
GO

-- REVIEW (SteveMiller): the function appears not to be in use. If
-- ever it comes back into use, the unit tests should be activated
-- and updated.

CREATE FUNCTION [fnGetWordformParses] (
	@nAgentId INT,
	@nWritingSystem INT,
	@cParseType CHAR(10))
RETURNS @tblWordFormParses TABLE (
	[Id] INT,
	--( See the notes under string tables in FwCore.sql about the 
	--( COLLATE clause.
	Txt NVARCHAR(4000) COLLATE Latin1_General_BIN)
AS
BEGIN
	
	IF @cParseType = 'All'
		
		--( Including the All query here will make sure this
		--( function is called upon startup, making an execution
		--( plan. It also keeps the SQL code in one spot.
		
		--( This will return all word forms in the list.
		
		INSERT INTO @tblWordFormParses
		SELECT DISTINCT Obj, Txt
		FROM WfiWordform_Form wff (READUNCOMMITTED)
		ORDER BY Txt
	
	ELSE IF @cParseType = 'Some'
		
		--( wordforms have analyses that have evaluations by the agent
		
		INSERT INTO @tblWordFormParses
		SELECT wff.Obj, wff.Txt
		FROM wfiWordform_Form wff (READUNCOMMITTED)
		JOIN  WfiWordform_Analyses wa (READUNCOMMITTED) ON wa.Src = wff.Obj
		JOIN CmAgentEvaluation cae (READUNCOMMITTED) ON cae.Target = wa.Dst
		JOIN CmObject o (READUNCOMMITTED) ON o.[Id] = cae.[Id]
			AND o.Owner$ = @nAgentId
		ORDER BY Txt
		
	ELSE IF @cParseType = 'Never' OR @cParseType = 'NeedsEval'
		
		-- REVIEW (SteveMiller): Never is for the nonhuman parser, and 
		-- NeedsEval is for the human agent. Functionally they are the same.
		
		--(	Never:		wordforms have no evals by the agent (parser).
		--(				(error for human)
		--( NeedsEval:	Wordforms have analyses which do not have agent
		--( 			evals (error for nonhuman)
		
		--( John Hatton:
		--( "never parsed" isn't a very good name, is it? The full name 
		--( would be "the Parser has never even been asked to try to 
		--( parsed this word, so we don't know if it parses or not".
		--( Technically, I suppose this means that the parsing agent
		--( has no evaluations at all, whether good or bad, on this 
		--( wordform. It has never seen it.
		
		--( We need two queries in one: we need to return the text of the
		--( wordform(s). We also need to find evaluations only for a particular
		--( agent. Then we find where the wordform text *does not* find an
		--( evaluation from the agent.
		
		INSERT INTO @tblWordFormParses
		SELECT wff.Obj, wff.Txt
		FROM wfiWordform_Form wff (READUNCOMMITTED)
		JOIN  WfiWordform_Analyses wa (READUNCOMMITTED) ON wa.Src = wff.Obj
		LEFT OUTER JOIN (
 			--( Subselect: Get the target of all the agent evaluations which
			--( are owned by the agent passed in to this function.			
			SELECT ae.Target
			FROM CmAgentEvaluation ae (READUNCOMMITTED)
			JOIN CmObject oae (READUNCOMMITTED) ON oae.[Id] = ae.[Id]
			AND oae.Owner$ = @nAgentId
			) cae ON cae.Target = wa.Dst
		WHERE wff.ws = @nWritingSystem
			--( The wordforms that have nulls in agent evaluation targets
			--( don't have any analyses. These are the wordforms we want.
			AND cae.Target IS NULL
		ORDER BY Txt
		
	RETURN
END
GO
