/***********************************************************************************************
	Final model creation processes for the Scripture domain.

	Note: These declarations need to be ordered, such that if stored procedure X
	calls stored procedure Y, then X should be created first, then Y.
	Doing this avoids an error message about dendencies.
***********************************************************************************************/

print '****************************** Loading ScriptureSP.sql ******************************'
go


if exists (select *
             from sysobjects
            where name = 'CreateNewScrBook')
	drop proc CreateNewScrBook
go
print 'creating proc CreateNewScrBook'
go
/*****************************************************************************
 * CreateNewScrBook
 *
 * Description: Deletes an existing book (if any) and creates a new one having
 * the given "canonical" book number. It also creates a title object for the
 * book.
 * Parameters:
 *	hvoScripture	Id of owning Scripture
 * 	nBookNumber	"canonical" book number (e.g., 1=GEN, 2=EXO, ...)
 *	hvoBook		id of new ScrBook object - output
 *	hvoBookTitle	id of new Title (an StText object) - output
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc CreateNewScrBook
	@hvoScripture	int,
	@nBookNumber	int,
 	@hvoBook	int = null output,
	@hvoBookTitle	int = null output
as
  	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int, @ord int, @hvoScrBookRef int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'NewScrBook_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Determine the ScrBookRef corresponding to this book and the relative position
	-- of this book in the ScrBook table.
	set @hvoScrBookRef = 0
	select @hvoScrBookRef = [id]
	from ScrBookRef_
	where OwnOrd$ = @nBookNumber
	if @hvoScrBookRef = 0 begin
		set @err = 55678
		raiserror('No matching ScrBookRef: %d', 16, 1, @nBookNumber) 
		goto LFail
	end

  	set @clid = 3002 -- ScrBook
	set @flid = 3001001 -- Scripture_ScriptureBooks
	set @ord = 0

	-- In the case of redo, the book id could be passed in as a prameter.
	-- If not, then we check to see if there's an existing book in the
	-- ScriptureBooks sequence. If we do find an existing book, @ord will
        -- get set > 0, and we will delete it below.
	if @hvoBook is null begin
		select @ord = OwnOrd$, @hvoBook = [id]
		from ScrBook_
		where BookId = @hvoScrBookRef
		and OwnFlid$ = @flid
		and Owner$ = @hvoScripture
	end
	else if EXISTS(SELECT * FROM ScrBook_ WHERE BookId = @hvoScrBookRef) begin
		set @err = 55679
		raiserror('Redo attempting to insert existing book: ID=%d', 16, 4, @hvoBook) 
		goto LFail
	end

	if @ord > 0 begin
		-- Delete the existing book
		exec DeleteObj$ @hvoBook
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail
		end
		SET @hvoBook = null
-- REVIEW TomB: Should we be calling DeletOwnSeq here instead in order to preserve other book info?
	end
	else begin
		-- Select the lowest ord for any existing book beyond the one we want
		-- to create.
		select	@ord = coalesce(max(bk.[OwnOrd$])+1, 0)
		from	[ScrBook_] bk with (serializable)
		join	ScrBookRef_ on ScrBookRef_.[id] = bk.BookId
		and	ScrBookRef_.OwnOrd$ < @nBookNumber
		where	bk.[Owner$] = @hvoScripture
			and bk.[OwnFlid$] = @flid
  
		if exists(select * from [ScrBook_] bk with (serializable)
			where	bk.[Owner$] = @hvoScripture
			and	bk.[OwnFlid$] = @flid
			and	bk.[OwnOrd$] = @ord) begin

	  		update	[CmObject] with (serializable)
	  		set 	[OwnOrd$]=[OwnOrd$]+1
	  		where 	[Owner$] = @hvoScripture
	  			and [OwnFlid$] = @flid
	  			and [OwnOrd$] >= @ord 
			if @@error <> 0 begin 
				set @err = @@error 
				goto LFail
			end
		end
	end

	-- Create the new ScrBook (base) object
	set @guid = NewId()
	if @hvoBook is null begin
		insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values(@guid, @clid, @hvoScripture, @flid, @ord)
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail
		end
		set @hvoBook = @@identity
	end
	else begin
		insert [CmObject] ([id], [Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values(@hvoBook, @guid, @clid, @hvoScripture, @flid, @ord)
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail 
		end
	end

	-- Create the new Title (base) object
	set @clid = 14 -- StText
	set @flid = 3002004 -- Scripture_ScriptureBooks
	set @guid = NewId()

	if @hvoBookTitle is null begin
		insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values(@guid, @clid, @hvoBook, @flid, NULL)
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail
		end
		set @hvoBookTitle = @@identity
	end
	else begin
		insert [CmObject] ([id], [Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values(@hvoBookTitle, @guid, @clid, @hvoBook, @flid, NULL)
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail
		end
	end

	-- Insert into ScrBook
	insert [ScrBook] ([Id], [BookId])
	values(@hvoBook, @hvoScrBookRef)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to ScrBook: ID=%d', 16, 2, @hvoBook) 
		goto LFail
	end

	-- Insert into StText
	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoBookTitle, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 3, @hvoBookTitle) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'Import_NewScrBookJRP')
	drop proc Import_NewScrBookJRP
go
print 'creating proc Import_NewScrBookJRP'
go
/*****************************************************************************
 * Import_NewScrBookJRP
 *
 * THIS IS FOR PERFORMANCE TEST PURPOSES ONLY!!!
 *
 * Description: Deletes an existing book (if any) and creates a new one having
 * the given "canonical" book number. It also creates a title object for the
 * book.
 * Parameters:
 *	hvoScripture	Id of owning Scripture
 *      nBookNumber	"canonical" book number (e.g., 1=GEN, 2=EXO, ...)
 *	hvoBook		id of new ScrBook object - output
 *	hvoBookTitle	id of new Title (an StText object) - output
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc Import_NewScrBookJRP
	@hvoScripture	int,
	@nBookNumber	int,
 	@hvoBook	int = null output,
	@hvoBookTitle	int = null output
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int, @ord int, @hvoScrBookRef int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'NewScrBookJRP_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Determine the ScrBookRef corresponding to this book and the relative position
	-- of this book in the ScrBook table.
	set @hvoScrBookRef = 0
	select @hvoScrBookRef = [id]
	from ScrBookRef_
	where OwnOrd$ = @nBookNumber
	if @hvoScrBookRef = 0 begin
		set @err = 55678
		raiserror('No matching ScrBookRef: %d', 16, 1, @nBookNumber) 
		goto LFail
	end

	set @flid = 3001001 -- Scripture_ScriptureBooks
	set @ord = 0
	select @ord = OwnOrd$, @hvoBook = [id]
	from ScrBook_
	where BookId = @hvoScrBookRef

	if @ord > 0 begin
		-- Delete the existing book
		exec DeleteObj$ @hvoBook
-- REVIEW TomB: Should we be calling DeletOwnSeq here instead in order to preserve other book info?
	end
	else begin
		-- Select the lowest ord for any existing book beyond the one we want
		-- to create.
		select	@ord = coalesce(max(bk.[OwnOrd$])+1, 1)
		from	[ScrBook_] bk with (serializable)
		join	ScrBookRef_ on ScrBookRef_.[id] = bk.BookId
		and	ScrBookRef_.OwnOrd$ < @nBookNumber
		where	bk.[Owner$] = @hvoScripture
			and bk.[OwnFlid$] = @flid
	end

	-- Create the new ScrBook (base) object
	exec CreateObject_ScrBook
	@ScrBook_Name_ws = NULL, @ScrBook_Name_txt = NULL, 
	@ScrBook_Abbrev_ws = NULL, @ScrBook_Abbrev_txt = NULL, 
	@Owner = @hvoScripture,
	@OwnFlid = @flid,
	@StartObj = NULL,
	@NewObjId = @hvoBook output,
	@NewObjGuid = NULL

	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoScripture, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoBook = @@identity

	-- Create the new Title (base) object
	set @clid = 14 -- StText
	set @flid = 3002004 -- Scripture_ScriptureBooks
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoBook, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoBookTitle = @@identity

	-- Insert into ScrBook
	insert [ScrBook] ([Id], [BookId])
	values(@hvoBook, @hvoScrBookRef)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to ScrBook: ID=%d', 16, 1, @hvoBook) 
		goto LFail
	end

	-- Insert into StText
	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoBookTitle, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoBookTitle) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'Import_AppendScrSection')
	drop proc Import_AppendScrSection
go
print 'creating proc Import_AppendScrSection'
go
/*****************************************************************************
 * Import_AppendScrSection
 *
 * Description: Adds a Scripture ection to the end of the given ScrBook
 *
 * Parameters:
 *	hvoScrBook	Id of owning ScrBook
 *	ord		position for new section - must be max(OwningOrd$ + 1)
 *	hvoSection	Id of new ScrSection - output (optional)
 *	hvoSectHeading	Id of new StText to hold the section heading (optional)
 *	hvoSectContent	Id of new StText to hold the section contents (optional)
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc Import_AppendScrSection
	@hvoScrBook int,			-- Id of owning ScrBook
	@ord int,				-- position for new section
	@hvoSection int = null output,		-- Id of new ScrSection
	@hvoSectHeading int = null output,	-- Id of new StText for section heading
	@hvoSectContent int = null output	-- Id of new StText for section contents
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'AppendScrSection_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	set @clid = 3005 -- ScrSection
	set @flid = 3002001 -- ScrBook_Sections

	-- Create the new ScrSection object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoScrBook, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoSection = @@identity

	insert [ScrSection] ([Id])
	values(@hvoSection)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to ScrSection: ID=%d', 16, 1, @hvoSection) 
		goto LFail
	end

	-- Create the StTexts
	set @clid = 14 -- StText

	-- Create the new Section Heading object
	set @flid = 3005001 -- ScrSection_Heading
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoSection, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoSectHeading = @@identity

	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoSectHeading, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoSectHeading) 
		goto LFail
	end

	-- Create the new Section Content object
	set @flid = 3005002 -- ScrSection_Content
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoSection, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoSectContent = @@identity

	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoSectContent, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoSectContent) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'Import_AppendPara')
	drop proc Import_AppendPara
go
print 'creating proc Import_AppendPara'
go
/*****************************************************************************
 * Import_AppendPara
 *
 * Description: Adds a paragraph to the end of the given StText.
 *
 * Parameters:
 *	hvoText		Id of owning StText
 *	ord		position for new paragraph - must be max(OwningOrd$ + 1)
 *	stuContents	Contents of new paragraph
 *	rgbContentsFmt	Format data for Contents
 *	hvoPara		id of new object - output (optional)
 *      rgbStParaFmt	Format data (named style) for StPara (optional)
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc Import_AppendPara
	@hvoText int,
	@ord int,				-- position for new paragraph
	@stuContents ntext,		-- Contents of new paragraph
	@rgbContentsFmt image,	-- format data for Contents
	@hvoPara int = null output,		-- id of new object
	@rgbStParaFmt varbinary(8000) = null	-- format data for paragraph
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @clid = 16 -- StTxtPara
	set @flid = 14001 -- StText_Paragraphs

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'AppendPara_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Create the new object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoText, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoPara = @@identity

	-- Insert into StPara
	insert [StPara] ([Id], [StyleRules])
	values(@hvoPara, @rgbStParaFmt)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StPara: ID=%d', 16, 1, @hvoPara) 
		goto LFail
	end

	-- Insert into StTxtPara
	insert StTxtPara ([Id],[Contents],[Contents_Fmt])
	values (@hvoPara, @stuContents, @rgbContentsFmt)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StTextPara: ID=%d', 16, 1, @hvoPara) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'GetScrBookInfo')
	drop proc GetScrBookInfo
go
print 'creating proc GetScrBookInfo'
go
/*****************************************************************************
 * GetScrBookInfo
 *
 * Description: Retrieves IDs (for joining to ScrBookRef), names and
 *		abbreviations for all Scripture books; retrieves all available
 *		encodings for Name and Abbrev fields.
 *
 * Parameters:
 *	hvoScripture	Id of Scripture
 * Returns: 0
 *
 *****************************************************************************/
create proc GetScrBookInfo
	@hvoScripture	int
as
	-- REVIEW (SteveMiller): This apparently is not in use when I came through
	-- refactoring MultiTxt$ out of the system. As it stood, the query would
	-- return one row for the book name, and another for the book abbreviation.
	-- I put the name and abbrev in one row. Hope that doesn't mess someone up.
	
	SELECT
		bk.[Id],
		bk.BookId,
		sbn.Txt AS BookName,
		sbn.Txt AS BookAbbrev,
		sbn.Ws
	FROM ScrBook_ bk
	LEFT OUTER JOIN ScrBook_Name sbn ON sbn.Obj = bk.[Id]
	LEFT OUTER JOIN ScrBook_Abbrev sba ON 
		sba.Obj = sbn.Obj AND sba.Obj = bk.[Id] AND sba.WS = sbn.WS
	WHERE bk.Owner$ = @hvoScripture AND bk.OwnFlid$ = 3001001 -- Scripture_ScriptureBooks
	ORDER BY bk.OwnOrd$

go


if exists (select *
             from sysobjects
            where name = 'GetScrBookTitle')
	drop proc GetScrBookTitle
go
print 'creating proc GetScrBookTitle'
go
/*****************************************************************************
 * GetScrBookTitle
 *
 * Description: Retrieves title of a given ScrBook.
 *
 * Parameters:
 *	hvoScrBook	Id of ScrBook
 * Returns: 0
 *
 *****************************************************************************/
create proc GetScrBookTitle
	@hvoScrBook	int
as
	select	[Id] "hvoTitle",
		[Owner$] "hvoOwner"
	from	StText_
	where	[Owner$] = @hvoScrBook
		and [OwnFlid$] = 3002004 -- ScrBook_Ttitle
go


if exists (select *
             from sysobjects
            where name = 'CreateObj_WfiWordForm')
	drop proc CreateObj_WfiWordForm
go
print 'creating proc CreateObj_WfiWordForm'
go
/*****************************************************************************
 * CreateObj_WfiWordForm
 *
 * Description: Adds a WfiWordForm object, if needed. If the wordform to be
 * created already exists, then just return the HVO. Otherwise, create it and
 * set its Form property using the given writing system.
 * Parameters:
 *	hvoWfi		Id of owning Wordform Inventory
 *	stuForm		wordform
 *	ws		character offset into StTxtPara
 *	id		Id of new (or existing) wordform
 *	nSpellingStat	Spelling status
 * Returns: Error code if an error occurs
 *
 *****************************************************************************/
create proc CreateObj_WfiWordForm
	@hvoWfi		int,
	@stuForm	nvarchar(4000),
	@Ws		int,
	@id		int = null output,
	@nSpellingStat	tinyint = 0 output
as
	-- Begin by checking to see if it already exists. If so, then our
	-- job is easy.
	select	@id = f.[Obj],
		@nSpellingStat = w.[SpellingStatus]
	from	WfiWordform_Form f
	join	WfiWordform w on w.[id] = f.[Obj]
	where	CONVERT ( varbinary(8000), f.[Txt]) = CONVERT ( varbinary(8000), @stuForm)
	and	f.[Ws] = @Ws

	if @id is not null return 0

	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @clid = 5062 -- WfiWordform
	set @flid = 5063001 -- WordformInventory_Wordforms

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'WfiWordform_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Create the new object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoWfi, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @id = @@identity

	-- Insert into WfiWordform
	insert WfiWordform ([Id], [SpellingStatus])
	values (@id, @nSpellingStat)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to WfiWordform: ID=%d', 16, 1, @id) 
		goto LFail
	end

	-- Insert into WfiWordform_Form
	insert WfiWordform_Form ([Obj],[Ws],[Txt])
	values (@id, @Ws, @stuForm)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to WfiWordform_Form: ID=%d, Ws=%d, Txt=%s', 16, 1, @id, @Ws, @stuForm) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO

if exists (select *
             from sysobjects
            where name = 'GetNewFootnoteGuids')
	drop proc GetNewFootnoteGuids
go
print 'creating proc GetNewFootnoteGuids'
go
/*****************************************************************************
 * GetNewFootnoteGuids
 *
 * Description: Retrieves a result set that contains an ordered mapping
 * between the GUIDs of footnotes for a ScrBook and the GUIDs of footnotes for
 * a revision of that book.
 *
 * Parameters:
 *	bookId	Id of ScrBook
 *	revId	Id of an archived revision of the ScrBook
 * Returns: 0
 *
 *****************************************************************************/
create proc GetNewFootnoteGuids
	@bookId	int,
	@revId	int
as
	select	bookfn.Guid$ "ScrBookFootnoteGuid",
		revfn.Guid$ "RevisionFootnoteGuid",
		revfn.ownord$
	from	StFootnote_ bookfn (readuncommitted)
	join	StFootnote_ revfn (readuncommitted) on bookfn.ownord$ = revfn.ownord$
	where	bookfn.owner$ = @bookId
	and	revfn.owner$ = @revId
	order by revfn.ownord$
GO

if exists (select *
             from sysobjects
            where name = 'GetParasWithORCs')
drop proc GetParasWithORCs
go
print 'creating proc GetParasWithORCs'
go
/*****************************************************************************
 * GetParasWithORCs
 *
 * Description: Retrieves a list of HVO's of StTxtParas which contain ORC
 * characters (most of which are probably footnotes).
 *
 * Parameters:
 *	revId	Id of an archived revision of a ScrBook
 * Returns: 0
 *
 *****************************************************************************/
create proc GetParasWithORCs @revId int
as
begin
	select	p.[Id] "id", p.OwnOrd$ "pord", t.OwnFlid$ "tflid", s.OwnOrd$ "sord", 1 "t_or_s"
	from	StTxtPara_ p (readuncommitted)
	join	StText_ t (readuncommitted) on p.Owner$ = t.[Id]
	join	ScrSection_ s (readuncommitted) on t.Owner$ = s.[Id]
	join	ScrBook b (readuncommitted) on s.Owner$ = b.[Id]
	and	b.[id] = @revId
	where	p.Contents COLLATE Latin1_General_BIN like N'%' + NCHAR(0xFFFC) + '%' COLLATE Latin1_General_BIN
	union all
	select	p.[Id], p.OwnOrd$, 0, 0, 0
	from	StTxtPara_ p (readuncommitted)
	join	StText_ t (readuncommitted) on p.Owner$ = t.[Id]
	join	ScrBook b (readuncommitted) on t.Owner$ = b.[Id]
	and	t.OwnFlid$ = 3002004
	and	b.[id] = @revId
	where	p.Contents COLLATE Latin1_General_BIN like N'%' + NCHAR(0xFFFC) + '%' COLLATE Latin1_General_BIN

	order by t_or_s, sord, tflid, pord--select PATINDEX('85BD0CE977CE49629850205F8B73C741', CAST(CAST(Contents_fmt AS varbinary(8000)) AS nvarchar(4000)))
end
GO