set nocount on

/***********************************************************************************************
	Note: These declarations need to be ordered, such that if stored procedure X
	calls stored procedure Y, then X should be created first, then Y.
	Doing this avoids an error message like the following:

creating proc FindOrCreateWfiAnalysis
Cannot add rows to sysdepends for the current stored procedure because it depends on the 
missing object 'ChkDupWFAnalysis'. The stored procedure will still be created.
***********************************************************************************************/

/***********************************************************************************************
	Add extended stored procedures
***********************************************************************************************/

if object_id('master..xp_IsMatch') is not null begin
	print 'removing xp_IsMatch'
	EXEC master..sp_dropextendedproc 'xp_IsMatch'
end
go
print 'adding xp_IsMatch'
EXEC master..sp_addextendedproc 'xp_IsMatch', 'FwSqlExtend.dll'
go


/***********************************************************************************************
	Meta data tables.
***********************************************************************************************/


-- Version$ table.
if object_id('Version$') is not null begin
	print 'removing table Version$'
	drop table [Version$]
end
go
print 'creating table Version$'
create table [Version$] (
	[DbVer]		int primary key,
	[Guid$]		uniqueidentifier	not null,
	[DateStdVer]	datetime		not null,
	[DateCustomized] datetime,
	[ParDbVer]	int,
	[ParGuid]	uniqueidentifier,
	[ParDateStdVer]	datetime,
	[ParDateCustomized] datetime
)
go

-- This must match kdbAppVersion in DbVersion.h. See DbVersion.h for further information.
insert into Version$([DbVer], [Guid$], [DateStdVer], [DateCustomized], 
		[ParDbVer], [ParGuid], [ParDateStdVer], [ParDateCustomized])

	values (200132, newid(), current_timestamp, NULL, NULL, NULL, NULL, NULL);
go


-- AppCompat$ table.
if object_id('AppCompat$') is not null begin
	print 'removing proc AppCompat$'
	drop proc [AppCompat$]
end
go
print 'creating table AppCompat$'
create table [AppCompat$] (
	[AppGuid] uniqueidentifier primary key,
	[AppName] nvarchar(200),
	[EarliestCompatVer] int not null,
	[LastKnownCompatVer] int not null,
)
go

insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('39886581-4DD5-11d4-8078-0000C0FB81B5', 'FwNotebook', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('5EA62D01-7A78-11d4-8078-0000C0FB81B5', 'FwChoicesListEditor', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('A7D421E1-1DD3-11d5-B720-0010A4B54856', 'TE', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('8645FA4B-EE90-11D2-A9B8-0080C87B6086', 'FwMorphologyModelEditor', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('8645fa4d-ee90-11d2-a9b8-0080c87b6086', 'FwLexEd', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('76230C21-7084-11d5-83CD-0050BA78F57C', 'FwExplorer', 500, 500);
go


-- Module$ table.
if object_id('Module$') is not null begin
	print 'removing proc Module$'
	drop proc [Module$]
end
go
print 'creating table Module$'
create table [Module$] (
	[Id] 		int 				primary key clustered,
	[Name] 		nvarchar(kcchMaxName) not null	unique,
	[Ver] 		int 		not null,
	[VerBack] 	int 		not null,

	constraint [_CK_Module$_VerBack] check (0 < [VerBack] and [VerBack] <= [Ver])
)
go


-- Class$ table.
if object_id('Class$') is not null begin
	print 'removing proc Class$'
	drop proc [Class$]
end
go
print 'creating table Class$'
create table [Class$] (
	[Id]		int				primary key clustered,
	[Mod]		int		not null	references [Module$] ([Id]),
	[Base]		int		not null	references [Class$] ([Id]),
	[Abstract]	bit,
	[Name]		nvarchar(kcchMaxName) not null	unique
)
go

-- Field$ table.
if object_id('Field$') is not null begin
	print 'removing proc Field$'
	drop table [Field$]
end
go
print 'creating table Field$'
create table [Field$] (
	[Id]		int				primary key clustered,
	[Type]		int		not null,
	[Class]		int		not null	references [Class$] ([Id]),
	[DstCls]	int		null		references [Class$] ([Id]),
	[Name] 		nvarchar(kcchMaxName) not null,
	[Custom] 	tinyint		not null 	default 1,
	[CustomId] 	uniqueidentifier null		default newid(),
	[Min]		bigint		null		default null,
	[Max]		bigint		null		default null,
	[Big]		bit		null		default 0,
	UserLabel	NVARCHAR(kcchMaxName) NULL DEFAULT NULL,
	HelpString	NVARCHAR(kcchMaxName) NULL DEFAULT NULL,
	ListRootId	INT NULL DEFAULT NULL,
	WsSelector	INT NULL,
	XmlUI		NTEXT NULL
	constraint [_UQ_Field$_Class_Fieldname]	unique ([class], [name]),
	constraint [_CK_Field$_DstCls]
		check (([Type] < kcptMinObj and [DstCls] is null) or
			([Type] >= kcptMinObj and [DstCls] is not null)),
	constraint [_CK_Field$_Custom]
		check (([Custom] = 0 and [CustomId] is null) or
			([Custom] = 1 and [CustomId] is not null)),
	constraint [_CK_Field$_Type_Integer]
		check (([Type] <> kcptInteger and [Min] is null and [Max] is null) or
			[Type] = kcptInteger),
	constraint [_CK_Field$_Type]
		check ([Type] In (	kcptBoolean,
					kcptInteger,
					kcptNumeric,
					kcptFloat,
					kcptTime,
					kcptGuid,
					kcptImage,
					kcptGenDate,
					kcptBinary,
					kcptString,
					kcptMultiString,
					kcptUnicode,
					kcptMultiUnicode,
					kcptBigString,
					kcptMultiBigString,
					kcptBigUnicode,
					kcptMultiBigUnicode,
					kcptOwningAtom,
					kcptReferenceAtom,
					kcptOwningCollection,
					kcptReferenceCollection,
					kcptOwningSequence,
					kcptReferenceSequence)),
	constraint [_CK_Field$_MinMax] check ((Max is null and min is null) or (Type = kcptInteger and Max >= Min))
)
create nonclustered index Ind_Field$_ClassType on Field$(Class, Type)
create nonclustered index ind_Field$_DstCls on Field$(DstCls)
go


-- ClassPar$ table.
if object_id('ClassPar$') is not null begin
	print 'removing proc ClassPar$'
	drop proc [ClassPar$]
end
go
print 'creating table ClassPar$'
create table [ClassPar$] (
	[Src]		int		not null	references [Class$] ([Id]),
	[Dst]		int		not null	references [Class$] ([Id]),
	[Depth] 	int 		not null,

	constraint [_CK_ClassPar$_Depth] check (([Depth] > 0 and [Src] <> [Dst]) or ([Depth] = 0 and [Src] = [Dst])),
	constraint [_UQ_ClassPar$_Depth] unique ([Src], [Depth]),
	constraint [_PK_ClassPar$] primary key clustered ([Src], [Dst])
)
create nonclustered index Ind_ClassPar$_Dst_Src on ClassPar$([Dst], [Src])
go


-- PropInfo$ view.
if object_id('PropInfo$') is not null begin
	print 'removing proc PropInfo$'
	drop view [PropInfo$]
end
go
print 'creating view PropInfo$'
go
create view [PropInfo$] as
select convert(char(25), [Class$].[Name]) as [Class],
	convert(char(5), [Class$].[Id]) as [Clid],
	convert(char(25), [Field$].[Name]) as [Property],
	convert(char(8), [Field$].[Id]) as [Flid],
	convert(char(20), case [Field$].[Type]
		when 1 then 'Boolean'
		when 2 then 'Integer'
		when 3 then 'Numeric'
		when 4 then 'Float'
		when 5 then 'Time'
		when 6 then 'Guid'
		when 7 then 'Image'
		when 8 then 'GenDate'
		when 9 then 'Binary'
		when 13 then 'String'
		when 14 then 'MultiString'
		when 15 then 'Unicode'
		when 16 then 'MultiUnicode'
		when 17 then 'BigString'
		when 18 then 'MultiBigString'
		when 19 then 'BigUnicode'
		when 20 then 'MultiBigUnicode'
		when 23 then 'OwningAtom'
		when 24 then 'ReferenceAtom'
		when 25 then 'OwningCollection'
		when 26 then 'ReferenceCollection'
		when 27 then 'OwningSequence'
		when 28 then 'ReferenceSequence'
		else 'Unknown'
		end) as [Type],
	convert(char(3), [Field$].[Type]) as [Tid],
	convert(char(25), (select [Name] from [Class$] where [Class$].[Id] = [DstCls])) as [Signature],
	convert(char(5), case [Field$].[Custom]
		when 0 then 'false'
		when 1 then 'true'
		else 'BOGUS'
		end) as [Custom],
	convert(char(20), [Field$].[CustomId]) as [CustomId]
from [Field$] join [Class$]
	on [Field$].[Class] = [Class$].[Id]
go

--( FlidCollation$ table.
IF OBJECT_ID('FlidCollation$') IS NOT NULL BEGIN
	PRINT 'removing table FlidCollation$'
	DROP TABLE [FlidCollation$]
END
GO
PRINT 'creating table FlidCollation$'
GO
CREATE TABLE FlidCollation$ (
	[Id]			INT	PRIMARY KEY CLUSTERED IDENTITY(1,1),
	[Ws]			INT NOT NULL,
	[CollationId]	INT	NOT NULL,
	[Flid]			INT NOT NULL)

/***********************************************************************************************
	Procedures and tables used to pass in and out lists of objects
***********************************************************************************************/


-- ObjListTbl$ table.
if object_id('ObjListTbl$') is not null begin
	print 'removing table ObjListTbl$'
	drop table [ObjListTbl$]
end
go
print 'creating table ObjListTbl$'
go
create table [ObjListTbl$] (
	[uid] 	uniqueidentifier	not null,
	[ObjId] int			not null,
	[Ord] 	int			not null,
	[Class]	int			null
)
create nonclustered index IND_ObjListTbl$ on ObjListTbl$ (uid, ObjId)
go


-- ObjInfoTbl$ table.
if object_id('ObjInfoTbl$') is not null begin
	print 'removing table ObjInfoTbl$'
	drop table [ObjInfoTbl$]
end
go
print 'creating table ObjInfoTbl$'
go
create table [ObjInfoTbl$]
(
	[uid]		uniqueidentifier not null,
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
create nonclustered index Ind_ObjInfoTbl$_Id on ObjInfoTbl$(uid, ObjId)
go


/***********************************************************************************************
	Table to synchronize data updates between applications.
***********************************************************************************************/
print 'creating table Sync$'
create table [Sync$]
(
	[Id] int primary key clustered identity(1,1),
	[LpInfoId] uniqueidentifier null,
	[Msg] int null,
	[ObjId] int null,
	[ObjFlid] int null
)
go

/***********************************************************************************************
 * ClearSyncTable$
 *
 * Description: 
 *	Deletes all rows from the sync$ table.
 *
 * Paramters: 
 *	@dbName=Database name;
 *
 * Returns:
 *	Returns: 0 if successful, otherwise an error code
 *
 * Notes:
 **********************************************************************************************/
if object_id('ClearSyncTable$') is not null begin
	print 'removing proc ClearSyncTable$'
	drop proc [ClearSyncTable$]
end
go
print 'creating proc ClearSyncTable$'
go
create proc [ClearSyncTable$]
	@dbName nvarchar(4000)
as
	declare	@fIsNocountOn int

	-- check for the arbitrary case where the db name is null
	if @dbName is null return 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	if (not exists(select spid from master.dbo.sysprocesses sproc
		join master.dbo.sysdatabases sdb on sdb.dbid = sproc.dbid and name = @dbName
		where sproc.spid != @@spid))
		truncate table sync$

	select max(id) from sync$ (readuncommitted)

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return 0
go


/***********************************************************************************************
 * StoreSyncRec$
 *
 * Description: 
 *	Deletes all rows from the sync$ table.
 *
 * Paramters: 
 *	@dbName=Database name;
 *
 * Returns:
 *	Returns: 0 if successful, otherwise an error code
 *
 * Notes:
 **********************************************************************************************/
if object_id('StoreSyncRec$') is not null begin
	print 'removing proc StoreSyncRec$'
	drop proc [StoreSyncRec$]
end
go
print 'creating proc StoreSyncRec$'
go
create proc [StoreSyncRec$]
	@dbName nvarchar(4000),
	@uid uniqueidentifier,
	@msg int,
	@hvo int,
	@flid int
as
	declare	@fIsNocountOn int

	-- check for the arbitrary case where the db name is null
	if @dbName is null return 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	if (select count(distinct spid) from master.dbo.sysprocesses sproc
		join master.dbo.sysdatabases sdb on sdb.dbid = sproc.dbid and name = @dbName
		where sproc.spid != @@spid) > 0
		insert sync$ (LpInfoId, Msg, ObjId, ObjFlid)
		values (@uid, @msg, @hvo, @flid)
	
-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return 0
go


/***********************************************************************************************
 * SetObjList$
 *
 * Description: 
 *	places an array of objects into the ObjListTbl$ table
 *
 * Paramters: 
 *	@ObjList=list of objects;
 *	@uid=unique identifier associated with the list of objects;
 *	@Tbl=the table to place the objects onto (1=ObjListTbl$, otherwise ObjInfoTbl$);
 *	@fLittleEndian=a flag that determines if the varbinary contains integers stored in
 *		little or big endian (1=little endian, otherwise big endian)
 *
 * Returns:
 *	Returns: 0 if successful, otherwise an error code
 *
 * Notes:
 *	The @ObjList parameter allows for a maximum of 1975 object Id's (each one is 4 bytes)
 **********************************************************************************************/
if object_id('SetObjList$') is not null begin
	print 'removing proc SetObjList$'
	drop proc [SetObjList$]
end
go
print 'creating proc SetObjList$'
go
create proc [SetObjList$]
	@ObjList varbinary(7900),
	@uid uniqueidentifier = null output, -- if null then a guid is generated, otherwise use the supplied value
	@Tbl tinyint = 1,
	@fLittleEndian tinyint = 1
as
	declare @nNumObjs int, @iCurrObj int
	declare	@fIsNocountOn int, @iTemp int
	declare @Err int

	-- check for the arbitrary case where the array of objects is null
	if @ObjList is null return 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	if @uid is null set @uid = newid()

	-- get the number of objects in the destination object array
	set @nNumObjs = datalength(@ObjList) / 4

	set @iCurrObj = 0
	if @Tbl = 1 begin
		-- loop through the array of objects and insert each one into the ObjListTbl$ table
		if @fLittleEndian = 1 begin
			while @iCurrObj < @nNumObjs begin
				set @iTemp = @iCurrObj * 4
				insert into [ObjListTbl$] with (rowlock) ([uid], [ObjId], [Ord]) 
				values(@uid, substring(@ObjList, @iTemp + 4, 1) +
					substring(@ObjList, @iTemp + 3, 1) +
					substring(@ObjList, @iTemp + 2, 1) +
					substring(@ObjList, @iTemp + 1, 1), @iCurrObj)
				set @Err = @@error
				if @Err <> 0 goto LFail
				set @iCurrObj = @iCurrObj + 1
			end
		end
		else begin
			while @iCurrObj < @nNumObjs begin
				insert into [ObjListTbl$] with (rowlock) ([uid], [ObjId], [Ord]) 
					values(@uid, substring(@ObjList, @iCurrObj*4+1, 4), @iCurrObj)
				set @Err = @@error
				if @Err <> 0 goto LFail
				set @iCurrObj = @iCurrObj + 1
			end
		end
	end 
	else begin
		-- loop through the array of objects and insert each one into the ObjInfoTbl$ table
		if @fLittleEndian = 1 begin
			while @iCurrObj < @nNumObjs begin
				set @iTemp = @iCurrObj * 4
				insert into [ObjInfoTbl$] with (rowlock) ([uid], [ObjId], [OrdKey]) values(@uid, 
					substring(@ObjList, @iTemp + 4, 1) +
					substring(@ObjList, @iTemp + 3, 1) +
					substring(@ObjList, @iTemp + 2, 1) +
					substring(@ObjList, @iTemp + 1, 1), @iCurrObj)
				set @Err = @@error
				if @Err <> 0 goto LFail
				set @iCurrObj = @iCurrObj + 1
			end
		end
		else begin
			while @iCurrObj < @nNumObjs begin
				insert into [ObjInfoTbl$] with (rowlock) ([uid], [ObjId], [OrdKey]) 
					values(@uid, substring(@ObjList, @iCurrObj*4+1, 4), @iCurrObj)
				set @Err = @@error
				if @Err <> 0 goto LFail
				set @iCurrObj = @iCurrObj + 1
			end
		end
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return 0

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	raiserror ('SetObjList$: SQL Error %d; Unable to insert rows into the ObjListTbl$.', 16, 1, @Err)
	return @Err
go


/***********************************************************************************************
 * CleanObjListTbl$ 
 *
 * Description: 
 *	removes a results set from the ObjInfoTbl$ table
 *
 * Parameters:
 *	@uid=unique identifier associated with the list of objects that is to be removed
 *
 * Returns:
 *	0 if successful, otherwise an error code
 **********************************************************************************************/
if object_id('CleanObjListTbl$') is not null begin
	print 'removing proc CleanObjListTbl$'
	drop proc [CleanObjListTbl$]
end
go
print 'creating proc CleanObjListTbl$'
go
create proc [CleanObjListTbl$]
	@uid uniqueidentifier
as
	declare @fIsNocountOn int, @Err int, @sUid nvarchar(50)

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- remove the specified rows from the ObjListTbl$ table
	delete	[ObjListTbl$] with (rowlock)
	where	[uid] = @uid

	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('CleanObjListTbl$: SQL Error %d; Unable to remove rows from the ObjInfoTbl$ table (UID=%s).', 16, 1, @Err, @sUid)
	end

	if @fIsNocountOn = 0 set nocount off

	return @Err
go


-- ObjInfoTbl$_Owned view.
if object_id('ObjInfoTbl$_Owned') is not null begin
	print 'removing view ObjInfoTbl$_Owned'
	drop view [ObjInfoTbl$_Owned]
end
go
print 'creating view ObjInfoTbl$_Owned'
go
create view [ObjInfoTbl$_Owned]
as
	select	* 
	from	ObjInfoTbl$ (readuncommitted)
	where	[RelType] in (kcptOwningAtom, kcptOwningCollection, kcptOwningSequence)
go


-- ObjInfoTbl$_Ref view.
if object_id('ObjInfoTbl$_Ref') is not null begin
	print 'removing view ObjInfoTbl$_Ref'
	drop view [ObjInfoTbl$_Ref]
end
go
print 'creating view ObjInfoTbl$_Ref'
go
create view [ObjInfoTbl$_Ref]
as
	select	* 
	from	ObjInfoTbl$ (readuncommitted)
	where	[RelType] in (kcptReferenceAtom, kcptReferenceCollection, kcptReferenceSequence)

go


/***********************************************************************************************
 * CleanObjInfoTbl$
 *
 * Description: 
 *	removes a results set from the ObjInfoTbl$ table
 *
 * Parameters:
 *	@uid=unique Id associated with the subset of data that should be removed from the 
 *		ObjInfoTbl$ table
 *
 * Returns: 
 *	0 if successful, otherwise an error code
 **********************************************************************************************/
if object_id('CleanObjInfoTbl$') is not null begin
	print 'removing proc CleanObjInfoTbl$'
	drop proc [CleanObjInfoTbl$]
end
go
print 'creating proc CleanObjInfoTbl$'
go
create proc [CleanObjInfoTbl$]
	@uid uniqueidentifier
as
	declare @fIsNocountOn int, @Err int, @sUid nvarchar(50)

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- remove the specified rows from the ObjInfoTbl$ table
	delete	[ObjInfoTbl$] with (rowlock)
	where	[uid] = @uid

	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('CleanObjInfoTbl$: SQL Error %d; Unable to remove rows from the ObjInfoTbl$ table (UID=%s).', 16, 1, @Err, @sUid)
	end

	if @fIsNocountOn = 0 set nocount off

	return @Err
go


/***********************************************************************************************
	Meta Data table Triggers.
***********************************************************************************************/


/***********************************************************************************************
 * Trigger: TR_Class$_Ins
 *
 * Description:
 *	This trigger creates a table for each inserted row, fills in ClassPar$, and creates an
 *	update trigger on the newly created table that maintains the CmObject UpdDttm column
 *	(this effectively updates the timestamp column that is used for optimistic locking)
 *
 * Type: 	Insert
 * Table:	Class$
 *
 * Notes:
 *	The Class$ table is only modified when the model is initial built. Thus, this trigger
 *	is largely responsible for creating the initial model - as new rows are added to Class$
 *	this trigger builds the corresponding tables for each class.
 **********************************************************************************************/
if object_id('TR_Class$_Ins') is not null begin
	print 'removing trigger TR_Class$_Ins'
	drop trigger [TR_Class$_Ins]
end
go
print 'creating trigger TR_Class$_Ins'
go
create trigger [TR_Class$_Ins] on [Class$] for insert 
as
	declare @clid int, @clidBase int, @depth int, @clidT int, @clidBaseT int
	declare @sName sysname, @sBase sysname
	declare @Abstract bit
	declare @sql varchar(4000)
	declare @fIsNocountOn int
	declare @Err int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	select	top 1 	
		@clid = [Id], 
		@clidBase = [Base], 
		@sName = [Name],
		@Abstract = [Abstract]
	from	inserted 
	order by [Id]

	set @clidBaseT = @clidBase
	while @@rowcount > 0 begin
		-- Fill in ClassPar$
		insert into [ClassPar$] ([Src], [Dst], [Depth]) 
			values(@clid, @clid, 0)
		if @@error <> 0 goto LFail

		set @depth = 1
		set @clidT = @clid
		while @clidBaseT <> @clidT begin
			insert into [ClassPar$] ([Src], [Dst], [Depth])
				values(@clid, @clidBaseT, @depth)
			if @@error <> 0 goto LFail

			set @clidT = @clidBaseT
			select	@clidBaseT = [Base] 
			from	[Class$] 
			where	[Id] = @clidT
			if @@rowcount = 0 break

			set @depth = @depth + 1
		end

		-- Create Database Model from Class$ entries (CmObject table pre-created)
		If @sName <> 'CmObject' Begin

			-- Create Table
			select	@sBase = [Name] 
			from	[Class$] 
			where	[id] = @clidBase

			set @sql = 'create table [' + @sName + '] ([id] int constraint [_PK_'
					+ @sName + '] primary key clustered'

			  -- CmObject foreign keys are handled through a trigger
			if @sBase <> 'CmObject' set @sql = @sql +  ', constraint [_FK_' 
					+ @sName + '_id] foreign key ([Id]) references [' + @sBase + '] ([Id])'

			set @sql = @sql + ')'
			exec (@sql)
			if @Err <> 0 Begin
				raiserror('TR_Class$_Ins: SQL Error %d; Failed to Create Table %s', 16, 1, @Err, @sName)
				goto LFail
			end

			-- Create Trigger
			set @sql = 'create trigger [TR_' + @sName + '_TStmp] on [' + @sName + '] for update' + char(13) +
				'as' + char(13) +
				'update	CmObject' + char(13) +
				'set 	UpdDttm = getdate()' + char(13) +
				'from 	CmObject co join inserted i on co.[Id] = i.[Id]'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 Begin
				raiserror('TR_Class$_Ins: SQL Error %d; Failed to Create Trigger for %s',16,1,@Err,@sName)
				goto LFail
			end
		end

		set @clidT = @clid
		select top 1 
			@clid = [Id], 
			@clidBase = [Base], 
			@sName = [Name] 
		from	inserted 
		where	[Id] > @clidT 
		order by [Id]
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return

LFail:
	rollback tran
	raiserror('TR_Class$_Ins Failed on class %s ', 16,1, @sName)
go

/***********************************************************************************************
	CmObject table.
***********************************************************************************************/


-- CmObject table.

if object_id('CmObject') is not null begin
	print 'removing table CmObject'
	drop table [CmObject]
end
go
print 'creating table CmObject'
create table [CmObject] (
	[Id] 		int 				primary key clustered identity(1,1),
	[Guid$] 	uniqueidentifier not null 	unique default newid(),
	[Class$] 	int 		not null	references [Class$] ([Id]),
	[Owner$] 	int 		null		references [CmObject] ([Id]),
	[OwnFlid$] 	int 		null		references [Field$] ([Id]),
	[OwnOrd$] 	int 		null,
	[UpdStmp] 	timestamp,
	[UpdDttm]	smalldatetime	not null	default getdate(),

	-- an object cannot be owned by itself and if an object has an owner an owning flid
	--	must be specified
	constraint [_CK_CmObject_Owner$] check
		(([Owner$] is not null or [OwnFlid$] is null) and
			([Owner$] <> [Id]))
)

create nonclustered index Ind_CmObject_Owner$_OwnFlid$_OwnOrd$ on [CmObject] ([Owner$], [OwnFlid$], [OwnOrd$])
go

--( The following are from the index tuning wizard, on TestlangProj,
--( April 19, 2005:

CREATE INDEX Ind_CmObject_Id ON dbo.CmObject ([Id])
GO

CREATE INDEX Ind_CmObject_Guid$ ON dbo.CmObject (Guid$)
GO

-- REVIEW (SteveMiller): An index on Id, Owner, and OwnOrd$ actually causes
-- an execution plan to use the index, rather than use the clustered index
-- on ID. This, in spite of the fact that the index tuner recommended putting
-- the index on (in previous research). The nonclustered index that was here
-- was removed.

if object_id('CmObject_') is not null begin
	print 'removing view CmObject_'
	drop view [CmObject_]
end
go
print 'creating view CmObject_'
go
create view [CmObject_] 
as 
	select	[CmObject].* 
	from	[CmObject]
go


/***********************************************************************************************
	CmObject triggers.
***********************************************************************************************/


/***********************************************************************************************
 * Trigger: TR_CmObject$_RI_Del
 *
 * Description:
 *	This trigger handles the referential integrity of CmObject. Thus, it makes sure that
 *	rows are not modified or deleted that would break a foreign key type reference from
 *	another table to CmObject. In other words, it makes sure that an object's rows are not 
 *	removed from CmObject while it still exists in other class tables.
 *
 * Type: 	Update, Delete
 * Table:	CmObject
 *
 * Notes:
 *	A trigger was used instead of several foreign key relationships for performance 
 *	reasons. If foreign keys are used then whenever a row is deleted from CmObject, SQL 
 *	Server would have to check every table that references CmObject, regardless of the type
 *	of object being deleted, and regardless of the type of class (table) that references
 *	CmObject. Thus, instead, the trigger determines the type of object that is being deleted,
 *	and only checks the corresponding class.
 *
 **********************************************************************************************/
if object_id('TR_CmObject$_RI_Del') is not null begin
	print 'removing trigger TR_CmObject$_RI_Del'
	drop trigger TR_CmObject$_RI_Del
end
go
print 'creating trigger TR_CmObject$_RI_Del'
go
create trigger TR_CmObject$_RI_Del on CmObject for delete
as
	declare @sDynSql nvarchar(4000)
	declare @iCurDelClsId int
	declare @fIsNocountOn int
	declare @uid uniqueidentifier

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	--( 	The following query is against the "deleted" table. This table
	--( is poorly documented in SQL Server documentation, but as I recall, both
	--( Oracle and FoxPro have a similar concept. The rows marked as deleted are
	--( here. The query inserts them into a scratch table ObjListTbl$. This table
	--( isn't one of the temp tables, or a table variable, but a scratch table the
	--( authors set up. It's used here because dynamic SQL isn't able to see the
	--( deleted table.
	--(	    Note also the use of newid(). This generates a new, unique ID. However,
	--( it happens only once, not for the whole table. The reason for this, I think,
	--( is that another user might be using the same scratch table concurrently. The
	--( second user would have a different ID than the first user. This makes sure 
	--( each user is using their own rows in the same scratch table.
	
	-- copy the deleted rows into a the ObjListTbl table - this is necessary since the logical "deleted" 
	--	table is not in	the scope of the dynamic SQL
	set @uid = newid()	
	insert into [ObjListTbl$] ([Uid], [ObjId], [Ord], [Class])
	select	@uid, [Id], coalesce([OwnOrd$], -1), [Class$]
	from	deleted
	if @@error <> 0 begin
		raiserror('TR_CmObject$_RI_Del: Unable to copy the logical DELETED table to the ObjListTbl table', 16, 1)
		goto LFail
	end
	
	-- REVIEW (SteveMiller): With the use of IDs, the SERIALIZABLE keyword shouldn't be
	-- needed here. 
	
	-- get the first class to process
	select	@iCurDelClsId = min([Class])
	from	[ObjListTbl$] (REPEATABLEREAD)
	where	[uid] = @uid
	if @@error <> 0 begin
		raiserror('TR_CmObject$_RI_Del: Unable to get the first deleted class', 16, 1)
		goto LFail
	end

	-- loop through all of the classes in the deleted logical table
	while @iCurDelClsId is not null begin

		--(    In SQL Server, you can set a variable with a SELECT statement,
		--( as long as the query returns a single row. In this case, the code
		--( queries the Class$ table on the Class.ID, to return the name of the
		--( class.  The name of the Class is concatenated into a string.
		--(    In this system, remember: 1) Each class is mapped to a table, 
		--( whether it is an abstract or concrete class.  2) Each class is
		--( subclassed from CmObject. 3) The data in an object will therefore
		--( be persisted in more than one table: CmObject, and at least one table
		--( mapped to a subclass. This is foundational to understanding this database.
		--(    The query in the dynamic SQL joins the data in the scatch table, which
		--( came from the deleted table, which originally came from CmObject--we are
		--( in the CmObject trigger. The join is on the object ID. So this is checking
		--( to see if some of some of the object's data is still in one of the subclass
		--( tables. If so, it rolls back the transaction and raises an error. In this
		--( system, you must remove the object's persisted data in the subclass(es)
		--( before removing the persisted data in CmObject. 

		-- REVIEW (SteveMiller): Is it necessary to make sure the data in the subclass
		-- tables is removed before removing the persisted data in the CmObject table?
		-- The presence of this	check makes referential integrity very tight. However,
		-- it comes at the cost of performance. We may want to return to this if we ever
		-- need some speed in the object deletion process. If nothing else, the dynamic
		-- SQL can be converted into a EXEC sp_executesql command, which is more efficient.

		select	@sDynSql = 
			'if exists ( ' +
				'select * ' +
				'from ObjListTbl$ del (readuncommitted) join ' + [name] + ' c ' +
					'on del.[ObjId] = c.[Id] and del.[Class] = ' + convert(nvarchar(11), @iCurDelClsId) +
				'where del.[uid] = ''' + convert(varchar(255), @uid) + ''' ' +
			') begin ' +
				'raiserror(''Delete in CmObject violated referential integrity with %s'', 16, 1, ''' + [name] + ''') ' +
				'exec CleanObjListTbl$ ''' + convert(varchar(255), @uid) + ''' ' +
				'rollback tran ' +
			'end '
		from	[Class$]
		where	[Id] = @iCurDelClsId

		exec (@sDynSql)
		if @@error <> 0 begin
			raiserror('TR_CmObject$_RI_Del: Unable to execute dynamic SQL', 16, 1)
			goto LFail
		end

		-- get the next class to process
		select	@iCurDelClsId = min([Class])
		from	[ObjListTbl$] (REPEATABLEREAD)
		where	[Class] > @iCurDelClsId
			and [uid] = @uid
	end

	exec CleanObjListTbl$ @uid
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return

LFail:
	-- because the transaction is ROLLBACKed the rows in the ObjListTbl$ will be removed
	rollback tran
	return
go

/***********************************************************************************************
 * Trigger: TR_CmObject$_UpdDttm_Del
 *
 * Description:
 *	Updates the UpdDttm on owers of deleted objects.
 **********************************************************************************************/
 
if object_id('TR_CmObject$_UpdDttm_Del') is not null begin
	print 'removing trigger TR_CmObject$_UpdDttm_Del'
	drop trigger TR_CmObject$_UpdDttm_Del
end
go
print 'creating trigger TR_CmObject$_UpdDttm_Del'
go
create trigger TR_CmObject$_UpdDttm_Del on CmObject for delete
as
	declare @fIsNocountOn int
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	update CmObject set UpdDttm = getdate()
		from CmObject co JOIN deleted del on co.[id] = del.[owner$] 
		
	if @@error <> 0 begin
		raiserror('TR_CmObject$_UpdDttm_Del: Unable to update owning object', 16, 1)
		goto LFail
	end
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return
	
LFail:
	-- because the transaction is ROLLBACKed the rows in the ObjListTbl$ will be removed
	rollback tran
	return
go

/***********************************************************************************************
 * Trigger: TR_CmObject_ValidateOwner
 *
 * Description:
 *	This trigger validates an object's owner information. These validations include: make 
 *	sure the owner's class is a subclass of the class the owning field belongs to, make
 *	sure the inserted object's class is a subclass of the owning field's destination class,
 *	make sure the OwnOrd$ column contains a proper value, make sure only one object at most
 *	is owned through an atomic relationship, and make sure there are no duplicate Ord 
 *	values within the same sequence
 *.
 * Type: 	Update
 * Table:	CmObject
 *
 * Notes:
 *	Obviously since this is an update trigger these validations are not performed when an
 *	object is initially created. Instead, the CreateObject... procedures that exist for
 *	each non-abstract class contain the appropriate validations.
 *
 *	This trigger returns immediately if neither Owner$, OwnFlid$, or OwnOrd$ are modified.
 *
 **********************************************************************************************/
if object_id('TR_CmObject_ValidateOwner') is not null begin
	print 'removing trigger TR_CmObject_ValidateOwner'
	drop trigger [TR_CmObject_ValidateOwner]
end
go
print 'creating trigger TR_CmObject_ValidateOwner'
go
create trigger [TR_CmObject_ValidateOwner] on [CmObject] for update 
as
	--( We used to check to not allow an object's class to be changed,
	--( similar to the check for update([Id]) immediately below. We 
	--( have since found the need to change Lex Entries. For instance,
	--( a LexSubEntry can turn into a LexMajorEntry.

	if update([Id]) begin
		raiserror('An object''s Id cannot be changed', 16, 1)
		rollback tran
	end

	-- only perform checks if one of the following columns are updated: id, owner$, ownflid$, or 
	--	ownord$	because updates to UpdDttm or UpdStmp do not require the below validations
	if not ( update([Owner$]) or update([OwnFlid$]) or update([OwnOrd$]) )  return

	declare @idBad int, @own int, @flid int, @ord int, @cnt int
	declare @dupownId int, @dupseqId int
	declare @fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	if update([Owner$]) or update([OwnFlid$]) or update([OwnOrd$]) begin
		-- Get the owner's class and make sure it is a subclass of the field's type. Get the 
		--	inserted object's class and make sure it is a subclass of the field's dst type.
		-- 	Make sure the OwnOrd$ field is consistent with the field type (if not sequence 
		--	then it should be null). Make sure more than one object is not added as a child 
		--	of an object with an atomic owning relationship. Make sure there are no duplicate
		--	Ord values within a sequence
		select top 1
			@idBad = ins.[Id],
			@own = ins.[Owner$],
			@flid = ins.[OwnFlid$],
			@ord = ins.[OwnOrd$],
			@dupownId = dupown.[Id],
			@dupseqId = dupseq.[Id]
		from	inserted ins
			-- If there is no owner, there is nothing to check so an inner join is OK here.
			join [CmObject] own (readuncommitted) on own.[Id] = ins.[Owner$]
			-- The constraints on CmObject guarantee this join.
			join [Field$] fld on fld.[Id] = ins.[OwnFlid$]
			-- If this join has no matches the owner is of the wrong type.
			left outer join [ClassPar$] ot on ot.[Src] = own.[Class$] 
				and ot.[Dst] = fld.[Class]
			-- If this join has no matches the inserted object is of the wrong type.
			left outer join [ClassPar$] it on it.[Src] = ins.[Class$] 
				and it.[Dst] = fld.[DstCls]
			-- if this join has matches there is more than one owned object in an atomic relationship
			left outer join [CmObject] dupown (readuncommitted) on fld.[Type] = kcptOwningAtom and dupown.[Owner$] = ins.[Owner$] 
				and dupown.[OwnFlid$] = ins.[OwnFlid$] 
				and dupown.[Id] <> ins.[Id]
			-- if this join has matches there is a duplicate sequence order in a sequence relationship
			left outer join [CmObject] dupseq (readuncommitted) on fld.[Type] = kcptOwningSequence and dupseq.[Owner$] = ins.[Owner$] 
				and dupseq.[OwnFlid$] = ins.[OwnFlid$] 
				and dupseq.[OwnOrd$] = ins.[OwnOrd$] 
				and dupseq.[Id] <> ins.[Id]
		where
			ot.[Src] is null
			or it.[Src] is null
			or (fld.[Type] = kcptOwningAtom and ins.[OwnOrd$] is not null)
			or (fld.[Type] = kcptOwningCollection and ins.[OwnOrd$] is not null)
			or (fld.[Type] = kcptOwningSequence and ins.[OwnOrd$] is null)
			or dupown.[Id] is not null
			or dupseq.[Id] is not null

		if @@rowcount <> 0 begin
			if @dupownId is not null begin
				raiserror('More than one owned object in an atomic relationship: New ID=%d, Owner=%d, OwnFlid=%d, Already Owned Id=%d', 16, 1,
						@idBad, @own, @flid, @dupownId)
			end
			else if @dupseqId is not null begin
				raiserror('Duplicate OwnOrd in a sequence relationship: New ID=%d, Owner=%d, OwnFlid=%d, OwnOrd=%d, Duplicate Id=%d', 16, 1,
						@idBad, @own, @flid, @ord, @dupseqId)
			end
			else begin
				raiserror('Bad owner information ID=%d, Owner$=%d, OwnFlid$=%d, OwnOrd$=%d', 16, 1, @idBad, @own, @flid, @ord)
			end
			rollback tran
		end
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
go

/***********************************************************************************************
	String tables.
***********************************************************************************************/

--( The Txt field is collated to Latin1_General_BIN because Yi,
--( IPA, and Khmer at least are not in the Microsoft collation
--( tables currently. This makes equality tests fail. We have
--( discovered however that they equate correctly in binary
--( collations. How this effects sorting is yet to be seen, and
--( we are talking about ways to fix that.

-- MultiStr$ table.
if object_id('MultiStr$') is not null begin
	print 'removing table MultiStr$'
	drop table [MultiStr$]
end
go
print 'creating table MultiStr$'
create table [MultiStr$] (
	[Flid]		int		not null	references [Field$] ([Id]),
	[Obj] 		int		not null,
	[Ws]		int		not null,
	[Txt] 		nvarchar(kcchMaxUniVarChar) COLLATE Latin1_General_BIN not null,
	[Fmt] 		varbinary(kcbMaxVarBin)	not null,

	constraint [_PK_MultiStr$] primary key clustered ([Flid], [Obj], [Ws])
)
create nonclustered index Ind_MultiStr$ on MultiStr$(obj)
go


--( The section for creating the MultiTxt$ table used to go here.
--( It has since been moved to TR_Field$_UpdateModel_Ins

-- MultiBigStr$ table.
if object_id('MultiBigStr$') is not null begin
	print 'removing table MultiBigStr$'
	drop table [MultiBigStr$]
end
go
print 'creating table MultiBigStr$'
create table [MultiBigStr$] (
	[Flid]		int		not null	references [Field$] ([Id]),
	[Obj]		int		not null,
	[Ws]		int		not null,
	[Txt] 		ntext		COLLATE Latin1_General_BIN not null,
	[Fmt] 		image		not null,

	constraint [_PK_MultiBigStr$] primary key clustered ([Flid], [Obj], [Ws])
)
create nonclustered index Ind_MultiBigStr$ on MultiBigStr$(obj)
go

-- Set 'Text In Row' option for MultiBigStr$.
exec sp_tableoption 'MultiBigStr$', 'text in row', '4000'
go


-- MultiBigTxt$ table.
if object_id('MultiBigTxt$') is not null begin
	print 'removing table MultiBigTxt$'
	drop table [MultiBigTxt$]
end
go
print 'creating table MultiBigTxt$'
create table [MultiBigTxt$] (
	[Flid]		int		not null	references [Field$] ([Id]),
	[Obj]		int		not null,
	[Ws]		int		not null,
	[Txt]		ntext		COLLATE Latin1_General_BIN not null,

	constraint [_PK_MultiBigTxt$] primary key clustered ([Flid], [Obj], [Ws])
)
create nonclustered index Ind_MultiBigTxt$ on MultiBigTxt$(obj)
go

-- Set 'Text In Row' option for MultiBigTxt$.
exec sp_tableoption 'MultiBigTxt$', 'text in row', '4000'
go


/***********************************************************************************************
	String table stored procedures.
***********************************************************************************************/


/***********************************************************************************************
 * SetMultiStr$
 *
 * Description:
 *	Inserts, updates, or deletes a multi-string in the MultiStr$ string table
 *
 * Parameters:
 *	@flid=field id of the string
 *	@obj=the object that owns the string
 *	@ws=the string's language writing system
 *	@txt=the text contents of the string, if null then the multi-string will be deleted
 *	@fmt=the string's formating
 *
 * Returns:
 *	0 if successful, otherwise an error code
 **********************************************************************************************/
if object_id('SetMultiStr$') is not null begin
	print 'removing proc SetMultiStr$'
	drop proc [SetMultiStr$]
end
go
print 'creating proc SetMultiStr$'
go
create proc [SetMultiStr$]
	@flid int,
	@obj int,
	@ws int,
	@txt nvarchar(4000) = null,
	@fmt varbinary(8000) = null
as
	declare @sTranName varchar(50), @nTrnCnt int
	declare	@fIsNocountOn int, @Err int
	declare @nRowCnt int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction already exists; if one does then create a savepoint, 
	--	otherwise create a transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'SetMultiStr$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- determine if the string should be removed
	if @txt is null or len(@txt) = 0 begin
		delete from MultiStr$ 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
	else begin
		-- attempt to update the string, if no rows are updated then insert the string
		update	MultiStr$ 
		set	[Txt] = @txt, [Fmt] = @fmt 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		select @Err = @@error, @nRowCnt = @@rowcount
		if @Err <> 0 goto LCleanUp
		if @nRowCnt = 0  begin
			insert into [MultiStr$] ([Flid], [Obj], [Ws], [Txt], [Fmt]) 
				values(@flid, @obj, @ws, @txt, @fmt)
			set @Err = @@error
			if @Err <> 0 goto LCleanUp
		end
	end

	-- update the timestamp column in CmObject by updating the update date and time
	update	[CmObject]
	set	[UpdDttm] = getdate()
	where	[Id] = @obj
	set @Err = @@error
	if @Err <> 0 goto LCleanUp

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	if @Err = 0 begin
		-- if a transaction was created within this procedure commit it
		if @nTrnCnt = 0 commit tran @sTranName 
	end
	else begin
		rollback tran @sTranName 
	end

	return @err
go


/***********************************************************************************************
 * SetMultiTxt$
 *
 * Description:
 *	Inserts, updates, or deletes a multi-string in the SetMultiTxt$ string table
 *
 * Parameters:
 *	@flid=field id of the string
 *	@obj=the object that owns the string
 *	@ws=the string's language writing system
 *	@txt=the text contents of the string, if null then the multi-string will be deleted
 *
 * Returns:
 *	0 if successful, otherwise an error code
 **********************************************************************************************/
if object_id('SetMultiTxt$') is not null begin
	print 'removing procedure SetMultiTxt$'
	drop proc [SetMultiTxt$]
end
go
print 'creating proc SetMultiTxt$'
go
create proc [SetMultiTxt$]
	@flid int,
	@obj int,
	@ws int,
	@txt nvarchar(4000)
as
	declare @sTranName varchar(50), @nTrnCnt int
	declare	@fIsNocountOn int, @Err int
	declare @nRowCnt int
	DECLARE
		@nvcTable NVARCHAR(60),
		@nvcSql NVARCHAR(4000)

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction already exists; if one does then create a savepoint, 
	--	otherwise create a transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'SetMultiTxt$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName
	
	EXEC GetMultiTableName @flid, @nvcTable OUTPUT
	
	-- determine if the string should be removed
	if @txt is null or len(@txt) = 0 begin
		SET @nvcSql = N'DELETE FROM ' + @nvcTable + CHAR(13) +
			N'WHERE Obj = @nObj AND Ws = @nWs'
		
		EXECUTE sp_executesql @nvcSql, N'@nObj INT, @nWs INT', @obj, @ws
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
	else begin
		-- attempt to update the string, if no rows are updated then insert the string
		SET @nvcSql = 
			N'UPDATE ' + @nvcTable + CHAR(13) +
			N'SET Txt = @nvcTxt ' + CHAR(13) +
			N'WHERE Obj = @nObj AND Ws = @nWs'
		EXECUTE sp_executesql @nvcSql,
			N'@nvcTxt NVARCHAR(4000), @nObj INT, @nWs INT',
			@txt, @obj, @ws
		
		select @Err = @@error, @nRowCnt = @@rowcount
		if @Err <> 0
			goto LCleanUp
		
		if @nRowCnt = 0 begin
			SET @nvcSql = 
				N'INSERT INTO ' + @nvcTable + 
				N' (Obj, Ws, Txt)' + CHAR(13) +
				CHAR(9) + N'VALUES (@nObj, @nWs, @nvcTxt)'
			EXECUTE sp_executesql @nvcSQL,
				N'@nvcTxt NVARCHAR(4000), @nObj INT, @nWs INT',
				@txt, @obj, @ws
			set @Err = @@error
			if @Err <> 0 goto LCleanUp
		end
	end
	
	-- update the timestamp column in CmObject by updating the update date and time
	update	[CmObject]
	set	[UpdDttm] = getdate()
	where	[Id] = @obj
	set @Err = @@error
	if @Err <> 0 goto LCleanUp

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	if @Err = 0 begin
		-- if a transaction was created within this procedure commit it
		if @nTrnCnt = 0 commit tran @sTranName 
	end
	else begin
		rollback tran @sTranName 
	end

	return @err
go


/***********************************************************************************************
 * SetMultiBigStr$
 *
 * Description:
 *	Inserts, updates, or deletes a multi-string in the MultiBigStr$ string table
 *
 * Parameters:
 *	@flid=field id of the string
 *	@obj=the object that owns the string
 *	@ws=the string's language writing system
 *	@txt=the text contents of the string, if null then the multi-string will be deleted
 *	@fmt=the string's formating
 *
 * Returns:
 *	0 if successful, otherwise an error code
 **********************************************************************************************/
if object_id('SetMultiBigStr$') is not null begin
	print 'removing proc SetMultiBigStr$'
	drop proc [SetMultiBigStr$]
end
go
print 'creating proc SetMultiBigStr$'
go
create proc [SetMultiBigStr$]
	@flid int,
	@obj int,
	@ws int,
	@txt ntext,
	@fmt image
as
	declare @sTranName varchar(50), @nTrnCnt int
	declare	@fIsNocountOn int, @Err int
	declare @nRowCnt int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction already exists; if one does then create a savepoint, 
	--	otherwise create a transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'SetMultiBigStr$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- determine if the string should be removed
	if @txt is null or @txt like '' begin
		delete from MultiBigStr$ 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
	else begin
		-- attempt to update the string, if no rows are updated then insert the string
		update	MultiBigStr$
		set	[Txt] = @txt, [Fmt] = @fmt 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		select @Err = @@error, @nRowCnt = @@rowcount
		if @Err <> 0 goto LCleanUp
		if @nRowCnt = 0 begin
			insert into [MultiBigStr$] ([Flid], [Obj], [Ws], [Txt], [Fmt]) 
				values(@flid, @obj, @ws, @txt, @fmt)
			set @Err = @@error
			if @Err <> 0 goto LCleanUp
		end
	end

	-- update the timestamp column in CmObject by updating the update date and time
	update	[CmObject]
	set	[UpdDttm] = getdate()
	where	[Id] = @obj
	set @Err = @@error
	if @Err <> 0 goto LCleanUp

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	if @Err = 0 begin
		-- if a transaction was created within this procedure commit it
		if @nTrnCnt = 0 commit tran @sTranName 
	end
	else begin
		rollback tran @sTranName 
	end

	return @err
go


/***********************************************************************************************
 * SetMultiBigTxt$
 *
 * Description:
 *	Inserts, updates, or deletes a multi-string in the SetMultiBigTxt$ string table
 *
 * Parameters:
 *	@flid=field id of the string
 *	@obj=the object that owns the string
 *	@ws=the string's language writing system
 *	@txt=the text contents of the string, if null then the multi-string will be deleted
 *
 * Returns:
 *	0 if successful, otherwise an error code
 **********************************************************************************************/
if object_id('SetMultiBigTxt$') is not null begin
	print 'removing proc SetMultiBigTxt$'
	drop proc [SetMultiBigTxt$]
end
go
print 'creating proc SetMultiBigTxt$'
go
create proc [SetMultiBigTxt$]
	@flid int,
	@obj int,
	@ws int,
	@txt ntext
as
	declare @sTranName varchar(50), @nTrnCnt int
	declare	@fIsNocountOn int, @Err int
	declare @nRowCnt int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction already exists; if one does then create a savepoint, 
	--	otherwise create a transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'SetMultiBigStr$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- determine if the string should be removed
	if @txt is null or @txt like '' begin
		delete from MultiBigTxt$ 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
	else begin
		-- attempt to update the string, if no rows are updated then insert the string
		update	MultiBigTxt$ 
		set	[Txt] = @txt 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		select @Err = @@error, @nRowCnt = @@rowcount
		if @Err <> 0 goto LCleanUp
		if @nRowCnt = 0 begin
			insert into [MultiBigTxt$] ([Flid], [Obj], [Ws], [Txt]) 
				values(@flid, @obj, @ws, @txt)
			set @Err = @@error
			if @Err <> 0 goto LCleanUp
		end
	end

	-- update the timestamp column in CmObject by updating the update date and time
	update	[CmObject]
	set	[UpdDttm] = getdate()
	where	[Id] = @obj
	set @Err = @@error
	if @Err <> 0 goto LCleanUp

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	if @Err = 0 begin
		-- if a transaction was created within this procedure commit it
		if @nTrnCnt = 0 commit tran @sTranName 
	end
	else begin
		rollback tran @sTranName 
	end

	return @err
go

/***********************************************************************************************
 * GetMultiTableName
 *
 * Description:
 *	Given a field ID (flid), which is stored in Field$.ID, returns the name of a multi
 *	table. For instance, flid 5062001 is for WfiWordform_Form.Form, and the the multilanguage
 *	data is stored in table WfiWordform_Form.
 *
 * Parameters:
 *	@nFlid = Field ID
 *	@nvcTableName = the name of the table returned.
 *
 * Returns:
 *	name of the table returned in parameter @nvcTableName
 **********************************************************************************************/

if object_id('GetMultiTableName') is not null begin
	print 'removing proc GetMultiTableName'
	drop proc [GetMultiTableName]
end
go
print 'creating proc GetMultiTableName'
go

CREATE PROCEDURE GetMultiTableName
 	@nFlid INT = NULL, 
	@nvcTableName NVARCHAR(60) OUTPUT
AS
 	SELECT @nvcTableName = c.[Name] + '_' + f.[Name]
 	FROM Class$ c
 	JOIN Field$ f ON f.Class = c.[Id] AND f.[Id] = @nFlid
GO

/***********************************************************************************************
 * MergeWritingSystem
 *
 * Description:
 *	Updates an old Writings System (ws) value with a new ws value.
 *
 * Parameters:
 *	@nOldWs = ID of the old writing system (ws)
 *	@nNewWs = ID of the new ws
 *
 * Returns:
 *	none
 **********************************************************************************************/

if object_id('MergeWritingSystem') is not null begin
	print 'removing proc MergeWritingSystem'
	drop proc [MergeWritingSystem]
end
go
print 'creating proc MergeWritingSystem'
go

CREATE PROCEDURE MergeWritingSystem
	@nOldWs INT,
	@nNewWs INT
AS
	DECLARE
		@nRowCount INT,
		@nFlid INT,
		@nvcTableName NVARCHAR(60),
		@nvcSql NVARCHAR(200)
	
	SET @nRowCount = 1
	SELECT TOP 1 @nFlid = [Id] FROM Field$ WHERE Type = 16 ORDER BY [Id]
	WHILE @nRowCount > 0 BEGIN
		EXEC GetMultiTableName @nFlid, @nvcTableName OUTPUT
		
		SET @nvcSql = N'UPDATE ' + @nvcTableName + CHAR(13) +
			N'SET Ws = @nNewWs WHERE Ws = @nOldWs'
		EXECUTE sp_executesql @nvcSql,
			N'@nNewWs INT, @nOldWs INT', @nNewWs, @nOldWs
	
		SELECT TOP 1 @nFlid = [Id]
		FROM Field$
		WHERE Type = 16 AND [Id] > @nFlid
		ORDER BY [Id]
		
		SET @nRowCount = @@ROWCOUNT
	END

	UPDATE MultiBigTxt$ SET Ws = @nNewWs WHERE Ws = @nOldWs
	UPDATE MultiStr$ SET Ws = @nNewWs WHERE Ws = @nOldWs
	UPDATE MultiBigStr$ SET Ws = @nNewWs WHERE Ws = @nOldWs
GO

/***********************************************************************************************
 * xp_GetSortKey
 *
 * Description:
 *	This is a temporary dummy until the extended stored procedure by the same name gets built.
 *	It is built for the purpose of building and testing other units. When completed, the
 *	extended stored procedure will generate a sort key using ICU.
 *
 * Parameters:
 *	@nvcText = text upon which the sort key is generated
 *	@nvcLocale = the locale for which the sort key is generated
 *	@nKey = the sort key produced
 *
 * Returns:
 *	output parameters, no return value
 **********************************************************************************************/

if object_id('xp_GetSortKey') is not null begin
	print 'removing proc xp_GetSortKey'
	drop proc [xp_GetSortKey]
end
go
print 'creating proc xp_GetSortKey'
go
CREATE PROCEDURE [xp_GetSortKey]
	@nvcText NVARCHAR(4000) OUTPUT,
	@nvcLocale NVARCHAR(100) OUTPUT,
	@nKey VARBINARY(900) OUTPUT
AS
	SET @nKey = ASCII(@nvcText) -- will take first character of @nvcText
GO


/***********************************************************************************************
	Object query stored procedures.
***********************************************************************************************/

/***********************************************************************************************
 * Function: fnGetOwnedObjects$
 *
 * Description: 
 *	returns objects that are owned by the specified object(s) (directly and, if fRecurse is
 *  true, also indirectly).
 *
 * Parameters: 
 *	@ObjId=Id of the object;
 * 	@hXMLDocObjList=handle to a parsed XML document that contains multiple object Ids - the
 *		ownership chain will be produced for each of these objectIds;
 *	@grfcpt=mask that indicates what types of owning properties included to find owned objects;
 *		a combination of 8388608 = 2^23 for owning atomic,
 *		33554432 = 2^25 for owning collection, and
 *		134217728 = 2^27 for owing sequence
 *		null to get all owned objects; 
 *	@fBaseClasses=a flag that determines if the base classes of owned objects are included 
 *		in the object list (e.g., rows for each object + all superclasses including CmObject.
 *		So if a CmPerson is included, it will also have a row for CmPossibility and CmObject);
 *	@fSubClasses=flag that determines if the sub classes of owned objects are included in 
 *		the object list (note that invalid subclasses may be returned -- all subclasses of
 *		the basic target class from Field$ are returned);
 *	@fRecurse=determinse if the owning tree should be tranversed (0=do not recurse the 
 *		owning tree, 1=recurse the owning tree);
 *	@riid = return only rows where the class = @riid, or the class is a subclass of @riid
 *		(this is most useful if @fSubClasses is nonzero since otherwise the returned result
 *		table is likely to be empty). Original note from author: "if a class was specified
 *		remove the owned objects that are not of that type of class; these objects were
 *		necessary in order to get a list of all of the referenced and referencing objects
 *		that were potentially the type of specified class"
 *	@fCaclOrdKey=determines if the order key is calculated (0=do not caclulate the order 
 *		key, 1=calculate the order key)
 *
 *	If fBaseClasses and fSubclasses are both false, the result has one row for each
 *		owned object, with inheritdepth 0.
 *	If fBaseClasses is true, there are additional rows (for each object) for each of its
 *		base classes (including CmObject), with inheritdepth indicating how many classes
 *		are in the inheritance chain between the actual class of the object and the
 *		class indicated in ObjClass. (Note that only in the row where inheritdepth is 0
 *		is ObjClass the actual class of the object indicted by objid.)
 *	If fSubclasses is true, there are additional rows (for each object) for each of
 *		the subclasses of its actual class, with (-InheritDepth) indicating how many
 *		classes intervene between ObjClass and the actual class of ObjId.
 *
 * Returns: 
 *	Table containing the object information in the format:
 *		[ObjId]		int,
 *		[ObjClass]	int,
 *		[InheritDepth]	int,
 *		[OwnerDepth]	int,
 *		[RelObjId]	int,  -- (misnamed!) owner of ObjId
 *		[RelObjClass]	int, -- class of RelObjId
 *		[RelObjField]	int, -- Field$ id of field in which RelObjId owns ObjId
 *		[RelOrder]	int, -- ord of ObjId in field RelObjId of owner RelObjId
 *		[RelType]	int, -- value from CmTypes.h indicating type of RelObjField (owning atomic, collection, seq).
 *		[OrdKey]	varbinary(250) -- ordering key which groups rows for same object, then flid, then ord.
 *
 * Notes: 
 *	If @ObjId is not specified this procedure works on all of the rows in the ObjInfTbl$ 
 *	where uid=@uid
 **********************************************************************************************/
if object_id('fnGetOwnedObjects$') is not null begin
	print 'removing function fnGetOwnedObjects$'
	drop function [fnGetOwnedObjects$]
end
go
print 'creating function fnGetOwnedObjects$'
go
create function [fnGetOwnedObjects$] (
	@ObjId int=null,
	@hXMLDocObjList int=null,
	@grfcpt int=kgrfcptAll,
	@fBaseClasses tinyint=0,
	@fSubClasses tinyint=0,
	@fRecurse tinyint=1,
	@riid int=NULL,
	@fCalcOrdKey tinyint=1 )
returns @ObjInfo table (
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
as
begin
	declare @nRowCnt int
	declare	@nObjId int, @nInheritDepth int, @nOwnerDepth int, @sOrdKey varchar(250)

	-- if NULL was specified as the mask assume that all objects are desired
	if @grfcpt is null set @grfcpt = kgrfcptAll

	-- at least one and only one object must be specified somewhere - objId paramater or XML
	if @objId is null and @hXMLDocObjList is null goto LFail
	if @objId is not null and @hXMLDocObjList is not null goto LFail

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 

		-- get the class of the specified object
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	@objId, co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[CmObject] co (readuncommitted)
		where	co.[Id] = @objId
		if @@error <> 0 goto LFail
	end
	else begin

		-- parse the XML list of Object IDs and insert them into the table variable
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	i.[Id], co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	openxml (@hXMLDocObjList, '/root/Obj') with ([Id] int) i
			join [CmObject] co (readuncommitted) on co.[Id] = i.[Id]
		if @@error <> 0 goto LFail
	end

	set @nOwnerDepth = 1
	set @nRowCnt = 1
	while @nRowCnt > 0 begin	
		-- determine if the order key should be calculated - if the order key is not needed a more 
		--    effecient query can be used to generate the ownership tree
		if @fCalcOrdKey = 1 begin
			-- get the objects owned at the next depth and calculate the order key
			insert	into @ObjInfo
				(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
			select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 
				oi.OrdKey+convert(varbinary, co.[Owner$]) + convert(varbinary, co.[OwnFlid$]) + convert(varbinary, coalesce(co.[OwnOrd$], 0))
			from 	[CmObject] co (readuncommitted)
					join @ObjInfo oi on co.[Owner$] = oi.[ObjId]
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	oi.[OwnerDepth] = @nOwnerDepth - 1
				and ( 	( @grfcpt & 8388608 = 8388608 and f.[Type] = 23 )
					or ( @grfcpt & 33554432 = 33554432 and f.[Type] = 25 )
					or ( @grfcpt & 134217728 = 134217728 and f.[Type] = 27 )
				)
		end
		else begin
			-- get the objects owned at the next depth and do not calculate the order key
			insert	into @ObjInfo
				(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
			select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type]
			from 	[CmObject] co (readuncommitted)
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	exists (select 	*
					from 	@ObjInfo oi
					where 	oi.[ObjId] = co.[Owner$]
						and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
				and ( 	( @grfcpt & 8388608 = 8388608 and f.[Type] = 23 )
					or ( @grfcpt & 33554432 = 33554432 and f.[Type] = 25 )
					or ( @grfcpt & 134217728 = 134217728 and f.[Type] = 27 )
				)
		end
 		set @nRowCnt=@@rowcount
 
 		-- determine if the whole owning tree should be included in the results
  		if @fRecurse = 0 break

 		set @nOwnerDepth = @nOwnerDepth + 1
 	end

	--
	-- get all of the base classes of the object(s), including CmObject.
	--
	if @fBaseClasses = 1 begin
		insert	into @ObjInfo
			(ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	oi.[ObjId], p.[Dst], p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType], oi.[OrdKey]
		from	@ObjInfo oi
				join [ClassPar$] p on oi.[ObjClass] = p.[Src]
				join [Class$] c on c.[id] = p.[Dst]
		where	p.[Depth] > 0 
		if @@error <> 0 goto LFail
	end
	--
	-- get all of the sub classes of the object(s)
	--
	if @fSubClasses = 1 begin
		insert	into @ObjInfo
			(ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	oi.[ObjId], p.[Src], -p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType], oi.[OrdKey]
		from	@ObjInfo oi
				join [ClassPar$] p on oi.[ObjClass] = p.[Dst] and InheritDepth = 0
				join [Class$] c on c.[id] = p.[Dst]
		where	p.[Depth] > 0 
			and p.[Dst] <> 0
		if @@error <> 0 goto LFail
	end

	-- if a class was specified remove the owned objects that are not of that type of class; these objects were
	--    necessary in order to get a list of all of the referenced and referencing objects that were potentially 
	--    the type of specified class
	if @riid is not null begin
		delete	@ObjInfo
		where 	not exists (
				select	*
				from	[ClassPar$] cp
				where	cp.[Dst] = @riid
					and cp.[Src] = [ObjClass]
			)
		if @@error <> 0 goto LFail
	end

	return
LFail:
	
	delete from @ObjInfo
	return
end
go

/*************************************************************************
 * Function: fnGetOwnedIds
 *
 * Description: 
 *	Returns the IDs of a list, not caring about hierarchy or order. This 
 *	allows us to optimize performance.
 *
 * Parameters: 
 *	@nOwner = The owinging ID, such as a Possibility List
 * 	@nTopFlid = The owning flid (field ID) of the first level of owned 
 *				objects, such as 8008 (Possibility). If null, 8008 is
 *				used.
 *	@nSubFlid = The flid of secondary flid (field ID) of subsequent
 *				levels, such as 7004 (Subpossibility). If null, 7004
 *				is used.
 *
 * Returns: 
 *	Table containing the Ids:
 *		[Id]		INT,
 *		[Level]		INT
 *	Level is a utility field for the function, and not necessary to the
 *	results of the function. It can be dropped in a calling query.
 *	
 * Example: 
 *	SELECT [Id] FROM dbo.fnGetOwnedIds (2, 8008, 7004)
 ************************************************************************/

IF OBJECT_ID('fnGetOwnedIds') IS NOT NULL BEGIN
	PRINT 'removing function fnGetOwnedIds'
	DROP FUNCTION fnGetOwnedIds 
END
GO
PRINT 'creating function fnGetOwnedIds'
GO

CREATE FUNCTION fnGetOwnedIds (
	@nOwner INT,
	@nTopFlid INT,
	@nSubFlid INT)
RETURNS @tblObjects TABLE (
	[Id] INT,
	Guid$ UNIQUEIDENTIFIER,
	Class$ INT ,
	Owner$ INT,
	OwnFlid$ INT,
	OwnOrd$ INT,
	UpdStmp BINARY(8),
	UpdDttm SMALLDATETIME,
	[Level] INT)
AS
BEGIN
	DECLARE
		@nLevel INT,
		@nRowCount INT
	
	IF @nTopFlid IS NULL
		SET @nTopFlid = 8008 --( Possibility
	IF @nSubFlid IS NULL
		SET @nSubFlid = 7004 --( Subpossibility
	
	--( Get the first level of owned objects
	SET @nLevel = 1
	
	INSERT INTO @tblObjects
	SELECT
		[Id],
		Guid$,
		Class$,
		Owner$,
		OwnFlid$,
		OwnOrd$,
		UpdStmp,
		UpdDttm,
		@nLevel
	FROM CmObject (READUNCOMMITTED)
	WHERE Owner$ = @nOwner AND OwnFlid$ = @nTopFlid --( e.g. possibility, 8008
	
	SET @nRowCount = @@ROWCOUNT --( Using @@ROWCOUNT alone was flakey in the loop.
	
	--( Get the sublevels of owned objects
	WHILE @nRowCount != 0 BEGIN
		
		INSERT INTO @tblObjects
		SELECT
			o.[Id],
			o.Guid$,
			o.Class$,
			o.Owner$,
			o.OwnFlid$,
			o.OwnOrd$,
			o.UpdStmp,
			o.UpdDttm,
			(@nLevel + 1)
		FROM @tblObjects obj
		JOIN CmObject o (READUNCOMMITTED) ON o.Owner$ = obj.[Id] 
			AND  o.OwnFlid$ = @nSubFlid --( e.g. subpossibility, 7004
		WHERE obj.[Level] = @nLevel	
		
		SET @nRowCount = @@ROWCOUNT
		SET @nLevel = @nLevel + 1
	END
	
	RETURN
END
GO

/***********************************************************************************************
 * Procedure: GetLinkedObjs$
 *
 * Description: 
 *	retrieves objects owned or referenced by the specifed object(s)
 *
 * Parameters: 
 *	@ObjId=the object for which all linked objects will be gathered;
 * 	@hXMLDocObjList=handle to a parsed XML document that contains multiple object Ids - the
 *		ownership chain will be produced for each of these objectIds;
 *	@grfcpt=mask that indicates what types of related objects should be retrieved; 
 *	@fBaseClasses=a flag that determines if the base classes of owned objects are included 
 *		in the object list (e.g., rows for each object + all superclasses except CmObject.
 *		So if a CmPerson is included, it will also have a row for CmPossibility)
 *	@fSubClasses=flag that determines if the sub classes of owned objects are included in 
 *		the object list;
 *	@fRecurse=a flag that determines if the owning tree is traversed; 
 *	@nRefDirection=determines which reference directions will be included in the results
 *		(0=both, 1=referenced by this/these object(s), -1 reference this/these objects)
 *	@riid=only return objects of this class (including subclasses of this class). NULL
 *		returns all classes;
 *	@fCalcOrdKey=flag that determines if the order key is calculated; 
 *
 * Returns: 
 *	0 if successful, otherwise an error code
 *
 * Notes: 
 *	This version of GetLinkedObjects$ is much more blocking and deadlock safe because it does 
 *	not use the ObjInfoTbl$ table. Instead, this procedure expects the calling application or
 *	procedure to create a temporary table named #ObjInfoTbl$. See the below assumptions 
 *	section for the structure of this table.
 *
 * 	Objects should be specified using either the @ObjId parameter or through an XML 
 *	document (the @hXMLDocObjList parameter is a handle to a parsed XML document) but not
 *	both. The XML document should be in the format:
 *		<root>
 *			<ObjId="1"/>
 *			<ObjId="2"/>
 *		</root>
 *
 * Assumptions:
 *	This procedure assumes that the calling application/procedure has created the 
 *	temporary table #ObjInfoTbl$ with the following structure:
 *
 *	create table [#ObjInfoTbl$]
 *	(
 *		[ObjId]		int		not null,
 *		[ObjClass]	int		null,
 *		[InheritDepth]	int		null		default(0),
 *		[OwnerDepth]	int		null		default(0),
 *		[RelObjId]	int		null,
 *		[RelObjClass]	int		null,
 *		[RelObjField]	int		null,
 *		[RelOrder]	int		null,
 *		[RelType]	int		null,
 *		[OrdKey]	varbinary(250)	null		default(0)
 *	)
 *
 *	It is recommended that in most cases the calling application/procedure also create a 
 *	nonclustered index on at least the ObjId.
 *
 * Example:
 *	-- this is an example of how to get linked objects for multiple objects within one
 *	--	call to GetLinkedObjects$
 *	declare @hXMLDoc int
 *	exec sp_xml_preparedocument @hXMLDoc output, 
 *		'<root><Obj Id="10"/><Obj Id="200"/></root>'
 *
 *	create table [#ObjInfoTbl$]
 *	(
 *		[ObjId]		int		not null,
 *		[ObjClass]	int		null,
 *		[InheritDepth]	int		null		default(0),
 *		[OwnerDepth]	int		null		default(0),
 *		[RelObjId]	int		null,
 *		[RelObjClass]	int		null,
 *		[RelObjField]	int		null,
 *		[RelOrder]	int		null,
 *		[RelType]	int		null,
 *		[OrdKey]	varbinary(250)	null		default(0)
 *	)
 *
 *	create nonclustered index #ObjInfoTblObjId on #ObjInfoTbl$ ([ObjId])
 *
 *	exec GetLinkedObjs$ null, @hXMLDoc
 *
 *	select * from [#ObjInfoTbl$]
 *
 *	drop table [#ObjInfoTbl$]
 *	exec sp_xml_removedocument @hXMLDoc
 *
 * Notes:
 *	This procedure apparently started out life as GetLinkedObjects2$, an "experimental
 *  work in progress" of Jonathan Richards'. Since the two procedures were identical,
 *  GetLinkedObjects2$ was eliminated. Jonathan named this GetLinkedObjects$, but the
 *  older version is firmly entrenched into some code at this time, so I (Steve Miller) 
 *  renamed it to its current name.
 **********************************************************************************************/
if object_id('GetLinkedObjs$') is not null begin
	print 'removing proc GetLinkedObjs$'
	drop proc [GetLinkedObjs$]
end
go
print 'creating proc GetLinkedObjs$'
go

create proc [GetLinkedObjs$]
	@ObjId int=null,
	@hXMLDocObjList int=null,
	@grfcpt int=kgrfcptAll,
	@fBaseClasses bit=0,
	@fSubClasses bit=0,
	@fRecurse bit=1,
	@nRefDirection smallint=0,
	@riid int=null,
	@fCalcOrdKey bit=1
as
	declare @Err int, @nRowCnt int
	declare	@sQry nvarchar(1000), @sUid nvarchar(50)
	declare	@nObjId int, @nObjClass int, @nInheritDepth int, @nOwnerDepth int, @nClass int, @nField int, 
		@nRelOrder int, @nType int, @nDirection int, @sClass sysname, @sField sysname, 
		@sOrderField sysname, @sOrdKey varchar(502)
	declare	@fIsNocountOn int

	set @Err = 0

	CREATE TABLE [#OwnedObjsInfo$](
		[ObjId]		INT NOT NULL,
		[ObjClass]	INT NULL,
		[InheritDepth]	INT NULL DEFAULT(0),
		[OwnerDepth]	INT NULL DEFAULT(0),
		[RelObjId]	INT NULL,
		[RelObjClass]	INT NULL,
		[RelObjField]	INT NULL,
		[RelOrder]	INT NULL,
		[RelType]	INT NULL,
		[OrdKey]	VARBINARY(250) NULL DEFAULT(0))
	
	CREATE NONCLUSTERED INDEX #OwnedObjsInfoObjId ON #OwnedObjsInfo$ ([ObjId])
	
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- if null was specified as the mask assume that all objects are desired
	if @grfcpt is null set @grfcpt = kgrfcptAll
	
	-- make sure objects were specified either in the XML or through the @ObjId parameter
	if ( @ObjId is null and @hXMLDocObjList is null ) or ( @ObjId is not null and @hXMLDocObjList is not null )
		goto LFail

	-- get the owned objects
	IF (kgrfcptOwning) & @grfcpt > 0 --( mask = owned obects
		INSERT INTO [#OwnedObjsInfo$]
			SELECT * FROM dbo.fnGetOwnedObjects$(
				@ObjId,
				@hXMLDocObjList,
				@grfcpt,
				@fBaseClasses,
				@fSubClasses,
				@fRecurse,
				@riid,
				@fCalcOrdKey)
	ELSE --( mask = referenced items or all: get all owned objects
		INSERT INTO [#OwnedObjsInfo$]
			SELECT * FROM dbo.fnGetOwnedObjects$(
				@ObjId,
				@hXMLDocObjList,
				kgrfcptAll,
				@fBaseClasses,
				@fSubClasses,
				@fRecurse,
				@riid,
				@fCalcOrdKey)
	
	IF NOT (kgrfcptReference) & @grfcpt > 0 --( mask = not referenced. In other words, mask is owned or all
		INSERT INTO [#ObjInfoTbl$]
			SELECT * FROM [#OwnedObjsInfo$]
	
	-- determine if any references should be included in the results
	if (kgrfcptReference) & @grfcpt > 0 begin
	
		--
		-- get a list of all of the classes that reference each class associated with the specified object 
		--	and a list of the classes that each associated class reference, then loop through them to 
		--	get all of the objects that participate in the references
		--

		-- determine which reference direction should be included
		if @nRefDirection = 0 begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that reference (atomic, sequences, and collections) this class
			select 	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], c.[Id], f.[Name], f.[Id],
				1, -- references this class
				-- Note the COLLATE statement is required here when using database servers with non-US collation!!
				master.dbo.fn_varbintohexstr(oi.[OrdKey]) COLLATE SQL_Latin1_General_CP1_CI_AS
			from 	#OwnedObjsInfo$ oi
					join [Field$] f on f.[DstCls] = oi.[ObjClass] 
						and ( 	( f.[type] = kcptReferenceAtom and @grfcpt & kfcptReferenceAtom = kfcptReferenceAtom )
							or ( f.[type] = kcptReferenceCollection and @grfcpt & kfcptReferenceCollection = kfcptReferenceCollection )
							or ( f.[type] = kcptReferenceSequence and @grfcpt & kfcptReferenceSequence = kfcptReferenceSequence )
						)
					join [Class$] c on f.[Class] = c.[Id]
			union all
			-- get the classes that are referenced (atomic, sequences, and collections) by this class
			select	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], f.[DstCls], f.[Name], f.[Id],
				2, -- referenced by this class
				-- Note the COLLATE statement is required here when using database servers with non-US collation!!
				master.dbo.fn_varbintohexstr(oi.[OrdKey]) COLLATE SQL_Latin1_General_CP1_CI_AS
			from	#OwnedObjsInfo$ oi 
					join [Class$] c on c.[Id] = oi.[ObjClass]
					join [Field$] f on f.[Class] = c.[Id] 
						and ( 	( f.[type] = kcptReferenceAtom and @grfcpt & kfcptReferenceAtom = kfcptReferenceAtom )
							or ( f.[type] = kcptReferenceCollection and @grfcpt & kfcptReferenceCollection = kfcptReferenceCollection )
							or ( f.[type] = kcptReferenceSequence and @grfcpt & kfcptReferenceSequence = kfcptReferenceSequence )
						)
			order by oi.[ObjId]
		end
		else if @nRefDirection = 1 begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that are referenced (atomic, sequences, and collections) by these classes
			select	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], f.[DstCls], f.[Name], f.[Id],
				2, -- referenced by this class
				-- Note the COLLATE statement is required here when using database servers with non-US collation!!
				master.dbo.fn_varbintohexstr(oi.[OrdKey]) COLLATE SQL_Latin1_General_CP1_CI_AS
			from	#OwnedObjsInfo$ oi
					join [Class$] c on c.[Id] = oi.[ObjClass]
					join [Field$] f on f.[Class] = c.[Id] 
						and ( 	( f.[type] = kcptReferenceAtom and @grfcpt & kfcptReferenceAtom = kfcptReferenceAtom )
							or ( f.[type] = kcptReferenceCollection and @grfcpt & kfcptReferenceCollection = kfcptReferenceCollection )
							or ( f.[type] = kcptReferenceSequence and @grfcpt & kfcptReferenceSequence = kfcptReferenceSequence )
						)
			order by oi.[ObjId]
		end
		else begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that reference (atomic, sequences, and collections) these classes
			-- do not include internal references between objects within the owning object hierarchy;
			--	this will be handled below
			select 	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], c.[Id], f.[Name], f.[Id],
				1, -- references this class
				-- Note the COLLATE statement is required here when using database servers with non-US collation!!
				master.dbo.fn_varbintohexstr(oi.[OrdKey]) COLLATE SQL_Latin1_General_CP1_CI_AS
			from 	#OwnedObjsInfo$ oi
					join [Field$] f on f.[DstCls] = oi.[ObjClass] 
						and ( 	( f.[type] = kcptReferenceAtom and @grfcpt & kfcptReferenceAtom = kfcptReferenceAtom )
							or ( f.[type] = kcptReferenceCollection and @grfcpt & kfcptReferenceCollection = kfcptReferenceCollection )
							or ( f.[type] = kcptReferenceSequence and @grfcpt & kfcptReferenceSequence = kfcptReferenceSequence )
						)
					join [Class$] c on f.[Class] = c.[Id]
			order by oi.[ObjId]
		end

		open GetClassRefObj_cur
		fetch GetClassRefObj_cur into @nObjId, @nObjClass, @nInheritDepth, @nOwnerDepth, @nType, @sClass, @nClass, 
				@sField, @nField, @nDirection, @sOrdKey
		while @@fetch_status = 0 begin

			-- build the base part of the query
			set @sQry = 'insert into #ObjInfoTbl$ '+
					'(ObjId,ObjClass,InheritDepth,OwnerDepth,RelObjId,RelObjClass,RelObjField,RelOrder,RelType,OrdKey)' + char(13) +
					'select '

			-- determine if the reference is atomic
			if @nType = kcptReferenceAtom begin
				-- determine if this class references an object's class within the object hierachy,
				--	and whether or not it should be included
				if @nDirection = 1 and (@nRefDirection = 0 or @nRefDirection = -1) begin 
					set @sQry=@sQry+convert(nvarchar(11), @nObjId)+','+convert(nvarchar(11), @nObjClass)+','+
							convert(nvarchar(11), @nInheritDepth)+','+convert(nvarchar(11), @nOwnerDepth)+','+
							't.[Id],'+convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nField)+','+
							'NULL,'+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'] t (readuncommitted) '+
						'where ['+@sField+']='+convert(nvarchar(11),@nObjId)

					-- determine if only external references should be included - don't included
					--	references between objects within the owning hierarchy
					if @nRefDirection = -1 begin
						set @sQry = @sQry + 'and not exists (' +
								'select * from #OwnedObjsInfo$ oi ' +
								'where oi.[ObjId]=t.[Id] ' +
									'and oi.[RelType] not in (' +
									convert(nvarchar(11), kfcptReferenceAtom)+',' +
									convert(nvarchar(11), kfcptReferenceCollection)+',' +
									convert(nvarchar(11), kfcptReferenceSequence)+'))'
					end
				end
				-- determine if this class is referenced by an object's class within the object hierachy,
				--	and whether or not it should be included
				else if @nDirection = 2 and (@nRefDirection = 0 or @nRefDirection = 1) begin
					set @sQry=@sQry+'['+@sField+'],'+
					 		convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nInheritDepth)+','+
							convert(nvarchar(11), @nOwnerDepth)+','+convert(nvarchar(11), @nObjId)+','+
							convert(nvarchar(11), @nObjClass)+','+convert(nvarchar(11), @nField)+','+
							'NULL,'+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'] (readuncommitted) ' +
						'where [id]='+convert(nvarchar(11),@nObjId)+' '+
							'and ['+@sField+'] is not null'
				end
			end
			else begin
				-- if the reference is ordered insert the order value, otherwise insert null
				if @nType = kcptReferenceSequence set @sOrderField = '[Ord]'
				else set @sOrderField = 'NULL'

				-- determine if this class references an object's class and whether or not it should be
				--	included
				if @nDirection = 1 and (@nRefDirection = 0 or @nRefDirection = -1) begin 
					set @sQry=@sQry+convert(nvarchar(11), @nObjId)+','+convert(nvarchar(11), @nObjClass)+','+
							convert(nvarchar(11), @nInheritDepth)+','+convert(nvarchar(11), @nOwnerDepth)+','+
							't.[Src],'+convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nField)+','+
							@sOrderField+','+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'_'+@sField+'] t (readuncommitted) '+
						'where t.[dst]='+convert(nvarchar(11),@nObjId)

					-- determine if only external references should be included - don't included
					--	references between objects within the owning hierarchy
					if @nRefDirection = -1 begin
						set @sQry = @sQry + 'and not exists (' +
								'select * from #OwnedObjsInfo$ oi ' +
								'where oi.[ObjId]=t.[Src] ' +
									'and oi.[RelType] not in (' +
									convert(nvarchar(11), kfcptReferenceAtom)+',' +
									convert(nvarchar(11), kfcptReferenceCollection)+',' +
									convert(nvarchar(11), kfcptReferenceSequence)+'))'
					end
				end
				-- determine if this class is referenced by an object's class and whether or not it
				--	should be included
				else if @nDirection = 2 and (@nRefDirection = 0 or @nRefDirection = 1) begin
					set @sQry=@sQry+'[Dst],'+
							convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nInheritDepth)+','+
							convert(nvarchar(11), @nOwnerDepth)+','+convert(nvarchar(11), @nObjId)+','+
							convert(nvarchar(11), @nObjClass)+','+convert(nvarchar(11), @nField)+','+
							@sOrderField+','+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'_'+@sField+'] (readuncommitted) '+
						'where [src]='+convert(nvarchar(11),@nObjId)
				end
			end

			exec (@sQry)				
			set @Err = @@error
			if @Err <> 0 begin
				raiserror ('GetLinkedObjs$: SQL Error %d; Error performing dynamic SQL.', 16, 1, @Err)

				close GetClassRefObj_cur
				deallocate GetClassRefObj_cur

				goto LFail
			end

			fetch GetClassRefObj_cur into @nObjId, @nObjClass, @nInheritDepth, @nOwnerDepth, @nType, @sClass, 
					@nClass, @sField, @nField, @nDirection, @sOrdKey
		end

		close GetClassRefObj_cur
		deallocate GetClassRefObj_cur
	end

	-- if a class was specified remove the owned objects that are not of that type of class; these objects were
	--    necessary in order to get a list of all of the referenced and referencing objects that were potentially 
	--    the type of specified class
	if @riid is not null begin
		delete	#ObjInfoTbl$
		where 	not exists (
				select	*
				from	[ClassPar$] cp
				where	cp.[Dst] = @riid
					and cp.[Src] = [ObjClass]
			)
		set @Err = @@error
		if @Err <> 0 begin
			raiserror ('GetLinkedObjs$: SQL Error %d; Unable to remove objects that are not the specified class %d.', 16, 1, @Err, @riid)
			goto LFail
		end
	end

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go

/***********************************************************************************************
 * GetLinkedObjects$
 *
 * Description: 
 *	retrieves objects owned or referenced by the specifed object(s)
 *
 * Parameters: 
 *	@uid=a unique Id that identifies this call's results set; @ObjId=Id of the object;
 *	@ObjId=the object for which all linked objects will be gathered;
 *	@grfcpt=mask that indicates what types of related objects should be retrieved; 
 *	@fBaseClasses=a flag that determines if the base classes of owned objects are included 
 *		in the object list (e.g., rows for each object + all superclasses except CmObject.
 *		So if a CmPerson is included, it will also have a row for CmPossibility)
 *	@fSubClasses=flag that determines if the sub classes of owned objects are included in 
 *		the object list;
 *	@fRecurse=a flag that determines if the owning tree is traversed; 
 *	@nRefDirection=determines which reference directions will be included in the results
 *		(0=both, 1=referenced by this/these object(s), -1 reference this/these objects)
 *	@riid=only return objects of this class (including subclasses of this class). NULL
 *		returns all classes;
 *	@fCalcOrdKey=flag that determines if the order key is calculated; 
 *
 * Returns: 
 *	0 if successful, otherwise an error code
 *
 * Notes: 
 *	If @ObjId is not specified this procedure works on all of the rows in the ObjInfTbl$ 
 *	where uid=@uid
 **********************************************************************************************/
if object_id('GetLinkedObjects$') is not null begin
	print 'removing proc GetLinkedObjects$'
	drop proc [GetLinkedObjects$]
end
go
print 'creating proc GetLinkedObjects$'
go
create proc [GetLinkedObjects$]
	@uid uniqueidentifier output,
	@ObjId int=NULL,
	@grfcpt int=kgrfcptAll,
	@fBaseClasses tinyint=0,
	@fSubClasses tinyint=0,
	@fRecurse tinyint=1,
	@nRefDirection smallint=0,
	@riid int=NULL,
	@fCalcOrdKey tinyint=1
as
	declare @Err int, @nRowCnt int
	declare	@sQry nvarchar(1000), @sUid nvarchar(50)
	declare	@nObjId int, @nObjClass int, @nInheritDepth int, @nOwnerDepth int, @nClass int, @nField int, 
		@nRelOrder int, @nType int, @nDirection int, @sClass sysname, @sField sysname, 
		@sOrderField sysname, @sOrdKey varchar(502)
	declare	@fIsNocountOn int

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- if null was specified as the mask assume that all objects are desired
	if @grfcpt is null set @grfcpt = kgrfcptAll

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 
		-- get a unique value to identify this invocation's results
		set @uid = newid()

		-- get the class of the specified object
		insert into [ObjInfoTbl$] with (rowlock) (uid, ObjId, ObjClass, OrdKey)
		select	@uid, @objId, co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[CmObject] co (readuncommitted)
		where	co.[Id] = @objId

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to insert the initial object into the ObjInfoTbl$ table (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
	end
	else begin
		update	[ObjInfoTbl$] with (rowlock)
		set	[ObjClass]=co.[Class$], [OwnerDepth]=0, [InheritDepth]=0,
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			[OrdKey]=convert(varbinary, coalesce(co.[Owner$], 0)) + 
				convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
				convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[ObjInfoTbl$] oi (readuncommitted)
				join [CmObject] co (readuncommitted) on oi.[ObjId] = co.[Id]
		where	oi.[uid]=@uid
	end

	-- determine if the whole owning tree should be included in the results
	set @nOwnerDepth = 1
	set @nRowCnt = 1
	while @nRowCnt > 0
	begin	
		-- determine if the order key should be calculated - if the order key is not needed a more 
		--    effecient query can be used to generate the ownership tree
		if @fCalcOrdKey = 1 begin
			-- get the objects owned at the next depth and calculate the order key
			insert	into [ObjInfoTbl$] with (rowlock)
				(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
			select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 
				oi.OrdKey+convert(varbinary, co.[Owner$]) + convert(varbinary, co.[OwnFlid$]) + convert(varbinary, coalesce(co.[OwnOrd$], 0))
			from 	[CmObject] co (readuncommitted)
					join [ObjInfoTbl$] oi (readuncommitted) on co.[Owner$] = oi.[ObjId]
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	oi.[Uid]=@uid
				and oi.[OwnerDepth] = @nOwnerDepth - 1
				and ( 	( @grfcpt & kfcptOwningAtom = kfcptOwningAtom and f.[Type] = kcptOwningAtom )
					or ( @grfcpt & kfcptOwningCollection = kfcptOwningCollection and f.[Type] = kcptOwningCollection )
					or ( @grfcpt & kfcptOwningSequence = kfcptOwningSequence and f.[Type] = kcptOwningSequence )
				)
		end
		else begin
			-- get the objects owned at the next depth and do not calculate the order key
			insert	into [ObjInfoTbl$] with (rowlock)
				(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
			select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type]
			from 	[CmObject] co (readuncommitted)
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	exists (select 	*
					from 	[ObjInfoTbl$] oi (readuncommitted)
					where 	oi.[ObjId] = co.[Owner$]
						and oi.[Uid] = @uid
						and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
				and ( 	( @grfcpt & kfcptOwningAtom = kfcptOwningAtom and f.[Type] = kcptOwningAtom )
					or ( @grfcpt & kfcptOwningCollection = kfcptOwningCollection and f.[Type] = kcptOwningCollection )
					or ( @grfcpt & kfcptOwningSequence = kfcptOwningSequence and f.[Type] = kcptOwningSequence )
				)
		end
		select @nRowCnt=@@rowcount, @Err=@@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to traverse owning hierachy (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	

		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth + 1
	end

	--
	-- get all of the base classes of the object(s)
	--
	if @fBaseClasses = 1 begin
		insert	into ObjInfoTbl$ with (rowlock)
			(uid, ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	@uid, oi.[ObjId], p.[Dst], p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType], oi.[OrdKey]
		from	[ObjInfoTbl$] oi (readuncommitted)
				join [ClassPar$] p on oi.[ObjClass] = p.[Src]
				join [Class$] c on c.[id] = p.[Dst]
		where	p.[Depth] > 0 and p.[Dst] <> 0
			and [Uid]=@uid

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to get base classes (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	
	end
	--
	-- get all of the sub classes of the object(s)
	--
	if @fSubClasses = 1 begin
		insert	into ObjInfoTbl$ with (rowlock)
			(uid, ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	@uid, oi.[ObjId], p.[Src], -p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType], oi.[OrdKey]
		from	[ObjInfoTbl$] oi (readuncommitted)
				join [ClassPar$] p on oi.[ObjClass] = p.[Dst] and InheritDepth = 0
				join [Class$] c on c.[id] = p.[Dst]
		where	p.[Depth] > 0 and p.[Dst] <> 0
			and [Uid] = @uid

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to get sub classes (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	
	end
	
	-- determine if any references should be included in the results
	if (kgrfcptReference) & @grfcpt > 0 begin

		--
		-- get a list of all of the classes that reference each class associated with the specified object 
		--	and a list of the classes that each associated class reference, then loop through them to 
		--	get all of the objects that participate in the references
		--

		-- determine which reference direction should be included
		if @nRefDirection = 0 begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that reference (atomic, sequences, and collections) this class
			select 	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], c.[Id], f.[Name], f.[Id],
				1, -- references this class
				convert(varchar, oi.[OrdKey])
			from 	[ObjInfoTbl$] oi (readuncommitted)
					join [Field$] f on f.[DstCls] = oi.[ObjClass] 
						and ( 	( f.[type] = kcptReferenceAtom and @grfcpt & kfcptReferenceAtom = kfcptReferenceAtom )
							or ( f.[type] = kcptReferenceCollection and @grfcpt & kfcptReferenceCollection = kfcptReferenceCollection )
							or ( f.[type] = kcptReferenceSequence and @grfcpt & kfcptReferenceSequence = kfcptReferenceSequence )
						)
					join [Class$] c on f.[Class] = c.[Id]
			where	[Uid]=@uid
				and (@riid is null or oi.[ObjClass] = @riid)
			union all
			-- get the classes that are referenced (atomic, sequences, and collections) by this class
			select	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], f.[DstCls], f.[Name], f.[Id],
				2, -- referenced by this class
				-- Note the COLLATE statement is required here when using database servers with non-US collation!!
				master.dbo.fn_varbintohexstr(oi.[OrdKey]) COLLATE SQL_Latin1_General_CP1_CI_AS
			from	[ObjInfoTbl$] oi (readuncommitted)
					join [Class$] c on c.[Id] = oi.[ObjClass]
					join [Field$] f on f.[Class] = c.[Id] 
						and ( 	( f.[type] = kcptReferenceAtom and @grfcpt & kfcptReferenceAtom = kfcptReferenceAtom )
							or ( f.[type] = kcptReferenceCollection and @grfcpt & kfcptReferenceCollection = kfcptReferenceCollection )
							or ( f.[type] = kcptReferenceSequence and @grfcpt & kfcptReferenceSequence = kfcptReferenceSequence )
						)
			where	[Uid]=@uid
				and (@riid is null or f.[DstCls] = @riid)
			order by oi.[ObjId]
		end
		else if @nRefDirection = 1 begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that are referenced (atomic, sequences, and collections) by these classes
			select	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], f.[DstCls], f.[Name], f.[Id],
				2, -- referenced by this class
				convert(varchar, oi.[OrdKey])
			from	[ObjInfoTbl$] oi (readuncommitted)
					join [Class$] c on c.[Id] = oi.[ObjClass]
					join [Field$] f on f.[Class] = c.[Id] 
						and ( 	( f.[type] = kcptReferenceAtom and @grfcpt & kfcptReferenceAtom = kfcptReferenceAtom )
							or ( f.[type] = kcptReferenceCollection and @grfcpt & kfcptReferenceCollection = kfcptReferenceCollection )
							or ( f.[type] = kcptReferenceSequence and @grfcpt & kfcptReferenceSequence = kfcptReferenceSequence )
						)
			where	[Uid]=@uid
				and (@riid is null or f.[DstCls] = @riid)
			order by oi.[ObjId]
		end
		else begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that reference (atomic, sequences, and collections) these classes
			-- do not include internal references between objects within the owning object hierarchy;
			--	this will be handled below
			select 	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], c.[Id], f.[Name], f.[Id],
				1, -- references this class
				-- Note the COLLATE statement is required here when using database servers with non-US collation!!
				master.dbo.fn_varbintohexstr(oi.[OrdKey]) COLLATE SQL_Latin1_General_CP1_CI_AS
			from 	[ObjInfoTbl$] oi (readuncommitted)
					join [Field$] f on f.[DstCls] = oi.[ObjClass] 
						and ( 	( f.[type] = kcptReferenceAtom and @grfcpt & kfcptReferenceAtom = kfcptReferenceAtom )
							or ( f.[type] = kcptReferenceCollection and @grfcpt & kfcptReferenceCollection = kfcptReferenceCollection )
							or ( f.[type] = kcptReferenceSequence and @grfcpt & kfcptReferenceSequence = kfcptReferenceSequence )
						)
					join [Class$] c on f.[Class] = c.[Id]
			where	[Uid]=@uid
				and (@riid is null or oi.[ObjClass] = @riid)
			order by oi.[ObjId]
		end

		open GetClassRefObj_cur
		fetch GetClassRefObj_cur into @nObjId, @nObjClass, @nInheritDepth, @nOwnerDepth, @nType, @sClass, @nClass, 
				@sField, @nField, @nDirection, @sOrdKey
		while @@fetch_status = 0 begin

			-- build the base part of the query
			set @sQry = 'insert into [ObjInfoTbl$] with (rowlock) '+
					'(uid,ObjId,ObjClass,InheritDepth,OwnerDepth,RelObjId,RelObjClass,RelObjField,RelOrder,RelType,OrdKey)' + char(13) +
					'select '''+convert(nvarchar(255), @uid)+''','

			-- determine if the reference is atomic
			if @nType = kcptReferenceAtom begin
				-- determine if this class references an object's class within the object hierachy,
				--	and whether or not it should be included
				if @nDirection = 1 and (@nRefDirection = 0 or @nRefDirection = -1) begin 
					set @sQry=@sQry+convert(nvarchar(11), @nObjId)+','+convert(nvarchar(11), @nObjClass)+','+
							convert(nvarchar(11), @nInheritDepth)+','+convert(nvarchar(11), @nOwnerDepth)+','+
							't.[Id],'+convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nField)+','+
							'NULL,'+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'] t (readuncommitted) '+
						'where ['+@sField+']='+convert(nvarchar(11),@nObjId)

					-- determine if only external references should be included - don't included
					--	references between objects within the owning hierarchy
					if @nRefDirection = -1 begin
						set @sQry = @sQry + 'and not exists (' +
								'select * from [ObjInfoTbl$] oi (readuncommitted) ' +
								'where oi.[ObjId]=t.[Id] ' +
									'and oi.[uid] = '''+convert(nvarchar(255), @uid)+ '''' +
									'and oi.[RelType] not in (' +
									convert(nvarchar(11), kfcptReferenceAtom)+',' +
									convert(nvarchar(11), kfcptReferenceCollection)+',' +
									convert(nvarchar(11), kfcptReferenceSequence)+'))'
					end
				end
				-- determine if this class is referenced by an object's class within the object hierachy,
				--	and whether or not it should be included
				else if @nDirection = 2 and (@nRefDirection = 0 or @nRefDirection = 1) begin
					set @sQry=@sQry+'['+@sField+'],'+
					 		convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nInheritDepth)+','+
							convert(nvarchar(11), @nOwnerDepth)+','+convert(nvarchar(11), @nObjId)+','+
							convert(nvarchar(11), @nObjClass)+','+convert(nvarchar(11), @nField)+','+
							'NULL,'+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'] (readuncommitted) ' +
						'where [id]='+convert(nvarchar(11),@nObjId)+' '+
							'and ['+@sField+'] is not null'
				end
			end
			else begin
				-- if the reference is ordered insert the order value, otherwise insert null
				if @nType = kcptReferenceSequence set @sOrderField = '[Ord]'
				else set @sOrderField = 'NULL'

				-- determine if this class references an object's class and whether or not it should be
				--	included
				if @nDirection = 1 and (@nRefDirection = 0 or @nRefDirection = -1) begin 
					set @sQry=@sQry+convert(nvarchar(11), @nObjId)+','+convert(nvarchar(11), @nObjClass)+','+
							convert(nvarchar(11), @nInheritDepth)+','+convert(nvarchar(11), @nOwnerDepth)+','+
							't.[Src],'+convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nField)+','+
							@sOrderField+','+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'_'+@sField+'] t (readuncommitted) '+
						'where t.[dst]='+convert(nvarchar(11),@nObjId)

					-- determine if only external references should be included - don't included
					--	references between objects within the owning hierarchy
					if @nRefDirection = -1 begin
						set @sQry = @sQry + 'and not exists (' +
								'select * from [ObjInfoTbl$] oi (readuncommitted) ' +
								'where oi.[ObjId]=t.[Src] ' +
									'and oi.[uid] = '''+convert(nvarchar(255), @uid)+ '''' +
									'and oi.[RelType] not in (' +
									convert(nvarchar(11), kfcptReferenceAtom)+',' +
									convert(nvarchar(11), kfcptReferenceCollection)+',' +
									convert(nvarchar(11), kfcptReferenceSequence)+'))'
					end
				end
				-- determine if this class is referenced by an object's class and whether or not it
				--	should be included
				else if @nDirection = 2 and (@nRefDirection = 0 or @nRefDirection = 1) begin
					set @sQry=@sQry+'[Dst],'+
							convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nInheritDepth)+','+
							convert(nvarchar(11), @nOwnerDepth)+','+convert(nvarchar(11), @nObjId)+','+
							convert(nvarchar(11), @nObjClass)+','+convert(nvarchar(11), @nField)+','+
							@sOrderField+','+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'_'+@sField+'] (readuncommitted) '+
						'where [src]='+convert(nvarchar(11),@nObjId)
				end
			end

			exec (@sQry)				
			set @Err = @@error
			if @Err <> 0 begin
				set @sUid = convert(nvarchar(50), @Uid)
				raiserror ('GetLinkedObjects$: SQL Error %d; Error performing dynamic SQL (UID=%s).', 16, 1, @Err, @sUid)

				close GetClassRefObj_cur
				deallocate GetClassRefObj_cur

				goto LFail
			end

			fetch GetClassRefObj_cur into @nObjId, @nObjClass, @nInheritDepth, @nOwnerDepth, @nType, @sClass, 
					@nClass, @sField, @nField, @nDirection, @sOrdKey
		end

		close GetClassRefObj_cur
		deallocate GetClassRefObj_cur
	end

	-- if a class was specified remove the owned objects that are not of that type of class; these objects were
	--    necessary in order to get a list of all of the referenced and referencing objects that were potentially 
	--    the type of specified class
	if @riid is not null begin
		delete	[ObjInfoTbl$]
		where 	[Uid] = @uid
			and not exists (
				select	*
				from	[ClassPar$] cp
				where	cp.[Dst] = @riid
					and cp.[Src] = [ObjClass]
			)
		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to remove objects that are not the specified class %d (UID=%s).', 16, 1, @Err, @riid, @sUid)
			goto LFail
		end
	end

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


/***********************************************************************************************
 * Function: fnGetOwnershipPath$
 *
 * Description: 
 *	returns objects that are in the ownership chain of the specified object(s)
 *
 * Parameters: 
 *	@ObjId=Id of the object;
 * 	@hXMLDocObjList=handle to a parsed XML document that contains multiple object Ids - the
 *		ownership chain will be produced for each of these objectIds;
 *	@nDirection=determines if all objects in the owning chain are included (0), if only 
 *		objects owned by the specified object(s) are included (1), or if only objects 
 *		that own the specified object(s) are included (-1) in the results;
 *	@fRecurse=determinse if the owning tree should be tranversed (0=do not recurse the 
 *		owning tree, 1=recurse the owning tree)
 *	@fCaclOrdKey=determines if the order key is calculated (0=do not caclulate the order 
 *		key, 1=calculate the order key)
 *
 * Returns: 
 *	Table containing the object information in the format:
 *		[ObjId]		int,
 *		[ObjClass]	int,
 *		[InheritDepth]	int,
 *		[OwnerDepth]	int,
 *		[RelObjId]	int,
 *		[RelObjClass]	int,
 *		[RelObjField]	int,
 *		[RelOrder]	int,
 *		[RelType]	int,
 *		[OrdKey]	varbinary(250)
 **********************************************************************************************/
if object_id('fnGetOwnershipPath$') is not null begin
	print 'removing function fnGetOwnershipPath$'
	drop function [fnGetOwnershipPath$]
end
go
print 'creating function fnGetOwnershipPath$'
go
create function [fnGetOwnershipPath$] (
	@ObjId int=null,
	@hXMLDocObjList int=null,
	@nDirection smallint=0,	
	@fRecurse tinyint=1,
	@fCalcOrdKey tinyint=1 )
returns @ObjInfo table (
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
as
begin
	declare @nRowCnt int, @nOwnerDepth int

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 

		-- get the class of the specified object
		insert into @ObjInfo
			(ObjId, ObjClass, OwnerDepth, InheritDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	@objId, co.[Class$], 0, 0, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type],
			-- go ahead and calculate the order key for depth 0 objects even if @fCalcOrdKey=0
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[CmObject] co (readuncommitted)
				left outer join [Field$] f on co.[OwnFlid$] = f.[Id]
		where	co.[Id] = @objId
		if @@error <> 0 goto LFail
	end
	else begin

		-- parse the XML list of Object IDs and insert them into the table variable
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	i.[Id], co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	openxml (@hXMLDocObjList, '/root/Obj') with ([Id] int) i
			join [CmObject] co (readuncommitted) on co.[Id] = i.[Id]
		if @@error <> 0 goto LFail
	end

	-- determine if the objects owned by the specified object(s) should be included in the results
	if @nDirection = 0 or @nDirection = 1 begin
		set @nRowCnt = 1
		set @nOwnerDepth = 1
	end
	else set @nRowCnt = 0
	while @nRowCnt > 0 begin	

		-- determine if the order key should be calculated - if the order key is not needed a more 
		--    effecient query can be used to generate the ownership tree
		if @fCalcOrdKey = 1 begin
			-- get the objects owned at the next depth and calculate the order key
			insert into @ObjInfo
				(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
			select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[DstCls], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 
				oi.OrdKey+convert(varbinary, co.[Owner$]) + convert(varbinary, co.[OwnFlid$]) + convert(varbinary, coalesce(co.[OwnOrd$], 0))
			from 	[CmObject] co (readuncommitted)
					join @ObjInfo oi on co.[Owner$] = oi.[ObjId]
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	oi.[OwnerDepth] = @nOwnerDepth - 1
		end
		else begin
			-- get the objects owned at the next depth and do not calculate the order key
			insert into @ObjInfo
				(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
			select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[DstCls], co.[OwnFlid$], co.[OwnOrd$], f.[Type]
			from 	[CmObject] co (readuncommitted)
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	exists (select 	*
					from 	@ObjInfo oi
					where 	oi.[ObjId] = co.[Owner$]
						and oi.[OwnerDepth] = @nOwnerDepth - 1
					)
		end
		set @nRowCnt = @@rowcount

		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth + 1
	end

	-- determine if the heirarchy of objects that own the specified object(s) should be included in the results
	if @nDirection = 0 or @nDirection = -1 begin
		set @nRowCnt = 1
		set @nOwnerDepth = -1
	end
	else set @nRowCnt = 0
	while @nRowCnt > 0 begin
		insert into @ObjInfo
			(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select 	co.[Id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 0
		from 	[CmObject] co (readuncommitted)
				left join [Field$] f on f.[id] = co.[OwnFlid$]
		-- for this query the exists clause is more effecient than a join based on the ownership depth
		where 	exists (select	*
				from	@ObjInfo oi
				where	oi.[RelObjId] = co.[Id]
					and oi.[OwnerDepth] = @nOwnerDepth + 1
				)
		set @nRowCnt = @@rowcount

		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth - 1
	end

	return
LFail:
	delete @ObjInfo

	return
end
go


/***********************************************************************************************
 * GetOwnershipPath$
 *
 * Description: 
 *	retrieves objects that are in the ownership chain of the specified object(s)
 *
 * Parameters: 
 *	@uid=a unique Id that identifies this call's results set; 
 *	@ObjId=Id of the object;
 *	@nDirection=determines if all objects in the owning chain are included (0), if only 
 *		objects owned by the specified object(s) are included (1), or if only objects 
 *		that own the specified object(s) are included (-1) in the results;
 *	@fRecurse=determinse if the owning tree should be tranversed (0=do not recurse the 
 *		owning tree, 1=recurse the owning tree)
 *	@fCaclOrdKey=determines if the order key is calculated (0=do not caclulate the order 
 *		key, 1=calculate the order key)
 *
 * Returns: 
 *	0 if successful, otherwise an error code
 *
 * Notes: 
 *	If @ObjId is not specified this procedure works on all of the rows in the ObjInfTbl$ 
 *	where uid=@uid
 **********************************************************************************************/
if object_id('GetOwnershipPath$') is not null begin
	print 'removing proc GetOwnershipPath$'
	drop proc [GetOwnershipPath$]
end
go
print 'creating proc GetOwnershipPath$'
go
create proc [GetOwnershipPath$]
	@uid uniqueidentifier output,
	@ObjId int=NULL,
	@nDirection smallint=0,	
	@fRecurse tinyint=1,
	@fCalcOrdKey tinyint=1
as
	declare @Err int, @nRowCnt int, @nOwnerDepth int, @fIsNocountOn int, @sUid nvarchar(50)

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 
		-- get a unique value to identify this invocation's results
		set @uid = newid()

		-- get the class of the specified object
		insert into [ObjInfoTbl$] with (rowlock)
			(uid, ObjId, ObjClass, OwnerDepth, InheritDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	@uid, @objId, co.[Class$], 0, 0, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type],
			-- go ahead and calculate the order key for depth 0 objects even if @fCalcOrdKey=0
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[CmObject] co (readuncommitted)
				left outer join [Field$] f on co.[OwnFlid$] = f.[Id]
		where	co.[Id] = @objId

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetOwnershipPath$: SQL Error %d; Error inserting initial object (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
	end
	else begin
		update	[ObjInfoTbl$] with (rowlock)
		set	[ObjClass]=co.[Class$], [OwnerDepth]=0, [InheritDepth]=0, [RelObjId]=co.[Owner$], [RelObjClass]=f.[Class], 
			[RelObjField]=co.[OwnFlid$], [RelOrder]=co.[OwnOrd$], [RelType]=f.[Type],
			-- go ahead and calculate the order key for depth 0 objects even if @fCalcOrdKey=0
			[OrdKey]=convert(varbinary, coalesce(co.[Owner$], 0)) + 
				convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
				convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[ObjInfoTbl$] oi (readuncommitted)
				join [CmObject] co (readuncommitted) on oi.[ObjId] = co.[Id] 
				left outer join [Field$] f on co.[OwnFlid$] = f.[Id]
		where	oi.[uid]=@uid

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetOwnershipPath$: SQL Error %d; Unable to update initial objects (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
	end

	-- determine if the objects owned by the specified object(s) should be included in the results
	if @nDirection = 0 or @nDirection = 1 begin
		set @nRowCnt = 1
		set @nOwnerDepth = 1
	end
	else set @nRowCnt = 0
	while @nRowCnt > 0 begin	

		-- determine if the order key should be calculated - if the order key is not needed a more 
		--    effecient query can be used to generate the ownership tree
		if @fCalcOrdKey = 1 begin
			-- get the objects owned at the next depth and calculate the order key
			insert into [ObjInfoTbl$] with (rowlock)
				(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
			select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[DstCls], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 
				oi.OrdKey+convert(varbinary, co.[Owner$]) + convert(varbinary, co.[OwnFlid$]) + convert(varbinary, coalesce(co.[OwnOrd$], 0))
			from 	[CmObject] co (readuncommitted)
					join [ObjInfoTbl$] oi (readuncommitted) on co.[Owner$] = oi.[ObjId]
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	[Uid]=@uid
				and oi.[OwnerDepth] = @nOwnerDepth - 1
		end
		else begin
			-- get the objects owned at the next depth and do not calculate the order key
			insert into [ObjInfoTbl$] with (rowlock)
				(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
			select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[DstCls], co.[OwnFlid$], co.[OwnOrd$], f.[Type]
			from 	[CmObject] co (readuncommitted)
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	exists (select 	*
					from 	[ObjInfoTbl$] oi (readuncommitted)
					where 	oi.[ObjId] = co.[Owner$]
						and oi.[Uid] = @uid
						and oi.[OwnerDepth] = @nOwnerDepth - 1
					)
		end
		select @nRowCnt=@@rowcount, @Err=@@error

		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetOwnershipPath$: SQL Error %d; Unable to traverse owning hierachy - owned object(s) (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end

		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth + 1
	end

	-- determine if the heirarchy of objects that own the specified object(s) should be included in the results
	if @nDirection = 0 or @nDirection = -1 begin
		set @nRowCnt = 1
		set @nOwnerDepth = -1
	end
	else set @nRowCnt = 0
	while @nRowCnt > 0 begin
		-- REVIEW: JDR
		-- possibly calculate the OrdKey for this direction as well - if this is done it may be easiest to calculate all of the order
		-- keys at the very end
		insert into [ObjInfoTbl$] with (rowlock)
			(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select 	@uid, co.[Id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 0
		from 	[CmObject] co (readuncommitted)
				left join [Field$] f on f.[id] = co.[OwnFlid$]
		-- for this query the exists clause is more effecient than a join based on the ownership depth
		where 	exists (select	*
				from	ObjInfoTbl$ oi (readuncommitted)
				where	oi.[RelObjId] = co.[Id]
					and oi.[Uid]=@uid
					and oi.[OwnerDepth] = @nOwnerDepth + 1
				)
		select @nRowCnt=@@rowcount, @Err=@@error

		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetOwnershipPath$: SQL Error %d; Unable to traverse owning hierachy - object(s) that own the specified object(s) (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth - 1
	end

	set @Err = 0
LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


/***********************************************************************************************
 * Function: fnIsInOwnershipPath$
 *
 * Description: 
 *	determines if the specified object is in the ownership path of the specified owning 
 *	object
 *
 * Parameters: 
 *	@ObjId=Id of the object; 
 *	@OwnerObjId=Id of the owner object;
 *
 * Returns: 
 * 	true (1) if the object is in the ownership path, false (0) if the object is not in the
 *	ownership path, or -1 if an error occured
 **********************************************************************************************/
if object_id('fnIsInOwnershipPath$') is not null begin
	print 'removing function fnIsInOwnershipPath$'
	drop function [fnIsInOwnershipPath$]
end
go
print 'creating function fnIsInOwnershipPath$'
go
create function [fnIsInOwnershipPath$] (
	@ObjId int,
	@OwnerObjId int )
returns tinyint
as
begin
	declare @nRowCnt int, @nOwnerDepth int
	declare @fInPath tinyint
	declare @ObjInfo table (
		[ObjId]		int		not null,
		[ObjClass]	int		null,
		[InheritDepth]	int		null		default(0),
		[OwnerDepth]	int		null		default(0),
		[RelObjId]	int		null,
		[RelObjClass]	int		null,
		[RelObjField]	int		null,
		[RelOrder]	int		null,
		[RelType]	int		null,
		[OrdKey]	varbinary(250)	null		default(0) )

	set @fInPath = 0

	-- get the class of the specified object
	insert into @ObjInfo (ObjId, ObjClass)
	select	@OwnerObjId, co.[Class$]
	from	[CmObject] co (readuncommitted)
	where	co.[Id] = @OwnerObjId
	if @@error <> 0 goto LFail

	set @nRowCnt = 1
	set @nOwnerDepth = 1
	while @nRowCnt > 0 begin
		-- determine if one of the objects at the current depth owns the specified object, if
		--    one does we can exit here
		if exists (
			select	*
			from	[CmObject] co (readuncommitted)
					join @ObjInfo oi on co.[Owner$] = oi.[ObjId]
			where	oi.[OwnerDepth] = @nOwnerDepth - 1
				and co.[Id] = @ObjId 
			) 
		begin
			set @fInPath = 1
			goto Finish
		end

		-- add all of the objects owned at the next depth to the object list
		insert	into @ObjInfo (ObjId, ObjClass, OwnerDepth, RelObjId)
		select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$]
		from 	[CmObject] co (readuncommitted)
		where 	exists (select	*
				from 	@ObjInfo oi
				where 	oi.[ObjId] = co.[Owner$]
					and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
		set @nRowCnt = @@rowcount

		set @nOwnerDepth = @nOwnerDepth + 1
	end

Finish:
	return @fInPath
LFail:
	return -1
end
go


/***********************************************************************************************
 * fnGetObjInOwnershipPathWithId$
 *
 * Description: 
 *	returns a table of the closest object(s) in the ownership path of class riid
 *
 * Parameters: 
 *	@ObjId=Id of the object;
 * 	@hXMLDocObjList=handle to a parsed XML document that contains multiple object Ids - the
 *		ownership chain will be produced for each of these objectIds;
 *	@riid=class of the retrieved object(s)
 *
 * Returns: 
 *	Table containing the object information in the format:
 *		[ObjId]		int,
 *		[ObjClass]	int,
 *		[InheritDepth]	int,
 *		[OwnerDepth]	int,
 *		[RelObjId]	int,
 *		[RelObjClass]	int,
 *		[RelObjField]	int,
 *		[RelOrder]	int,
 *		[RelType]	int,
 *		[OrdKey]	varbinary(250)
 **********************************************************************************************/
if object_id('fnGetObjInOwnershipPathWithId$') is not null begin
	print 'removing function fnGetObjInOwnershipPathWithId$'
	drop function [fnGetObjInOwnershipPathWithId$]
end
go
print 'creating function fnGetObjInOwnershipPathWithId$'
go
create function [fnGetObjInOwnershipPathWithId$] (
	@objId int=null,
	@hXMLDocObjList int=null,
	@riid int )
returns @ObjInfo table (
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
as
begin
	declare	@iOwner int, @iOwnerClass int, @iCurObjId int, @iPrevObjId int

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 

		-- get the class of the specified object
		insert into @ObjInfo (ObjId, ObjClass, InheritDepth, OwnerDepth, ordkey)
		select	@objId, co.[Class$], null, null, null
		from	[CmObject] co (readuncommitted)
		where	co.[Id] = @objId
		if @@error <> 0 goto LFail		
	end
	else begin

		-- parse the XML list of Object IDs and insert them into the table variable
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	i.[Id], co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	openxml (@hXMLDocObjList, '/root/Obj') with ([Id] int) i
			join [CmObject] co (readuncommitted) on co.[Id] = i.[Id]
		if @@error <> 0 goto LFail
	end

	select	@iCurObjId=min(ObjId)
	from	@ObjInfo

	while @iCurObjId is not null begin
		set @iPrevObjId = @iCurObjId

		-- loop up (objects that own the specified objects) through the ownership hierarchy until the specified type (class=riid) of 
		-- 	owning object is found or the top of the ownership hierarchy is reached
		set @iOwnerClass = 0
		while @iOwnerClass <> @riid begin
			select top 1
				@iOwner = co.[Owner$],
				@iOwnerClass = f.[Class]
			from	[CmObject] co (readuncommitted)
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	co.[id] = @iCurObjId

			if @@rowcount > 0 set @iCurObjId = @iOwner
			else begin
				set @iCurObjId = null
				break
			end
		end

		if @iCurObjId is not null begin
			-- update the ObjInfoTbl$ so that specified object(s) is/are related to the specified type of
			--    object (class=riid) that owns it
			update	@ObjInfo
			set	[RelObjId]=@iOwner,
				[RelObjClass]=(
					select co.[Class$]
					from [CmObject] co (readuncommitted)
					where co.[id]=@iOwner)
			where	[ObjId]=@iPrevObjId
			if @@error <> 0 goto LFail
		end

		-- if the user specified an object there was only one object to process and we can therefore
		--    break out of the loop
		if @objId is not null break

		select	@iCurObjId=min(ObjId)
		from	@ObjInfo
		where	[ObjId] > @iPrevObjId
	end

	return
LFail:
	delete @ObjInfo
	return
end
go


/***********************************************************************************************
 * GetObjInOwnershipPathWithId$
 *
 * Description: 
 *	retrieves the closest object(s) in the ownership path of class riid
 *
 * Parameters: 
 *	@ObjId=Id of the object;
 *	@riid=class of the retrieved object(s)
 *
 * Returns: 
 *	0 if successful, otherwise an error code
 *
 * Notes: 
 *	if @ObjId is not specified this procedure works on all of the rows in the ObjInfTbl$ 
 *	where uid=@uid
 **********************************************************************************************/
if object_id('GetObjInOwnershipPathWithId$') is not null begin
	print 'removing proc GetObjInOwnershipPathWithId$'
	drop proc [GetObjInOwnershipPathWithId$]
end
go
print 'creating proc GetObjInOwnershipPathWithId$'
go
create proc [GetObjInOwnershipPathWithId$]
	@uid uniqueidentifier output,
	@objId int=NULL,
	@riid int
as
	declare	@iOwner int, @iOwnerClass int, @iCurObjId int, @iPrevObjId int,
		@Err int, @fIsNoCountOn int
	declare @sUid nvarchar(50)

	set @Err = 0
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 
		-- get a unique value to identify this invocation's results
		set @uid = newid()

		-- get the class of the specified object
		insert into [ObjInfoTbl$] with (rowlock) (uid, ObjId, ObjClass, InheritDepth, OwnerDepth, ordkey)
		select	@uid, @objId, co.[Class$], null, null, null
		from	[CmObject] co (readuncommitted)
		where	co.[Id] = @objId
		
		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetObjInOwnershipPathWithId$: SQL Error %d; Unable to insert the initial object (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	
	end
	else begin
		update	[ObjInfoTbl$] with (rowlock)
		set	[ObjClass]=co.[Class$], [OwnerDepth]=null, [InheritDepth]=null, [RelObjId]=null, 
			[RelObjClass]=null, [RelObjField]=null,	[RelOrder]=null, [RelType]=null, [OrdKey]=null
		from	[ObjInfoTbl$] oi (readuncommitted)
				join [CmObject] co (readuncommitted) on oi.[ObjId] = co.[Id] 
		where	oi.[uid]=@uid

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetObjInOwnershipPathWithId$: SQL Error %d; Unable to update the initial object(s) (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	
	end

	select	@iCurObjId=min(ObjId)
	from	ObjInfoTbl$ (REPEATABLEREAD)
	where	uid=@uid

	while @iCurObjId is not null begin
		set @iPrevObjId = @iCurObjId

		-- loop up (objects that own the specified objects) through the ownership hierarchy until the specified type (class=riid) of 
		-- 	owning object is found or the top of the ownership hierarchy is reached
		set @iOwnerClass = 0
		while @iOwnerClass <> @riid begin
			select top 1
				@iOwner = co.[Owner$],
				@iOwnerClass = f.[Class]
			from	[CmObject] co (readuncommitted)
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	co.[id] = @iCurObjId

			if @@rowcount > 0 set @iCurObjId = @iOwner
			else begin
				set @iCurObjId = null
				break
			end
		end

		if @iCurObjId is not null
		begin
			-- update the ObjInfoTbl$ so that specified object(s) is/are related to the specified type of
			--    object (class=riid) that owns it
			update	[ObjInfoTbl$] with (rowlock)
			set	[RelObjId]=@iOwner,
				[RelObjClass]=(
					select co.[Class$]
					from [CmObject] co (readuncommitted)
					where co.[id]=@iOwner)
			where	[uid]=@uid 
				and [ObjId]=@iPrevObjId

			set @Err = @@error
			if @Err <> 0 begin
				set @sUid = convert(nvarchar(50), @Uid)
				raiserror ('GetObjInOwnershipPathWithId$: SQL Error %d; Unable to update object relationship information (UID=%s).', 16, 1, @Err, @sUid)
				goto LFail
			end	
		end

		-- if the user specified an object there was only one object to process and we can therefore
		--    break out of the loop
		if @objId is not null break

		select	@iCurObjId=min(ObjId)
		from	[ObjInfoTbl$] (REPEATABLEREAD)
		where	[uid]=@uid 
			and [ObjId] > @iPrevObjId
	end

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


/***********************************************************************************************
 * GetIncomingRefs$
 *
 * Description: 
 *	retrieves objects that have external references to the specified object(s) or any 
 *	object(s) it/they own(s)
 *
 * Parameters:  
 *	@uid=a unique Id that identifies this call's results set; 
 *	@ObjId=Id of the object;
 *	@fRecurse=flag that determines if the owning tree is traversed;
 *	@fDelOwnTree=flat that determines if the temporary owning tree produced in the 
 *		ObjInfoTbl$ is removed
 *
 * Returns: 
 *	0 if successful, otherwise an error code
 *
 * Notes: 
 *	If @ObjId is not specified this procedure works on all of the rows in the ObjInfTbl$ 
 *	where uid=@uid
 *
 * TODO: (JonathanR) - this function should eventually be a wrapper around an appropriate call 
 *		to GetLinkedObjects$
 **********************************************************************************************/
if object_id('GetIncomingRefs$') is not null begin
	print 'removing proc GetIncomingRefs$'
	drop proc [GetIncomingRefs$]
end
go
print 'creating proc GetIncomingRefs$'
go

create proc [GetIncomingRefs$]
	@uid uniqueidentifier output,
	@ObjId int=null,
	@fRecurse tinyint=1,
	@fDelOwnTree tinyint=1
as
	declare @Err int

	exec @Err = GetLinkedObjects$ @uid output, @ObjId, kgrfcptAll, 1, 0, @fRecurse, -1, null, 0
	return @Err
go

/*****************************************************************************
 * IsValidObject$
 *
 * Description: Determines whether the given class is the actual type or a
 * base class type of the given object id.
 *
 * Parameters:
 *	@idOfObjectToCheck	HVO of object to check
 *	@class 			Class ID
 *	@fValid  out		Set to 0 if object does not exist or is not
 *				the type (or subtype) of the given class
 *
 * Returns: nothing
 *
 *****************************************************************************/

if object_id('IsValidObject$') is not null begin
	print 'removing proc IsValidObject$'
	drop proc [IsValidObject$]
end
go
print 'creating proc IsValidObject$'
go

create proc IsValidObject$
	@idOfObjectToCheck int,
	@class int,
	@fValid int out
as
	DECLARE @actualClass int

	select @actualClass = class$ from CmObject (readuncommitted) where id = @idOfObjectToCheck
	if @class = @actualclass
		set @fValid = 1
	else
		exec ClassIsDerivedFrom$ @actualClass, @class, @fValid out
GO

/*****************************************************************************
 * ClassIsDerivedFrom$
 *
 * Description: Determines whether the class passed as the @class is really
 * a subclass of the given base class.
 *
 * Parameters:
 *	@class		Class ID of class which is purportedly a subclass of
 *			@baseClass
 *	@baseClass 	Class ID of class which is purportedly a base class of
 *			@class
 *	@fValid  out	Set to 0 if @class is not a valid class ID or if it is
 *			not a subclass of the given base class
 *
 * Returns: nothing
 *
 *****************************************************************************/
if object_id('ClassIsDerivedFrom$') is not null begin
	print 'removing proc ClassIsDerivedFrom$'
	drop proc [ClassIsDerivedFrom$]
end
go
print 'creating proc ClassIsDerivedFrom$'
go

create proc ClassIsDerivedFrom$
	@class int,
	@baseClass int,
	@fValid int out
as
	DECLARE @actualBase int
	select @actualBase = Base from class$ where id = @class
	if @actualBase = @baseClass
		set @fValid = 1
	else begin
		if @actualBase > 0
			exec ClassIsderivedFrom$ @actualBase, @baseClass, @fValid out
		else
			set @fValid = 0
	end
GO

/***********************************************************************************************
 * Procedure: GetUndoDelObjInfo
 *
 * Description
 *  retrieves the information needed to undo deleting an object or set of objects
 *
 * Parameters:
 *	@ObjId=the object for which all linked objects will be gathered;
 * 	@hXMLDocObjList=handle to a parsed XML document that contains multiple object Ids - the
 *		undo information will be produced for each of these objectIds;
 *
 * 	Objects should be specified using either the @ObjId parameter or through an XML 
 *	document (the @hXMLDocObjList parameter is a handle to a parsed XML document) but not
 *	both. The XML document should be in the format:
 *		<root>
 *			<ObjId="1"/>
 *			<ObjId="2"/>
 *		</root>
 *
 * Assumptions:
 *	This procedure assumes that the calling application/procedure has created the 
 *	temporary table #UndoDelObjInfo with the following structure:
 *
 *	CREATE TABLE #UndoDelObjInfo
 *	(
 *		Type INT,					-- type of the property (negated for incoming refs)
 *		ObjId INT,					-- object id
 *		Flid INT,					-- field id of the property
 *		IntVal INT,					-- value: Boolean, Integer, GenDate, Atomic Ref, Ws of
 *										multilingual unicode/string, Src of incoming
 *		TimeVal DATETIME,			-- value: Time
 *		GuidVal UNIQUEIDENTIFIER,	-- value: Guid
 *		ImageVal IMAGE,				-- value: Image, or Fmt of formatted big string
 *		TextVal NTEXT,				-- value: big Unicode, or Txt of formatted big string
 *		Ord INT						-- value: ord of Ref sequence, either outgoing or incoming
 *	)
 *
 * Example:
 *	This is an example of how to get the undo information for deleting the object with id 6111
 *
 *	CREATE TABLE #UndoDelObjInfo
 *	(
 *		Type INT,
 *		ObjId INT,
 *		Flid INT,
 *		IntVal INT,
 *		TimeVal DATETIME,
 *		GuidVal UNIQUEIDENTIFIER,
 *		ImageVal IMAGE,
 *		TextVal NTEXT,
 *		Ord INT
 *	)
 *	exec GetUndoDelObjInfo 6111
 *	select * from #UndoDelObjInfo ORDER BY Type, ObjId, Flid, Ord
 *	drop table #UndoDelObjInfo
 *
 **********************************************************************************************/
IF OBJECT_ID('GetUndoDelObjInfo') is not null BEGIN
	PRINT 'removing proc GetUndoDelObjInfo'
	DROP PROC GetUndoDelObjInfo
END
GO
PRINT 'creating proc GetUndoDelObjInfo'
GO

CREATE PROC GetUndoDelObjInfo
	@ObjId int=null,
	@hXMLDocObjList int=null
AS
	-- make sure that nocount is turned on
	DECLARE @fIsNocountOn INT
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON

	CREATE TABLE  #ObjInfoForDelete (
		ObjId			INT NOT NULL,
		ObjClass		INT NULL,
		InheritDepth	INT NULL DEFAULT(0),
		OwnerDepth		INT NULL DEFAULT(0),
		Owner			INT NULL,
		OwnerClass		INT NULL,
		OwnFlid			INT NULL,
		OwnOrd			INT NULL,
		OwnPropType		INT NULL,
		OrdKey			VARBINARY(250) NULL DEFAULT(0))
	CREATE NONCLUSTERED INDEX #Ind_ObjInfo_ObjId ON dbo.#ObjInfoForDelete (ObjId)

	INSERT INTO #ObjInfoForDelete
	SELECT * FROM dbo.fnGetOwnedObjects$(
		@ObjId,			-- single objeect id
		@hXMLDocObjList,-- xml list of object ids
		null,			-- we want all owning prop types
		1,				-- we want base class records
		0,				-- but not subclasses
		1,				-- we want recursion (all owned, not just direct)
		null,			-- we want objects of any class
		0)				-- we don't need an 'order key'

	DECLARE @PropType INT
	SET @PropType = 1
	DECLARE @ClassName NVARCHAR(100)
	DECLARE @FieldName NVARCHAR(100)
	DECLARE @Flid INT

	DECLARE @props TABLE(type INT, flid INT)
	INSERT INTO @props
	SELECT DISTINCT f.type, f.id
	FROM Field$ f
	JOIN #ObjInfoForDelete oo ON oo.ObjClass = f.class

	DECLARE @sQry NVARCHAR(4000)
	DECLARE @sPropType NVARCHAR(20)
	DECLARE @sFlid NVARCHAR(20)

	SELECT TOP 1 @flid = flid, @PropType = type FROM @props ORDER BY flid
	WHILE @@rowcount > 0
	BEGIN
		SELECT @FieldName = f.Name, @Flid = f.Id, @ClassName = c.Name
		FROM Field$ f
		JOIN Class$ c ON c.Id = f.Class
		WHERE f.Type = @PropType AND f.Id = @Flid
		SET @sPropType = CONVERT(NVARCHAR(20), @PropType)
		SET @sFlid = CONVERT(NVARCHAR(20), @Flid)

		SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Id,' + @sFlid + ', '
		IF @PropType in (1,2,8,24) BEGIN	-- Boolean, Integer, GenDate, RefAtomic
			SET @sQry = @sQry + 
				'[' + @FieldName + '], null, null, null, null, null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		-- 3 (Numeric) and 4 (Float) are never used (as of January 2005)
		ELSE IF @PropType = 5 BEGIN		-- Time
			SET @sQry = @sQry +
				'null, [' + @FieldName + '], null, null, null, null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		ELSE IF @PropType = 6 BEGIN		-- Guid
			SET @sQry = @sQry +
				'null, null, [' + @FieldName + '], null, null, null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		ELSE IF @PropType in (7,9) BEGIN	-- Image, Binary
			SET @sQry = @sQry +
				'null, null, null, [' + @FieldName + '], null, null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		-- 10,11,12 are unassigned values (as of January 2005)
		ELSE IF @PropType in (13,17) BEGIN		-- String, BigString
			SET @sQry = @sQry + 'null, null, null, ' +
				@FieldName + '_Fmt, [' + @FieldName + '], null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		ELSE IF @PropType in (14,18) BEGIN		-- MultiString, MultiBigString
			SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Obj,' + @sFlid +
				', Ws, null, null, Fmt, Txt, null ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Obj in (select ObjId from #ObjInfoForDelete) and Txt is not null'
		END
		ELSE IF @PropType in (15,19) BEGIN		-- Unicode, BigUnicode
			SET @sQry = @sQry +
				'null, null, null, null, [' + @FieldName + '], null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		ELSE IF @PropType in (16,20) BEGIN		-- MultiUnicode, MultiBigUnicode
			-- (MultiBigUnicode is unused as of January 2005)
			SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Obj,' + @sFlid +
				', Ws, null, null, null, Txt, null ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Obj in (select ObjId from #ObjInfoForDelete) and Txt is not null'
		END
		-- 21,22 are unassigned (as of January 2005)
		-- 23,25,27 are Owning Properties, which are handled differently from Value/Reference
		--          Properties
		ELSE IF @PropType = 26 BEGIN		-- RefCollection
			SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Src,' + @sFlid +
				', Dst, null, null, null, null, null ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Src in (select ObjId from #ObjInfoForDelete)'
		END
		ELSE IF @PropType = 28 BEGIN		-- RefSequence
			SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Src,' + @sFlid +
				', Dst, null, null, null, null, Ord ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Src in (select ObjId from #ObjInfoForDelete) order by Ord'
		END
		ELSE BEGIN
			SET @sQry = null
		END
		IF (@sQry is not null) BEGIN
		--	PRINT @sQry
			EXEC (@sQry)
		END
		SELECT TOP 1 @flid = flid, @PropType = type FROM @props WHERE flid > @flid ORDER BY flid
	END

	-- Now do incoming references. Note that we exclude references where the SOURCE of the
	-- reference is in the deleted object collection, as those references will be reinstated
	-- by code restoring the forward ref properties.  Incoming references are marked in the
	-- table by negative values in the Type field.

	DELETE FROM @props
	INSERT INTO @props
	SELECT DISTINCT f.type, f.id
	FROM Field$ f
	JOIN #ObjInfoForDelete oo ON oo.ObjClass = f.DstCls AND f.type IN (24, 26, 28)

	SELECT TOP 1 @flid = flid, @PropType = type FROM @props ORDER BY flid
	WHILE @@rowcount > 0
	BEGIN
		SELECT @FieldName = f.Name, @Flid = f.Id, @ClassName = c.Name
		FROM Field$ f
		JOIN Class$ c ON c.Id = f.Class
		WHERE f.Type = @PropType AND f.Id = @Flid
		SET @sPropType = CONVERT(NVARCHAR(20), @PropType)
		SET @sFlid = CONVERT(NVARCHAR(20), @Flid)

		IF @PropType = 24 BEGIN				-- RefAtomic
			SET @sQry = 'insert into #UndoDelObjInfo select -' + @sPropType +
				', [' + @FieldName + '], ' + @sFlid +
				', Id, null, null, null, null, null ' +
				'from ' + @ClassName +
				' where [' + @FieldName + '] in (select ObjId from #ObjInfoForDelete)' +
				' and Id not in (select ObjId from #ObjInfoForDelete)'
		END
		ELSE IF @PropType = 26 BEGIN		-- RefCollection
			SET @sQry = 'insert into #UndoDelObjInfo select -' + @sPropType + ',Dst,' + @sFlid +
				', Src, null, null, null, null, null ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Dst in (select ObjId from #ObjInfoForDelete)' +
				' and Src not in (select ObjId from #ObjInfoForDelete)' +
				' order by Src'
		END
		ELSE IF @PropType = 28 BEGIN		-- RefSequence
			SET @sQry = 'insert into #UndoDelObjInfo select -' + @sPropType + ',Dst,' + @sFlid +
				', Src, null, null, null, null, Ord ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Dst in (select ObjId from #ObjInfoForDelete)' +
				' and Src not in (select ObjId from #ObjInfoForDelete)' +
				' order by Src, Ord'
		END
		ELSE BEGIN
			SET @sQry = null
		END
		IF (@sQry is not null) BEGIN
		--	PRINT @sQry
			EXEC (@sQry)
		END
		SELECT TOP 1 @flid = flid, @PropType = type FROM @props WHERE flid > @flid ORDER BY flid
	END

	-- if we turned on nocount, turn it off
	IF @fIsNocountOn = 0 SET NOCOUNT OFF

	RETURN @@error
GO

/***********************************************************************************************
 * Function: fnGetSubObjects$
 *
 * Description: 
 *	returns a table of all owned sub-objects related to a specified owning field
 *
 * Parameters:
 * 	@hXMLDocObjList=handle to a parsed XML document that contains multiple object Ids - the
 *		ownership chain will be produced for each of these objectIds;
 *	@ObjId=Id of the owning object object
 *	@Flid=the Field ID of the field that contains the owning relationship
 *
 * Returns: 
 *	Table containing the object information in the format:
 *		[ObjId]		int,
 *		[ObjClass]	int,
 *		[InheritDepth]	int,
 *		[OwnerDepth]	int,
 *		[RelObjId]	int,
 *		[RelObjClass]	int,
 *		[RelObjField]	int,
 *		[RelOrder]	int,
 *		[RelType]	int,
 *		[OrdKey]	varbinary(250)
 *
 * Notes:
 *	This procedure is intended for recursive relationships, e.g. sub events
 **********************************************************************************************/
if object_id('fnGetSubObjects$') is not null begin
	print 'removing function GetSubObjects$'
	drop function [fnGetSubObjects$]
end
go
print 'Creating function fnGetSubObjects$'
go
create function [fnGetSubObjects$] (
	@ObjId int=null,
	@hXMLDocObjList int=null,
	@Flid int )
returns @ObjInfo table (
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
as
begin
	declare @nRowCnt int, @nOwnerDepth int

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 

		-- get the class of the specified object
		insert into @ObjInfo (ObjId, ObjClass)
		select	@objId, co.[Class$]
		from	[CmObject] co (readuncommitted)
		where	co.[Id] = @objId
		if @@error <> 0 goto LFail
	end
	else begin

		-- parse the XML list of Object IDs and insert them into the table variable
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	i.[Id], co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	openxml (@hXMLDocObjList, '/root/Obj') with ([Id] int) i
			join [CmObject] co (readuncommitted) on co.[Id] = i.[Id]
		if @@error <> 0 goto LFail
	end

	-- loop through the ownership hiearchy for all sub-objects based on the specified flid (field ID)
	set @nRowCnt = 1
	set @nOwnerDepth = 1
	while @nRowCnt > 0 begin	
		insert into @ObjInfo
			(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
		select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], null, co.[OwnFlid$], co.[OwnOrd$], 25
		from 	[CmObject] co (readuncommitted)
		where 	co.[OwnFlid$] = @flid
			and exists (
				select 	*
				from 	@ObjInfo oi
				where 	oi.[ObjId] = co.[Owner$]
					and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
		set @nRowCnt = @@rowcount
		set @nOwnerDepth = @nOwnerDepth + 1
	end

	return	
LFail:
	delete @ObjInfo
	return
end
go


/***********************************************************************************************
 * GetSubObjects$
 *
 * Description: 
 *	retrievs all owned sub-objects related to a specified owning field - this is intended 
 *	for recursive relationships, i.e. sub events
 *
 * Parameters:
 *	@uid=a unique Id that identifies this call's results set within the ObjInfoTbl$ table; 
 *	@ObjId=Id of the owning object object
 *	@Flid=the Field ID of the field that contains the owning relationship
 *
 * Notes: 
 *	If @ObjId is not specified this procedure works on all of the rows in the ObjInfTbl$ 
 *	where uid=@uid
 **********************************************************************************************/
if object_id('GetSubObjects$') is not null begin
	print 'removing proc GetSubObjects$'
	drop proc [GetSubObjects$]
end
go
print 'Creating proc GetSubObjects$'
go
create proc [GetSubObjects$]
	@uid uniqueidentifier output,
	@ObjId int=NULL,
	@Flid int
as
	declare @Err int, @nRowCnt int, @nOwnerDepth int
	declare	@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 
		-- get a unique value to identify this invocation's results
		set @uid = newid()

		-- get the class of the specified object
		insert into [ObjInfoTbl$] with (rowlock) (uid, ObjId, ObjClass)
		select	@uid, @objId, co.[Class$]
		from	[CmObject] co (readuncommitted)
		where	co.[Id] = @objId
		set @Err = @@error
		if @Err <> 0 goto Finish
	end
	else begin
		update	[ObjInfoTbl$] with (rowlock)
		set	[ObjClass]=co.[Class$], [OwnerDepth]=0, [InheritDepth]=0
		from	[ObjInfoTbl$] oi (readuncommitted)
				join [CmObject] co (readuncommitted) on oi.[ObjId] = co.[Id]
					and oi.[uid]=@uid
		set @Err = @@error
		if @Err <> 0 goto Finish
	end

	-- loop through the ownership hiearchy for all sub-objects based on the specified flid (field ID)
	set @nRowCnt = 1
	set @nOwnerDepth = 1
	while @nRowCnt > 0 begin	
		insert into [ObjInfoTbl$] with (rowlock)
			(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
		select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], null, co.[OwnFlid$], co.[OwnOrd$], 25
		from 	[CmObject] co (readuncommitted)
		where 	co.[OwnFlid$] = @flid
			and exists (
				select 	*
				from 	[ObjInfoTbl$] oi (readuncommitted)
				where 	oi.[ObjId] = co.[Owner$]
					and oi.[Uid] = @uid
					and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
		select @nRowCnt=@@rowcount, @Err=@@error

		if @Err <> 0 goto Finish
		set @nOwnerDepth = @nOwnerDepth + 1
	end
	
Finish:
	-- reestablish the initial setting of nocount
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


/***********************************************************************************************
 * GetIncomingRefsPrepDel$
 *
 * Description: 
 *	retrieves any incoming external references to the specified object(s) along with
 *	maintaining information that is beneficial for later deleting the specified object(s); 
 *	see the procedure DeletePrepDelObjects$
 *
 * Parameters: 
 *	@uid=a unique Id that identifies this call's results set within the ObjInfoTbl$ table; 
 *	@ObjId=Id of the object
 *
 * Returns: 
 *	0 if successful, otherwise an error code
 **********************************************************************************************/
if object_id('GetIncomingRefsPrepDel$') is not null begin
	print 'removing proc GetIncomingRefsPrepDel$'
	drop proc [GetIncomingRefsPrepDel$]
end
go
print 'creating proc GetIncomingRefsPrepDel$'
go
create proc [GetIncomingRefsPrepDel$]
	@uid uniqueidentifier output,
	@ObjId int=NULL
as
	declare @Err int, @sUid nvarchar(50)

	-- get incoming references, but do not delete the ownership tree
	exec @Err=GetIncomingRefs$ @uid output, @ObjId, 1, 0
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('GetIncomingRefsPrepDel$: SQL Error %d; Unable to get incoming references (UID=%s).', 16, 1, @Err, @sUid)
	end

	return @Err
go


/***********************************************************************************************
 * Function: fnGetLastModified$
 *
 * Description: 
 *	retrieves the latest modification date and time of the specified object and objets owned 
 *	by the specified object
 *
 * Parameters:
 *	@ObjId=the object Id
 *
 * Returns: 
 *	The date and time of the last modification
 **********************************************************************************************/
if object_id('fnGetLastModified$') is not null begin
	print 'removing function fnGetLastModified$'
	drop function [fnGetLastModified$]
end
go
print 'creating function fnGetLastModified$'
go
create function [fnGetLastModified$] (@ObjId int)
returns smalldatetime
as
begin
	declare @dttmLastUpdate smalldatetime

	-- get all objects owned by the specified object
	select	@dttmLastUpdate = max(co.[UpdDttm])
	from	fnGetOwnershipPath$ (@Objid, null, 1, 1, 0) oi
			join [CmObject] co (readuncommitted) on oi.[ObjId] = co.[Id]

	return @dttmLastUpdate
end
go


/***********************************************************************************************
 * GetPossibilities
 *
 * Description: 
 *	retrieves the possibilities and their abbreviations of a specified possibility list
 *
 * Parameters: 
 *	@ObjId=the object Id of the possibility list;
 *	@Ws=the writing system
 *
 * Returns: 
 *	0 if successful, otherwise an error code (not currently being used)
 **********************************************************************************************/
if object_id('GetPossibilities') is not null begin
	print 'removing proc GetPossibilities'
	drop proc [GetPossibilities]
end
go
print 'creating proc GetPossibilities'
go
create proc [GetPossibilities]
	@ObjId int,
	@Ws int
as
	declare @uid uniqueidentifier, 
	        @retval int

	-- get all of the possibilities owned by the specified possibility list object
	declare @tblObjInfo table (
		[ObjId]		int		not null,
		[ObjClass]	int		null,
		[InheritDepth]	int		null	default(0),
		[OwnerDepth]	int		null	default(0),
		[RelObjId]	int		null,
		[RelObjClass]	int		null,
		[RelObjField]	int		null,
		[RelOrder]	int		null,
		[RelType]	int		null,
		[OrdKey]	varbinary(250)	null	default(0))

	insert into @tblObjInfo
		select * from fnGetOwnedObjects$(@ObjId, null, 176160768, 0, 0, 1, 7, 1)
	
	-- First return a count so that the caller can preallocate memory for the results.
	select count(*) from @tblObjInfo
	
	--
	--  get an ordered list of relevant writing system codes
	--
	declare @tblWs table (
		[WsId]	int not null, -- don't make unique. It shouldn't happen, but we don't want a crash if it does.
		[Ord]	int primary key clustered identity(1,1))
	--( 0xffffffff (-1) or 0xfffffffd (-3) = First string from a) ordered checked analysis 
	-- writing systems b) any remaining analysis writing systems or stars if none of the above.
	if @Ws = kwsAnal or @Ws = kwsAnals begin
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentAnalysisWritingSystems caws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on caws.dst = lws.id
			order by caws.Ord
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_AnalysisWritingSystems caws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on caws.dst = lws.id and lws.id not in (select WsId from @tblWs)
	end
	--( 0xfffffffe (-2) or 0xfffffffc (-4) = First string from a) ordered checked vernacular 
	-- writing systems b) any remaining vernacular writing systems or stars if none of the above.
	else if @Ws = kwsVern or @Ws = kwsVerns begin
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentVernacularWritingSystems cvws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on cvws.dst = lws.id
			order by cvws.Ord
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_VernacularWritingSystems cvws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on cvws.dst = lws.id and lws.id not in (select WsId from @tblWs)
	end
	--( 0xfffffffb = -5 = First string from a) ordered checked analysis writing systems 
	-- b) ordered checked vernacular writing systems, c) any remaining analysis writing systems,
	-- d) any remaining vernacular writing systems or stars if none of the above.
	else if @Ws = kwsAnalVerns begin
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentAnalysisWritingSystems caws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on caws.dst = lws.id
			order by caws.Ord
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentVernacularWritingSystems cvws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on cvws.dst = lws.id
			where lws.id not in (select WsId from @tblWs)
			order by cvws.Ord
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_AnalysisWritingSystems caws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on caws.dst = lws.id and lws.id not in (select WsId from @tblWs)
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_VernacularWritingSystems cvws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on cvws.dst = lws.id and lws.id not in (select WsId from @tblWs)
	end
	--( 0xfffffffa = -6 = First string from a) ordered checked vernacular writing systems 
	-- b) ordered checked analysis writing systems, c) any remaining vernacular writing systems, 
	-- d) any remaining analysis writing systems or stars if none of the above.
	else if @Ws = kwsVernAnals begin
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentVernacularWritingSystems cvws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on cvws.dst = lws.id
			order by cvws.Ord
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentAnalysisWritingSystems caws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on caws.dst = lws.id
			where lws.id not in (select WsId from @tblWs)
			order by caws.Ord
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_VernacularWritingSystems cvws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on cvws.dst = lws.id and lws.id not in (select WsId from @tblWs)
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_AnalysisWritingSystems caws (readuncommitted)
			join LgWritingSystem lws (readuncommitted) on caws.dst = lws.id and lws.id not in (select WsId from @tblWs)
	end
	else -- Hard coded value
		insert into @tblWs (WsId) Values(@Ws)

	-- Now that we have the desired writing systems in @tblWs, we can return the desired information.
	select
		o.ObjId,
		(select top 1 isnull(ca.[txt], '***') + ' - ' + isnull(cn.[txt], '***')
			from LgWritingSystem lws (readuncommitted)
			left outer join CmPossibility_Name cn (readuncommitted) on cn.[ws] = lws.[Id] and cn.[Obj] = o.[objId]
			left outer join CmPossibility_Abbreviation ca (readuncommitted) on ca.[ws] = lws.[Id] and ca.[Obj] = o.[objId]
			join @tblWs wstbl on wstbl.WsId = lws.id
			order by (
				select [Ord] = CASE 
					WHEN cn.[txt] IS NOT NULL THEN wstbl.[ord]
					WHEN ca.[txt] IS NOT NULL THEN wstbl.[ord] + 9000
					ELSE wstbl.[Ord] + 99000
					END)),
		isnull((select top 1 lws.id
			from LgWritingSystem lws (readuncommitted)
			left outer join CmPossibility_Name cn (readuncommitted) on cn.[ws] = lws.[Id] and cn.[Obj] = o.[objId]
			left outer join CmPossibility_Abbreviation ca (readuncommitted) on ca.[ws] = lws.[Id] and ca.[Obj] = o.[objId]
			join @tblWs wstbl on wstbl.WsId = lws.id
			order by (
				select [Ord] = CASE 
					WHEN cn.[txt] IS NOT NULL THEN wstbl.[ord]
					WHEN ca.[txt] IS NOT NULL THEN wstbl.[ord] + 9000
					ELSE wstbl.[Ord] + 99000
					END)
			), (select top 1 WsId from @tblws)),
		o.OrdKey, cp.ForeColor, cp.BackColor, cp.UnderColor, cp.UnderStyle
	from @tblObjInfo o
		left outer join CmPossibility cp (readuncommitted) on cp.[id] = o.[objId]
	order by o.OrdKey

	return @retval
go

-----------------------------------------------------------------------------------------
-- Description: retrieves the possibilities and their abbreviations of a specified possibility list
--    that have a specific keyword in their names
-- Parameters: 
--    @ObjId=the object Id of the possibility list;
--    @Ws=the writing system;
--    @sKeyword=the keyword to search for
-- Returns: 0 if successful, otherwise an error code

-- ***** TODO: This is not correct. It doesn't handle kwsVernAnals & kwsAnalVerns, and might possibly
-- have other problems that we solved in GetPossibilities. However, this whole procedure will
-- need to be updated before release to do proper matching based on proper Unicode algorithms,
-- so we aren't fixing this at this tiem.

if object_id('GetPossKeyword') is not null begin
	print 'removing proc GetPossKeyword'
	drop proc [GetPossKeyword]
end
go
print 'creating proc GetPossKeyword'
go

create proc [GetPossKeyword]
	@ObjId int,
	@Ws int,
	@sKeyword nvarchar(250)
as
	declare @retval int

	-- get all of the possibilities owned by the specified possibility list object
	
	declare @tblObjInfo table (
		[ObjId]	int not null,
		[ObjClass] int null,
		[InheritDepth] int null default(0),
		[OwnerDepth] int null default(0),
		[RelObjId] int null,
		[RelObjClass] int null,
		[RelObjField] int null,
		[RelOrder] int null,
		[RelType] int null,
		[OrdKey] varbinary(250)	null default(0))


	insert into @tblObjInfo
		select * from fnGetOwnedObjects$(@ObjId, null, kgrfcptOwning, 1, 0, 1, null, 1)
	
	-- Fudge this for now so it doesn't crash.
	if @Ws = kwsAnal or @Ws = kwsAnals or @Ws = kwsAnalVerns
		
		--( To avoid seeing stars, send a "magic" writing system of kwsAnal. 
		--( This will cause the query to return the first non-null string.
		--( Priority is givin to encodings with the highest order.
		
		select
			o.ObjId,
			isnull((select top 1 txt
				from CmPossibility_Name cn (readuncommitted)
				left outer join LgWritingSystem le (readuncommitted) on le.[Id] = cn.[ws]
				left outer join LanguageProject_AnalysisWritingSystems lpaws (readuncommitted) on lpaws.[dst] = le.[id]
				left outer join LanguageProject_CurrentAnalysisWritingSystems lpcaws (readuncommitted) on lpcaws.[dst] = lpaws.[dst]
				where cn.[Obj] = o.[objId] and cn.[Txt] like '%' + @sKeyword + '%'
				order by isnull(lpcaws.[ord], 99999)), '***'),
			isnull((select top 1 txt
				from CmPossibility_Abbreviation ca (readuncommitted)
				left outer join LgWritingSystem le (readuncommitted) on le.[Id] = ca.[ws]
				left outer join LanguageProject_AnalysisWritingSystems lpaws (readuncommitted) on lpaws.[dst] = le.[id]
				left outer join LanguageProject_CurrentAnalysisWritingSystems lpcaws (readuncommitted) on lpcaws.[dst] = lpaws.[dst]
				where ca.[Obj] = o.[objId]
				order by isnull(lpcaws.[ord], 99999)), '***'),
			o.OrdKey
		from @tblObjInfo o
		where o.[ObjClass] = 7  -- CmPossibility
		order by o.OrdKey
		
	else if @Ws = kwsVern or @Ws = kwsVerns or @Ws = kwsVernAnals
		
		--( To avoid seeing stars, send a "magic" writing system of kwsVern. 
		--( This will cause the query to return the first non-null string.
		--( Priority is givin to encodings with the highest order.
		
		select
			o.ObjId,
			isnull((select top 1 txt
				from CmPossibility_Name cn (readuncommitted)
				left outer join LgWritingSystem le (readuncommitted) on le.[Id] = cn.[ws]
				left outer join LanguageProject_VernacularWritingSystems lpvws (readuncommitted) on lpvws.[dst] = le.[id]
				left outer join LanguageProject_CurrentVernacularWritingSystems lpcvws (readuncommitted) on lpcvws.[dst] = lpvws.[dst]
				where cn.[Obj] = o.[objId] and cn.[Txt] like '%' + @sKeyword + '%'
				order by isnull(lpcvws.[ord], 99999)), '***'),
			isnull((select top 1 txt
				from CmPossibility_Abbreviation ca (readuncommitted)
				left outer join LgWritingSystem le (readuncommitted) on le.[Id] = ca.[ws]
				left outer join LanguageProject_VernacularWritingSystems lpvws (readuncommitted) on lpvws.[dst] = le.[id]
				left outer join LanguageProject_CurrentVernacularWritingSystems lpcvws (readuncommitted) on lpcvws.[dst] = lpvws.[dst]
				where ca.[Obj] = o.[objId]
				order by isnull(lpcvws.[ord], 99999)), '***'),
			o.OrdKey
		from @tblObjInfo o
		where o.[ObjClass] = 7  -- CmPossibility
		order by o.OrdKey
		
	else
		select	o.ObjId, isnull(cn.txt, '***'), isnull(ca.txt, '***'), o.OrdKey
			from @tblObjInfo o
				left outer join [CmPossibility_Name] cn (readuncommitted)
					on cn.[Obj] = o.[ObjId] and cn.[Ws] = @Ws
				left outer join [CmPossibility_Abbreviation] ca (readuncommitted)
					on ca.[Obj] = o.[ObjId] and ca.[Ws] = @Ws
			where o.[ObjClass] = 7  -- CmPossibility
				and cn.[Txt] like '%' + @sKeyword + '%'
			order by o.OrdKey

	return @retval
go


/***********************************************************************************************
 * GetTagInfo$
 *
 * Description:
 *   Gets info about overlay tags, using encodings by priority
 *   
 * Parameters:
 *   @iOwnerId - The ID of the owner
 *   @iWritingSystem - See notes below
 * 
 * Notes:
 *   The @iWritingSystem parameter supports a "magic" value. If kwsAnal, the query will
 *   return the first non-null string, giving priority to the first Analysis Writing system 
 *   with the highest Order. Likewise, if @iWritingSystem is kwsVern, the query will
 *   return the first non-null string, giving priority to the first Vernacular Writing system 
 *
 * Example:
 *	exec GetTagInfo$ 2573, kwsAnal
 *
***********************************************************************************************/
if object_id('GetTagInfo$') is not null begin
	print 'removing procedure GetTagInfo$'
	drop proc [GetTagInfo$]
end
go
print 'creating proc GetTagInfo$'
go

create proc GetTagInfo$
	@iOwnerId int,
	@iWritingSystem int
as
	
	declare @fIsNocountOn int
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- TODO (SteveM) This needs to be fixed to handle kwsAnalVerns and kwsVernAnals properly.
	--( if "magic" writing system is for analysis encodings
	if @iWritingSystem = kwsAnal or @iWritingSystem = kwsAnals or @iWritingSystem = kwsAnalVerns
		select 
			[co].[Guid$],
			[opi].[Dst],
			isnull((select top 1 [ca].[txt]
				from CmPossibility_Abbreviation ca (readuncommitted)
				left outer join LgWritingSystem le (readuncommitted)
					on le.[Id] = ca.[ws]
				left outer join LanguageProject_AnalysisWritingSystems lpaws (readuncommitted)
					on lpaws.[dst] = le.[id]
				left outer join LanguageProject_CurrentAnalysisWritingSystems lpcaws (readuncommitted)
					on lpcaws.[dst] = lpaws.[dst]
				where ca.[Obj] = [opi].[Dst]
				order by isnull(lpcaws.[ord], 99999)), '***'),
			isnull((select top 1 [cn].[txt]
				from CmPossibility_Name cn (readuncommitted)
				left outer join LgWritingSystem le (readuncommitted)
					on le.[Id] = cn.[ws]
				left outer join LanguageProject_AnalysisWritingSystems lpaws (readuncommitted)
					on lpaws.[dst] = le.[id]
				left outer join LanguageProject_CurrentAnalysisWritingSystems lpcaws (readuncommitted)
					on lpcaws.[dst] = lpaws.[dst]
				where cn.[Obj] = [opi].[Dst]
				order by isnull(lpcaws.[ord], 99999)), '***'),
			[cp].[ForeColor],
			[cp].[BackColor],
			[cp].[UnderColor],
			[cp].[UnderStyle],
			[cp].[Hidden]
		from CmOverlay_PossItems [opi] (readuncommitted)
			join CmPossibility [cp] (readuncommitted) on [cp].[id] = [opi].[Dst]
			join CmObject [co] (readuncommitted) on [co].[id] = [cp].[id]
		where [opi].[Src] = @iOwnerId
		order by [opi].[Dst]
	
	--( if "magic" writing system is for vernacular encodings
	else if @iWritingSystem = kwsVern or @iWritingSystem = kwsVerns or @iWritingSystem = kwsVernAnals
		select 
			[co].[Guid$],
			[opi].[Dst],
			isnull((select top 1 txt
				from CmPossibility_Abbreviation ca (readuncommitted)
				left outer join LgWritingSystem le (readuncommitted)
					on le.[Id] = ca.[ws]
				left outer join LanguageProject_VernacularWritingSystems lpvws (readuncommitted)
					on lpvws.[dst] = le.[id]
				left outer join LanguageProject_CurrentVernacularWritingSystems lpcvws (readuncommitted)
					on lpcvws.[dst] = lpvws.[dst]
				where ca.[Obj] = [opi].[Dst]
				order by isnull(lpcvws.[ord], 99999)), '***'),
			isnull((select top 1 txt
				from CmPossibility_Name cn (readuncommitted)
				left outer join LgWritingSystem le (readuncommitted)
					on le.[Id] = cn.[ws]
				left outer join LanguageProject_VernacularWritingSystems lpvws (readuncommitted)
					on lpvws.[dst] = le.[id]
				left outer join LanguageProject_CurrentVernacularWritingSystems lpcvws (readuncommitted)
					on lpcvws.[dst] = lpvws.[dst]
				where cn.[Obj] = [opi].[Dst]
				order by isnull(lpcvws.[ord], 99999)), '***'),
			[cp].[ForeColor],
			[cp].[BackColor],
			[cp].[UnderColor],
			[cp].[UnderStyle],
			[cp].[Hidden]
		from CmOverlay_PossItems [opi] (readuncommitted)
			join CmPossibility [cp] (readuncommitted) on [cp].[id] = [opi].[Dst]
			join CmObject [co] (readuncommitted) on [co].[id] = [cp].[id]
		where [opi].[Src] = @iOwnerId
		order by [opi].[Dst]

	--( if one particular writing system is wanted
	else
		select 
			[co].[Guid$],
			[opi].[Dst],
			isnull([ca].[txt], '***'),
			isnull([cn].[txt], '***'),
			[cp].[ForeColor],
			[cp].[BackColor],
			[cp].[UnderColor],
			[cp].[UnderStyle],
			[cp].[Hidden]
		from CmOverlay_PossItems [opi] (readuncommitted)
			join CmPossibility [cp] (readuncommitted) on [cp].[id] = [opi].[Dst]
			join CmObject [co] (readuncommitted) on [co].[id] = [cp].[id]
			left outer join CmPossibility_Abbreviation [ca] (readuncommitted)
				on [ca].[Obj] = [opi].[Dst] and [ca].[ws] = @iWritingSystem
			left outer join CmPossibility_Name cn (readuncommitted)
				on [cn].[Obj] = [opi].[Dst] and [cn].[ws] = @iWritingSystem
		where [opi].[Src] = @iOwnerId
		order by [opi].[Dst]
		
	--( if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

LFail: 
	--( if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

go

/***********************************************************************************************
	Object creation and copy stored procedures.
***********************************************************************************************/


/***********************************************************************************************
 * Function: fnGetColumnDef$
 *
 * Description:
 *	Returns a SQL Server column datatype definition based on the FieldWorks datatype	
 *
 * Parameters:
 *	@sFieldType=the FieldWorks datatype value
 *
 * Returns:
 *	nvarchar(1000) string containing the SQL Server column definition
 **********************************************************************************************/
if object_id('[fnGetColumnDef$]') is not null begin
	print 'removing function fnGetColumnDef$'
	drop function [fnGetColumnDef$]
end
go
print 'creating function fnGetColumnDef$'
go
create function [fnGetColumnDef$] (@nFieldType int)
returns nvarchar(1000)
as
begin
	return case @nFieldType
			when 1 then N'bit = 0'					-- Boolean
			when 2 then N'int = 0'					-- Integer
			when 3 then N'decimal(28,4) = 0'		-- Numeric
			when 4 then N'float = 0.0'				-- Float
			when 5 then N'datetime = null'			-- Time
			when 6 then N'uniqueidentifier = null'	-- Guid
			when 7 then N'image = null'				-- Image
			when 8 then N'int = 0'					-- GenDate
			when 9 then N'varbinary(8000) = null'	-- Binary
			when 13 then N'nvarchar(4000) = null'	-- String
			when 15 then N'nvarchar(4000) = null'	-- Unicode
			when 17 then N'ntext = null'			-- BigString
			when 19 then N'ntext = null'			-- BigUnicode
		end
end
go


/***********************************************************************************************
 * DefineCreateProc$
 *
 * Description:
 *	This procedure creates the CreateObject_... procedure for a given class.
 *
 * Paramters:
 *	@clid=class Id of the class related to the new procedure
 * 
 * Returns:
 * 	0 if successful, otherwise an error
 **********************************************************************************************/

if object_id('[DefineCreateProc$]') is not null begin
	print 'removing proc DefineCreateProc$'
	drop proc [DefineCreateProc$]
end
go
print 'creating proc DefineCreateProc$'
go
create proc [DefineCreateProc$]
	@clid int
as
	declare @Err int, @fIsNocountOn int
	declare @sDynSQL1 nvarchar(4000), @sDynSQL2 nvarchar(4000), @sDynSQL3 nvarchar(4000), 
		@sDynSQL4 nvarchar(4000), @sDynSQL5 nvarchar(4000), @sDynSQLParamList nvarchar(4000),
		@sDynSQLCustomParamList NVARCHAR(4000)
	declare @sValuesList nvarchar(1000)
	declare @fAbs tinyint, @sClass sysname, @sProcName sysname
	declare @sFieldName sysname, @nFieldType int, @flid int,
		@sFieldList nvarchar(4000), @sXMLTableDef nvarchar(4000)
	declare @sInheritClassName sysname, @nInheritClid int
	DECLARE @nCustom TINYINT
	
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- validate the class
	select	@fAbs = [Abstract], 
		@sClass = [Name] 
	from	[Class$] 
	where	[Id] = @clid
	if @fAbs is null begin
		raiserror('Invalid class: clid=%d', 16, 1, @clid)
		set @Err = 50001
		goto LCleanUp
	end
	if @fAbs <> 0 begin
		raiserror('Cannot create procedure for abstract class %s', 16, 1, @sClass)
		set @Err = 50002
		goto LCleanUp
	end

	set @sProcName = N'CreateObject_' + @sClass

	-- if an old procedure exists remove it
	if exists ( 
		select	* 
		from	sysobjects 
		where	type = 'P' 
			and name = @sProcName 
		) begin 
		set @sDynSQL1 = N'drop proc '+@sProcName
		exec (@sDynSQL1)
	end

	--
	-- build the parameter list and table insert statements
	--
	
	set @sDynSQL3=N''
	set @sDynSQL4=N''
	set @sDynSQLParamList=N''
	SET @sDynSQLCustomParamList = N''

	-- create a cursor to loop through the base classes and class
	declare curClassInheritPath cursor local fast_forward for
	select	c.[Name], c.[Id]
	from	[ClassPar$] cp join [Class$] c on cp.[Dst] = c.[Id]
	where	cp.[Src] = @clid
		and cp.[Dst] > 0
	order by cp.[Depth] desc
	
	open curClassInheritPath
	fetch curClassInheritPath into @sInheritClassName, @nInheritClid

	while @@fetch_status = 0 begin

		set @sValuesList=''

		-- create a cursor to assemble the field list
		declare curFieldList cursor local fast_forward for
		select	[Name], [Type], [Id], Custom
		from	[Field$]
		where	[Class] = @nInheritClid 
			and [Name] <> 'Id'
			-- do not include MultiString type columns nor relationship, e.g. reference sequence,
			--	type columns because these are all stored in tables external to the actual 
			--	class table
			and [Type] not in (23, 24, 25, 26, 27, 28)
		--( We want to put custom fields last, so that the parameter list doesn't get
		--( reshuffled when a custom field gets added to a super or base class. That
		--( would throw off calling programs.
		order by Custom, [Id]
		
		open curFieldList
		FETCH curFieldList INTO @sFieldName, @nFieldType, @flid, @nCustom
		
		set @sFieldList = N''
		set @sXMLTableDef = N''
		while @@fetch_status = 0 begin
			if @nFieldType = 14 begin -- MultiStr$
				IF @nCustom = 0
	 				set @sDynSQLParamList = @sDynSQLParamList + char(9) +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt nvarchar(4000) = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt varbinary(8000) = null' + N', ' + char(13)
				ELSE -- IF @nCustom = 1
	 				set @sDynSQLCustomParamList = @sDynSQLCustomParamList + char(9) +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt nvarchar(4000) = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt varbinary(8000) = null' + N', ' + char(13)
					
				set @sDynSQL3 = @sDynSQL3 + char(9) +
					N'if @' + @sInheritClassName + N'_' + @sFieldName + N'_txt is not null begin' + char(13) +
					char(9) + char(9) + N'insert into [MultiStr$] with (rowlock) ([Flid],[Obj],[Ws],[Txt],[Fmt]) ' + char(13) + 
					char(9) + char(9) + N'values (' + convert(nvarchar(11), @flid)+ N',@ObjId,' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt)'
				set @sDynSQL3 = @sDynSQL3 + 
N'
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
'
			end
			else if @nFieldType = 16 begin -- MultiTxt$
				IF @nCustom = 0
	 				set @sDynSQLParamList = @sDynSQLParamList + char(9) +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt nvarchar(4000) = null' + N', ' + char(13)
				ELSE -- IF @nCustom = 1
	 				set @sDynSQLCustomParamList = @sDynSQLCustomParamList + char(9) +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt nvarchar(4000) = null' + N', ' + char(13)
				
				set @sDynSQL3 = @sDynSQL3 + char(9) +
					N'if @' + @sInheritClassName + N'_' + @sFieldName + N'_txt is not null begin' + char(13)
				SET @sDynSQL3 = @sDynSQL3 + CHAR(9) + CHAR(9) + 
					N'INSERT INTO ' + @sInheritClassName + N'_' + @sFieldName + 
					N' WITH (ROWLOCK) (Obj, Ws, Txt)' + CHAR(13) +
					char(9) + char(9) + N'values (@ObjId,' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws' + ',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt)'
				set @sDynSQL3 = @sDynSQL3 + 
N'
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
'
			end
			else if @nFieldType = 18 begin -- MultiBigStr$
				IF @nCustom = 0
	 				set @sDynSQLParamList = @sDynSQLParamList + char(9) + 
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt ntext = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt image = null' + N', ' + char(13)
				ELSE -- IF @nCustom = 1
	 				set @sDynSQLCustomParamList = @sDynSQLCustomParamList + char(9) + 
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt ntext = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt image = null' + N', ' + char(13)
					
				set @sDynSQL3 = @sDynSQL3 + char(9) +
					N'if @' + @sInheritClassName + N'_' + @sFieldName + N'_txt is not null begin' + char(13) +
					char(9) + char(9) + N'insert into [MultiBigStr$] with (rowlock) ([Flid],[Obj],[Ws],[Txt],[Fmt])' + char(13) + 
					char(9) + char(9) + N'values (' + convert(nvarchar(11), @flid)+ N',@ObjId,' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt)'
				set @sDynSQL3 = @sDynSQL3 + 
N'
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
'
			end
			else if @nFieldType = 20 begin -- MultiBigTxt$
				IF @nCustom = 0
	 				set @sDynSQLParamList = @sDynSQLParamList + char(9) +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt ntext = null' + N', ' + char(13)
				ELSE -- IF @nCustom = 1
	 				set @sDynSQLCustomParamList = @sDynSQLCustomParamList + char(9) +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
						N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt ntext = null' + N', ' + char(13)
				
				set @sDynSQL3 = @sDynSQL3 + char(9) +
					N'if @' + @sInheritClassName + N'_' + @sFieldName + N'_txt is not null begin' + char(13) +
					char(9) + char(9) + N'insert into [MultiBigTxt$] with (rowlock) ([Flid],[Obj],[Ws],[Txt])' + char(13) + 
					char(9) + char(9) + N'values (' + convert(nvarchar(11), @flid)+ N',@ObjId,' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt)'
				set @sDynSQL3 = @sDynSQL3 + 
N'
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
'
			end	
			else begin
				IF @nCustom = 0
					set @sDynSQLParamList = @sDynSQLParamList + char(9) + 
						N'@' + @sInheritClassName + '_' + @sFieldName + ' ' +
						dbo.fnGetColumnDef$(@nFieldType) + N',' + char(13)
				ELSE -- IF @nCustom = 1
					set @sDynSQLCustomParamList = @sDynSQLCustomParamList + char(9) + 
						N'@' + @sInheritClassName + '_' + @sFieldName + ' ' +
						dbo.fnGetColumnDef$(@nFieldType) + N',' + char(13)
				
				set @sFieldList = @sFieldList + N',[' + @sFieldName + N']'
				
				if @sValuesList = ''
					set @sValuesList = N'@' + @sInheritClassName + N'_' + @sFieldName
				else
					set @sValuesList = @sValuesList + N', @' + @sInheritClassName + N'_' + @sFieldName
				
				if @nFieldType = 13 or @nFieldType = 17 begin -- String or BigString
					IF @nCustom = 0
						set @sDynSQLParamList = @sDynSQLParamList + char(9) + 
							N'@' + @sInheritClassName + '_' + @sFieldName + '_fmt '
					ELSE -- IF @nCustom = 1
						set @sDynSQLCustomParamList = @sDynSQLCustomParamList + char(9) + 
							N'@' + @sInheritClassName + '_' + @sFieldName + '_fmt '
					
					if @nFieldType = 13 BEGIN
						IF @nCustom = 0
							set @sDynSQLParamList = @sDynSQLParamList + 'varbinary(8000) = null,' + char(13)
						ELSE -- IF @nCustom = 1
							set @sDynSQLCustomParamList = @sDynSQLCustomParamList + 'varbinary(8000) = null,' + char(13)
						END
					else if @nFieldType = 17 BEGIN
						IF @nCustom = 0
							set @sDynSQLParamList = @sDynSQLParamList + 'image = null,' + char(13)
						ELSE -- IF @nCustom = 1
							set @sDynSQLCustomParamList = @sDynSQLCustomParamList + 'image = null,' + char(13)
					END

					set @sFieldList = @sFieldList + N',[' + @sFieldName + N'_fmt]'
					set @sValuesList = @sValuesList + N', @' + @sInheritClassName + '_' + @sFieldName + '_fmt'
				end

			end
			
			FETCH curFieldList INTO @sFieldName, @nFieldType, @flid, @nCustom
		end

		close curFieldList
		deallocate curFieldList

		if @sFieldList <> N'' set @sDynSQL4 = @sDynSQL4 + char(13) + char(9) +
				N'insert into ['+@sInheritClassName+N'] ([Id]' + 	@sFieldList + N') ' + char(13) + 
				char(9) + char(9) + N'values (@ObjId, ' + @sValuesList + N')'
		else set @sDynSQL4 = @sDynSQL4 + char(9) + N'insert into ['+@sInheritClassName+N'] with (rowlock) ([Id]) values(@ObjId)'
		set @sDynSQL4 = @sDynSQL4 + char(13) + char(9) + N'set @Err = @@error' + char(13) + char(9) + N'if @Err <> 0 goto LCleanUp' + char(13)

		fetch curClassInheritPath into @sInheritClassName, @nInheritClid
	end
	
	close curClassInheritPath
	deallocate curClassInheritPath
	
	--
	-- build the dynamic SQL strings
	--

	IF LEN(@sDynSQLCustomParamList) != 0 BEGIN
--		SET @sDynSQLCustomParamList = ',' + CHAR(13) + 
--			SUBSTRING(@sDynSQLCustomParamList, 1, LEN(@sDynSQLCustomParamList) - 3)
		-- Move the trailing comma and whitespace to the beginning of the list.
		DECLARE @lenCustom INT, @lenNew INT
		SET @lenCustom = LEN(@sDynSQLCustomParamList)
		SET @lenNew = CHARINDEX(N',', @sDynSQLCustomParamList, @lenCustom - 4) - 1
		IF @lenNew = -1 SET @lenNew = @lenCustom	-- sanity check
		SET @sDynSQLCustomParamList = ',' + CHAR(13) + SUBSTRING(@sDynSQLCustomParamList, 1, @lenNew)
	END

	set @sDynSQLParamList =
N'
----------------------------------------------------------------
-- This stored procedure was generated with DefineCreateProc$ --
----------------------------------------------------------------

--( Selected parameters can be used instead of the whole list. For example:
--( exec CreateObject_CmAgent @NewObjId = @NewObjId output,	@NewObjGuid = @NewObjGuid output

Create proc ['+@sProcName+N']' + char(13) + 
	@sDynSQLParamList + 
N'	@Owner int = null,
	@OwnFlid int = null,
	@StartObj int = null,
	@NewObjId int output,
	@NewObjGuid uniqueidentifier output,
	@fReturnTimestamp tinyint = 0,
	@NewObjTimestamp int = null output' + 
	@sDynSQLCustomParamList + CHAR(13)

	set @sDynSQL1 = 
N'as	
	declare @fIsNocountOn int, @Err int, @nTrnCnt int, @sTranName sysname
	declare @OwnOrd int, @Type int, @ObjId int, @guid uniqueidentifier
	declare @DstClass int, @OwnerClass int, @OwnerFlidClass int

	set @nTrnCnt = null
	set @Type = null
	set @OwnOrd = null
	set @NewObjTimestamp = null

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- validate the new object''s owner arguments
	if @Owner is not null begin
		-- get the type of the @OwnFlid field and validate @OwnFlid as being a valid field
		select	@Type = [Type], @DstClass = [DstCls], @OwnerFlidClass = [Class]
		from	[Field$]
		where	[Id] = @OwnFlid
		if @@rowcount = 0 begin
			raiserror(''Owner field does not exist: OwnFlid=%d'', 16, 1, @OwnFlid)
			set @Err = 50001
			goto LCleanUp
		end
		if @Type not in (23, 25, 27) begin
			raiserror(''OwnFlid is not an owning relationship field: OwnFlid=%d Type=%d'', 16, 1, @Ownflid, @Type)
			set @Err = 50002
			goto LCleanUp
		end

		-- make sure the @OwnFlid field has a relationship with the ' + @sClass + N' class
		if @DstClass <> ' + convert(nvarchar(11), @clid) + N'  begin
			-- check the base classes
			if not exists (
				select	*
				from	[ClassPar$]
				where	[Src] = '+convert(nvarchar(11), @clid) + N' and [Dst] = @DstClass 
			) begin
				raiserror(''OwnFlid does not relate to the ' + @sClass + N' class: OwnFlid=%d'', 16, 1, @OwnFlid)
				set @Err = 50003
				goto LCleanUp
			end
		end

		-- make sure that @OwnFlid is a field of the @Owner class
		select	@OwnerClass = [Class$]
		from	[CmObject]
		where	[Id] = @Owner
		if @@rowcount = 0 begin
			raiserror(''Owner object does not exist: Owner=%d'', 16, 1, @Owner)
			set @Err = 50004
			goto LCleanUp
		end
		if @OwnerClass <> @OwnerFlidClass begin
			-- check the base classes
			if not exists (
				select	*
				from	[ClassPar$]
				where	[Src] = @ownerClass and [Dst] = @OwnerFlidClass
			) begin
				raiserror(''OwnFlid is not a field of the owner class: Owner=%d, OwnerClass=%d, OwnFlid=%d'', 16, 1, @Owner, @OwnerClass, @OwnFlid)
				set @Err = 50005
				goto LCleanUp
			end
		end
	end

	-- determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	--	transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = '''+@sProcName+N'_tr'' + convert(varchar(2), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName
'
	set @sDynSQL2 = 
N'
	-- determine if the object is being added to an owning sequence
	if @Type = 27 begin

		-- determine if the objects should be added to the end of the list
		
		-- REVIEW (SteveMiller): SERIALIZABLE here is entirely keeping with good db code. However,
		-- SERIALIZABLE holds a lock for the duration of the transaction, which bars any further
		-- inserts/updates from happening. This should be acceptable here, but could be a place to
		-- look if locking problems occur.
		
		if @StartObj is null begin
			select	@ownOrd = coalesce(max([OwnOrd$])+1, 1)
			from	[CmObject] with (SERIALIZABLE)
			where	[Owner$] = @Owner
				and [OwnFlid$] = @OwnFlid
		end
		else begin
			-- get the ordinal value of the object that is located where the new object is to be inserted
			select	@OwnOrd = [OwnOrd$]
			from	[CmObject] with (SERIALIZABLE)
			where	[Id] = @StartObj
			if @OwnOrd is null begin
				raiserror(''The start object does not exist in the owning sequence: Owner=%d, OwnFlid=%d, StartObj=%d'', 16, 1, @Owner, @OwnFlid, @StartObj)
				set @Err = 50006
				goto LCleanUp
			end
			
			-- increment the ordinal value(s) of the object(s) in the sequence that occur at or after 
			--	the new object(s)
			update	[CmObject] with (SERIALIZABLE)
			set	[OwnOrd$] = [OwnOrd$] + 1
			where	[Owner$] = @Owner
				and [OwnFlid$] = @OwnFlid
				and [OwnOrd$] >= @OwnOrd
		end
	end
	
	-- determine if the object is being added to an atomic owning relationship
	else if @Type = 23 begin
		-- make sure there isn''t already an object owned by @Owner
		if exists (
			select	*
			from	[CmObject]
			where	[Owner$] = @Owner and [OwnFlid$] = @OwnFlid
			) begin
			raiserror(''An object is already owned by the atomic relationship: Owner=%d, OwnFlid=%d'', 16, 1, @Owner, @OwnFlid)
			set @Err = 50007
			goto LCleanUp
		end
	end
	
	set @guid = newid()
	insert into [CmObject] with (rowlock) ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values (@guid, '+convert(nvarchar(11), @clid)+N', @Owner, @OwnFlid, @OwnOrd)
	set @Err = @@error
	set @ObjId = @@identity	
	if @Err <> 0 begin
		raiserror(''SQL Error %d: Unable to create the new object'', 16, 1, @Err)
		goto LCleanUp
	end

'
	set @sDynSQL5 = 
N'	

	-- set the output paramters
	set @NewObjId = @ObjId
	set @NewObjGuid = @guid
	if @fReturnTimestamp = 1 begin
		select	@NewObjTimestamp = [UpdStmp]
		from	[CmObject]
		where	[Id] = @NewObjId
	end

LCleanUp:

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction or savepoint was created
	if @nTrnCnt is not null begin
		if @Err = 0 begin
			-- if a transaction was created within this procedure commit it
			if @nTrnCnt = 0 commit tran @sTranName 
		end
		else begin
			rollback tran @sTranName 
		end
	end

	return @Err
'

	--
	-- execute the dynamic SQL
	--
	
 	exec (@sDynSQLParamList + @sDynSql1+@sDynSQL2+@sDynSQL3+@sDynSQL4+@sDynSQL5)
 	set @Err = @@error
 	if @Err <> 0 begin
 		raiserror ('SQL Error %d: Unable to create procedure for class %s', 16, 1, @Err, @sClass)
 		goto LCleanUp
 	end	

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return @Err
go

/***********************************************************************************************
 * CreateObject$
 *
 * Description:
 *	Creates an object given its class id.
 *
 * Paramters:
 *	If @id is null, the object id is generated and returned.
 *  If @guid is null, the guid is generated and returned.
 * 
 * Returns:
 * 	0 if successful, otherwise an error
 **********************************************************************************************/

if object_id('CreateObject$') is not null begin
	print 'removing proc CreateObject$'
	drop proc [CreateObject$]
end
go
print 'creating proc CreateObject$'
go
create proc [CreateObject$]
	@clid int,
	@id int output,
	@guid uniqueidentifier output
as
	SpBegin()

	declare @ObjId int
	declare @depth int
	declare @sSql nvarchar(kcchMaxSql), @sTbl nvarchar(kcchMaxName), @sId nvarchar(kcchMaxInt)
	declare @fAbs bit

	if @guid is null set @guid = NewId()

	select @fAbs = [Abstract], @sTbl = [Name] from [Class$] where [Id] = @clid
	if @@rowcount <> 1 begin
		RaisError('Bad Class ID: %d', 16, 1, @clid)
		set @err = @@error
		goto LFail
	end

	if @fAbs <> 0 begin
		RaisError('Cannot instantiate abstract class: @s', 16, 1, @sTbl)
		set @err = @@error
		goto LFail
	end

	select @depth = [Depth] from [ClassPar$] where [Src] = @clid and [Dst] = kclidCmObject
	if @@rowcount <> 1 begin
		RaisError('Bad Class Id or corrupt ClassPar$ table: %d', 16, 1, @clid)
		set @err = @@error
		goto LFail
	end

	-- if an Id was supplied assume that the IDENTITY_INSERT setting is turned on and the incoming Id is legal
	if @id is null begin
		insert into [CmObject] ([Guid$], [Class$], [OwnOrd$])
			values(@guid, @clid, null)
		SpCheck(@@error)

		set @id = @@identity
	end
	else begin
		insert into [CmObject] ([Guid$], [Id], [Class$], [OwnOrd$])
			values(@guid, @id, @clid, null)
		SpCheck(@@error)
	end
	set @sId = convert(nvarchar(kcchMaxInt), @id)

	while @depth > 0 begin
		set @depth = @depth - 1

		select @sTbl = c.[Name]
		from [ClassPar$] cp join [Class$] c on c.[Id] = cp.[Dst]
		where cp.[Src] = @clid and cp.[Depth] = @depth

		if @@rowcount <> 1 begin
			RaisError('Corrupt ClassPar$ table: %d', 16, 1, @clid)
			set @err = @@error
			goto LFail
		end

		set @sSql = 'insert into [' + @sTbl + '] with (rowlock) ([Id]) values(' + @sId + ')'
		exec (@sSql)
		SpCheck(@@error)
	end

	SpEnd()
go


/***********************************************************************************************
 * CreateOwnedObject$
 *
 * Description:
 *	Creates an object given its class id.
 *
 * Paramters:
 *	If @id is null, the object id is generated and returned.
 *  If @guid is null, the guid is generated and returned.
 * 
 * Returns:
 * 	0 if successful, otherwise an error
 **********************************************************************************************/


if object_id('CreateOwnedObject$') is not null begin
	print 'removing proc CreateOwnedObject$'
	drop proc CreateOwnedObject$
end
go
print 'creating proc CreateOwnedObject$'
go
create proc [CreateOwnedObject$]
	@clid int,
	@id int output,
	@guid uniqueidentifier output,
	@owner int,
	@ownFlid int,
	@type int,			-- type of field (atomic, collection, or sequence)
	@StartObj int = null,		-- object to insert before - owned sequences
	@fGenerateResults tinyint = 0,	-- default to not generating results
	@nNumObjects int = 1,		-- number of objects to create
	@uid uniqueidentifier = null output
as
	declare @err int, @nTrnCnt int, @sTranName varchar(50) 
	declare @depth int, @fAbs bit
	declare @sDynSql nvarchar(4000), @sTbl sysname, @sId varchar(11)
	declare @OwnOrd int
	declare @i int, @currId int, @currOrd int, @currListOrd int
	declare	@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- validate the class
	select	@fAbs = [Abstract], @sTbl = [Name] 
	from	[Class$] (READUNCOMMITTED)
	where	[Id] = @clid
	if @fAbs <> 0 begin
		RaisError('Cannot instantiate abstract class: %s', 16, 1, @sTbl)
		return 50001
	end
	-- get the inheritance depth
	select	@depth = [Depth] 
	from	[ClassPar$]  (READUNCOMMITTED)
	where	[Src] = @clid 
		and [Dst] = 0

	-- determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	--	transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'CreateOwnedObject$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- determine if the object is being added to a sequence
	if @type = kcptOwningSequence begin

		-- determine if the object(s) should be added to the end of the sequence
		if @StartObj is null begin
			select	@ownOrd = coalesce(max([OwnOrd$])+1, 1)
			from	[CmObject] WITH (REPEATABLEREAD)
			where	[Owner$] = @Owner
				and [OwnFlid$] = @OwnFlid
		end
		else begin
			-- get the ordinal value of the object that is located where the new object is to be inserted
			select	@OwnOrd = [OwnOrd$]
			from	[CmObject] with (repeatableread)
			where	[Id] = @StartObj

			-- increment the ordinal value(s) of the object(s) in the sequence that occur at or after the new object(s)
			update	[CmObject] WITH (REPEATABLEREAD)
			set 	[OwnOrd$]=[OwnOrd$]+@nNumObjects
			where 	[Owner$] = @owner
				and [OwnFlid$] = @OwnFlid
				and [OwnOrd$] >= @OwnOrd
		end
	end

	-- determine if more than one object should be created; if more than one object is created the created objects IDs are stored
	--	in the ObjListTbl$ table so that the calling procedure/application can determine the IDs (the calling procedure or
	--	application is responsible for cleaning up the ObjListTlb$), otherwise if only one object is created the new object's
	--	ID is passed back to the calling procedure/application through output parameters -- the two approaches are warranted
	--	because it is ideal to avoid using the ObjListTbl$ if only one object is being created, also this maintains backward
	--	compatibility with existing code
	if @nNumObjects > 1 begin

		set @uid = NewId()

		set @i = 0
		set @currListOrd = coalesce(@ownOrd, 0)

		-- if an Id was supplied assume that the IDENTITY_INSERT setting is turned on and the incoming Id is legal
		if @id is not null begin
			while @i < @nNumObjects begin
				set @currId = @id + @i
				set @currOrd = @ownOrd + @i

				insert into [CmObject] ([Guid$], [Id], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
					values(newid(), @currId, @clid, @owner, @ownFlid, @currOrd)
				set @err = @@error
				if @Err <> 0 begin 
					raiserror('Unable to create object: ID=%d, Class=%d, Owner=%d, OwnFlid=%d, OwnOrd=%d', 16, 1,
							@currId, @clid, @owner, @ownFlid, @currOrd)
					goto LFail 
				end

				-- add the new object to the list of created objects
				insert into ObjListTbl$ with (rowlock) (uid, ObjId, Ord, Class) 
					values (@uid, @id + @i, @currListOrd + @i, @clid)

				set @i = @i + 1
			end
		end
		else begin
			while @i < @nNumObjects begin
				set @currOrd = @ownOrd + @i
				
				insert into [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
					values(newid(), @clid, @owner, @ownFlid, @currOrd)
				set @err = @@error 
				if @Err <> 0 begin 
					raiserror('Unable to create object: Class=%d, Owner=%d, OwnFlid=%d, OwnOrd=%d', 16, 1,
							@clid, @owner, @ownFlid, @currOrd)
					goto LFail 
				end
				set @id = @@identity

				-- add the new object to the list of created objects
				insert into ObjListTbl$ with (rowlock) (uid, ObjId, Ord, Class) 
					values (@uid, @id, @currListOrd + @i, @clid)
				set @i = @i + 1
			end
		end

		-- insert the objects' Ids into all of the base classes
		while @depth > 0 begin
			set @depth = @depth - 1

			select	@sTbl = c.[Name]
			from	[ClassPar$] cp  (READUNCOMMITTED)
			join [Class$] c  (READUNCOMMITTED) on c.[Id] = cp.[Dst]
			where	cp.[Src] = @clid 
				and cp.[Depth] = @depth
			set @sDynSql =  'insert into [' + @sTbl + '] ([Id]) '+
					'select [ObjId] ' +
					'from [ObjListTbl$] (readuncommitted) '+
					'where [uid] = '''+convert(varchar(250), @uid)+''''
			exec (@sDynSql)
			set @err = @@error 
			if @Err <> 0 begin 
				raiserror('Unable to add rows to the base table %s', 16, 1, @sTbl) 
				goto LFail 
			end
		end		
		
		if @fGenerateResults = 1 begin
			select	ObjId
			from	ObjListTbl$ (readuncommitted)
			where	uid=@uid
			order by Ord
		end
	end
	else begin
		if @guid is null set @guid = NewId()

		-- if an Id was supplied assume that the IDENTITY_INSERT setting is turned on and the incoming Id is legal
		if @id is not null begin
			insert into [CmObject] ([Guid$], [Id], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
				values(@guid, @id, @clid, @owner, @ownFlid, @ownOrd)
			set @err = @@error 
			if @Err <> 0 goto LFail 
		end
		else begin
			insert into [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
				values(@guid, @clid, @owner, @ownFlid, @ownOrd)
			set @err = @@error 
			if @Err <> 0 goto LFail 
			set @id = @@identity
		end

		-- insert the object's Id into all of the base classes
		set @sId = convert(varchar(11), @id)
		while @depth > 0 begin
			set @depth = @depth - 1

			select	@sTbl = c.[Name]
			from	[ClassPar$] cp  (READUNCOMMITTED)
			join [Class$] c  (READUNCOMMITTED) on c.[Id] = cp.[Dst]
			where	cp.[Src] = @clid 
				and cp.[Depth] = @depth
			if @@rowcount <> 1 begin
				raiserror('Corrupt ClassPar$ table: %d', 16, 1, @clid)
				set @err = @@error
				goto LFail
			end
	
			set @sDynSql = 'insert into [' + @sTbl + '] with (rowlock) ([Id]) values (' + @sId + ')'
			exec (@sDynSql)
			set @err = @@error 
			if @Err <> 0 begin 
				raiserror('Unable to add a row to the base table %s: ID=%s', 16, 1, @sTbl, @sId) 
				goto LFail 
			end
		end

		if @fGenerateResults = 1 begin
			select @id [Id], @guid [Guid]
		end	
	end
	
	-- update the date/time of the owner
	UPDATE [CmObject] SET [UpdDttm] = GetDate()
		FROM [CmObject] WHERE [Id] = @owner
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
go

/***********************************************************************************************
 *	CopyObj$
 *
 *	Description: 
 *		Creates a copy of an object.
 *
 *	TODO (SteveMiller):
 *		This version of CopyObj$ quadrupled the speed of its immediate predecessor. However,
 *		some more speed may be gained. One potential gain is putting a primary key and/or
 *		index on the temp table #SourceObjs.
 **********************************************************************************************/

IF OBJECT_ID('CopyObj$') IS NOT NULL BEGIN
   	PRINT 'removing procedure CopyObj$'
   	DROP PROC [CopyObj$]
END
GO
PRINT 'creating procedure CopyObj$'
GO
CREATE PROCEDURE [CopyObj$]
   	@nTopSourceObjId INT,  	--( the top owning object
   	@nTopDestOwnerId INT,	--( The ID of the owner of the top object we're creating here
   	@nTopDestOwnerFlid INT,		--( The owning field ID of the top object we're creating here
   	@nTopDestObjId INT OUTPUT	--( the ID for the new object we're creating here
AS
   
   	DECLARE 
   		@nSourceObjId INT,
   		@nOwnerID INT,
   		@nOwnerFieldId INT, --(owner flid
   		@nRelObjId INT,
   		@nRelObjFieldId INT,  --( related object flid
   		@guidNew UNIQUEIDENTIFIER,
   		@nFirstOuterLoop TINYINT,
   		@nDestObjId INT,
   		@nOwnerDepth INT,
   		@nInheritDepth INT,
   		@nClass INT,
   		@nvcClassName NVARCHAR(100),
   		@nvcQuery NVARCHAR(4000)
   	
   	DECLARE
   		@nvcFieldsList NVARCHAR(4000),
   		@nvcValuesList NVARCHAR(4000),
   		@nColumn INT,
   		@sysColumn SYSNAME,
   		@nFlid INT,
   		@nType INT,
   		@nSourceClassId INT,
   		@nDestClassId INT,
   		@nvcFieldName NVARCHAR(100),
  		@nvcTableName NVARCHAR(100)
	
   	CREATE TABLE #SourceObjs (
   		[ObjId]			INT		not null,
   		[ObjClass]		INT		null,
   		[InheritDepth]	INT		null		DEFAULT(0),
   		[OwnerDepth]	INT		null		DEFAULT(0),
   		[RelObjId]		INT		null,
   		[RelObjClass]	INT		null,
   		[RelObjField]	INT		null,
   		[RelOrder]		INT		null,
   		[RelType]		INT		null,
   		[OrdKey]		VARBINARY(250)	null	DEFAULT(0),
   		[ClassName]		NVARCHAR(100),
   		[DestinationID]	INT		NULL)
   	
   	SET @nFirstOuterLoop = 1
   	SET @nOwnerId = @nTopDestOwnerId
   	SET @nOwnerFieldId = @nTopDestOwnerFlid
   	
   	--== Get the Object Tree ==--
   	
   	INSERT INTO #SourceObjs
   		SELECT oo.*, c.[Name], NULL
   		FROM dbo.fnGetOwnedObjects$(@nTopSourceObjId, NULL, NULL, 1, 0, 1, null, 1) oo
   		JOIN Class$ c ON c.[Id] = oo.[ObjClass]
   		WHERE oo.[ObjClass] <> 0 -- Have to block CmObject rows, now that fnGetOwnedObjects$ returns the CmObject table.
   	
   	--== Create CmObject Records ==--
   	
   	--( Create all the CmObjects for all the objects copied
   	
   	DECLARE curNewCmObjects CURSOR FAST_FORWARD FOR
		SELECT  MAX([ObjId]), MAX([RelObjId]), MAX([RelObjField])
   		FROM #SourceObjs
   		GROUP BY [ObjId], [RelObjId], [RelObjField]
   		ORDER BY MIN([OwnerDepth]), MAX([InheritDepth]) DESC
	
   	OPEN curNewCmObjects 
   	FETCH curNewCmObjects INTO @nSourceObjId, @nRelObjId, @nRelObjFieldId
   	WHILE @@FETCH_STATUS = 0 BEGIN
   		SET @guidNew = NEWID()
   		
   		INSERT INTO CmObject WITH (ROWLOCK) ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
   			SELECT @guidNew, [Class$], @nOwnerId, @nOwnerFieldId, [OwnOrd$]
   			FROM CmObject
   			WHERE [Id] = @nSourceObjId
   		
   		SET @nDestObjId = @@IDENTITY
   		
   		UPDATE #SourceObjs SET [DestinationID] = @nDestObjId WHERE [ObjId] = @nSourceObjID
   		
   		--== Copy records in "multi" string tables ==--
		
		--( Tables of the former MultiTxt$ table are now  set in a separate loop.
		
   		INSERT INTO MultiStr$ WITH (ROWLOCK) ([Flid], [Obj], [Ws], [Txt], [Fmt])
   		SELECT [Flid], @nDestObjID, [WS], [Txt], [Fmt]
   		FROM MultiStr$  (READUNCOMMITTED)
   		WHERE [Obj] = @nSourceObjId
   		
   		--( As of this writing, MultiBigTxt$ is not used anywhere in the conceptual
   		--( model, and it is impossible to use it through the interface.
   		
   		INSERT INTO MultiBigTxt$ WITH (ROWLOCK) ([Flid], [Obj], [Ws], [Txt])
   		SELECT [Flid], @nDestObjID, [WS], [Txt]
   		FROM MultiBigTxt$ (READUNCOMMITTED)
   		WHERE [Obj] = @nSourceObjId
   		
   		INSERT INTO MultiBigStr$ WITH (ROWLOCK) ([Flid], [Obj], [Ws], [Txt], [Fmt])
   		SELECT [Flid], @nDestObjID, [WS], [Txt], [Fmt]
   		FROM MultiBigStr$ (READUNCOMMITTED)
   		WHERE [Obj] = @nSourceObjId
   		
   		--( If the object ID = the top owning object ID
   		IF @nFirstOuterLoop = 1
   			SET @nTopDestObjId = @nDestObjID --( sets the output parameter
   		
   		SET @nFirstOuterLoop = 0
   		
   		--( This fetch is different than the one at the top of the loop!
  		FETCH curNewCmObjects INTO @nSourceObjId, @nRelObjId, @nOwnerFieldId
		
   		SELECT @nOwnerId = [DestinationId] FROM #SourceObjs WHERE ObjId = @nRelObjId
   	END
   	CLOSE curNewCmObjects
   	DEALLOCATE curNewCmObjects
   	
   	--== Create All Other Records ==--
   	
   	DECLARE curRecs CURSOR FAST_FORWARD FOR 
   		SELECT DISTINCT [OwnerDepth], [InheritDepth], [ObjClass], [ClassName]
   		FROM #SourceObjs
   		ORDER BY [OwnerDepth], [InheritDepth] DESC, [ObjClass]
   	
   	OPEN curRecs
   	FETCH curRecs INTO 	@nOwnerDepth, @nInheritDepth, @nClass, @nvcClassName
   	WHILE @@FETCH_STATUS = 0 BEGIN
   		SET @nvcFieldsList = N''
   		SET @nvcValuesList = N''
   		SET @nColumn = 1
   		SET @sysColumn = COL_NAME(OBJECT_ID(@nvcClassName), @nColumn)
   		WHILE @sysColumn IS NOT NULL BEGIN
   			IF @nColumn > 1 BEGIN --( not the first time in loop
   				SET @nvcFieldsList = @nvcFieldsList + N', '
   				SET @nvcValuesList = @nvcValuesList + N', '
   			END
   			SET @nvcFieldName = N'[' + UPPER(@sysColumn) + N']'
   			
   			--( Field list for insert
   			SET @nvcFieldsList = @nvcFieldsList + @nvcFieldName
   			
   			--( Vales to put into those fields
   			IF @nvcFieldName = '[ID]'
   				SET @nvcValuesList = @nvcValuesList + N' so.[DestinationId] '
   			ELSE IF @nvcFieldName = N'[DATECREATED]' OR @nvcFieldName = N'[DATEMODIFIED]'
   				SET @nvcValuesList = @nvcValuesList + N'CURRENT_TIMESTAMP'
   			ELSE
   				SET @nvcValuesList = @nvcValuesList + @nvcFieldName
   			
   			SET @nColumn = @nColumn + 1
   			SET @sysColumn = COL_NAME(OBJECT_ID(@nvcClassName), @nColumn)
   		END
   		
   		SET @nvcQuery = 
   			N'INSERT INTO ' + @nvcClassName + ' WITH (ROWLOCK) (
   				' + @nvcFieldsList + ') 
   			SELECT ' + @nvcValuesList + N'
   			FROM ' + @nvcClassName + ' cn (READUNCOMMITTED)
   			JOIN #SourceObjs so ON 
   				so.[OwnerDepth] = ' + STR(@nOwnerDepth) + N' AND
   				so.[InheritDepth] = ' + STR(@nInheritDepth) + N' AND
   				so.[ObjClass] = ' + STR(@nClass) + N' AND
   				so.[ObjId] = cn.[Id]'
   		
   		EXEC (@nvcQuery)
		
   		--== Copy References ==--
   		
   		DECLARE curReferences CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
   		SELECT f.[Id], f.[Type], f.[Name]
   		FROM Field$ f (READUNCOMMITTED)
   		WHERE f.[Class] = @nClass AND 
			(f.[Type] = kcptReferenceCollection OR f.[Type] = kcptReferenceSequence)
   			
   		OPEN curReferences
   		FETCH curReferences INTO @nFlid, @nType, @nvcFieldName
   		WHILE @@FETCH_STATUS = 0 BEGIN
   			
   			SET @nvcQuery = N'INSERT INTO ' + @nvcClassName + N'_' + @nvcFieldName + N' ([Src], [Dst]'
   			
   			IF @nType = kcptReferenceCollection
   				SET @nvcQuery = @nvcQuery + N') 
   					SELECT DestinationId, r.[Dst] 
   					FROM '
   			ELSE --( IF @nType = kcptReferenceSequence
   				SET @nvcQuery = @nvcQuery + N', [Ord]) 
   					SELECT DestinationId, r.[Dst], r.[Ord]
   					FROM '
   			
    			SET @nvcQuery = @nvcQuery + @nvcClassName + N'_' + @nvcFieldName + N' r (READUNCOMMITTED) 
     				JOIN #SourceObjs ON 
     					[OwnerDepth] = @nOwnerDepth AND
     					[InheritDepth] =  @nInheritDepth AND
     					[ObjClass] = @nClass AND
     					[ObjId] = r.[Src]'
    			
    			EXEC sp_executesql @nvcQuery,
	   				N'@nOwnerDepth INT, @nInheritDepth INT, @nClass INT', 
   					@nOwnerDepth, @nInheritDepth, @nClass
			
   			FETCH curReferences INTO @nFlid, @nType, @nvcFieldName
   		END
   		CLOSE curReferences
   		DEALLOCATE curReferences
   		
   		FETCH curRecs INTO 	@nOwnerDepth, @nInheritDepth, @nClass, @nvcClassName
   	END
   	CLOSE curRecs
   	DEALLOCATE curRecs
   		
   	--== References to Copied Objects ==--
   	
   	--( objects can point to themselves. For instance, the People list has a 
    	--( researcher that points back to the People list. For copies, this reference
    	--( back to itself needs to have the new object, not the old source object. For
    	--( all other reference properties, the old object will do fine.
   	
   	DECLARE curRefs2CopiedObjs CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
   		SELECT DISTINCT c.[Name] + N'_' + f.[Name]
   		FROM Class$ c
   		JOIN Field$ f ON f.[Class] = c.[Id]
   		JOIN #SourceObjs s ON s.[ObjClass] = c.[Id]
   		WHERE f.[Type] = kcptReferenceCollection OR f.[Type] = kcptReferenceSequence
   	
   	OPEN curRefs2CopiedObjs
   	FETCH curRefs2CopiedObjs INTO @nvcTableName
   	WHILE @@FETCH_STATUS = 0 BEGIN
   		SET @nvcQuery = N'UPDATE ' + @nvcTableName + N' 
   			SET [Dst] = #SourceObjs.[DestinationId]
   			FROM ' + @nvcTableName + N', #SourceObjs
   			WHERE ' + @nvcTableName + N'.[Dst] = #SourceObjs.[ObjId]'
   		
  		EXEC sp_executesql @nvcQuery
		
   		FETCH curRefs2CopiedObjs INTO @nvcTableName
   	END
   	CLOSE curRefs2CopiedObjs
   	DEALLOCATE curRefs2CopiedObjs

	--== MultiTxt$ Records ==--
	
	DECLARE curMultiTxt CURSOR FAST_FORWARD FOR 
		SELECT DISTINCT ObjId, ObjClass, ClassName, DestinationId
		FROM #SourceObjs
	
	--( First get the object IDs and their class we're working with
	OPEN curMultiTxt
	FETCH curMultiTxt INTO @nSourceObjId, @nClass, @nvcClassName, @nDestObjId
	WHILE @@FETCH_STATUS = 0 BEGIN
		
		--( Now copy into each of the multitxt fields
		SELECT TOP 1 @nFlid = [Id], @nvcFieldName = [Name]
		FROM Field$
		WHERE Class = @nClass AND Type = kcptMultiUnicode
		ORDER BY [Id]
		
		WHILE @@ROWCOUNT > 0 BEGIN
			SET @nvcQuery = 
				N'INSERT INTO ' + @nvcClassName + N'_' + @nvcFieldName + N' ' +
				N'WITH (ROWLOCK) (Obj, Ws, Txt)' + CHAR(13) +
				CHAR(9) + N'SELECT @nDestObjId, WS, Txt' + CHAR(13) +
				CHAR(9) + N'FROM ' + @nvcClassName + N'_' + @nvcFieldName + ' (READUNCOMMITTED)' + CHAR(13) + 
				CHAR(9) + N'WHERE Obj = @nSourceObjId'
			
			EXECUTE sp_executesql @nvcQuery,
				N'@nDestObjId INT, @nSourceObjId INT',
				@nDestObjID, @nSourceObjId
			
			SELECT TOP 1 @nFlid = [Id], @nvcFieldName = [Name]
			FROM Field$
			WHERE [Id] > @nFlid AND Class = @nClass AND Type = kcptMultiUnicode
			ORDER BY [Id]
		END
		
		FETCH curMultiTxt INTO @nSourceObjId, @nClass, @nvcClassName, @nDestObjId
	END
	CLOSE curMultiTxt
	DEALLOCATE curMultiTxt
		
	DROP TABLE #SourceObjs

GO

/***********************************************************************************************
	Object deletion stored procedures.
***********************************************************************************************/

/***********************************************************************************************
 * DeleteObj$
 *
 * Description: 
 *	Removes an object and any objects it owns from the database, also references (ref. 
 *	pointers, ref. collections, and ref. sequences) are appropriately cleaned up
 *
 * Parameters: 
 *	@objId=the Id of the object to remove - if @objId is not specified this 
 *		procedures works on all of the objects in DelObjTbl$
 * 	@hXMLDocObjList=handle to a parsed XML document that contains multiple object Ids - the
 *		ownership chain will be produced for each of these objectIds;
 *
 * Returns: 
 *	0 if successful, otherwise an error code
 *
 * Notes:
 * 	Objects should be specified using either the @ObjId parameter or through an XML 
 *	document (the @hXMLDocObjList parameter is a handle to a parsed XML document) but not
 *	both.
 *
 * TODO: (?) DeleteObjects() should replace this in interface code.
 **********************************************************************************************/
if object_id('DeleteObj$') is not null begin
	print 'removing proc DeleteObj$'
	drop proc [DeleteObj$]
end
go
print 'creating proc DeleteObj$'
go
create proc [DeleteObj$]
	@objId int = null,
	@hXMLDocObjList int=null
as
	DECLARE @nvcId NVARCHAR(20)
	SET @nvcId = CONVERT(NVARCHAR(20), @objId)
	
	EXEC DeleteObjects @nvcId, @hXMLDocObjList
GO

/***********************************************************************************************
 * DeletePrepDelObjects$
 *
 * Description: 
 *	Deletes the object(s) that were prepared by GetIncomingRefsPrepDel$
 *
 * Parameters: 
 *	@uid=a unique Id that identifies the GetIncomingRefsPrepDel$ result set in the 
 *		ObjInfoTbl$
 *	@fRemoveObjInfo=a flag that determines if data temporarily stored in the ObjInfoTbl$, 
 *		which is used for internal processing, is removed
 *
 * Returns: 
 *	0 if successful, otherwise an error code
 **********************************************************************************************/
if object_id('DeletePrepDelObjects$') is not null begin
	print 'removing proc DeletePrepDelObjects$'
	drop proc [DeletePrepDelObjects$]
end
go
print 'creating proc DeletePrepDelObjects$'
go
create proc [DeletePrepDelObjects$]
	@uid uniqueidentifier,
	@fRemoveObjInfo tinyint = 1
as
	declare @Err int, @nRowCnt int, @nTrnCnt int
	declare	@sQry nvarchar(kcchMaxSql), @sUid nvarchar(50)
	declare	@nObjClass int, @nInheritDepth int, @nOwnerDepth int, @nOrdrAndType tinyint, @sDelClass nvarchar(kcchMaxName), @sDelField nvarchar(kcchMaxName)
	declare	@fIsNocountOn int
	
	DECLARE
		@nObj INT,
		@nvcTableName NVARCHAR(60),
		@nFlid INT
	
	set @Err = 0
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--    otherwise create a transaction
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran DelObj$_Tran
	else save tran DelObj$_Tran
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to create a transaction.', 16, 1, @Err)
		goto LFail
	end	

	--
	-- remove strings associated with the objects that will be deleted
	--
	delete	MultiStr$
	from [ObjInfoTbl$] oi join [MultiStr$] ms on oi.[ObjId] = ms.[obj]
	where oi.[Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to remove strings from the MultiStr$ table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end

	--( This query finds the class of the object, and from there deteremines
	--( which multitxt fields need deleting. It gets the first property first.
	--( Any remaining multitxt properties are found in the loop.
	
	SELECT TOP 1
		@nObj = oi.ObjId,
		@nFlid = f.[Id],
		@nvcTableName = c.[Name] + '_' + f.[Name]
	FROM Field$ f
	JOIN Class$ c ON c.[Id] = f.Class
	JOIN CmObject o ON o.Class$ = f.Class AND Type = 16
	JOIN ObjInfoTbl$ oi ON oi.ObjId = o.[Id]
	ORDER BY f.[Id]
	
	SET @nRowCnt = @@ROWCOUNT
	WHILE @nRowCnt > 0 BEGIN
		SET @sQry = 
			N'DELETE ' + @nvcTableName + N' WITH (REPEATABLEREAD) ' + CHAR(13) +
			CHAR(9) + N'FROM ObjInfoTbl$ oi (READUNCOMMITTED)' + CHAR(13) +
			CHAR(9) + N'JOIN ' + @nvcTableName + ' x (READUNCOMMITTED) ON x.Obj = @nObj'
		
		EXECUTE sp_executesql @sQry, N'@nObj INT', @nObj
		
		set @Err = @@error
		if @Err <> 0 begin
			raiserror ('DeleteObj$: SQL Error %d; Unable to remove strings from the MultiTxt table ', 16, 1, @Err)
			goto LFail
		end
		
		SELECT TOP 1
			@nObj = oi.ObjId,
			@nFlid = f.[Id],
			@nvcTableName = c.[Name] + '_' + f.[Name]
		FROM Field$ f
		JOIN Class$ c ON c.[Id] = f.Class
		JOIN CmObject o ON o.Class$ = f.Class AND Type = 16
		JOIN ObjInfoTbl$ oi ON oi.ObjId = o.[Id]
		WHERE f.[Id] > @nFlid
		ORDER BY f.[Id]
		
		SET @nRowCnt = @@ROWCOUNT
	END
	
	delete MultiBigStr$
	from [ObjInfoTbl$] oi join [MultiBigStr$] ms on oi.[ObjId] = ms.[obj]
	where oi.[Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to remove strings from the MultiBigStr$ table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end
	delete MultiBigTxt$
	from [ObjInfoTbl$] oi join [MultiBigTxt$] ms on oi.[ObjId] = ms.[obj]
	where oi.[Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to remove strings from the MultiBigTxt$ table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end

	--
	-- loop through the objects and delete all owned objects and clean-up all relationships
	--
	declare Del_Cur cursor fast_forward local for
	-- get the external classes that reference (atomic, sequences, and collections) one of the owned classes
	select	oi.ObjClass, 
		min(oi.InheritDepth) as InheritDepth, 
		max(oi.OwnerDepth) as OwnerDepth, 
		c.Name as DelClassName,
		f.Name as DelFieldName,
		case oi.[RelType]
			when kcptReferenceAtom then 1		-- atomic reference
			when kcptReferenceCollection then 2	-- reference collection 
			when kcptReferenceSequence then 3	-- reference sequence
		end as OrdrAndType
	from	ObjInfoTbl$ oi (REPEATABLEREAD) join Class$ c on oi.RelObjClass = c.Id
			join Field$ f on oi.RelObjField = f.Id
	where	oi.[Uid] = @uid
		and oi.[RelType] in (kcptReferenceAtom,kcptReferenceCollection,kcptReferenceSequence)
	group by oi.ObjClass, c.Name, f.Name, oi.RelType
	union all
	-- get internal references - the call to GetIncomingRefsPrepDel$ only found external references
	select	oi.ObjClass, 
		min(oi.InheritDepth) as InheritDepth, 
		max(oi.OwnerDepth) as OwnerDepth, 
		c.Name as DelClassName,
		f.Name as DelFieldName,
		case oi.[RelType]
			when kcptReferenceAtom then 1		-- atomic reference
			when kcptReferenceCollection then 2	-- reference collection 
			when kcptReferenceSequence then 3	-- reference sequence
		end as OrdrAndType
	from	ObjInfoTbl$ oi (REPEATABLEREAD) join Field$ f on f.[DstCls] = oi.[ObjClass] and f.Type in (kcptReferenceAtom,kcptReferenceCollection,kcptReferenceSequence)
			join Class$ c on c.[Id] = f.[Class]
	where	oi.[Uid] = @uid
		and exists (
			select	*
			from	ObjInfoTbl$ oi2 (readuncommitted)
			where	oi2.[Uid] = @uid
				and oi2.[ObjClass] = f.[Class]
		)
	group by oi.ObjClass, c.Name, f.Name, oi.RelType
	union all
	-- get the classes that are referenced by the owning classes
	select	oi.ObjClass,
		min(oi.InheritDepth) as InheritDepth,
		max(oi.OwnerDepth) as OwnerDepth,
		c.Name as DelClassName,
		f.Name as DelFieldName,
		case f.[Type]
			when kcptReferenceCollection then 4	-- reference collection 
			when kcptReferenceSequence then 5	-- reference sequence
		end as OrdrAndType
	from	[ObjInfoTbl$] oi (REPEATABLEREAD) join [Class$] c on c.[Id] = oi.[ObjClass]
			join [Field$] f on f.[Class] = c.[Id] and f.[Type] in (kcptReferenceCollection, kcptReferenceSequence)
	where	oi.[Uid] = @uid
		and ( oi.[RelType] in (kcptOwningAtom,kcptOwningCollection,kcptOwningSequence) or oi.[RelType] is null )
	group by oi.ObjClass, c.Name, f.Name, f.[Type]
	union all
	-- get the owned classes
	select	oi.ObjClass, 
		min(oi.InheritDepth) as InheritDepth, 
		max(oi.OwnerDepth) as OwnerDepth, 
		c.Name as DelClassName,
		NULL,
		6 as OrdrAndType
	from	ObjInfoTbl$ oi (REPEATABLEREAD) join Class$ c on oi.ObjClass = c.Id
	where	oi.[Uid] = @uid
		and ( oi.[RelType] in (kcptOwningAtom,kcptOwningCollection,kcptOwningSequence) or oi.[RelType] is null )
	group by oi.ObjClass, c.Name
	order by OrdrAndType, InheritDepth asc, OwnerDepth desc, DelClassName

	open Del_Cur
	fetch Del_Cur into @nObjClass, @nInheritDepth, @nOwnerDepth, @sDelClass, @sDelField, @nOrdrAndType

	while @@fetch_status = 0 begin
	
		-- classes that contain refence pointers to this class
		if @nOrdrAndType = 1 begin
			set @sQry='update ['+@sDelClass+'] set ['+@sDelField+']=NULL '+
				'from ['+@sDelClass+'] r '+
					'join [ObjInfoTbl$] oi (readuncommitted) on r.['+@sDelField+'] = oi.[ObjId] '
		end
		-- classes that contain sequence or collection references to this class
		else if @nOrdrAndType = 2 or @nOrdrAndType = 3 begin
			set @sQry='delete ['+@sDelClass+'_'+@sDelField+'] '+
				'from ['+@sDelClass+'_'+@sDelField+'] c '+
					'join [ObjInfoTbl$] oi (readuncommitted) on c.[Dst] = oi.[ObjId] '
		end
		-- classes that are referenced by this class's collection or sequence references
		else if @nOrdrAndType = 4 or @nOrdrAndType = 5 begin
			set @sQry='delete ['+@sDelClass+'_'+@sDelField+'] '+
				'from ['+@sDelClass+'_'+@sDelField+'] c '+
					'join [ObjInfoTbl$] oi (readuncommitted) on c.[Src] = oi.[ObjId] '
		end
		-- remove class data
		else if @nOrdrAndType = 6 begin
			set @sQry='delete ['+@sDelClass+'] '+ 
				'from ['+@sDelClass+'] o '+
					'join [ObjInfoTbl$] oi (readuncommitted) on o.[id] = oi.[ObjId] '
		end

		set @sQry = @sQry +
				'where oi.[ObjClass]='+convert(nvarchar(11),@nObjClass)+' '+
					'and oi.[Uid]='''+convert(varchar(250), @uid)+''''
		exec(@sQry)
		select @Err = @@error, @nRowCnt = @@rowcount

		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to execute dynamic SQL (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end

		fetch Del_Cur into @nObjClass, @nInheritDepth, @nOwnerDepth, @sDelClass, @sDelField, @nOrdrAndType
	end

	close Del_Cur
	deallocate Del_Cur

	--
	-- delete the objects in CmObject
	--
	delete CmObject
	from ObjInfoTbl$ do join CmObject co on do.[ObjId] = co.[id]

	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to remove the objects from the CmObject table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end

	-- determine if the ObjInfoTbl$ should be cleaned up
	if @fRemoveObjInfo = 1 begin 
		exec @Err=CleanObjInfoTbl$ @uid
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to remove rows from the ObjInfoTbl$ table (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
	end

	if @nTrnCnt = 0 commit tran DelObj$_Tran

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0

LFail:
	rollback tran DelObj$_Tran
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go

/*************************************************************************
 * CreateDeleteObj
 *
 * Description: 
 *	Creates a delete trigger for each object that deletes related 
 *	properties to the object. used on database creation, or when the
 *	object properties get changed.
 *
 * Parameters: 
 *	@nClassId = Class to create the trigger for
 *
 * Notes:
 *	Since this is a delete trigger, most of the object properties will
 *	go away with the record of this table. We still have to deal with:
 *
 *		1. References to this object
 *		2. string properties, stored in other tables
 *		3. properties in its parent class, stored in other tables
 *
 *	But before doing that, we must make sure the objects owned by this
 *	one go away.
 *
 *	The SERIALIZABLE locking hint sets these commands to the SERIALIZABLE
 *	transaction level. If we need greater concurrency, we may want to
 *	drop down to REPEATABLEREAD. See "Locking Hints" and "SET TRANSACTION
 *	LEVEL" on Books On Line (BOL).
 *************************************************************************/

IF OBJECT_ID('CreateDeleteObj') IS NOT NULL BEGIN
   	PRINT 'removing procedure CreateDeleteObj'
   	DROP PROC CreateDeleteObj
END
GO
PRINT 'creating procedure CreateDeleteObj'
GO

CREATE PROCEDURE CreateDeleteObj
	@nClassId INT
AS
	DECLARE
		@nvcObjClassName NVARCHAR(100),
		@nvcClassName NVARCHAR(100),
		@nFieldId INT,
		@nvcFieldName NVARCHAR(100),
		@nvcProcName NVARCHAR(120),  --( max possible size + a couple spare
		@nvcQuery1 VARCHAR(4000), --( 4000's not big enough; need more than 1 string
		@nvcQuery2 VARCHAR(4000),
		@nvcQuery3 VARCHAR(4000),
		@nvcQuery4 VARCHAR(4000),		
		@fBuildProc BIT, --( Currently all tables are getting one
		@nvcDropQuery NVARCHAR(140),
		@nvcObjName NVARCHAR(100),
		@nOwnedClassId INT,
		@nDebug TINYINT
	
	SET @nDebug = 0
	
	SELECT @nvcObjClassName = c.Name FROM Class$ c WHERE c.Id = @nClassId
	
	SET @fBuildProc = 0
	SET @nvcProcName = N'TR_' + @nvcObjClassName + N'_ObjDel_Del'
	SET @nvcQuery1 = ''
	SET @nvcQuery2 = ''
	SET @nvcQuery3 = ''
	SET @nvcQuery4 = ''
	
	--( The initial part of the CREATE TRIGGER command
	IF OBJECT_ID(@nvcProcName) IS NULL
		SET @nvcQuery1 = N'CREATE'
	ELSE
		SET @nvcQuery1 = N'ALTER'
	
	--( This assumes only one ID (row) in deleted
	
	SET @nvcQuery1 = @nvcQuery1 +
		N' TRIGGER ' + @nvcProcName + N' ON ' + @nvcObjClassName + CHAR(13) + 
		N'INSTEAD OF DELETE ' + CHAR(13) +
		N'AS ' + CHAR(13)
	IF @nDebug = 1
		SET @nvcQuery1 = @nvcQuery1 + 
			CHAR(9) + N'PRINT ''TRIGGER ' + @nvcProcName + 
				N' ON ' + @nvcObjClassName + N' INSTEAD OF DELETE ''' + CHAR(13) +
			CHAR(9) + CHAR(13)
	SET @nvcQuery1 = @nvcQuery1 +
		CHAR(9) + N'/* == This trigger generated by CreateDeleteObj == */ ' + CHAR(13) +
		CHAR(9) + CHAR(13) +
		CHAR(9) + N'DECLARE @nObjId INT ' + CHAR(13) +
		CHAR(9) + N'SELECT @nObjId = d.[Id] FROM deleted d' + CHAR(13) +
		CHAR(9) + CHAR(13)
	
	--==( Delete references *to* this object )==--
	
	--( atomic references to this object
	
	SELECT TOP 1 @nFieldId = f.Id, @nvcClassName = c.Name, @nvcFieldName = f.Name
	FROM Field$ f
	JOIN Class$ c ON c.Id = f.Class
	WHERE f.DstCls = @nClassId AND f.Type = 24
	ORDER BY f.Id
	
	IF @@ROWCOUNT != 0 BEGIN
		SET @fBuildProc = 1
 		SET @nvcQuery1 = @nvcQuery1 + CHAR(9) + 
			'/* Delete atomic references *to* this object */ ' + CHAR(13) +
			CHAR(9) + CHAR(13)
	END	
	WHILE @@ROWCOUNT != 0 BEGIN
		SET @nvcQuery1 = @nvcQuery1 + 
			CHAR(9) + N'UPDATE ' + @nvcClassName + N' WITH (SERIALIZABLE) ' + CHAR(13) + 
			CHAR(9) + N'SET [' + @nvcFieldName + N'] = NULL ' + CHAR(13) +
			CHAR(9) + N'WHERE [' + @nvcFieldName + N'] = @nObjId ' + CHAR(13) +
			CHAR(9) + CHAR(13)
		
		SELECT TOP 1 @nFieldId = f.Id, @nvcClassName = c.Name, @nvcFieldName = f.Name
		FROM Field$ f
		JOIN Class$ c ON c.Id = f.Class
		WHERE f.Id > @nFieldId AND f.DstCls = @nClassId AND f.Type = 24
		ORDER BY f.Id			
	END
	
	--( collection and sequence refences
	
	SELECT TOP 1 @nFieldId = f.Id, @nvcClassName = c.Name, @nvcFieldName = f.Name
	FROM Field$ f
	JOIN Class$ c ON c.Id = f.Class
	WHERE f.DstCls = @nClassId AND f.Type IN (26, 28)
	ORDER BY f.Id
	
	IF @@ROWCOUNT != 0 BEGIN
		SET @fBuildProc = 1
 		SET @nvcQuery2 = @nvcQuery2 + CHAR(9) + 
			'/* Delete collection and sequence references *to* this object */ ' + CHAR(13) +
			CHAR(9) + CHAR(13)
	END	
	WHILE @@ROWCOUNT != 0 BEGIN
		SET @nvcQuery2 = @nvcQuery2 + 
			CHAR(9) + N'DELETE ' + @nvcClassName + N'_' + @nvcFieldName + N' WITH (SERIALIZABLE) ' + CHAR(13) +
			CHAR(9) + N'WHERE [Dst] = @nObjId ' + CHAR(13) +
			CHAR(9) + CHAR(13)
		
		SELECT TOP 1 @nFieldId = f.Id, @nvcClassName = c.Name, @nvcFieldName = f.Name
		FROM Field$ f
		JOIN Class$ c ON c.Id = f.Class
		WHERE f.Id > @nFieldId AND f.DstCls = @nClassId AND f.Type IN (26, 28)
		ORDER BY f.Id			
	END
		
	--==( Delete references *of* this object )==--
	
	--( Atomic references will get wiped out autmatically when this record
	--( goes away.
	
	--( Collection and Sequence refences
	
	SELECT TOP 1 @nFieldId = f.Id, @nvcClassName = c.Name, @nvcFieldName = f.Name
	FROM Field$ f
	JOIN Class$ c ON c.Id = f.Class
	WHERE f.Class = @nClassId AND f.Type IN (26, 28)
	ORDER BY f.Id
	
	IF @@ROWCOUNT != 0 BEGIN
		SET @fBuildProc = 1
 		SET @nvcQuery3 = @nvcQuery3 + CHAR(9) + 
			'/* Delete references *of* this object */ ' + CHAR(13) +
			CHAR(9) + CHAR(13)
	END	
	WHILE @@ROWCOUNT != 0 BEGIN
		SET @nvcQuery3 = @nvcQuery3 + 
			CHAR(9) + N'DELETE ' + @nvcClassName + N'_' + @nvcFieldName + N' WITH (SERIALIZABLE) ' + CHAR(13) +
			CHAR(9) + N'WHERE [Src] = @nObjId ' + CHAR(13) +
			CHAR(9) + CHAR(13)
		
		SELECT TOP 1 @nFieldId = f.Id, @nvcClassName = c.Name, @nvcFieldName = f.Name
		FROM Field$ f
		JOIN Class$ c ON c.Id = f.Class
		WHERE f.Id > @nFieldId AND f.Class = @nClassId AND f.Type IN (26, 28)
		ORDER BY f.Id			
	END
	
	--==( Delete strings of this object )==--
		
	SET @nvcQuery4 = @nvcQuery4 + 
		CHAR(9) + N'/* Delete any strings of this object */ ' + CHAR(13) + 
		CHAR(9) + CHAR(13)
	
	--( If any MultiStr$ properties, create delete code.
	SELECT TOP 1 @nFieldId = Id FROM Field$ WHERE Class = @nClassId AND Type = 14
	IF @@ROWCOUNT != 0 BEGIN
		SET @fBuildProc = 1
		SET @nvcQuery4 = @nvcQuery4 + 
			CHAR(9) + N'DELETE MultiStr$ WITH (SERIALIZABLE) ' + CHAR(13) + 
			CHAR(9) + N'WHERE [Obj] = @nObjId ' + CHAR(13) + 
			CHAR(9) + CHAR(13)
	END
	
	--( If any MultiTxt$ properties, create delete code.
	SELECT TOP 1 @nFieldId = f.ID, @nvcClassName = c.Name, @nvcFieldName = f.Name
	FROM Field$ f
	JOIN Class$ c ON c.ID = f.Class
	WHERE f.Class = @nClassId AND f.Type = 16
	ORDER BY f.Id
	
	WHILE @@ROWCOUNT != 0 BEGIN
		SET @fBuildProc = 1
		SET @nvcQuery4 = @nvcQuery4 + 
			CHAR(9) + N'DELETE ' + @nvcClassName + N'_' + @nvcFieldName + N' WITH (SERIALIZABLE) ' + CHAR(13) +
			CHAR(9) + N'WHERE [Obj] = @nObjId ' + CHAR(13) +
			CHAR(9) + CHAR(13)
		
		SELECT TOP 1 @nFieldId = f.Id, @nvcClassName = c.Name, @nvcFieldName = f.Name
		FROM Field$ f
		JOIN Class$ c ON c.Id = f.Class
		WHERE f.ID > @nFieldId AND f.Class = @nClassId AND f.Type = 16
		ORDER BY f.Id
	END
	
	--( If any MultiBigStr$ properties, create delete code.
	
	SELECT TOP 1 @nFieldId = Id FROM Field$ WHERE Class = @nClassId AND Type = 18
	IF @@ROWCOUNT != 0 BEGIN
		SET @fBuildProc = 1
		SET @nvcQuery4 = @nvcQuery4 + 
			CHAR(9) + N'DELETE MultiBigStr$ WITH (SERIALIZABLE) ' + CHAR(13) + 
			CHAR(9) + N'WHERE [Obj] = @nObjId ' + CHAR(13) + 
			CHAR(9) + CHAR(13)
	END
	
	--( If any MultiBigTxt$ properties, create delete code.
	
	SELECT TOP 1 @nFieldId = Id FROM Field$ WHERE Class = @nClassId AND Type = 20
	IF @@ROWCOUNT != 0 BEGIN
		SET @fBuildProc = 1
		SET @nvcQuery4 = @nvcQuery4 + 
			CHAR(9) + N'DELETE MultiBigTxt$ WITH (SERIALIZABLE) ' + CHAR(13) + 
			CHAR(9) + N'WHERE [Obj] = @nObjId ' + CHAR(13) + 
			CHAR(9) + CHAR(13)
	END
	
	--==( Delete this row, since this is an DELETE INSTEAD OF trigger )==--
	
	SET @fBuildProc = 1
	SET @nvcQuery4 = @nvcQuery4 +
		CHAR(9) + N'/* Delete this row (for INSTEAD OF DELETE trigger) */ ' + CHAR(13) +
		CHAR(9) + CHAR(13)
	SET @nvcQuery4 = @nvcQuery4 + 
		CHAR(9) + N'DELETE ' + @nvcObjClassName + N' WITH (SERIALIZABLE) ' + CHAR(13) +
		CHAR(9) + N'WHERE [Id] = @nObjId ' + CHAR(13) +
		CHAR(9) + CHAR(13)	
	
	--==( Delete properties in parent class )==--
	
	--( This will delete properties *only* in the parent class,
	--( because the parent class will have the same call to
	--( delete properties in *its* parent class. The parent
	--( class has a depth of 1.
	
 	SELECT @nvcClassName = c.Name
 	FROM ClassPar$ cp
 	JOIN Class$ c ON c.Id = cp.Dst
 	WHERE cp.Src = @nClassId AND cp.Depth = 1
 	
 	IF @@ROWCOUNT = 1 BEGIN	--( should only be CmObject that misses
 		SET @fBuildProc = 1
 		SET @nvcQuery4 = @nvcQuery4 + 
 			CHAR(9) + N'/* Delete properties in parent class */' + CHAR(13) + 
 			CHAR(9) + CHAR(13)
 		SET @nvcQuery4 = @nvcQuery4 + 
 			CHAR(9) + N'DELETE ' + @nvcClassName + N' WITH (SERIALIZABLE) ' + CHAR(13) + 
			CHAR(9) + N'WHERE [Id] = @nObjId ' + CHAR(13) + 
 			CHAR(9) + CHAR(13)
 	END
	
	--==( Create the new trigger )==--
	
	IF @fBuildProc = 1 BEGIN
		IF @nDebug = 1 BEGIN
			PRINT '---- query1 ----'
			PRINT @nvcQuery1
			PRINT CHAR(9) + '---- query2 ----'
			PRINT @nvcQuery2
			PRINT CHAR(9) + '---- query3 ----'
			PRINT @nvcQuery3
			PRINT CHAR(9) + '---- query4 ----'
			PRINT @nvcQuery4
		END
		
		EXECUTE (@nvcQuery1 + @nvcQuery2 + @nvcQuery3 + @nvcQuery4)
	END
GO

/*************************************************************************
 * DeleteObjects
 *
 * Description: 
 *	Deletes objects and their owned objects. It also removes references
 *	to the object(s).
 *
 * Parameters: 
 *	@ntIds	= A Unicode string that has either a comma delimited list of
 *				IDs, or an XML string of IDs. See fnGetIdsFromString for
 *				more on the structure of the XML doc.
 *	@nXmlIdsHandle = An integer for a handle to an XML doc. Either this
 *				parameter or the other must be used. Not both.
 *
 * Notes:
 *	Before an object can be deleted, references to it must be deleted.
 *	But before that, the objects that this object owns must be deleted.
 *
 *	This procedure depends on delete triggers that are created by
 *	CreateDeleteObj. It also uses fnGetIdsFromString with XML docs.
 *************************************************************************/

IF OBJECT_ID('DeleteObjects') IS NOT NULL BEGIN
   	PRINT 'removing procedure DeleteObjects'
   	DROP PROC DeleteObjects
END
GO
PRINT 'creating procedure DeleteObjects'
GO

CREATE PROCEDURE DeleteObjects
	@ntIds NTEXT = NULL,
	@nXmlIdsParam INT = NULL
AS
	DECLARE @tIds TABLE (ID INT, ClassName NVARCHAR(100), Level TINYINT)
	
	DECLARE
		@hXmlIds INT,
		@nRowCount INT,
		@nObjId INT,
		@nLevel INT,
		@nvcClassName NVARCHAR(100),
		@nvcSql NVARCHAR(1000),
		@nError INT
	
	SET @nError = 0
	
	IF (@ntIds IS NULL AND @nXmlIdsParam IS NULL) OR (@ntIds IS NOT NULL AND @nXmlIdsParam IS NOT NULL)
		GOTO Fail
	
	--==( Load Ids )==--
	
	--( If we're working with an XML doc:
	--Note: (JohnT): The identifier in the With clauses of the OPENXML is CASE SENSITIVE!!
	IF @nXmlIdsParam IS NOT NULL BEGIN
		INSERT INTO @tIds
		SELECT f.ID, c.Name, 0
		FROM OPENXML(@nXmlIdsParam, '/root/Obj') WITH (Id INT) f
		JOIN CmObject o ON o.ID = f.ID
		JOIN Class$ c ON c.ID = o.Class$
	END
	--( If we're working with an XML string:
	ELSE IF SUBSTRING(@ntIds, 1, 1) = '<' BEGIN
		EXECUTE sp_xml_preparedocument @hXmlIds OUTPUT, @ntIds
		
		INSERT INTO @tIds
		SELECT f.ID, f.ClassName, 0
		FROM dbo.fnGetIdsFromString(@ntIds, @hXmlIds) AS f
		
		EXECUTE sp_xml_removedocument @hXmlIds
	END
	--( If we're working with a comma delimited list
	ELSE
		INSERT INTO @tIds
		SELECT f.ID, f.ClassName, 0
		FROM dbo.fnGetIdsFromString(@ntIds, NULL) AS f
	
	--( Now find owned objects
	
	SET @nLevel = 1
	
	INSERT INTO @tIds
	SELECT o.ID, c.Name, @nLevel
	FROM @tIds t
	JOIN CmObject o ON o.Owner$ = t.Id
	JOIN Class$ c ON c.ID = o.Class$
	
	SET @nRowCount = @@ROWCOUNT
	WHILE @nRowCount != 0 BEGIN
		SET @nLevel = @nLevel + 1
		
		INSERT INTO @tIds
		SELECT o.ID, c.Name, @nLevel
		FROM @tIds t
		JOIN CmObject o ON o.Owner$ = t.Id
		JOIN Class$ c ON c.ID = o.Class$
		WHERE t.Level = @nLevel - 1
		
		SET @nRowCount = @@ROWCOUNT
	END
	SET @nLevel = @nLevel - 1
	
	--==( Delete objects )==--
	
	--( We're going to start out at the leaves and work
	--( toward the trunk.
	
	WHILE @nLevel >= 0	BEGIN
		
		SELECT TOP 1 @nObjId = t.ID, @nvcClassName = t.ClassName
		FROM @tIds t
		WHERE t.Level = @nLevel
		ORDER BY t.Id
				
		SET @nRowCount = @@ROWCOUNT
		WHILE @nRowCount = 1 BEGIN
			SET @nvcSql = N'DELETE ' + @nvcClassName + N' WHERE Id = @nObjectID'
			EXEC sp_executesql @nvcSql, N'@nObjectID INT', @nObjectId = @nObjId
			SET @nError = @@ERROR
			IF @nError != 0
				GOTO Fail
			
			SELECT TOP 1 @nObjId = t.ID, @nvcClassName = t.ClassName
			FROM @tIds t
			WHERE t.Id > @nobjId AND t.Level = @nLevel
			ORDER BY t.ID
			
			SET @nRowCount = @@ROWCOUNT
		END
		
		SET @nLevel = @nLevel - 1
	END
		
	RETURN 0

Fail:
	RETURN @nError
GO

/***********************************************************************************************
	Stored procedures for managing collections and sequences.
***********************************************************************************************/


/***********************************************************************************************
 * DefineReplaceRefCollProc$
 *
 * Description: 
 *	Creates the procedures that handle reference collections for a particular table
 *
 * Parameters:	
 *	@sTbl = the name of the reference sequence joiner table
 *
 * Returns:
 *	0 if successful, otherwise the appropriate error code
 **********************************************************************************************/
if object_id('DefineReplaceRefCollPrc$') is not null begin
	print 'removing proc DefineReplaceRefCollProc$'
	drop proc [DefineReplaceRefCollProc$]
end
go
print 'Creating proc DefineReplaceRefCollProc$'
go
create proc [DefineReplaceRefCollProc$]
	@sTbl sysname
as
	declare @sDynSql nvarchar(4000), @sDynSql2 nvarchar(4000)
	declare @err int

	if object_id('ReplaceRefColl_' + @sTbl ) is not null begin
		set @sDynSql = 'alter '
	end
	else begin
		set @sDynSql = 'create '
	end

set @sDynSql = @sDynSql + N'
proc ReplaceRefColl_' + @sTbl +'
	@SrcObjId int,
	@hXMLDocInsert int = null,
	@hXMLDocDelete int = null,
	@fRemoveXMLDocs tinyint = 1
as
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @sTranName varchar(300)
	declare @i int, @RowsAffected int

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--	otherwise create a transaction
	set @sTranName = ''ReplaceRef$_'+@sTbl+''' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to create a transaction'', 16, 1, @Err)
		goto LCleanup
	end

	-- determine if any object references should be removed
	if @hXMLDocDelete is not null begin
		-- objects may be listed in a collection more than once, and the delete list specifies how many
		--	occurrences of an object need to be removed; the above delete however removed all occurences,
		--	so the appropriate number of certain objects may need to be added back in

		-- create a temporary table to hold objects that are referenced more than once and at least one
		--	of the references is to be removed
		declare @t table (
			DstObjId int,
			Occurrences int,
			DelOccurrences int
		)
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to create a temporary table'', 16, 1, @Err)
			goto LCleanup
		end

		-- get the objects that are referenced more than once along with the actual number of references; do this
		--	only for the objects where at least one reference is going to be removed
		insert into @t (DstObjId, DelOccurrences, Occurrences)
		select	jt.[Dst], ol.[DelCnt], count(*)
		from	['+@sTbl+'] jt (REPEATABLEREAD)
			join (
				select	[Id] ObjId, count(*) DelCnt
				from	openxml(@hXMLDocDelete, ''/root/Obj'') with ([Id] int)
				group by [Id]
			) as ol on jt.[Dst] = ol.[ObjId]
		where	jt.[Src] = @SrcObjid
		group by jt.[Dst], ol.[DelCnt]
		having count(*) > 1
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to insert objects that are referenced more than once: SrcObjId(src) = %d'', 
					16, 1, @Err, @SrcObjId)
			goto LCleanup
		end
'
set @sDynSql2 = N'
		-- remove the object references
		-- for some reason the preferable DELETE...FROM query generates server exceptions when the openxml statement is
		--	used, so the only alternative is to use IN (...)
		delete	['+@sTbl+']
		where	[Src] = @SrcObjId
			and [Dst] in (
				select	[Id]
				from	openxml(@hXMLDocDelete, ''/root/Obj'') with ([Id] int)
			)
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to delete objects from a reference collection: SrcObjId(src) = %d'', 
					16, 1, @Err, @SrcObjId)
			goto LCleanup
		end

		-- reinsert the appropriate number of objects that had multiple references
		set @i = 0
		set @RowsAffected = 1 -- set to 1 to get inside of the loop
		while @RowsAffected > 0 begin
			insert into ['+@sTbl+'] with (REPEATABLEREAD) ([Src], [Dst])
			select	@SrcObjid, [DstObjId]
			from	@t
			where	Occurrences - DelOccurrences > @i
			select @Err = @@error, @RowsAffected = @@rowcount
			if @Err <> 0 begin
				raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to reinsert objects into a reference collection: SrcObjId(src) = %d'', 
						16, 1, @Err, @SrcObjId)
				goto LCleanup
			end
			set @i = @i + 1
		end

	end

	-- determine if any object references should be inserted
	if @hXMLDocInsert is not null begin

		insert into ['+@sTbl+'] with (REPEATABLEREAD) ([Src], [Dst])
		select	@SrcObjId, ol.[Id]
		from	openxml(@hXMLdocInsert, ''/root/Obj'') with (Id int) as ol
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to insert objects into a reference collection: SrcObjId(src) = %d'', 
					16, 1, @Err, @SrcObjId)
			goto LCleanup
		end
	end	

LCleanup:
	if @Err <> 0 rollback tran @sTranName
	else if @nTrnCnt = 0 commit tran @sTranName

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- determine if the XML documents should be removed
	if @fRemoveXMLDocs = 1 begin
		if @hXMLdocInsert is not null exec sp_xml_removedocument @hXMLdocInsert
		if @hXMLdocDelete is not null and @hXMLdocDelete <> @hXMLdocInsert exec sp_xml_removedocument @hXMLdocDelete
	end

	return @Err
'

	exec ( @sDynSql + @sDynSql2 )
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('DefineReplaceRefCollProc: SQL Error %d: Unable to create or alter the procedure ReplaceRefColl_%s$',
				16, 1, @Err, @sTbl)
		return @err
	end

	return 0
go


/***********************************************************************************************
 * ReplaceRefColl$
 *
 * Description: General procedure that calls the appropriate ReplaceRefColl_ procedure
 *
 * Parameters:	
 *	@flid = the FLID of the field that contains the reference sequence relationship
 *	@SrcObjId = the id of the object that contains the reference sequence relationship
 *	@hXMLDocInsert = prepared XML document handle for the list of insert reference objects
 *	@hXMLDocDelete = prepared XML document handle for the list of delete reference objects
 *	@fRemoveXMLDocs = flag that determines if the prepared XML documents should be removed 
 *		from memory/cache (defaults to true)
 *
 * Returns:	
 *	0 if successful, otherwise the appropriate error code
 *
 * Example:
 *	declare @hdocIns int, @hdocDel int
 *	-- prepare the XML documents and get their corresponding handles
 *	exec sp_xml_preparedocument @hdocIns output, 
 *	'<root><Obj Id="1771"/><Obj Id="1772"/></root>'
 *	exec sp_xml_preparedocument @hdocDel output, 
 *	'<root><Obj Id="1773"/><Obj Id="1774"/></root>'
 *	exec ReplaceRefColl_CmPossibility_Researchers 185, @hdocIns, @hdocDel
 **********************************************************************************************/
if object_id('ReplaceRefColl$') is not null begin
	print 'removing proc ReplaceRefColl$'
	drop proc [ReplaceRefColl$]
end
go
print 'creating proc ReplaceRefColl$'
go
create proc [ReplaceRefColl$]
	@flid int,
	@SrcObjId int,
	@hXMLDocInsert int = null,
	@hXMLDOcDelete int = null,
	@fRemoveXMLDocs tinyint = 1
as
	declare @Err int
	declare	@sDynSql varchar(500)

	select	@sDynSql = 'exec ReplaceRefColl_' + c.[Name] + '_' + f.[Name] + ' ' +
			coalesce(convert(varchar(11), @SrcObjId), 'null') + ',' +
			coalesce(convert(varchar(11), @hXMLDocInsert), 'null') + ',' +
			coalesce(convert(varchar(11), @hXMLDOcDelete), 'null') + ',' +
			coalesce(convert(varchar(3), @fRemoveXMLDocs), 'null')
	from	Field$ f join Class$ c on f.[Class] = c.[Id]
	where	f.[Id] = @flid and f.[Type] = kcptReferenceCollection

	if @@rowcount <> 1 begin
		raiserror('ReplaceRefColl$: Invalid flid: %d', 16, 1, @flid)
		return 50000
	end

	exec (@sDynSql)
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('ReplaceRefColl$: SQL Error %d: Unable to perform replace: %d', 16, 1, @Err, @sDynSql)
		return @Err
	end

	return 0
go


/***********************************************************************************************
 * ReplaceRefSeqProc$
 *
 * Description: 
 *	Creates the procedure that handles reference sequences for a particular table
 *
 * Parameters:	
 *	@sTbl = the name of the reference sequence joiner table
 *	@flid = the field ID of the field that contains the reference sequence relationship
 *
 * Returns:
 *	0 if successful, otherwise the appropriate error code
 **********************************************************************************************/
if object_id('DefineReplaceRefSeqProc$') is not null begin
	print 'removing proc DefineReplaceRefSeqProc$'
	drop proc [DefineReplaceRefSeqProc$]
end
go
print 'Creating proc DefineReplaceRefSeqProc$'
go
create proc [DefineReplaceRefSeqProc$]
	@sTbl sysname,
	@flid int
as
	declare @sDynSql nvarchar(4000), @sDynSql2 nvarchar(4000), @sDynSql3 nvarchar(4000), @sDynSql4 nvarchar(4000)
	declare @err int

	if object_id('ReplaceRefSeq_' + @sTbl) is not null begin
		set @sDynSql = 'alter '
	end
	else begin
		set @sDynSql = 'create '
	end

set @sDynSql = @sDynSql +
N'proc ReplaceRefSeq_' + @sTbl +'
	@SrcObjId int,
	@ListStmp int,
	@hXMLdoc int = null,
	@StartObj int = null,
	@StartObjOccurrence int = 1,
	@EndObj int = null,
	@EndObjOccurrence int = 1,
	@fRemoveXMLdoc tinyint = 1
as
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @sTranName varchar(300)
	declare @nNumObjs int, @iCurObj int, @nMinOrd int, @StartOrd int, @EndOrd int
	declare @nSpaceAvail int
	declare @UpdStmp int

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
'
/*
	Cannot do this until SeqStmp$ is enabled.
	select @UpdStmp = [UpdStmp] from SeqStmp$ where [Src] = @SrcObjId and [Flid] = ' + convert(varchar(11), @flid) + '
	if @UpdStmp is not null and @ListStmp <> @UpdStmp begin
		raiserror(''The sequence list in '+@sTbl+' has been modified: SrcObjId = %d SrcFlid = ' + convert(varchar(11), @flid) + '.'', 
				16, 1, @SrcObjId)
		return 50000
	end
*/
set @sDynSql = @sDynSql +
N'
	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--	otherwise create a transaction
	set @sTranName = ''ReplaceRefSeq_'+@sTbl+''' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to create a transaction'', 16, 1, @Err)
		goto LFail
	end

	-- get the starting and ending ordinal values
	set @EndOrd = null
	set @StartOrd = null
	if @StartObj is null begin
		-- since the @StartObj is null the list of objects should be added to the end of the sequence, so
		--	get the maximum ord value and add 1
		select	@StartOrd = coalesce(max([Ord]), 0) + 1
		from	['+@sTbl+'] with (REPEATABLEREAD)
		where	[Src] = @SrcObjId
	end
	else begin
		-- create a temporary table to hold all of the ord values associated with Src=@SrcObjId and (Dst=
		--	@StartObj or Dst=@EndObj); this table will have an identity column so subsequent queries
		--	can easily determine which ord value is associated with a particular position in a sequence
		declare @t table (
			Occurrence int identity(1,1),
			IsStart	tinyint,
			Ord int
		)

'
set @sDynSql2 = N'			
		-- determine if an end object was not specified, or if the start and end object are the same
		if @EndObj is null or (@EndObj = @StartObj) begin
			-- only collect occurrences for the start object

			-- limit the number of returned rows from a select based on the desired occurrence; this will
			--	avoid processing beyond the desired occurrence
			if @EndObj is null set rowcount @StartObjOccurrence
			else set rowcount @EndObjOccurrence

			-- insert all of the Ord values associated with @StartObj
			insert into @t (IsStart, Ord)
			select	1, [Ord]
			from	[' + @sTbl + '] (readuncommitted)
			where	[Src] = @SrcObjId
				and [Dst] = @StartObj
			order by [Ord]
			set @Err = @@error
			if @Err <> 0 begin
				raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to insert ord values into the temporary table'', 16, 1, @Err)
				goto LFail
			end

			-- make selects return all rows
			set rowcount 0

			-- determine if the end and start objects are the same; if they are then search for the
			--	end object''s ord value based on the specified occurrence
			if @EndObj = @StartObj begin
				select	@EndOrd = [Ord]
				from	@t
				where	[Occurrence] = @EndObjOccurrence
			end
		end
		else begin
			-- insert Ord values associated with @StartObj and @EndObj
			insert into @t ([IsStart], [Ord])
			select	case [Dst]
					when @StartObj then 1
					else 0
				end, 
				[Ord]
			from	[' + @sTbl + '] (readuncommitted)
			where	[Src] = @SrcObjId
				and ( [Dst] = @StartObj
					or [Dst] = @EndObj )
			order by 1 desc, [Ord]
			set @Err = @@error
			if @Err <> 0 begin
				raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to insert ord values into the temporary table'', 16, 1, @Err)
				goto LFail
			end
			
			-- get the end ord value associated with @EndObjOccurrence
			select	@EndOrd = [Ord]
			from	@t
			where	[IsStart] = 0
				and [Occurrence] = @EndObjOccurrence +
					( select max([Occurrence]) from @t where [IsStart] = 1 )
		end

		-- get the start ord value associated with @StartObjOccurrence
		select	@StartOrd = [Ord]
		from	@t
		where	[IsStart] = 1
			and [Occurrence] = @StartObjOccurrence

	end
'
set @sDynSql3 = N'
	-- validate the arguments
	if @StartOrd is null begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': Unable to locate ordinal value: SrcObjId(Src) = %d, StartObj(Dst) = %d, StartObjOccurrence = %d'', 
				16, 1, @SrcObjId, @StartObj, @StartObjOccurrence)
		set @Err = 50001
		goto LFail
	end
	if @EndOrd is null and @EndObj is not null begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': Unable to locate ordinal value: SrcObjId(Src) = %d, EndObj(Dst) = %d, EndObjOccurrence = %d'', 
				16, 1, @SrcObjId, @EndObj, @EndObjOccurrence)
		set @Err = 50002
		goto LFail
	end
	if @EndOrd is not null and @EndOrd < @StartOrd begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': The starting ordinal value %d is greater than the ending ordinal value %d: SrcObjId(Src) = %d, StartObj(Dst) = %d, StartObjOccurrence = %d, EndObj(Dst) = %d, EndObjOccurrence = %d'', 
				16, 1, @StartOrd, @EndOrd, @SrcObjId, @StartObj, @StartObjOccurrence, @EndObj, @EndObjOccurrence)
		set @Err = 50003
		goto LFail
	end

	-- check for a delete/replace
	if @EndObj is not null begin
		
		delete	[' + @sTbl + '] with (REPEATABLEREAD)
		where	[Src] = @SrcObjId
			and [Ord] >= @StartOrd
			and [Ord] <= @EndOrd
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to remove objects between %d and %d for source = %d'', 
					16, 1, @Err, @StartOrd, @EndOrd, @SrcObjId)
			goto LFail
		end
	end

	-- determine if any objects are going to be inserted
	if @hXMLDoc is not null begin
		-- get the number of objects to be inserted
		select	@nNumObjs = count(*)
		from 	openxml(@hXMLdoc, ''/root/Obj'') with (Id int)
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to process XML document: document handle = %d'', 
					16, 1, @hXMLdoc)
			goto LFail
		end
'
set @sDynSql4 = N'
		-- if the objects are not appended to the end of the list then determine if there is enough room
		if @StartObj is not null begin

			-- find the largest ordinal value less than the start object''s ordinal value
			select	@nMinOrd = coalesce(max([Ord]), -1) + 1
			from	['+@sTbl+'] with (REPEATABLEREAD)
			where	[Src] = @SrcObjId
				and [Ord] < @StartOrd

			-- determine if a range of objects was deleted; if objects were deleted then there is more room
			--	available
			if @EndObj is not null begin
				-- the actual space available could be determined, but this would involve another
				--	query (this query would look for the minimum Ord value greater than @EndOrd); 
				--	however, it is known that at least up to the @EndObj is available

				set @nSpaceAvail = @EndOrd - @nMinOrd
				if @nMinOrd > 0 set @nSpaceAvail = @nSpaceAvail + 1
			end
			else begin
				set @nSpaceAvail = @StartOrd - @nMinOrd
			end

			-- determine if space needs to be made
			if @nSpaceAvail < @nNumObjs begin
				update	[' + @sTbl + '] with (REPEATABLEREAD)
				set	[Ord] = [Ord] + @nNumObjs - @nSpaceAvail
				where	[Src] = @SrcObjId
					and [Ord] >= @nMinOrd
				set @Err = @@error
				if @Err <> 0 begin
					raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to increment the ordinal values; src = %d'', 
							16, 1, @Err, @SrcObjId)
					goto LFail
				end
			end
		end
		else begin
			-- find the largest ordinal value plus one
			select	@nMinOrd = coalesce(max([Ord]), -1) + 1
			from	['+@sTbl+'] with (REPEATABLEREAD)
			where	[Src] = @SrcObjId
		end

		insert into [' + @sTbl + '] with (REPEATABLEREAD) ([Src], [Dst], [Ord])
		select	@SrcObjId, ol.[Id], ol.[Ord] + @nMinOrd
		from 	openxml(@hXMLdoc, ''/root/Obj'') with (Id int, Ord int) ol
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to insert objects into the reference sequence table'', 
					16, 1, @Err)
			goto LFail
		end
	end

	if @nTrnCnt = 0 commit tran @sTranName

	-- determine if the XML document should be removed
	if @fRemoveXMLdoc = 1 and @hXMLDoc is not null exec sp_xml_removedocument @hXMLDoc

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0

LFail:
	rollback tran @sTranName

	-- determine if the XML document should be removed
	if @fRemoveXMLdoc = 1 and @hXMLDoc is not null exec sp_xml_removedocument @hXMLDoc

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
'

	exec ( @sDynSql + @sDynSql2 + @sDynSql3 + @sDynSql4 )
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('DefineReplaceRefSeqProc: SQL Error %d: Unable to create or alter the procedure ReplaceRefSeq_%s$',
				16, 1, @Err, @sTbl)
		return @err
	end

	return 0
go


/***********************************************************************************************
 * ReplaceRefSeq$
 *
 * Description: 
 *	General procedure that calls the appropriate ReplaceRefSeq_ procedure
 *
 * Parameters:	
 *	@flid = the FLID of the field that contains the reference sequence relationship
 *	@SrcObjId = the id of the object that contains the reference sequence relationship
 *	@ListStmp = the timestamp value associated with the sequence list when it was first
 *		read from the database
 *	@hXMLdoc = prepared XML document handle
 *	@StartObj = where the inserted objects should be placed before; if null then the objects
 *		will be appended to the end of the list and no objects will be deleted/replaced
 *	@StartObjOccurrence = the occurrence of the StartObj where the inserted objects should
 *		be placed
 *	@EndObj = the last object in the list of objects that is to be removed; if null
 *		no objects will be deleted/replaced
 *	@EndObjOccurrence = the occurrence of the EndObj that indicates the last object that
 *		is to be removed
 *	@fRemoveXMLDoc = flag that determines if the prepared XML documents should be removed 
 *		from memory/cache (default is true)
 *
 * Returns:
 *	0 if successful, otherwise the appropriate error code
 *
 * Example:
 *	declare @hdoc int
 *	-- prepare an XML document and get its handle
 *	exec sp_xml_preparedocument @hdoc output, 
 *	'<root><Obj Id="4708" Ord="0"/><Obj Id="4708" Ord="1"/><Obj Id="4708" Ord="2"/>
 *	<Obj Id="4708" Ord="3"/></root>'
 *	-- call the generic ReplaceRefSeq$ procedure
 *	exec ReplaceRefSeq$ 6001019, 1, null, @hdoc, 4710, 1, null, null
 **********************************************************************************************/
if object_id('ReplaceRefSeq$') is not null begin
	print 'removing proc ReplaceRefSeq$'
	drop proc [ReplaceRefSeq$]
end
go
print 'creating proc ReplaceRefSeq$'
go
create proc [ReplaceRefSeq$]
	@flid int,
	@SrcObjId int,
	@ListStmp int,
	@hXMLdoc int,
	@StartObj int = null,
	@StartObjOccurrence int = 1,
	@EndObj int = null,
	@EndObjOccurrence int = 1,
	@fRemoveXMLDoc tinyint = 1
as
	declare @Err int
	declare	@sDynSql varchar(500)

	select	@sDynSql = 'exec ReplaceRefSeq_' + c.[Name] + '_' + f.[Name] + ' ' +
			coalesce(convert(varchar(11), @SrcObjId), 'null') + ',' +
			coalesce(convert(varchar(11), @ListStmp), 'null') + ',' +
			coalesce(convert(varchar(11), @hXMLdoc), 'null') + ',' +
			coalesce(convert(varchar(11), @StartObj), 'null') + ',' +
			coalesce(convert(varchar(11), @StartObjOccurrence), 'null') + ',' +
			coalesce(convert(varchar(11), @EndObj), 'null') + ',' +
			coalesce(convert(varchar(11), @EndObjOccurrence), 'null') + ',' +
			coalesce(convert(varchar(3), @fRemoveXMLDoc), 'null')
	from	Field$ f join Class$ c on f.[Class] = c.[Id]
	where	f.[Id] = @flid and f.[Type] = kcptReferenceSequence

	if @@rowcount <> 1 begin
		raiserror('ReplaceRefSeq$: Invalid flid: %d', 16, 1, @flid)
		return 50000
	end

	exec (@sDynSql)
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('ReplaceRefSeq$: SQL Error %d: Unable to perform replace: %d', 16, 1, @Err, @sDynSql)
		return @Err
	end

	return 0
go


DbgNuke(MoveToOwnedAtom$, proc)
go
print 'creating proc MoveToOwnedAtom$'
go

----------------------------------------------------------------------------------------------------
--( MoveToOwnedAtom$
----------------------------------------------------------------------------------------------------
--( Responsibility:	S. A. Miller, previously Jonathan Richards
--( Last Reviewed:
--( 
--( Description:
--( 	Moves an object to an atomic object
--( 
--( Parameters:
--( 	@ObjId int,	-- The ID of the object to be moved.
--( 	@DstObjId int,		-- The ID of the object which will own the object(s) moved
--( 	@DstFlid int		-- The FLID (field ID) of the object attribute that will own the object(s)
--( 
--( Returns:
--( 	0 if successful, otherwise appropriate error code.
--( 	
--( Notes:
--( 	MoveOwnedSeq, from which this procedure originated, had the capability
--( 	to replace a set of objects in the target list. This functionaltfy is no longer
--( 	supported.
--( 
--( 	Copied and modified from MoveToOwnedColl$
--( 	
--( Example Call:
--( 	Currently (June 2001) this is called from the stored procedure MoveOwnedObject. When and
--( 	if this becomes a stand-alone procedure, the call would look something like this:
--( 
--( 		execute MoveToOwnedAtom$ 1660, 1579, 4004009
----------------------------------------------------------------------------------------------------
create proc MoveToOwnedAtom$
	@ObjId int,
	@DstObjId int,
	@DstFlid int
as
	declare @sTranName varchar(50)
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int
	declare @OldOwnerId int, @OldOwningFlid int, @nSrcType int, @nDstType int, @OriginalOrd int, @oldOwnedObject int
	
	set @Err = 0
	
	-- transactions
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	set @sTranName = 'MoveToOwnedAtom$_' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedAtom$: SQL Error %d; Unable to create a transaction', 16, 1, @Err)
		goto LFail
	end
	
	-- ( Get old owner information
	select @OldOwnerId=[Owner$], @OldOwningFlid=[OwnFlid$]
	from CmObject with (repeatableread)
	where [Id]=@ObjId

	-- ( Check new destination field type.
	select @nDstType = [Type]
	from Field$
	where [id] = @DstFlid
	if @nDstType <> 23 begin
		set @Err = 51000 
		raiserror('MoveToOwnedAtom$: The destination must be to an owned atomic property', 16, 1)
		goto LFail
	end

	--( Check source property type
	select @nSrcType = [Type]
	from Field$
	where [id] = @OldOwningFlid
	if @nSrcType = 23 or @nSrcType = 25 or @nSrcType = 27 begin
		-- Any owning type is fine.
		set @Err = 0
	end
	else begin -- Other types not allowed.
		set @Err = 51000 
		raiserror('MoveToOwnedAtom$: The source must be to an owning property', 16, 1)
		goto LFail
	end

	--( Delete current object owned in the atomic field, if it exists.
	select top 1 @oldOwnedObject=Id
	from CmObject
	where OwnFlid$=@DstFlid and Owner$=@DstObjId
	if @oldOwnedObject > 0 begin
		exec DeleteObj$ @oldOwnedObject
		set @Err = @@error
		if @Err <> 0 begin
			raiserror('MoveToOwnedAtom$: SQL Error %d; Unable to delete old object.', 16, 1, @Err)
			goto LFail
		end
	end

	-- Store old OwnOrd$ value. (May be null.)
	select @OriginalOrd=[OwnOrd$]
	from CmObject
	where [Id]=OwnOrd$
	
	update	CmObject with (repeatableread)
	set [Owner$] = @DstObjId,
		[OwnFlid$] = @DstFlid,
		[OwnOrd$] = null
	where [Id] = @ObjId
		
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedAtom$: SQL Error %d; Unable to update owners in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d', 
				16, 1, @Err, @DstObjId, @DstFlid)
		goto LFail
	end

	-- ( Renumber OwnOrd$ for items following in a sequence, if source was an owning sequence.
	if @OriginalOrd <> null begin
		update CmObject with (repeatableread)
		set [OwnOrd$]=[OwnOrd$] - 1
		where [Owner$]=@OldOwnerId and [OwnFlid$]=@OldOwningFlid and [OwnOrd$] > @OriginalOrd
	end

	-- stamp the owning objects as updated
	update CmObject with (repeatableread)
		set [UpdDttm] = getdate()
		where [Id] in (@OldOwnerId, @DstObjId)
		--( seems to execute as fast as a where clause written:
		--(    where [Id] = @OldOwnerId or [Id] =@DstObjId
	
	if @nTrnCnt = 0 commit tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0
	
LFail:
	rollback tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
GO


DbgNuke(MoveToOwnedColl$, proc)
go
print 'creating proc MoveToOwnedColl$'
go
/*
----------------------------------------------------------------------------------------------------
--( MoveToOwnedColl$
----------------------------------------------------------------------------------------------------
--( Responsibility:	S. A. Miller, previously Jonathan Richards
--( Last Reviewed:
--( Description:
--( 	Moves one or more objects from one list to a collection list
--( 
--( Parameters:
--( 	@SrcObjId int,		-- The ID of the object that owns the source object(s)
--( 	@SrcFlid int,		-- The FLID (field ID) of the object attribute that owns the object(s)
--( 	@StartObj int = null,	-- The ID of the first object to be moved.
--( 	@EndObj int = null,	-- The ID of the last object to be moved
--( 	@DstObjId int,		-- The ID of the object which will own the object(s) moved
--( 	@DstFlid int		-- The FLID (field ID) of the object attribute that will own the object(s)
--( 
--( Returns:
--( 	0 if successful, otherwise appropriate error code.
--( 	
--( Notes:
--( 	In various queries below, Owner$, OwnFlid$, and ID are all used in the where clause. 
--( 	The ID field is a primary key, and uniquely identifies the row we 
--( 	are interestend in.  The DstObjId and DstFlid fields can also be used to uniquely
--( 	identify the row. They are used together to validate that the DstObjID and 
--( 	DstFld belongs to the ID.
--( 	
--( 	MoveOwnedSeq, from which this procedure originated, had the capability
--( 	to replace a set of objects in the target list. This functionaltfy is no longer
--( 	supported.
--( 
--( 	Copied and modified from MoveOwnedSeq$
--( 	
--( Example Call:
--( 	Currently (June 2001) this is called from the stored procedure MoveOwnedObject. When and
--( 	if this becomes a stand-alone procedure, the call would look something like this:
--( 
--( 		execute MoveToOwnedColl$ 1569, 4001001, 1660, 1660, 1579, 4004009, 1580
----------------------------------------------------------------------------------------------------
*/

create proc MoveToOwnedColl$
	@SrcObjId int,		-- The ID of the object that owns the source object(s)
	@SrcFlid int,		-- The FLID (field ID) of the object attribute that owns the object(s)
	@StartObj int = null,	-- The ID of the first object to be moved.
	@EndObj int = null,	-- The ID of the last object to be moved
	@DstObjId int,		-- The ID of the object which will own the object(s) moved
	@DstFlid int		-- The FLID (field ID) of the object attribute that will own the object(s)
	
as
	declare @sTranName varchar(50)
	declare @StartOrd int, @EndOrd int
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @nSrcType int

	-- Remark these constants for production code. For coding and testing with Query Analyzer,
	-- unremark these constants and put an @ in front of the variables wherever they appear.
	/*
	declare @kcptOwningSequence int
	set @kcptOwningSequence = 27
	declare @kcptOwningCollection int
	set @kcptOwningCollection = 25
	declare @kcptOwningAtom int
	set @kcptOwningAtom = 23
	*/
	
	set @Err = 0
	
	-- transactions
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	set @sTranName = 'MoveToOwnedColl$_' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedColl$: SQL Error %d; Unable to create a transaction', 16, 1, @Err)
		goto LFail
	end
	
	select @nSrcType = [Type]
	from Field$
	where [id] = @SrcFlid
	
	if @nSrcType = kcptOwningSequence begin  --( If source object is an owning sequence

		select	@StartOrd = [OwnOrd$]
		from	CmObject (repeatableread)
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [Id] = @StartObj
		
		if @EndObj is null begin
			select	@EndOrd = max([OwnOrd$])
			from	CmObject (REPEATABLEREAD)
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
		end
		else begin
			select	@EndOrd = [OwnOrd$]
			from	CmObject (repeatableread)
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
				and [Id] = @EndObj
		end
		
		if @EndOrd is not null and @EndOrd < @StartOrd begin
			raiserror('MoveToOwnedColl$: The starting ordinal value %d is greater than the ending ordinal value %d in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d EndObj(Id) = %d', 
					16, 1, @StartOrd, @EndOrd, @SrcObjId, @SrcFlid, @StartObj, @EndObj)
			set @Err = 51001
			goto LFail
		end
		
		update	CmObject with (repeatableread)
		set [Owner$] = @DstObjId,
			[OwnFlid$] = @DstFlid,
			[OwnOrd$] = null
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [OwnOrd$] >= @StartOrd and [OwnOrd$] <= @EndOrd
	end
	else begin
		-- ENHANCE SteveMiller: Cannot yet move more than one object from a collection to a sequence.
		if @nSrcType = kcptOwningCollection and not @StartObj = @EndObj begin
			raiserror('MoveToOwnedSeq$: Cannot yet move more than one object from a collection to a sequence', 16, 1)
			set @Err = 51002
			goto LFail
		end
		
		update	CmObject with (repeatableread)
		set [Owner$] = @DstObjId,
			[OwnFlid$] = @DstFlid,
			[OwnOrd$] = null
		where [Id] = @StartObj
	end
		
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedColl$: SQL Error %d; Unable to update owners in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d, start = %d, end = %d', 
				16, 1, @Err, @DstObjId, @DstFlid, @StartOrd, @EndOrd)
		goto LFail
	end
	
	-- stamp the owning objects as updated
	update CmObject with (repeatableread)
		set [UpdDttm] = getdate()
		where [Id] in (@SrcObjId, @DstObjId)
		--( seems to execute as fast as a where clause written:
		--(    where [Id] = @SrcObjId or [Id] =@DstObjId

	if @nTrnCnt = 0 commit tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0
	
LFail:
	rollback tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


DbgNuke(MoveToOwnedSeq$, proc)
go
print 'creating proc MoveToOwnedSeq$'
go
/*
----------------------------------------------------------------------------------------------------
--( MoveToOwnedSeq$
----------------------------------------------------------------------------------------------------
--( Responsibility:	S. A. Miller, previously Jonathan Richards
--( Last Reviewed:
--( 
--( Description:
--( 	Moves one or more objects from one list to a sequence list, or from one spot in a sequence
--( 	list to another spot in a sequence list. 
--( 
--( Parameters:
--( 	@SrcObjId int,		-- The ID of the object that owns the source object(s)
--( 	@SrcFlid int,		-- The FLID (field ID) of the object attribute that owns the object(s)
--( 	@StartObj int,		-- The ID of the first object to be moved
--( 	@EndObj int = null,	-- The ID of the last object to be moved
--( 	@DstObjId int,		-- The ID of the object which will own the object(s) moved
--( 	@DstFlid int,		-- The FLID (field ID) of the object attribute that will own the object(s)
--( 	@DstStartObj int = null	-- the ID of the object before which the object(s) will
--( 						-- be moved. If null, the objects will be appended 
--( 						-- to the list.
--( 
--( Returns:
--( 	0 if successful, otherwise appropriate error code.
--( 	
--( Notes:
--( 	In various queries below, Owner$, OwnFlid$, and ID are all used in the where clause. 
--( 	The ID field is a primary key, and uniquely identifies the row we 
--( 	are interestend in.  The DstObjId and DstFlid fields can also be used to uniquely
--( 	identify the row. They are used together to validate that the DstObjID and 
--( 	DstFld belongs to the ID.
--( 	
--( 	MoveOwnedSeq, from which this procedure originated, had the capability
--( 	to replace a set of objects in the target list. This functionaltfy is no longer
--( 	supported.
--( 
--( 	Copied and modified from MoveOwnedSeq$
--( 	
--( Example Call:
--( 	Currently (June 2001) this is called from the stored procedure MoveOwnedObject. When and
--( 	if this becomes a stand-alone procedure, the call would look something like this:
--( 
--( 		execute MoveToOwnedSeq$ 1569, 4001001, 1660, 1660, 1579, 4004009, 1580
--( 
--------------------------------------------------------------------------------------------------
*/
CREATE proc MoveToOwnedSeq$
	@SrcObjId int,
	@SrcFlid int,
	@StartObj int,
	@EndObj int = null,
	@DstObjId int,
	@DstFlid int,
	@DstStartObj int = null
as
	declare @sTranName varchar(50)
	declare @nDstType int
	declare @nMinOrd int, @StartOrd int, @EndOrd int, @DstStartOrd int, @DstEndOrd int, @DstEndDelOrd int
	declare @nSpaceAvail int, @nSpaceNeed int, @nNewOrdOffset int, @fMadeSpace tinyint
	declare @uid uniqueidentifier
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @UpdStmp int, @RetVal int, @nSrcType int

	-- Remark these constants for production code. For coding and testing with Query Analyzer,
	-- unremark these constants and put an @ in front of the variables wherever they appear.
	/*
	declare @kcptOwningSequence int
	set @kcptOwningSequence = 27
	declare @kcptOwningCollection int
	set @kcptOwningCollection = 25
	declare @kcptOwningAtom int
	set @kcptOwningAtom = 23
	*/
	
	set @Err = 0
	set @fMadeSpace = 0
	
	--==Transactions ==--
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--	otherwise create a transaction
	set @sTranName = 'MoveToOwnedSeq$_' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to create a transaction', 16, 1, @Err)
		goto LFail
	end
	
	--== Get Start and End Orders ==-
	
	--( See notes at the top of the file about the query where clause
	
	if @DstStartObj is null begin 
		select	@DstStartOrd = coalesce(max([OwnOrd$]), -1) + 1
		from	CmObject (REPEATABLEREAD)
		where	[Owner$] = @DstObjId
			and [OwnFlid$] = @DstFlid
	end
	else begin
		select	@DstStartOrd = [OwnOrd$]
		from	CmObject (repeatableread)
		where	[Owner$] = @DstObjId
			and [OwnFlid$] = @DstFlid
			and [Id] = @DstStartObj
	end
	
	--( Get type (atomic, collection, or sequence) of source
	select @nSrcType = [Type]
	from Field$
	where [id] = @SrcFlid
	
	if @nSrcType = kcptOwningSequence begin  --( If source object is an owning sequence
		-- get the starting and ending ordinal values
		select	@StartOrd = [OwnOrd$]
		from	CmObject (repeatableread)
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [Id] = @StartObj
		if @EndObj is null begin
			select	@EndOrd = max([OwnOrd$])
			from	CmObject (REPEATABLEREAD)
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
		end
		else begin
			select	@EndOrd = [OwnOrd$]
			from	CmObject (repeatableread)
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
				and [Id] = @EndObj
		end
	end
	
	-- If source object is an owning collection
	else if @nSrcType = kcptOwningCollection begin
		 
		-- ENHANCE SteveMiller: Cannot yet move more than one object from a collection to a sequence.
		if not @StartObj = @EndObj begin
			raiserror('MoveToOwnedSeq$: Cannot yet move more than one object from a collection to a sequence', 16, 1)
			set @Err = 51000
			goto LFail
		end
			
		set @StartOrd = @DstStartOrd
		set @EndOrd = @StartOrd
	end
	
	-- If source object is an owning atom
	else if @nSrcType = kcptOwningAtom begin
		 
		if not @StartObj = @EndObj begin
			raiserror('MoveToOwnedSeq$: Cannot move two atoms at the same time', 16, 1)
			set @Err = 51001
			goto LFail
		end
		
		set @StartOrd = @DstStartOrd
		set @EndOrd = @StartOrd
	end
	
	set @DstEndOrd = @DstStartOrd + @EndOrd - @StartOrd
	
	--== Validate the arguments  ==--
	if @StartOrd is null begin
		raiserror('MoveToOwnedSeq$: Unable to locate ordinal value in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d', 
				16, 1, @SrcObjId, @SrcFlid, @StartObj)
		set @Err = 51002
		goto LFail
	end
	if @EndOrd is null begin
		raiserror('MoveToOwnedSeq$: Unable to locate ordinal value in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d EndObj(Id) = %d', 
				16, 1, @SrcObjId, @SrcFlid, @EndObj)
		set @Err = 51003
		goto LFail
	end
	if @DstStartOrd is null begin
		raiserror('MoveToOwnedSeq$: Unable to locate ordinal value in CmObject: DstObjId(Owner$) = %d DstFlid(OwnFlid$) = %d DstStartObj(Id) = %d', 
				16, 1, @DstObjId, @DstFlid, @DstStartObj)
		set @Err = 51004
		goto LFail
	end
	if @EndOrd is not null and @EndOrd < @StartOrd begin
		raiserror('MoveToOwnedSeq$: The starting ordinal value %d is greater than the ending ordinal value %d in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d EndObj(Id) = %d', 
				16, 1, @StartOrd, @EndOrd, @SrcObjId, @SrcFlid, @StartObj, @EndObj)
		set @Err = 51005
		goto LFail
	end
	
	-- if the objects are not appended to the end of the destination list then determine if there is enough room
	if @DstStartObj is not null begin
		
		-- find the object with the largest ordinal value less than the destination start object's ordinal
		select @nMinOrd = coalesce(max([OwnOrd$]), -1)
		from	CmObject with (REPEATABLEREAD)
		where	[Owner$] = @DstObjId
			and [OwnFlid$] = @DstFlid
			and [OwnOrd$] < @DstStartOrd
		set @Err = @@error
		if @Err <> 0 begin
			raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to analyze the sequence in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d', 
					16, 1, @Err, @DstObjId, @DstFlid)
			goto LFail
		end
		
		set @nSpaceAvail = @DstStartOrd - @nMinOrd - 1
		set @nSpaceNeed = @EndOrd - @StartOrd + 1
		
		-- see if there is currently enough room for the objects under the destination object's sequence list; 
		--	if there is not then make room
		if @nSpaceAvail < @nSpaceNeed begin
			
			set @fMadeSpace = 1
			
			update	CmObject with (repeatableread)
			set	[OwnOrd$] = [OwnOrd$] + @nSpaceNeed - @nSpaceAvail
			where	[Owner$] = @DstObjId
				and [OwnFlid$] = @DstFlid
				and [OwnOrd$] >= @DstStartOrd
			set @Err = @@error
			if @Err <> 0 begin
				raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to increment the ordinal values in the CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d', 
					16, 1, @Err, @DstObjId, @DstFlid)
				goto LFail
			end
		end
		
		set @nNewOrdOffset = @nMinOrd + 1 - @StartOrd
	end
	else begin
		set @nNewOrdOffset = @DstStartOrd - @StartOrd
	end
	
	-- determine if the source and destination owning sequence is the same
	if @SrcObjId = @DstObjId and @SrcFlid = @DstFlid begin
		
		-- if room was made below the objects that are to be moved then the objects to be moved also
		--	had their ordinal values modified, so calculate the new source ordinal numbers so that they
		--	will remain in the range of objects that are to be moved
		if @fMadeSpace = 1 and @StartOrd > @DstStartOrd begin
			set @StartOrd =  @StartOrd + @nSpaceNeed - @nSpaceAvail
			set @EndOrd = @EndOrd + @nSpaceNeed - @nSpaceAvail
			set @nNewOrdOffset = @DstStartOrd - @StartOrd
		end

		-- update the ordinals of the specified range of objects in the specified sequence
		update	CmObject with (repeatableread)
		set	[OwnOrd$] = [OwnOrd$] + @nNewOrdOffset
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [OwnOrd$] >= @StartOrd
			and [OwnOrd$] <= @EndOrd
		set @Err = @@error
		if @Err <> 0 begin
			raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to update ordinals in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d, start = %d, end = %d', 
				16, 1, @Err, @DstObjId, @DstFlid, @StartOrd, @EndOrd)
			goto LFail
		end
	end
	
	-- destination and source are not the same	
	else begin
		if @nSrcType = kcptOwningSequence begin
			-- update the owner of the specified range of objects in the specified sequence
			update	CmObject with (repeatableread)
			set	[Owner$] = @DstObjId,
				[OwnFlid$] = @DstFlid,
				[OwnOrd$] = [OwnOrd$] + @nNewOrdOffset
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
				and [OwnOrd$] >= @StartOrd
				and [OwnOrd$] <= @EndOrd
		end
		else if @nSrcType = kcptOwningCollection or @nSrcType = kcptOwningAtom begin
			update	CmObject with (repeatableread)
			set	[Owner$] = @DstObjId,
				[OwnFlid$] = @DstFlid,
				[OwnOrd$] = @DstStartOrd + @nNewOrdOffset
			where	[Id] = @StartObj
		end
		
		set @Err = @@error
		if @Err <> 0 begin
			raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to update owners in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d, start = %d, end = %d', 
				16, 1, @Err, @DstObjId, @DstFlid, @StartOrd, @EndOrd)
			goto LFail
		end
	end
	
	-- stamp the owning objects as updated
	update CmObject with (repeatableread)
		set [UpdDttm] = getdate()
		where [Id] in (@SrcObjId, @DstObjId)
		--( seems to execute as fast as a where clause written:
		--(    where [Id] = @SrcObjId or [Id] =@DstObjId
	
	if @nTrnCnt = 0 commit tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0
	
LFail:
	rollback tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


DbgNuke(MoveOwnedObject$, proc)
go
print 'creating proc MoveOwnedObject$'
go
/*
----------------------------------------------------------------------------------------------------
--( MoveOwnedObject$
----------------------------------------------------------------------------------------------------
--( Responsibility:	S. A. Miller, previously Jonathan Richards
--( Last Reviewed:
--( 
--( Description:
--( 	Moves one or more objects from one list to another list, or from one spot in a list
--( 	to another spot in a list. 
--( 
--( Parameters:
--( 	@SrcObjId int,		-- The ID of the object that owns the source object(s)
--( 	@SrcFlid int,		-- The FLID (field ID) of the object attribute that owns the object(s)
--( 	@ListStmp int,		-- The timestamp value of the object(s) to be moved. Unused.
--( 	@StartObj int = null,	-- The ID of the first object to be moved
--( 	@EndObj int = null,	-- The ID of the last object to be moved
--( 	@DstObjId int,		-- The ID of the object which will own the object(s) moved
--( 	@DstFlid int,		-- The FLID (field ID) of the object attribute that will own the object(s)
--( 	@DstStartObj int = null	-- the ID of the object before which the object(s) will
--( 						-- be moved. If null, the objects will be appended 
--( 						-- to the list. Used for MoveToOwnedSeq$ only.
--( 	See comments after each of the parameters below.
--( 
--( Returns:
--( 	0 if successful, otherwise appropriate error code.
--( 	
--( Notes:
--( 	This is a "wrapper" procedure. The intent is that eventually the procedures this
--( 	procedure calls will be stand-alone procedures. As I understand it, some
--( 	COM objects have to be written before that can happen.
--( 	
--( 	MoveOwnedSeq, from which this procedure originated, had the capability
--( 	to replace a set of objects in the target list. This functionaltfy is no longer
--( 	supported
--( 
--( 	Copied and modified from MoveOwnSeq$
--( 
--( Example Call:
--( 	execute MoveOwnedObject$ 1569, 4001001, NULL, 1660, 1660, 1579, 4004009, 1580
--( 
--( Useful Query Examples:
--( 	select *
--( 	from cmObject
--( 	where owner$ = 1569
--( 		and ownflid$ = 4001001
--( 
--( 	select *
--( 	from cmObject
--( 	where owner$ = 1579
--( 		and ownflid$ = 4004009
--------------------------------------------------------------------------------------------------
*/
create proc MoveOwnedObject$
	@SrcObjId int,
	@SrcFlid int,
	@ListStmp int,
	@StartObj int = null,
	@EndObj int = null,
	@DstObjId int,
	@DstFlid int,
	@DstStartObj int = null
as
	declare @Err int, @nDstType int
	
	/*
	-- Remark these constants for production code. For coding and testing with Query Analyzer,
	-- unremark these constants and put an @ in front of the variables wherever they appear.
	declare @kcptOwningSequence int
	set @kcptOwningSequence = 27
	declare @kcptOwningCollection int
	set @kcptOwningCollection = 25
	declare @kcptOwningAtom int
	set @kcptOwningAtom = 23
	*/
	
	set @Err = 0
	
	-- Get if atomic, collection, or sequence for destination
	select @nDstType = [Type]
	from Field$
	where [id] = @DstFlid
	
	-- Destination type is owning sequence	
	if @nDstType = kcptOwningSequence begin
		execute MoveToOwnedSeq$ @SrcObjId, @SrcFlid, @StartObj, @EndObj, @DstObjId, @DstFlid, @DstStartObj
	end
	
	-- Destinaton type is owning collection
	else if @nDstType = kcptOwningCollection begin
		execute MoveToOwnedColl$ @SrcObjId, @SrcFlid, @StartObj, @EndObj, @DstObjId, @DstFlid
	end
	
	-- Destination type is owning atomic
	else if @nDstType = kcptOwningAtom begin
		if not @StartObj = @EndObj begin
			set @Err = 51000 
			raiserror('MoveOwnedObject$: The starting and ending object IDs and  must be the same when moving an object to an owned atomic', 16, 1, @Err)
			goto LFail
		end
		execute MoveToOwnedAtom$ @StartObj, @DstObjId, @DstFlid
	end
	
	-- Other types not allowed
	else begin
		set @Err = 51001 
		raiserror('MoveOwnedObject$: Only owned sequences and collections allowed', 16, 1, @Err)
		goto LFail
	end
	
	return 0
	
LFail:
	return @Err
go


/***********************************************************************************************
	Object deletion procedures.
***********************************************************************************************/


/***********************************************************************************************
 * DeleteOwnSeq$
 *
 * Description:	
 *	Deletes a specified range of owned sequence objects
 *
 * Parameters:	
 *	@SrcObjId = the object that owns the source sequence
 *	@SrcFlid = the FLID of the object that owns the source sequence
 *	@ListStmp = the timestamp value associated with the sequence when it was read from the 
 *		database (can be 0)
 *	@StartObj = the starting object in the sequence of the objects that are to be removed
 *	@EndObj = the ending object in the sequence of the objects that are to be removed; if 
 *		null then the objects from the starting object to the end of the sequence will 
 *		be removed
 *
 * Returns:
 *	0 if successful, otherwise the appropriate error code
 *
 * REVIEW (SteveMiller): This procedure is called only by VwOleDbDa.cpp(7133).
 **********************************************************************************************/
if object_id('DeleteOwnSeq$') is not null begin
	print 'removing proc DeleteOwnSeq$'
	drop proc [DeleteOwnSeq$]
end
go
print 'creating proc DeleteOwnSeq$'
go
create proc [DeleteOwnSeq$]
	@SrcObjId int,
	@SrcFlid int,
	@ListStmp int,
	@StartObj int,
	@EndObj int = null
as
	declare @sTranName varchar(50)
	declare @StartOrd int, @EndOrd int
	declare @guid uniqueidentifier
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @UpdStmp int,
		@nvcId NVARCHAR(20)

	DECLARE @tblIds TABLE (Id NVARCHAR(20))
	
	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--	otherwise create a transaction
	set @sTranName = 'DeleteOwnSeq$_' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('DeleteOwnSeq$: SQL Error %d; Unable to create a transaction', 16, 1, @Err)
		goto LFail
	end	
	
	-- get the starting and ending ordinal values
	select	@StartOrd = [OwnOrd$]
	from	CmObject (repeatableread)
	where	[Owner$] = @SrcObjId
		and [OwnFlid$] = @SrcFlid
		and [Id] = @StartObj
	if @EndObj is null begin
		select	@EndOrd = max([OwnOrd$])
		from	CmObject (REPEATABLEREAD)
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
	end
	else begin
		select	@EndOrd = [OwnOrd$]
		from	CmObject (repeatableread)
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [Id] = @EndObj
	end
	
	-- validate the parameters
	if @StartOrd is null begin
		raiserror('DeleteOwnSeq$: Unable to locate ordinal value in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d', 
				16, 1, @SrcObjId, @SrcFlid, @StartObj)
		set @Err = 51001
		goto LFail
	end
	if @EndOrd is null begin
		raiserror('DeleteOwnSeq$: Unable to locate ordinal value in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d EndObj(Id) = %d', 
				16, 1, @SrcObjId, @SrcFlid, @EndObj)
		set @Err = 51002
		goto LFail
	end
	if @EndOrd < @StartOrd begin
		raiserror('DeleteOwnSeq$: The starting ordinal value %d is greater than the ending ordinal value %d in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d EndObj(Id) = %d', 
				16, 1, @StartOrd, @EndOrd, @SrcObjId, @SrcFlid, @StartObj, @EndObj)
		set @Err = 51004
		goto LFail
	end

	-- get the list of objects that are to be deleted and insert them into the ObjInfoTbl$ table
	--set @guid = newid()
	--insert into ObjInfoTbl$ with (rowlock) (uid, ObjId)
	--select	@guid, [Id]
	INSERT INTO @tblIds
	SELECT CONVERT(NVARCHAR(20), Id)
	from	CmObject with (REPEATABLEREAD)
	where	[Owner$] = @SrcObjId
		and [OwnFlid$] = @SrcFlid
		and [OwnOrd$] >= @StartOrd
		and [OwnOrd$] <= @EndOrd
	
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('DeleteOwnSeq$: SQL Error %d; Unable to insert objects into the ObjInfoTbl$; SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d EndObj(Id) = %d', 
				16, 1, @Err, @SrcObjId, @SrcFlid, @StartObj, @EndObj)
		goto LFail
	end	
	
	SELECT TOP 1 @nvcId FROM @tblIds ORDER BY Id
	WHILE @@ROWCOUNT != 0 BEGIN
		--exec @Err = DeleteObject$ @guid, null, 1
		EXEC DeleteObjects @nvcId
		SELECT TOP 1 @nvcId FROM @tblIds WHERE ID < @nvcId ORDER BY Id
	END
	if @Err <> 0 goto LFail

	if @nTrnCnt = 0 commit tran @sTranName

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0

LFail:
	rollback tran @sTranName

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


/***********************************************************************************************
       Stored Procedures and Triggers for Creating and Updating the Data Model.
***********************************************************************************************/


/***********************************************************************************************
 * UpdateClassView$
 *
 * Description: 
 *	Recreates the view associated with the given class.  
 *
 * Parameters: 
 *	@clid=the class id number of the class to which a custom field has been added (or from 
 *		which a custom field has been removed);
 *	@fRebuildSubClassViews=a flag that determines whether or not sub class views are recreated
 *
 * Returns: 
 *	0 if successful, 1 if an error occurs.
 *
 * Notes: 
 *	By taking the field information from the Field$ table directly, this procedure can be 
 *	used either when a custom field is added or when one is removed. Fields that have the 
 *	same name are not allowed in views, and are avoided here.
 **********************************************************************************************/
if object_id('UpdateClassView$') is not null begin
	print 'removing proc UpdateClassView$'
	drop proc [UpdateClassView$]
end
go
print 'creating proc UpdateClassView$'
go
create proc [UpdateClassView$]
	@clid int,
	@fRebuildSubClassViews tinyint=0
as
	declare @sTable sysname, @sBaseTable sysname, @sSubClass sysname
	declare @sField sysname, @flid int, @nType int
	declare @sDynSql nvarchar(4000), @sViewtext nvarchar(4000)
	declare @Err int, @fIsNocountOn int, @nTrnCnt int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- validate the parameter
	select	@sTable = c.[Name], @sBaseTable = base.[Name]
	from	[Class$] c join [Class$] base on c.[Base] = base.[Id]
	where	c.[Id] = @clid
	if @sTable is null begin
		raiserror('Invalid class id %d', 16, 1, @clid)
		return 50001
	end
	if @sBaseTable is null begin
		raiserror('The Class$ table has been corrupted', 16, 1)
		return 50002
	end

	-- If this procedure was called within a transaction, then create a savepoint; otherwise
	--	create a transaction.
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin transaction UpdateClassView$_Tran
	else save transaction UpdateClassView$_Tran
	set @Err = @@error
	if @Err <> 0 goto LFail
	
	-- drop the existing view		
	set @sDynSql = N'if object_id(''' + @sTable + N'_'') is not null drop view [' + @sTable + N'_]'
	exec (@sDynSql)
	set @Err = @@error
	if @Err <> 0 goto LFail
	
	set @sDynsql = N'create view [' + @sTable + '_]' + char(13) +
		N'as' + char(13) + N'select [' + @sBaseTable + N'_].*'
	
	declare fld_cur cursor local static forward_only read_only for
	select	[Id], [Name], [Type] 
	from	[Field$]
	where	[Class] = @clid 
		and ([Type] <= 9 or [Type] in (13,15,17,19,24) ) 
	order by [Id]
	
	open fld_cur
	fetch fld_cur into @flid, @sField, @nType
	while @@fetch_status = 0 begin
		set @sDynSql = @sDynSql + N',[' + @sTable + N'].[' + @sField + N']'

		-- check for strings, which have an additional format column
		if @nType = 13 or @nType = 17 set @sDynSql = @sDynSql + N',[' + @sTable + N'].[' + @sField + N'_Fmt]'

		fetch fld_cur into @flid, @sField, @nType
	end
	close fld_cur
	deallocate fld_cur

	set @sDynSql = @sDynSql + char(13) + N'from [' + @sBaseTable + N'_] join [' + @sTable + N'] on [' +
		@sBaseTable + N'_].[Id] = [' + @sTable + N'].[Id]'
	exec (@sDynSql)
	set @Err = @@error
	if @Err <> 0 goto LFail

	if @fRebuildSubClassViews = 1 begin

		-- Refresh all the views that depend on this class. This is necessary because views 
		--	based on the * operator are not automatically updated when tables are altered
		declare SubClass_cur cursor local static forward_only read_only for
		select	c.[Name]
		from	[ClassPar$] cp join [Class$] c on cp.[Src] = c.[Id]
		where	[Dst] = @clid
			and [Depth] > 0
		order by [Depth] desc

		open SubClass_cur
		fetch SubClass_cur into @sSubClass
		while @@fetch_status = 0 begin

			-- store the view contents
			select	@sViewText = [text]
			from	syscomments
			where	id = object_id(@sSubClass+'_')
			if @@rowcount <> 1 begin
				if @@rowcount = 0 begin
					raiserror('Could not find contents of view %s_', 16, 1, @sSubClass)
					set @Err = 50003
					goto LFail
				end
				-- if this happens a new approach will be necessary!!
				raiserror('View is too large to fit into an 8K page and could not be recreated', 16, 1)
				set @Err = 50004
				goto LFail
			end

			-- remove the current view
			set @sDynSql = N'drop view [' + @sSubClass + '_]'
			exec ( @sDynSql )
			set @Err = @@error
			if @Err <> 0 goto LFail

			-- rebuild the view
			exec ( @sViewtext )
			set @Err = @@error
			if @Err <> 0 goto LFail

			fetch SubClass_cur into @sSubClass
		end
		close SubClass_cur
		deallocate SubClass_cur
	end

	if @nTrnCnt = 0 commit tran UpdateClassView$_Tran

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return 0

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran UpdateClassView$_Tran
	return @Err
go


/***********************************************************************************************
 * AddCustomField$
 *
 * Description: 
 *	Adds a custom field to a class in the FieldWorks conceptual model schema.
 *
 * Parameters:
 *	@flid=the newly generated field Id (input/output parameter);
 *	@name=the name of the custom field;
 *	@type=the type code for the custom field;
 *	@clid=the class id of the class to which the field is being added;
 *	@clidDst=the class id of the target class for OwningAtom or ReferenceAtom fields (opt);
 *	@Min=the minimum value allowed for Type 2 integer field (opt);
 *	@Max=the maximum value allowed for Type 2 integer field (opt);
 *	@Big=flag that determines if a binary datatype should be stored as varbinary
 *		(@Big=0) or image (@Big=1) (opt)
 *
 * Notes: 
 *	The @Big paramter has a default value of NULL because it is used only for 6 of 23 
 *	possible types of custom fields.  
 *
 * 	4/20/2001 (ValerieN) Modified only to insert into the Field$ table.  The other 
 *	functionality is now in the trigger TR_Field$_UpdateModel_Ins  This procedure can be 
 *	removed when we figure out how to auto-generate the [ID] with the class prefix.
 **********************************************************************************************/
if object_id('AddCustomField$') is not null begin
	print 'removing proc AddCustomField$'
	drop proc [AddCustomField$]
end
go
print 'creating proc AddCustomField$'
go
create proc [AddCustomField$]
	@flid int output,
	@name varchar(100),
	@type int,
	@clid int,
	@clidDst int = null,
	@Min bigint = null,
	@Max bigint = null,
	@Big bit = null,
	@nvcUserLabel	NVARCHAR(kcchMaxName) = NULL,
	@nvcHelpString	NVARCHAR(kcchMaxName) = NULL,
	@nListRootId	INT  = NULL,
	@nWsSelector	INT = NULL,
	@ntXmlUI		NTEXT = NULL
AS
	declare @flidNew int, @flidMax int
	declare @sql varchar(1000)
	declare @Err int

	-- If this procedure was called within a transaction, then create a savepoint; otherwise
	-- create a transaction.
	declare @nTrnCnt int
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran AddCustomField$_Tran
	else save tran AddCustomField$_Tran

	-- calculate the new flid if needed
	if @flid is null or @flid = 0 begin
		select	@flidMax = max([Id]) 
		from	[Field$] (REPEATABLEREAD) 
		where	[Class] = @clid
		if @flidMax is null or @flidMax - @clid * 1000 < 500 set @flidNew = 1000 * @clid + 500
		else set @flidNew = @flidMax + 1
		set @flid = @flidNew
	end
	else begin
		-- make sure the provided flid is legal
		if @flid < (@clid * 1000 + 500) or @flid > (@clid * 1000 + 999) begin
			set @Err = @flid
			goto HandleError
		end
		-- make sure the provided flid is not already used
		select @flidNew = [Id]
		from   [Field$] (REPEATABLEREAD)
		where  [Id] = @flid
		if (@flidNew is not null) begin
			set @Err = @flid
			goto HandleError
		end
		set @flidNew = @flid
	end

	-- perform the insert into Field$
	insert into [Field$] ([Id], [Type], [Class], [DstCls], [Name], [Custom], [Min], [Max], [Big],
		UserLabel, HelpString, ListRootId, WsSelector, XmlUI)
	values (@flidNew, @type, @clid, @clidDst, @name, 1, @Min, @Max, @Big,
		@nvcUserLabel, @nvcHelpString, @nListRootId, @nWsSelector, @ntXmlUI)

	set @Err = @@error
	if @Err <> 0 goto HandleError

	if @nTrnCnt = 0 commit tran AddCustomField$_Tran
	return 0

HandleError:
	rollback tran AddCustomField$_Tran
	return @Err
go


/***********************************************************************************************
 * GenerateCustomName
 *
 * Description: 
 *	Generates a unique custom field name.
 *
 * Parameters: 
 *	none
 *
 * Returns: 
 *	0 if successful, 1 if an error occurs.
 *
 * Example:
 *	DECLARE @nvcName NVARCHAR(100)
 *	EXEC GenerateCustomName @nvcName OUTPUT
 *
 * Notes: 
 *	See in code for problems around non-Roman field names
 **********************************************************************************************/
IF OBJECT_ID('GenerateCustomName') IS NOT NULL BEGIN
	PRINT 'removing proc GenerateCustomName'
	DROP PROCEDURE GenerateCustomName
END
GO
PRINT 'creating proc GenerateCustomName'
GO

CREATE PROCEDURE GenerateCustomName
	
	--( There was some discussion of making the custom field name as 
	--( close as possibile to the label for the custom field. The 
	--( problem came in non-Roman scripts. What would happen if the
	--( user chose a script that Microsoft doesn't have in its 
	--( collation tables? This proc would fail. For now, any value
	--( that gets passed in is overwritten.
	
	@nvcName NVARCHAR(100) OUTPUT
AS BEGIN
	DECLARE
		@nCount INT,
		@nRowcount INT,
		@nWhatever INT
	
	SET @nvcName = 'custom'
	SET @nCount = 0
	
	--( The first custom field doesn't have any number appended to it
	--( in Data Notebook, so we'll follow that example here.
	SELECT @nWhatever = [Id] FROM Field$ WHERE [Name] = @nvcName
	
	SET @nRowcount = @@ROWCOUNT
	WHILE @nRowcount != 0 BEGIN
		SET @nCount = @nCount + 1
		
		SELECT @nWhatever = [Id]
		FROM Field$
		WHERE [Name] = @nvcName + CAST(@nCount AS VARCHAR(3))
		
		SET @nRowcount = @@ROWCOUNT
	END
	
	IF @nCount = 0
		SET @nvcName = @nvcName
	ELSE
		SET @nvcName = @nvcName + CONVERT(VARCHAR(3), @nCount)
END
GO


/***********************************************************************************************
 * Trigger: TR_Field$_UpdateModel_Ins
 *
 * Description:
 *	This trigger updates the database model based on row inserts into the Field$ table.
 *	Basically, it alters the underlying class table to add a new column (or columns) 
 *	depending on its type. This trigger handles both the initial model creation and custom
 *	fields.
 *
 * Type: 	Insert
 * Table:	Field$
 *
 * Notes:
 *	When custom fields are added, the trigger also rebuilds the class views. This is
 *	necessary because the * operator in views does not pick up ALTER TABLE changes made to
 *	the underlying class tables.
 *
 *	The fields UserLabel, HelpString, ListRootId, WsSelector, and XmlUI were added to this
 *	table much later than the other fields. They are meant to be used with custom fields,
 *	but they have no impact on column creation here.
 **********************************************************************************************/
if object_id('TR_Field$_UpdateModel_Ins') is not null begin
	print 'removing trigger TR_Field$_UpdateModel_Ins'
	drop trigger [TR_Field$_UpdateModel_Ins]
end
go
print 'creating trigger TR_Field$_UpdateModel_Ins'
go
create trigger [TR_Field$_UpdateModel_Ins] on [Field$] for insert 
as
	declare @sFlid VARCHAR(20)
	declare @Type INT
	declare @Clid INT
	declare @DstCls INT
	declare @sName sysname
	declare @sClass sysname
	declare @sTargetClass sysname
	declare @Min BIGINT
	declare @Max BIGINT
	declare @Big BIT
	declare @fIsCustom bit

	declare @sql NVARCHAR(1000)
	declare @Err INT
	declare @fIsNocountOn INT

	declare @sMin VARCHAR(25)
	declare @sMax VARCHAR(25)
	declare @sTable VARCHAR(20)
	declare @sFmtArg VARCHAR(40)

	declare @sTableName sysname

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- get the first class to process
	Select @sFlid= min([id]) from inserted
	
	-- loop through all of the classes in the inserted logical table
	while @sFlid is not null begin

		-- get inserted data
		select 	@Type = [Type], @Clid = [Class], @sName = [Name], @DstCls = [DstCls], @Min = [Min], @Max = [Max], @Big = [Big], @fIsCustom = [Custom]
		from	inserted i 
		where	[Id] = @sFlid

		-- get class name
		select 	@sClass = [Name]  from class$  where [Id] = @Clid

		-- get target class for Reference Objects
		if @Type in (24,26,28) begin
			select 	@sTargetClass = [Name]  from class$  where [Id] = @DstCls
		end

		if @type = 2 begin

			set @sMin = coalesce(convert(varchar(25), @Min), 0)
			set @sMax = coalesce(convert(varchar(25), @Max), 0)

			-- Add Integer to table sized based on Min/Max values supplied
			set @sql = 'ALTER TABLE [' + @sClass + '] ADD [' + @sName + '] '

			if @Min >= 0 and @Max <= 255
				set @sql = @sql + 'TINYINT NOT NULL DEFAULT ' + @sMin
			else if @Min >= -32768 and @Max <= 32767
				set @sql = @sql + 'SMALLINT NOT NULL DEFAULT ' + @sMin
			else if @Min < -2147483648 or @Max > 2147483647
				set @sql = @sql + 'BIGINT NOT NULL DEFAULT ' + @sMin
			else
				set @sql = @sql + 'INT NOT NULL DEFAULT ' + @sMin
			exec (@sql)
			if @@error <> 0 goto LFail

			-- Add Check constraint
			if @Min is not null and @Max is not null begin
				-- format as text

				set @sql = 'ALTER TABLE [' + @sClass + '] ADD CONSTRAINT [' +
					'_CK_' + @sClass + '_' + @sName + '] ' + CHAR(13) + CHAR(9) +
					' check ( [' + @sName + '] is null or ([' + @sName + '] >= ' + @sMin + ' and  [' + @sName + '] <= ' + @sMax + '))'
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end
			
		end
		else if @type IN (14,16,18,20) begin
			-- Define the view or table for this multilingual custom field

			set @sTable = case @type
				when 14 then 'MultiStr$'
				when 18 then 'MultiBigStr$'
				when 20 then 'MultiBigTxt$'
				end
			set @sFmtArg = case @type
				when 14 then '[Fmt]'
				when 18 then '[Fmt]'
				when 20 then 'cast(null as varbinary) as [Fmt]'
				end
			
			IF @type = 16 BEGIN
				-- TODO (SteveMiller): The Txt field really ought to be cut down
				-- to 83 or less for a number of reasons. First, indexes don't do
				-- a whole lot of good when they get beyond 83 characters. Second,
				-- a lot of these fields probably don't need more than 80, and if
				-- they do, ought to be put in a different field. Third, Firebird
				-- indexes don't go beyond 83.
				--
				-- The fields currently larger than 83 (or 40, for that matter),
				-- is flids 7001 and 20002. 6001004 does in TestLangProj, but that's
				-- "bogus data". These two might become MultiBigTxt fields. Ideally,
				-- word forms ought to be cut down to 83, but Ken indicates that
				-- idioms might be stored there.
				
				--( See notes under string tables about Latin1_General_BIN
				
				SET @sql = N'CREATE TABLE ' + @sClass + N'_' + @sName + N' ( ' + CHAR(13) + CHAR(10) +
					CHAR(9) + N'[Obj] INT NOT NULL, ' + CHAR(13) + CHAR(10) +
					CHAR(9) + N'[Ws] INT NOT NULL, ' + CHAR(13) + CHAR(10) +
					CHAR(9) + N'[Txt] NVARCHAR(4000) COLLATE Latin1_General_BIN NOT NULL)'
				EXEC sp_executesql @sql
				
				SET @sql = N'CREATE INDEX pk_' + @sClass + N'_' + @sName +
					N' ON ' + @sClass + N'_' + @sName + N'(Obj, WS)'
				EXEC sp_executesql @sql
				-- We need these indexes for at least the MakeMissingAnalysesFromLexicion to
				-- perform reasonably. (This is used in parsing interlinear texts.)
				-- SQLServer allows this index even though these fields are
				-- currently too big to index if the whole length is used. In practice, the
				-- limit of 450 unicode characters is very(!) unlikely to be exceeded for
				-- a single wordform or morpheme form.
				if @sName = 'Form' and (@sClass = 'MoForm' or @sClass = 'WfiWordform') BEGIN
					SET @sql = N'CREATE INDEX Ind_' + @sClass + N'_' + @sName +
						N'_Txt ON ' + @sClass + N'_' + @sName + N'(txt)'
					EXEC sp_executesql @sql
				END
		END
			ELSE BEGIN
	  			set @sql = 'CREATE VIEW [' + @sClass + '_' + @sName + '] AS' + CHAR(13) + CHAR(10) +
	  				CHAR(9) + 'select [Obj], [Flid], [Ws], [Txt], ' + @sFmtArg + CHAR(13) + CHAR(10) +
	  				CHAR(9) + 'FROM [' + @sTable + ']' + CHAR(13) + CHAR(10) +
	  				CHAR(9) + 'WHERE [Flid] = ' + @sFlid
	  			exec (@sql)
			END
			if @@error <> 0 goto LFail
			
		end
		else if @type IN (23,25,27) begin
			-- define the view for this OwningAtom/Collection/Sequence custom field.
			set @sql = 'CREATE VIEW [' + @sClass + '_' + @sName + '] AS' + CHAR(13) + CHAR(10) +
				CHAR(9) + 'select [Owner$] as [Src], [Id] as [Dst]' 
			
			if @type = 27 set @sql = @sql + ', [OwnOrd$] as [Ord]'

			set @sql = @sql + CHAR(13) +
				CHAR(9) + 'FROM [CmObject]' + CHAR(13) + CHAR(10) +
				CHAR(9) + 'WHERE [OwnFlid$] = ' + @sFlid
			exec (@sql)
			if @@error <> 0 goto LFail

			--( Adding an owning atomic StText field requires all existing instances
			--( of the owning class to possess an empty StText and StTxtPara.
				
			IF @type = 23 AND @DstCls = 14 BEGIN				
				SET @sql = '
				DECLARE @recId INT,
					@newId int,
					@dummyId int,
					@dummyGuid uniqueidentifier
				
				DECLARE curOwners CURSOR FOR SELECT [id] FROM ' + @sClass + '
				OPEN curOwners
				FETCH NEXT FROM curOwners INTO @recId
				WHILE @@FETCH_STATUS = 0
				BEGIN
					EXEC CreateObject_StText
						0, @recId, ' + @sFlid + ', null, @newId OUTPUT, @dummyGuid OUTPUT
					EXEC CreateObject_StTxtPara
						null, null, null, null, null, null, @newId, 14001, null, @dummyId, @dummyGuid OUTPUT
					FETCH NEXT FROM curOwners INTO @recId
				END
				CLOSE curOwners
				DEALLOCATE curOwners'
				
				EXEC (@sql)
			END
			
		end
		else if @type IN (26,28) begin
			-- define the table for this custom reference collection/sequence field.
			set @sql = 'CREATE TABLE [' + @sClass + '_' + @sName + '] (' + CHAR(13) +
				'[Src] INT NOT NULL,' + CHAR(13) +
				'[Dst] INT NOT NULL,' + CHAR(13) 

			if @type = 28 set @sql = @sql + '[Ord] INT NOT NULL,' + CHAR(13)

			set @sql = @sql +
				'CONSTRAINT [_FK_' + @sClass + '_' + @sName + '_Src] ' +
				'FOREIGN KEY ([Src]) REFERENCES [' + @sClass + '] ([Id]),' + CHAR(13) +
				'CONSTRAINT [_FK_' + @sClass + '_' + @sName + '_Dst] ' +
				'FOREIGN KEY ([Dst]) REFERENCES [' + @sTargetClass + '] ([Id]),' + CHAR(13) +
				case @type
					when 26 then ')'
					when 28 then
						CHAR(9) + CHAR(9) + 'CONSTRAINT [_PK_' + @sClass + '_' + @sName + '] ' + 
						'PRIMARY KEY CLUSTERED ([Src], [Ord])' + CHAR(13) + ')'
					end
			exec (@sql)
			if @@error <> 0 goto LFail

			if @type = 26 begin
				set @sql = 'create clustered index ' + 
						@sClass + '_' + @sName + '_ind on ' + 
						@sClass + '_' + @sName + ' ([Src], [Dst])'
				exec (@sql)
				if @@error <> 0 goto LFail

				set @sTableName = @sClass + '_' + @sName
				exec @Err = DefineReplaceRefCollProc$ @sTableName
				if @Err <> 0 begin
					raiserror('TR_Field$_UpdateModel_Ins: Unable to create the procedure that handles reference collections for table %s',
							16, 1, @sName)
					goto LFail
				end

			end

			if @type = 28 begin
				set @sTableName = @sClass + '_' + @sName
				exec @Err = DefineReplaceRefSeqProc$ @sTableName, @sFlid
				if @Err <> 0 begin
					raiserror('TR_Field$_UpdateModel_Ins: Unable to create the procedure that handles reference sequences for table %s',
							16, 1, @sName)
					goto LFail
				end
			end
			
			--( Insert trigger
			SET @sql = 'CREATE TRIGGER [TR_' + @sClass + '_' + @sName + '_DtTmIns]' + CHAR(13) +
				CHAR(9) + 'ON [' + @sClass + '_' + @sName + '] FOR INSERT ' + CHAR(13) +
				'AS ' + CHAR(13) +
				CHAR(9) + 'UPDATE CmObject SET UpdDttm = GetDate() ' + CHAR(13) + 
				CHAR(9) + CHAR(9) + 'FROM CmObject co JOIN inserted ins ON co.[id] = ins.[src] ' + CHAR(13) +
				CHAR(9) + CHAR(13)  + 
				CHAR(9) + 'IF @@error <> 0 BEGIN' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'Raiserror(''TR_' + @sClass + '_' + @sName + '_DtTmIns]: ' + 
					'Unable to update CmObject'', 16, 1)' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'GOTO LFail' + CHAR(13) + 
				CHAR(9) + 'END' + CHAR(13) +
				CHAR(9) + 'RETURN' + CHAR(13) +
				CHAR(9) + CHAR(13) +
				CHAR(9) + 'LFail:' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'ROLLBACK TRAN' + CHAR(13) + 
				CHAR(9) + CHAR(9) + 'RETURN' + CHAR(13)		
			EXEC (@sql)
			IF @@error <> 0 GOTO LFail

			--( Delete trigger
			SET @sql = 'CREATE TRIGGER [TR_' + @sClass + '_' + @sName + '_DtTmDel]' + CHAR(13) +
				CHAR(9) + 'ON [' + @sClass + '_' + @sName + '] FOR DELETE ' + CHAR(13) +
				'AS ' + CHAR(13) +
				CHAR(9) + 'UPDATE CmObject SET UpdDttm = GetDate() ' + CHAR(13) + 
				CHAR(9) + CHAR(9) + 'FROM CmObject co JOIN deleted del ON co.[id] = del.[src] ' + CHAR(13) +
				CHAR(9) + CHAR(13)  + 
				CHAR(9) + 'IF @@error <> 0 BEGIN' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'Raiserror(''TR_' + @sClass + '_' + @sName + '_DtTmDel]: ' + 
					'Unable to update CmObject'', 16, 1)' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'GOTO LFail' + CHAR(13) + 
				CHAR(9) + 'END' + CHAR(13) +
				CHAR(9) + 'RETURN' + CHAR(13) +
				CHAR(9) + CHAR(13) +
				CHAR(9) + 'LFail:' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'ROLLBACK TRAN' + CHAR(13) + 
				CHAR(9) + CHAR(9) + 'RETURN' + CHAR(13)		
			EXEC (@sql)
			IF @@error <> 0 GOTO LFail
			
		end
		else begin
			-- add the custom field to the appropriate table
			set @sql = 'ALTER TABLE [' + @sClass + '] ADD [' + @sName + '] ' + case
				when @type = 1 then 'BIT NOT NULL DEFAULT 0'			-- Boolean
				when @type = 3 then 'DECIMAL(28,4) NOT NULL DEFAULT 0'		-- Numeric
				when @type = 4 then 'FLOAT NOT NULL DEFAULT 0.0'		-- Float
				-- Time: default to current time except for fields in LgWritingSystem.
				when @type = 5 AND @sClass != 'LgWritingSystem' then 'DATETIME NULL DEFAULT GETDATE()'
				when @type = 5 AND @sClass = 'LgWritingSystem' then 'DATETIME NULL'
				when @type = 6 then 'UNIQUEIDENTIFIER NULL'			-- Guid
				when @type = 7 then 'IMAGE NULL'				-- Image
				when @type = 8 then 'INT NOT NULL DEFAULT 0'			-- GenDate
				when @type = 9 and @Big is null then 'VARBINARY(8000) NULL'		-- Binary
				when @type = 9 and @Big = 0 then 'VARBINARY(8000) NULL'		-- Binary
				when @type = 9 and @Big = 1 then 'IMAGE NULL'			-- Binary
				when @type = 13 then 'NVARCHAR(4000) NULL'			-- String
				when @type = 15 then 'NVARCHAR(4000) NULL'			-- Unicode
				when @type = 17 then 'NTEXT NULL'				-- BigString
				when @type = 19 then 'NTEXT NULL'				-- BigUnicode
				when @type = 24 then 'INT NULL'					-- ReferenceAtom
				end
			exec (@sql)
			if @@error <> 0 goto LFail
			if @type in (13,17)  begin
				set @sql = 'ALTER TABLE [' + @sClass + '] ADD ' + case @type
					when 13 then '[' + @sName + '_Fmt] VARBINARY(8000) NULL' -- String
					when 17 then '[' + @sName + '_Fmt] IMAGE NULL'			-- BigString
					end
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end

			-- Set the 'Text In Row' option for the table if type is 7, 17 or 19.
			if @type in (7, 17, 19) exec sp_tableoption @sClass, 'text in row', '1000'

			-- don't create foreign key constraints on CmObject
			if @type = 24 and @sClass != 'CmObject' begin
				set @sql = 'ALTER TABLE [' + @sClass + '] ADD CONSTRAINT [' +		-- ReferenceAtom
					'_FK_' + @sClass + '_' + @sName + '] ' + CHAR(13) + CHAR(9) +
					' FOREIGN KEY ([' + @sName + ']) REFERENCES [' + @sTargetClass + '] ([Id])'
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end
			
		end
		
		-- get the next class to process
		Select @sFlid= min([id]) from inserted  where [Id] > @sFlid

	end  -- While loop
	
	--( UpdateClassView$ is executed in TR_Field$_UpdateModel_InsLast, which is created
	--( in LangProjSP.sql.
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return

LFail:
	rollback tran
	return
go

/***********************************************************************************************
 * Trigger: TR_Field$_UpdateModel_Del
 *
 * Description:
 *	This trigger cleans up columns and any additional tables that are associated with the
 *	deleted row in Field$
 *
 * Notes:
 *	This trigger might be used for data migration procedures, not just custom fields.
 * 
 * Type: 	Delete
 * Table:	Field$
 **********************************************************************************************/
if object_id('TR_Field$_UpdateModel_Del') is not null begin
	print 'removing trigger TR_Field$_UpdateModel_Del'
	drop trigger TR_Field$_UpdateModel_Del
end
go
print 'creating trigger TR_Field$_UpdateModel_Del'
go
create trigger TR_Field$_UpdateModel_Del on Field$ for delete 
as
	declare @Clid INT
	declare @DstCls INT
	declare @sName VARCHAR(100)
	declare @sClass VARCHAR(100)
	declare @sFlid VARCHAR(20)
	declare @Type INT
	DECLARE @nAbstract INT
	
	declare @Err INT
	declare @fIsNocountOn INT
	declare @sql VARCHAR(1000)
	
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- get the first custom field to process
	Select @sFlid= min([id]) from deleted
	
	-- loop through all of the custom fields to be deleted
	while @sFlid is not null begin
		
		-- get deleted fields
		select 	@Type = [Type], @Clid = [Class], @sName = [Name], @DstCls = [DstCls]
		from	deleted 
		where	[Id] = @sFlid
		
		-- get class name
		select 	@sClass = [Name], @nAbstract = Abstract  from class$  where [Id] = @Clid
		
		if @type IN (14,16,18,20) begin
			-- Remove any data stored for this multilingual custom field.
			declare @sTable VARCHAR(20)
			set @sTable = case @type
				when 14 then 'MultiStr$'
				when 16 then 'MultiTxt$ (No Longer Exists)'
				when 18 then 'MultiBigStr$'
				when 20 then 'MultiBigTxt$'
				end
			IF @type != 16  -- MultiTxt$ data will be deleted when the table is dropped
			BEGIN
				set @sql = 'DELETE FROM [' + @sTable + '] WHERE [Flid] = ' + @sFlid
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			END
			
			-- Remove the view created for this multilingual custom field.
			IF @type != 16
				set @sql = 'DROP VIEW [' + @sClass + '_' + @sName + ']'
			ELSE
				SET @sql = 'DROP TABLE [' + @sClass + '_' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail
		end
		else if @type IN (23,25,27) begin
			-- Remove the view created for this custom OwningAtom/Collection/Sequence field.
			set @sql = 'DROP VIEW [' + @sClass + '_' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail
			-- Check for any objects stored for this custom OwningAtom/Collection/Sequence field.
			declare @DelId INT
			select @DelId = [Id] FROM CmObject (readuncommitted) WHERE [OwnFlid$] = @sFlid
			set @Err = @@error
			if @Err <> 0 goto LFail
			if @DelId is not null begin
				raiserror('TR_Field$_UpdateModel_Del: Unable to remove %s field until corresponding objects are deleted',
						16, 1, @sName)
				goto LFail
			end
		end
		else if @type IN (26,28) begin
			-- Remove the table created for this custom ReferenceCollection/Sequence field.
			set @sql = 'DROP TABLE [' + @sClass + '_' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail

			-- Remove the procedure that handles reference collections or sequences for 
			-- the dropped table
			set @sql = N'
				IF OBJECT_ID(''ReplaceRefColl_' + @sClass +  '_' + @sName + ''') IS NOT NULL
					DROP PROCEDURE [ReplaceRefColl_' + @sClass + '_' + @sName + ']
				IF OBJECT_ID(''ReplaceRefSeq_' + @sClass +  '_' + @sName + ''') IS NOT NULL
					DROP PROCEDURE [ReplaceRefSeq_' + @sClass + '_' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail
		end
		else begin
			-- Remove the format column created if this was a custom String field.
			if @type in (13,17) begin
				set @sql = 'ALTER TABLE [' + @sClass + '] DROP COLUMN [' + @sName + '_Fmt]'
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end
			-- Remove the constraint created if this was a custom ReferenceAtom field.
			-- Not necessary for CmObject : Foreign Key constraints are not created agains CmObject
			if @type = 24 begin
				declare @sTarget VARCHAR(100)
				select @sTarget = [Name] FROM [Class$] WHERE [Id] = @DstCls
				set @Err = @@error
				if @Err <> 0 goto LFail
				if @sTarget != 'CmObject' begin
					set @sql = 'ALTER TABLE [' + @sClass + '] DROP CONSTRAINT [' +
						'_FK_' + @sClass + '_' + @sName + ']'
					exec (@sql)
					set @Err = @@error
					if @Err <> 0 goto LFail
				end
			end
			-- Remove Default Constraint from Numeric or Date fields before dropping the column
			If @type in (1,2,3,4,5,8) begin
				select @sql = 'ALTER TABLE [' + @sClass + '] DROP CONSTRAINT [' + so.name + ']'
				from sysconstraints sc
					join sysobjects so on so.id = sc.constid and so.name like 'DF[_]%'
					join sysobjects so2 on so2.id = sc.id
					join syscolumns sco on sco.id = sc.id and sco.colid = sc.colid
				where so2.name = @sClass   -- Tablename
				and   sco.name = @sName    -- Fieldname
				and   so2.type = 'U'	   -- Userdefined table
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end
			
			-- Remove the column created for this custom field.
			set @sql = 'ALTER TABLE [' + @sClass + '] DROP COLUMN [' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail
			
			-- fix the view associated with this class.
			exec @Err = UpdateClassView$ @Clid, 1
			if @Err <> 0 goto LFail
		end
		
		--( Rebuild CreateObject_*

		IF @nAbstract != 1 BEGIN
			EXEC @Err = DefineCreateProc$ @Clid
			IF @Err <> 0 GOTO LFail
		END

		-- get the next custom field to process
		Select @sFlid= min([id]) from deleted  where [Id] > @sFlid
		
	end -- While loop
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return

LFail:
	rollback tran
	return
go


/***********************************************************************************************
 * Trigger: TR_Field$_No_Upd
 *
 * Description:
 *	Limit most data in Field$ from being updated.
 *
 * Type: 	Update
 * Table:	Field$
 *
 *	The fields UserLabel, HelpString, ListRootId, WsSelector, and XmlUI were added to this
 *	table much later than the other fields. They are meant to be used with custom fields. The
 *	original trigger prohibited updates on the table altogether, but we would like to update
 *	these new fields.
 **********************************************************************************************/

if object_id('TR_Field$_No_Upd') is not null begin
	print 'removing trigger TR_Field$_No_Upd'
	drop trigger [TR_Field$_No_Upd]
end
go
print 'creating trigger TR_Field$_No_Upd'
go
create trigger [TR_Field$_No_Upd] on [Field$] for update 
as
	
	DECLARE @nId INT
	
	--( This doesn't deal with IDs. Hopefully no on will ever be so rash
	--( as to do that.
	
	--( Many of the fields have constraints of their own, which makes it 
	--( hard to meet or test the conditions below.
	
	SELECT @nId = i.[Id]
	FROM inserted i
	JOIN deleted d ON d.[Id] = i.[Id]
	WHERE COALESCE(i.Type, 0) != COALESCE(d.Type, 0)
		OR COALESCE(i.Class, 0) != COALESCE(d.Class, 0)
		OR COALESCE(i.DstCls, 0) != COALESCE(d.DstCls, 0)
		OR i.[Name] != d.[Name]
		OR i.Custom != d.Custom
		--( Guids are 36 in length, but just in case...
		OR COALESCE(CONVERT(VARCHAR(100), i.CustomId), '0') != COALESCE(CONVERT(VARCHAR(100), d.CustomId), '0')
		OR COALESCE(i.[Min], 0) != COALESCE(d.[Min], 0)
		OR COALESCE(i.[Max], 0) != COALESCE(d.[Max], 0)
		OR COALESCE(i.Big, 0) != COALESCE(d.Big, 0)
	
	--( This forms a kind of assert. No one should be touching the metadata fields
	--( of Field$
	IF @@ROWCOUNT != 0 BEGIN
		raiserror('Update is not allowed on the Field$ table metadata fields.  Delete the field record and reinsert it with the new values.', 16, 1)
		rollback tran
	END
	
	return
go

/***********************************************************************************************
 * Name: DeleteModelClass
 *
 * Description:
 *	This procedure deletes a row from Class$ and cleans up associated rows in Field$ as well as
 *	any tables and stored procedures generated for the deleted Class.
 *
 * NOTE: You should delete SubClasses before their SuperClass.
 **********************************************************************************************/
if object_id('DeleteModelClass') is not null begin
	print 'removing proc DeleteModelClass'
	drop proc DeleteModelClass
end
print 'creating proc DeleteModelClass'
go

CREATE PROCEDURE DeleteModelClass
 	@Clid INT 
as
	declare @sName VARCHAR(100)
	DECLARE @nAbstract INT
	
	declare @Err INT
	declare @fIsNocountOn INT
	declare @sql VARCHAR(1000)
	
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	SELECT @sName=[Name], @nAbstract=[Abstract] FROM Class$ WHERE [id]=@Clid

	-- 1. Delete the associated rows from ClassPar$ and check for surviving subclasses
	DELETE FROM ClassPar$ WHERE Src=@Clid
	set @Err = @@error
	if @Err <> 0 goto LFail
	DECLARE @cSub int
	SELECT @cSub=COUNT(*) FROM ClassPar$ WHERE Dst=@Clid
	set @Err = @@error
	if @Err <> 0 goto LFail
	if @cSub<> 0 goto LFail
			
	-- 2. Delete any rows in Field$ where Class=<thisDeletedClass>
	DELETE FROM Field$ WHERE Class=@Clid
	set @Err = @@error
	if @Err <> 0 goto LFail

	DELETE FROM Field$ WHERE DstCls=@Clid 	-- Is this correct?
	set @Err = @@error
	if @Err <> 0 goto LFail

	-- 3. Delete the table and view for thisDeletedClass.
	SET @sql='DROP TABLE ' + @sName
	exec (@sql)
	set @Err = @@error
	if @Err <> 0 goto LFail

	SET @sql='DROP VIEW ' + @sName + '_'
	exec (@sql)
	set @Err = @@error
	if @Err <> 0 goto LFail

	-- 4. If it exists delete the CreateObject procedure for thisDeletedClass.
	SET @sql='IF OBJECT_ID(''CreateObject_' + @sName + ''') IS NOT NULL BEGIN' +
			' DROP PROCEDURE CreateObject_' + @sName + 
		' END'
	exec (@sql)
	set @Err = @@error
	if @Err <> 0 goto LFail

	-- 5. Delete any rows in CmObject where Class$=<thisDeletedClass>.
	DELETE FROM CmObject WHERE Class$=@Clid
	set @Err = @@error
	if @Err <> 0 goto LFail
				
	-- Actually delete the affected rows
	DELETE FROM Class$ WHERE [Id]=@Clid
	set @Err = @@error
	if @Err <> 0 goto LFail

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return
LFail:
	rollback tran
	return
go



/***********************************************************************************************
	Custom Collation/Sort
***********************************************************************************************/

/*******************************************************************************
 * Procedure: CreateFlidCollations
 *
 * Description:
 *	Creates flid/Collation combinations 
 *
 * Parameters--ONLY 1 parameter is expected to be not null:
 *	@nEncID			= Writing system ID
 *	@nCollationID	= Collation ID
 *	@nFlid			= Field ID
 *****************************************************************************/

IF OBJECT_ID('CreateFlidCollations') IS NOT NULL BEGIN
	PRINT 'removing procedure CreateFlidCollations'
	DROP PROCEDURE [CreateFlidCollations]
END
GO
PRINT 'creating procedure CreateFlidCollations'
GO
CREATE PROCEDURE [CreateFlidCollations]
	@nEncID INT,
	@nCollationID INT,
	@nFlid INT
AS

	-- TODO (SteveMi): Only certain strings should have FlidCollation
	-- and MultiTxtSortKey$

	IF @nEncId IS NOT NULL
		PRINT 'todo'
		-- TODO (SteveMi): this chunk
	
	ELSE IF @nCollationID IS NOT NULL
		PRINT 'todo'
		-- TODO (SteveMi): this chunk
	
	ELSE IF @nFlid IS NOT NULL
		
		--( We want to create flidcollations only for current writing systems.
		--( We also don't want to duplicate any Writing System/Collation/Flid
		--( combination.
		
		INSERT INTO FlidCollation$ ([Ws], [CollationId], [Flid])
		SELECT curwritingsys.[Ws], wsc.[Dst] AS [CollationID], @nFlid AS [Flid]
		FROM (
			SELECT [Dst] AS [Ws] FROM LanguageProject_CurrentAnalysisWritingSystems
			UNION
			SELECT [Dst] AS [Ws] FROM LanguageProject_CurrentVernacularWritingSystems) curwritingsys
		JOIN LgWritingSystem_Collations wsc ON wsc.[Src] = curwritingsys.[Ws]
		LEFT OUTER JOIN FlidCollation$ fc ON 
			fc.[Ws] = curwritingsys.[Ws] AND
			fc.[CollationID] = wsc.[Dst] AND 
			fc.[Flid] = @nFlid
		WHERE (
			fc.[Ws] IS NULL OR
			fc.[CollationID] IS NULL OR
			fc.[Flid] IS NULL)
	
	--( The insert into FlidCollation$ should trigger an insert trigger
	--( sort key creation in MultiTxtSortKey$

	-- TODO (SteveMi): above comment.
		
GO

/*******************************************************************************
 * Procedure: DeleteFlidCollations
 *
 * Description:
 *	Deletes flid/Collation combinations 
 *
 * Parameters--ONLY 1 parameter is expected to be not null:
 *	@nEncID			= Writing system ID
 *	@nCollationID	= Collation ID
 *	@nFlid			= Field ID
 *****************************************************************************/

IF OBJECT_ID('DeleteFlidCollations') IS NOT NULL BEGIN
	PRINT 'removing procedure DeleteFlidCollations'
	DROP PROCEDURE [DeleteFlidCollations]
END
GO
PRINT 'creating procedure DeleteFlidCollations'
GO
CREATE PROCEDURE [DeleteFlidCollations]
	@nEncID INT,
	@nCollationID INT,
	@nFlid INT
AS

	-- TODO (SteveMi): Only certain strings should have FlidCollation
	-- and MultiTxtSortKey$

	IF @nEncId IS NOT NULL
		PRINT 'todo'
		-- TODO (SteveMi): this chunk
	
	ELSE IF @nCollationID IS NOT NULL
		PRINT 'todo'
		-- TODO (SteveMi): this chunk
	
	ELSE IF @nFlid IS NOT NULL
		

		INSERT INTO FlidCollation$ ([Ws], [CollationId], [Flid])
		SELECT e.[Ws], wsc.[Dst] AS [CollationID], @nFlid AS [Flid]
		FROM (
			SELECT [Dst] AS [Ws] FROM LanguageProject_CurrentAnalysisWritingSystems
			UNION
			SELECT [Dst] AS [Ws] FROM LanguageProject_CurrentVernacularWritingSystems) e
		JOIN LgWritingSystem_Collations wsc ON wsc.[Src] = e.[Ws]
		LEFT OUTER JOIN FlidCollation$ fc ON 
			fc.[Ws] = e.[Ws] AND
			fc.[CollationID] = wsc.[Dst] AND 
			fc.[Flid] = @nFlid
		WHERE (
			fc.[Ws] IS NULL OR
			fc.[CollationID] IS NULL OR
			fc.[Flid] IS NULL)
	
	--( The delete into FlidCollation$ should trigger an delete trigger
	--( sort key creation in MultiTxtSortKey$

	-- TODO (SteveMi): above comment.
		
GO

/***********************************************************************************************
       Utilities
***********************************************************************************************/

/***********************************************************************************************
 * Stored Procedure: LogInfo$
 *
 * Description:
 *  Returns info about the SQL Server log file.
 *
 * Notes:
 *	This can be tricky, because any command that changes data will change the numbers of 
 *	the log file, which are the numbers we're looking at.
 *
 *  I've debated whether to pass the database name in, but currently the stored procedure is
 *  written to be smart enough to fire on the current database.
 *
 *	Originally written because the log file is filling up the disk causing fatal, unrecoverable
 *	errors.
 **********************************************************************************************/

IF OBJECT_ID('LogInfo$') IS NOT NULL BEGIN
	PRINT 'removing procedure LogInfo$'
	DROP PROCEDURE [LogInfo$]
END
GO
PRINT 'creating procedure LogInfo$'
GO

CREATE PROCEDURE LogInfo$
	@ncLogFileName NCHAR(128) OUTPUT,
	@nLogFileSize INT OUTPUT,
	@nLogFileSpaceUsed INT OUTPUT,
	@nLogFileMaxSize INT OUTPUT,
	@nSpaceAvailForLogFile INT OUTPUT
AS
BEGIN
	DECLARE
		@rLogUsedPercent REAL
	
	--( We'll get the log file size from sysfiles after doing the temp tables, 
	--( because the size can change. status of 0x40 indicates the log file
	
	SELECT @ncLogFileName = [filename] FROM sysfiles WHERE ([status] & 0x40) <> 0 
	
	--( This block can change the numbers on the log file, so it is executed before
	--( other code. We'll add more to mbfree momentarily.
	
	CREATE TABLE #fixeddrives (drive CHAR(1) PRIMARY KEY, mbfree INTEGER NOT NULL)
	--( xp_fixeddrives is not documented by MS, but it is quite a bit on the web. See, for example,
	--( http://www.mssqlcity.com/FAQ/Devel/get_list_of_drives.htm
	INSERT INTO #fixeddrives EXEC master..xp_fixeddrives
	SELECT @nSpaceAvailForLogFile = mbfree FROM #fixeddrives WHERE drive = LEFT(@ncLogFileName, 1)
	DROP TABLE #fixeddrives
	--( xp_fixeddrives expresses space in Mb. We want it in Kb
	SET @nSpaceAvailForLogFile = @nSpaceAvailForLogFile * 1024
	
	--( We have a create temp table after this, but there's no helping it.
	
	SELECT
		@nLogFileSize = [size],
		@nLogFileMaxSize = [maxsize]
	FROM sysfiles
	WHERE ([status] & 0x40) <> 0 -- status of 0x40 indicates the log file
	
	--( SQL Server returns the size of the file in 8-KB pages. We want it in KB. The conversion 
	--( factor is 8.
	
	SET @nLogFileSize = @nLogFileSize * 8
	
	--( SQL Server returns the max size of the file in 8-KB pages. We want it in KB. The conversion 
	--( factor 8. The value of maxsize could also be 0 (no growth) or -1 (grow until disk full).
	
	IF @nLogFileMaxSize > 0
		SET @nLogFileMaxSize = @nLogFileMaxSize * 8
	
	--( This block can change the numbers on the log file, so it is executed after the
	--( previous code. We would use a table variable here, but SQL Server will give an
	--( error "EXECUTE cannot be used as a source when inserting into a table variable."
	
	--( DBCC SQLPERF (LOGSPACE) returns space used as a percentage.
	
	CREATE TABLE #LogInfo (DbName NVARCHAR(128), LogSize REAL, LogUsed REAL, Status TINYINT)
	INSERT INTO #LogInfo EXEC ('DBCC SQLPERF (LOGSPACE)')
	SELECT @rLogUsedPercent = LogUsed FROM #LogInfo WHERE [DbName] = DB_NAME()
	DROP TABLE #LogInfo
	
	SET @nLogFileSpaceUsed = ROUND(@nLogFileSize * (@rLogUsedPercent / 100), 0)
	
	--( Now calc how much space is available for the log file. 
	
	IF @nLogFileMaxSize = -1
		--(	@nSpaceAvailForLogFile already has free disk space.
		SET @nSpaceAvailForLogFile = @nSpaceAvailForLogFile + (@nLogFileSize - @nLogFileSpaceUsed)
	ELSE IF @nLogFileMaxSize = 0
		SET @nSpaceAvailForLogFile = @nLogFileSize - @nLogFileSpaceUsed
	ELSE
		SET @nSpaceAvailForLogFile = @nLogFileMaxSize  - @nLogFileSpaceUsed
	
END
GO

/***********************************************************************************************
 * Function: fnIsMatch$
 *
 * Description:
 *  Wrapper for extended stored procedure xp_IsMatch 
 *
 * Notes:
 **********************************************************************************************/

IF OBJECT_ID('fnIsMatch$') IS NOT NULL BEGIN
	PRINT 'removing function fnIsMatch$'
	DROP FUNCTION [fnIsMatch$]
END
GO
PRINT 'creating function fnIsMatch$'
GO

CREATE FUNCTION [fnIsMatch$] (
	@nvcPattern NVARCHAR(4000),
	@nvcString NVARCHAR(4000))
	--TODO (SteveMiller): more parameters are needed.
RETURNS INT
AS
BEGIN

	DECLARE
		@nError INT,
		@fMatch BIT
	
	EXEC @nError = master..xp_IsMatch @nvcPattern, @nvcString, @fMatch OUTPUT
	
	IF @nError != 0
		SET @fMatch = -1

	RETURN @fMatch
	
END
GO

/***********************************************************************************************
 * Function: fnGetLastCommaDelimID$
 *
 * Description:
 *  Certain strings have a comma delimmited list of IDs. In the case of CmSortSpec, some fields
 *  have a series of IDs, the last of which is of interest to us. 
 *
 * Notes:
 *	An enhancement may be made to get the nth ID desired, instead of the last. If made, this
 *  function would more closely resemble the INSTR() function of Oracle and FoxPro. Code that
 *  mimics Oracle's can be found at:
 *    http://www.brasileiro.net:8080/postgres/cookbook/view-one-recipe.adp?recipe_id=33
 **********************************************************************************************/

IF OBJECT_ID('fnGetLastCommaDelimID$') IS NOT NULL BEGIN
	PRINT 'removing function fnGetLastCommaDelimID$'
	DROP FUNCTION [fnGetLastCommaDelimID$]
END
GO
PRINT 'creating function fnGetLastCommaDelimID$'
GO

CREATE FUNCTION [fnGetLastCommaDelimID$] (
	@nvcSourceString NVARCHAR(4000))
RETURNS INT
AS
BEGIN
	DECLARE 
		@nScratch SMALLINT,
		@nCommaPosition SMALLINT
	
	IF @nvcSourceString IS NULL
		SET @nCommaPosition = NULL
	ELSE BEGIN
		
		--( In case there are no commas
		SET @nScratch = CHARINDEX(',', @nvcSourceString)
		SET @nCommaPosition = @nScratch
		
		--( Find the last comma
		WHILE @nScratch > 0 BEGIN		
			SET @nCommaPosition = @nScratch
			SET @nScratch = CHARINDEX(',', @nvcSourceString, @nCommaPosition + 1)
		END
	END
	
	--( Return the ID after the last comma.
	RETURN CONVERT(INT, SUBSTRING(
		@nvcSourceString,
		@nCommaPosition + 1,
		LEN(@nvcSourceString) - @nCommaPosition))
END

GO

/*************************************************************************
 * Function fnGetIdsFromString
 *
 * Description: 
 *	Loads a table variable with object IDs from an NTEXT parameter
 *	which has IDs either in a comma delimited list or in an XML doc.
 *
 * Parameters: 
 *	@ntIds	= either a comma delimited list or an XML doc of IDs. Can
 *				be a singe ID.
 *  @hXmlIds = an integer handle to an XML doc, if used.
 *
 * Returns:
 *	@tabIds	= table variable of IDs.
 *
 * Notes:
 *	In tests, I had trouble using sp_xml_preparedocument and 
 *	sp_xml_removedocument in a stored function. So if you're using an
 *	XML document, you must set up the XML document before calling this
 *	function.
 *
 * Calling Sample:
 *
 *	SET @ntIds = N'<root><Obj ID="1"/></root>'
 *	
 *	EXECUTE sp_xml_preparedocument @hXmlIds OUTPUT, @ntIds
 *	
 *	INSERT INTO @tIds 
 *	SELECT f."ID", f."CLASSNAME"
 *	FROM dbo.fnGetIdsFromString(@ntIds, @hXmlIds) AS f
 *	
 *	EXECUTE sp_xml_removedocument @hXmlIds
 *************************************************************************/

IF OBJECT_ID('fnGetIdsFromString') IS NOT NULL BEGIN
   	PRINT 'removing function fnGetIdsFromString'
   	DROP FUNCTION fnGetIdsFromString
END
GO
PRINT 'creating function fnGetIdsFromString'
GO

CREATE FUNCTION fnGetIdsFromString (@ntIds NTEXT, @hXmlIds INT)
RETURNS @tabIds TABLE (ID INT, ClassName NVARCHAR(100))
AS
BEGIN
	DECLARE
		@nId INT,
		@nEnd INT,
		@nStart INT
	
	--( IDs from comma delimited string
	
	IF SUBSTRING(@ntIds, 1, 1) != '<' BEGIN
		
		SET @nStart = 1
		SET @nEnd = CHARINDEX(',', @ntIds, @nStart)
		
		WHILE @nEnd > 1 BEGIN
			SET @nId = SUBSTRING(@ntIds, @nStart, @nEnd - @nStart)
			
			INSERT INTO @tabIds
			SELECT @nId, c.Name
			FROM CmObject o
			JOIN Class$ c ON c.ID = o.Class$
			WHERE o.ID = @nId
			
	 		SET @nStart = @nEnd + 1
			SET @nEnd = CHARINDEX(',', @ntIds, @nStart)	
		END
		
		--( last one.
		SET @nId = SUBSTRING(@ntIds, @nStart, DATALENGTH(@ntIds) - @nStart)
		
		INSERT INTO @tabIds
		SELECT @nId, c.Name
		FROM CmObject o
		JOIN Class$ c ON c.ID = o.Class$
		WHERE o.ID = @nId
	END
	
	--( Load from an XML string
	ELSE BEGIN
		--( In certain conditions, a function cannot call
		--( sp_xml_preparedocument. You must set it up first
		--( in the calling program:
		--(
 		--( EXECUTE sp_xml_preparedocument @hXmlIds OUTPUT, @ntIds
		
		--Note: (JohnT): The identifier in the With clauses of the OPENXML is CASE SENSITIVE!!
		INSERT INTO @tabIds
		SELECT i.ID, c.Name
		FROM OPENXML(@hXmlIds, '/root/Obj') WITH (Id INT) i
		JOIN CmObject o ON o.ID = i.ID
		JOIN Class$ c ON c.ID = o.CLASS$
		
		--( In certain conditions, a function cannot call
		--( sp_xml_removedocument. You must set it up first in
		--( the calling program:
		--(
 		--( EXECUTE sp_xml_removedocument @hXmlIds
	END
	RETURN
	
END
GO

/***********************************************************************************************
 * Function: ManageConstraints$
 *
 * Parameteres:
 *	@nvcTableName		= Name of the table with the constraints. NULL = all tables
 *	@cConstraintType	= Type of constraint. Default is 'F'. From Books On Line, under the
 *						topic sysobjects:
 *							C = CHECK constraint
 *							D = Default or DEFAULT constraint
 *							F = FOREIGN KEY constraint
 *							L = Log
 *							FN = Scalar function
 *							IF = Inlined table-function
 *							P = Stored procedure
 *							PK = PRIMARY KEY constraint (type is K)
 *							RF = Replication filter stored procedure 
 *							S = System table
 *							TF = Table function
 *							TR = Trigger
 *							U = User table
 *							UQ = UNIQUE constraint (type is K)
 *							V = View
 *							X = Extended stored procedure
 *	@cAction			= Action to preform on the trigger. Current supported values are:
 *							CHECK, NOCHECK, and DROP. CHECK and NOCHECK can only be used with
 *							FOREIGN KEY (type F) and CHECK (type C) constraints. Defaults to
 *							'CHECK'
 *
 * Description:
 *  Activate or deactivate constraints for a table. May be expanded more someday for extra
 *	functionality.
 **********************************************************************************************/

IF OBJECT_ID('ManageConstraints$') IS NOT NULL BEGIN
	PRINT 'removing procedure ManageConstraints$'
	DROP PROCEDURE [ManageConstraints$]
END
GO
PRINT 'creating procedure ManageConstraints$'
GO

CREATE PROCEDURE [ManageConstraints$]
		@nvcTableName NVARCHAR(50) = NULL,
		@cConstraintType CHAR(2) = 'F',
		@cAction CHAR(10) = 'CHECK'
AS
	DECLARE
		@sysConstraintName SYSNAME,
		@nvcSQL NVARCHAR(200)
	
	--( Run for all tables
	IF @nvcTableName IS NULL BEGIN
		DECLARE curConstraints CURSOR FOR
			SELECT consobjs.[Name] AS FKName, tableobjs.[Name] AS TableName
			FROM sysconstraints sc
			JOIN sysobjects consobjs ON consobjs.[id] = sc.[constid] --( to get constraint names
			JOIN sysobjects tableobjs ON tableobjs.[id] = sc.[id] --( to get table names
			WHERE consobjs.[xtype] = @cConstraintType
	
		OPEN curConstraints
		FETCH NEXT FROM curConstraints INTO @sysConstraintName, @nvcTableName
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @nvcSQL = 'ALTER TABLE ' + @nvcTableName + ' ' + @cAction + 
				' CONSTRAINT ' + @sysConstraintName
			EXEC (@nvcSQL)
			
			FETCH NEXT FROM curConstraints INTO @sysConstraintName, @nvcTableName
		END
		CLOSE curConstraints
		DEALLOCATE curConstraints
	END
	
	ELSE BEGIN --( @nvcTableName is not null, run for individual table
		DECLARE curConstraints CURSOR FOR
			SELECT consobjs.[Name]
			FROM sysconstraints sc
			JOIN sysobjects consobjs ON consobjs.[id] = sc.[constid] --( to get constraint names
			JOIN sysobjects tableobjs ON tableobjs.[id] = sc.[id] --( to get table names
			WHERE tableobjs.[Name] = @nvcTableName AND consobjs.[xtype] = @cConstraintType
	
		OPEN curConstraints
		FETCH NEXT FROM curConstraints INTO @sysConstraintName
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @nvcSQL = 'ALTER TABLE ' + @nvcTableName + ' ' + @cAction + 
				' CONSTRAINT ' + @sysConstraintName
			EXEC (@nvcSQL)
			
			FETCH NEXT FROM curConstraints INTO @sysConstraintName
		END
		CLOSE curConstraints
		DEALLOCATE curConstraints
	END

/**************************************************************************
 * Procedure: StartTrace$
 *
 * Description: 
 *	Creates a trace file, turns on events and data columns to use, and
 *      starts the trace
 *
 * Parameters: 
 *	Most of the parameters are used directly with sp_trace_create. See
 *      Books Online (BOL) for usage. Except the two output parameters,
 *	each has a default.
 *      
 *	@TraceId         (OUTPUT) The trace ID, used later for stopping
			 the trace.
 *	@nReturnCode     (OUTPUT) Return code.
 *	@nTraceType      0 = "FwPlain.trc", mimics a new trace that is 
				created by Profiler with default settings.
 *	                 1 = "FwExpanded.trc", a trace that tries to 
 *                       	balance the desire for more information
 *	                 	and limited disk space.
 *	@nTraceOptions	 See Books Online for possible values.
 *	@nvcTracePath    Path for the trace. The file name and is added
 *	                 by the stored proc. 
 *	@biMaxMbFileSize The max size the file can get in megabytes.
 *      @dtStopTime      Date and time to stop the trace file.
 *
 * Returns: 
 *	0 if succesful, otherwise the error code.
 *
 * Notes:
 *	Unless specified otherwise, the trace file can be found in the
 *	root directory.
 *
 *	To stop the trace, use StopTrace$. If for some reason you've lost
 *	track of the trace ID#, use StopTraces$
 *
 *	The easiest way to create code for a new type of trace file is:
 *
 *		1. Go to Profiler
 *		2. Use the interface you want to pick events and options
 *		3. Go to File/Script Trace.../For SQL Server 2000
 *		4. Copy the code here.
 *************************************************************************/

if object_id('StartTrace$') is not null begin
	print 'removing proc StartTrace$'
	drop procedure [StartTrace$]
end
go
print 'creating procedure StartTrace$'
go

CREATE PROCEDURE [StartTrace$] 
	--( Some variables/parameters not Hungarian because of code copied
	--( from Profiler
	@TraceId INT OUTPUT,
	@nReturnCode INT OUTPUT,
	@nTraceType INT = 0,
	@nTraceOptions INT = 2, --( 2 = TRACE_FILE_ROLLOVER. See BOL
	@nvcTracePath NVARCHAR(245) = N'C:\',
	@bnMaxMbFileSize BIGINT = 1,
	@dtStopTime DATETIME = NULL
AS

	DECLARE
		@nvcTraceFile NVARCHAR(245),
		@on BIT,
		@nvcErrMsg NVARCHAR(50),
		@nvcCommand NVARCHAR(512)
	
	 --( sp_trace_create attaches .trc to the end of a file name.
	IF @nTraceType = 0
		SET @nvcTraceFile = @nvcTracePath + N'FwPlain'
	ELSE IF @nTraceType = 1
		SET @nvcTraceFile = @nvcTracePath + N'FwExpanded'
	ELSE BEGIN
		SET @nvcErrMsg = N'StartTrace: bad Trace type'
		GOTO Fail
	END

	
	--== Delete Old Trace if exists ==--
	
	--( This won't work if the trace is still running. You need to
	--( stop the trace first. Chances are the Trace ID is 1.
	
	SET @nvcCommand = 'if exist ' + @nvcTraceFile + '.trc del ' + @nvcTraceFile + '.trc'
	EXEC @nReturnCode = master.dbo.xp_cmdshell @nvcCommand, NO_OUTPUT
	IF NOT @nReturnCode = 0 BEGIN --( If not 0, then it will be 1
		SET @nvcErrMsg = N'StartTrace: Delete ' + @nvcTraceFile + N'.trc failed '
		GOTO Fail
	END
	
	--== Create the New Trace ==--
	
	EXEC @nReturnCode = sp_trace_create
		@TraceID OUTPUT,
		@nTraceOptions,
		@nvcTraceFile,
		@bnMaxMbFileSize,
		@dtStopTime
	
	IF NOT @nReturnCode = 0 BEGIN
		SET @nvcErrMsg = N'StartTrace: See Books Online for error return code ' + 
			CONVERT(NVARCHAR(2), @nReturnCode)
		GOTO Fail
	END
	
	SET @on = 1
	
	--( FwPlain, a genric trace file
	IF @nTraceType = 0 BEGIN
		exec sp_trace_setevent @TraceID, 10, 1, @on
		exec sp_trace_setevent @TraceID, 10, 6, @on
		exec sp_trace_setevent @TraceID, 10, 9, @on
		exec sp_trace_setevent @TraceID, 10, 10, @on
		exec sp_trace_setevent @TraceID, 10, 11, @on
		exec sp_trace_setevent @TraceID, 10, 12, @on
		exec sp_trace_setevent @TraceID, 10, 13, @on
		exec sp_trace_setevent @TraceID, 10, 14, @on
		exec sp_trace_setevent @TraceID, 10, 16, @on
		exec sp_trace_setevent @TraceID, 10, 17, @on
		exec sp_trace_setevent @TraceID, 10, 18, @on
		exec sp_trace_setevent @TraceID, 12, 1, @on
		exec sp_trace_setevent @TraceID, 12, 6, @on
		exec sp_trace_setevent @TraceID, 12, 9, @on
		exec sp_trace_setevent @TraceID, 12, 10, @on
		exec sp_trace_setevent @TraceID, 12, 11, @on
		exec sp_trace_setevent @TraceID, 12, 12, @on
		exec sp_trace_setevent @TraceID, 12, 13, @on
		exec sp_trace_setevent @TraceID, 12, 14, @on
		exec sp_trace_setevent @TraceID, 12, 16, @on
		exec sp_trace_setevent @TraceID, 12, 17, @on
		exec sp_trace_setevent @TraceID, 12, 18, @on
		exec sp_trace_setevent @TraceID, 14, 1, @on
		exec sp_trace_setevent @TraceID, 14, 6, @on
		exec sp_trace_setevent @TraceID, 14, 9, @on
		exec sp_trace_setevent @TraceID, 14, 10, @on
		exec sp_trace_setevent @TraceID, 14, 11, @on
		exec sp_trace_setevent @TraceID, 14, 12, @on
		exec sp_trace_setevent @TraceID, 14, 13, @on
		exec sp_trace_setevent @TraceID, 14, 14, @on
		exec sp_trace_setevent @TraceID, 14, 16, @on
		exec sp_trace_setevent @TraceID, 14, 17, @on
		exec sp_trace_setevent @TraceID, 14, 18, @on
		exec sp_trace_setevent @TraceID, 15, 1, @on
		exec sp_trace_setevent @TraceID, 15, 6, @on
		exec sp_trace_setevent @TraceID, 15, 9, @on
		exec sp_trace_setevent @TraceID, 15, 10, @on
		exec sp_trace_setevent @TraceID, 15, 11, @on
		exec sp_trace_setevent @TraceID, 15, 12, @on
		exec sp_trace_setevent @TraceID, 15, 13, @on
		exec sp_trace_setevent @TraceID, 15, 14, @on
		exec sp_trace_setevent @TraceID, 15, 16, @on
		exec sp_trace_setevent @TraceID, 15, 17, @on
		exec sp_trace_setevent @TraceID, 15, 18, @on
		exec sp_trace_setevent @TraceID, 17, 1, @on
		exec sp_trace_setevent @TraceID, 17, 6, @on
		exec sp_trace_setevent @TraceID, 17, 9, @on
		exec sp_trace_setevent @TraceID, 17, 10, @on
		exec sp_trace_setevent @TraceID, 17, 11, @on
		exec sp_trace_setevent @TraceID, 17, 12, @on
		exec sp_trace_setevent @TraceID, 17, 13, @on
		exec sp_trace_setevent @TraceID, 17, 14, @on
		exec sp_trace_setevent @TraceID, 17, 16, @on
		exec sp_trace_setevent @TraceID, 17, 17, @on
		exec sp_trace_setevent @TraceID, 17, 18, @on
	END
	
	ELSE IF @nTraceType = 1 BEGIN
		exec sp_trace_setevent @TraceID, 10, 1, @on
		exec sp_trace_setevent @TraceID, 10, 9, @on
		exec sp_trace_setevent @TraceID, 10, 11, @on
		exec sp_trace_setevent @TraceID, 10, 12, @on
		exec sp_trace_setevent @TraceID, 10, 13, @on
		exec sp_trace_setevent @TraceID, 10, 14, @on
		exec sp_trace_setevent @TraceID, 10, 16, @on
		exec sp_trace_setevent @TraceID, 10, 17, @on
		exec sp_trace_setevent @TraceID, 10, 18, @on
		exec sp_trace_setevent @TraceID, 10, 21, @on
		exec sp_trace_setevent @TraceID, 10, 31, @on
		exec sp_trace_setevent @TraceID, 10, 34, @on
		exec sp_trace_setevent @TraceID, 14, 1, @on
		exec sp_trace_setevent @TraceID, 14, 9, @on
		exec sp_trace_setevent @TraceID, 14, 11, @on
		exec sp_trace_setevent @TraceID, 14, 12, @on
		exec sp_trace_setevent @TraceID, 14, 13, @on
		exec sp_trace_setevent @TraceID, 14, 14, @on
		exec sp_trace_setevent @TraceID, 14, 16, @on
		exec sp_trace_setevent @TraceID, 14, 17, @on
		exec sp_trace_setevent @TraceID, 14, 18, @on
		exec sp_trace_setevent @TraceID, 14, 21, @on
		exec sp_trace_setevent @TraceID, 14, 31, @on
		exec sp_trace_setevent @TraceID, 14, 34, @on
		exec sp_trace_setevent @TraceID, 15, 1, @on
		exec sp_trace_setevent @TraceID, 15, 9, @on
		exec sp_trace_setevent @TraceID, 15, 11, @on
		exec sp_trace_setevent @TraceID, 15, 12, @on
		exec sp_trace_setevent @TraceID, 15, 13, @on
		exec sp_trace_setevent @TraceID, 15, 14, @on
		exec sp_trace_setevent @TraceID, 15, 16, @on
		exec sp_trace_setevent @TraceID, 15, 17, @on
		exec sp_trace_setevent @TraceID, 15, 18, @on
		exec sp_trace_setevent @TraceID, 15, 21, @on
		exec sp_trace_setevent @TraceID, 15, 31, @on
		exec sp_trace_setevent @TraceID, 15, 34, @on
		exec sp_trace_setevent @TraceID, 16, 1, @on
		exec sp_trace_setevent @TraceID, 16, 9, @on
		exec sp_trace_setevent @TraceID, 16, 11, @on
		exec sp_trace_setevent @TraceID, 16, 12, @on
		exec sp_trace_setevent @TraceID, 16, 13, @on
		exec sp_trace_setevent @TraceID, 16, 14, @on
		exec sp_trace_setevent @TraceID, 16, 16, @on
		exec sp_trace_setevent @TraceID, 16, 17, @on
		exec sp_trace_setevent @TraceID, 16, 18, @on
		exec sp_trace_setevent @TraceID, 16, 21, @on
		exec sp_trace_setevent @TraceID, 16, 31, @on
		exec sp_trace_setevent @TraceID, 16, 34, @on
		exec sp_trace_setevent @TraceID, 17, 1, @on
		exec sp_trace_setevent @TraceID, 17, 9, @on
		exec sp_trace_setevent @TraceID, 17, 11, @on
		exec sp_trace_setevent @TraceID, 17, 12, @on
		exec sp_trace_setevent @TraceID, 17, 13, @on
		exec sp_trace_setevent @TraceID, 17, 14, @on
		exec sp_trace_setevent @TraceID, 17, 16, @on
		exec sp_trace_setevent @TraceID, 17, 17, @on
		exec sp_trace_setevent @TraceID, 17, 18, @on
		exec sp_trace_setevent @TraceID, 17, 21, @on
		exec sp_trace_setevent @TraceID, 17, 31, @on
		exec sp_trace_setevent @TraceID, 17, 34, @on
		exec sp_trace_setevent @TraceID, 21, 1, @on
		exec sp_trace_setevent @TraceID, 21, 9, @on
		exec sp_trace_setevent @TraceID, 21, 11, @on
		exec sp_trace_setevent @TraceID, 21, 12, @on
		exec sp_trace_setevent @TraceID, 21, 13, @on
		exec sp_trace_setevent @TraceID, 21, 14, @on
		exec sp_trace_setevent @TraceID, 21, 16, @on
		exec sp_trace_setevent @TraceID, 21, 17, @on
		exec sp_trace_setevent @TraceID, 21, 18, @on
		exec sp_trace_setevent @TraceID, 21, 21, @on
		exec sp_trace_setevent @TraceID, 21, 31, @on
		exec sp_trace_setevent @TraceID, 21, 34, @on
		exec sp_trace_setevent @TraceID, 22, 1, @on
		exec sp_trace_setevent @TraceID, 22, 9, @on
		exec sp_trace_setevent @TraceID, 22, 11, @on
		exec sp_trace_setevent @TraceID, 22, 12, @on
		exec sp_trace_setevent @TraceID, 22, 13, @on
		exec sp_trace_setevent @TraceID, 22, 14, @on
		exec sp_trace_setevent @TraceID, 22, 16, @on
		exec sp_trace_setevent @TraceID, 22, 17, @on
		exec sp_trace_setevent @TraceID, 22, 18, @on
		exec sp_trace_setevent @TraceID, 22, 21, @on
		exec sp_trace_setevent @TraceID, 22, 31, @on
		exec sp_trace_setevent @TraceID, 22, 34, @on
		exec sp_trace_setevent @TraceID, 33, 1, @on
		exec sp_trace_setevent @TraceID, 33, 9, @on
		exec sp_trace_setevent @TraceID, 33, 11, @on
		exec sp_trace_setevent @TraceID, 33, 12, @on
		exec sp_trace_setevent @TraceID, 33, 13, @on
		exec sp_trace_setevent @TraceID, 33, 14, @on
		exec sp_trace_setevent @TraceID, 33, 16, @on
		exec sp_trace_setevent @TraceID, 33, 17, @on
		exec sp_trace_setevent @TraceID, 33, 18, @on
		exec sp_trace_setevent @TraceID, 33, 21, @on
		exec sp_trace_setevent @TraceID, 33, 31, @on
		exec sp_trace_setevent @TraceID, 33, 34, @on
		exec sp_trace_setevent @TraceID, 34, 1, @on
		exec sp_trace_setevent @TraceID, 34, 9, @on
		exec sp_trace_setevent @TraceID, 34, 11, @on
		exec sp_trace_setevent @TraceID, 34, 12, @on
		exec sp_trace_setevent @TraceID, 34, 13, @on
		exec sp_trace_setevent @TraceID, 34, 14, @on
		exec sp_trace_setevent @TraceID, 34, 16, @on
		exec sp_trace_setevent @TraceID, 34, 17, @on
		exec sp_trace_setevent @TraceID, 34, 18, @on
		exec sp_trace_setevent @TraceID, 34, 21, @on
		exec sp_trace_setevent @TraceID, 34, 31, @on
		exec sp_trace_setevent @TraceID, 34, 34, @on
		exec sp_trace_setevent @TraceID, 35, 1, @on
		exec sp_trace_setevent @TraceID, 35, 9, @on
		exec sp_trace_setevent @TraceID, 35, 11, @on
		exec sp_trace_setevent @TraceID, 35, 12, @on
		exec sp_trace_setevent @TraceID, 35, 13, @on
		exec sp_trace_setevent @TraceID, 35, 14, @on
		exec sp_trace_setevent @TraceID, 35, 16, @on
		exec sp_trace_setevent @TraceID, 35, 17, @on
		exec sp_trace_setevent @TraceID, 35, 18, @on
		exec sp_trace_setevent @TraceID, 35, 21, @on
		exec sp_trace_setevent @TraceID, 35, 31, @on
		exec sp_trace_setevent @TraceID, 35, 34, @on
		exec sp_trace_setevent @TraceID, 36, 1, @on
		exec sp_trace_setevent @TraceID, 36, 9, @on
		exec sp_trace_setevent @TraceID, 36, 11, @on
		exec sp_trace_setevent @TraceID, 36, 12, @on
		exec sp_trace_setevent @TraceID, 36, 13, @on
		exec sp_trace_setevent @TraceID, 36, 14, @on
		exec sp_trace_setevent @TraceID, 36, 16, @on
		exec sp_trace_setevent @TraceID, 36, 17, @on
		exec sp_trace_setevent @TraceID, 36, 18, @on
		exec sp_trace_setevent @TraceID, 36, 21, @on
		exec sp_trace_setevent @TraceID, 36, 31, @on
		exec sp_trace_setevent @TraceID, 36, 34, @on
		exec sp_trace_setevent @TraceID, 37, 1, @on
		exec sp_trace_setevent @TraceID, 37, 9, @on
		exec sp_trace_setevent @TraceID, 37, 11, @on
		exec sp_trace_setevent @TraceID, 37, 12, @on
		exec sp_trace_setevent @TraceID, 37, 13, @on
		exec sp_trace_setevent @TraceID, 37, 14, @on
		exec sp_trace_setevent @TraceID, 37, 16, @on
		exec sp_trace_setevent @TraceID, 37, 17, @on
		exec sp_trace_setevent @TraceID, 37, 18, @on
		exec sp_trace_setevent @TraceID, 37, 21, @on
		exec sp_trace_setevent @TraceID, 37, 31, @on
		exec sp_trace_setevent @TraceID, 37, 34, @on
		exec sp_trace_setevent @TraceID, 41, 1, @on
		exec sp_trace_setevent @TraceID, 41, 9, @on
		exec sp_trace_setevent @TraceID, 41, 11, @on
		exec sp_trace_setevent @TraceID, 41, 12, @on
		exec sp_trace_setevent @TraceID, 41, 13, @on
		exec sp_trace_setevent @TraceID, 41, 14, @on
		exec sp_trace_setevent @TraceID, 41, 16, @on
		exec sp_trace_setevent @TraceID, 41, 17, @on
		exec sp_trace_setevent @TraceID, 41, 18, @on
		exec sp_trace_setevent @TraceID, 41, 21, @on
		exec sp_trace_setevent @TraceID, 41, 31, @on
		exec sp_trace_setevent @TraceID, 41, 34, @on
		exec sp_trace_setevent @TraceID, 50, 1, @on
		exec sp_trace_setevent @TraceID, 50, 9, @on
		exec sp_trace_setevent @TraceID, 50, 11, @on
		exec sp_trace_setevent @TraceID, 50, 12, @on
		exec sp_trace_setevent @TraceID, 50, 13, @on
		exec sp_trace_setevent @TraceID, 50, 14, @on
		exec sp_trace_setevent @TraceID, 50, 16, @on
		exec sp_trace_setevent @TraceID, 50, 17, @on
		exec sp_trace_setevent @TraceID, 50, 18, @on
		exec sp_trace_setevent @TraceID, 50, 21, @on
		exec sp_trace_setevent @TraceID, 50, 31, @on
		exec sp_trace_setevent @TraceID, 50, 34, @on
		exec sp_trace_setevent @TraceID, 53, 1, @on
		exec sp_trace_setevent @TraceID, 53, 9, @on
		exec sp_trace_setevent @TraceID, 53, 11, @on
		exec sp_trace_setevent @TraceID, 53, 12, @on
		exec sp_trace_setevent @TraceID, 53, 13, @on
		exec sp_trace_setevent @TraceID, 53, 14, @on
		exec sp_trace_setevent @TraceID, 53, 16, @on
		exec sp_trace_setevent @TraceID, 53, 17, @on
		exec sp_trace_setevent @TraceID, 53, 18, @on
		exec sp_trace_setevent @TraceID, 53, 21, @on
		exec sp_trace_setevent @TraceID, 53, 31, @on
		exec sp_trace_setevent @TraceID, 53, 34, @on
		exec sp_trace_setevent @TraceID, 55, 1, @on
		exec sp_trace_setevent @TraceID, 55, 9, @on
		exec sp_trace_setevent @TraceID, 55, 11, @on
		exec sp_trace_setevent @TraceID, 55, 12, @on
		exec sp_trace_setevent @TraceID, 55, 13, @on
		exec sp_trace_setevent @TraceID, 55, 14, @on
		exec sp_trace_setevent @TraceID, 55, 16, @on
		exec sp_trace_setevent @TraceID, 55, 17, @on
		exec sp_trace_setevent @TraceID, 55, 18, @on
		exec sp_trace_setevent @TraceID, 55, 21, @on
		exec sp_trace_setevent @TraceID, 55, 31, @on
		exec sp_trace_setevent @TraceID, 55, 34, @on
		exec sp_trace_setevent @TraceID, 61, 1, @on
		exec sp_trace_setevent @TraceID, 61, 9, @on
		exec sp_trace_setevent @TraceID, 61, 11, @on
		exec sp_trace_setevent @TraceID, 61, 12, @on
		exec sp_trace_setevent @TraceID, 61, 13, @on
		exec sp_trace_setevent @TraceID, 61, 14, @on
		exec sp_trace_setevent @TraceID, 61, 16, @on
		exec sp_trace_setevent @TraceID, 61, 17, @on
		exec sp_trace_setevent @TraceID, 61, 18, @on
		exec sp_trace_setevent @TraceID, 61, 21, @on
		exec sp_trace_setevent @TraceID, 61, 31, @on
		exec sp_trace_setevent @TraceID, 61, 34, @on
		exec sp_trace_setevent @TraceID, 67, 1, @on
		exec sp_trace_setevent @TraceID, 67, 9, @on
		exec sp_trace_setevent @TraceID, 67, 11, @on
		exec sp_trace_setevent @TraceID, 67, 12, @on
		exec sp_trace_setevent @TraceID, 67, 13, @on
		exec sp_trace_setevent @TraceID, 67, 14, @on
		exec sp_trace_setevent @TraceID, 67, 16, @on
		exec sp_trace_setevent @TraceID, 67, 17, @on
		exec sp_trace_setevent @TraceID, 67, 18, @on
		exec sp_trace_setevent @TraceID, 67, 21, @on
		exec sp_trace_setevent @TraceID, 67, 31, @on
		exec sp_trace_setevent @TraceID, 67, 34, @on
		exec sp_trace_setevent @TraceID, 68, 1, @on
		exec sp_trace_setevent @TraceID, 68, 9, @on
		exec sp_trace_setevent @TraceID, 68, 11, @on
		exec sp_trace_setevent @TraceID, 68, 12, @on
		exec sp_trace_setevent @TraceID, 68, 13, @on
		exec sp_trace_setevent @TraceID, 68, 14, @on
		exec sp_trace_setevent @TraceID, 68, 16, @on
		exec sp_trace_setevent @TraceID, 68, 17, @on
		exec sp_trace_setevent @TraceID, 68, 18, @on
		exec sp_trace_setevent @TraceID, 68, 21, @on
		exec sp_trace_setevent @TraceID, 68, 31, @on
		exec sp_trace_setevent @TraceID, 68, 34, @on
		exec sp_trace_setevent @TraceID, 69, 1, @on
		exec sp_trace_setevent @TraceID, 69, 9, @on
		exec sp_trace_setevent @TraceID, 69, 11, @on
		exec sp_trace_setevent @TraceID, 69, 12, @on
		exec sp_trace_setevent @TraceID, 69, 13, @on
		exec sp_trace_setevent @TraceID, 69, 14, @on
		exec sp_trace_setevent @TraceID, 69, 16, @on
		exec sp_trace_setevent @TraceID, 69, 17, @on
		exec sp_trace_setevent @TraceID, 69, 18, @on
		exec sp_trace_setevent @TraceID, 69, 21, @on
		exec sp_trace_setevent @TraceID, 69, 31, @on
		exec sp_trace_setevent @TraceID, 69, 34, @on
		exec sp_trace_setevent @TraceID, 70, 1, @on
		exec sp_trace_setevent @TraceID, 70, 9, @on
		exec sp_trace_setevent @TraceID, 70, 11, @on
		exec sp_trace_setevent @TraceID, 70, 12, @on
		exec sp_trace_setevent @TraceID, 70, 13, @on
		exec sp_trace_setevent @TraceID, 70, 14, @on
		exec sp_trace_setevent @TraceID, 70, 16, @on
		exec sp_trace_setevent @TraceID, 70, 17, @on
		exec sp_trace_setevent @TraceID, 70, 18, @on
		exec sp_trace_setevent @TraceID, 70, 21, @on
		exec sp_trace_setevent @TraceID, 70, 31, @on
		exec sp_trace_setevent @TraceID, 70, 34, @on
		exec sp_trace_setevent @TraceID, 71, 1, @on
		exec sp_trace_setevent @TraceID, 71, 9, @on
		exec sp_trace_setevent @TraceID, 71, 11, @on
		exec sp_trace_setevent @TraceID, 71, 12, @on
		exec sp_trace_setevent @TraceID, 71, 13, @on
		exec sp_trace_setevent @TraceID, 71, 14, @on
		exec sp_trace_setevent @TraceID, 71, 16, @on
		exec sp_trace_setevent @TraceID, 71, 17, @on
		exec sp_trace_setevent @TraceID, 71, 18, @on
		exec sp_trace_setevent @TraceID, 71, 21, @on
		exec sp_trace_setevent @TraceID, 71, 31, @on
		exec sp_trace_setevent @TraceID, 71, 34, @on
		exec sp_trace_setevent @TraceID, 72, 1, @on
		exec sp_trace_setevent @TraceID, 72, 9, @on
		exec sp_trace_setevent @TraceID, 72, 11, @on
		exec sp_trace_setevent @TraceID, 72, 12, @on
		exec sp_trace_setevent @TraceID, 72, 13, @on
		exec sp_trace_setevent @TraceID, 72, 14, @on
		exec sp_trace_setevent @TraceID, 72, 16, @on
		exec sp_trace_setevent @TraceID, 72, 17, @on
		exec sp_trace_setevent @TraceID, 72, 18, @on
		exec sp_trace_setevent @TraceID, 72, 21, @on
		exec sp_trace_setevent @TraceID, 72, 31, @on
		exec sp_trace_setevent @TraceID, 72, 34, @on
		exec sp_trace_setevent @TraceID, 74, 1, @on
		exec sp_trace_setevent @TraceID, 74, 9, @on
		exec sp_trace_setevent @TraceID, 74, 11, @on
		exec sp_trace_setevent @TraceID, 74, 12, @on
		exec sp_trace_setevent @TraceID, 74, 13, @on
		exec sp_trace_setevent @TraceID, 74, 14, @on
		exec sp_trace_setevent @TraceID, 74, 16, @on
		exec sp_trace_setevent @TraceID, 74, 17, @on
		exec sp_trace_setevent @TraceID, 74, 18, @on
		exec sp_trace_setevent @TraceID, 74, 21, @on
		exec sp_trace_setevent @TraceID, 74, 31, @on
		exec sp_trace_setevent @TraceID, 74, 34, @on
		exec sp_trace_setevent @TraceID, 75, 1, @on
		exec sp_trace_setevent @TraceID, 75, 9, @on
		exec sp_trace_setevent @TraceID, 75, 11, @on
		exec sp_trace_setevent @TraceID, 75, 12, @on
		exec sp_trace_setevent @TraceID, 75, 13, @on
		exec sp_trace_setevent @TraceID, 75, 14, @on
		exec sp_trace_setevent @TraceID, 75, 16, @on
		exec sp_trace_setevent @TraceID, 75, 17, @on
		exec sp_trace_setevent @TraceID, 75, 18, @on
		exec sp_trace_setevent @TraceID, 75, 21, @on
		exec sp_trace_setevent @TraceID, 75, 31, @on
		exec sp_trace_setevent @TraceID, 75, 34, @on
		exec sp_trace_setevent @TraceID, 76, 1, @on
		exec sp_trace_setevent @TraceID, 76, 9, @on
		exec sp_trace_setevent @TraceID, 76, 11, @on
		exec sp_trace_setevent @TraceID, 76, 12, @on
		exec sp_trace_setevent @TraceID, 76, 13, @on
		exec sp_trace_setevent @TraceID, 76, 14, @on
		exec sp_trace_setevent @TraceID, 76, 16, @on
		exec sp_trace_setevent @TraceID, 76, 17, @on
		exec sp_trace_setevent @TraceID, 76, 18, @on
		exec sp_trace_setevent @TraceID, 76, 21, @on
		exec sp_trace_setevent @TraceID, 76, 31, @on
		exec sp_trace_setevent @TraceID, 76, 34, @on
		exec sp_trace_setevent @TraceID, 77, 1, @on
		exec sp_trace_setevent @TraceID, 77, 9, @on
		exec sp_trace_setevent @TraceID, 77, 11, @on
		exec sp_trace_setevent @TraceID, 77, 12, @on
		exec sp_trace_setevent @TraceID, 77, 13, @on
		exec sp_trace_setevent @TraceID, 77, 14, @on
		exec sp_trace_setevent @TraceID, 77, 16, @on
		exec sp_trace_setevent @TraceID, 77, 17, @on
		exec sp_trace_setevent @TraceID, 77, 18, @on
		exec sp_trace_setevent @TraceID, 77, 21, @on
		exec sp_trace_setevent @TraceID, 77, 31, @on
		exec sp_trace_setevent @TraceID, 77, 34, @on
		exec sp_trace_setevent @TraceID, 78, 1, @on
		exec sp_trace_setevent @TraceID, 78, 9, @on
		exec sp_trace_setevent @TraceID, 78, 11, @on
		exec sp_trace_setevent @TraceID, 78, 12, @on
		exec sp_trace_setevent @TraceID, 78, 13, @on
		exec sp_trace_setevent @TraceID, 78, 14, @on
		exec sp_trace_setevent @TraceID, 78, 16, @on
		exec sp_trace_setevent @TraceID, 78, 17, @on
		exec sp_trace_setevent @TraceID, 78, 18, @on
		exec sp_trace_setevent @TraceID, 78, 21, @on
		exec sp_trace_setevent @TraceID, 78, 31, @on
		exec sp_trace_setevent @TraceID, 78, 34, @on
		exec sp_trace_setevent @TraceID, 79, 1, @on
		exec sp_trace_setevent @TraceID, 79, 9, @on
		exec sp_trace_setevent @TraceID, 79, 11, @on
		exec sp_trace_setevent @TraceID, 79, 12, @on
		exec sp_trace_setevent @TraceID, 79, 13, @on
		exec sp_trace_setevent @TraceID, 79, 14, @on
		exec sp_trace_setevent @TraceID, 79, 16, @on
		exec sp_trace_setevent @TraceID, 79, 17, @on
		exec sp_trace_setevent @TraceID, 79, 18, @on
		exec sp_trace_setevent @TraceID, 79, 21, @on
		exec sp_trace_setevent @TraceID, 79, 31, @on
		exec sp_trace_setevent @TraceID, 79, 34, @on
		exec sp_trace_setevent @TraceID, 80, 1, @on
		exec sp_trace_setevent @TraceID, 80, 9, @on
		exec sp_trace_setevent @TraceID, 80, 11, @on
		exec sp_trace_setevent @TraceID, 80, 12, @on
		exec sp_trace_setevent @TraceID, 80, 13, @on
		exec sp_trace_setevent @TraceID, 80, 14, @on
		exec sp_trace_setevent @TraceID, 80, 16, @on
		exec sp_trace_setevent @TraceID, 80, 17, @on
		exec sp_trace_setevent @TraceID, 80, 18, @on
		exec sp_trace_setevent @TraceID, 80, 21, @on
		exec sp_trace_setevent @TraceID, 80, 31, @on
		exec sp_trace_setevent @TraceID, 80, 34, @on
		exec sp_trace_setevent @TraceID, 100, 1, @on
		exec sp_trace_setevent @TraceID, 100, 9, @on
		exec sp_trace_setevent @TraceID, 100, 11, @on
		exec sp_trace_setevent @TraceID, 100, 12, @on
		exec sp_trace_setevent @TraceID, 100, 13, @on
		exec sp_trace_setevent @TraceID, 100, 14, @on
		exec sp_trace_setevent @TraceID, 100, 16, @on
		exec sp_trace_setevent @TraceID, 100, 17, @on
		exec sp_trace_setevent @TraceID, 100, 18, @on
		exec sp_trace_setevent @TraceID, 100, 21, @on
		exec sp_trace_setevent @TraceID, 100, 31, @on
		exec sp_trace_setevent @TraceID, 100, 34, @on
	END
	
	--( Set a filter
	IF @nTraceType = 0
		exec sp_trace_setfilter @TraceID, 10, 0, 7, N'SQL Profiler'
	
	--== Start the Trace ==--
	
	EXEC @nReturnCode = sp_trace_setstatus @TraceID, 1

	IF NOT @nReturnCode = 0 BEGIN
		SET @nvcErrMsg = N'StartTrace: Couldn''t start the trace with sp_trace_setstatus'
		GOTO Fail
	END

	GOTO Finish

Fail:
	RAISERROR (@nvcErrMsg, 16, 1)
	SELECT ErrorCode = @nReturnCode
	
	--( Stop the trace
	EXEC sp_trace_setstatus @TraceID, 0	
	--( Close the trace
	EXEC sp_trace_setstatus @TraceID, 2

Finish:
	GO


/**************************************************************************
 * Procedure: StopTrace$
 *
 * Description: 
 *	Stops the trace indicated by the parameter @iTraceId
 *
 * Parameters: 
 *	@iTraceID The Trace ID number of the trace to stop. 
 *
 * Notes:
 *	This is the sister proc to StartTrace$.
 *
 *	If you don't know the trace number, run StopTraces$, which will
 *      stop all traces.
 *************************************************************************/

if object_id('StopTrace$') is not null begin
	print 'removing proc StopTrace$'
	drop procedure [StopTrace$]
end
go
print 'creating procedure StopTrace$'
go

CREATE PROCEDURE [StopTrace$]
	--( Chances are the trace ID is 1.
	@iTraceId INT = 1
AS
	--( Stop the trace
	EXEC sp_trace_setstatus @ITraceID, 0	
	--( Close the trace
	EXEC sp_trace_setstatus @ITraceID, 2

GO

/**************************************************************************
 * Procedure: StopTraces$
 *
 * Description: 
 *	Stops all traces
 *
 * Notes:
 *	If you want to stop just one trace, use StopTrace$
 *************************************************************************/

if object_id('StopTraces$') is not null begin
	print 'removing proc StopTraces$'
	drop procedure [StopTraces$]
end
go
print 'creating procedure StopTraces$'
go

CREATE PROCEDURE [StopTraces$]
AS

--(The assumption here is that all traces need to be stopped

DECLARE @traceID INT
DECLARE traces CURSOR LOCAL FAST_FORWARD FOR
	SELECT DISTINCT traceid
	FROM ::fn_trace_getinfo(DEFAULT)

OPEN traces
FETCH NEXT FROM traces INTO @traceid
WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC sp_trace_setstatus @traceID, 0
	EXEC sp_trace_setstatus @traceID, 2 
	FETCH NEXT FROM traces INTO @traceid
END
CLOSE traces
DEALLOCATE traces

GO

/***********************************************************************************************
	User settings.
	The denys will be added once everything else is updated.
***********************************************************************************************/
-- deny insert, update, delete on CmObject to FwDeveloper
-- deny insert, update, delete on MultiStr$ to FwDeveloper
-- deny insert, update, delete on MultiTxt$ to FwDeveloper
-- deny insert, update, delete on MultiBigStr$ to FwDeveloper
-- deny insert, update, delete on MultiBitTxt$ to FwDeveloper
-- go

/*****************************************************************************
 * GetFwUsers
 *
 * Description: Get the list of users defined for the current FW server. Any
 * underscores in the username are replaced with spaces
 *
 * Parameters:
 *	none
 * Returns: list of users
 *
 *****************************************************************************/

if object_id('GetFwUsers') is not null begin
	print 'removing proc GetFwUsers'
	drop procedure GetFwUsers
end
go
print 'creating procedure GetFwUsers'
go

create proc GetFwUsers
as
	select REPLACE(name, '_', ' ') "name"
	from master.dbo.syslogins
	where isntgroup != 1
	and isntuser !=1
	and name != 'FWDeveloper'
	and name != 'sa'
GO

/**************************************************************************
 * Procedure: LockDetails
 *
 * Description: 
 * ============
 *	Returns Detailed lock info
 *
 * Parameters:
 * ===========
 *	@nvcOption: See sample calls below for options
 *	@nManageTempTable 1 = yes (default) stored proc will handle temp table,
 *		0 = no -- the calling program will manage a temp table called
 *		#tblLockInfo.
 *
 * Notes:
 * ======
 *	See: "Understanding Locking in SQL Server", "sp_lock", and "Displaying
 *	Locking Information" for more information about locks.
 *
 *	In sp_lock, the Status column shows if the lock has been obtained
 *	(GRANT), is blocking on another process (WAIT), or is being converted
 *	to another lock (CNVT). A lock being converted to another lock is held
 *	in one mode, but is waiting to acquire a stronger lock mode (for
 *	example, update to exclusive). When diagnosing blocking issues, a
 *	CNVT can be considered similar to WAIT.
 *
 *	A table variable can not be used when using EXEC. Stored functions
 *	can't access temp tables. A temp table was used here.
 *
 * Sample Calls:
 * =============
 *	EXEC LockDetails 'Blockers' --( will show just blocked process(es),
 *								and processes that might be blockers
 *	EXEC LockDetails 			--( for use with Query Analzer, will show 
 *								locks with English descriptions
 *	EXEC LockDetails 'Generic'	--( Generic report of outstanding locks
 *************************************************************************/

IF OBJECT_ID('LockDetails') IS NOT NULL BEGIN
	PRINT 'removing procedure LockDetails'
	DROP PROCEDURE LockDetails
END
GO
PRINT 'creating procedure LockDetails'
GO

CREATE PROCEDURE LockDetails 
	@nvcOption NVARCHAR(10) = NULL,
	@nManageTempTable TINYINT = 1
AS
	
	DECLARE
		@nShowDescriptions TINYINT,
		@nShowBlocksOnly TINYINT
	
	IF UPPER(@nvcOption) = 'GENERIC' BEGIN
		SET @nShowDescriptions = 0
		SET @nShowBlocksOnly = 0
	END
	ELSE IF UPPER(@nvcOption) = 'BLOCKERS' BEGIN
		SET @nShowDescriptions = 0
		SET @nShowBlocksOnly = 1
	END
	ELSE BEGIN --( IF @nvcOption IS NULL OR UPPER(@nvcOption) = 'DETAILS'
		SET @nShowDescriptions = 1
		SET @nShowBlocksOnly = 0
	END
	
	DECLARE @tblBlocked TABLE (
		spid INT,
		dbid INT,
		ObjId INT,
		IndId INT,
		Type CHAR(5),
		Resource CHAR(20),
		Mode CHAR(10),
		Status CHAR(10))
	
	IF @nManageTempTable = 1
		CREATE TABLE #tblLockInfo (
			spid INT,
			dbid INT,
			ObjId INT,
			IndId INT,
			Type CHAR(5),
			Resource CHAR(20),
			Mode CHAR(10),
			Status CHAR(10))
	
	INSERT INTO #tblLockInfo EXEC sp_lock
	
	--==( Showing descriptions )==--
	
	IF @nShowDescriptions != 0
		
		SELECT
			li.spid,
			(SELECT DISTINCT program_name 
				FROM master..sysprocesses
				WHERE spid = li.spid) AS ProgramName,
			li.dbid,
			DB_NAME(li.dbid) AS DatabaseName,
			li.ObjId,
			ISNULL(OBJECT_NAME(li.ObjId), '') AS ObjectName,
			li.IndId,
			li.Type,
			TypeDescription = CASE li.Type
				WHEN 'RID' THEN 'Single row lock'
				WHEN 'KEY' THEN 'Row lock in an index, to protect key ranges in serializable'
				WHEN 'PAG' THEN 'Data or Index page lock'
				WHEN 'EXT' THEN 'Contiguous group of 8 data pages or indexes pages'
				WHEN 'TAB' THEN 'Entire table lock, including data and indexes'
				WHEN 'DB' THEN 'Database lock'
				END,
			li.Resource,
			ResourceDescription = CASE li.Resource
				WHEN 'RID' THEN 'Row identifier'
				WHEN 'KEY' THEN 'Hex # used internally by SQL Server'
				WHEN 'PAG' THEN 'Page number The page is identified by a fileid:page ' + 
					'combination, where fileid is the fileid in the sysfiles ' +
					'table, and page is the logical page number within that file.'
				WHEN 'EXT' THEN 'First page number in the extent being locked. The page ' +
					'is identified by a fileid:page combination.'
				WHEN 'TAB' THEN 'See ObjId column for the ID of the table.'
				WHEN 'DB' THEN 'See DbId column for the ID of the database.'
				ELSE ''
				END,
			li.Mode,
			ModeDescription = CASE li.Mode
				WHEN 'IS' THEN 'Intent shared'
				WHEN 'S' THEN 'Shared'
				WHEN 'U' THEN 'Update'
				WHEN 'IX' THEN 'Intent Exclusive'
				WHEN 'SIX' THEN 'Shared Intent Exclusive'
				WHEN 'X' THEN 'Exclusive'
				WHEN 'Sch-M' THEN 'Schema Modification'
				WHEN 'Sch-S' THEN 'Schema Stability'
				WHEN 'BU' THEN 'Bulk Update'
				END,
			li.Status
		FROM #tblLockInfo li

	ELSE BEGIN --( IF @nShowDescriptions = 0
		
		--==( If looking for blocked and blocking processes )==--
		
		IF @nShowBlocksOnly = 1 BEGIN
			
			INSERT INTO @tblBlocked
			SELECT spid, dbid, ObjId, IndId, Type, Resource, Mode, Status
			FROM #tblLockInfo
			WHERE Status = 'WAIT'
			
			SELECT
				b.spid,
				(SELECT DISTINCT program_name 
					FROM master..sysprocesses
					WHERE spid = b.spid) AS ProgramName,
				b.dbid,
				DB_NAME(b.dbid) AS DatabaseName,
				b.ObjId,
				ISNULL(OBJECT_NAME(b.ObjId), '') AS ObjectName,
				b.IndId,
				b.Type,
				b.Resource,
				b.Mode,
				b.Status
			FROM @tblBlocked b
			UNION
			SELECT
				li.spid,
				(SELECT DISTINCT program_name 
					FROM master..sysprocesses
					WHERE spid = li.spid) AS ProgramName,
				li.dbid,
				DB_NAME(li.dbid) AS DatabaseName,
				li.ObjId,
				ISNULL(OBJECT_NAME(li.ObjId), '') AS ObjectName,
				li.IndId,
				li.Type,
				li.Resource,
				li.Mode,
				li.Status
			FROM @tblBlocked b
			JOIN #tblLockInfo li ON li.dbid = b.dbid
				AND li.ObjId = b.ObjId
				AND li.Resource = b.Resource
			WHERE li.Status != 'WAIT'
		END
		
		--==( Generic report of locks for calling program )==--
		
		ELSE --( IF @nShowBlocksOnly = 0
			SELECT
				li.spid,
				(SELECT DISTINCT program_name 
					FROM master..sysprocesses
					WHERE spid = li.spid) AS ProgramName,
				li.dbid,
				DB_NAME(li.dbid) AS DatabaseName,
				li.ObjId,
				ISNULL(OBJECT_NAME(li.ObjId), '') AS ObjectName,
				li.IndId,
				li.Type,
				li.Resource,
				li.Mode,
				li.Status
			FROM #tblLockInfo li
			WHERE DB_NAME(li.dbid) != 'tempdb' AND DB_NAME(li.dbid) != 'master'
	END --( IF @nShowDescriptions = 0
	
	IF @nManageTempTable = 1
		DROP TABLE #tblLockInfo 
	
	RETURN
GO

/***********************************************************************************************
 * Procedure: GetUndoDelObjInfo
 *
 * Description
 *  retrieves the information needed to undo deleting an object or set of objects
 *
 * Parameters:
 *	@ObjId=the object for which all linked objects will be gathered;
 * 	@hXMLDocObjList=handle to a parsed XML document that contains multiple object Ids - the
 *		undo information will be produced for each of these objectIds;
 *
 * 	Objects should be specified using either the @ObjId parameter or through an XML 
 *	document (the @hXMLDocObjList parameter is a handle to a parsed XML document) but not
 *	both. The XML document should be in the format:
 *		<root>
 *			<ObjId="1"/>
 *			<ObjId="2"/>
 *		</root>
 *
 * Assumptions:
 *	This procedure assumes that the calling application/procedure has created the 
 *	temporary table #UndoDelObjInfo with the following structure:
 *
 *	CREATE TABLE #UndoDelObjInfo
 *	(
 *		Type INT,					-- type of the property (negated for incoming refs)
 *		ObjId INT,					-- object id
 *		Flid INT,					-- field id of the property
 *		IntVal INT,					-- value: Boolean, Integer, GenDate, Atomic Ref, Ws of
 *										multilingual unicode/string, Src of incoming
 *		TimeVal DATETIME,			-- value: Time
 *		GuidVal UNIQUEIDENTIFIER,	-- value: Guid
 *		ImageVal IMAGE,				-- value: Image, or Fmt of formatted big string
 *		TextVal NTEXT,				-- value: big Unicode, or Txt of formatted big string
 *		Ord INT						-- value: ord of Ref sequence, either outgoing or incoming
 *	)
 *
 * Example:
 *	This is an example of how to get the undo information for deleting the object with id 6111
 *
 *	CREATE TABLE #UndoDelObjInfo
 *	(
 *		Type INT,
 *		ObjId INT,
 *		Flid INT,
 *		IntVal INT,
 *		TimeVal DATETIME,
 *		GuidVal UNIQUEIDENTIFIER,
 *		ImageVal IMAGE,
 *		TextVal NTEXT,
 *		Ord INT
 *	)
 *	exec GetUndoDelObjInfo 6111
 *	select * from #UndoDelObjInfo ORDER BY Type, ObjId, Flid, Ord
 *	drop table #UndoDelObjInfo
 *
 **********************************************************************************************/
IF OBJECT_ID('GetUndoDelObjInfo') is not null BEGIN
	PRINT 'removing proc GetUndoDelObjInfo'
	DROP PROC GetUndoDelObjInfo
END
GO
PRINT 'creating proc GetUndoDelObjInfo'
GO
CREATE PROC GetUndoDelObjInfo
	@ObjId int=null,
	@hXMLDocObjList int=null
AS
	-- make sure that nocount is turned on
	DECLARE @fIsNocountOn INT
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON

	CREATE TABLE  #ObjInfoForDelete (
		ObjId			INT NOT NULL,
		ObjClass		INT NULL,
		InheritDepth	INT NULL DEFAULT(0),
		OwnerDepth		INT NULL DEFAULT(0),
		Owner			INT NULL,
		OwnerClass		INT NULL,
		OwnFlid			INT NULL,
		OwnOrd			INT NULL,
		OwnPropType		INT NULL,
		OrdKey			VARBINARY(250) NULL DEFAULT(0))
	CREATE NONCLUSTERED INDEX #Ind_ObjInfo_ObjId ON dbo.#ObjInfoForDelete (ObjId)

	INSERT INTO #ObjInfoForDelete
	SELECT * FROM dbo.fnGetOwnedObjects$(
		@ObjId,			-- single objeect id
		@hXMLDocObjList,-- xml list of object ids
		null,			-- we want all owning prop types
		1,				-- we want base class records
		0,				-- but not subclasses
		1,				-- we want recursion (all owned, not just direct)
		null,			-- we want objects of any class
		0)				-- we don't need an 'order key'

	DECLARE @PropType INT
	SET @PropType = 1
	DECLARE @ClassName NVARCHAR(100)
	DECLARE @FieldName NVARCHAR(100)
	DECLARE @Flid INT

	DECLARE @props TABLE(type INT, flid INT)
	INSERT INTO @props
	SELECT DISTINCT f.type, f.id
	FROM Field$ f
	JOIN #ObjInfoForDelete oo ON oo.ObjClass = f.class

	DECLARE @sQry NVARCHAR(4000)
	DECLARE @sPropType NVARCHAR(20)
	DECLARE @sFlid NVARCHAR(20)

	SELECT TOP 1 @flid = flid, @PropType = type FROM @props ORDER BY flid
	WHILE @@rowcount > 0
	BEGIN
		SELECT @FieldName = f.Name, @Flid = f.Id, @ClassName = c.Name
		FROM Field$ f
		JOIN Class$ c ON c.Id = f.Class
		WHERE f.Type = @PropType AND f.Id = @Flid
		SET @sPropType = CONVERT(NVARCHAR(20), @PropType)
		SET @sFlid = CONVERT(NVARCHAR(20), @Flid)

		SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Id,' + @sFlid + ', '
		IF @PropType in (1,2,8,24) BEGIN	-- Boolean, Integer, GenDate, RefAtomic
			SET @sQry = @sQry + 
				'[' + @FieldName + '], null, null, null, null, null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		-- 3 (Numeric) and 4 (Float) are never used (as of January 2005)
		ELSE IF @PropType = 5 BEGIN		-- Time
			SET @sQry = @sQry +
				'null, [' + @FieldName + '], null, null, null, null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		ELSE IF @PropType = 6 BEGIN		-- Guid
			SET @sQry = @sQry +
				'null, null, [' + @FieldName + '], null, null, null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		ELSE IF @PropType in (7,9) BEGIN	-- Image, Binary
			SET @sQry = @sQry +
				'null, null, null, [' + @FieldName + '], null, null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		-- 10,11,12 are unassigned values (as of January 2005)
		ELSE IF @PropType in (13,17) BEGIN		-- String, BigString
			SET @sQry = @sQry + 'null, null, null, ' +
				@FieldName + '_Fmt, [' + @FieldName + '], null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		ELSE IF @PropType in (14,18) BEGIN		-- MultiString, MultiBigString
			SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Obj,' + @sFlid +
				', Ws, null, null, Fmt, Txt, null ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Obj in (select ObjId from #ObjInfoForDelete) and Txt is not null'
		END
		ELSE IF @PropType in (15,19) BEGIN		-- Unicode, BigUnicode
			SET @sQry = @sQry +
				'null, null, null, null, [' + @FieldName + '], null ' +
				'from ' + @ClassName + ' where Id in (select ObjId from #ObjInfoForDelete) ' +
				'and [' + @FieldName + '] is not null'
		END
		ELSE IF @PropType in (16,20) BEGIN		-- MultiUnicode, MultiBigUnicode
			-- (MultiBigUnicode is unused as of January 2005)
			SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Obj,' + @sFlid +
				', Ws, null, null, null, Txt, null ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Obj in (select ObjId from #ObjInfoForDelete) and Txt is not null'
		END
		-- 21,22 are unassigned (as of January 2005)
		-- 23,25,27 are Owning Properties, which are handled differently from Value/Reference
		--          Properties
		ELSE IF @PropType = 26 BEGIN		-- RefCollection
			SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Src,' + @sFlid +
				', Dst, null, null, null, null, null ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Src in (select ObjId from #ObjInfoForDelete)'
		END
		ELSE IF @PropType = 28 BEGIN		-- RefSequence
			SET @sQry = 'insert into #UndoDelObjInfo select ' + @sPropType + ',Src,' + @sFlid +
				', Dst, null, null, null, null, Ord ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Src in (select ObjId from #ObjInfoForDelete) order by Ord'
		END
		ELSE BEGIN
			SET @sQry = null
		END
		IF (@sQry is not null) BEGIN
		--	PRINT @sQry
			EXEC (@sQry)
		END
		SELECT TOP 1 @flid = flid, @PropType = type FROM @props WHERE flid > @flid ORDER BY flid
	END

	-- Now do incoming references. Note that we exclude references where the SOURCE of the
	-- reference is in the deleted object collection, as those references will be reinstated
	-- by code restoring the forward ref properties.  Incoming references are marked in the
	-- table by negative values in the Type field.

	DELETE FROM @props
	INSERT INTO @props
	SELECT DISTINCT f.type, f.id
	FROM Field$ f
	JOIN #ObjInfoForDelete oo ON oo.ObjClass = f.DstCls AND f.type IN (24, 26, 28)

	SELECT TOP 1 @flid = flid, @PropType = type FROM @props ORDER BY flid
	WHILE @@rowcount > 0
	BEGIN
		SELECT @FieldName = f.Name, @Flid = f.Id, @ClassName = c.Name
		FROM Field$ f
		JOIN Class$ c ON c.Id = f.Class
		WHERE f.Type = @PropType AND f.Id = @Flid
		SET @sPropType = CONVERT(NVARCHAR(20), @PropType)
		SET @sFlid = CONVERT(NVARCHAR(20), @Flid)

		IF @PropType = 24 BEGIN				-- RefAtomic
			SET @sQry = 'insert into #UndoDelObjInfo select -' + @sPropType +
				', [' + @FieldName + '], ' + @sFlid +
				', Id, null, null, null, null, null ' +
				'from ' + @ClassName +
				' where [' + @FieldName + '] in (select ObjId from #ObjInfoForDelete)' +
				' and Id not in (select ObjId from #ObjInfoForDelete)'
		END
		ELSE IF @PropType = 26 BEGIN		-- RefCollection
			SET @sQry = 'insert into #UndoDelObjInfo select -' + @sPropType + ',Dst,' + @sFlid +
				', Src, null, null, null, null, null ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Dst in (select ObjId from #ObjInfoForDelete)' +
				' and Src not in (select ObjId from #ObjInfoForDelete)' +
				' order by Src'
		END
		ELSE IF @PropType = 28 BEGIN		-- RefSequence
			SET @sQry = 'insert into #UndoDelObjInfo select -' + @sPropType + ',Dst,' + @sFlid +
				', Src, null, null, null, null, Ord ' +
				'from ' + @ClassName + '_' + @FieldName +
				' where Dst in (select ObjId from #ObjInfoForDelete)' +
				' and Src not in (select ObjId from #ObjInfoForDelete)' +
				' order by Src, Ord'
		END
		ELSE BEGIN
			SET @sQry = null
		END
		IF (@sQry is not null) BEGIN
		--	PRINT @sQry
			EXEC (@sQry)
		END
		SELECT TOP 1 @flid = flid, @PropType = type FROM @props WHERE flid > @flid ORDER BY flid
	END

	-- if we turned on nocount, turn it off
	IF @fIsNocountOn = 0 SET NOCOUNT OFF

	RETURN @@error
GO

/*****************************************************************************
 * TransferAnnotation
 *
 * Description: Transfer all annotations which both begin and end on 'oldObj' 
 * to point to 'newObj' instead. Also add 'delta' to the BeginOffset and 
 * EndOffset of each transferred annotation.
 *
 * Parameters:
 *	@oldObj -- object to move annotations from
 *	@newObj -- object to move them to
 *	@delta -- amount to add to BeginOffset and EndOffset
 *
 * Returns: none
  *****************************************************************************/

if object_id('TransferAnnotation') is not null begin
	print 'removing proc TransferAnnotation'
	drop procedure TransferAnnotation
end
go
print 'creating procedure TransferAnnotation'
go
create proc TransferAnnotation
	@oldObj int,
	@newObj int,
	@delta int
as
update CmBaseAnnotation set
	BeginOffset = BeginOffset + @delta, BeginObject = @newObj,
	EndOffset = EndOffset + @delta, EndObject = @newObj
where BeginObject = @oldObj and EndObject = @oldObj
GO

/***********************************************************************************************
 * Function: fnGetFormatForWs
 *
 * Description: 
 *	Create the minimal format value for a string in the given writing system.  This is needed,
 *  for example, in data migration when the type of a field has changed from Unicode to String.
 *
 * Parameters: 
 *	@ws = database id of a writing system
 *
 * Returns: 
 *   varbinary(20) value containing the desired format value (which uses 19 of the 20 bytes)
 *
 * Notes: 
 *   This is more deterministic and reliable than former approaches, which were not even as good
 *   as the following SQL:
 *		SELECT TOP 1 Fmt
 *		FROM MultiStr$
 *		WHERE Ws=@ws AND DATALENGTH(Fmt) = 19
 *		GROUP BY Fmt
 *		ORDER BY COUNT(Fmt) DESC
 **********************************************************************************************/
if object_id('fnGetFormatForWs') is not null begin
	print 'removing function fnGetFormatForWs'
	drop function fnGetFormatForWs
end
go

create function fnGetFormatForWs (@ws int)
returns varbinary(20)
as
begin
	DECLARE @hexVal varbinary(20)

	-- one run with one property (the writing system), starting at the beginning of the string
	SET @hexVal= 0x010000000000000000000000010006

	-- CAST (@ws AS varbinary(4)) puts the bytes in the wrong order for the format string,
	-- so we'll add it one byte at a time in the desired order.
	DECLARE @byte int, @x1 int
	SET @byte = @ws % 256
	SET @x1 = @ws / 256
	SET @hexVal = @hexVal  + CAST (@byte AS varbinary(1))

	SET @byte = @x1 % 256
	SET @x1 = @x1 / 256
	SET @hexVal = @hexVal  + CAST (@byte AS varbinary(1))

	SET @byte = @x1 % 256
	SET @x1 = @x1 / 256
	SET @hexVal = @hexVal  + CAST (@byte AS varbinary(1))

	SET @byte = @x1 % 256
	return @hexVal  + CAST (@byte AS varbinary(1))
end
go
