/***********************************************************************************************
	Final model creation processes for language projects.

	Note: These declarations need to be ordered, such that if stored procedure X
	calls stored procedure Y, then X should be created first, then Y.
	Doing this avoids an error message about dendencies.
***********************************************************************************************/

print '****************************** Loading LangProjSP.sql ******************************'
go

--
-- post model creation performance enhancements
--

-- once the model is built very few modifications are made to the following 
--	tables, so use a 95% fillfactor
dbcc dbreindex ('Field$', '', 95)

-- once the model is built no modifications are made to the following tables, 
--	so use a 100% fillfactor
dbcc dbreindex ('Class$', '', 100)
dbcc dbreindex ('ClassPar$', '', 100)
go

--
-- create CreateObject_ procedures for all non-abstract classes
--
begin
	print 'creating CreateObject_ procedures...'

	declare @sClassName sysname, @clid int

	declare class_cur cursor local fast_forward for
	select	[Name], [Id]
	from	[Class$]
	where	[Abstract] = 0

	-- loop through each non-abstract class and build an ObjectCreate_ procedure
	open class_cur
	fetch class_cur into @sClassName, @clid
	while @@fetch_status = 0 begin
		exec DefineCreateProc$ @clid
		fetch class_cur into @sClassName, @clid
	end

	close class_cur
	deallocate class_cur
end
go

--( Creating delete triggers

BEGIN
	PRINT 'Creating delete triggers...'
	DECLARE	@nClassId INT
	--( First class
	SELECT TOP 1 @nClassId = Id FROM Class$ ORDER BY Id
	WHILE @@ROWCOUNT != 0 BEGIN
		EXEC CreateDeleteObj @nClassId
		--( Next class	
		SELECT TOP 1 @nClassId = Id FROM Class$ WHERE Id > @nClassId ORDER BY Id
	END
END
GO

--
-- create class views that contain all base classes including CmObject
--
begin
	print 'creating class views...'

	declare @depth int, @clid int, @sClass sysname

	create table #tblInheritStack (depth int, clid int)
	create clustered index ind_#tblInheritStack on #tblInheritStack (depth)

	-- start with CmObject
	insert into #tblInheritStack (Depth, clid)
	select	0, [Id]
	from	[Class$] 
	where	name = 'CmObject'

	-- loop through the inheritance hierarchy and build the inheritance stack
	set @depth = 0
	while 1 = 1 begin
		insert into #tblInheritStack (Depth, clid)
		select	@depth+1, cp.[Src]
		from	[ClassPar$] cp join #tblInheritStack inhstack on cp.[Dst] = inhstack.[clid]
		where	cp.[Depth] = 1
			and inhstack.[Depth] = @depth
		if @@rowcount = 0 break

		set @depth = @depth + 1
	end

	declare classview_cur cursor local fast_forward for
	select	[clid]
	from	#tblInheritStack
	where	depth > 0
	order by [Depth]

	open classview_cur
	fetch classview_cur into @clid
	while @@fetch_status = 0 begin
		select	@sClass = [Name]
		from	Class$
		where	[Id] = @clid
		exec UpdateClassView$ @clid, 0
		fetch classview_cur into @clid
	end
	close classview_cur
	deallocate classview_cur
	
	drop table #tblInheritStack
end
go

-----------------------------------------------------------------
--( Now that all the views for all the tables have been created,
--( we can put in a second insert trigger on Field$. This will
--( regen the associated view to a table whenever a new column 
--( is added to a table. It will also regen the CreateObject_*
--( stored procedure, using DefineCreateProc$.
-----------------------------------------------------------------

/***********************************************************************************************
 * Trigger: TR_Field$_UpdateModel_InsLast
 *
 * Description:
 *	TR_Field$_UpdateModel_Ins takes care of most of the work of making sure the database
 *	is OK when adding a new field to a table. Unfortunately, it didn't rebuild the associated
 *	view in most cases, using UpdateClassView$. If we put did put the following code into
 *	that trigger, UpdateClassView$ would be called twice for each field when creating a new
 *	database, once by the trigger, and once by LangProjSP.sql. LangProjSP.sql makes sure the
 *	views are created with the proper class hierarchy, whereas UpdateClassView$ does not.
 *	This trigger was written to take care of that problem. In addition, the CreateObject_*
 *	stored procedure was not being regenerated, and this trigger takes tare of that, too.
 *	Finally, some of the delete object functionality was moved here.
 *
 *	The trigger is intended to fire after all other insert triggers on the Field$ table.
 *
 * Type: 	Insert
 * Table:	Field$
 *
 * Notes:
 *	To make sure this trigger fires last, execute the following after the trigger is created:
 *	
 *		EXEC sp_settriggerorder 'TR_Field$_UpdateModel_InsLast', 'last', 'INSERT'
 **********************************************************************************************/

IF OBJECT_ID('TR_Field$_UpdateModel_InsLast') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_Field$_UpdateModel_InsLast'
	DROP TRIGGER TR_Field$_UpdateModel_InsLast
END
GO
PRINT 'creating trigger TR_Field$_UpdateModel_InsLast'
GO

CREATE TRIGGER TR_Field$_UpdateModel_InsLast ON Field$ FOR INSERT
AS
	DECLARE
		@nErr INT,
		@nClassid INT,
		@nAbstract BIT,
		@nLoopLevel TINYINT,
		@fExit BIT
		
	DECLARE @tblSubclasses TABLE (ClassId INT, Abstract BIT, ClassLevel TINYINT)
	
	SELECT @nClassId = Class FROM inserted
	SET @nLoopLevel = 1
	
	--==( Outer loop: all the classes for the level )==--
	
	--( This insert is necessary for any subclasses. It also 
	--( gets Class$.Abstract for updating the CreateObject_*
	--( stored procedure.
	
	INSERT INTO @tblSubclasses
	SELECT @nClassId, c.Abstract, @nLoopLevel
	FROM Class$ c
	WHERE c.Id = @nClassId
	
	--( Rebuild the delete trigger
	
	EXEC @nErr = CreateDeleteObj @nClassId
	IF @nErr <> 0 GOTO LFail
	
	--( Rebuild CreateObject_*
 			
	SELECT @nAbstract = Abstract FROM @tblSubClasses
	IF @nAbstract != 1 BEGIN
		EXEC @nErr = DefineCreateProc$ @nClassId
		IF @nErr <> 0 GOTO LFail
	END
	
	SET @fExit = 0	
	WHILE @fExit = 0 BEGIN
		
		--( Inner loop: update all classes subclassed from the previous
		--( set of classes.
		
		SELECT TOP 1 @nClassId = ClassId, @nAbstract = Abstract
		FROM @tblSubclasses
		WHERE ClassLevel = @nLoopLevel
		ORDER BY ClassId
		
		WHILE @@ROWCOUNT > 0 BEGIN
			
			--( Update the view
			
 			EXEC @nErr = UpdateClassView$ @nClassId, 1
 			IF @nErr <> 0 GOTO LFail
			
			--( Get next class
			
			SELECT TOP 1 @nClassId = ClassId, @nAbstract = Abstract
			FROM @tblSubclasses
			WHERE ClassLevel = @nLoopLevel AND ClassId > @nClassId
			ORDER BY ClassId			
		END
		
		--( Load outer loop with next level
		SET @nLoopLevel = @nLoopLevel + 1
		
		INSERT INTO @tblSubclasses
		SELECT c.Id, c.Abstract, @nLoopLevel
		FROM @tblSubClasses sc
		JOIN Class$ c ON c.Base = sc.ClassId
		WHERE sc.ClassLevel = @nLoopLevel - 1
		
		IF @@ROWCOUNT = 0
			SET @fExit = 1
	END
		
	RETURN

LFail:
 	ROLLBACK TRANSACTION
 	RETURN

GO

EXEC sp_settriggerorder 'TR_Field$_UpdateModel_InsLast', 'last', 'INSERT'
GO

/***********************************************************************************************
 * Trigger: TR_Class$_InsLast
 *
 * Description:
 *	TR_Class$_Ins takes care of most of the work of making sure the database is OK when adding
 *	a new class to a table. Unfortunately, it didn't rebuild the associated CreateObject_*
 *	stored procedure, using DefineCreateProc$. If we put did put the following code into
 *	that trigger, DefineCreateProc$ would be called twice for each class when creating a new
 *	database, once by the trigger, and once by LangProjSP.sql. This procedure is created after 
 *	the views created in LangProjSP.sql. It is intended to fire after all other insert triggers 
 *	on the Field$ table.
 *
 * Type: 	Insert
 * Table:	Class$
 *
 * Notes:
 *	To make sure this trigger fires last, execute the following after the trigger is created:
 *	
 *		EXEC sp_settriggerorder 'TR_Class$_InsLast', 'last', 'INSERT'
 **********************************************************************************************/

IF OBJECT_ID('TR_Class$_InsLast') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_Class$_InsLast'
	DROP TRIGGER TR_Class$_InsLast
END
GO
PRINT 'creating trigger TR_Class$_InsLast'
GO

CREATE TRIGGER TR_Class$_InsLast ON Class$ FOR INSERT
AS
	DECLARE
		@nErr INT,
		@nClassid INT,
		@nAbstract BIT
	
	SELECT @nClassId = Id, @nAbstract = Abstract FROM inserted
	
	--( Build the CreateObject_ stored procedure
	IF @nAbstract = 0 BEGIN
		EXEC @nErr = DefineCreateProc$ @nClassId
		IF @nErr <> 0 GOTO LFail
	END
	
	--( Build the delete trigger
	EXEC @nErr = CreateDeleteObj @nClassId
	IF @nErr <> 0 GOTO LFail	
	
	RETURN

LFail:
	ROLLBACK TRANSACTION
	RETURN
GO


EXEC sp_settriggerorder 'TR_Class$_InsLast', 'last', 'INSERT'
GO

/***********************************************************************************************
	SQL scripts used to arrange CmObject data from a FieldWorks database 
	in a hierarchical structure to facilitate writing the data to a file in XML format.
***********************************************************************************************/

if not object_id('ObjHierarchy$') is null begin
	print 'removing table ObjHierarchy$'
	drop table ObjHierarchy$
end
print 'creating table ObjHierarchy$'
go
create table ObjHierarchy$ (
	strDepth varchar(50),
	intDepth int,
	ownOrd int,
	ownFlid int,
	owner int,
	class int,
	guid uniqueidentifier,
	id int
)
create index idx_id on ObjHierarchy$ (id)
create index idx_strDepth on ObjHierarchy$ (strDepth)
create index idx_flid on ObjHierarchy$ (ownFlid)
create index idx_owner on ObjHierarchy$ (owner)
go


/***********************************************************************************************
	This procedure copies all CmObjects to the ObjHierarchy$ table and orders
	them in a hierarchy according to ownership as ordered by the strDepth column. 
	This is a string column and so string comparisons are used to order it.
	To list the objects in order of ownership enter
	    select * from ObjHierarchy$ order by strDepth
***********************************************************************************************/
if not object_id('UpdateHierarchy') is null begin
	print 'removing proc UpdateHierarchy'
	drop proc UpdateHierarchy
end
print 'creating proc UpdateHierarchy'
go
create proc UpdateHierarchy
as
	set nocount on

	--  Delete all objects in the ObjHierarchy$ table.
	truncate table ObjHierarchy$

	--  Copy all the CmObject records to the ObjHierarchy$ table.
	insert into ObjHierarchy$ (strDepth, intDepth, ownOrd, ownFlid, owner, class, guid, id) 
		select NULL, NULL, ownOrd$, ownFlid$, owner$, class$, guid$, id from CmObject


	--  Set the intDepth=1 and strDepth for top level (root) objects.
	--  These will be numbered according to the order of id.

	declare @intChildCounter int
	declare @intId int
	declare @intNumChildren int
	declare @intNumSigDigits int

	select @intChildCounter=1
	select @intNumChildren=count(*) from ObjHierarchy$ where owner is null
	select @intNumSigDigits=log10(@intNumChildren + 0.5) + 1

	declare curRootObjects cursor FAST_FORWARD for select id from objhierarchy$ where owner is null order by id
	open curRootObjects
	fetch next from curRootObjects into @intId
	while @@fetch_status = 0
	begin
		update ObjHierarchy$ set intDepth=1,
			strDepth=replicate('0', @intNumSigDigits - log10(@intChildCounter + 0.5)) + cast(@intChildCounter as varchar) 
			where id=@intId
		select @intChildCounter=@intChildCounter + 1
		fetch next from curRootObjects into @intId
	end
	close curRootObjects
	deallocate curRootObjects


	--  Determine how many objects there are

	declare @intDepth int
	declare @strDepth varchar(100)

	select @intDepth=2
	select @intNumChildren=count(*) from ObjHierarchy$ where owner in (select id from ObjHierarchy$ where intDepth=1)
	select @intNumSigDigits=log10(@intNumChildren + 0.5) + 1

	while (@intNumChildren > 0)
	begin
		select @intChildCounter=1

		-- This is ordered by FLID and OWNORD so 2 or more owning sequences are not interleaved

		declare curObjects cursor FAST_FORWARD for select c.id, p.strDepth from objhierarchy$ c, objHierarchy$ p where c.owner=p.id and p.intdepth=(select max(intDepth) from ObjHierarchy$ where intDepth is not NULL) order by p.strDepth, c.ownFlid, c.ownOrd, c.id
		open curObjects
		fetch next from curObjects into @intId, @strDepth
		while @@fetch_status = 0
		begin
			update ObjHierarchy$ set intDepth=@intDepth, 
				strDepth=@strDepth + replicate('0', @intNumSigDigits - log10(@intChildCounter + 0.5)) + cast(@intChildCounter as varchar)
				where id=@intId
			select @intChildCounter=@intChildCounter + 1
			fetch next from curObjects into @intId, @strDepth
		end
		close curObjects
		deallocate curObjects

		--  Increment the depth and see if there are more child records
		select @intNumChildren=count(*) from ObjHierarchy$ where owner in (select id from ObjHierarchy$ where intDepth=@intDepth)
		select @intDepth=@intDepth + 1
		if (@@ROWCOUNT = 0 ) return   
		select @intNumSigDigits=log10(@intNumChildren + 0.5) + 1
	end
go


if object_id('dbo.GetStTexts$') is not null
begin
	print 'Removing procedure: GetStTexts$'
	drop proc GetStTexts$
end
go
print 'Creating procedure: GetStTexts$'
go
create proc GetStTexts$
	@uid uniqueidentifier
as
	declare @StTextClassId int

	-- get the StText (structured text) class type
	select	@StTextClassId = id
	from	Class$
	where	name = 'StText'

	-- select the structured text information based on the IDs of class type StText
	select	stp.Src,
		stp.Dst,
		sp.StyleRules,
		sttp.Contents
	from	StText_Paragraphs stp 
			join StPara sp on sp.Id = stp.Dst
			join ObjInfoTbl$ oi (readuncommitted) on stp.Src = oi.ObjId 
			left outer join StTxtPara sttp (readuncommitted) on sttp.Id = sp.Id
	where	oi.uid = @uid
		and oi.ObjClass = @StTextClassId
go


/***********************************************************************************************
	PageSetup$ 
	Description:
		This table is used to persist Page Setup information.
***********************************************************************************************/
-- PageSetup$ table.
if not object_id('PageSetup$') is null
  begin print 'removing table PageSetup$' drop table PageSetup$
end
go


-- Strictly speaking, the "Id" column should have a foreign key constraint to the ID column of
-- CmMajorObject but this would make deletions difficult, and a few stray records in this 
-- table won't hurt.
print 'creating table PageSetup$'
go
create table [PageSetup$] (
	[Id] int primary key clustered,
	[MarginLeft] int not null,
	[MarginRight] int not null,
	[MarginTop] int not null,
	[MarginBottom] int not null,
	[MarginHeader] int not null,
	[MarginFooter] int not null,
	[PaperSize] int not null,
	[PaperWidth] int not null,
	[PaperHeight] int not null,
	[Orientation] int not null,
	[Header] nvarchar(400),
	[Header_Fmt] varbinary(400),
	[Footer] nvarchar(400),
	[Footer_Fmt] varbinary(400),
	[PrintFirstHeader] bit
)
go


/***********************************************************************************************
	Functions for querying property run information found in the fmt columns associated
	with various string datatypes, e.g. string, multi-string, etc.
***********************************************************************************************/

/***********************************************************************************************
 * Function: AlignBinary
 *
 * Description:
 *	Realigns bits - converts from little endian to big endian or vice versa
 *
 * Parameters:
 *	@b=four byte binary string
 *
 * Returns:
 *	realigned four byte binary string
 **********************************************************************************************/
if object_id('AlignBinary') is not null
begin
	drop function AlignBinary
end
go
print 'creating function AlignBinary'
go
create function AlignBinary (@b binary(4))
returns binary(4)
as
begin
	declare @New binary(4)

	set @New = substring(@b, 4, 1) + substring(@b, 3, 1) + substring(@b, 2, 1) + substring(@b, 1, 1)
	return @New
end
go


/***********************************************************************************************
 * Function: GetRunProp
 *
 * Description:
 *	Returns a table of the property runs associated with a format column
 *
 * Parameters:
 *	@fmt=the contents of the format column for which run information should be generated
 *	@txt=the text associated with the format and property runs
 *
 * Returns:
 *	A table that contains the property runs. Each run is represented as a separate row in
 *	the table
 **********************************************************************************************/
if object_id('GetRunProp') is not null begin
	print 'removing function GetRunProp'
	drop function GetRunProp
end
go
print 'creating function GetRunProp'
go
create function GetRunProp (@fmt varbinary(8000), @sTxt nvarchar(4000))
returns @t 
	table (	
		iRun 		int		not null, 
		ichMin 		int		not null, 
		ibProp 		int		not null, 
		ictip 		tinyint		null, 
		scp 		int		null,
		rgbTip 		varbinary(8)	null,
		rgbTipNumBytes	tinyint		null,
		ictsp 		tinyint		null,
		cbTsp		int		null,
		rgbTsp		varbinary(8000)	null,
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		sRunTxt 	NVARCHAR(4000) COLLATE Latin1_General_BIN NOT NULL
	)
as
begin
	declare @nRuns int, @i int, @nFmtLen int, @nPropRegion int
	declare @ichMin int, @ibProp int, @nRunLen int
	declare @ctip tinyint, @iCurrScp tinyint, @scp int, @scpNumBytes tinyint, 
		@rgbTipNumBytes tinyint, @rgbTip bigint
	declare @ctsp tinyint, @iCurrStp tinyint, @cbTsp int, @stpNumBytes tinyint
	declare @NumBytes tinyint, @byteOffset int

	set @nRuns = dbo.AlignBinary(substring(@fmt, 1, 4))
	
	set @i = 0
	set @nFmtLen = len(@fmt)
	set @nPropRegion = 4+@nRuns*8+1

	while @i < @nRuns begin
	
		-- get the character offset into the text region for the current run
		set @ichMin = dbo.AlignBinary(substring(@fmt, 5+@i*8, 4))
		-- get the byte offset into the property region for the current run
		set @ibProp = dbo.AlignBinary(substring(@fmt, 9+@i*8, 4))

		-- get the length of the run
		if @i+1 < @nRuns begin
			set @nRunLen = dbo.AlignBinary(substring(@fmt, 5+(@i+1)*8, 4)) - @ichMin
		end
		else begin
			set @nRunLen = len(@sTxt) - @ichMin
		end

		-- get the number of scalar properties
		set @ctip = convert(tinyint, substring(@fmt, @nPropRegion+@ibProp, 1))
		-- get the number of string properties
		set @ctsp = convert(tinyint, substring(@fmt, @nPropRegion+@ibProp+1, 1))

		-- loop through the scalar properties
		set @iCurrScp = 0
		set @byteOffset = @nPropRegion+@ibProp+2
		while @iCurrScp < @ctip begin

			-- determine how many bytes the scp (scalar property) is stored in
			set @NumBytes = convert(tinyint, substring(@fmt, @byteOffset, 1))
			if (0x00 & @NumBytes = 0x00) or (0x40 & @NumBytes = 0x40) begin -- top bits = 00 or 01
				-- use 1 byte to store 7 significant bits
				set @scpNumBytes = 1
				set @scp = convert(tinyint, @Numbytes) -- @NumBytes contains the first byte 
			end
			else if 0x80 & @NumBytes = 0x80 begin -- top bits = 10 
				-- use 2 bytes to store 14 significant bits
				set @scpNumBytes = 2
				set @scp = convert(smallint, substring(@fmt, @byteOffset+1, 1)+substring(@fmt, @byteOffset, 1)) - 128
			end
			else if 0xc0 & @NumBytes = 0xc0 begin -- top bits = 11
				-- use 5 bytes to store 32 significant bits
				set @scpNumBytes = 5
				set @scp = dbo.AlignBinary(substring(@fmt, @byteOffset, 4)) - 192
			end

			set @byteOffset = @byteOffset + @scpNumBytes

			-- determine how many bytes the rgbTip value is stored in; also subtract the bottom 
			--	2 bits of the first byte of the scp, which are used to specify the rgbTip 
			--	byte length, from the scp value
			set @NumBytes = convert(tinyint, substring(@fmt, @nPropRegion+@ibProp+2, 1))
			if 0x00 & @NumBytes = 0x00 begin
				set @rgbTipNumBytes = 1
			end
			else if 0x01 & @NumBytes = 0x01 begin
				set @rgbTipNumBytes = 2
				set @scp = @scp - 1
			end
			else if 0x02 & @NumBytes = 0x02 begin
				set @rgbTipNumBytes = 4
				set @scp = @scp - 2
			end
			else if 0x03 & @NumBytes = 0x03 begin
				set @rgbTipNumBytes = 8
				set @scp = @scp - 3
			end
			set @rgbTip = substring(@fmt, @byteOffset, @rgbTipNumbytes)

			set @byteOffset = @byteOffset + @rgbTipNumBytes
						
			-- insert the data into the logical table @t
			insert into @t (iRun, ichMin, ibProp, ictip, scp, rgbTip, rgbTipNumBytes, ictsp, cbTsp, rgbTsp, sRunTxt)
				values (@i, @ichMin, @ibProp, @iCurrScp, @scp, @rgbTip,	@rgbTipNumBytes,
					null, null, null, substring(@sTxt, @ichMin+1, @nRunLen)
				)

			set @iCurrScp = @iCurrScp + 1
		end

		-- loop through the string-valued properties
		set @iCurrStp = 0
		while @iCurrStp < @ctsp begin
			
			-- determine how many bytes the stp (string-valued property) is stored in
			set @NumBytes = convert(tinyint, substring(@fmt, @byteOffset, 1))
			if (0x00 & @NumBytes = 0x00) or (0x40 & @NumBytes = 0x40) begin -- top bits = 00 or 01
				-- use 1 byte to store 7 significant bits
				set @stpNumBytes = 1
				set @cbTsp = convert(tinyint, @NumBytes) -- @stpNumBytes contains the first byte 
			end
			else if 0x80 & @NumBytes = 0x80 begin -- top bits = 10 
				-- use 2 bytes to store 14 significant bits
				set @stpNumBytes = 2
				set @cbTsp = convert(smallint, substring(@fmt, @byteOffset+1, 1)+substring(@fmt, @byteOffset, 1)) - 128
			end
			else if 0xc0 & @NumBytes = 0xc0 begin -- top bits = 11
				-- use 5 bytes to store 32 significant bits
				set @stpNumBytes = 4
				set @cbTsp = dbo.AlignBinary(substring(@fmt, @byteOffset, 4)) - 192
			end

			set @byteOffset = @byteOffset + @stpNumBytes

			-- insert the data into the logical table @t
			insert into @t (iRun, ichMin, ibProp, ictip, scp, rgbTip, rgbTipNumBytes, ictsp, cbTsp, rgbTsp, sRunTxt)
				values (@i, @ichMin, @ibProp, null, null, null, null, @iCurrStp, @cbTsp,
					substring(@fmt, @byteOffset, @cbTsp), substring(@sTxt, @ichMin+1, @nRunLen)
				)

			set @byteOffset = @byteOffset + @cbTsp

			set @iCurrStp = @iCurrStp + 1
		end

		-- check to see if there are no scalar or string-valued properties, in which case insert 
		--	the run without any property information
		if @ctsp = 0 and @ctip = 0 begin
			-- insert the data into the logical table @t
			insert into @t (iRun, ichMin, ibProp, ictip, scp, rgbTip, rgbTipNumBytes, ictsp, cbTsp, rgbTsp, sRunTxt)
				values (@i, @ichMin, @ibProp, null, null, null, null, null, null, null,
					substring(@sTxt, @ichMin+1, @nRunLen)
				)
		end

		set @i = @i + 1
	end

	return
end
go


if object_id('IsA') is not null begin
print 'drop function IsA'
	drop function IsA
end
go
print 'creating function IsA'
go
create function IsA
	(@SuperClid int,
	@Clid int)
returns int
as
begin
	return 0
end
go
print 'altering function IsA'
go

-----------------------------------------------------------------------------------------
-- Function: IsA
-- Description: This function checks to see if @SuperClid is a superclass of @Clid.
-- Parameters:	
--    @SuperClid - the class id of the superclass
--    @Clid - the class id of the object
-- Return: 1 if @SuperClid is a superclass of @Clid, otherwise 0.
-----------------------------------------------------------------------------------------
alter function IsA
	(@SuperClid int,
	@Clid int)
returns int
as
begin
	declare @BaseId int, @retVal int

	if (@Clid = 0) return 0	-- CmObject has no superclass.
	if ((@SuperClid < 0) Or (@Clid < 0)) return 0

	set @retVal = 0
	set @BaseId = -1

	-- Check to see if it is the same class.
	if (@SuperClid = @Clid) return 1

	select @BaseId = Base from Class$ where Id=@Clid
	if (@BaseId = -1) return 0	-- Couldn't find @Clid

	if (@BaseId = 0) return 0	-- Have run into CmObject, so quit.

	-- Check to see if superclass is CmObject.
	if (@SuperClid = 0) return 1

	-- Now do it the hard way.
	if (@BaseId = @SuperClid) return 1
	else exec @retVal=dbo.IsA @SuperClid, @BaseId

	return @retVal
end
go


/***********************************************************************************************
 * GetOrderedMultiTxt
 *
 * Returns an ordered list of strings with their encodings. The order follows the encodings
 * in CurrentAnalysisWritingSystems or CurrentVernacularWritingSystems, then any other encodings,
 * then ***.
 *
 * Parameters:
 *   @id - The id of the object owning the string
 *   @flid - The property in which the string is stored
 *   @anal - 1 to use CurrentAnalaysisEncs (default), 0 to use CurrentVernacularWritingSystems
 *
 * Notes:
 *     1) A number of different combinations exist. One of two methods can be used
 *   to deal with them. i) Create dynamic SQL each time the proc is called. ii) Hard
 *   code each combination. The latter was picked. Although more code has to be
 *   compiled, the stored proc is called many times, particularly on start up. This 
 *   means the compilation will be used many times. No noticeable difference was
 *   seen when this modification was implemented.
 *
 *     2) The fallback *** was typically created by doing a union. (See the query for
 *   MulitTxt$, for example.) This proved problematic with ntext columns.
 *     A union causes a "work table" in tempdb. See dbtabcount in Books On Line
 *   for a discussion of work tables. ntext variable types are not permitted in work
 *   tables. A workaround was attempted by using @@ROWCOUNT to see if any
 *   rows were returned by the query. If not, SELECT '***', 0, 99999 was fired. This
 *   works in Query Analyzer, but does not return a row in Debug, nor apparently to
 *   the interface. The use of the table variable was used as a workaround.
***********************************************************************************************/

if exists (select * from sysobjects where name = 'GetOrderedMultiTxt')
	drop proc GetOrderedMultiTxt
go
print 'creating proc GetOrderedMultiTxt'
go

create proc GetOrderedMultiTxt
	@id int,
	@flid int,
 	@anal tinyint = 1
as
	
	declare @fIsNocountOn int
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	declare 
		@iFieldType int,
		@nvcTable NVARCHAR(60),
		@nvcSql NVARCHAR(4000)
	
	select @iFieldType = [Type] from Field$ where [Id] = @flid
	EXEC GetMultiTableName @flid, @nvcTable OUTPUT

	--== Analysis WritingSystems ==--
	
	if @anal = 1
	begin
		
		-- MultiStr$ --
		if @iFieldType = kcptMultiString
			select
				isnull(ms.[txt], '***') txt,
				ms.[ws],
				isnull(lpcae.[ord], 99998) [ord]
			from MultiStr$ ms (readuncommitted)
			left outer join LgWritingSystem le (readuncommitted) on le.[Id] = ms.[ws]
			left outer join LanguageProject_AnalysisWritingSystems lpae (readuncommitted) on lpae.[dst] = le.[id]
			left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae (readuncommitted) on lpcae.[dst] = lpae.[dst]
			where ms.[obj] = @id and ms.[flid] = @flid
			union all
			select '***', 0, 99999
			order by isnull([ord], 99998)
		
		-- MultiBigStr$ --
		else if @iFieldType = kcptMultiBigString
		begin
			--( See note 2 in the header 
			declare @tblMultiBigStrAnalysis table (
				--( See the notes under string tables in FwCore.sql about the 
				--( COLLATE clause.
				Txt NTEXT COLLATE Latin1_General_BIN,
				[ws] int,
				[ord] int primary key)
			
			insert into @tblMultiBigStrAnalysis
			select
				isnull(mbs.[txt], '***') txt,
				mbs.[ws],
				isnull(lpcae.[ord], 99998) [ord]
			from MultiBigStr$ mbs (readuncommitted)
			left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mbs.[ws]
			left outer join LanguageProject_AnalysisWritingSystems lpae (readuncommitted) on lpae.[dst] = le.[id]
			left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae (readuncommitted) on lpcae.[dst] = lpae.[dst]
			where mbs.[obj] = @id and mbs.[flid] = @flid
			order by isnull([ord], 99998)
			
			insert into @tblMultiBigStrAnalysis
			select convert(ntext, '***') [txt], 0 [ws], 99999 [ord]

			select * from @tblMultiBigStrAnalysis order by [ord]
		end
		
		-- MultiBigTxt$ --
		else if @iFieldType = kcptMultiBigUnicode
		begin
			--( See note 2 in the header 
			declare @tblMultiBigTxtAnalysis table (
				--( See the notes under string tables in FwCore.sql about the 
				--( COLLATE clause.
				Txt NTEXT COLLATE Latin1_General_BIN,
				[ws] int,
				[ord] int primary key)
			
			insert into @tblMultiBigTxtAnalysis
			select
				isnull(mbt.[txt], '***') txt,
				mbt.[ws],
				isnull(lpcae.[ord], 99998) [ord]
			from MultiBigTxt$ mbt (readuncommitted)
			left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mbt.[ws]
			left outer join LanguageProject_AnalysisWritingSystems lpae (readuncommitted) on lpae.[dst] = le.[id]
			left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae (readuncommitted) on lpcae.[dst] = lpae.[dst]
			where mbt.[obj] = @id and mbt.[flid] = @flid
			order by isnull([ord], 99998)
			
			insert into @tblMultiBigTxtAnalysis
			select convert(ntext, '***') [txt], 0 [ws], 99999 [ord]

			select * from @tblMultiBigTxtAnalysis order by [ord]
		end
		
		-- MultiTxt$ -- 
		else if @iFieldType = kcptMultiUnicode BEGIN
			SET @nvcSql =
				N'select ' + CHAR(13) +
					N'isnull(mt.[txt], ''***'') txt, ' + CHAR(13) +
					N'mt.[ws], ' + CHAR(13) +
					N'isnull(lpcae.[ord], 99998) [ord] ' + CHAR(13) +
				N'from ' + @nvcTable + N' mt (readuncommitted) ' + CHAR(13) +
				N'left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mt.[ws] ' + CHAR(13) +
				N'left outer join LanguageProject_AnalysisWritingSystems lpae (readuncommitted) ' + 
					N'on lpae.[dst] = le.[id] ' + CHAR(13) +
				N'left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae (readuncommitted) ' +
					N'on lpcae.[dst] = lpae.[dst] ' + CHAR(13) +
				N'where mt.[obj] = @id ' + CHAR(13) +
				N'union all ' + CHAR(13) +
				N'select ''***'', 0, 99999 ' + CHAR(13) +
				N'order by isnull([ord], 99998) '
			
			EXEC sp_executesql @nvcSql, N'@id INT', @id
		END

	end
	
	--== Vernacular WritingSystems ==--
	
	else if @anal = 0
	begin
		
		-- MultiStr$ --
		if @iFieldType = kcptMultiString
			select
				isnull(ms.[txt], '***') txt,
				ms.[ws],
				isnull(lpcve.[ord], 99998) [ord]
			from MultiStr$ ms (readuncommitted)
			left outer join LgWritingSystem le (readuncommitted) on le.[Id] = ms.[ws]
			left outer join LanguageProject_VernacularWritingSystems lpve (readuncommitted) on lpve.[dst] = le.[id]
			left outer join LanguageProject_CurrentVernacularWritingSystems lpcve (readuncommitted) on lpcve.[dst] = lpve.[dst]
			where ms.[obj] = @id and ms.[flid] = @flid
			union all
			select '***', 0, 99999
			order by isnull([ord], 99998)
		
		-- MultiBigStr$ --
		else if @iFieldType = kcptMultiBigString
		begin
			--( See note 2 in the header 
			declare @tblMultiBigStrVernacular table (
				--( See the notes under string tables in FwCore.sql about the 
				--( COLLATE clause.
				Txt NTEXT COLLATE Latin1_General_BIN,
				[ws] int,
				[ord] int primary key)
			
			insert into @tblMultiBigStrVernacular
			select
				isnull(mbs.[txt], '***') txt,
				mbs.[ws],
				isnull(lpcve.[ord], 99998) [ord]
			from MultiBigStr$ mbs (readuncommitted)
			left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mbs.[ws]
			left outer join LanguageProject_VernacularWritingSystems lpve (readuncommitted) on lpve.[dst] = le.[id]
			left outer join LanguageProject_CurrentVernacularWritingSystems lpcve (readuncommitted) on lpcve.[dst] = lpve.[dst]
			where mbs.[obj] = @id and mbs.[flid] = @flid
			order by isnull([ord], 99998)
			
			insert into @tblMultiBigStrVernacular
			select convert(ntext, '***') [txt], 0 [ws], 99999 [ord]

			select * from @tblMultiBigStrVernacular order by [ord]
		end
		
		-- MultiBigTxt$ --
		else if @iFieldType = kcptMultiBigUnicode
		begin
			--( See note 2 in the header 
			declare @tblMultiBigTxtVernacular table (
				--( See the notes under string tables in FwCore.sql about the 
				--( COLLATE clause.
				Txt NTEXT COLLATE Latin1_General_BIN,
				[ws] int,
				[ord] int primary key)
			
			insert into @tblMultiBigTxtVernacular
			select
				isnull(mbt.[txt], '***') txt,
				mbt.[ws],
				isnull(lpcve.[ord], 99998) [ord]
			from MultiBigTxt$ mbt (readuncommitted)
			left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mbt.[ws]
			left outer join LanguageProject_VernacularWritingSystems lpve (readuncommitted) on lpve.[dst] = le.[id]
			left outer join LanguageProject_CurrentVernacularWritingSystems lpcve (readuncommitted) on lpcve.[dst] = lpve.[dst]
			where mbt.[obj] = @id and mbt.[flid] = @flid
			order by isnull([ord], 99998)
			
			insert into @tblMultiBigTxtVernacular
			select convert(ntext, '***') [txt], 0 [ws], 99999 [ord]

			select * from @tblMultiBigTxtVernacular order by [ord]
		end
		
		-- MultiTxt$ --
		else if @iFieldType = kcptMultiUnicode BEGIN
			SET @nvcSql =
				N' select ' + CHAR(13) +
					N'isnull(mt.[txt], ''***'') txt, ' + CHAR(13) +
					N'mt.[ws], ' + CHAR(13) +
					N'isnull(lpcve.[ord], 99998) ord ' + CHAR(13) +
				N'from ' + @nvcTable + N' mt (readuncommitted) ' + CHAR(13) +
				N'left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mt.[ws] ' + CHAR(13) +
				N'left outer join LanguageProject_VernacularWritingSystems lpve (readuncommitted) ' + 
					N'on lpve.[dst] = le.[id] ' + CHAR(13) +
				N'left outer join LanguageProject_CurrentVernacularWritingSystems lpcve (readuncommitted) ' + 
					N'on lpcve.[dst] = lpve.[dst] ' + CHAR(13) +
				N'where mt.[obj] = @id ' + CHAR(13) +
				N'union all ' + CHAR(13) +
				N'select ''***'', 0, 99999 ' + CHAR(13) +
				N'order by isnull([ord], 99998) ' 
			
			EXEC sp_executesql @nvcSql, N'@id INT', @id
		END
	end
	else
		raiserror('@anal flag not set correctly', 16, 1) 
		goto LFail

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	go


/***********************************************************************************************
 * GetOrderedMultiTxtXml$
 *
 * Description:
 *   Returns an ordered list of strings. The order follows the encodings in CurrentAnalysisWritingSystems
 *   or CurrentVernacularWritingSystems, then any other encodings, then ***. It returns the HVO, string,
 *   writing system, and order.
 *
 * Parameters:
 *   @hXMLDocObjList - handle to a parsed XML document that contains object Ids of the string owners
 *   @iFlid - The property in which the string is stored
 *   @tiAnal - 1 to use CurrentAnalaysisEncs (default), 0 to use CurrentVernacularWritingSystems
 *
 * 
 * Notes:
 *   If you are interested in only one Object ID, use GetOrderedMultiTxt.
 *
 * Example:
 *	-- this is an example of how to get names of three objects (one spurious)
 *  -- with a call to GetOrderedMultiTxtXml$, 
 *
 *  declare @iXmlDoc int
 *	exec sp_xml_preparedocument @iXmlDoc output, 
 *		'<root><Obj Id="13"/><Obj Id="185"/><Obj Id="10"/></root>'
 *	exec GetOrderedMultiTxtXml$ @iXmlDoc, 5001, 1
 *	exec sp_xml_removedocument @iXmlDoc
 * 
 * ENHANCE: SteveMi(KenZ) May want to
 * generalize to handle MultiBigTxt$, MultiStr$, and MultiBigStr$
 *
***********************************************************************************************/
if object_id('GetOrderedMultiTxtXml$') is not null begin
	print 'removing procedure GetOrderedMultiTxtXml$'
	drop proc [GetOrderedMultiTxtXml$]
end
go
print 'creating proc GetOrderedMultiTxtXml$'
go

create proc GetOrderedMultiTxtXml$
	@hXMLDocObjList int = null,
	@iFlid int,
 	@tiAnal tinyint = 1
as
	
	declare @fIsNocountOn int
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	DECLARE
		@nvcTable NVARCHAR(60),
		@nvcSql NVARCHAR(4000)
	
	EXEC GetMultiTableName @iflid, @nvcTable OUTPUT
	
	if @tiAnal = 1 BEGIN
		
		SET @nvcSql = N'select ' + CHAR(13) +
			N'ids.[Id], ' + CHAR(13) +
			N'isnull((select top 1 isnull(mt.[txt], ''***'') ' + CHAR(13) +
 				N'from ' + @nvcTable + N' mt (readuncommitted) ' + CHAR(13) +
 				N'left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mt.[ws] ' + CHAR(13) +
 				N'left outer join LanguageProject_AnalysisWritingSystems lpae (readuncommitted) ' +
					N'on lpae.[dst] = le.[id] ' + CHAR(13) +
 				N'left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae (readuncommitted) ' + 
					N'on lpcae.[dst] = lpae.[dst] ' + CHAR(13) +
				N'where mt.[obj] = ids.[Id] ' + CHAR(13) +
 				N'order by isnull(lpcae.[ord], 99999)), ''***'') as [txt] , ' + CHAR(13) +
			N'isnull((select top 1 isnull(mt.[ws], 0) ' + CHAR(13) +
 				N'from ' + @nvcTable + N' mt (readuncommitted) ' + CHAR(13) +
 				N'left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mt.[ws] ' + CHAR(13) +
 				N'left outer join LanguageProject_AnalysisWritingSystems lpae (readuncommitted) ' + 
					N' on lpae.[dst] = le.[id] ' + CHAR(13) +
 				N'left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae (readuncommitted) ' + 
					N'on lpcae.[dst] = lpae.[dst] ' + CHAR(13) +
				N'where mt.[obj] = ids.[Id] ' + CHAR(13) +
 				N'order by isnull(lpcae.[ord], 99999)), 0) as [ws] ' + CHAR(13) +
			N'from openxml (@hXMLDocObjList, ''/root/Obj'') with ([Id] int) ids '
			
		EXEC sp_executesql @nvcSql, N'@hXMLDocObjList INT', @hXMLDocObjList
	END
	else if @tiAnal = 0 BEGIN
		
		SET @nvcSql = N'select ' + CHAR(13) +
			N'ids.[Id], ' + CHAR(13) +
			N'isnull((select top 1 isnull(mt.[txt], ''***'') as [txt] ' + CHAR(13) +
 				N'from ' + @nvcTable + N' mt (readuncommitted) ' + CHAR(13) +
 				N'left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mt.[ws] ' + CHAR(13) +
 				N'left outer join LanguageProject_VernacularWritingSystems lpve (readuncommitted) ' +
					N'on lpve.[dst] = le.[id] ' + CHAR(13) +
 				N'left outer join LanguageProject_CurrentVernacularWritingSystems lpcve (readuncommitted) ' + 
					N'on lpcve.[dst] = lpve.[dst] ' + CHAR(13) +
				N'where mt.[obj] = ids.[Id] ' + CHAR(13) +
 				N'order by isnull(lpcve.[ord], 99999)), ''***'') , ' + CHAR(13) +
			N'isnull((select top 1 isnull(mt.[ws], 0) as [ws] ' + CHAR(13) +
 				N'from ' + @nvcTable + N' mt (readuncommitted) ' + CHAR(13) +
 				N'left outer join LgWritingSystem le (readuncommitted) on le.[Id] = mt.[ws] ' + CHAR(13) +
 				N'left outer join LanguageProject_VernacularWritingSystems lpve (readuncommitted) ' +
					N'on lpve.[dst] = le.[id] ' + CHAR(13) +
 				N'left outer join LanguageProject_CurrentVernacularWritingSystems lpcve (readuncommitted) ' + 
					N'on lpcve.[dst] = lpve.[dst] ' + CHAR(13) +
				N'where mt.[obj] = ids.[Id] ' + CHAR(13) +
 				N'order by isnull(lpcve.[ord], 99999)), 0) ' + CHAR(13) +
			N'from openxml (@hXMLDocObjList, ''/root/Obj'') with ([Id] int) ids '
		
		EXEC sp_executesql @nvcSql, N'@hXMLDocObjList INT', @hXMLDocObjList
	END
	else begin
		raiserror('@tiAnal flag not set correctly', 16, 1) 
		goto LFail
	end
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

go

/***********************************************************************************************
	Various and sundry other triggers
***********************************************************************************************/

/***********************************************************************************************
 *	Trigger: TR_CmSortSpec_Ins
 *
 *	Description:
 *		Gets the primary, secondary, and tertiary sort fields out of a CmSortSpec record
 *		and creates records for them in FlidCollations$
 *
 *	Notes:
 *		When a custom sort is specified through the UI, a CmSortSpec is first created. This
 *		means that this trigger will be fired for insert with nulls, and have no affect. The
 *		UI then does an update on the CmSortSpec, and that's when all the data getes put into
 *		the CmSortSpec record.
 **********************************************************************************************/

IF OBJECT_ID('TR_CmSortSpec_Ins') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_CmSortSpec_Ins'
	DROP TRIGGER [TR_CmSortSpec_Ins]
END
GO
PRINT 'creating trigger TR_CmSortSpec_Ins'
GO
CREATE TRIGGER [TR_CmSortSpec_Ins] ON CmSortSpec FOR INSERT
AS
	
	DECLARE
		@nvcPrimary NVARCHAR(4000),
		@nvcSecondary NVARCHAR(4000),
		@nvcTertiary NVARCHAR(4000),
		@nID INT
	
	DECLARE curCmSortSpecIns CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
		SELECT [PrimaryField], [SecondaryField], [TertiaryField] FROM Inserted
	
	OPEN curCmSortSpecIns
	FETCH curCmSortSpecIns INTO @nvcPrimary, @nvcSecondary, @nvcTertiary
	WHILE @@FETCH_STATUS = 0 BEGIN
		
		SET @nID = dbo.fnGetLastCommaDelimID$(@nvcPrimary)
		EXEC CreateFlidCollations NULL, NULL, @nID
		
		SET @nID = dbo.fnGetLastCommaDelimID$(@nvcSecondary)
		EXEC CreateFlidCollations NULL, NULL, @nID
		
		SET @nID = dbo.fnGetLastCommaDelimID$(@nvcTertiary)
		EXEC CreateFlidCollations NULL, NULL, @nID		
		
		FETCH curCmSortSpecIns INTO @nvcPrimary, @nvcSecondary, @nvcTertiary
	END
	CLOSE curCmSortSpecIns
	DEALLOCATE curCmSortSpecIns
	
GO

/***********************************************************************************************
 *	Trigger: TR_CmSortSpec_Del
 *
 *	Description:
 *		Gets the primary, secondary, and tertiary sort fields out of a CmSortSpec record
 *		and deletes their records win FlidCollations$
 *
 *	Notes:
 *		When a custom sort is specified through the UI, a CmSortSpec is first created. This
 *		means that this trigger will be fired for insert with nulls, and have no affect. The
 *		UI then does an update on the CmSortSpec, and that's when all the data getes put into
 *		the CmSortSpec record.
 **********************************************************************************************/

IF OBJECT_ID('TR_CmSortSpec_Del') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_CmSortSpec_Del'
	DROP TRIGGER [TR_CmSortSpec_Del]
END
GO
PRINT 'creating trigger TR_CmSortSpec_Del'
GO
CREATE TRIGGER [TR_CmSortSpec_Del] ON CmSortSpec FOR DELETE
AS
	
	DECLARE
		@nvcPrimary NVARCHAR(4000),
		@nvcSecondary NVARCHAR(4000),
		@nvcTertiary NVARCHAR(4000),
		@nID INT,
		@nFlid INT
	
	DECLARE curCmSortSpecDel CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
		SELECT [PrimaryField], [SecondaryField], [TertiaryField] FROM Deleted
	
	OPEN curCmSortSpecDel
	FETCH curCmSortSpecDel INTO @nvcPrimary, @nvcSecondary, @nvcTertiary
	WHILE @@FETCH_STATUS = 0 BEGIN
		
		-- this needs to work
		SELECT TOP 1 [PrimaryWs] FROM [CmSortSpec] WHERE [PrimaryWs] = @nFlid
		UNION
		SELECT TOP 1 [SecondaryWs] FROM [CmSortSpec] WHERE [SecondaryWs] = @nFlid
		UNION
		SELECT TOP 1 [TertiaryWs] FROM [CmSortSpec] WHERE [TertiaryWs] = @nFlid
		
		IF @@ROWCOUNT = 0
		SET @nID = dbo.fnGetLastCommaDelimID$(@nvcPrimary)
		EXEC DeleteFlidCollations NULL, NULL, @nID
		
		FETCH curCmSortSpecIns INTO @nvcPrimary, @nvcSecondary, @nvcTertiary
	END
	CLOSE curCmSortSpecDel
	DEALLOCATE curCmSortSpecDel
	
GO

/***********************************************************************************************
 *	Trigger: TR_CmSortSpec_Upd
 *
 *	Description:
 *		Gets the primary, secondary, and tertiary sort fields out of a CmSortSpec record.
 *
 *	Notes:
 *		When a custom sort is specified through the UI, a CmSortSpec is first created. This
 *		means that this trigger will be fired for insert with nulls, and have no affect. The
 *		UI then does an update on the CmSortSpec, and that's when all the data getes put into
 *		the CmSortSpec record.
 **********************************************************************************************/

IF OBJECT_ID('TR_CmSortSpec_Upd') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_CmSortSpec_Upd'
	DROP TRIGGER [TR_CmSortSpec_Upd]
END
GO
PRINT 'creating trigger TR_CmSortSpec_Upd'
GO
CREATE TRIGGER [TR_CmSortSpec_Upd] ON CmSortSpec FOR INSERT
AS
	
	DECLARE
		@nvcPrimaryIns NVARCHAR(4000),
		@nvcSecondaryIns NVARCHAR(4000),
		@nvcTertiaryIns NVARCHAR(4000),
		@nvcPrimaryDel NVARCHAR(4000),
		@nvcSecondaryDel NVARCHAR(4000),
		@nvcTertiaryDel NVARCHAR(4000),
		@nID INT
	
	DECLARE curCmSortSpecIns CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
		SELECT
			ins.[PrimaryField] AS [PrimaryIns], 
			ins.[SecondaryField] AS [SecondaryIns],
			ins.[TertiaryField] AS [TertiaryIns],
			del.[PrimaryField] AS [PrimaryDel], 
			del.[SecondaryField] AS [SecondaryDel],
			del.[TertiaryField] AS [TertiaryDel]
		FROM Inserted ins
		JOIN Deleted del ON del.[ID] = ins.[Id]
	
	OPEN curCmSortSpecIns
	FETCH curCmSortSpecIns INTO
		@nvcPrimaryIns,
		@nvcSecondaryIns,
		@nvcTertiaryIns,
		@nvcPrimaryDel,
		@nvcSecondaryDel,
		@nvcTertiaryDel
	WHILE @@FETCH_STATUS = 0 BEGIN
		
		IF @nvcPrimaryIns IS NOT NULL AND @nvcPrimaryDel IS NULL BEGIN
			-- insert new
			SET @nId = NULL  --dummy line to make the compiler happy
		END
		ELSE IF @nvcPrimaryIns IS NULL AND @nvcPrimaryDel IS NOT NULL BEGIN
			-- delete old one
			SET @nId = NULL  --dummy line to make the compiler happy
		END
		ELSE IF @nvcPrimaryIns <> @nvcPrimaryDel BEGIN
			SET @nID = dbo.fnGetLastCommaDelimID$(@nvcPrimaryIns)
			EXEC CreateFlidCollations NULL, NULL, @nID
		END
		---
			SET @nID = dbo.fnGetLastCommaDelimID$(@nvcSecondaryIns)
			EXEC CreateFlidCollations NULL, NULL, @nID
	
			SET @nID = dbo.fnGetLastCommaDelimID$(@nvcTertiaryIns)
			EXEC CreateFlidCollations NULL, NULL, @nID		
		
		FETCH curCmSortSpecIns INTO @nvcPrimaryIns, @nvcSecondaryIns, @nvcTertiaryIns
	END
	CLOSE curCmSortSpecIns
	DEALLOCATE curCmSortSpecIns
	
GO

/***********************************************************************************************
 * Trigger: TR_StTxtPara_Owner_Ins
 *
 * Description:
 *	Update UpdDttm on the CmObject record of the owning StText record. Also update the owner
 *  of the owning StText record:
 *
 *		x --> StText --> StTxtPara
 *
 *  Update UpdDttm of x and StText.
 *
 * Type: 	Inserrt
 * Table:	StTxtPara
 **********************************************************************************************/

IF object_id('TR_StTxtPara_Owner_Ins') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StTxtPara_Owner_Ins'
	DROP TRIGGER [TR_StTxtPara_Owner_Ins]
END
GO
PRINT 'creating trigger TR_StTxtPara_Owner_Ins'
GO

CREATE TRIGGER [TR_StTxtPara_Owner_Ins] on [StTxtPara] FOR INSERT
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	UPDATE grandowner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
		JOIN [CmObject] AS grandowner ON grandowner.[Id] = owner.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StTxtPara_Owner_Ins: SQL Error %d; Unable to insert rows into the StTxtPara.', 16, 1, @iErr)
	RETURN
GO

/***********************************************************************************************
 * Trigger: TR_StTxtPara_Owner_UpdDel
 *
 * Description:
 *	Update UpdDttm on the CmObject record of the owning StText record. Also update the owner
 *  of the owning StText record:
 *
 *		x --> StText --> StTxtPara
 *
 *  Update UpdDttm of x and StText.
 *
 * Type: 	Update, Delete
 * Table:	StTxtPara
 **********************************************************************************************/

IF object_id('TR_StTxtPara_Owner_UpdDel') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StTxtPara_Owner_UpdDel'
	DROP TRIGGER [TR_StTxtPara_Owner_UpdDel]
END
GO
PRINT 'creating trigger TR_StTxtPara_Owner_UpdDel'
GO

CREATE TRIGGER [TR_StTxtPara_Owner_UpdDel] on [StTxtPara] FOR UPDATE, DELETE
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	UPDATE grandowner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
		JOIN [CmObject] AS grandowner ON grandowner.[Id] = owner.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StTxtPara_Owner_UpdDel: SQL Error %d; Unable to insert rows into the StTxtPara.', 16, 1, @iErr)
	RETURN
GO

/***********************************************************************************************
 * Trigger: TR_StPara_Owner_Ins
 *
 * Description:
 *	Update UpdDttm on the CmObject record of the owning StText record. Also update the owner
 *  of the owning StText record:
 *
 *		x --> StText --> StPara
 *
 *  Update UpdDttm of x and StText.
 *
 * Type: 	Insert
 * Table:	StPara
 **********************************************************************************************/

IF object_id('TR_StPara_Owner_Ins') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StPara_Owner_Ins'
	DROP TRIGGER [TR_StPara_Owner_Ins]
END
GO
PRINT 'creating trigger TR_StPara_Owner_Ins'
GO

CREATE TRIGGER [TR_StPara_Owner_Ins] on [StPara] FOR INSERT
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	UPDATE grandowner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
		JOIN [CmObject] AS grandowner ON grandowner.[Id] = owner.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StPara_Owner_Ins: SQL Error %d; Unable to insert rows into the StPara.', 16, 1, @iErr)
	RETURN

/***********************************************************************************************
 * Trigger: TR_StPara_Owner_UpdDel
 *
 * Description:
 *	Update UpdDttm on the CmObject record of the owning StText record. Also update the owner
 *  of the owning StText record:
 *
 *		x --> StText
 *
 *  Update UpdDttm of x.
 *
 * Type: 	Update, Delete
 * Table:	StPara
 **********************************************************************************************/

IF object_id('TR_StPara_Owner_UpdDel') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StPara_Owner_UpdDel'
	DROP TRIGGER [TR_StPara_Owner_UpdDel]
END
GO
PRINT 'creating trigger TR_StPara_Owner_UpdDel'
GO

CREATE TRIGGER [TR_StPara_Owner_UpdDel] on [StPara] FOR UPDATE, DELETE
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	UPDATE grandowner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
		JOIN [CmObject] AS grandowner ON grandowner.[Id] = owner.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StPara_Owner_UpdDel: SQL Error %d; Unable to insert rows into the StPara.', 16, 1, @iErr)
	RETURN
	
/***********************************************************************************************
 * Trigger: TR_StText_Owner_Ins
 *
 * Description:
 *	Update UpdDttm on the CmObject record of the owner of the StText record.
 *
 * Type: 	Insert
 * Table:	StText
 **********************************************************************************************/

IF object_id('TR_StText_Owner_Ins') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StText_Owner_Ins'
	DROP TRIGGER [TR_StText_Owner_Ins]
END
GO
PRINT 'creating trigger TR_StText_Owner_Ins'
GO

CREATE TRIGGER [TR_StText_Owner_Ins] on [StText] FOR INSERT
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StText_Owner_Ins: SQL Error %d; Unable to insert rows into the StText.', 16, 1, @iErr)
	RETURN

/***********************************************************************************************
 * Trigger: TR_StText_Owner_UpdDel
 *
 * Description:
 *	Update UpdDttm on the CmObject record of the owner of the StText record.
 *
 * Type: 	Update, Delete
 * Table:	StText
 **********************************************************************************************/

IF object_id('TR_StText_Owner_UpdDel') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StText_Owner_UpdDel'
	DROP TRIGGER [TR_StText_Owner_UpdDel]
END
GO
PRINT 'creating trigger TR_StText_Owner_UpdDel'
GO

CREATE TRIGGER [TR_StText_Owner_UpdDel] on [StText] FOR UPDATE, DELETE
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StText_Owner_UpdDel: SQL Error %d; Unable to insert rows into the StText.', 16, 1, @iErr)
	RETURN


/***********************************************************************************************
 * Procedure: NoteInterlinProcessTime
 * Note: this needs to be in LangProjSP.sql since it depends on language project
 *
 * Description: 
 *	For each paragraph in a specified StText, ensures that there is a CmBaseAnnotation
 *	of type Process Time (actually the type is passed as an argument) whose BeginObject
 *	is the paragraph, and sets its CompDetails to a representation of the UpdStmp of the
 * 	paragraph.
 *
 * Parameters: 
 *	@atid int=id of the attribute defin for process type (app typically has it cached)
 * 	@stid int=id of the StText whose paragraphs are to be marked. 
 *
 * Returns:
 *  the object ids of any created CmBaseAnnotation objects
 **********************************************************************************************/
if object_id('NoteInterlinProcessTime') is not null begin
	print 'removing proc NoteInterlinProcessTime'
	drop proc [NoteInterlinProcessTime]
end
go
print 'creating proc NoteInterlinProcessTime'
go

create proc NoteInterlinProcessTime
	@atid INT, @stid INT,
	@nvNew nvarchar(4000) output
AS BEGIN

	declare @lpid int
	select top 1 @lpid = id from LanguageProject

	set @nvNew = ''

	declare MakeAnnCursor cursor local static forward_only read_only for
	select tp.id from StTxtPara_ tp (readuncommitted)
	left outer join CmBaseAnnotation_ cb (readuncommitted)
					on cb.BeginObject = tp.id and cb.AnnotationType = @atid
	where tp.owner$ = @stid and cb.id is null

	declare @tpid int,
		@NewObjGuid uniqueidentifier,
		@cbaId int
	open MakeAnnCursor
		fetch MakeAnnCursor into @tpid
		while @@fetch_status = 0 begin
			exec CreateOwnedObject$ 37, @cbaId out, @NewObjGuid out, @lpid, kflidLanguageProject_Annotations, kcptOwningCollection
			set @nvNew = @nvNew + ',' + cast(@cbaId as nvarchar(8))
			update CmBaseAnnotation set BeginObject = @tpid where id = @cbaId
			update CmAnnotation set AnnotationType = @atid where id = @cbaId
			set @cbaId = null
			set @NewObjGuid = null
			fetch MakeAnnCursor into @tpid
		end
	close MakeAnnCursor
	deallocate MakeAnnCursor

	update CmBaseAnnotation_
	set CompDetails = cast(cast(tp.UpdStmp as bigint) as NVARCHAR(20))
	from CmBaseAnnotation_ cba (readuncommitted)
	join StTxtPara_ tp (readuncommitted) on cba.BeginObject = tp.id and tp.owner$ = @stid
	where cba.AnnotationType = @atid

	return @@ERROR
END
GO
