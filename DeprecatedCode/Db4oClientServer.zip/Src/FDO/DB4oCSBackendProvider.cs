// --------------------------------------------------------------------------------------------
// Copyright (C) 2008 SIL International. All rights reserved.
// 
// Distributable under the terms of either the Common Public License or the
// GNU Lesser General Public License, as specified in the LICENSING.txt file.
// 
// File: DB4oBackendProvider.cs
// Responsibility: Randy Regnier
// Last reviewed: never
// --------------------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.IO;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Config.Encoding;
using Db4objects.Db4o.Internal;
using SIL.FieldWorks.FDO.DomainServices.DataMigration;

namespace SIL.FieldWorks.FDO.Infrastructure.Impl
{
	/// <summary>
	/// A subclass of the FDOBackendProvider
	/// which handles a DB4o database.
	/// </summary>
	internal sealed class DB4oCSBackendProvider : FDOBackendProvider
	{
		private IObjectServer m_server;
		private IObjectContainer m_db;
		private IConfiguration m_configuration;
		private readonly Dictionary<string, CustomFieldInfo> m_myKnownCustomFields = new Dictionary<string, CustomFieldInfo>();
		private string m_dbPathname;
		private ModelVersionNumberCs m_modelVersionNumber;

		/// <summary>
		/// Constructor.
		/// </summary>
		internal DB4oCSBackendProvider(FdoCache cache, IdentityMap identityMap, ICmObjectSurrogateFactory surrogateFactory, IFwMetaDataCacheManagedInternal mdc, IDataMigrationManager dataMigrationManager)
			: base(cache, identityMap, surrogateFactory, mdc, dataMigrationManager)
		{
			m_configuration = InitializeConfiguration();
            // Db4o requires the original surrogates in order to make Commit work properly.
		    identityMap.RetainSurrogates = true;
		}

		private IConfiguration InitializeConfiguration()
		{
			var configuration = new Config4Impl();
			//var configuration = Db4oFactory.Configure();
			//var csConfiguration = m_configuration.ClientServer();
			configuration.RegisterTypeHandler(
				new CmObjectSurrogateTypeHandlerPredicateCs(),
				new CmObjectSurrogateTypeHandlerCs(m_cache, m_identityMap));
			configuration.RegisterTypeHandler(
				new CustomFieldInfoTypeHandlerPredicateCs(),
				new CustomFieldInfoTypeHandlerCs());
			configuration.RegisterTypeHandler(
				new ModelVersionNumberTypeHandlerPredicateCs(),
				new ModelVersionNumberTypeHandlerCs());
			configuration.Callbacks(false);
			configuration.WeakReferences(false);
			configuration.CallConstructors(false);

			// New options.
			configuration.ActivationDepth(2);
			configuration.UpdateDepth(2);
			configuration.DetectSchemaChanges(false);
			configuration.TestConstructors(false);
			configuration.StringEncoding(StringEncodings.Utf8());

			var type = typeof (CmObjectSurrogate);
			//configuration.ObjectClass(type).Indexed(true);
			configuration.ObjectClass(type).CascadeOnDelete(true);
			configuration.ObjectClass(type).UpdateDepth(2);
			configuration.ObjectClass(type).MinimumActivationDepth(2);
			configuration.ObjectClass(type).MaximumActivationDepth(2);

			type = typeof(CustomFieldInfo);
			//configuration.ObjectClass(type).Indexed(true);
			configuration.ObjectClass(type).CascadeOnDelete(true);
			configuration.ObjectClass(type).UpdateDepth(2);
			configuration.ObjectClass(type).MinimumActivationDepth(2);
			configuration.ObjectClass(type).MaximumActivationDepth(2);

			type = typeof(ModelVersionNumberCs);
			//configuration.ObjectClass(type).Indexed(true);
			configuration.ObjectClass(type).CascadeOnDelete(true);
			configuration.ObjectClass(type).UpdateDepth(2);
			configuration.ObjectClass(type).MinimumActivationDepth(2);
			configuration.ObjectClass(type).MaximumActivationDepth(2);

			configuration.BTreeNodeSize(50);
			//m_csConfiguration.Cache.SlotCacheSize = 
			//m_csConfiguration.File.Storage

			return configuration;
		}

		#region IFWDisposable implementation

		/// <summary>
		/// Executes in two distinct scenarios.
		/// 
		/// 1. If disposing is true, the method has been called directly
		/// or indirectly by a user's code via the Dispose method.
		/// Both managed and unmanaged resources can be disposed.
		/// 
		/// 2. If disposing is false, the method has been called by the 
		/// runtime from inside the finalizer and you should not reference (access) 
		/// other managed objects, as they already have been garbage collected.
		/// Only unmanaged resources can be disposed.
		/// </summary>
		/// <param name="disposing"></param>
		/// <remarks>
		/// If any exceptions are thrown, that is fine.
		/// If the method is being done in a finalizer, it will be ignored.
		/// If it is thrown by client code calling Dispose,
		/// it needs to be handled by fixing the bug.
		/// 
		/// If subclasses override this method, they should call the base implementation.
		/// </remarks>
		protected override void Dispose(bool disposing)
		{
			// Can be called more than once,
			// but only do things the first time.
			if (IsDisposed)
				return;

			if (disposing)
			{
				if (m_db != null)
					m_db.Dispose(); // Calls 'Close'.
				if (m_server != null)
					m_server.Close();
			}

			// Dispose unmanaged resources here, whether disposing is true or false.

			// Null all data members.
			m_db = null;
			m_server = null;
			m_configuration = null;

			base.Dispose(disposing);
		}

		#endregion IFWDisposable implementation

		/// <summary>
		/// This flag is needed for renaming the database files, and then reconnecting to the
		/// database.  We don't need/want to reload the data in that case!
		/// </summary>
		bool m_fRestarting;

		/// <summary>
		/// Start the BEP.
		/// </summary>
		/// <param name="currentModelVersion"></param>
		/// <param name="backendProviderOptions"></param>
		/// <returns></returns>
		internal override int StartupInternal(int currentModelVersion, object[] backendProviderOptions)
		{
			int currentDataStoreVersion;
			BasicInit(backendProviderOptions);

			if (!File.Exists(m_dbPathname))
				throw new InvalidOperationException("File does not exist");

			try
			{
				m_server = Db4oFactory.OpenServer(m_configuration, m_dbPathname, 0);
				m_server.GrantAccess("me", "neverguessit");
				m_db = m_server.OpenClient();

				// Load model version number, and check against current number.
				m_modelVersionNumber = (ModelVersionNumberCs) m_db.QueryByExample(typeof (ModelVersionNumberCs))[0];
				currentDataStoreVersion = m_modelVersionNumber.m_modelVersionNumber;
				var needConversion = (currentDataStoreVersion != currentModelVersion);

				if (m_fRestarting)
				{
					System.Diagnostics.Debug.Assert(currentDataStoreVersion == currentModelVersion);
					m_fRestarting = false;		// need to set explicitly before each call.
					return currentDataStoreVersion;
				}
				// Load optional custom fields.
				var customFields = new List<CustomFieldInfo>();
				foreach (CustomFieldInfo customField in m_db.QueryByExample(typeof(CustomFieldInfo)))
				{
					customFields.Add(customField);
					m_myKnownCustomFields.Add(customField.Key, customField);
				}
				RegisterOriginalCustomProperties(customFields);

				// Load surrogates.
				foreach (CmObjectSurrogate surrogate in m_db.QueryByExample(typeof(CmObjectSurrogate)))
				{
					if (needConversion)
						RegisterSurrogateForConversion(surrogate);
					else
						RegisterInactiveSurrogate(surrogate);
				}
			}
			catch (Exception err)
			{
				throw err;
			}
			return currentDataStoreVersion;
		}

		internal override void RemoveBackEnd()
		{
			throw new NotImplementedException();
		}

		private void BasicInit(object[] backendProviderOptions)
		{
			m_dbPathname = backendProviderOptions[0] as string;
			DatabaseName = Path.GetFileName(m_dbPathname);
		}

		/// <summary>
		/// Restore from a data migration, which used an XML BEP.
		/// </summary>
		/// <param name="xmlBepPathname"></param>
		internal override void RestoreWithoutMigration(string xmlBepPathname)
		{
			// Close down connection.
			m_db.Close();
			// Copy original file.
			File.Copy(m_dbPathname, Path.Combine(m_dbPathname, ".bak"));
			// 'port' without migration to new DB4o, but reusing the old filename name.
			PortLanguageProject(new[] { m_dbPathname }, new BackendStartupParameter(FDOBackendProviderType.kXML, BackendBulkLoadDomain.None, new[] { xmlBepPathname }));
		}

		/// <summary>
		/// Create a LangProject with the BEP.
		/// </summary>
		/// <param name="backendProviderOptions"></param>
		internal override void CreateInternal(object[] backendProviderOptions)
		{
			BasicInit(backendProviderOptions);

			if (File.Exists(m_dbPathname))
				throw new InvalidOperationException("File already exists");

			try
			{
				// Create a brand new DB.
				m_server = Db4oFactory.OpenServer(m_configuration, m_dbPathname, 0);
				m_server.GrantAccess("me", "neverguessit");
				m_db = m_server.OpenClient();
				// Store model version number;
				m_modelVersionNumber = new ModelVersionNumberCs { m_modelVersionNumber = m_modelVersionOverride };
				m_db.Store(m_modelVersionNumber);
				m_db.Commit();
			}
			catch (Exception err)
			{
				throw err;
			}
		}

		#region IDataStorer implementation

		/// <summary>
		/// Update the backend store.
		/// </summary>
		/// <param name="newbies">The newly created objects</param>
		/// <param name="dirtballs">The recently modified objects</param>
		/// <param name="goners">The recently deleted objects</param>
        public override bool Commit(HashSet<ICmObjectOrSurrogate> newbies, HashSet<ICmObjectOrSurrogate> dirtballs, HashSet<ICmObjectId> goners)
		{
			try
			{
				IEnumerable<CustomFieldInfo> cfiList;
				if (!HaveAnythingToCommit(newbies, dirtballs, goners, out cfiList)) return true;

				m_db.Ext().Purge();
				foreach (var customFieldInfo in cfiList)
				{
					if (m_myKnownCustomFields.ContainsKey(customFieldInfo.Key)) continue;

					m_db.Store(customFieldInfo);
					m_myKnownCustomFields.Add(customFieldInfo.Key, customFieldInfo);
				}

                // Enhance JohnT: possibly this could be sped up by taking advantage of the case where
                // newby is already a CmObjectSurrogate. This is probably only the case where we are
                // doing data migration or switching backends, however.
				foreach (var newby in newbies)
					m_db.Store(m_identityMap.GetSurrogate(newby.Id) as CmObjectSurrogate);

				foreach (var dirtball in dirtballs)
					m_db.Store(m_identityMap.GetSurrogate(dirtball.Id) as CmObjectSurrogate);

				foreach (var goner in goners)
					m_db.Delete(m_identityMap.GetSurrogate(goner) as CmObjectSurrogate);

				m_db.Commit();
			}
			catch (Exception err)
			{
				m_db.Rollback();
				throw err;
			}

			return base.Commit(newbies, dirtballs, goners);
		}

		/// <summary>
		/// Update the version number.
		/// </summary>
		internal override void UpdateVersionNumber()
		{
			m_modelVersionNumber.m_modelVersionNumber = ModelVersion;
			m_db.Store(m_modelVersionNumber);
			m_db.Commit();
		}

		#endregion IDataStorer implementation

		/// <summary>
		/// Rename the database, which means renaming the files.
		/// </summary>
		public override bool RenameDatabase(string sNewBasename)
		{
			return RenameMyFiles(sNewBasename);
		}

		/// <summary>
		/// THIS NEEDS TO BE CHECKED OVER CAREFULLY TO DETERMINE WHETHER IT ACTUALLY WORKS!
		/// </summary>
		/// <param name="sNewBasename"></param>
		/// <returns>true if the rename succeeds, false if it fails</returns>
		private bool RenameMyFiles(string sNewBasename)
		{
			string sNewPath = Path.ChangeExtension(
				Path.Combine(Path.GetDirectoryName(m_dbPathname), sNewBasename),
				Path.GetExtension(m_dbPathname));
			if (File.Exists(sNewPath))
				return false;

			if (m_db != null)
				m_db.Dispose(); // Calls 'Close'.
			if (m_server != null)
				m_server.Close();
			m_server = null;
			m_db = null;

			bool retval = true;
			try
			{
				File.Move(m_dbPathname, sNewPath);
				m_dbPathname = sNewPath;
			}
			catch
			{
				retval = false;
			}
			// Re-establish the connection to the (probably renamed) files.
			m_fRestarting = true;
			InitializeConfiguration();
			StartupInternal(ModelVersion, new object[] { m_dbPathname });

			return retval;
		}
	}
}