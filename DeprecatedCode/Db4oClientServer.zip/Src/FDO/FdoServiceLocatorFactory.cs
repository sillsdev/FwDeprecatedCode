// --------------------------------------------------------------------------------------------
// Copyright (C) 2009 SIL International. All rights reserved.
// 
// Distributable under the terms of either the Common Public License or the
// GNU Lesser General Public License, as specified in the LICENSING.txt file.
// 
// File: ServiceLocatorFactory.cs
// Responsibility: Randy Regnier
// Last reviewed: never
// --------------------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using Microsoft.Practices.ServiceLocation;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.FwUtils;
using SIL.FieldWorks.FDO.Application;
using SIL.FieldWorks.FDO.Application.Impl;
using SIL.FieldWorks.FDO.Infrastructure;
using SIL.FieldWorks.FDO.Infrastructure.Impl;
using SIL.FieldWorks.FDO.DomainServices.DataMigration;
using StructureMap;
using StructureMap.Configuration.DSL;
using StructureMap.Pipeline;
using StructureMap.ServiceLocatorAdapter;

namespace SIL.FieldWorks.FDO.IOC
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Factory for hard-wired FDO Common Service Locator.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	internal sealed partial class FdoServiceLocatorFactory : IServiceLocatorBootstrapper
	{
		private readonly FDOBackendProviderType m_backendProviderType;

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="backendProviderType"></param>
		/// ------------------------------------------------------------------------------------
		internal FdoServiceLocatorFactory(FDOBackendProviderType backendProviderType)
		{
			m_backendProviderType = backendProviderType;
		}

		#region Implementation of IServiceLocatorBootstrapper

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Create an IServiceLocator instance.
		/// </summary>
		/// <returns>An IServiceLocator instance.</returns>
		/// ------------------------------------------------------------------------------------
		public IServiceLocator CreateServiceLocator()
		{
			var registry = new Registry();

			// NB: Default is:
			// .CacheBy(InstanceScope.PerRequest);

			// Add data migration manager. (new one per request)
			registry
				.For<IDataMigrationManager>()
				.Use<FdoDataMigrationManager>();

			// Add FdoCache
			registry
				.For<FdoCache>()
				.LifecycleIs(new SingletonLifecycle())
				.Use<FdoCache>();

			// Add ITsStrFactory
			registry
				.For<ITsStrFactory>()
				.LifecycleIs(new SingletonLifecycle())
				.Use(c => TsStrFactoryClass.Create());

			// Add ILgWritingSystemFactory
			registry
				.For<ILgWritingSystemFactory>()
				.LifecycleIs(new SingletonLifecycle())
				.Use(wsf => LgWritingSystemFactoryClass.Create());

			// Add MDC
			registry
				.For<IFwMetaDataCacheManaged>()
				.LifecycleIs(new SingletonLifecycle())
				.Use<FdoMetaDataCache>();
			// Register its other interface.
			registry
				.For<IFwMetaDataCacheManagedInternal>()
				.Use(c => (IFwMetaDataCacheManagedInternal)c.GetInstance<IFwMetaDataCacheManaged>());

			// Add IdentityMap
			registry
				.For<IdentityMap>()
				.LifecycleIs(new SingletonLifecycle())
				.Use<IdentityMap>();
			// No. This makes a second instance of IdentityMap,
			// which is probably not desirable.
			//registry
			//    .For<ICmObjectIdFactory>()
			//    .LifecycleIs(new SingletonLifecycle())
			//    .Use<IdentityMap>();
			// Register IdentityMap's other interface.
			registry
				.For<ICmObjectIdFactory>()
				.Use(c => (ICmObjectIdFactory)c.GetInstance<IdentityMap>());

			// Add surrogate factory (internal);
			registry
				.For<ICmObjectSurrogateFactory>()
				.LifecycleIs(new SingletonLifecycle())
				.Use<CmObjectSurrogateFactory>();

			// Add surrogate repository (internal);
			registry
				.For<ICmObjectSurrogateRepository>()
				.LifecycleIs(new SingletonLifecycle())
				.Use<CmObjectSurrogateRepository>();

			// Add BEP.
			switch (m_backendProviderType)
			{
				default:
					throw new InvalidOperationException(Strings.ksInvalidBackendProviderType);
				case FDOBackendProviderType.kXML:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<XMLBackendProvider>();
					break;
				case FDOBackendProviderType.kDb4o:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<DB4oBackendProvider>();
					break;
				case FDOBackendProviderType.kDb4oCS:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<DB4oCSBackendProvider>();
					break;
				case FDOBackendProviderType.kBerkeleyDB:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<BerkeleyDBBackendProvider>();
					break;
				case FDOBackendProviderType.kMemoryOnly:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<MemoryOnlyBackendProvider>();
					break;
				case FDOBackendProviderType.kMercurial:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<MercurialBackend>();
					break;
				case FDOBackendProviderType.kGit:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<GitBackendProvider>();
					break;
				case FDOBackendProviderType.kXmlFiles:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<XmlFilesBackendProvider>();
					break;
				case FDOBackendProviderType.kMySqlClientServer:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<MySqlClientServerBackend>();
					break;
				case FDOBackendProviderType.kMySqlClientServerInnoDB:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<MySqlClientServerBackendInnoDB>();
					break;
				case FDOBackendProviderType.kDataStore:
					registry
						.For<IDataSetup>()
						.LifecycleIs(new SingletonLifecycle())
						.Use<DataStore>();
					break;
			}
			// Register two additional interfaces of the BEP, which are injected into other services.
			registry
				.For<IDataStorer>()
				.Use(c => (IDataStorer)c.GetInstance<IDataSetup>());
			registry
				.For<IDataReader>()
				.Use(c => (IDataReader)c.GetInstance<IDataSetup>());

			// Add Mediator
			registry
				.For<IActionHandler>()
				.LifecycleIs(new SingletonLifecycle())
				.Use<FdoMediator>();
			// Register two additional interfaces for the IActionHandler.
			registry
				.For<IUnitOfWorkService>()
				.Use(c => (IUnitOfWorkService)c.GetInstance<IActionHandler>());
			registry
				.For<IWorkerThreadReadHandler>()
				.Use(c => (IWorkerThreadReadHandler) c.GetInstance<IActionHandler>());

			// Add generated factories.
			AddFactories(registry);

			// Add generated Repositories
			AddRepositories(registry);

			// Add IAnalysisRepository
			registry
				.For<IAnalysisRepository>()
				.LifecycleIs(new SingletonLifecycle())
				.Use<AnalysisRepository>();

			// Add SDA
			registry
				.For<ISilDataAccessManaged>()
				.LifecycleIs(new SingletonLifecycle())
				.Use<DomainDataByFlid>();

			// Add loader helper
			registry
				.For<LoadingServices>()
				.LifecycleIs(new SingletonLifecycle())
				.Use<LoadingServices>();

			var container = new Container(registry);
			// Do this once after something is added, to make sure
			// the entire set of objects can be created.
			// After it proves ok, then block the line again,
			// and let SM create them 'on demand'.
			//container.AssertConfigurationIsValid();

			return new StructureMapServiceLocatorWrapper(new StructureMapServiceLocator(container));
		}

		#endregion
	}

	/// <summary>
	/// Wrapper for StructureMapServiceLocator,
	/// which adds the extra methods of IFdoServiceLocator.
	/// </summary>
    internal sealed class StructureMapServiceLocatorWrapper : IFdoServiceLocator, IServiceLocatorInternal
	{
		private readonly StructureMapServiceLocator m_baseServiceLocator;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="baseServiceLocator"></param>
		internal StructureMapServiceLocatorWrapper(StructureMapServiceLocator baseServiceLocator)
		{
			if (baseServiceLocator == null) throw new ArgumentNullException("baseServiceLocator");

			m_baseServiceLocator = baseServiceLocator;
		}

		#region Implementation of IServiceProvider

		/// <summary>
		/// Gets the service object of the specified type.
		/// </summary>
		/// <returns>
		/// A service object of type <paramref name="serviceType"/>.
		///                     -or- 
		///                 null if there is no service object of type <paramref name="serviceType"/>.
		/// </returns>
		/// <param name="serviceType">An object that specifies the type of service object to get. 
		///                 </param><filterpriority>2</filterpriority>
		public object GetService(Type serviceType)
		{
			return m_baseServiceLocator.GetService(serviceType);
		}

		#endregion

		#region Implementation of IServiceLocator

		/// <summary>
		/// Get an instance of the given <paramref name="serviceType"/>.
		/// </summary>
		/// <param name="serviceType">Type of object requested.</param><exception cref="T:Microsoft.Practices.ServiceLocation.ActivationException">if there is an error resolving
		///             the service instance.</exception>
		/// <returns>
		/// The requested service instance.
		/// </returns>
		public object GetInstance(Type serviceType)
		{
			return m_baseServiceLocator.GetInstance(serviceType);
		}

		/// <summary>
		/// Get an instance of the given named <paramref name="serviceType"/>.
		/// </summary>
		/// <param name="serviceType">Type of object requested.</param><param name="key">Name the object was registered with.</param><exception cref="T:Microsoft.Practices.ServiceLocation.ActivationException">if there is an error resolving
		///             the service instance.</exception>
		/// <returns>
		/// The requested service instance.
		/// </returns>
		public object GetInstance(Type serviceType, string key)
		{
			return m_baseServiceLocator.GetInstance(serviceType, key);
		}

		/// <summary>
		/// Get all instances of the given <paramref name="serviceType"/> currently
		///             registered in the container.
		/// </summary>
		/// <param name="serviceType">Type of object requested.</param><exception cref="T:Microsoft.Practices.ServiceLocation.ActivationException">if there is are errors resolving
		///             the service instance.</exception>
		/// <returns>
		/// A sequence of instances of the requested <paramref name="serviceType"/>.
		/// </returns>
		public IEnumerable<object> GetAllInstances(Type serviceType)
		{
			return m_baseServiceLocator.GetAllInstances(serviceType);
		}

		/// <summary>
		/// Get an instance of the given <typeparamref name="TService"/>.
		/// </summary>
		/// <typeparam name="TService">Type of object requested.</typeparam><exception cref="T:Microsoft.Practices.ServiceLocation.ActivationException">if there is are errors resolving
		///             the service instance.</exception>
		/// <returns>
		/// The requested service instance.
		/// </returns>
		public TService GetInstance<TService>()
		{
			return m_baseServiceLocator.GetInstance<TService>();
		}

		/// <summary>
		/// Get an instance of the given named <typeparamref name="TService"/>.
		/// </summary>
		/// <typeparam name="TService">Type of object requested.</typeparam><param name="key">Name the object was registered with.</param><exception cref="T:Microsoft.Practices.ServiceLocation.ActivationException">if there is are errors resolving
		///             the service instance.</exception>
		/// <returns>
		/// The requested service instance.
		/// </returns>
		public TService GetInstance<TService>(string key)
		{
			return m_baseServiceLocator.GetInstance<TService>(key);
		}

		/// <summary>
		/// Get all instances of the given <typeparamref name="TService"/> currently
		///             registered in the container.
		/// </summary>
		/// <typeparam name="TService">Type of object requested.</typeparam><exception cref="T:Microsoft.Practices.ServiceLocation.ActivationException">if there is are errors resolving
		///             the service instance.</exception>
		/// <returns>
		/// A sequence of instances of the requested <typeparamref name="TService"/>.
		/// </returns>
		public IEnumerable<TService> GetAllInstances<TService>()
		{
			return m_baseServiceLocator.GetAllInstances<TService>();
		}

		#endregion

		#region Implementation of IFdoServiceLocator

		/// <summary>
		/// Get the specified object instance; short for getting ICmObjectRepository and asking it to GetObject.
		/// </summary>
		public ICmObject GetObject(int hvo)
		{
			return m_baseServiceLocator.GetInstance<ICmObjectRepository>().GetObject(hvo);
		}

        /// <summary>
        /// Answers true iff GetObject(hvo) will succeed; useful to avoid throwing and catching exceptions
        /// when possibly working with fake objects.
        /// </summary>
        public bool IsValidObjectId(int hvo)
        {
            return m_baseServiceLocator.GetInstance<ICmObjectRepository>().IsValidObjectId(hvo);
            
        }


		/// <summary>
		/// Get the specified object instance; short for getting ICmObjectRepository and asking it to GetObject.
		/// </summary>
		public ICmObject GetObject(Guid guid)
		{
			return m_baseServiceLocator.GetInstance<ICmObjectRepository>().GetObject(guid);
		}

        /// <summary>
        /// Get the specified object instance; short for getting ICmObjectRepository and asking it to GetObject.
        /// </summary>
        public ICmObject GetObject(ICmObjectId id)
        {
            return m_baseServiceLocator.GetInstance<ICmObjectRepository>().GetObject(id);
        }

	    private ILgWritingSystemRepository m_writingSystems;
		/// <summary>
		/// Shortcut to the WS repository.
		/// </summary>
		public ILgWritingSystemRepository WritingSystems
		{
			get { return m_writingSystems ?? (m_writingSystems = m_baseServiceLocator.GetInstance<ILgWritingSystemRepository>()); }
		}

	    private ICmObjectRepository m_objectRepository;
        /// <summary>
        /// Shortcut.
        /// </summary>
	    public ICmObjectRepository ObjectRepository
	    {
            get {
                return m_objectRepository ??
                       (m_objectRepository = m_baseServiceLocator.GetInstance<ICmObjectRepository>());
            }
	    }

        private ICmObjectIdFactory m_idFactory;
        /// <summary>
        /// Shortcut.
        /// </summary>
	    public ICmObjectIdFactory ObjectIdFactory
	    {
            get { return m_idFactory ?? (m_idFactory = m_baseServiceLocator.GetInstance<ICmObjectIdFactory>()); }
	    }

	    private IFwMetaDataCacheManaged m_mdc;
        /// <summary>
        /// Shortcut.
        /// </summary>
	    public IFwMetaDataCacheManaged MetaDataCache
	    {
            get { return m_mdc ?? (m_mdc = m_baseServiceLocator.GetInstance<IFwMetaDataCacheManaged>()); }
	    }

        private ILgWritingSystemFactory m_wsf;
        /// <summary>
        /// Shortcut to the writing system factory that gives meaning to writing systems.
        /// </summary>
        public ILgWritingSystemFactory WritingSystemFactory
	    {
            get { return m_wsf ?? (m_wsf = m_baseServiceLocator.GetInstance<ILgWritingSystemFactory>()); }
	    }

	    private LoadingServices m_loadingServices;
        /// <summary>
        /// Shortcut to a service used in fluffing up surrogates.
        /// </summary>
        public LoadingServices LoadingServices
        {
            get { return m_loadingServices ?? (m_loadingServices = m_baseServiceLocator.GetInstance<LoadingServices>()); }
        }

        private IdentityMap m_identityMap;
        /// <summary>
        /// Shortcut to the map used to find the one and only instance of FDO object for any given id.
        /// </summary>
        public IdentityMap IdentityMap
        {
            get { return m_identityMap ?? (m_identityMap = m_baseServiceLocator.GetInstance<IdentityMap>()); }
        }
	    #endregion
	}
}