//#define USEENVANDTRANS
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.IO;
using NUnit.Framework;
using SIL.FieldWorks.Common.COMInterfaces;
using SIL.FieldWorks.Common.FwUtils;
using SIL.Utils;
using SIL.FieldWorks.FDO.Application;
using SIL.FieldWorks.FDO.FDOTests;
using SIL.FieldWorks.FDO.Infrastructure;

namespace SIL.FieldWorks.FDO.CoreTests.PersistingLayerTests
{
	/// <summary>
	/// This class defines all the tests to be run by the
	/// persisting backend providers (BEP), embedded and client-server.
	/// 
	/// (Client-server only BEP tests are defined in
	/// PersistingClientServerBackendProviderTestBase, which derives
	/// from this class.)
	/// 
	/// The embedded BEP test classes that actually store data
	/// derive from this base class, in order to create the required BEP.
	/// 
	/// The client-server BEP test classes derive from PersistingClientServerBackendProviderTestBase.
	/// 
	/// All tests that are common to both embedded and client-server BEPs are defined on this class,
	/// however, so all BEPs can be tested the exact same way.
	/// I can do this, because BEPs only support the four basic
	/// "CRUD" operations (Create, Read, Update, and Delete).
	/// 
	/// Test CmObject properties.
	/// 1. Guid,
	/// 2. Owner.
	/// 3. OwningFlid
	/// 
	/// Test the most basic generated properties.
	/// We test these flid types here:
	/// CellarModuleDefns.kcptBoolean: Done
	/// CellarModuleDefns.kcptInteger: Done
	/// CellarModuleDefns.kcptTime: Done
	/// CellarModuleDefns.kcptGuid: Done
	/// CellarModuleDefns.kcptGenDate: Done
	/// CellarModuleDefns.kcptBinary: Done
	/// 
	/// CellarModuleDefns.kcptUnicode: Done
	/// CellarModuleDefns.kcptBigUnicode: Done
	/// 
	/// CellarModuleDefns.kcptString: Done
	/// CellarModuleDefns.kcptBigString: Done
	/// 
	/// CellarModuleDefns.kcptMultiString: Done
	/// CellarModuleDefns.kcptMultiBigString: Done
	/// 
	/// CellarModuleDefns.kcptMultiUnicode: Done
	/// CellarModuleDefns.kcptMultiBigUnicode: Done
	/// 
	/// CellarModuleDefns.kcptNumeric: (Not used in model.)
	/// CellarModuleDefns.kcptFloat: (Not used in model.)
	/// CellarModuleDefns.kcptImage: (Not used in model.)
	/// 
	/// </summary>
	public abstract class PersistingBackendProviderTestBase : FdoTestBase
	{
		private int m_customCertifiedFlid;
		private int m_customITsStringFlid;
		private int m_customMultiUnicodeFlid;
		private int m_customAtomicReferenceFlid;
		//private int m_customReferenceSequenceFlid; // This is a 'gonna be', not a 'has been'.
		/// <summary></summary>
		protected BackendBulkLoadDomain m_loadType = BackendBulkLoadDomain.All;

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// If a test overrides this, it should call the base implementation.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[TestFixtureSetUp]
		public override void FixtureSetup()
		{
			base.FixtureSetup();

			var servLoc = Cache.ServiceLocator;
			var mdc = servLoc.GetInstance<IFwMetaDataCacheManaged>();
			if (m_internalRestart)
			{
				m_customCertifiedFlid = mdc.GetFieldId("WfiWordform", "Certified", false);
				m_customITsStringFlid = mdc.GetFieldId("WfiWordform", "NewTsStringProp", false);
				m_customMultiUnicodeFlid = mdc.GetFieldId("WfiWordform", "MultiUnicodeProp", false);
				m_customAtomicReferenceFlid = mdc.GetFieldId("WfiWordform", "NewAtomicRef", false);
				//m_customReferenceSequenceFlid = mdc.GetFieldId("WfiWordform", "NewRefSeq", false);
			}
			else
			{
				m_customCertifiedFlid = mdc.AddCustomField("WfiWordform", "Certified", FieldType.kcptBoolean, 0);
				m_customITsStringFlid = mdc.AddCustomField("WfiWordform", "NewTsStringProp", FieldType.kcptString, 0);
				m_customMultiUnicodeFlid = mdc.AddCustomField("WfiWordform", "MultiUnicodeProp", FieldType.kcptMultiUnicode, 0);
				m_customAtomicReferenceFlid = mdc.AddCustomField("WfiWordform", "NewAtomicRef", FieldType.kcptReferenceAtom, CmPersonTags.kClassId);
				//m_customReferenceSequenceFlid = mdc.AddCustomField("WfiWordform", "NewRefSeq", FieldType.kcptReferenceSequence, CmPersonTags.kClassId);
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// If a test overrides this, it should call the base implementation.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public override void FixtureTeardown()
		{
			m_customCertifiedFlid = 0;
			m_customITsStringFlid = 0;
			m_customMultiUnicodeFlid = 0;
			m_customAtomicReferenceFlid = 0;
			//m_customReferenceSequenceFlid = 0;

			base.FixtureTeardown();
		}

		/// <summary>
		/// Make sure the basic data types are right.
		/// </summary>
		[Test]
		public void BasicDataTypes()
		{
			Cache.DomainDataByFlid.BeginNonUndoableTask();

			var lp = Cache.LanguageProject;

			// 'Remember' some guids.
			// Atomic property.
			var lpGuid = lp.Guid;
			// Owning collection property.
			var aaGuid = lp.AnalyzingAgentsOC.ToArray()[0].Guid;
			// Owning sequence property.
			var pssGuid = lp.TranslationTagsOA.PossibilitiesOS[0].Guid;

			// CellarModuleDefns.kcptBoolean:
			lp.TranslationTagsOA.IsClosed = true;
			var isClosed = lp.TranslationTagsOA.IsClosed;
			var isSorted = lp.TranslationTagsOA.IsSorted;
			// CellarModuleDefns.kcptInteger:
			lp.TranslationTagsOA.Depth = 5;
			var depth = lp.TranslationTagsOA.Depth;
			// CellarModuleDefns.kcptTime
			var dateCreated = lp.DateCreated;
			// CellarModuleDefns.kcptGuid
			var uv = Cache.ServiceLocator.GetInstance<IUserViewFactory>().Create();
			uv.App = Guid.NewGuid();
			var appGuid = uv.App;
			var uvGuid = uv.Guid;
			// CellarModuleDefns.kcptGenDate
			lp.PeopleOA = Cache.ServiceLocator.GetInstance<ICmPossibilityListFactory>().Create();
			var eve = Cache.ServiceLocator.GetInstance<ICmPersonFactory>().Create();
			lp.PeopleOA.PossibilitiesOS.Add(eve);
			eve.DateOfBirth = new GenDate(GenDate.PrecisionType.Before, 1, 1, 3000, true);
			var eveDOB = eve.DateOfBirth;
			// CellarModuleDefns.kcptBinary:
			var byteArrayValue = new byte[] { 1, 2, 3 };
			uv.Details = byteArrayValue;
			// CellarModuleDefns.kcptUnicode & CellarModuleDefns.kcptBigUnicode:
			const string newEthCode = "ZPI";
			lp.EthnologueCode = newEthCode;
			// CellarModuleDefns.kcptString & CellarModuleDefns.kcptBigString:
			var le = Cache.ServiceLocator.GetInstance<ILexEntryFactory>().Create();
			lp.LexDbOA.EntriesOC.Add(le);
			var irOriginalValue = Cache.TsStrFactory.MakeString("<import & residue>",
			                                                    Cache.WritingSystemFactory.UserWs);
			le.ImportResidue = irOriginalValue;
			var streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTssAsXml(irOriginalValue,
			                            Cache.WritingSystemFactory,
			                            0,
			                            Cache.WritingSystemFactory.UserWs, true);
			var xmlOriginalValue = streamWrapper.Contents;
			// ITsTextProps
			var userWs = Cache.WritingSystemFactory.UserWs;
			var bldr = TsPropsBldrClass.Create();
			bldr.SetStrPropValue((int)FwTextPropType.ktptNamedStyle, "Arial");
			bldr.SetIntPropValues((int)FwTextPropType.ktptWs, 0, userWs);
			var style = Cache.ServiceLocator.GetInstance<IStStyleFactory>().Create();
			lp.StylesOC.Add(style);
			const string styleName = "Name With <this> & <that>";
			style.Name = styleName;
			style.Rules = bldr.GetTextProps();
			var rOriginalvalue = style.Rules;
			streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTtpAsXml(rOriginalvalue,
			                            Cache.WritingSystemFactory,
			                            0);
			var xmlOriginalValueRules = streamWrapper.Contents;

			// Use same test, since the multiString and MultiUnicode props
			// all use the same mechanism (on MultiAccessor) to read/write
			// the data.
			// CellarModuleDefns.kcptMultiString:
			// CellarModuleDefns.kcptMultiBigString:
			// CellarModuleDefns.kcptMultiUnicode:
			// CellarModuleDefns.kcptMultiBigUnicode:
			var tsf = Cache.TsStrFactory;
			var englishWsHvo = Cache.WritingSystemFactory.GetWsFromStr("en");
			var nameEnValue = tsf.MakeString("Stateful FDO Test Project", englishWsHvo);
			streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTssAsXml(nameEnValue,
			                            Cache.WritingSystemFactory,
			                            0,
			                            englishWsHvo, true);
			// Set LP's Name.
			//lp.Name.set_String(
			//    englishWsHvo,
			//    nameEnValue);
			//var nameEsValue = tsf.MakeString("Proyecto de prueba: FDO", spanishWsHvo);
			//streamWrapper = TsStreamWrapperClass.Create();
			//streamWrapper.WriteTssAsXml(nameEsValue,
			//     Cache.WritingSystemFactory,
			//     0,
			//     spanishWsHvo, true);
			//var esXML = streamWrapper.Contents;
			//lp.Name.set_String(
			//    spanishWsHvo,
			//    nameEsValue);

			// Check that ScriptureReferenceSystem is persisted & reloaded.
			var srs = lp.ScriptureReferenceSystem;

			Cache.DomainDataByFlid.EndNonUndoableTask(); // Should do a commit.

			// Restart BEP.
			RestartCache(false);
			lp = Cache.LanguageProject;

			// Atomic property.
			var lpGuidRestored = lp.Guid;
			Assert.IsTrue(lpGuid == lpGuidRestored, "Object Guid not saved/restored properly.");

			// Owning collection property.
			Assert.IsTrue(lp.AnalyzingAgentsOC.ToArray()[0].Guid == aaGuid,
			              "AnalyzingAgent Guid not the same.");

			// Owning sequence property.
			Assert.IsTrue(lp.TranslationTagsOA.PossibilitiesOS[0].Guid == pssGuid,
			              "Translation type Guid not the same.");

			// Check bool.
			Assert.IsTrue(lp.TranslationTagsOA.IsClosed,
			                "Wrong boolean value restored (for true).");
			Assert.AreEqual(isSorted, lp.TranslationTagsOA.IsSorted,
				"Wrong boolean value restored (for false).");
			// Check int.
			Assert.AreEqual(depth,
			                lp.TranslationTagsOA.Depth,
			                "Wrong integer value restored.");
			// Check time.
			Assert.AreEqual(dateCreated.Year,
			                lp.DateCreated.Year,
			                "Wrong year part of time value restored.");
			Assert.AreEqual(dateCreated.Month,
			                lp.DateCreated.Month,
			                "Wrong month part of time value restored.");
			Assert.AreEqual(dateCreated.Day,
			                lp.DateCreated.Day,
			                "Wrong day part of time value restored.");
			Assert.AreEqual(dateCreated.Hour,
			                lp.DateCreated.Hour,
			                "Wrong hour part of time value restored.");
			Assert.AreEqual(dateCreated.Minute,
			                lp.DateCreated.Minute,
			                "Wrong minute part of time value restored.");
			Assert.AreEqual(dateCreated.Second,
			                lp.DateCreated.Second,
			                "Wrong second part of time value restored.");
			Assert.AreEqual(dateCreated.Millisecond,
			                lp.DateCreated.Millisecond,
			                "Wrong millisecond time value restored.");
			// Check Guid.
			uv = Cache.ServiceLocator.GetInstance<IUserViewRepository>().GetObject(uvGuid);
			Assert.AreEqual(appGuid,
			                uv.App,
			                "Wrong Guid value restored.");
			// Check GenDate
			eve = (ICmPerson)lp.PeopleOA.PossibilitiesOS[0];
			Assert.AreEqual(eveDOB,
			                eve.DateOfBirth,
			                "Wrong DOB value restored.");
			// Check Binary.
			Assert.AreEqual(byteArrayValue,
			                uv.Details,
			                "Wrong Binary value restored.");
			// Check Unicode
			Assert.AreEqual(newEthCode,
			                lp.EthnologueCode,
			                "Wrong Unicode value restored.");
			// Check string (ITsString)
			var irRestoredValue = lp.LexDbOA.EntriesOC.ToArray()[0].ImportResidue;
			streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTssAsXml(irRestoredValue,
			                            Cache.WritingSystemFactory,
			                            0,
			                            Cache.WritingSystemFactory.UserWs, true);
			var xmlRestoredValue = streamWrapper.Contents;
			Assert.AreEqual(xmlOriginalValue, xmlRestoredValue,
			                "Wrong ITsString value restored.");
			// ITsTextProps
			var rRestoredValue = lp.StylesOC.ToArray()[0].Rules;
			streamWrapper = TsStreamWrapperClass.Create();
			streamWrapper.WriteTtpAsXml(rRestoredValue,
			                            Cache.WritingSystemFactory,
			                            0);
			var xmlRestoredValueRules = streamWrapper.Contents;
			Assert.AreEqual(xmlOriginalValueRules, xmlRestoredValueRules,
			                "Wrong ITsTextProps value restored.");

			var styleRestoredName = lp.StylesOC.ToArray()[0].Name;
			Assert.AreEqual(styleName, styleRestoredName, "Wrong style name restored.");
			
			//englishWsHvo = Cache.WritingSystemFactory.GetWsFromStr("en");
			//irRestoredValue = lp.Name.get_String(englishWsHvo);
			//streamWrapper = TsStreamWrapperClass.Create();
			//streamWrapper.WriteTssAsXml(irRestoredValue,
			//     Cache.WritingSystemFactory,
			//     0,
			//     englishWsHvo, true);
			//Assert.AreEqual(enXML, streamWrapper.Contents,
			//    "Wrong ITsString value (Name) restored.");
			//spanishWsHvo = Cache.WritingSystemFactory.GetWsFromStr("es");
			//irRestoredValue = lp.Name.get_String(spanishWsHvo);
			//streamWrapper = TsStreamWrapperClass.Create();
			//streamWrapper.WriteTssAsXml(irRestoredValue,
			//     Cache.WritingSystemFactory,
			//     0,
			//     spanishWsHvo, true);
			//Assert.AreEqual(esXML, streamWrapper.Contents,
			//    "Wrong ITsString value (Name) restored.");

			Assert.AreEqual(srs.Guid, lp.ScriptureReferenceSystem.Guid, "Wrong ScriptureReferenceSystem Guid.");
		}

		/// <summary>
		/// Make sure BackendProvider does an 'on demand' load.
		/// </summary>
		[Test]
		public void OnDemandLoadTest()
		{
			var originalLoadType = m_loadType;
			try
			{
				m_loadType = BackendBulkLoadDomain.None;
				RestartCache(false);

				var lp = Cache.LanguageProject;
				var lexDb = lp.LexDbOA;
				Assert.IsNotNull(lexDb, "Null Lex DB.");
			}
			finally
			{
				m_loadType = originalLoadType;
				RestartCache(false);
			}
		}

		/// <summary>
		/// Add new custom field, persist it, and reload it.
		/// </summary>
		[Test]
		public void CustomFieldTest()
		{
			// Restart BEP to force a commit.
			RestartCache(true);

			// Make sure the custom fields were reloaded,
			// which means they had to also have been saved.
			var mdc = Cache.ServiceLocator.GetInstance<IFwMetaDataCacheManaged>();
			var flid = mdc.GetFieldId("WfiWordform", "Certified", false);
			Assert.IsTrue(mdc.IsCustom(flid));
			flid = mdc.GetFieldId("WfiWordform", "NewAtomicRef", false);
			Assert.IsTrue(mdc.IsCustom(flid));
		}

		/// <summary>
		/// Add new custom field data, persist it, and reload it.
		/// </summary>
		[Test]
		public void CustomFieldDataTest()
		{
			var servLoc = Cache.ServiceLocator;
			var sda = servLoc.GetInstance<ISilDataAccessManaged>();
			var lp = Cache.LanguageProject;

			sda.BeginNonUndoableTask();
			var wf = servLoc.GetInstance<IWfiWordformFactory>().Create();
			var wfGuid = wf.Guid;
			// Set custom boolean property.
			sda.SetBoolean(wf.Hvo, m_customCertifiedFlid, true);
			// Set custom ITsString property.
			var tsf = Cache.TsStrFactory;
			var userWs = Cache.WritingSystemFactory.UserWs;
			var newStringValue = tsf.MakeString("New ITsString", userWs);
			sda.SetString(wf.Hvo, m_customITsStringFlid, newStringValue);
			// Set custom MultiUnicode property.
			var newUnicodeTsStringValue = tsf.MakeString("New unicode ITsString", userWs);
			sda.SetMultiStringAlt(wf.Hvo, m_customMultiUnicodeFlid, userWs, newUnicodeTsStringValue);
			// Set atomic reference custom property.
			var possListFactory = servLoc.GetInstance<ICmPossibilityListFactory>();
			lp.PeopleOA = possListFactory.Create();
			var personFactory = servLoc.GetInstance<ICmPersonFactory>();
			var person = personFactory.Create();
			lp.PeopleOA.PossibilitiesOS.Add(person);
			var personGuid = person.Guid;
			sda.SetObjProp(wf.Hvo, m_customAtomicReferenceFlid, person.Hvo);

			// possibly temp
			Cache.DomainDataByFlid.EndNonUndoableTask();

			// Restart BEP.
			RestartCache(false);

			servLoc = Cache.ServiceLocator;
			userWs = Cache.WritingSystemFactory.UserWs;
			sda = servLoc.GetInstance<ISilDataAccessManaged>();
			wf = servLoc.GetInstance<IWfiWordformRepository>().GetObject(wfGuid);
			Assert.IsTrue(sda.get_BooleanProp(wf.Hvo, m_customCertifiedFlid), "Custom prop is not 'true'.");
			var tss = sda.get_StringProp(wf.Hvo, m_customITsStringFlid);
			Assert.AreEqual(tss.Text, newStringValue.Text, "Wrong TsString in custom property.");
			tss = sda.get_MultiStringAlt(wf.Hvo, m_customMultiUnicodeFlid, userWs);
			Assert.AreEqual(tss.Text, newUnicodeTsStringValue.Text, "MultiUnicode custom property is not newUnicodeTsStringValue.");
			person = servLoc.GetInstance<ICmPersonRepository>().GetObject(personGuid);
			Assert.AreEqual(person.Hvo, sda.get_ObjectProp(wf.Hvo, m_customAtomicReferenceFlid), "Wrong atomic ref custom value.");
		}

		/// <summary>
		/// Rename the database to something else, and back again.
		/// </summary>
		[Test]
		public void RenameDatabaseTest()
		{
			string sOrigName = Cache.DatabaseName;
			const string sNewProjectName = "SomethingCompletelyDifferent";
			bool fOk = Cache.RenameDatabase(sNewProjectName);
			Assert.IsTrue(fOk, "Renaming database file(s) to something completely different succeeded");
			string s = Path.GetFileNameWithoutExtension(Cache.DatabaseName);
			if (s != sNewProjectName)
				Assert.AreEqual(sNewProjectName.ToUpperInvariant(), s, "Renaming database file(s) changed the DatabaseName property correctly");
			else
				Assert.AreEqual(sNewProjectName, s, "Renaming database file(s) changed the DatabaseName property correctly");
			fOk = Cache.RenameDatabase(sOrigName);
			Assert.IsTrue(fOk, "Renaming database file(s) back to the original name(s) succeeded");
			s = Cache.DatabaseName;
			Assert.AreEqual(sOrigName, s, "Renaming database file(s) back changed the DatabaseName property correctly");
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kMemoryOnly
	/// backend provider. Technically, this one need not be test here, since it doesn't
	/// actually persist anything, but in order to have the test stabel be complete for
	/// all BEPs, I run them anyway.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class MemoryOnlyTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			return BootstrapSystem(FDOBackendProviderType.kMemoryOnly, null, m_loadType);
		}

		/// <summary>
		/// Override to do nothing.
		/// </summary>
		/// <param name="doCommit">'True' to end the task and commit the changes. 'False' to skip the commit.</param>
		protected override void RestartCache(bool doCommit)
		{
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kDb4o
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class DB4oTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string filename = "TestLangProj.db4o";
			if (!m_internalRestart && File.Exists(filename))
				File.Delete(filename);

			return BootstrapSystem(FDOBackendProviderType.kDb4o, new object[] { filename }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kDb4o
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class DB4oCSTests : PersistingClientServerBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string filename = "TestLangProjCS.db4o";
			if (!m_internalRestart && File.Exists(filename))
				File.Delete(filename);

			return BootstrapSystem(FDOBackendProviderType.kDb4oCS, new object[] { filename }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kBerkeleyDB
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	[Category("ExcludeOnLinux64")] // TODO-Linux: Berkley-DB .NET wrapper doesn't work on Linux 64-bit
	public sealed class BerkeleyDBTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			var codepath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase.Substring(MiscUtils.IsUnix ? 7 : 8));
			var bdbPath = Path.Combine(codepath, "TestLangProj.bdb");
#if USEENVANDTRANS
			string dirMain = Path.Combine(codepath, "Main");
			if (!Directory.Exists(dirMain))
				Directory.CreateDirectory(dirMain);
			string dirSecondary = Path.Combine(codepath, "Secondary");
			if (!Directory.Exists(dirSecondary))
				Directory.CreateDirectory(dirSecondary);
#endif
			if (!m_internalRestart)
			{
#if USEENVANDTRANS
				string mainPath = Path.Combine(dirMain, "TestLangProj.bdb");
				if (File.Exists(mainPath))
					File.Delete(mainPath);
				string idxPath = Path.Combine(Path.Combine(codepath, @"Secondary"), "TestLangProj.idx");
				if (File.Exists(idxPath))
					File.Delete(idxPath);
#else
				if (File.Exists(bdbPath))
					File.Delete(bdbPath);
				var idxPath = Path.Combine(codepath, "TestLangProj.idx");
				if (File.Exists(idxPath))
					File.Delete(idxPath);
#endif
			}

			return BootstrapSystem(FDOBackendProviderType.kBerkeleyDB, new object[] {bdbPath}, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kXML
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class XMLTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string filename = "TestLangProj.xml";
			if (!m_internalRestart)
			{
				if (File.Exists(filename))
					File.Delete(filename);
			}

			return BootstrapSystem(FDOBackendProviderType.kXML, new object[] { filename }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kMercurial
	/// back end provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class MercurialTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string fileName = "TestLangProjMercurial.xml";
			var path = Path.Combine(Path.GetTempPath(), "FieldWorksTest");

			if (!m_internalRestart)
			{
				if (File.Exists(Path.Combine(path, fileName)))
					File.Delete(Path.Combine(path, fileName));
				if (Directory.Exists(path))
					Directory.Delete(path, true);
				Directory.CreateDirectory(path);
			}

			return BootstrapSystem(FDOBackendProviderType.kMercurial,
				new object[] { fileName, path }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kGit
	/// back end provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class GitTests : PersistingBackendProviderTestBase
	{
		private const string BaseTestDirectory = "FieldWorksTest";

		internal static string GitPath
		{
			get { return Path.Combine(Path.GetTempPath(), BaseTestDirectory); }
		}

		private static void DeleteDirectory(string path)
		{
			if (!Directory.Exists(path))
				return;

			foreach (var subPath in Directory.GetFileSystemEntries(path))
			{
				if (Directory.Exists(subPath))
					DeleteDirectory(subPath);
				else
				{
					var attr = File.GetAttributes(subPath);
					attr &= ~FileAttributes.ReadOnly;
					File.SetAttributes(subPath, attr);
					File.Delete(subPath);
				}
			}
			Directory.Delete(path);
		}

		internal static void DeleteDatabase(string path)
		{
			DeleteDirectory(path);
		}

		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string projectName = "TestLangProjGit";

			var path = GitPath;

			if (!m_internalRestart)
			{
				if (Directory.Exists(path))
					DeleteDirectory(path);
				Directory.CreateDirectory(path);
			}

			return BootstrapSystem(FDOBackendProviderType.kGit,
				new object[] { projectName, path }, m_loadType);
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Teardown method that is run after all Git tests are run
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public override void FixtureTeardown()
		{
			if (!m_internalRestart)
			DeleteDirectory(Path.Combine(Path.GetTempPath(), BaseTestDirectory));
			base.FixtureTeardown();
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kXmlFiles
	/// back end provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class XmlFilesTests : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string projName = "TestLangProjXmlFiles";
			var tempDirPath = Path.GetTempPath();

			if (!m_internalRestart)
			{
				var projPath = Path.Combine(tempDirPath, projName);
				if (Directory.Exists(projPath))
					Directory.Delete(projPath, true);
				Directory.CreateDirectory(projPath);
			}

			return BootstrapSystem(FDOBackendProviderType.kXmlFiles,
				new object[] { projName, tempDirPath, DvcsType.Mercurial, "0" }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kDataStore
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class DataStoreXmlFilesMercurial : PersistingBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			const string projName = "TestLangProjXmlFiles";
			var tempDirPath = Path.GetTempPath();

			if (!m_internalRestart)
			{
				var projPath = Path.Combine(tempDirPath, projName);
				if (Directory.Exists(projPath))
					Directory.Delete(projPath, true);
				Directory.CreateDirectory(projPath);
			}

			return BootstrapSystem(FDOBackendProviderType.kDataStore, new object[] {
				projName, tempDirPath, FDOBackendProviderType.kXmlFiles, DvcsType.Mercurial},
				m_loadType);
		}
	}

	/// <summary>
	/// Common base class for all client-server tests classes
	/// 
	/// All unit tests for all client-server BEPs should be defined here,
	/// much like the BEP-wide tests are defined in PersistingBackendProviderTestBase.
	/// </summary>
	public abstract class PersistingClientServerBackendProviderTestBase : PersistingBackendProviderTestBase
	{
		private FdoCache m_secondConnectionCache;

		/// <summary>
		/// Get the FdoCache on the first connection.
		/// </summary>
		protected FdoCache CacheFirstConnection
		{
			get { return Cache; }
		}

		/// <summary>
		/// Get the FdoCache on the first connection.
		/// </summary>
		protected FdoCache CacheSecondConnection
		{
			get { return m_secondConnectionCache; }
		}

		/// <summary>
		/// Override method to create second connection.
		/// </summary>
		public override void FixtureSetup()
		{
			base.FixtureSetup();

			m_internalRestart = true;
			try
			{
				m_secondConnectionCache = CreateCache();
			}
			finally
			{
				m_internalRestart = false;
			}
		}

		/// <summary>
		/// Override to dispose the second connection.
		/// </summary>
		public override void FixtureTeardown()
		{
			m_secondConnectionCache.Dispose();
			m_secondConnectionCache = null;

			base.FixtureTeardown();

			var path = Path.Combine(Path.GetTempPath(), "FieldWorksTest");
			if (Directory.Exists(path))
				Directory.Delete(path, true);
		}

		/// <summary>
		/// Make sure the two connections are present on the same database.
		/// </summary>
		[Test]
		public void EnsureThereAreTwoConnectionsOnSameDatabase()
		{
			Assert.IsNotNull(CacheFirstConnection, "Connection #1 is not available.");
			Assert.IsNotNull(CacheSecondConnection, "Connection #2 is not available.");
			Assert.AreNotSame(CacheFirstConnection, CacheSecondConnection, "Connections have the same FdoCache.");
		}

		/// <summary>
		/// Make sure the two connections get the same CmObject.
		/// </summary>
		[Test]
		public void EnsureSameCmObjectTests()
		{
			var lpFromConnection1 = CacheFirstConnection.LanguageProject;
			var lpFromConnection2 = CacheSecondConnection.LanguageProject;
			Assert.AreNotSame(lpFromConnection1, lpFromConnection2, "LangProjects are the same object.");
			Assert.AreEqual(lpFromConnection1.Guid, lpFromConnection2.Guid, "LPs have different Guid ids.");
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kMySqlClientServer
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class MySqlClientServerMyISAMTests : PersistingClientServerBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			var codepath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase.Substring(MiscUtils.IsUnix ? 7 : 8));
			// The unit test framework uses a single cache, and connections get closed
			// on test framework teardown. The database file will have a connection
			// open even after the unit test has completed. Each BEP system *must*
			// have its unique filename, because of this, and because BEP files are not thx
			// interchangeable, even between the embedded and CS MySql BEPs.

			//// MySQL has a file per table, and names the directory after the database name.
			//// The following works only if the datadir parameter in my.ini is set to the
			//// directory--and the computer has been rebooted. When I did that, MySQL failed 
			//// to start up.  
			//var codepath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase.Substring(8));
			const string dbName = "TestLangProjMyISAM";
			//var dirName = Path.Combine(codepath, dbName);
			//if (!m_internalRestart && Directory.Exists(dirName))
			//    Directory.Delete(dirName);

			return BootstrapSystem(FDOBackendProviderType.kMySqlClientServer,
			                       new object[] { dbName }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Base class for testing the FdoCache with the FDOBackendProviderType.kMySqlClientServer
	/// backend provider.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class MySqlClientServerInnoDBTests : PersistingClientServerBackendProviderTestBase
	{
		/// <summary>
		/// Override to create and load a very basic cache.
		/// </summary>
		/// <returns>An FdoCache that has only the basic data in it.</returns>
		protected override FdoCache CreateCache()
		{
			// The unit test framework uses a single cache, and connections get closed
			// on test framework teardown. The database file will have a connection
			// open even after the unit test has completed. Each BEP system *must*
			// have its unique filename, because of this, and because BEP files are not 
			// interchangeable, even between the embedded and CS MySql BEPs.

			//// MySQL has a file per table, and names the directory after the database name.
			//// The following works only if the datadir parameter in my.ini is set to the
			//// directory--and the computer has been rebooted. When I did that, MySQL failed 
			//// to start up.  
			//var codepath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase.Substring(8));
			const string dbName = "TestLangProjInnoDB";
			//var dirName = Path.Combine(codepath, dbName);
			//if (!m_internalRestart && Directory.Exists(dirName))
			//    Directory.Delete(dirName);

			return BootstrapSystem(FDOBackendProviderType.kMySqlClientServerInnoDB,
			                       new object[] { dbName }, m_loadType);
		}
	}

	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Test migrating data from each type of BEP to all others.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	[TestFixture]
	public sealed class BEPPortTests
	{
		/// <summary>
		/// Gets the current architecture (i686 or x86_64 on Linux, or
		/// Win on Windows)
		/// </summary>
		private static string Architecture
		{
			get
			{
	            if (Environment.OSVersion.Platform == PlatformID.Unix)
	            {
                    // Unix - return output from 'uname -m'
                    using (Process process = new Process())
                    {
                            process.StartInfo.FileName = "uname";
                            process.StartInfo.Arguments = "-m";
                            process.StartInfo.UseShellExecute = false;
                            process.StartInfo.CreateNoWindow = true;
                            process.StartInfo.RedirectStandardOutput = true;
                            process.Start();

                            string architecture = process.StandardOutput.ReadToEnd().Trim();

                            process.StandardOutput.Close();
                            process.Close();
                            return architecture;
                    }
	            }
				return "Win";
			}
		}

		private readonly List<BackendStartupParameter> m_sourceInfo = new List<BackendStartupParameter>
		{
 				new BackendStartupParameter(FDOBackendProviderType.kXML, BackendBulkLoadDomain.All,
					new object[] { "TLP.xml" }),
				new BackendStartupParameter(FDOBackendProviderType.kDb4o, BackendBulkLoadDomain.All,
					new object[] { "TLP.db4o" }),
				new BackendStartupParameter(FDOBackendProviderType.kMemoryOnly, BackendBulkLoadDomain.All,
					new object[] { null }),
				new BackendStartupParameter(FDOBackendProviderType.kMercurial, BackendBulkLoadDomain.All,
      				new object[] { "TLPHg.xml", Path.Combine(Path.GetTempPath(), "FieldWorksTest") }),
				new BackendStartupParameter(FDOBackendProviderType.kMySqlClientServer, BackendBulkLoadDomain.All,
					new object[] { "TLP" }),
				new BackendStartupParameter(FDOBackendProviderType.kMySqlClientServerInnoDB, BackendBulkLoadDomain.All,
					new object[] { "TLP"}),
				new BackendStartupParameter(FDOBackendProviderType.kGit, BackendBulkLoadDomain.All,
					new object[] { "TestLangProjGit", GitTests.GitPath }),
				new BackendStartupParameter(FDOBackendProviderType.kXmlFiles, BackendBulkLoadDomain.All,
      				new object[] { "TestLangProjXmlFiles", Path.GetTempPath() }),
				new BackendStartupParameter(FDOBackendProviderType.kDataStore, BackendBulkLoadDomain.All,
				    new object[] { "TestLangProjXmlFilesHg", Path.GetTempPath(),
				        FDOBackendProviderType.kXmlFiles, DvcsType.Mercurial }),
				// TODO-Linux: Berkley-DB .NET wrapper doesn't work on 64-bit Linux
				Architecture == "x86_64" ? null : (new BackendStartupParameter(FDOBackendProviderType.kBerkeleyDB, BackendBulkLoadDomain.All,
					new object[] { "TLP.bdb" }))
      };
		private readonly List<BackendStartupParameter> m_targetInfo = new List<BackendStartupParameter>
		{
				new BackendStartupParameter(FDOBackendProviderType.kXML, BackendBulkLoadDomain.All,
					new object[] { "TLP_New.xml" }),
				new BackendStartupParameter(FDOBackendProviderType.kDb4o, BackendBulkLoadDomain.All,
					new object[] { "TLP_New.db4o" }),
				new BackendStartupParameter(FDOBackendProviderType.kMemoryOnly, BackendBulkLoadDomain.All,
					new object[] { null }),
				new BackendStartupParameter(FDOBackendProviderType.kMercurial, BackendBulkLoadDomain.All,
	      		    new object[] { "TLPHg_New.xml", Path.Combine(Path.GetTempPath(), "FieldWorksTest") }),
				new BackendStartupParameter(FDOBackendProviderType.kMySqlClientServer, BackendBulkLoadDomain.All,
					new object[] { "TLP_New" }),
				new BackendStartupParameter(FDOBackendProviderType.kMySqlClientServerInnoDB, BackendBulkLoadDomain.All,
					new object[] { "TLP_New" }),
				new BackendStartupParameter(FDOBackendProviderType.kGit, BackendBulkLoadDomain.All,
					new object[] { "TestLangProjGit_New", GitTests.GitPath }),
				new BackendStartupParameter(FDOBackendProviderType.kXmlFiles, BackendBulkLoadDomain.All,
	      		    new object[] { "TestLangProjXmlFilesNew", Path.GetTempPath() }),
				new BackendStartupParameter(FDOBackendProviderType.kDataStore, BackendBulkLoadDomain.All,
				    new object[] { "TestLangProjXmlFilesHgNew", Path.GetTempPath(),
				        FDOBackendProviderType.kXmlFiles, DvcsType.Mercurial }),

				// TODO-Linux: Berkley-DB .NET wrapper doesn't work on 64-bit Linux
				Architecture == "x86_64" ? null : (new BackendStartupParameter(FDOBackendProviderType.kBerkeleyDB, BackendBulkLoadDomain.All,
					new object[] { "TLP_New.bdb" }))
      	};

		#region Non-test methods.

		/// <summary>
		/// Actually do the test between the source data in 'sourceGuids'
		/// and the target data in 'targetCache'.
		/// </summary>
		/// <param name="sourceGuids"></param>
		/// <param name="targetCache"></param>
		private static void CompareResults(ICollection<Guid> sourceGuids, FdoCache targetCache)
		{
			var allTargetObjects = GetAllCmObjects(targetCache);
			Assert.AreEqual(sourceGuids.Count, allTargetObjects.Length, "Wrong number of objects in target DB.");
			foreach (var obj in allTargetObjects)
				Assert.IsTrue(sourceGuids.Contains(obj.Guid), "Missing guid in target DB.");
		}

		/// <summary>
		/// Get the ICmObjectRepository from the cache.
		/// </summary>
		/// <param name="cache"></param>
		/// <returns></returns>
		private static ICmObject[] GetAllCmObjects(FdoCache cache)
		{
			return cache.ServiceLocator.GetInstance<ICmObjectRepository>().AllInstances().ToArray();
		}

		/// <summary>
		/// Get the IDataSetup from the cache.
		/// </summary>
		/// <param name="cache"></param>
		/// <returns></returns>
		private static IDataSetup GetMainBEPInterface(FdoCache cache)
		{
			return cache.ServiceLocator.GetInstance<IDataSetup>();
		}

		/// <summary>
		/// Wipe out the current BEP's file(s), since it is about to be created ex-nihilo.
		/// </summary>
		/// <param name="backendParameters"></param>
		private static void DeleteDatabase(BackendStartupParameter backendParameters)
		{
			// MySQL, Mercurial, and XmlFiles have their own mechanisms. MySQL's is 
			// implemented on its strategy.
			if (backendParameters.ProviderType == FDOBackendProviderType.kMySqlClientServer ||
				backendParameters.ProviderType == FDOBackendProviderType.kMySqlClientServerInnoDB ||
				backendParameters.ProviderType == FDOBackendProviderType.kMercurial ||
				backendParameters.ProviderType == FDOBackendProviderType.kXmlFiles || 
				backendParameters.ProviderType == FDOBackendProviderType.kDataStore)
				return;

			if (backendParameters.ProviderType == FDOBackendProviderType.kGit)
			{
				GitTests.DeleteDatabase(Path.Combine((string) backendParameters.StartupOptions[1],
				                                     (string) backendParameters.StartupOptions[0]));
			}

			var pathname = "";
			if (backendParameters.ProviderType != FDOBackendProviderType.kMemoryOnly)
				pathname = (string)backendParameters.StartupOptions[0];
			if (backendParameters.ProviderType != FDOBackendProviderType.kMemoryOnly && File.Exists(pathname))
				File.Delete(pathname);

			if (backendParameters.ProviderType != FDOBackendProviderType.kBerkeleyDB)
				return;

			pathname = pathname.Replace(".bdb", ".idx");
			if (File.Exists(pathname))
				File.Delete(pathname);
		}

		#endregion Non-test methods.

		/// <summary>
		/// Make sure each BEP type migrates to all other BEP types,
		/// including memory only just to be complete.
		/// 
		/// This test uses an already opened BEP for the source,
		/// so it tests the BEP method that accepts the source FdoCache
		/// and creates a new target.
		/// </summary>
		[Test]
		public void PortAllBEPsTestsUsingAnAlreadyOpenedSource()
		{
			var path = Path.Combine(Path.GetTempPath(), "FieldWorksTest");
			if (! Directory.Exists(path))
				Directory.CreateDirectory(path);

			foreach (var sourceBackendStartupParameters in m_sourceInfo)
			{
				if (sourceBackendStartupParameters == null)
					continue;

				DeleteDatabase(sourceBackendStartupParameters);

				// Set up data source, but only do it once.
				var sourceGuids = new List<Guid>();
				using (var sourceCache = FdoCache.CreateCache(sourceBackendStartupParameters.ProviderType))
				{
					var sourceDataSetup = GetMainBEPInterface(sourceCache);
					// The source is created ex nihilo.
					sourceDataSetup.CreateNewLanguageProject(sourceBackendStartupParameters.StartupOptions);
					sourceDataSetup.LoadDomain(sourceBackendStartupParameters.BulkLoadDomain);
					foreach (var obj in GetAllCmObjects(sourceCache))
						sourceGuids.Add(obj.Guid); // Collect up all source Guids.

					foreach (var targetBackendStartupParameters in m_targetInfo)
					{
						if (targetBackendStartupParameters == null)
							continue;

						DeleteDatabase(targetBackendStartupParameters);

						// Migrate source data to new BEP.
						using (var targetCache = FdoCache.CreateCache(targetBackendStartupParameters.ProviderType))
						{
							var targetDataSetup = GetMainBEPInterface(targetCache);
							targetDataSetup.CreateNewLanguageProject(targetBackendStartupParameters.StartupOptions, sourceCache);
							targetDataSetup.LoadDomain(BackendBulkLoadDomain.All);

							CompareResults(sourceGuids, targetCache);
						}
					}
				}
			}
		}

		/// <summary>
		/// Make sure each BEP type migrates to all other BEP types,
		/// including memory only just to be complete.
		/// 
		/// This test uses an un-opened BEP for the source,
		/// so it tests the BEP method that starts up the source and creates the target.
		/// </summary>
		[Test]
		public void PortAllBEPsTestsUsingAnUnopenedSource()
		{
			var path = Path.Combine(Path.GetTempPath(), "FieldWorksTest");
			if (!Directory.Exists(path))
				Directory.CreateDirectory(path);

			foreach (var sourceBackendStartupParameters in m_sourceInfo)
			{
				if (sourceBackendStartupParameters == null)
					continue;

				// The Memory only source BEP can't tested here, since it can't be deleted, created, and restarted
				// which is required of all source BEPs in this test.
				// The source memory BEP is tested in 'PortAllBEPsTestsUsingAnAlreadyOpenedSource',
				// since source BEPs are only created once and the open connection is reused for all targets.
				if (sourceBackendStartupParameters.ProviderType == FDOBackendProviderType.kMemoryOnly)
					continue;

				DeleteDatabase(sourceBackendStartupParameters);
				var createSource = true;
				var sourceGuids = new List<Guid>();
				foreach (var targetBackendStartupParameters in m_targetInfo)
				{
					if (targetBackendStartupParameters == null)
						continue;

					DeleteDatabase(targetBackendStartupParameters);

					// Set up data source, but only do it once.
					using (var sourceCache = FdoCache.CreateCache(sourceBackendStartupParameters.ProviderType))
					{
						var sourceDataSetup = GetMainBEPInterface(sourceCache);
						if (createSource)
						{
							// When 'createSource' is true, the source is created ex-nihilo.
							DeleteDatabase(sourceBackendStartupParameters);
							sourceDataSetup.CreateNewLanguageProject(sourceBackendStartupParameters.StartupOptions);
							createSource = false; // Next time, only load it.
						}
						else
						{
							// When 'createSource' is false, the source is just loaded from its file.
							sourceDataSetup.StartupExtantLanguageProject(sourceBackendStartupParameters.StartupOptions);
						}
						sourceDataSetup.LoadDomain(BackendBulkLoadDomain.All);
						foreach (var obj in GetAllCmObjects(sourceCache))
							sourceGuids.Add(obj.Guid); // Collect up all source Guids.
					}

					// Migrate source data to new BEP.
					using (var targetCache = FdoCache.CreateCache(targetBackendStartupParameters.ProviderType))
					{
						var targetDataSetup = GetMainBEPInterface(targetCache);
						targetDataSetup.CreateNewLanguageProject(targetBackendStartupParameters.StartupOptions,
						                                         sourceBackendStartupParameters);
						targetDataSetup.LoadDomain(BackendBulkLoadDomain.All);
						CompareResults(sourceGuids, targetCache);
					}
					sourceGuids.Clear();
				}
			}
		}
	}
}
