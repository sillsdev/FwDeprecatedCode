// --------------------------------------------------------------------------------------------
// Copyright (C) 2008 SIL International. All rights reserved.
// 
// Distributable under the terms of either the Common Public License or the
// GNU Lesser General Public License, as specified in the LICENSING.txt file.
// 
// File: DB4oCSCustomSerialization.cs
// Responsibility: Randy Regnier
// Last reviewed: never
// --------------------------------------------------------------------------------------------
using System;
using System.Text;
using Db4objects.Db4o.Typehandlers; // ITypeHandlerPredicate
using Db4objects.Db4o.Reflect; // IReflectClass
using Db4objects.Db4o.Internal; // ITypeHandler4 and friends
using Db4objects.Db4o.Marshall; // For IReadContext and IWriteContext.
using Db4objects.Db4o.Internal.Marshall; // UnmarshallingContext
using Db4objects.Db4o.Internal.Handlers; // FirstClassObjectHandler

namespace SIL.FieldWorks.FDO.Infrastructure.Impl
{
	/// <summary>
	/// 
	/// </summary>
	internal class CmObjectSurrogateTypeHandlerPredicateCs : ITypeHandlerPredicate
	{
		/// <summary>
		/// return true if a TypeHandler is to be used for a specific
		/// Type
		/// </summary>
		/// <param name="classReflector">
		/// the Type passed by db4o CS that is to
		/// be tested by this predicate.
		/// </param>
		/// <returns>
		/// true if the TypeHandler is to be used for a specific
		/// Type.
		/// </returns>
		public bool Match(IReflectClass classReflector)
		{
			var claxx = classReflector.Reflector().ForClass(typeof(CmObjectSurrogate));
			return claxx.Equals(classReflector);
		}
	}

	/// <summary>
	/// Maybe use StandardReferenceTypeHandler for superclass, if queries are needed.
	/// </summary>
	internal class CmObjectSurrogateTypeHandlerCs : PlainObjectHandler
	{
		private readonly FdoCache m_cache;
		private readonly IdentityMap m_identitymap;
		private readonly UnicodeEncoding m_unicodeEnc = new UnicodeEncoding();

		/// <summary>
		/// Constructor.
		/// </summary>
		internal CmObjectSurrogateTypeHandlerCs(FdoCache cache, IdentityMap identitymap)
		{
			if (cache == null) throw new ArgumentNullException("cache");
			if (identitymap == null) throw new ArgumentNullException("identitymap");

			m_cache = cache;
			m_identitymap = identitymap;
		}

		// ITypeHandler4 override
		public override void Write(IWriteContext context, object obj)
		{
			var asSurrogate = (ICmObjectSurrogate) obj;
			// Write Guid.
			context.WriteBytes(asSurrogate.Guid.ToByteArray());
			// Write class name.
			var classBytes = m_unicodeEnc.GetBytes(asSurrogate.Classname);
			context.WriteInt(classBytes.Length);
			context.WriteBytes(classBytes);
			// Write the XML data.
			var dataBytes = asSurrogate.XMLBytes;
			context.WriteInt(dataBytes.Length);
			context.WriteBytes(dataBytes);
		}

		// IReferenceTypeHandler override
		public override void Activate(IReferenceActivationContext context)
		{
			var context2 = (UnmarshallingContext)context;
			var buffer = (ByteArrayBuffer)context2.Buffer();

			// Get Guid and CmObjectId.
			var reconId = CmObjectId.Create(new Guid(buffer.ReadBytes(16)));
			// Get class name.
			var className = m_unicodeEnc.GetString(buffer.ReadBytes(buffer.ReadInt()));
			// Get the data.
			var dataLength = buffer.ReadInt();
			// Reconstitute the surrogate.
			((CmObjectSurrogate)context.PersistentObject()).InitializeFromDataStore(
				m_cache,
				reconId,
				className,
				buffer.ReadBytes(dataLength));
		}
	}

	/// <summary>
	/// 
	/// </summary>
	internal class CustomFieldInfoTypeHandlerPredicateCs : ITypeHandlerPredicate
	{
		#region Implementation of ITypeHandlerPredicate

		/// <summary>
		/// return true if a TypeHandler is to be used for a specific
		/// Type
		/// </summary>
		/// <param name="classReflector">
		/// the Type passed by db4o that is to
		/// be tested by this predicate.
		/// </param>
		/// <returns>
		/// true if the TypeHandler is to be used for a specific
		/// Type.
		/// </returns>
		public bool Match(IReflectClass classReflector)
		{
			var claxx = classReflector.Reflector().ForClass(typeof(CustomFieldInfo));
			return claxx.Equals(classReflector);
		}

		#endregion
	}

	/// <summary>
	/// Maybe use StandardReferenceTypeHandler for superclass, if queries are needed.
	/// </summary>
	internal class CustomFieldInfoTypeHandlerCs : PlainObjectHandler
	{

		// ITypeHandler4 override
		public override void Write(IWriteContext context, object obj)
		{
			// Write the data.
			var cfi = (CustomFieldInfo)obj;
			context.WriteInt(cfi.m_flid);
			context.WriteInt((int)cfi.m_fieldType);
			context.WriteInt(cfi.m_destinationClass);
			var cvtr = new UnicodeEncoding();
			var bytes = cvtr.GetBytes(cfi.m_classname);
			context.WriteInt(bytes.Length);
			context.WriteBytes(bytes);
			bytes = cvtr.GetBytes(cfi.m_fieldname);
			context.WriteInt(bytes.Length);
			context.WriteBytes(bytes);
		}

		// IReferenceTypeHandler override
		public override void Activate(IReferenceActivationContext context)
		{
			var context2 = (UnmarshallingContext)context;
			var buffer = (ByteArrayBuffer)context2.Buffer();
			// Get the data.
			var cfi = (CustomFieldInfo)context.PersistentObject();
			cfi.m_flid = buffer.ReadInt();
			cfi.m_fieldType = (FieldType)buffer.ReadInt();
			cfi.m_destinationClass = buffer.ReadInt();
			var cvtr = new UnicodeEncoding();
			var len = buffer.ReadInt();
			cfi.m_classname = cvtr.GetString(buffer.ReadBytes(len));
			len = buffer.ReadInt();
			cfi.m_fieldname = cvtr.GetString(buffer.ReadBytes(len));
		}
	}

	/// <summary>
	/// 
	/// </summary>
	internal class ModelVersionNumberTypeHandlerPredicateCs : ITypeHandlerPredicate
	{
		/// <summary>
		/// return true if a TypeHandler is to be used for a specific
		/// Type
		/// </summary>
		/// <param name="classReflector">
		/// the Type passed by db4o that is to
		/// be tested by this predicate.
		/// </param>
		/// <returns>
		/// true if the TypeHandler is to be used for a specific
		/// Type.
		/// </returns>
		public bool Match(IReflectClass classReflector)
		{
			var claxx = classReflector.Reflector().ForClass(typeof(ModelVersionNumberCs));
			return claxx.Equals(classReflector);
		}
	}

	/// <summary>
	/// Maybe use StandardReferenceTypeHandler for superclass, if queries are needed.
	/// </summary>
	internal class ModelVersionNumberTypeHandlerCs : PlainObjectHandler
	{
		// ITypeHandler4 override
		public override void Write(IWriteContext context, object obj)
		{
			// Write the data.
			context.WriteInt(((ModelVersionNumberCs)obj).m_modelVersionNumber);
		}

		// IReferenceTypeHandler override
		public override void Activate(IReferenceActivationContext context)
		{
			var context2 = (UnmarshallingContext)context;
			var buffer = (ByteArrayBuffer)context2.Buffer();
			// Get the data.
			((ModelVersionNumberCs)context.PersistentObject()).m_modelVersionNumber = buffer.ReadInt();
		}
	}

	/// <summary>
	/// A barebones way to store the model version number in DB4o.
	/// </summary>
	internal class ModelVersionNumberCs
	{
		internal int m_modelVersionNumber;
	}
}