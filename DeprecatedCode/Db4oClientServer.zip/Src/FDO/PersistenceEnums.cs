﻿namespace SIL.FieldWorks.FDO.Infrastructure
{
	/// <summary>
	/// Domain to have bulk loaded by the backend provider
	/// </summary>
	public enum BackendBulkLoadDomain
	{
		/// <summary>WFI and WfiWordforms</summary>
		WFI,
		/// <summary>Lexicon and entries.</summary>
		Lexicon,
		/// <summary>Texts and their paragraphs (no twfics or wordforms)</summary>
		Text,
		/// <summary></summary>
		Scripture,
		/// <summary>Load everything.</summary>
		All,
		/// <summary>Strictly 'on demand' loading</summary>
		None
	}

	/// <summary>
	/// Supported backend data providers.
	/// </summary>
	public enum FDOBackendProviderType
	{
		/// <summary>
		/// An invalid type
		/// </summary>
		kInvalid = 0,

		/// <summary>
		/// An XML file in some currently unspecified format.
		/// </summary>
		/// <remarks>XMLBackendProvider</remarks>
		kXML = 1,

		/// <summary>
		/// A DB4o object database.
		/// </summary>
		/// <remarks>DB4oBackendProvider</remarks>
		kDb4o = 2,

		/// <summary>
		/// A BerkeleyDB database.
		/// </summary>
		/// <remarks>BerkeleyDBBackendProvider</remarks>
		kBerkeleyDB = 3,

		/// <summary>
		/// A mostly 'do nothing' backend.
		/// This backend is used where there is no actual backend data store on the hard drive.
		/// This could be used for tests, for instance, that create all FDO test data themselves.
		/// </summary>
		/// <remarks>MemoryOnlyBackendProvider</remarks>
		kMemoryOnly = 4,

		/// <summary>
		/// An attempt at using a DVCS (Mercurial) as a back end. This uses the XML
		/// back end together with Mercurial.
		/// </summary>
		kMercurial = 5,

		/// <summary>
		/// Attempt at using Git DVCS as a back end. Makes use of Git's ability to store
		/// blobs.
		/// </summary>
		kGit = 6,

		/// <summary>
		/// Multiple XML files
		/// </summary>
		/// <remarks>XMLFilesBackendProvider</remarks>
		kXmlFiles = 7,

		/// <summary>
		/// A client/server MySQL database, with a MyISAM engine.
		/// </summary>
		/// <remarks>MySQLClientServer</remarks>
		kMySqlClientServer = 101,

		/// <summary>
		/// A client/server MySQL database, with an InnoDB engine.
		/// </summary>
		/// <remarks>MySQLClientServer</remarks>
		kMySqlClientServerInnoDB = 102,

		/// <summary>
		/// Any back end above, with or without DVCS
		/// </summary>
		/// <remarks>A back end that can be passed any back end provider above. A DVCS object
		/// can also be passed, or no DVCS object.</remarks>
		kDataStore = 201,

		/// <summary>
		/// A DB4o Client/Server object database.
		/// </summary>
		/// <remarks>DB4oCSBackendProvider</remarks>
		kDb4oCS = 8

	};

	/// <summary>
	/// Enumeration of types or main obejct properties.
	/// </summary>
	internal enum ObjectPropertyType
	{
		Owning,
		Reference
	} ;

	/// <summary>
	/// Enumeration of DVCS types
	/// </summary>
	public enum DvcsType
	{
		/// <summary>
		/// No DVCS is being used
		/// </summary>
		None = 0,

		/// <summary>
		/// Mercurial
		/// </summary>
		Mercurial = 1, //FDOBackendProviderType.kMercurial,

		/// <summary>
		/// Git
		/// </summary>
		Git = 2, //FDOBackendProviderType.kGit
	} ;


}