/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, 2002, SIL International. All rights reserved.

File: M3DeViewConstructors.h
Responsibility: Randy Regnier
Last reviewed: never

These classes provide a suitable view for objects in non-CmPossibilities reference field editor
(e.g., AfDeFeRefs).

Defines:
	View constructors that determines how the reference view appears for the various classes.
	MoMorphoSyntaxAnalysisVc
	MoInflAffixSlotVc
	PhEnvironmentVc
	LexEntryVc
	LexSenseVc
	ReversalIndexEntryVc
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef M3DE_VIEW_CONSTRUCTORS_INCLUDED
#define M3DE_VIEW_CONSTRUCTORS_INCLUDED 1

/*----------------------------------------------------------------------------------------------
	A view constructor that displays a single PhEnvironment in a reference view.
	It may also be used to provide views in list choosers, etc.

  	Depending on fLoadData, the view constructor needs to load anything it uses, since the
	desired information may not be in the cache.

	@h3{Hungarian: evc}
----------------------------------------------------------------------------------------------*/
class PhEnvironmentVc : public ObjVc
{
public:
	typedef ObjVc SuperClass;

	PhEnvironmentVc(bool fLoadData = true);
	virtual ~PhEnvironmentVc();

	STDMETHOD(Display)(IVwEnv * pvwenv, HVO hvo, int frag);
	STDMETHOD(LoadDataFor)(IVwEnv * pvwenv, HVO hvo, int frag);
protected:
	int m_aenc;
	int m_vws;
	StrUni m_stuDisplayName;
};
typedef GenSmartPtr<PhEnvironmentVc> PhEnvironmentVcPtr;

/*----------------------------------------------------------------------------------------------
	A view constructor that displays a single MoMorphoSyntaxInfo (and its subclasses)
	in a reference view. It may also be used to provide views in list choosers, etc.

  	Depending on fLoadData, the view constructor needs to load anything it uses, since the
	desired information may not be in the cache.

	@h3{Hungarian: msavc}
----------------------------------------------------------------------------------------------*/
class MoMorphoSyntaxAnalysisVc : public ObjVc
{
public:
	typedef ObjVc SuperClass;

	MoMorphoSyntaxAnalysisVc(bool fLoadData = true);
	virtual ~MoMorphoSyntaxAnalysisVc();

	STDMETHOD(Display)(IVwEnv * pvwenv, HVO hvo, int frag);
	STDMETHOD(LoadDataFor)(IVwEnv * pvwenv, HVO hvo, int frag);
protected:
	int m_iclid;
	HVO m_hvoForm;
	int m_flidForm;
	HVO m_hvoFormOwner;
	HVO m_hvoSense;
	HVO m_hvoPosA;	// Used for MoStemMsa & MoDerivationalAffixMsa
	HVO m_hvoPosB;	// Used for MoDerivationalAffixMsa
	int m_vws;	// Vernacular writing system.
	int m_aenc;	// Analysis writing system.
};
typedef GenSmartPtr<MoMorphoSyntaxAnalysisVc> MoMorphoSyntaxAnalysisVcPtr;

/*----------------------------------------------------------------------------------------------
	A view constructor that displays a single MoInflAffixSlot in a reference view.
	It may also be used to provide views in list choosers, etc.

  	Depending on fLoadData, the view constructor needs to load anything it uses, since the
	desired information may not be in the cache.

	@h3{Hungarian: iasvc}
----------------------------------------------------------------------------------------------*/
class MoInflAffixSlotVc : public ObjVc
{
public:
	typedef ObjVc SuperClass;

	MoInflAffixSlotVc(bool fLoadData = true);
	virtual ~MoInflAffixSlotVc();

	STDMETHOD(Display)(IVwEnv * pvwenv, HVO hvo, int frag);
	STDMETHOD(LoadDataFor)(IVwEnv * pvwenv, HVO hvo, int frag);
};
typedef GenSmartPtr<MoInflAffixSlotVc> MoInflAffixSlotVcPtr;

/*----------------------------------------------------------------------------------------------
	A view constructor that displays a single ReversalIndexEntry in a reference view.
	It may also be used to provide views in list choosers, etc.

  	Depending on fLoadData, the view constructor needs to load anything it uses, since the
	desired information may not be in the cache.

	@h3{Hungarian: rievc}
----------------------------------------------------------------------------------------------*/
class ReversalIndexEntryVc : public ObjVc
{
public:
	typedef ObjVc SuperClass;

	ReversalIndexEntryVc(bool fLoadData = true);
	virtual ~ReversalIndexEntryVc();

	STDMETHOD(Display)(IVwEnv * pvwenv, HVO hvo, int frag);
	STDMETHOD(LoadDataFor)(IVwEnv * pvwenv, HVO hvo, int frag);
};
typedef GenSmartPtr<ReversalIndexEntryVc> ReversalIndexEntryVcPtr;

/*----------------------------------------------------------------------------------------------
	A view constructor that displays a single LexSense in a reference view.
	It may also be used to provide views in list choosers, etc.

  	Depending on fLoadData, the view constructor needs to load anything it uses, since the
	desired information may not be in the cache.

	@h3{Hungarian: lsvc}
----------------------------------------------------------------------------------------------*/
class LexSenseVc : public ObjVc
{
public:
	typedef ObjVc SuperClass;

	LexSenseVc(bool fLoadData = true);
	virtual ~LexSenseVc();

	STDMETHOD(Display)(IVwEnv * pvwenv, HVO hvo, int frag);
	STDMETHOD(LoadDataFor)(IVwEnv * pvwenv, HVO hvo, int frag);
protected:
	int m_aenc;	// Analysis writing system.
};
typedef GenSmartPtr<LexSenseVc> LexSenseVcPtr;

/*----------------------------------------------------------------------------------------------
	A view constructor that displays a single LexEntry in a reference view.
	It may also be used to provide views in list choosers, etc.

  	Depending on fLoadData, the view constructor needs to load anything it uses, since the
	desired information may not be in the cache.

	@h3{Hungarian: levc}
----------------------------------------------------------------------------------------------*/
class LexEntryVc : public ObjVc
{
public:
	typedef ObjVc SuperClass;

	LexEntryVc(bool fLoadData = true);
	virtual ~LexEntryVc();

	STDMETHOD(Display)(IVwEnv * pvwenv, HVO hvo, int frag);
	STDMETHOD(LoadDataFor)(IVwEnv * pvwenv, HVO hvo, int frag);
protected:

	typedef enum {
		kledtNoForm = 0,
		kledtCitationForm = 1,
		kledtUnderlyingForm = 2,
		kledtAllomorph = 3
		} LEDataType;    // Hungarian ledt

	LEDataType m_ledtType;
	int m_vws;	// Vernacular writing system.
	HVO m_hvoMoForm;
	int m_aenc;	// Analysis writing system.
	HVO m_hvoLexSense;
	int m_iHomographNumber;
};
typedef GenSmartPtr<LexEntryVc> LexEntryVcPtr;

HRESULT CacheBasics(CustViewDa * pcvd, HVO hvo);
HRESULT CacheMstr(CustViewDa * pcvd, HVO hvo, StrUni stu, int ws);

#endif // M3DE_VIEW_CONSTRUCTORS_INCLUDED
