/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2000, SIL International. All rights reserved.

File: GenObjChsrDlg.h
Responsibility: Randy Regnier
Last reviewed: never

These classes provide a suitable chooser for objects in non-CmPossibilities reference
field editor (e.g., AfDeFeRefs).

Defines:
	GenObjChsrDlg
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef GENOBJCHSRDLG_INCLUDED
#define GENOBJCHSRDLG_INCLUDED 1

struct HvoVector;
typedef Vector<HvoVector> HvoVecVec; // Hungarian vhv.
struct HvoVector // Hungarian: hv.
{
	HVO hvo;
	StrUni stuName;
	HvoVecVec vhvChildren;
};

/*----------------------------------------------------------------------------------------------
	This class provides the functionality of the General Object Chooser Dialog.

	@h3{Hungarian: goc}
----------------------------------------------------------------------------------------------*/
class GenObjChsrDlg : public AfDialog
{
public:
	typedef AfDialog SuperClass;

	GenObjChsrDlg();
	virtual ~GenObjChsrDlg();
	void SetDialogValues(HvoVecVec * pvhvCandidates,
		HvoVecVec * pvhvUsed, int iws, bool fAtomic, bool fSequence);
	void GetDialogValues(Vector<HVO> & vhvo)
	{
		vhvo.Clear();
		for (int i = 0; i < m_vhvUsed.Size(); ++i)
			vhvo.Push((m_vhvUsed[i]).hvo);
	}

protected:
	bool AddItems();
	void OnDragBegin(LPNMTREEVIEW lpnmtv);
	void OnDrag(long xCur, long yCur);
	void OnDragEnd()
	{
		if (m_fdragging)
		{
			ImageList_EndDrag();
			ReleaseCapture();
			ShowCursor(true);
			m_fdragging = false;
		}
    return;
	}
	void OnMoveBtn(int ctidBtn);
	void OnDupBtn(int ctidBtn);
	void SetMoveBtnStatus();

	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);
	virtual bool OnInitDlg(HWND hwndCtrl, LPARAM lp);
	virtual bool OnGetDispInfo(NMTVDISPINFO * pntdi);
	virtual bool OnNotifyChild(int id, NMHDR * pnmh, long & lnRet);
	virtual bool OnSize(int wst, int dxp, int dyp);
	virtual bool OnSizing(int wse, RECT * prc);
	virtual bool OnClick(NMHDR * pnmh);
	virtual bool OnDblClick(NMHDR * pnmh);
	virtual bool OnApply(bool fClose);
	virtual bool OnCancel();

	HWND m_rghwndTypeAhead;
	HWND m_rghwndList;
	HWND m_rghwndTree;
	HWND m_hwndGrip;

	bool m_fdragging;
	/*------------------------------------------------------------------------------------------
		The source ids.
	------------------------------------------------------------------------------------------*/
	HvoVecVec m_vhvCandidates;
	/*------------------------------------------------------------------------------------------
		The target ids.
	------------------------------------------------------------------------------------------*/
	HvoVecVec m_vhvUsed;
	/*------------------------------------------------------------------------------------------
		The writing system used to display items.
	------------------------------------------------------------------------------------------*/
	int m_ws;
	/*------------------------------------------------------------------------------------------
		Determines if multiple items are to be returned.
	------------------------------------------------------------------------------------------*/
	bool m_fAtomic;
	/*------------------------------------------------------------------------------------------
		Determines if the reference is a sequence or a collection.
	------------------------------------------------------------------------------------------*/
	bool m_fSequence;
	/*------------------------------------------------------------------------------------------
		The underlying form.
	------------------------------------------------------------------------------------------*/
	// StrAnsi m_staHelp;

	int m_dypTypeAhead;
	int m_dypList;
	int m_dypTree;
	int m_ypOk;
	int m_dxpOk;
	int m_dxpUp;
	int m_dxpButtonSep;
	int m_dxpHelp;
	int m_dypHelp;
	int m_dxpMin;
	int m_dypMin;
};
typedef GenSmartPtr<GenObjChsrDlg> GenObjChsrDlgPtr;

/*----------------------------------------------------------------------------------------------
	This class paints the tree without flicker.
	Hungarian: goct
----------------------------------------------------------------------------------------------*/
class GenObjChsrTree : public AfWnd
{
typedef AfWnd SuperClass;

protected:
	virtual bool FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet);
	virtual bool OnPaint(HDC hdcDef);
};
typedef GenSmartPtr<GenObjChsrTree> GenObjChsrTreePtr;

#endif // GENOBJCHSRDLG_INCLUDED
