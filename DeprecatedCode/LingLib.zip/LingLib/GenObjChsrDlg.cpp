/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2000, SIL International. All rights reserved.

File: GenObjChsrDlg.cpp
Responsibility: Ken Zook
Last reviewed: never

Description:
	This implements the classes used to support a general object chooser dialog.
-------------------------------------------------------------------------------*//*:End Ignore*/
#include "Main.h"
#include "Vector_i.cpp"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE


//:>********************************************************************************************
//:> GenObjChsrDlg methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
----------------------------------------------------------------------------------------------*/
GenObjChsrDlg::GenObjChsrDlg()
{
	m_rid = kridGenObjChsrDlg;
	m_fAtomic = true;
	m_fSequence = false;
	m_ypOk = m_dxpOk = m_dypTree = m_dypList = 0;
	m_dxpButtonSep = 0;
	m_dxpHelp = m_dypHelp = 0;
	m_dxpMin = 0;
	m_dypMin = 0;
	m_fdragging = false;
}

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
GenObjChsrDlg::~GenObjChsrDlg()
{ /* Let superclass handle it. */ }

/*----------------------------------------------------------------------------------------------
	Initializes a GenObjChsrDlg.

	@param pvhdnCandidates Pointer to a vector of possible targets for the ref property.
	@param pvhdnUsed Pointer to a vector of extant targets for the ref property.
	@param iws The writing system to use for display names.
	@param fAtomic Flag to tell if multiple references are supported.
	@param fSequence Flag to tell if property is a sequence (true) or a collection (false).
----------------------------------------------------------------------------------------------*/
void GenObjChsrDlg::SetDialogValues(HvoVecVec * pvhvCandidates,
			HvoVecVec * pvhvUsed, int iws, bool fAtomic, bool fSequence)
{
	Assert(pvhvCandidates);
	Assert(pvhvUsed);
	Assert(iws);

	m_vhvCandidates = *pvhvCandidates;
	m_vhvUsed = *pvhvUsed;
	m_ws = iws;
	m_fAtomic = fAtomic;
	m_fSequence = m_fAtomic ? false : fSequence;
}

/*----------------------------------------------------------------------------------------------
	Add all the items in the list to the tree control.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::AddItems()
{
	WaitCursor wc;

	// Add each item to the tree.
	HTREEITEM hti;
	TVINSERTSTRUCT tvis = { TVI_ROOT, TVI_LAST };
	tvis.item.mask = TVIF_PARAM | TVIF_TEXT;
	tvis.item.pszText = LPSTR_TEXTCALLBACK;
	tvis.item.cChildren = 0;
	tvis.hParent = TVI_ROOT;

	TVINSERTSTRUCT tvisSel = { TVI_ROOT, TVI_LAST };
	tvisSel.item.mask = TVIF_PARAM | TVIF_TEXT;
	tvisSel.item.pszText = LPSTR_TEXTCALLBACK;
	tvisSel.item.cChildren = 0;
	tvisSel.hParent = TVI_ROOT;

	::SendMessage(m_rghwndTree, WM_SETREDRAW, false, 0);
	::SendMessage(m_rghwndList, WM_SETREDRAW, false, 0);

	Vector<HTREEITEM> vhtiSel;
	HvoVecVec vhvUsedT = m_vhvUsed;
	int cpssCand = m_vhvCandidates.Size();	// Size of possible reference targets.
	int cpssUsed = vhvUsedT.Size();	// Size of currently selected items.
	HvoVector hvC;
	HvoVector hvU;
	if (cpssCand)
	{
		// Turn scrollbars back on for the tree view.
		DWORD dwT = ::GetWindowLong(m_rghwndTree, GWL_STYLE);
		::SetWindowLong(m_rghwndTree, GWL_STYLE, dwT & ~TVS_NOSCROLL);
		// Turn scrollbars back on for the list.
		dwT = ::GetWindowLong(m_rghwndList, GWL_STYLE);
		::SetWindowLong(m_rghwndList, GWL_STYLE, dwT & ~LVS_NOSCROLL);
		// Add the items to the tree.
		for (int ipii = 0; ipii < cpssCand; ipii++)
		{
			hvC = m_vhvCandidates[ipii];

			// Add the item.
			tvis.item.lParam = hvC.hvo;
			hti = TreeView_InsertItem(m_rghwndTree, &tvis);

			// See if this item should be checked.
			for (int ipss = 0; ipss < cpssUsed; ipss++)
			{
				hvU = vhvUsedT[ipss];
				if (hvU.hvo == hvC.hvo)
				{
					// Keep track of this item for later.
					vhtiSel.Push(hti);
					break;
				}
			}
		}
	}

	for (int ipii = 0; ipii < cpssUsed; ipii++)
	{
		hvU = vhvUsedT[ipii];
		tvisSel.item.lParam = hvU.hvo;
		TreeView_InsertItem(m_rghwndList, &tvisSel);
	}

	int csel = vhtiSel.Size();
	Assert(!m_fAtomic || (uint)csel <= 1);
	if (!m_fAtomic)
	{
		// Set the checkbox for all the initial selected items.
		TVITEM tvi = { TVIF_HANDLE | TVIF_STATE };
		tvi.stateMask = TVIS_STATEIMAGEMASK;
		tvi.state = INDEXTOSTATEIMAGEMASK(2);
		for (int isel = csel; --isel >= 0; )
		{
			// Expand necessary items to make this item visible.
			TreeView_EnsureVisible(m_rghwndTree, vhtiSel[isel]);
			tvi.hItem = vhtiSel[isel];
			TreeView_SetItem(m_rghwndTree, &tvi);
		}
	}

	::SendMessage(m_rghwndTree, WM_SETREDRAW, true, 0);
	::SendMessage(m_rghwndList, WM_SETREDRAW, true, 0);

	// Select the first checked item or the top item in the tree if there aren't any
	// items that are checked.
	// NOTE: This has to be done after the treeview has been redrawn; otherwise it doesn't
	// always work correctly.
	HTREEITEM htiSel = csel ? vhtiSel[0] : TreeView_GetRoot(m_rghwndTree);
	TreeView_SelectItem(m_rghwndTree, htiSel);
	TreeView_EnsureVisible(m_rghwndTree, htiSel);

	return true;
}

/*----------------------------------------------------------------------------------------------
    Called by the framework to initialize the dialog. All one-time initialization should be
    done here (that is, all controls have been created and have valid hwnd's, but they
    need initial values.)
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::OnInitDlg(HWND hwndCtrl, LPARAM lp)
{
	if (m_vhvCandidates.Size() > 100)
		WaitCursor wc;
	// Subclass the Help button.
	AfButtonPtr qbtn;
	qbtn.Create();
	qbtn->SubclassButton(m_hwnd, kctidHelp, kbtHelp, NULL, 0);

	// Create the gripper control.
	m_hwndGrip = ::CreateWindow(_T("SCROLLBAR"), NULL, WS_CHILD | WS_VISIBLE | SBS_SIZEGRIP |
		SBS_SIZEBOX | SBS_SIZEBOXBOTTOMRIGHTALIGN, 0, 0, 0, 0,
		m_hwnd, NULL, NULL, NULL);

	// Cache the type ahead window.
	m_rghwndTypeAhead = ::GetDlgItem(m_hwnd, kctidTypeAhead);

	// Create the choices tree.
	Rect rcCTOld;
	HWND hwndTemp = ::GetDlgItem(m_hwnd, kctidItemTree);
	::GetWindowRect(hwndTemp, &rcCTOld);
	::MapWindowPoints(NULL, m_hwnd, (POINT *)&rcCTOld, 2);
	WndCreateStruct wcs;
	wcs.InitChild(WC_TREEVIEW, m_hwnd, kctidItemTree);
	wcs.SetRect(rcCTOld);
	wcs.style = ::GetWindowLong(hwndTemp, GWL_STYLE) | WS_VISIBLE | TVS_NOSCROLL;
	wcs.dwExStyle = ::GetWindowLong(hwndTemp, GWL_EXSTYLE);
	HWND hwndPrev = ::GetNextWindow(hwndTemp, GW_HWNDPREV);
	::DestroyWindow(hwndTemp);
	if (!m_fAtomic)
		wcs.style |= TVS_CHECKBOXES;
	GenObjChsrTreePtr qgoct;
	qgoct.Create();
	qgoct->CreateAndSubclassHwnd(wcs);
	m_rghwndTree = qgoct->Hwnd();
	::SetWindowPos(qgoct->Hwnd(), hwndPrev, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);

	// Create the selected tree.
	Rect rcSTOld;
	hwndTemp = ::GetDlgItem(m_hwnd, kctidSelectedTree);
	::GetWindowRect(hwndTemp, &rcSTOld);
	::MapWindowPoints(NULL, m_hwnd, (POINT *)&rcSTOld, 2);
	WndCreateStruct wcsSelT;
	wcsSelT.InitChild(WC_TREEVIEW, m_hwnd, kctidSelectedTree);
	wcsSelT.SetRect(rcSTOld);
	wcsSelT.style = ::GetWindowLong(hwndTemp, GWL_STYLE) | WS_VISIBLE | TVS_NOSCROLL;
	wcsSelT.dwExStyle = ::GetWindowLong(hwndTemp, GWL_EXSTYLE);
	hwndPrev = ::GetNextWindow(hwndTemp, GW_HWNDPREV);
	::DestroyWindow(hwndTemp);
	GenObjChsrTreePtr qgoctSel;
	qgoctSel.Create();
	qgoctSel->CreateAndSubclassHwnd(wcsSelT);
	m_rghwndList = qgoctSel->Hwnd();
	::SetWindowPos(qgoctSel->Hwnd(), hwndPrev, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);

	::ShowWindow(m_hwnd, SW_SHOW);
	::UpdateWindow(m_hwnd);

	Rect rcClient;
	GetClientRect(rcClient);
	Rect rcWindow(rcClient);
	::MapWindowPoints(m_hwnd, NULL, (POINT *)&rcWindow, 2);
	// Find the dimensions of the controls.
	Rect rcT;
	::GetWindowRect(::GetDlgItem(m_hwnd, kctidHelp), &rcT);
	m_ypOk = rcWindow.bottom - rcT.top;
	m_dypHelp = rcWindow.bottom - rcT.bottom;
	int xpLeft = rcT.left;
	::GetWindowRect(::GetDlgItem(m_hwnd, kctidCancel), &rcT);
	m_dxpButtonSep = xpLeft - rcT.right;
	m_dxpOk = rcT.Width();
	::GetWindowRect(::GetDlgItem(m_hwnd, kcidUp), &rcT);
	m_dxpUp = rcT.Width();
	::GetWindowRect(::GetDlgItem(m_hwnd, kctidToggleHelp), &rcT);
	//m_dxpMin = m_dxpUp * 2 + rcT.Width() + m_dxpButtonSep * 4;
	m_dxpMin = m_dxpUp * 3 + rcT.Width() + m_dxpButtonSep * 5;

	::GetWindowRect(m_rghwndTree, &rcT);	// Candidates tree control.
	m_dypTree = rcT.Height();
	::GetWindowRect(m_rghwndList, &rcT);	// Selected tree control.
	m_dypList = rcT.Height();

	// Add the items to the tree control.
	if (!AddItems())
		return false;

	GetClientRect(rcClient);
	m_dypMin = rcClient.Height() - (m_dypList / 2);
	OnSize(kwstRestored, rcClient.Width(), rcClient.Height());

	// Handle enable/disable btns and tree.
	if (m_fAtomic || !m_fSequence)
		::EnableWindow(m_rghwndList, false);
	::EnableWindow(m_rghwndTypeAhead, false);
	SetMoveBtnStatus();

	AfApp::Papp()->EnableMainWindows(false);
	return true;
}

/*----------------------------------------------------------------------------------------------
	Process notifications from user.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::OnNotifyChild(int ctidFrom, NMHDR * pnmh, long & lnRet)
{
	AssertPtr(pnmh);

	if (SuperClass::OnNotifyChild(ctidFrom, pnmh, lnRet))
		return true;

	switch (pnmh->code)
	{
	case TVN_GETDISPINFO:
		return OnGetDispInfo((NMTVDISPINFO *)pnmh);
	case NM_CLICK:
		return OnClick(pnmh);
	case NM_DBLCLK:
		return OnDblClick(pnmh);
/*
	case TVN_BEGINDRAG:
		if (ctidFrom == kctidSelectedTree)
		{
			OnDragBegin((LPNMTREEVIEW)pnmh);
			return true;
		}
		break;
*/
	case TVN_SELCHANGED:
		if (ctidFrom == kctidSelectedTree)
		{
			SetMoveBtnStatus();
			return true;
		}
		break;
	case BN_CLICKED:
		switch (ctidFrom)
		{
		case kcidDup:
			//OnDupBtn(ctidFrom);
			//return true;
		case kcidUp:
		case kcidDwn:
			OnMoveBtn(ctidFrom);
			return true;
		}
		break;
	default:
		break;
	}

	return false;
}

void GenObjChsrDlg::OnDupBtn(int ctidBtn)
{
	/*
	HTREEITEM hti = TreeView_GetSelection(m_rghwndList);
	Assert(hti);
	TVITEM tvi;
	tvi.hItem = hti;
	tvi.mask = TVIF_TEXT | TVIF_PARAM;
	tvi.pszText = pszText;
	tvi.cchTextMax = 1000;
	TVINSERTSTRUCT tvins;
	tvins.item = tvi;
	tvins.hParent = TVI_ROOT;*/
}

void GenObjChsrDlg::OnMoveBtn(int ctidBtn)
{
	Assert((ctidBtn == kcidUp)
		|| (ctidBtn == kcidDwn)
		|| (ctidBtn == kcidDup));

	achar * pszText = NewObj achar[1000];
	HTREEITEM htiSib;
	HTREEITEM hti = TreeView_GetSelection(m_rghwndList);
	Assert(hti);
	TVITEM tvi;
	tvi.hItem = hti;
	tvi.mask = TVIF_TEXT | TVIF_PARAM;
	tvi.pszText = pszText;
	tvi.cchTextMax = 1000;
	TreeView_GetItem(m_rghwndList, &tvi);
	TVINSERTSTRUCT tvins;
	tvins.item = tvi;
	tvins.hParent = TVI_ROOT;

	switch (ctidBtn)
	{
	case kcidUp:
		{
			HTREEITEM htiSib2;
			htiSib = TreeView_GetPrevSibling(m_rghwndList, hti);
			htiSib2 = TreeView_GetPrevSibling(m_rghwndList, htiSib);
			if (htiSib2)
				tvins.hInsertAfter = htiSib2;
			else
				tvins.hInsertAfter = TVI_FIRST;
			break;
		}
	case kcidDwn:
		{
			htiSib = TreeView_GetNextSibling(m_rghwndList, hti);
			tvins.hInsertAfter = htiSib;
			break;
		}
	case kcidDup:
		{
			tvins.hInsertAfter = hti;
			break;
		}
	default:
		Assert(false);
		break;
	}

	HTREEITEM htiNewSel = TreeView_InsertItem(m_rghwndList, &tvins);
	Assert(htiNewSel);
	TreeView_Select(m_rghwndList, htiNewSel, TVGN_CARET);
	if (ctidBtn != kcidDup)
		TreeView_DeleteItem(m_rghwndList, hti);
	delete pszText;
}

void GenObjChsrDlg::SetMoveBtnStatus()
{
	// Enable/disable Move... btns.
	if (m_fAtomic || !m_fSequence)
	{
		// Atomic or unordered collection, so disable.
		::EnableWindow(::GetDlgItem(m_hwnd, kcidUp), false);
		::EnableWindow(::GetDlgItem(m_hwnd, kcidDwn), false);
		::EnableWindow(::GetDlgItem(m_hwnd, kcidDup), false);
		return;
	}
	bool fEnabled = (TreeView_GetCount(m_rghwndList) > 1);
	// Enable, if more two or more items.
	::EnableWindow(::GetDlgItem(m_hwnd, kcidUp), fEnabled);
	::EnableWindow(::GetDlgItem(m_hwnd, kcidDwn), fEnabled);
	::EnableWindow(::GetDlgItem(m_hwnd, kcidDup), (TreeView_GetCount(m_rghwndList) > 0));
	if (!fEnabled)
		return;	// Quit, if fewer than two items.

	// Check selection positions.
	HTREEITEM hti = TreeView_GetSelection(m_rghwndList);
	if (!hti)
	{
		// None selected, so disable both.
		::EnableWindow(::GetDlgItem(m_hwnd, kcidUp), false);
		::EnableWindow(::GetDlgItem(m_hwnd, kcidDwn), false);
		::EnableWindow(::GetDlgItem(m_hwnd, kcidDup), false);
		return;
	}
	HTREEITEM htiSib = TreeView_GetPrevSibling(m_rghwndList, hti);
	::EnableWindow(::GetDlgItem(m_hwnd, kcidUp), (htiSib != NULL));
	htiSib = TreeView_GetNextSibling(m_rghwndList, hti);
	::EnableWindow(::GetDlgItem(m_hwnd, kcidDwn), (htiSib != NULL));
}

void GenObjChsrDlg::OnDragBegin(LPNMTREEVIEW lpnmtv)
{
    HIMAGELIST himl;    // handle to image list 
    RECT rcItem;        // bounding rectangle of item 
    //DWORD dwLevel;      // heading level of item 
    //DWORD dwIndent;     // amount that child items are indented 
 
    // Tell the tree-view control to create an image to use 
    // for dragging. 
    himl = TreeView_CreateDragImage(m_rghwndList, lpnmtv->itemNew.hItem); 
 
    // Get the bounding rectangle of the item being dragged. 
    TreeView_GetItemRect(m_rghwndList, lpnmtv->itemNew.hItem, &rcItem, true);
 
    // Get the heading level and the amount that the child items are 
    // indented. 
    //dwLevel = lpnmtv->itemNew.lParam; 
    //dwIndent = (DWORD) SendMessage(m_rghwndList, TVM_GETINDENT, 0, 0); 
 
    // Start the drag operation. 
    ImageList_BeginDrag(himl, 0, 0, 0); 
 
    // Hide the mouse pointer, and direct mouse input to the 
    // parent window. 
    ShowCursor(false); 
    SetCapture(GetParent(m_rghwndList)); 
    m_fdragging = true; 
    return; 
}

void GenObjChsrDlg::OnDrag(long xCur, long yCur)
{
	HTREEITEM htiTarget;  // handle to target item 
	TVHITTESTINFO tvht;  // hit test information 

	if (m_fdragging)
	{
        // Drag the item to the current position of the mouse pointer.
		ImageList_DragMove(xCur, yCur);
         // Find out if the pointer is on the item. If it is,
		// highlight the item as a drop target.
		tvht.pt.x = xCur;
		tvht.pt.y = yCur;
		if ((htiTarget = TreeView_HitTest(m_rghwndList, &tvht)) != NULL)
			TreeView_SelectDropTarget(m_rghwndList, htiTarget);
	}
	return;
}

/*----------------------------------------------------------------------------------------------
	If the user clicked on the state box, toggle the state (default action) and also select
	the item.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::OnClick(NMHDR * pnmh)
{
	AssertPtr(pnmh);

	if (pnmh->idFrom != kctidItemTree)
		return false;	// Let someone else handle it.

	HWND hwndFrom = pnmh->hwndFrom;

	TVHITTESTINFO tvhti;
	::GetCursorPos(&tvhti.pt);
	::ScreenToClient(hwndFrom, &tvhti.pt);

	if (TreeView_HitTest(hwndFrom, &tvhti))
	{
		if (tvhti.flags & TVHT_ONITEMSTATEICON)
		{
			// Has check box.
			Assert(tvhti.hItem);
			HVO hvo;
			achar szBuffer[1000];
			ZeroMemory(&szBuffer, sizeof(achar) * 1000);
			TreeView_SelectItem(hwndFrom, tvhti.hItem);

			TVITEM tvi = { TVIF_TEXT | TVIF_STATE | TVIF_PARAM, tvhti.hItem };
			tvi.stateMask = TVIS_STATEIMAGEMASK;
			tvi.pszText = szBuffer;
			tvi.cchTextMax = 1000;
			TreeView_GetItem(hwndFrom, &tvi);
			bool fChecked = (tvi.state >> 12) - 1;	// [NB: This is the old state.]
			hvo = tvi.lParam;

			if (fChecked)
			{
				// Remove it from the 'selected' tree, since it will soon be unchecked.
				TVITEM tviSel = { TVIF_PARAM | TVIF_HANDLE };
				tviSel.lParam;
				HTREEITEM hti = TreeView_GetRoot(m_rghwndList);
				int chti = TreeView_GetCount(m_rghwndList);
				for (int ihti = 0; ihti < chti; ihti++)
				{
					tviSel.hItem = hti;
					if (!TreeView_GetItem(m_rghwndList, &tviSel))
					{
						Assert(false);
						return false;
					}
					if (tviSel.lParam == hvo)
					{
						HTREEITEM htiNext = TreeView_GetNextSibling(m_rghwndList, hti);
						TreeView_DeleteItem(m_rghwndList, hti);
						hti = htiNext;
					}
					else
						hti = TreeView_GetNextSibling(m_rghwndList, hti);
				}
			}
			else
			{
				// Add it to the 'selected' tree, since it will soon be checked.
				TVINSERTSTRUCT tvis;
				tvis.hParent = TVI_ROOT;
				tvis.hInsertAfter = TVI_LAST;
				tvis.item.mask = TVIF_PARAM | TVIF_TEXT;
				tvis.item.lParam = hvo;
				tvis.item.pszText = szBuffer;
				tvis.item.cChildren = 0;
				TreeView_InsertItem(m_rghwndList, &tvis);
			}
			return true;
		}
	}

	return false;
}

/*----------------------------------------------------------------------------------------------
	If the user double clicks on an item in the atomic dialog, then we need to return the
	single item and close the dialog.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::OnDblClick(NMHDR * pnmh)
{
	//if (!m_fAtomic)
	//	return true;
	if (!m_fAtomic || pnmh->idFrom != kctidItemTree)
		return false;	// Let someone else handle it.

	return OnApply(true);
}

/*----------------------------------------------------------------------------------------------
	Show the appropriate text for an item based on the view of item selection.
	This gets called every time an item needs to be drawn in a tree.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::OnGetDispInfo(NMTVDISPINFO * pntdi)
{
	AssertPtr(pntdi);
	Assert(pntdi->item.mask == TVIF_TEXT);

	int cCount;
	HvoVecVec vhv;
	HvoVector hv;
	StrUni stu;
	StrApp str;
	switch (pntdi->hdr.idFrom)
	{
	case kctidItemTree:
		{
			vhv = m_vhvCandidates;
			break;
		}
	case kctidSelectedTree:
		{
			vhv = m_vhvUsed;
			break;
		}
	default:
		{
			Assert(false);
			return false;
		}
	}
	cCount = vhv.Size();
	for (int i = 0; i < cCount; ++i)
	{
		hv = vhv[i];
		if (pntdi->item.lParam == hv.hvo)
		{
			str = hv.stuName;
			lstrcpy(pntdi->item.pszText, str.Chars());
			break;
		}
	}
	return true;
}

/*----------------------------------------------------------------------------------------------
	Resize/move all the controls on the dialog.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::OnSize(int wst, int dxp, int dyp)
{
	// REVIEW DarrellZ: This might need to become non-static if it causes conflicts in
	// dialogs for different possibility lists.
	//static int s_dxpOldLeft = dxp - m_dxpHelp;
	static int s_dxpOldLeft = dxp;

	Rect rc;
	uint grfnMove = SWP_NOZORDER | SWP_NOSIZE;
	uint grfnSize = SWP_NOZORDER | SWP_NOMOVE;
	int dxpLeft = dxp;
	int xOffset;
	int yOffset;
/*
	if (m_fShowHelp)
	{
		m_dxpHelp = dxp - s_dxpOldLeft;
		dxpLeft -= m_dxpHelp;
	}
	else
	{
		s_dxpOldLeft = dxp;
	}
*/

	// Get the client size (in screen coordinates).
	Rect rcClient;
	GetClientRect(rcClient);
	::MapWindowPoints(m_hwnd, NULL, (POINT *)&rcClient, 2);


	// Resize the type ahead control.
	::GetWindowRect(m_rghwndTypeAhead, &rc);
	int dzpGap = rc.left - rcClient.left;
	xOffset = dzpGap;
	yOffset = dzpGap;
	::SetWindowPos(m_rghwndTypeAhead, NULL,
		xOffset, yOffset,
		dxpLeft - (dzpGap * 2), rc.Height(),
			SWP_NOZORDER);

	// Resize the 'candidate' tree control.
	::GetWindowRect(m_rghwndTypeAhead, &rc);
	int dypTree = dyp - m_dypTree;
	yOffset = rc.bottom + dzpGap;
	::SetWindowPos(m_rghwndTree, NULL,
		dzpGap, yOffset,
		dxpLeft - (dzpGap * 2), dypTree,
		grfnSize);

	// Resize the 'selected' tree control.
	::GetWindowRect(m_rghwndTree, &rc);
	yOffset = (rc.top - rcClient.top) + dypTree + dzpGap;
	::SetWindowPos(m_rghwndList, NULL,
		xOffset, yOffset,
		dxpLeft - (dzpGap * 2), m_dypList,
		SWP_NOZORDER);

	// Move the buttons.
	xOffset = dxpLeft - m_dxpOk - dzpGap;
	yOffset = dyp - m_ypOk;
	::SetWindowPos(::GetDlgItem(m_hwnd, kctidHelp), NULL, 
		xOffset, yOffset, 0, 0, grfnMove);
	::InvalidateRect(::GetDlgItem(m_hwnd, kctidHelp), NULL, true);

	xOffset = dxpLeft - dzpGap - (m_dxpOk * 2) - m_dxpButtonSep;
	::SetWindowPos(::GetDlgItem(m_hwnd, kctidCancel), NULL,
		xOffset, yOffset, 0, 0, grfnMove);
	::InvalidateRect(::GetDlgItem(m_hwnd, kctidCancel), NULL, true);

	xOffset = dxpLeft - dzpGap - (m_dxpOk * 3) - (m_dxpButtonSep * 2);
	::SetWindowPos(::GetDlgItem(m_hwnd, kctidOk), NULL,
		xOffset, yOffset, 0, 0, grfnMove);
	::InvalidateRect(::GetDlgItem(m_hwnd, kctidOk), NULL, true);

	::GetWindowRect(::GetDlgItem(m_hwnd, kctidToggleHelp), &rc);
	xOffset = dxpLeft - dzpGap - rc.Width();
	yOffset = dyp - m_ypOk - (dzpGap * 2) - rc.Height();
	::SetWindowPos(::GetDlgItem(m_hwnd, kctidToggleHelp), NULL,
		xOffset, yOffset, 0, 0, grfnMove);
	::InvalidateRect(::GetDlgItem(m_hwnd, kctidToggleHelp), NULL, true);

	Rect rcTH;
	::GetWindowRect(::GetDlgItem(m_hwnd, kctidToggleHelp), &rcTH);
	::GetWindowRect(::GetDlgItem(m_hwnd, kcidDup), &rc);
	xOffset = dxpLeft - dzpGap - rc.Width() - rcTH.Width() - m_dxpButtonSep;
	::SetWindowPos(::GetDlgItem(m_hwnd, kcidDup), NULL,
		xOffset, yOffset, 0, 0, grfnMove);
	::InvalidateRect(::GetDlgItem(m_hwnd, kcidDup), NULL, true);

	::GetWindowRect(::GetDlgItem(m_hwnd, kcidDwn), &rc);
	xOffset -=  m_dxpButtonSep + rc.Width();
	::SetWindowPos(::GetDlgItem(m_hwnd, kcidDwn), NULL,
		xOffset, yOffset, 0, 0, grfnMove);
	::InvalidateRect(::GetDlgItem(m_hwnd, kcidDwn), NULL, true);

	::GetWindowRect(::GetDlgItem(m_hwnd, kcidUp), &rc);
	xOffset -=  m_dxpButtonSep + rc.Width();
	::SetWindowPos(::GetDlgItem(m_hwnd, kcidUp), NULL,
		xOffset, yOffset, 0, 0, grfnMove);
	::InvalidateRect(::GetDlgItem(m_hwnd, kcidUp), NULL, true);

	// Move the gripper to the bottom right.
	::GetWindowRect(m_hwndGrip, &rc);
	::MoveWindow(m_hwndGrip, dxp - rc.Width(), dyp - rc.Height(), rc.Width(),
		rc.Height(), true);
	::InvalidateRect(m_hwndGrip, NULL, true);
/*
	// Move the help and toolbar windows.
	if (m_fShowHelp)
	{
		const int kypToolbar = 5;
		const int kdypToolbar = 46;
		::MoveWindow(m_hwndTool, dxp - m_dxpHelp, kypToolbar, m_dxpHelp,
			kdypToolbar - kypToolbar, true);
		::MoveWindow(m_hwndHelp, dxp - m_dxpHelp, kdypToolbar, m_dxpHelp,
			dyp - m_dypHelp - kdypToolbar, true);
	}
*/
	return SuperClass::OnSize(wst, dxp, dyp);
}


/*----------------------------------------------------------------------------------------------
	Handle window messages.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
	switch (wm)
	{
	case WM_SIZING:
		return OnSizing(wp, (RECT *)lp);
	case WM_DESTROY:
		AfApp::Papp()->EnableMainWindows(true);
/*
	case WM_MOUSEMOVE:
		if (m_fdragging)
		{
			long xPos = (int)(short)LOWORD(lp);
			long yPos = (int)(short)HIWORD(lp);
			OnDrag(xPos, yPos);
			return true;
		}
	case WM_LBUTTONUP:
		if (m_fdragging)
		{
			OnDragEnd();
			return true;
		}
*/
	}
	return SuperClass::FWndProc(wm, wp, lp, lnRet);
}

/*----------------------------------------------------------------------------------------------
	Make sure the dialog doesn't get resized smaller than a minimum size.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::OnSizing(int wse, RECT * prc)
{
	AssertPtr(prc);

	if (prc->bottom - prc->top < m_dypMin)
	{
		if (wse == WMSZ_TOPLEFT || wse == WMSZ_TOP || wse == WMSZ_TOPRIGHT)
			prc->top = prc->bottom - m_dypMin;
		else
			prc->bottom = prc->top + m_dypMin;
	}

	int dxpMin = m_dxpMin;
/*
	if (m_fShowHelp)
	{
		Rect rc;
		GetClientRect(rc);
		dxpMin = rc.Width() - m_dxpHelp + 50;
	}
*/
	if (prc->right - prc->left < dxpMin)
	{
		if (wse == WMSZ_TOPLEFT || wse == WMSZ_LEFT || wse == WMSZ_BOTTOMLEFT)
			prc->left = prc->right - dxpMin;
		else
			prc->right = prc->left + dxpMin;
	}
	return true;
}

/*----------------------------------------------------------------------------------------------
	This method is called by the framework when the user chooses the OK or the Apply Now button.
	When the framework calls this method, changes made in the dialog are accepted.
	The default OnApply closes the dialog.

	@param fClose not used here
	@return true if Successful
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::OnApply(bool fClose)
{
	m_vhvUsed.Clear();
	HvoVector hv;
	TVITEM tvi;
    tvi.mask = TVIF_PARAM;
    HTREEITEM hti;
	if (m_fAtomic)
	{
		hti = TreeView_GetSelection(m_rghwndTree);
		if (hti)
		{
			tvi.hItem = hti;
			TreeView_GetItem(m_rghwndTree, &tvi);
			hv.hvo = tvi.lParam;
			m_vhvUsed.Push(hv);
		}
	}
	else
	{
		hti = TreeView_GetRoot(m_rghwndList);
		int cti = TreeView_GetCount(m_rghwndList);
		for (int i = 0; i < cti; ++i)
		{
			tvi.hItem = hti;
			TreeView_GetItem(m_rghwndList, &tvi);
			hv.hvo = tvi.lParam;
			m_vhvUsed.Push(hv);
			hti = TreeView_GetNextSibling(m_rghwndList, hti);
		}
	}
	return SuperClass::OnApply(fClose);
}

/*----------------------------------------------------------------------------------------------
	This method is called by the framework when the user chooses the OK or the Apply Now button.
	When the framework calls this method, changes made in the dialog are accepted.
	The default OnApply closes the dialog.

	@param fClose not used here
	@return true if Successful
----------------------------------------------------------------------------------------------*/
bool GenObjChsrDlg::OnCancel()
{
	m_vhvUsed.Clear();
	return SuperClass::OnCancel();
}

/***********************************************************************************************
	GenObjChsrTree methods.
***********************************************************************************************/

/*----------------------------------------------------------------------------------------------
	Handle window messages.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrTree::FWndProc(uint wm, WPARAM wp, LPARAM lp, long & lnRet)
{
	// Don't erase the background (to reduce flicker).
	if (wm == WM_ERASEBKGND)
		return true;

	return SuperClass::FWndProc(wm, wp, lp, lnRet);
}

/*----------------------------------------------------------------------------------------------
	Draw everything to memory so it doesn't flicker.
----------------------------------------------------------------------------------------------*/
bool GenObjChsrTree::OnPaint(HDC hdcDef)
{
	Assert(!hdcDef);

	PAINTSTRUCT ps;
	HDC hdc = ::BeginPaint(m_hwnd, &ps);
	Rect rc = ps.rcPaint;

	// Create the virtual screen in memory.
	HDC hdcMem = AfGdi::CreateCompatibleDC(hdc);
	HBITMAP hbmp = AfGdi::CreateCompatibleBitmap(hdc, rc.Width(), rc.Height());
	HBITMAP hbmpOld = AfGdi::SelectObjectBitmap(hdcMem, hbmp);
	::SetViewportOrgEx(hdcMem, -rc.left, -rc.top, NULL);
	AfGfx::FillSolidRect(hdcMem, rc, ::GetSysColor(COLOR_3DFACE));

	// Draw the tree view in memory and then copy it to the screen.
	DefWndProc(WM_PAINT, (WPARAM)hdcMem, 0);
	::BitBlt(hdc, rc.left, rc.top, rc.Width(), rc.Height(), hdcMem, rc.left, rc.top, SRCCOPY);

	// Clean up.
	HBITMAP hbmpDebug;
	hbmpDebug = AfGdi::SelectObjectBitmap(hdcMem, hbmpOld, AfGdi::OLD);
	Assert(hbmpDebug && hbmpDebug != HGDI_ERROR);
	Assert(hbmpDebug == hbmp);

	BOOL fSuccess;
	if (hbmpOld != hbmp)
	{
		fSuccess = AfGdi::DeleteObjectBitmap(hbmp);
		Assert(fSuccess);
	}

	fSuccess = AfGdi::DeleteDC(hdcMem);
	Assert(fSuccess);

	::EndPaint(m_hwnd, &ps);
	return true;
}
