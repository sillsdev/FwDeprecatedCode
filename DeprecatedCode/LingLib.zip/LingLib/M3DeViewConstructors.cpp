/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, 2002, SIL International. All rights reserved.

File: M3DeViewConstructors.cpp
Responsibility: Randy Regnier
Last reviewed: never

Description:
	These classes provide a suitable view for objects in non-CmPossibilities
	reference field editor (e.g., AfDeFeRefs).
-------------------------------------------------------------------------------*//*:End Ignore*/
#include "Main.h"
#pragma hdrstop

#undef THIS_FILE
DEFINE_THIS_FILE

//:>********************************************************************************************
//:>	MoMorphoSyntaxAnalysisVc methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
	@param fLoadData True if the VC needs to load any data it uses.
----------------------------------------------------------------------------------------------*/
MoMorphoSyntaxAnalysisVc::MoMorphoSyntaxAnalysisVc(bool fLoadData) : SuperClass(fLoadData)
{
	m_iclid = 0;
	m_hvoForm = 0;
	m_hvoSense = 0;
}

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
MoMorphoSyntaxAnalysisVc::~MoMorphoSyntaxAnalysisVc()
{ /* Let superclass handle it. */ }

static DummyFactory g_fact1(_T("SIL.LingLib.MoMorphoSyntaxAnalysisVc"));

/*----------------------------------------------------------------------------------------------
	Load the data needed to display this view.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP MoMorphoSyntaxAnalysisVc::LoadDataFor(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);
	if (!hvo)
		return WarnHr(E_INVALIDARG);

	// The id of the MoAffixForm will be stored in m_hvoForm.
	// The ids of the LexSenses that refer to the MSA (hvo param) are stored in m_vhvoSenses.
	StrUni stuSqlStmt;
	ISilDataAccessPtr qsda;

	m_iclid = 0;
	m_hvoForm = 0;
	m_flidForm = 0;
	m_hvoFormOwner = 0;
	m_hvoSense = 0;
	m_hvoPosA = 0;
	m_hvoPosB = 0;
	m_vws = 0;
	m_aenc = 0;

	ComBool fIsNull;
	ComBool fMoreRows;
	ULONG cbSpaceTaken;
	IOleDbEncapPtr qode;
	IOleDbCommandPtr qodc;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	// I need to get to the lpinfo so I can get to the encodings.
	CustViewDaPtr qcvd = dynamic_cast<CustViewDa*>(qsda.Ptr());
	AfDbInfoPtr qdbi = qcvd->GetDbInfo();
	AfLpInfoPtr qlpi = qcvd->GetLpInfo();
	m_vws = qlpi->VernWs();
	m_aenc = qlpi->AnalWs();
	qdbi->GetDbAccess(&qode);

	// Get Class$ for hvo.
	stuSqlStmt.Format(L"select Class$ from CmObject (readuncommitted) "
		L"where Id=%d", hvo);
	CheckHr(qode->CreateCommand(&qodc));
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtSelectWithOneRowset));
	CheckHr(qodc->GetRowset(0));
	CheckHr(qodc->NextRow(&fMoreRows));
	if (!fMoreRows)
	{
		return WarnHr(E_FAIL);
	}
	CheckHr(qodc->GetColValue(1, reinterpret_cast<ULONG *>(&m_iclid),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	Assert(m_iclid);

	stuSqlStmt.Format(L"exec DisplayName_MSA \'<root><Obj Id=\"%d\"/></root>\'", hvo);
	CheckHr(qode->CreateCommand(&qodc));
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtStoredProcedure));
	CheckHr(qodc->GetRowset(0));
	CheckHr(qodc->NextRow(&fMoreRows));
	if (!fMoreRows)
	{
		return WarnHr(E_FAIL);
	}

	// Handle form and sense for all classes.
	StrUni stuV;
	CheckHr(qodc->GetColValue(4, reinterpret_cast<ULONG *>(&m_hvoForm),
			isizeof(HVO), &cbSpaceTaken, &fIsNull, 0));
	CheckHr(qodc->GetColValue(6, reinterpret_cast<ULONG *>(&m_hvoFormOwner),
			isizeof(HVO), &cbSpaceTaken, &fIsNull, 0));
	CheckHr(qodc->GetColValue(7, reinterpret_cast<ULONG *>(&m_flidForm),
			isizeof(HVO), &cbSpaceTaken, &fIsNull, 0));
	CheckHr(qodc->GetColValue(11, reinterpret_cast<ULONG *>(&m_hvoSense),
		isizeof(HVO), &cbSpaceTaken, &fIsNull, 0));
	if (m_hvoForm > 0)
	{
		// It is a real MoForm. It can be either an underlying form or allomorph.
		stuV = L"MoForm_Form";
	}
	else
	{
		// It's the citation form.
		Assert(m_flidForm == kflidLexEntry_CitationForm);
		stuV = L"LexEntry_CitationForm";
	}
	// This handles the id, owner, and class$ information.
	CheckHr(CacheBasics(qcvd, m_hvoFormOwner));
	CheckHr(CacheMstr(qcvd, m_hvoFormOwner, stuV, m_vws));

	// Cache gloss for sense.
	if (m_hvoSense > 0)
	{
		// This handles the id, owner, and class$ information.
		CheckHr(CacheBasics(qcvd, m_hvoSense));
		stuV = L"LexSense_Gloss";
		CheckHr(CacheMstr(qcvd, m_hvoSense, stuV, m_aenc));
	}

	switch (m_iclid)
	{
	default:
		return WarnHr(E_FAIL);
	case kclidMoInflectionalAffixMsa:
			break;	// Nothing else to do.
	case kclidMoDerivationalAffixMsa:
		{
			CheckHr(qodc->GetColValue(15, reinterpret_cast<ULONG *>(&m_hvoPosA),
				isizeof(HVO), &cbSpaceTaken, &fIsNull, 0));
			CheckHr(qodc->GetColValue(19, reinterpret_cast<ULONG *>(&m_hvoPosB),
				isizeof(HVO), &cbSpaceTaken, &fIsNull, 0));
			// Cache the fromPOS.
			if (m_hvoPosA > 0)
			{
				// This handles the id, owner, and class$ information.
				CheckHr(CacheBasics(qcvd, m_hvoPosA));
				stuV = L"CmPossibility_Name";
				CheckHr(CacheMstr(qcvd, m_hvoPosA, stuV, m_aenc));
			}
			// Cache the toPOS.
			if (m_hvoPosB > 0 && m_hvoPosB != m_hvoPosA)
			{
				// This handles the id, owner, and class$ information.
				CheckHr(CacheBasics(qcvd, m_hvoPosB));
				stuV = L"CmPossibility_Name";
				CheckHr(CacheMstr(qcvd, m_hvoPosB, stuV, m_aenc));
			}
			break;
		}
	case kclidMoDerivationalStepMsa:	// Fall through, for now.
	case kclidMoStemMsa:
		{
			CheckHr(qodc->GetColValue(15, reinterpret_cast<ULONG *>(&m_hvoPosA),
				isizeof(HVO), &cbSpaceTaken, &fIsNull, 0));
			// Cache the POS.
			if (m_hvoPosA > 0)
			{
				// This handles the id, owner, and class$ information.
				CheckHr(CacheBasics(qcvd, m_hvoPosA));
				stuV = L"CmPossibility_Name";
				CheckHr(CacheMstr(qcvd, m_hvoPosA, stuV, m_aenc));
			}
			break;
		}
	}

	return S_OK;

	END_COM_METHOD(g_fact1, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	This is the method for displaying the name of a single reference.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP MoMorphoSyntaxAnalysisVc::Display(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);

	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	ITsIncStrBldrPtr qtisb;
	qtisb.CreateInstance(CLSID_TsIncStrBldr);
	ITsStringPtr qtssName;
	int cch;
	switch (frag)
	{
	case kfrListName:
	case kfrRefName:
		{
			// Make sure data is loaded.
			CheckHr(LoadDataFor(pvwenv, hvo, frag));

			// Handle form : gloss for all classes.
			ITsStringPtr qtssForm;
			ITsStringPtr qtssGloss;
			if (m_flidForm > 0)
			{
				CheckHr(qsda->get_MultiStringAlt(m_hvoFormOwner, m_flidForm,
					m_vws, &qtssForm));
				qtssForm->get_Length(&cch);
				if (cch > 0)
					CheckHr(qtisb->AppendTsString(qtssForm));
				else
					CheckHr(qtisb->AppendRgch(L"***", 3));
			}
			else
				CheckHr(qtisb->AppendRgch(L"***", 3));	// No form at all.
			CheckHr(qtisb->AppendRgch(L" : ", 3));
			if (m_hvoSense > 0)
			{
				CheckHr(qsda->get_MultiStringAlt(m_hvoSense, kflidLexSense_Gloss,
					m_aenc, &qtssGloss));
				qtssGloss->get_Length(&cch);
				if (cch > 0)
					CheckHr(qtisb->AppendTsString(qtssGloss));
				else
					CheckHr(qtisb->AppendRgch(L"***", 3));
			}
			else
				CheckHr(qtisb->AppendRgch(L"***", 3));


			switch (m_iclid)
			{
			default:
				return WarnHr(E_FAIL);
			case kclidMoInflectionalAffixMsa:
					break;	// Nothing else to do.
			case kclidMoDerivationalAffixMsa:
				{
					// We will display: 'N/V'.
					CheckHr(qtisb->AppendRgch(L" : ", 3));
					ITsStringPtr qtssFromPOS;
					ITsStringPtr qtssToPOS;
					if (m_hvoPosA > 0)
					{
						CheckHr(qsda->get_MultiStringAlt(m_hvoPosA,
							kflidCmPossibility_Name, m_aenc, &qtssFromPOS));
						qtssFromPOS->get_Length(&cch);
						if (cch > 0)
							CheckHr(qtisb->AppendTsString(qtssFromPOS));
						else
							CheckHr(qtisb->AppendRgch(L"***", 3));
					}
					else
						CheckHr(qtisb->AppendRgch(L"***", 3));
					CheckHr(qtisb->AppendRgch(L"/", 1));
					if (m_hvoPosB > 0)
					{
						CheckHr(qsda->get_MultiStringAlt(m_hvoPosB,
							kflidCmPossibility_Name, m_aenc, &qtssToPOS));
						qtssToPOS->get_Length(&cch);
						if (cch > 0)
							CheckHr(qtisb->AppendTsString(qtssToPOS));
						else
							CheckHr(qtisb->AppendRgch(L"***", 3));
					}
					else
						CheckHr(qtisb->AppendRgch(L"***", 3));
					break;
				}
			case kclidMoDerivationalStepMsa:	// Fall through, for now.
			case kclidMoStemMsa:
				{
					// We will display: 'N'.
					CheckHr(qtisb->AppendRgch(L" : ", 3));
					ITsStringPtr qtssPOS;
					if (m_hvoPosA > 0)
					{
						CheckHr(qsda->get_MultiStringAlt(m_hvoPosA,
							kflidCmPossibility_Name, m_aenc, &qtssPOS));
						qtssPOS->get_Length(&cch);
						if (cch > 0)
							CheckHr(qtisb->AppendTsString(qtssPOS));
						else
							CheckHr(qtisb->AppendRgch(L"***", 3));
					}
					else
						CheckHr(qtisb->AppendRgch(L"***", 3));
					break;
				}
			}
			break;
		}
	}
	CheckHr(qtisb->GetString(&qtssName));
	CheckHr(pvwenv->AddString(qtssName));

	return S_OK;

	END_COM_METHOD(g_fact1, IID_IVwViewConstructor);
}

//:>********************************************************************************************
//:> MoInflAffixSlotVc methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
	@param fLoadData True if the VC needs to load any data it uses.
----------------------------------------------------------------------------------------------*/
MoInflAffixSlotVc::MoInflAffixSlotVc(bool fLoadData) : SuperClass(fLoadData)
{ }

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
MoInflAffixSlotVc::~MoInflAffixSlotVc()
{ /* Let superclass handle it. */ }

static DummyFactory g_fact2(_T("SIL.LingLib.MoInflAffixSlotVc"));

/*----------------------------------------------------------------------------------------------
	Load the data needed to display this view.
	
	(From RN)->In this case, we need to load the class, owner
	(so we can tell whether it is a subitem), the title, and create date. If all of these are
	already in the cache, don't reload it.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP MoInflAffixSlotVc::LoadDataFor(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);
	if (!hvo)
		return WarnHr(E_INVALIDARG);

	StrUni stuSqlStmt;
	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	ILgWritingSystemFactoryPtr qwsf;
	CheckHr(qsda->get_WritingSystemFactory(&qwsf));
	AssertPtr(qwsf);
	int ws;
	CheckHr(qwsf->get_UserWs(&ws));
	CustViewDaPtr qcvd = dynamic_cast<CustViewDa*>(qsda.Ptr());
	int clid;
	HVO hvoOwn;
	ITsStringPtr qtssName;
	int cchName;
	ITsStringPtr qtssDesc;
	int cchDesc;
	CheckHr(qsda->get_IntProp(hvo, kflidCmObject_Class, &clid));
	CheckHr(qsda->get_ObjectProp(hvo, kflidCmObject_Owner, &hvoOwn));
	CheckHr(qsda->get_MultiStringAlt(hvo, kflidMoInflAffixSlot_Name, ws, &qtssName));
	CheckHr(qtssName->get_Length(&cchName));
	CheckHr(qsda->get_MultiStringAlt(hvo, kflidMoInflAffixSlot_Description,
			ws, &qtssDesc));
	CheckHr(qtssDesc->get_Length(&cchDesc));
	if (clid && hvoOwn && qtssName && cchName && qtssDesc && cchDesc)
		return S_OK;

	// Since we got past the above 'return', we need to load all of the
	// data, but the referred to MSAs.
	IDbColSpecPtr qdcs;
	// This handles the id, owner, class$.
	CheckHr(CacheBasics(qcvd, hvo));
	// Cache 'Optional'.
	stuSqlStmt.Format(L"select Id, Optional "
		L"from MoInflAffixSlot (readuncommitted) "
		L"where id = %d ",hvo);
	qdcs.CreateInstance(CLSID_DbColSpec);
	CheckHr(qdcs->Push(koctBaseId, 0, 0, 0));
	CheckHr(qdcs->Push(koctInt, 1, 0, 0));
	CheckHr(qcvd->Load(stuSqlStmt.Bstr(), qdcs, hvo, 0, NULL, NULL));
	// Now handle the Name and Description.
	StrUni stuProp = L"MoInflAffixSlot_Name";
	CheckHr(CacheMstr(qcvd, hvo, stuProp, ws));
	stuProp = L"MoInflAffixSlot_Description";
	CheckHr(CacheMstr(qcvd, hvo, stuProp, ws));
	// TODO RandyR: Handle 'affixes' (?).

	return S_OK;

	END_COM_METHOD(g_fact2, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	This is the method for displaying the name of a single reference.
	
	(From RN)->This view shows the
	name for an RnGenericRecord consisting of the type of record, hyphen, title, hyphen, 
	creation date. "Subevent - Fishing for pirana - 3/22/2001"

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP MoInflAffixSlotVc::Display(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);

	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	ILgWritingSystemFactoryPtr qwsf;
	CheckHr(qsda->get_WritingSystemFactory(&qwsf));
	AssertPtr(qwsf);
	int ws;
	CheckHr(qwsf->get_UserWs(&ws));
	ITsIncStrBldrPtr qtisb;
	qtisb.CreateInstance(CLSID_TsIncStrBldr);
	ITsStringPtr qtssName;
	int cch;
	switch (frag)
	{
	case kfrListName:
	case kfrRefName:
		{
			// Make sure data is loaded.
			CheckHr(LoadDataFor(pvwenv, hvo, frag));
			ITsStringPtr qtss;
			CheckHr(qsda->get_MultiStringAlt(hvo, kflidMoInflAffixSlot_Name, ws, &qtss));
			qtss->get_Length(&cch);
			if (cch > 0)
				CheckHr(qtisb->AppendTsString(qtss));
			else
				CheckHr(qtisb->AppendRgch(L"***", 3));
			break;
		}
	}
	CheckHr(qtisb->GetString(&qtssName));
	CheckHr(pvwenv->AddString(qtssName));

	return S_OK;

	END_COM_METHOD(g_fact2, IID_IVwViewConstructor);
}

//:>********************************************************************************************
//:> PhEnvironmentVc methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
	@param fLoadData True if the VC needs to load any data it uses.
----------------------------------------------------------------------------------------------*/
PhEnvironmentVc::PhEnvironmentVc(bool fLoadData) : SuperClass(fLoadData)
{ }

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
PhEnvironmentVc::~PhEnvironmentVc()
{ /* Let superclass handle it. */ }

static DummyFactory g_fact6(_T("SIL.LingLib.PhEnvironmentVc"));

/*----------------------------------------------------------------------------------------------
	Load the data needed to display this view.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP PhEnvironmentVc::LoadDataFor(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);
	if (!hvo)
		return WarnHr(E_INVALIDARG);
	
	StrUni stuSqlStmt;
	ISilDataAccessPtr qsda;

	OLECHAR rgchName[8000];
	ComBool fIsNull;
	ComBool fMoreRows;
	ULONG cbSpaceTaken;
	IOleDbEncapPtr qode;
	IOleDbCommandPtr qodc;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	// I need to get to the lpinfo so I can get to the encodings.
	CustViewDaPtr qcvd = dynamic_cast<CustViewDa*>(qsda.Ptr());
	AfDbInfoPtr qdbi = qcvd->GetDbInfo();
	AfLpInfoPtr qlpi = qcvd->GetLpInfo();
	m_vws = qlpi->VernWs();
	m_aenc = qlpi->AnalWs();
	qdbi->GetDbAccess(&qode);

	// Get string.
	stuSqlStmt.Format(
		L"exec DisplayName_PhEnvironment \'<root><Obj Id=\"%d\"/></root>\'", hvo);
	CheckHr(qode->CreateCommand(&qodc));
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtStoredProcedure));
	CheckHr(qodc->GetRowset(0));
	CheckHr(qodc->NextRow(&fMoreRows));
	if (!fMoreRows)
	{
		return WarnHr(E_FAIL);
	}
	CheckHr(qodc->GetColValue(2, reinterpret_cast<ULONG *>(rgchName),
		isizeof(rgchName), &cbSpaceTaken, &fIsNull, 2));
	m_stuDisplayName = rgchName;

	// Cache object.
	// This handles the id, owner, and class$ information.
	CheckHr(CacheBasics(qcvd, hvo));
	StrUni stuProp = L"PhEnvironment_Name";
	CheckHr(CacheMstr(qcvd, hvo, stuProp, m_aenc));

	return S_OK;

	END_COM_METHOD(g_fact6, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	This is the method for displaying the name of a single reference.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP PhEnvironmentVc::Display(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);

	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	ITsIncStrBldrPtr qtisb;
	qtisb.CreateInstance(CLSID_TsIncStrBldr);
	ITsStringPtr qtssName;
	switch (frag)
	{
	case kfrListName:
	case kfrRefName:
		{
			// Make sure data is loaded.
			CheckHr(LoadDataFor(pvwenv, hvo, frag));
			CheckHr(qtisb->AppendRgch(m_stuDisplayName.Chars(), m_stuDisplayName.Length()));
			break;
		}
	}
	CheckHr(qtisb->GetString(&qtssName));
	CheckHr(pvwenv->AddString(qtssName));

	return S_OK;

	END_COM_METHOD(g_fact6, IID_IVwViewConstructor);
}

//:>********************************************************************************************
//:> ReversalIndexEntryVc methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
	@param fLoadData True if the VC needs to load any data it uses.
----------------------------------------------------------------------------------------------*/
ReversalIndexEntryVc::ReversalIndexEntryVc(bool fLoadData) : SuperClass(fLoadData)
{ }

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
ReversalIndexEntryVc::~ReversalIndexEntryVc()
{ /* Let superclass handle it. */ }

static DummyFactory g_fact8(_T("SIL.LingLib.ReversalIndexEntryVc"));

/*----------------------------------------------------------------------------------------------
	Load the data needed to display this view.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ReversalIndexEntryVc::LoadDataFor(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);
	if (!hvo)
		return WarnHr(E_INVALIDARG);


	StrUni stuSqlStmt;
	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	CustViewDaPtr qcvd = dynamic_cast<CustViewDa*>(qsda.Ptr());
	AfDbInfoPtr qdbi = qcvd->GetDbInfo();
	AfLpInfoPtr qlpi = qcvd->GetLpInfo();
	int clid;
	HVO hvoOwn;
	ITsStringPtr qtssName;
	int cchName;
	CheckHr(qsda->get_IntProp(hvo, kflidCmObject_Class, &clid));
	CheckHr(qsda->get_ObjectProp(hvo, kflidCmObject_Owner, &hvoOwn));
	CheckHr(qsda->get_StringProp(hvo, kflidReversalIndexEntry_Name, &qtssName));
	CheckHr(qtssName->get_Length(&cchName));
	if (clid && hvoOwn && qtssName && cchName)
		return S_OK;

	// Since we got past the above 'return', we need to load all of the data.
	IDbColSpecPtr qdcs;
	// This handles the id, owner, class$ information.
	stuSqlStmt.Format(L"select id, class$, Owner$, updstmp, Name, Name_Fmt "
		L"from ReversalIndexEntry_ (readuncommitted) "
		L"where id = %d ",hvo);
	qdcs.CreateInstance(CLSID_DbColSpec);
	CheckHr(qdcs->Push(koctBaseId, 0, 0, 0));
	CheckHr(qdcs->Push(koctInt, 1, kflidCmObject_Class, 0));
	CheckHr(qdcs->Push(koctObj, 1, kflidCmObject_Owner, 0));
	CheckHr(qdcs->Push(koctTimeStamp, 1, 0, 0));
	CheckHr(qdcs->Push(koctString, 1, kflidReversalIndexEntry_Name, 0));
	CheckHr(qdcs->Push(koctFmt, 1, kflidReversalIndexEntry_Name, 0));
	CheckHr(qcvd->Load(stuSqlStmt.Bstr(), qdcs, hvo, 0, NULL, NULL));

	return S_OK;

	END_COM_METHOD(g_fact8, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	This is the method for displaying the name of a single reference.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP ReversalIndexEntryVc::Display(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);

	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	ITsIncStrBldrPtr qtisb;
	qtisb.CreateInstance(CLSID_TsIncStrBldr);
	ITsStringPtr qtssName;
	int cch;
	switch (frag)
	{
	case kfrListName:
	case kfrRefName:
		{
			// Make sure data is loaded.
			CheckHr(LoadDataFor(pvwenv, hvo, frag));
			ITsStringPtr qtssBase;
			CheckHr(qsda->get_StringProp(hvo, kflidReversalIndexEntry_Name, &qtssBase));
			qtssBase->get_Length(&cch);
			if (cch > 0)
				CheckHr(qtisb->AppendTsString(qtssBase));
			else
				CheckHr(qtisb->AppendRgch(L"***", 3));
			break;
		}
	}
	CheckHr(qtisb->GetString(&qtssName));
	CheckHr(pvwenv->AddString(qtssName));

	return S_OK;

	END_COM_METHOD(g_fact8, IID_IVwViewConstructor);
}

//:>********************************************************************************************
//:> LexSenseVc methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
	@param fLoadData True if the VC needs to load any data it uses.
----------------------------------------------------------------------------------------------*/
LexSenseVc::LexSenseVc(bool fLoadData) : SuperClass(fLoadData)
{ }

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
LexSenseVc::~LexSenseVc()
{ /* Let superclass handle it. */ }

static DummyFactory g_fact9(_T("SIL.LingLib.LexSenseVc"));

/*----------------------------------------------------------------------------------------------
	Load the data needed to display this view.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP LexSenseVc::LoadDataFor(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);
	if (!hvo)
		return WarnHr(E_INVALIDARG);

	m_aenc = 0;


	StrUni stuSqlStmt;
	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	CustViewDaPtr qcvd = dynamic_cast<CustViewDa*>(qsda.Ptr());
	AfDbInfoPtr qdbi = qcvd->GetDbInfo();
	AfLpInfoPtr qlpi = qcvd->GetLpInfo();
	m_aenc = qlpi->AnalWs();
	int clid;
	HVO hvoOwn;
	ITsStringPtr qtssName;
	int cchName;
	CheckHr(qsda->get_IntProp(hvo, kflidCmObject_Class, &clid));
	CheckHr(qsda->get_ObjectProp(hvo, kflidCmObject_Owner, &hvoOwn));
	CheckHr(qsda->get_MultiStringAlt(hvo, kflidLexSense_Gloss, m_aenc, &qtssName));
	CheckHr(qtssName->get_Length(&cchName));
	if (clid && hvoOwn && qtssName && cchName)
		return S_OK;

	// Since we got past the above 'return', we need to load all of the data.
	CheckHr(CacheBasics(qcvd, hvo));
	StrUni stuProp = L"LexSense_Gloss";
	CheckHr(CacheMstr(qcvd, hvo, stuProp, m_aenc));

	return S_OK;

	END_COM_METHOD(g_fact9, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	This is the method for displaying the name of a single reference.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP LexSenseVc::Display(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);

	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	ITsIncStrBldrPtr qtisb;
	qtisb.CreateInstance(CLSID_TsIncStrBldr);
	ITsStringPtr qtssName;
	int cch;
	switch (frag)
	{
	case kfrListName:
	case kfrRefName:
		{
			// Make sure data is loaded.
			CheckHr(LoadDataFor(pvwenv, hvo, frag));
			ITsStringPtr qtssBase;
			CheckHr(qsda->get_MultiStringAlt(hvo, kflidLexSense_Gloss, m_aenc, &qtssBase));
			qtssBase->get_Length(&cch);
			if (cch > 0)
				CheckHr(qtisb->AppendTsString(qtssBase));
			else
				CheckHr(qtisb->AppendRgch(L"***", 3));
			break;
		}
	}
	CheckHr(qtisb->GetString(&qtssName));
	CheckHr(pvwenv->AddString(qtssName));

	return S_OK;

	END_COM_METHOD(g_fact9, IID_IVwViewConstructor);
}

//:>********************************************************************************************
//:> LexEntryVc methods.
//:>********************************************************************************************

/*----------------------------------------------------------------------------------------------
	Constructor.
	@param fLoadData True if the VC needs to load any data it uses.
----------------------------------------------------------------------------------------------*/
LexEntryVc::LexEntryVc(bool fLoadData) : SuperClass(fLoadData)
{ }

/*----------------------------------------------------------------------------------------------
	Destructor.
----------------------------------------------------------------------------------------------*/
LexEntryVc::~LexEntryVc()
{ /* Let superclass handle it. */ }

static DummyFactory g_fact10(_T("SIL.LingLib.LexEntryVc"));

/*----------------------------------------------------------------------------------------------
	Load the data needed to display this view.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP LexEntryVc::LoadDataFor(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);
	if (!hvo)
		return WarnHr(E_INVALIDARG);

	m_ledtType = kledtNoForm;
	m_vws = 0;
	m_hvoMoForm = 0;
	m_aenc = 0;
	m_hvoLexSense = 0;
	m_iHomographNumber = 0;

	StrUni stuSqlStmt;
	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	CustViewDaPtr qcvd = dynamic_cast<CustViewDa*>(qsda.Ptr());
	AfDbInfoPtr qdbi = qcvd->GetDbInfo();
	AfLpInfoPtr qlpi = qcvd->GetLpInfo();
	m_vws = qlpi->VernWs();
	m_aenc = qlpi->AnalWs();
	IOleDbEncapPtr qode;
	IOleDbCommandPtr qodc;
	qdbi->GetDbAccess(&qode);
	ComBool fIsNull;
	ComBool fMoreRows;
	ULONG cbSpaceTaken;
	IDbColSpecPtr qdcs;

	// Don't bother checking cache. We'll just load all of the data.
	stuSqlStmt.Format(L"exec DisplayName_LexEntry \'<root><Obj Id=\"%d\"/></root>\' ", hvo);
	CheckHr(qode->CreateCommand(&qodc));
	CheckHr(qodc->ExecCommand(stuSqlStmt.Bstr(), knSqlStmtStoredProcedure));
	CheckHr(qodc->GetRowset(0));
	CheckHr(qodc->NextRow(&fMoreRows));
	if (!fMoreRows)
	{
		return S_OK;	// This seems right.
	}
	
	qdcs.CreateInstance(CLSID_DbColSpec);
	HVO hvoFid;
	StrUni stuQ;

	// Cache homograph number, if greater than 0.
	CheckHr(qodc->GetColValue(3, reinterpret_cast<ULONG *>(&m_iHomographNumber),
			isizeof(int), &cbSpaceTaken, &fIsNull, 0));
	if (m_iHomographNumber > 0)
	{
		stuSqlStmt.Format(L"select id, class$, Owner$, updstmp, HomographNumber "
			L"from LexEntry_ (readuncommitted) "
			L"where id=%d ", hvo);
		CheckHr(qdcs->Clear());
		CheckHr(qdcs->Push(koctBaseId, 0, 0, 0));
		CheckHr(qdcs->Push(koctInt, 1, kflidCmObject_Class, 0));
		CheckHr(qdcs->Push(koctObj, 1, kflidCmObject_Owner, 0));
		CheckHr(qdcs->Push(koctTimeStamp, 1, 0, 0));
		CheckHr(qdcs->Push(koctInt, 1, kflidLexEntry_HomographNumber, 0));
		CheckHr(qcvd->Load(stuSqlStmt.Bstr(), qdcs, hvo, 0, NULL, NULL));
		CheckHr(qdcs->Clear());
	}

	CheckHr(qodc->GetColValue(5, reinterpret_cast<ULONG *>(&hvoFid),
			isizeof(HVO), &cbSpaceTaken, &fIsNull, 0));
	if (hvoFid == 0)
	{
		// Using citation form.
		m_ledtType = kledtCitationForm;
		hvoFid = hvo;
		stuQ = L"LexEntry_CitationForm";
	}
	else
	{
		// Check details of form.
		int ord;
		CheckHr(qodc->GetColValue(6, reinterpret_cast<ULONG *>(&ord),
				isizeof(int), &cbSpaceTaken, &fIsNull, 0));
		if (ord == 0)
			m_ledtType = kledtUnderlyingForm;	// Using underlying form.
		else
			m_ledtType = kledtAllomorph;	// Using allomorph.
		stuQ = L"MoForm_Form";
		m_hvoMoForm = hvoFid;
	}
	// Store sense id. May be 0, if none.
	CheckHr(qodc->GetColValue(11, reinterpret_cast<ULONG *>(&m_hvoLexSense),
			isizeof(HVO), &cbSpaceTaken, &fIsNull, 0));

	// Cache basic info, whether the LexEntry, or a MoForm.
	CheckHr(CacheBasics(qcvd, hvoFid));
	// Now handle the form from wherever it came from.
	CheckHr(CacheMstr(qcvd, hvoFid, stuQ, m_vws));

	// Cache sense info, if any.
	if (m_hvoLexSense > 0)
	{
		// Cache basic sense info.
		CheckHr(CacheBasics(qcvd, m_hvoLexSense));
		stuQ = L"LexSense_Gloss";
		CheckHr(CacheMstr(qcvd, m_hvoLexSense, stuQ, m_aenc));
	}

	return S_OK;

	END_COM_METHOD(g_fact10, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	This is the method for displaying the name of a single reference.

	@param pvwenv Pointer to the view environment.
	@param hvo The id of the object we are displaying.
	@param frag Identifies the part of the view we are currently displaying. 
	@return HRESULT indicating success (S_OK), or failure (E_FAIL).
----------------------------------------------------------------------------------------------*/
STDMETHODIMP LexEntryVc::Display(IVwEnv * pvwenv, HVO hvo, int frag)
{
	BEGIN_COM_METHOD
	ChkComArgPtr(pvwenv);

	ISilDataAccessPtr qsda;
	CheckHr(pvwenv->get_DataAccess(&qsda));
	AssertPtr(qsda);
	ITsIncStrBldrPtr qtisb;
	qtisb.CreateInstance(CLSID_TsIncStrBldr);
	ITsStringPtr qtssName;
	int cch;
	switch (frag)
	{
	case kfrListName:
	case kfrRefName:
		{
			// Make sure data is loaded.
			CheckHr(LoadDataFor(pvwenv, hvo, frag));

			// Handle form.
			HVO hvoFid;
			int flid = kflidMoForm_Form;
			ITsStringPtr qtssForm;
			if (m_ledtType == kledtCitationForm)
			{
				flid = kflidLexEntry_CitationForm;
				hvoFid = hvo;
			}
			else hvoFid = m_hvoMoForm;
			CheckHr(qsda->get_MultiStringAlt(hvoFid, flid, m_vws, &qtssForm));
			qtssForm->get_Length(&cch);
			if (cch > 0)
			{
				CheckHr(qtisb->AppendTsString(qtssForm));
				if (m_iHomographNumber > 0)
				{
					StrUni stuHN;
					stuHN.Format(L"-%d", m_iHomographNumber);
					CheckHr(qtisb->Append(stuHN.Bstr()));
				}
			}
			else
				CheckHr(qtisb->AppendRgch(L"***", 3));

			// Add separator.
			CheckHr(qtisb->AppendRgch(L" : ", 3));

			// Handle sense.
			if (m_hvoLexSense > 0)
			{
				ITsStringPtr qtssGloss;
				CheckHr(qsda->get_MultiStringAlt(m_hvoLexSense, kflidLexSense_Gloss,
						m_aenc, &qtssGloss));
				qtssGloss->get_Length(&cch);
				if (cch > 0)
					CheckHr(qtisb->AppendTsString(qtssGloss));
				else
					CheckHr(qtisb->AppendRgch(L"***", 3));
			}
			else
				CheckHr(qtisb->AppendRgch(L"***", 3));
			break;
		}
	}
	CheckHr(qtisb->GetString(&qtssName));
	CheckHr(pvwenv->AddString(qtssName));

	return S_OK;

	END_COM_METHOD(g_fact10, IID_IVwViewConstructor);
}

/*----------------------------------------------------------------------------------------------
	This method caches the Id, Class$, Owner$, and updstmp for the given hvo.

	@param pcvd Pointer to a data cache.
	@param hvo The id of the object we are caching.
	@return HRESULT S_OK. [Note: This may throw an exception.]
----------------------------------------------------------------------------------------------*/
HRESULT CacheBasics(CustViewDa * pcvd, HVO hvo)
{
	Assert(pcvd);
	Assert(hvo);

	IDbColSpecPtr qdcs;
	StrUni stuSqlStmt;

	stuSqlStmt.Format(L"select id, class$, Owner$, updstmp "
		L"from CmObject (readuncommitted) "
		L"where id = %d ",hvo);
	qdcs.CreateInstance(CLSID_DbColSpec);
	CheckHr(qdcs->Push(koctBaseId, 0, 0, 0));
	CheckHr(qdcs->Push(koctInt, 1, kflidCmObject_Class, 0));
	CheckHr(qdcs->Push(koctObj, 1, kflidCmObject_Owner, 0));
	CheckHr(qdcs->Push(koctTimeStamp, 1, 0, 0));
	CheckHr(pcvd->Load(stuSqlStmt.Bstr(), qdcs, hvo, 0, NULL, NULL));
	return S_OK;
}

/*----------------------------------------------------------------------------------------------
	This method caches the obj, txt, flid, ws, and Fmt for the given hvo.

	@param pcvd Pointer to a data cache.
	@param hvo The id of the object whose string we are caching.
	@param stu The SQL view of the object we are caching.
	@param ws The writing system for the string we are caching.

	@return HRESULT S_OK. [Note: This may throw an exception.]
----------------------------------------------------------------------------------------------*/
HRESULT CacheMstr(CustViewDa * pcvd, HVO hvo, StrUni stu, int ws)
{
	Assert(pcvd);
	Assert(hvo);

	IDbColSpecPtr qdcs;
	StrUni stuSqlStmt;

	qdcs.CreateInstance(CLSID_DbColSpec);
	stuSqlStmt.Format(L"select obj, txt, flid, ws, Fmt "
		L"from %s (readuncommitted) "
		L"where Obj = %d and Ws = %d ", stu.Chars(), hvo, ws);
	CheckHr(qdcs->Push(koctBaseId, 0, 0, 0));
	CheckHr(qdcs->Push(koctMlaAlt, 1, 0, 0));
	CheckHr(qdcs->Push(koctFlid, 1, 0, 0));
	CheckHr(qdcs->Push(koctEnc, 1, 0, 0));
	CheckHr(qdcs->Push(koctFmt, 1, 0, 0));
	CheckHr(pcvd->Load(stuSqlStmt.Bstr(), qdcs, hvo, 0, NULL, NULL));
	return S_OK;
}
