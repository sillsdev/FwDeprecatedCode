// WorkerThread.h: interface for the CWorkerThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WORKERTHREAD_H__4F6AA7DF_A1BA_4907_B717_9D8B5CFD7ACE__INCLUDED_)
#define AFX_WORKERTHREAD_H__4F6AA7DF_A1BA_4907_B717_9D8B5CFD7ACE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning( disable : 4786 )

#define WT_START_BE_SAFE	EnterCriticalSection(&m_cs); try {
#define WT_END_BE_SAFE		} catch(...){} LeaveCriticalSection(&m_cs);


class CWorkerThread  
{
public:
	CWorkerThread();
	virtual ~CWorkerThread();
	HANDLE	Done();		// set when done/exited

protected:
	CRITICAL_SECTION	m_cs;
	HANDLE				m_hShutdown;
	HANDLE				m_Thread;

	static DWORD WINAPI ThreadMethod( LPVOID lpParam ) { return 0;} 

private:
	HANDLE	m_DoneEvent;
};

#endif // !defined(AFX_WORKERTHREAD_H__4F6AA7DF_A1BA_4907_B717_9D8B5CFD7ACE__INCLUDED_)


