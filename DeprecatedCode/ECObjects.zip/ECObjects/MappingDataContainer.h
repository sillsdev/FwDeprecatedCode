// MappingDataContainer.h: interface for the CMappingDataContainer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAPPINGDATACONTAINER_H__0B44C6AE_CBCA_4ADF_B901_63C21BBF4662__INCLUDED_)
#define AFX_MAPPINGDATACONTAINER_H__0B44C6AE_CBCA_4ADF_B901_63C21BBF4662__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "InternalMappingData.h"	// data object that contains all mapping information
#include "Persist.h"

#include <map>

/////////////////////////////////////////////////////////////////////////////

typedef std::map<long, CInternalMappingData*> TIDMappingPtrs;	// map< ID, Data* >
typedef TIDMappingPtrs::iterator TIDMappingPtrsIT;				// iterator for map

typedef std::map<long, long> TKeyID;							// map< KEY, ID >
typedef TKeyID::iterator TKeyIDIT;								// iterator for map


class CMappingDataContainer  
{
public:
	CMappingDataContainer();
	virtual ~CMappingDataContainer();

	long	Size();
	bool	EraseAll();
	bool	FindID( long id );
	bool	FindKey( long key );
	bool	Add( CInternalMappingData* data, bool copy=false );		// only added if ID and Key are not already in container
	bool	AddCopy( CInternalMappingData* data );
	bool	Update( CInternalMappingData* data);	// update the data with matching Key, else false
	bool	RemoveKeyElement( long key );			// remove the item with this key

	bool	Test();

	CInternalMappingData*	GetDataFromID ( long id );
	CInternalMappingData*	GetDataFromKey( long key );

	friend CPersist& operator<<( CPersist& stream, CMappingDataContainer* data);
	friend CPersist& operator>>( CPersist& stream, CMappingDataContainer** data);


	CInternalMappingData*	at( int index );
	CInternalMappingData*	PopItem( int index );

private:
	CRITICAL_SECTION	m_CS;
	TIDMappingPtrs		m_DataMap;
	TKeyID				m_KeyIDMap;
};

#endif // !defined(AFX_MAPPINGDATACONTAINER_H__0B44C6AE_CBCA_4ADF_B901_63C21BBF4662__INCLUDED_)
