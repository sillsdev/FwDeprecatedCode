/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2004 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: ECUtil.h
Responsibility: 
Last reviewed:

Description:
	This file contains Utility methods (gathered in the ECUtil namespace).
-------------------------------------------------------------------------------*//*:End Ignore*/
#pragma once
#ifndef ECUtil_H_INCLUDED
#define ECUtil_H_INCLUDED 1

namespace ECUtil
{
	char * WideToMultiByte( BSTR bstrIn, unsigned int codePage = CP_UTF8 );
	wchar_t * MultiByteToWide( const char * dataIn, int length,
		unsigned int codePage = CP_UTF8);
}

// Local Variables:
// mode:C++
// compile-command:"cmd.exe /e:4096 /c c:\\FW\\Bin\\mkecob.bat"
// End: (These 4 lines are useful to Steve McConnel.)

#endif /*ECUtil_H_INCLUDED*/
