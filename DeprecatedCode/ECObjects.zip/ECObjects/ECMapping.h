// ECMapping.h : Declaration of the CECMapping

#ifndef __ECMAPPING_H_
#define __ECMAPPING_H_

#include "resource.h"			    // main symbols
#include "InternalMappingData.h"
#include "TraceCreation.h"


/////////////////////////////////////////////////////////////////////////////
// CECMapping
class ATL_NO_VTABLE CECMapping : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CECMapping, &CLSID_ECMapping>,
	public ISupportErrorInfo,
	public CTraceCreation,
	public IDispatchImpl<IECMapping, &IID_IECMapping, &LIBID_ECOBJECTSLib>
{
public:
//	CECMapping(){};
//	virtual ~CECMapping(){};
	CECMapping(): CTraceCreation( "CECMapping" ){}
	virtual ~CECMapping() {	OutputDebugString("~CECMapping()\n"); }

DECLARE_REGISTRY_RESOURCEID(IDR_ECMAPPING)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CECMapping)
	COM_INTERFACE_ENTRY(IECMapping)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IECMapping
public:
	STDMETHOD(get_WritingSystem)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_WritingSystem)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_NewEndMarker)(/*[out, retval]*/ BSTR *pVal);
////	STDMETHOD(put_NewEndMarker)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_NewBeginMarker)(/*[out, retval]*/ BSTR *pVal);
////	STDMETHOD(put_NewBeginMarker)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_DomainAsBSTR)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(Init)(VARIANT* myData);
	STDMETHOD(get_ID)(/*[out, retval]*/ long *pVal);
///	STDMETHOD(get_ReadOnly)(/*[out, retval]*/ IDispatch* *pVal);
///	STDMETHOD(AsReadOnly)(/*[out, retval]*/ IECMappingRO ** readOnly);

	STDMETHOD(get_Domain)(/*[out, retval]*/ MarkerDomain *pVal);
	STDMETHOD(put_Domain)(/*[in]*/ MarkerDomain newVal);

	STDMETHOD(get_IsInline)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_IsInline)(/*[in]*/ BOOL newVal);

	STDMETHOD(get_IsConfirmed)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_IsConfirmed)(/*[in]*/ BOOL newVal);

	STDMETHOD(get_MarkerEncoding)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_MarkerEncoding)(/*[in]*/ BSTR newVal);

	STDMETHOD(get_DataEncoding)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_DataEncoding)(/*[in]*/ BSTR newVal);

	STDMETHOD(get_EndMarker)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_EndMarker)(/*[in]*/ BSTR newVal);

	STDMETHOD(get_BeginMarker)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_BeginMarker)(/*[in]*/ BSTR newVal);

	STDMETHOD(get_StyleName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_StyleName)(/*[in]*/ BSTR newVal);

	CInternalMappingData*	InternalDataCopy();

private:
	CInternalMappingData	m_Data;
};

#endif //__ECMAPPING_H_
