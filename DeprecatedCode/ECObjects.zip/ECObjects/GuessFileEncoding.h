// GuessFileEncoding.cpp : Defines the entry point for the console application.
//
#ifndef __GuessFileEncoding_H__
#define __GuessFileEncoding_H__

#include "ECObjects.h"			// FileEncoding

#include <string.h>	//wcslen, wcscpy
#include <stdlib.h>
#include <io.h>
#include <wchar.h>



bool IsUTF8Text(const char* utf8, int len);
bool IsUTF8String(const char* utf8);




class CGuessFileEncoding
{
public:

	CGuessFileEncoding( BSTR fileName );	// char *fileName );
	~CGuessFileEncoding();

	bool			HasBOM()			{ return m_HasBOM; }
	EC_FileEncoding	BOM()				{ return m_BOMEncoding; }

	EC_FileEncoding	GuessEncoding();		// logic of guesser - post utf8

	EC_FileEncoding	GetFileEncoding()	{ if ( m_HasBOM ) return BOM(); return m_FileEncoding; }
	long			GetCertiantyPercent() { if ( m_HasBOM ) return 100; return 0; }

	void			GetEncodingAsString( char *buf );

	// ----- Static Methods --------------------------------------------
	static void	UnicodeValueToSurrogatePair( long scalar, short *high, short *low );
	static long	SurrogatePairToUnicodeValue( unsigned short high, unsigned short low );
	static EC_FileEncoding	ReadBOM( BSTR fileName );	// char* fname );


private:	
	// Member Methods	----------------------------------
	//
	void	GetFileData();			// open, and read 'n' bytes into the 'buffer'
	void	ParseTheBuffer();		// walk through the buffer and process the data

	// Member Variables	----------------------------------
	//
	EC_FileEncoding	m_FileEncoding;	// true if BOM was found in file
	char *			m_buf;			// storage location of file contents (first 'n' bytes)
	int				m_bufLength;	// number of bytes stored in buffer
//	char *		m_FileName;		// file name to open and determine encoding
	CComBSTR		m_FileName;

	bool			m_HasBOM;		// file contains a BOM
	EC_FileEncoding	m_BOMEncoding;	// BOM encoding value

};

#endif
