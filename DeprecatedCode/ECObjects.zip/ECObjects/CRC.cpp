// CRC.cpp: implementation of the CRC class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CRC.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRC* CRC::Instance()
{
	if ( m_Instance == NULL )
	{
		m_Instance = new CRC();
		m_Instance->BuildCRCTable();
	}
	
	return m_Instance;
}

void CRC::Done()
{
	if ( m_Instance )
		delete m_Instance;
}


/* CRC routines from CRCMAN.C */


CRC* CRC::m_Instance = NULL;
unsigned long CRC::m_CRC32_POLYNOMIAL = 0xEDB88320L;
unsigned long CRC::m_CRC32_STARTVALUE = 0xFFFFFFFFL;
unsigned long CRC::m_CRCTable[ 256 ];

void CRC::BuildCRCTable()
{
    int i;
    int j;
    unsigned long crc;

    for ( i = 0; i <= 255 ; i++ ) {
        crc = i;
        for ( j = 8 ; j > 0; j-- ) {
            if ( crc & 1 )
                crc = ( crc >> 1 ) ^ m_CRC32_POLYNOMIAL;
            else
                crc >>= 1;
        }
        m_CRCTable[ i ] = crc;
    }
}

//    crc = 0xFFFFFFFFL;
//    crc = CalculateBufferCRC( count, crc, buffer );
//    return( crc ^= 0xFFFFFFFFL );


//unsigned long CalculateBufferCRC( void *buffer, unsigned int count, unsigned long crc)
unsigned long CRC::CalculateCRC( void *buffer, unsigned int count )
{
	unsigned long crc = m_CRC32_STARTVALUE;
    unsigned char *p;
    unsigned long temp1;
    unsigned long temp2;

    p = (unsigned char*) buffer;
    while ( count-- != 0 ) {
        temp1 = ( crc >> 8 ) & 0x00FFFFFFL;
        temp2 = m_CRCTable[ ( (int) crc ^ *p++ ) & 0xff ];
        crc = temp1 ^ temp2;
    }
    return( crc ^= m_CRC32_STARTVALUE );
}
