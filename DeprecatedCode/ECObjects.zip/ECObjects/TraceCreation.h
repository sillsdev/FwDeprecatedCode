//	TraceCreation.h : Declaration of the CTraceCreation class
//
//	This class servers as an aid in tracking object creation and destruction.
//
//	Created 7/11/2002
//

#ifndef __TraceCreation_h__
#define __TraceCreation_h__



#include <map>
#include <string>
#include <vector>

typedef struct
{
	int active;
	int max;
} TraceCreationData;

typedef std::vector<bool> bVec;
typedef std::map< std::string, TraceCreationData > TraceCreationMap;
typedef std::map< std::string, bVec*> TraceCreationActiveMap;

#if 0		// def _DEBUG
	#define DEBUG_TRACECREATION_DECLARE( X )	class X: public CTraceCreation
	#define DEBUG_TRACECREATION_IMPLEMENT( X )	CTraceCreation( "X") 
//	#define DEBUG_TRACECREATION_DECLARE( X )	class X
//	#define DEBUG_TRACECREATION_IMPLEMENT( X )	
#else
	#define DEBUG_TRACECREATION_DECLARE( X )	class X
	#define DEBUG_TRACECREATION_IMPLEMENT( X )
#endif



class CTraceCreation
{
private:
//	CTraceCreation();
	enum creationType { CT_COPY, CT_ASSIGN, CT_CONS, CT_UNKNOWN };

public:
	static void Init();
	static void Reset();
	static void ShowObjects();
	static void ShowCount( char* name );

	static void Done();


	CTraceCreation();
	CTraceCreation( char* name );
	virtual ~CTraceCreation();
	
	CTraceCreation( const CTraceCreation& other);
	CTraceCreation & operator=( const CTraceCreation& other);

	int		GetTraceID()	{ return mID; };

private:
	bool	IsObjectActive();
	void	Init( char * name );

private:
///	static std::map< std::string, int > mObjects;
	static TraceCreationMap mObjects;
	static TraceCreationActiveMap mActiveObjects;
	static CRITICAL_SECTION mCS;
	static bool mbInitDone;
	static int  mMaxLen;

	std::string	mName;
	int mID;
	creationType mCreationType;

	char*	GetCreationString();
};



#endif
