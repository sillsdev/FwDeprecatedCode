	// ParatextProjectProxy.cpp : Implementation of CParatextProjectProxy
#include "stdafx.h"
#include "ECObjects.h"
#include "ParatextProjectProxy.h"
#include "ECMapping.h"

#include "MappingInfo.h"
#include "ECLibrary.h"
#include "ECUtil.h"
#include "CRC.h"

#include "io.h"		// _waccess function

#include <set>
#include <string>

// #import "ScriptureObjects.dll" rename_namespace("SO")	// for clarity use SO namespace
// #import "libid:CF24879E-A4BB-48dd-B9E4-300239BE2DD8" rename_namespace("SO")	// for clarity use SO namespace

///#import "c:\\Dev\\Projects\\NewEscesWork\\Shared\\Output\\Debug\\ScriptureObjects.dll" rename_namespace("SO")	// for clarity use SO namespace
#import "../TESO/TESO.tlb" rename_namespace("TESO")	// for clarity use SO namespace


#define	START_BE_SAFE( X )	bool besafeTrue=true; char besafeName__[] = {"" #X ""}; EnterCriticalSection( &m_csBusy );	try {
#define END_BE_SAFE		} catch(...) {besafeTrue=false;ATLTRACE("*** Exception: <%s>\n", besafeName__);} LeaveCriticalSection( &m_csBusy );
#define HAD_EXCEPTION	besafeTrue==false


/////////////////////////////////////////////////////////////////////////////
// CParatextProjectProxy

STDMETHODIMP CParatextProjectProxy::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IParatextProjectProxy
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


CParatextProjectProxy::CParatextProjectProxy(): CTraceCreation( "CParatextProjectProxy" ), m_ECLibrary(NULL)
{
	InitializeCriticalSection( &m_csBusy );

/*
	CComObject<ECLibrary> *pste;
	HRESULT hResult = CComObject<ECLibrary>::CreateInstance(&pste);
	if (FAILED(hResult))
	{
		ATLTRACE("Unable to create ECLibrary in CParatextProjectProxy constructor. *** ERROR ***\n" );
		return;
	}

	m_ECLibrary = pste;
*/

	CComObject<ECLibrary> *pste;
	HRESULT hResult = CComObject<ECLibrary>::CreateInstance(&pste);
	if (FAILED(hResult))
	{
		ATLTRACE("Unable to create ECLibrary in CParatextProjectProxy constructor. *** ERROR ***\n" );
		return;
	}
	ULONG lval = pste->AddRef();

	m_ECLibrary = pste;

	m_cbstrVernProj = "";
	m_cbstrBackProj = "";
	m_cbstrNoteProj = "";
	m_cbstrDefaultVernWritingSystem = "";
	m_cbstrDefaultAnalWritingSystem = "";
}


CParatextProjectProxy::~CParatextProjectProxy()
{
	DeleteCriticalSection( &m_csBusy );
	
	TMapIDMappingContainerIT it = m_DataCont.begin();
	while ( it != m_DataCont.end() )
	{
		CMappingDataContainer *data = (*it).second;
		delete data;
		it++;
	}

	this->ShowObjects();
	if ( m_ECLibrary )
		m_ECLibrary->Release();
	m_ECLibrary = 0;
	this->ShowObjects();

}


///////////////////////////*****************************//////////////////////

CPersist& operator<<( CPersist& stream, CParatextProjectProxy* data)
{
	//	description, # of mapping containers, mapping containers, vern proj, back proj, notes proj
	//////////////////////

	stream << "PTProject";								// Description

	long lval;
	lval = data->m_DataCont.size();						// number of ID - container pairs in the map
	stream << lval;										// number of containers

	TMapIDMappingContainerIT it = data->m_DataCont.begin();
	while ( it != data->m_DataCont.end() )
	{
		CMappingDataContainer *dataCont = (*it).second;
		stream << dataCont;

		it++;
	}

	stream << (BSTR*)&(data->m_cbstrVernProj.m_str);	// Vern project
	stream << (BSTR*)&(data->m_cbstrBackProj.m_str);	// Back Project
	stream << (BSTR*)&(data->m_cbstrNoteProj.m_str);	// Notes Project

	return stream;
}

CPersist& operator>>( CPersist& stream, CParatextProjectProxy** data)
{
	try
	{
		ATLTRACE(" --- Restoring <CParatextProjectProxy> from Archive ---\n");

		(*data)->Init();		// reset all the data structures...

		char* desc=0;
		BSTR bstrTemp;
		long lcount, i;
		
		//	description, # of mapping containers, mapping containers, vern proj, back proj, notes proj
		//////////////////////

		stream >> &desc;							// description
	
		// make sure it's the right type of CPersist data
		if ( desc && strcmp( desc, "PTProject" ) )
		{
			stream.SetError( CPersist::ET_BAD_INIT );
			ATLTRACE(" --- CParatextProjectProxy not created from <%s> stream. ---\n", desc );
			delete [] desc;
			return stream;
		}

		delete [] desc;

		stream >> lcount;							// number of mapping containers
		ATLTRACE(" --- Number of Mapping containers = %d\n", lcount );

		CMappingDataContainer *dataCont = new CMappingDataContainer;

		for ( i=0; i<lcount; i++ )	
		{
			stream >> &dataCont;	// read each container
			
			if ( dataCont->Size() > 0 )
			{
				(*data)->AddMappingContainer( dataCont );
			}

			dataCont->EraseAll();	// if poping data items off - this should be of size '0'
		}

		stream >> &bstrTemp;							// Vern project
		if ( ::SysStringByteLen( bstrTemp ) > 0 )
			(*data)->SetDomainProjectNameOnly( bstrTemp, MD_Vern );

		::SysFreeString( bstrTemp );

		stream >> &bstrTemp;							// Back project
		if ( ::SysStringByteLen( bstrTemp ) > 0 )
			(*data)->SetDomainProjectNameOnly( bstrTemp, MD_Back );

		::SysFreeString( bstrTemp );

		stream >> &bstrTemp;							// Notes project
		if ( ::SysStringByteLen( bstrTemp ) > 0 )
			(*data)->SetDomainProjectNameOnly( bstrTemp, MD_Note );

		::SysFreeString( bstrTemp );

		
		ATLTRACE(" --- CParatextProjectProject Successfully created from BLOB. ---\n" );
	}
	catch(...)
	{
		ATLTRACE(" ### ERROR: --- Object NOT Successfully created from BLOB\n" );

		// re initialize the data for the object...
		(*data)->Init();
	}
	return stream;
}
///////////////////////////*****************************//////////////////////
///////////////////////////*****************************//////////////////////
///////////////////////////*****************************//////////////////////
void CParatextProjectProxy::SaveToString( BSTR* archive )
{
	START_BE_SAFE( CParatextProjectProxy::SaveToString )

	CPersist pstream;
	pstream << this;
	*archive = ::SysAllocStringByteLen( pstream.ReadOnlyBuffer(), pstream.ReadOnlyBufferSize() );

	ATLTRACE( "* Created %d byte Archive Blob.\n", ::SysStringByteLen( *archive ) );

	END_BE_SAFE

	if ( HAD_EXCEPTION )
	{
		CComBSTR blob = "";
		*archive = blob.Copy();
	}

	ATLTRACE( "* Created %d byte Archive Blob.\n", ::SysStringByteLen( *archive ) );
		
	return;
}

void CParatextProjectProxy::Init()
{
	START_BE_SAFE( CParatextProjectProxy::Init )

	TMapIDMappingContainerIT it = m_DataCont.begin();
	while ( !(m_DataCont.empty()) && it != m_DataCont.end() )
	{
		CMappingDataContainer *data = (*it).second;
		data->EraseAll();
		it++;
	}

	m_cbstrVernProj	= L"";
	m_cbstrBackProj = L"";
	m_cbstrNoteProj = L"";

	END_BE_SAFE
}


///////////////////////////*****************************//////////////////////

STDMETHODIMP CParatextProjectProxy::get_VernTransProj(/*[out, retval]*/ BSTR* pt6Project)
{
	*pt6Project = m_cbstrVernProj.Copy();
	return S_OK;
}

STDMETHODIMP CParatextProjectProxy::get_BackTransProj(/*[out, retval]*/ BSTR* pt6Project)
{
	*pt6Project = m_cbstrBackProj.Copy();
	return S_OK;
}

STDMETHODIMP CParatextProjectProxy::get_NotesTransProj(/*[out, retval]*/ BSTR* pt6Project)
{
	*pt6Project = m_cbstrNoteProj.Copy();
	return S_OK;
}

STDMETHODIMP CParatextProjectProxy::get_DefaultVernWritingSystem(BSTR *pVal)
{
	*pVal = m_cbstrDefaultVernWritingSystem.Copy();
	return S_OK;
}

STDMETHODIMP CParatextProjectProxy::put_DefaultVernWritingSystem(BSTR newVal)
{
	m_cbstrDefaultVernWritingSystem = newVal;
	return S_OK;
}

STDMETHODIMP CParatextProjectProxy::get_DefaultAnalWritingSystem(BSTR *pVal)
{
	*pVal = m_cbstrDefaultAnalWritingSystem.Copy();
	return S_OK;
}

STDMETHODIMP CParatextProjectProxy::put_DefaultAnalWritingSystem(BSTR newVal)
{
	m_cbstrDefaultAnalWritingSystem = newVal;
	return S_OK;
}




STDMETHODIMP CParatextProjectProxy::put_VernTransProj(/*[in]*/ BSTR pt6Project)
{
	return SetDomainProject( pt6Project, MD_Vern, (CComBSTR*)&m_cbstrVernProj );
}

STDMETHODIMP CParatextProjectProxy::put_BackTransProj(/*[in]*/ BSTR pt6Project)
{
	return SetDomainProject( pt6Project, MD_Back, (CComBSTR*)&m_cbstrBackProj );
}

STDMETHODIMP CParatextProjectProxy::put_NotesTransProj(/*[in]*/ BSTR pt6Project)
{
	return SetDomainProject( pt6Project, MD_Note, (CComBSTR*)&m_cbstrNoteProj );
}

STDMETHODIMP CParatextProjectProxy::get_NumberOfMappings(/*[out,retval]*/ int* iCount)
{
	int count = 0;
	
	START_BE_SAFE( "get_NumberOfMappings" )

	TMapIDMappingContainerIT it = m_DataCont.begin();
	while ( it != m_DataCont.end() )
	{
		CMappingDataContainer *data = (*it).second;
		count += data->Size();
		it++;
	}

	END_BE_SAFE

	*iCount = count;

	return S_OK;
}


HRESULT CParatextProjectProxy::SetDomainProjectNameOnly( BSTR project, MarkerDomain domain)
{
	HRESULT hr = S_OK;
	switch ( domain )
	{
		case MD_Vern: m_cbstrVernProj = project; break;
		case MD_Back: m_cbstrBackProj = project; break;
		case MD_Note: m_cbstrNoteProj = project; break;
		default: hr = E_INVALIDARG; break;
	}

	return hr;
}


STDMETHODIMP CParatextProjectProxy::RefreshDomainMarkers( MarkerDomain domain )
{
	HRESULT hr = S_OK;
	CComBSTR throwAway;
	BSTR project=0;
	switch ( domain )
	{
		case MD_Vern: project = m_cbstrVernProj.Copy(); break;
		case MD_Back: project = m_cbstrBackProj.Copy(); break;
		case MD_Note: project = m_cbstrNoteProj.Copy(); break;	
		default: hr = E_INVALIDARG; break;
	}

	if (hr == S_OK && project && ::SysStringLen(project) )
		hr = SetDomainProject( project, domain, (CComBSTR*)&throwAway, false );

	if ( project )
		::SysFreeString( project );

	return hr;
}



HRESULT CParatextProjectProxy::SetDomainProject( BSTR project, MarkerDomain domain, CComBSTR* projString, bool cleanStart/*=true*/ )
{
	HRESULT hr = S_OK;
	*projString = project;

	START_BE_SAFE( "CParatextProjectProxy::SetDomainProject" )

	CMappingDataContainer *domainCont = GetContainerForDomain( domain );	// storage for container for the specified domain

	if ( cleanStart )
	{
		domainCont->EraseAll();			// make sure we start fresh for this domain
	}
	
	if ( projString->Length() == 0 )
	{
		domainCont->EraseAll();			// make sure we start fresh for this domain
		return hr;
	}

	try 
	{
		TESO::ISCScriptureTextPtr qScriptureText;
		qScriptureText.CreateInstance(__uuidof(TESO::SCScriptureText));
		ATLASSERT(qScriptureText != NULL);

//		::MessageBox(NULL, "asdfasdf", "asdfasdf", MB_OK);

		qScriptureText->Load((*projString).m_str); 

		std::set<std::string> EndMarkers;
		std::set<std::string>::iterator EndMarkerIT;
		std::string tmp;
//		char asciiMarker[256];

		for( int index=0; true; index++ )
		{
			TESO::ISCTagPtr scTag;
			scTag = qScriptureText->NthTag( index );
			if ( scTag == NULL )
				break;				// terminate the for loop

			BSTR cMarker, cEndMarker, TEStyle;
			scTag->get_Marker(&cMarker);
			scTag->get_Endmarker(&cEndMarker);
			scTag->get_TeStyleName(&TEStyle);

			// pre-pend the '\\' char for the TE Team
			// The current 6/03 version of the SO doesn't include
			//	the \ as part of the marker text that is returned by the
			//  'get_Marker' call.
			wchar_t *wcptr = cMarker;
			if ( *wcptr != '\\' )
			{
				// add the backslash to the start of the marker(s)
				//
				CComBSTR modMarker = L"\\";
				modMarker.AppendBSTR( cMarker );
				SysFreeString( cMarker );
				cMarker = modMarker.Copy();

				if ( ::SysStringLen( cEndMarker ) > 0 )
				{
					modMarker = L"\\";
					modMarker.AppendBSTR( cEndMarker );
					SysFreeString( cEndMarker );
					cEndMarker = modMarker.Copy();
				}
			}
			else
			{
				ATLTRACE("Marker already has backslash char at begining.\n");
			}

			// see if there is an end marker
			if ( ::SysStringLen( cEndMarker ) > 0 )
			{
				char* pszEndMarker = ECUtil::WideToMultiByte( cEndMarker );
	
				tmp = pszEndMarker;
				free( pszEndMarker );

				EndMarkerIT = EndMarkers.find( tmp );

				// is the end marker already defined for a different marker
				if ( EndMarkerIT == EndMarkers.end() )
					EndMarkers.insert( tmp );
			}

#if 0
			if ( !cleanStart )		// just want to add markers that don't already exist
			{
				short foundPos = -1;	// FindMapping( &cMarker, domain );
				OutputDebugString("Need to FIX THIS!!!!\n");

				if ( foundPos >= 0 )
				{
//					index++;
					continue;		// already exists, continue looking for new markers...
				}
				else
				{
					ATLTRACE("*#*#*# Found new marker in project not in mapping list from blob, adding <");
					OutputDebugStringW( cMarker );
					ATLTRACE(">\n");
				}
			}
#endif

			// see if the marker matches a previous end marker
			char* pszMarker = ECUtil::WideToMultiByte( cMarker );

			tmp = pszMarker;
			EndMarkerIT = EndMarkers.find( tmp );

			if ( EndMarkerIT != EndMarkers.end() )
			{
				// found end marker with same characters, don't add to the list of markers
				ATLTRACE("**Do not add to list.\n");
			}
			else
			{
				// add the backslash to the start of the marker(s)
				//
/*				CComBSTR modMarker = L"\\";
				modMarker.AppendBSTR( cMarker );
				SysFreeString( cMarker );
				cMarker = modMarker.Copy();

				if ( ::SysStringLen( cEndMarker ) > 0 )
				{
					modMarker = L"\\";
					modMarker.AppendBSTR( cEndMarker );
					SysFreeString( cEndMarker );
					cEndMarker = modMarker.Copy();
				}
*/

				CInternalMappingData *tstData = new CInternalMappingData();
				tstData->SetBeginMarker( cMarker );
				tstData->SetEndMarker( cEndMarker );
				tstData->SetDomain( domain );

				// if there is no TEStyle data then use what's in the Library

				if ( ::SysStringByteLen( TEStyle ) <= 0 )
				{
					::SysFreeString( TEStyle );

					m_ECLibrary->get_TEStyleName( cMarker, &TEStyle );
				}
				
				tstData->SetStyleName( TEStyle );

				if ( domainCont->Add( tstData ) == false )	// didn't add it
				{
					ATLTRACE("*** Data not added.\n" );
					delete tstData;		// don't leak...
				}
				else
				{
					ATLTRACE("### Found new marker in project, adding <");
					OutputDebugStringW( cMarker );
					ATLTRACE(">\n");
				}
			}

			SysFreeString( cMarker );
			SysFreeString( cEndMarker );
			SysFreeString( TEStyle );

//			index++;
		}
		EndMarkers.clear();
	} 
	catch (_com_error& e) 
	{
		ATLTRACE("*** ERROR Unable to load domain<%ld> Project <%S>\n", domain, (BSTR)e.Description());

		hr = E_INVALIDARG;
		*projString = "";
	}

	END_BE_SAFE

	return hr;
}


STDMETHODIMP CParatextProjectProxy::get_AsSafeArray(/*[out,retval]*/ VARIANT* pSafeArray)	// safe array of BYTES
{
	HRESULT hr = S_OK;

	START_BE_SAFE( CParatextProjectProxy::get_AsSafeArray );

	CPersist pstream;

	START_BE_SAFE( CParatextProjectProxy::get_AsSafeArray::BuildingStream  )
	
	pstream << this;

	END_BE_SAFE

	if ( HAD_EXCEPTION )
	{
		int asdf = 1234;
	}

	const int numItems = pstream.ReadOnlyBufferSize();

	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreate(VT_UI1, 1, rgsabound);

	const char *pSrc = pstream.ReadOnlyBuffer();
	unsigned char *pData = (unsigned char*)pSrc;
	long index = 0;

	char HUGEP *arrayData;
	hr = SafeArrayAccessData( psa, (void HUGEP* FAR*) &arrayData );
	if ( FAILED(hr) )
		return hr;

	memcpy( arrayData, pSrc, numItems );
	SafeArrayUnaccessData(psa);

	pSafeArray->vt = VT_UI1 | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;

	END_BE_SAFE

	return hr;
}

//////////////////////////////////////////////////////////

STDMETHODIMP CParatextProjectProxy::NthECMapping(/*[in]*/ int iIndex, /*[out]*/ IECMapping* *data)
{
	HRESULT hr = S_OK;
	long startPos, endPos;

	START_BE_SAFE( CParatextProjectProxy::NthECMapping );

	CMappingDataContainer* container = GetContainerForItemIndex( iIndex, &startPos, &endPos );
	int localIndex = iIndex-startPos;

	// Create CECMapping object
	//
	CComObject<CECMapping> *pste;
	HRESULT hResult = CComObject<CECMapping>::CreateInstance(&pste);
	if (FAILED(hResult))
		return hResult;

	// retrieve the iIndex mapping item
	CInternalMappingData *idata;
	if ( container == NULL )
	{
		idata = NULL;
	}
	else
	{
		idata = container->at( localIndex );
	}

	// pull out the data from the item and populate the COM object
	//
	VARIANT vData;
	memset(&vData, 0, sizeof(vData) );
	vData.vt = VT_USERDEFINED;
	vData.byref = idata;

	pste->Init( &vData );
	pste->AddRef();

	*data = pste;

	END_BE_SAFE

	return hr;
}

STDMETHODIMP CParatextProjectProxy::SetECMapping(/*[in]*/ IECMapping* mapping)
{
	HRESULT hr = S_OK;

	CInternalMappingData *idata = NULL;
	bool success = false;
	bool okToDel = true;

	START_BE_SAFE( CParatextProjectProxy::SetECMapping );

	idata = ((CECMapping*)mapping)->InternalDataCopy();
	CMappingDataContainer* domainCont = GetContainerForDomain( idata->GetDomain() );

	bool existingID  = domainCont->FindID ( idata->GetCreatorID() );
	bool existingKey = domainCont->FindKey( idata->GetSBKey() );

	if ( existingKey )		// Update the mapping
	{
		success = domainCont->Update( idata );
	}
	else					// Add the mapping
	{
		success = domainCont->Add( idata );		// take over ownership of the idata ptr
		okToDel = !success;						// don't allow it to be removed
	}


	END_BE_SAFE

	if ( idata && okToDel )
		delete idata;

	if ( !success )
	{
		ATLTRACE("*** ERR: Mapping Not Added\n");
	}

	return S_OK;
}

STDMETHODIMP CParatextProjectProxy::DeleteMarker(/*[in]*/ BSTR bstrMarker)
{
	HRESULT hr = S_OK;
	bool removed = false;
	CInternalMappingData idata;

	START_BE_SAFE( CParatextProjectProxy::DeleteMarker );

	idata.SetBeginMarker( bstrMarker );
	long key = idata.GetSBKey();
	CMappingDataContainer *domainCont = GetContainerForDomain( idata.GetDomain() );
	removed = domainCont->RemoveKeyElement( key );
		
	END_BE_SAFE

	if ( !removed )
		return E_INVALIDARG;

	return hr;
}


STDMETHODIMP CParatextProjectProxy::DeleteECMapping(/*[in]*/ IECMapping* mapping)
{
	HRESULT hr = S_OK;
	bool removed = false;
	CInternalMappingData *idata = NULL;

	START_BE_SAFE( CParatextProjectProxy::DeleteECMapping );	// -------------

	idata = ((CECMapping*)mapping)->InternalDataCopy();
	long key = idata->GetSBKey();
	CMappingDataContainer *domainCont = GetContainerForDomain( idata->GetDomain() );
	removed = domainCont->RemoveKeyElement( key );

	END_BE_SAFE													// -------------

	if ( idata )
		delete idata;

	if ( !removed )
		return E_INVALIDARG;

	return hr;
}

STDMETHODIMP CParatextProjectProxy::InitializeFromSafeArray(/*[in]*/ VARIANT pSafeArrayOfBytes )
{
	START_BE_SAFE( CParatextProjectProxy::InitializeFromSafeArray )

	long LBnd, UBnd;
	SafeArrayGetLBound(V_ARRAY(&pSafeArrayOfBytes), 1, &LBnd);
	SafeArrayGetUBound(V_ARRAY(&pSafeArrayOfBytes), 1, &UBnd);

	long lsize = UBnd-LBnd+1;
	char *data = new char[lsize];
	unsigned char *pData = (unsigned char*)data;
	for (long li = LBnd; li <= UBnd; li++, pData++ )
	{
		SafeArrayGetElement(V_ARRAY(&pSafeArrayOfBytes), &li, pData );
	}

	CPersist persist(data, lsize );
	delete [] data;

	if ( !persist.HasError() )
	{
		ATLTRACE("**** Good archive, now pull data into object. ***\n");
		CParatextProjectProxy *projPtr = this;
		persist >> &projPtr;
	}

	if ( persist.HasError() )
	{
		ATLTRACE("*** Initialize called with invalid data: Default initialization preformed.\n" );
		Init();
	}

	END_BE_SAFE

	if ( HAD_EXCEPTION )
	{
		ATLTRACE( "### ERROR: Unable to initialize with data.  Default initialization preformed.\n" );
	}

	return S_OK;
}

STDMETHODIMP CParatextProjectProxy::get_NumberOfMappingsForDomain(/*[in]*/ MarkerDomain domain, /*[out,retval]*/ int* iCount)
{
	HRESULT hr = S_OK;

	START_BE_SAFE( CParatextProjectProxy::NumberOfMappingsForDomain );

	CMappingDataContainer *domainCont = GetContainerForDomain( domain );
	long lcount = domainCont->Size();

	*iCount = (int)(lcount);
	
	END_BE_SAFE

	return hr;
}

STDMETHODIMP CParatextProjectProxy::NthECMappingForDomain(/*[in]*/ MarkerDomain domain, /*[in]*/ int iIndex, /*[out]*/ IECMapping* *data)
{
	HRESULT hr = S_OK;

	START_BE_SAFE( CParatextProjectProxy::NthECMappingForDomain );

	CMappingDataContainer *domainCont = GetContainerForDomain( domain );

	// first check to see if the index is good
	//
	long count = domainCont->Size();
	if ( iIndex < 0 || iIndex >= count )
		return E_INVALIDARG;
	
	// Create CECMapping object
	//
	CComObject<CECMapping> *pste;
	HRESULT hResult = CComObject<CECMapping>::CreateInstance(&pste);
	if (FAILED(hResult))
		return hResult;

	// retrieve the iIndex mapping item
	//
	CInternalMappingData *idata = domainCont->at( iIndex );

	// pull out the data from the item and populate the COM object
	//
	VARIANT vData;
	memset(&vData, 0, sizeof(vData) );
	vData.vt = VT_USERDEFINED;
	vData.byref = idata;

	pste->Init( &vData );
	pste->AddRef();

	*data = pste;
	
	END_BE_SAFE

	return hr;
}


CMappingDataContainer* CParatextProjectProxy::GetContainerForDomain(MarkerDomain domain)
{
	CMappingDataContainer *domainCont = NULL;					// storage for container for the specified domain

	START_BE_SAFE( CParatextProjectProxy::GetContainerForDomain );
	
	long status_empty = m_DataCont.empty();
	TMapIDMappingContainerIT status_begin = m_DataCont.begin();
	TMapIDMappingContainerIT status_end = m_DataCont.end();

	TMapIDMappingContainerIT it = m_DataCont.find( domain );
	if ( it == m_DataCont.end() || m_DataCont.empty() )			// doesn't currently exist
	{
		domainCont = new CMappingDataContainer;					// create a new one
		m_DataCont[ domain ] = domainCont;						// associate it with this domain
	}
	else
	{
		domainCont = (*it).second;								// get the container for this domain
	}

	END_BE_SAFE

	if ( HAD_EXCEPTION )
	{
		OutputDebugString("***** Shouldn't have had an exception!!! CHECK INTO THIS>>>>  ****** \n");
	}

	return domainCont;											// shouldn't ever be NULL
}


CMappingDataContainer* CParatextProjectProxy::GetContainerForItemIndex(long index, long *startPos, long *endPos )
{
	long cPos = 0, ePos;
	CMappingDataContainer* container;

	START_BE_SAFE( CParatextProjectProxy::GetContainerForDomain );

	TMapIDMappingContainerIT it = m_DataCont.begin();
	if ( it == m_DataCont.end() || index < 0 )				// doesn't currently exist
		return NULL;
	
	do
	{
		container = (*it).second;							// get the container
		ePos = cPos + container->Size() -1;					// end position with this container
		if ( index <= ePos )
		{
			*startPos = cPos;
			*endPos	  = ePos;
			return container;
		}
		cPos = ePos+1;
		it++;
	}while(it != m_DataCont.end() );
	
	END_BE_SAFE

	if ( HAD_EXCEPTION )
	{
		OutputDebugString("***** Shouldn't have had an exception!!! CHECK INTO THIS>>>>  ****** \n");
	}

	return NULL;
}

long CParatextProjectProxy::AddMappingContainer( CMappingDataContainer* dataCont )
{
	long rval = 0;

	START_BE_SAFE( CParatextProjectProxy::AddMappingContainer );

	long numMappings = dataCont->Size();

	if ( numMappings > 0 )
	{
		CInternalMappingData *dataItem = dataCont->at(0);	// just pull first one off for domain value
		CMappingDataContainer* domainCont = GetContainerForDomain( dataItem->GetDomain() );

		for ( int i=0; i<numMappings; i++)
		{
			dataItem = dataCont->PopItem( 0 );		// pop the item from container
			domainCont->Add( dataItem );			// add it to the domain container
		}
		rval = numMappings;
	}


	END_BE_SAFE

	if ( HAD_EXCEPTION )
	{
		OutputDebugString("***** Shouldn't have had an exception!!! CHECK INTO THIS>>>>  ****** \n");
	}

	return rval;
}


STDMETHODIMP CParatextProjectProxy::ReadTEStyleFile(BSTR styFileName)
{
	long numStyles;

	if ( m_ECLibrary )
		m_ECLibrary->ReadInTEStyleNames( styFileName, &numStyles );

	return S_OK;
}

STDMETHODIMP CParatextProjectProxy::get_AreProjectsAccessible(long *pVal)
{
	*pVal = 0;

	BOOL fVal = false;

	get_IsValidProject(MD_Vern, &fVal);
	if (!fVal)
		*pVal |= MD_Vern;

	get_IsValidProject(MD_Back, &fVal);
	if (!fVal)
		*pVal |= MD_Back;

	get_IsValidProject(MD_Note, &fVal);
	if (!fVal)
		*pVal |= MD_Note;

	return S_OK;
}

long GetPTRegKey( char* strResult, DWORD *iResultLength )
{
	char *strSubkey = "SOFTWARE\\ScrChecks\\1.0\\Settings_Directory";
    HKEY hKey;

    long lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE, strSubkey, 0, KEY_QUERY_VALUE, &hKey );
    if( lRet == ERROR_SUCCESS )
	{
	    lRet = RegQueryValueEx( hKey, NULL, NULL, NULL, (LPBYTE) strResult, iResultLength);
//		if( (lRet == ERROR_SUCCESS) && (*iResultLength < 256) )
//		{
//			if (strResult[strlen(strResult)-1] != '\\')
//				strcat(strResult, "\\");
//		}
	    RegCloseKey( hKey );
	}
	return lRet;
}

STDMETHODIMP CParatextProjectProxy::get_IsValidProject(MarkerDomain projectDomain, BOOL *pVal)
{
	*pVal = false;
	char strResult[256];
	DWORD iResultLength = sizeof(strResult);

	LONG lRet = GetPTRegKey( (char*)strResult, &iResultLength );
	if( (lRet == ERROR_SUCCESS) && (iResultLength < 256) )
	{
		if (strResult[strlen(strResult)-1] != '\\')
			strcat(strResult, "\\");

		CComBSTR cbstrSpec = strResult;
		CComBSTR * pcbstrProjName = 0;

		switch (projectDomain)
		{
		case MD_Vern:
			if ( m_cbstrVernProj.Length() > 0 )
				pcbstrProjName = (CComBSTR *)&m_cbstrVernProj;
			else
				*pVal = true;	// only return false if project has a value, but isn't valid
			break;
		case MD_Back:
			if ( m_cbstrBackProj.Length() > 0)
				pcbstrProjName = (CComBSTR *)&m_cbstrBackProj;
			else
				*pVal = true;	// only return false if project has a value, but isn't valid
			break;
		case MD_Note:
			if ( m_cbstrNoteProj.Length() > 0)
				pcbstrProjName = (CComBSTR *)&m_cbstrNoteProj;
			else
				*pVal = true;	// only return false if project has a value, but isn't valid
			break;
		}

		try
		{
			if (pcbstrProjName)
			{
				cbstrSpec += *pcbstrProjName;
				cbstrSpec += L".ssf";
				if (( ::_waccess( cbstrSpec.m_str, 0 ) != -1 ) &&
					( ::_waccess( cbstrSpec.m_str, 4 ) != -1 ))
				{
					*pVal = true;
				}
			}
		}
		catch(...)
		{
			return E_FAIL;
		}
	}

	return S_OK;
}


STDMETHODIMP CParatextProjectProxy::GetProjectFilename(MarkerDomain md, BSTR * pbstrFilename)
{
	BOOL fOutSet = false;
	char strResult[256];
	DWORD iResultLength = sizeof(strResult);

	LONG lRet = GetPTRegKey( (char*)strResult, &iResultLength );
	if( (lRet == ERROR_SUCCESS) && (iResultLength < 256) )
	{
		if (strResult[strlen(strResult)-1] != '\\')
			strcat(strResult, "\\");

		CComBSTR cbstrSpec = strResult;
		CComBSTR * pcbstrProjName = 0;

		switch (md)
		{
		case MD_Vern:
			if ( m_cbstrVernProj.Length() > 0 )
				pcbstrProjName = (CComBSTR *)&m_cbstrVernProj;
			break;
		case MD_Back:
			if ( m_cbstrBackProj.Length() > 0)
				pcbstrProjName = (CComBSTR *)&m_cbstrBackProj;
			break;
		case MD_Note:
			if ( m_cbstrNoteProj.Length() > 0)
				pcbstrProjName = (CComBSTR *)&m_cbstrNoteProj;
			break;
		}

		if (pcbstrProjName)
		{
			cbstrSpec += *pcbstrProjName;
			cbstrSpec += L".ssf";
			*pbstrFilename = cbstrSpec.Copy();
			fOutSet = true;
		}
	}

	if (! fOutSet)
	{
		CComBSTR cbstrBlank = L"";
		*pbstrFilename = cbstrBlank.Copy();
	}

	return S_OK;
}

