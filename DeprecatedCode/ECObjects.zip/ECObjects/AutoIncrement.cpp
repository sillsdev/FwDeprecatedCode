// AutoIncrement.cpp: implementation of the CAutoIncrement class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AutoIncrement.h"


CRITICAL_SECTION CAutoIncrement::m_CS;
unsigned long	 CAutoIncrement::m_BaseID = 1;
unsigned long	 CAutoIncrement::m_ResetCount = 0;
bool			 CAutoIncrement::m_bInitDone = false;

//////////////////////////////////////////////////////////////////////
// Define some preprocessor short cuts
//////////////////////////////////////////////////////////////////////

#define TRY_START	try { EnterCriticalSection( &m_CS );
#define TRY_STOP	} catch (...) { AtlTrace("__**-- Exception in CAutoIncrement**\n"); } LeaveCriticalSection( &m_CS );

//////////////////////////////////////////////////////////////////////
// Static/Global class methods
//	static void Init();
//	static unsigned long RestartIDS();
//	static unsigned long GetNextID();
//////////////////////////////////////////////////////////////////////

void CAutoIncrement::Init()
{
	if ( !m_bInitDone )	// only do once for the life of the containing object(s)
	{
		InitializeCriticalSection( &m_CS );
		m_bInitDone = true;
	}
}

unsigned long CAutoIncrement::RestartIDS()
{
	Init();				// make sure the CS is active

	TRY_START

	m_ResetCount++;		// bump the reset count
	m_BaseID = 1;		// reset the base id value

	TRY_STOP

	return m_ResetCount;
}

unsigned long CAutoIncrement::GetNextID()
{
	Init();				// make sure the CS is active

	unsigned long rval = m_BaseID;

	TRY_START

	m_BaseID++;			// increment the class counter

	TRY_STOP

	return rval;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAutoIncrement::CAutoIncrement()
{
	SetID();	// set local ID based on global class counter
}

CAutoIncrement::~CAutoIncrement()
{
	if ( m_bInitDone )
	{
		DeleteCriticalSection( &m_CS );
		m_bInitDone = false;
	}
}

unsigned long CAutoIncrement::SetID()
{
	m_ID = GetNextID();
	return m_ID;
}
