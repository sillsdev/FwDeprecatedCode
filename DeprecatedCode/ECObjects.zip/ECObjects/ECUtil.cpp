/*-----------------------------------------------------------------------*//*:Ignore in Surveyor
Copyright (C) 2004 SIL International. All rights reserved.

Distributable under the terms of either the Common Public License or the
GNU Lesser General Public License, as specified in the LICENSING.txt file.

File: ECUtil.cpp
Responsibility: 
Last reviewed:

Description:
	This file contains Utility methods (gathered in the ECUtil namespace).
-------------------------------------------------------------------------------*//*:End Ignore*/

#include "stdafx.h"
#include "ECUtil.h"

/*----------------------------------------------------------------------------------------------
	Wrap the system WideCharToMultiByte function, defaulting to the UTF8 code page.
----------------------------------------------------------------------------------------------*/
char * ECUtil::WideToMultiByte( BSTR bstrIn, unsigned int codePage/*=CP_UTF8*/)
{
	char * pszData = NULL;
	unsigned int bufferSize = ::WideCharToMultiByte( codePage, 0, bstrIn,
		::SysStringLen( bstrIn ), NULL, 0, 0, 0 ) + 1;
	pszData = (char *)malloc( bufferSize );
	if (!pszData)
		return NULL;

	::WideCharToMultiByte(codePage, 0, bstrIn, ::SysStringLen( bstrIn ), pszData, bufferSize, 0,
		0);
	pszData[bufferSize-1] = 0;

	return pszData;
}

/*----------------------------------------------------------------------------------------------
	Wrap the system MultiByteToWideChar function, defaulting to the UTF8 code page.
----------------------------------------------------------------------------------------------*/
wchar_t * ECUtil::MultiByteToWide(const char * dataIn, int length,
	unsigned int codePage/*=CP_UTF8*/)
{
	wchar_t * pwszData = NULL;
	unsigned int bufferSize = ::MultiByteToWideChar(codePage, 0, dataIn, length, pwszData, 0)
		+ 1;
	pwszData = (wchar_t *)malloc( bufferSize * sizeof(wchar_t) );
	if (!pwszData)
		return NULL;

	::MultiByteToWideChar( codePage, 0, dataIn, length, pwszData, bufferSize ); 
	pwszData[bufferSize-1] = 0;

	return pwszData;
}

// Local Variables:
// compile-command:"cmd.exe /e:4096 /c c:\\FW\\Bin\\mkecob.bat"
// End: (These 3 lines are useful to Steve McConnel.)
