// MappingInfo.h : Declaration of the Mapping related classes

#ifndef __MAPPINGINFO_H_
#define __MAPPINGINFO_H_

#include "TraceCreation.h"

///#include <vector>
///#include <map>

#include "VectorOfPtrs.h"
#include "Persist.h"
#include "InternalMappingData.h"	// CInternalMappingData


class CMappingInfo;

typedef CVectorOfPtrs<CMappingInfo>		TVectorMappingInfo;
typedef TVectorMappingInfo::iterator	TVectorITMappingInfo;

typedef CVectorOfPtrs<CInternalMappingData>		TVectorInternalMappingData;
typedef TVectorInternalMappingData::iterator	TVectorITInternalMappingData;

void	copyIfExists	( char*  in, char** out );
void	deleteIfExists	( char** inOut );

/////////////////////////////////////////////////////////////////////////////
// CMarkerProperties
//
//	Attributes:
//	- Begin Marker
//	- End Marker
//	- Data Encoding
//	- Marker Encoding
//	- Inline
/////////////////////////////////////////////////////////////////////////////
class CMarkerProperties: public CTraceCreation
{
public:
	CMarkerProperties( char* beginMarker );
	CMarkerProperties( char* beginMarker, char* endMarker );
	CMarkerProperties( BSTR beginMarker );
	CMarkerProperties( BSTR beginMarker, BSTR endMarker );

	~CMarkerProperties();

	void SetMarkerEncoding	( char* in );
	void SetDataEncoding	( char* in );
	void SetInline( short in ){ m_bIsInline = in; }

	const char* GetMarkerEncoding()	{ return m_MarkerEncoding; }
	const char* GetDataEncoding()	{ return m_DataEncoding; }
	const char* GetMarker()			{ return m_Marker; }
	const char* GetEndMarker()		{ return m_EndMarker; }
	short		IsInline()			{ return m_bIsInline; }

	friend CPersist& operator<<( CPersist& stream, CMarkerProperties* data);
	friend CPersist& operator>>( CPersist& stream, CMarkerProperties** data);

private:
	char *m_MarkerEncoding;	// what encoding to use on the marker fields
	char *m_DataEncoding;	// what encoding to use on the data
	char *m_Marker;			// marker
	char *m_EndMarker;		// end marker
	short m_bIsInline;		// is inline marker
};

/////////////////////////////////////////////////////////////////////////////
// CMappingInfo

class CMappingInfo: public CTraceCreation
{
private:
	CMappingInfo();
public:
	CMappingInfo( CMarkerProperties* marker );
	~CMappingInfo();

	void AsBSTR( BSTR *out);

	void	SetDomain( int in ) { m_iDomain = in; }
	int		GetDomain()			{ return m_iDomain; }

	void	SetTEStyleName( BSTR in )	{ m_cbstrTEStyleName = in; }
	void	GetTEStyleName( BSTR* out)	{ *out = m_cbstrTEStyleName.Copy(); }

	void	SetCharEncoding( BSTR in );//	{ m_cbstrCharEncoding = in; }
	void	GetCharEncoding( BSTR* out)	{ *out = m_cbstrCharEncoding.Copy(); }

	BOOL	IsConfirmed() { return m_bConfirmed; }
	void	SetConfirmed() { m_bConfirmed = true; }

	CMarkerProperties* GetMarker() { return m_Marker; }

	static CMappingInfo* FromBSTR( wchar_t *wptr, int *outLength );

	friend CPersist& operator<<( CPersist& stream, CMappingInfo* data);
	friend CPersist& operator>>( CPersist& stream, CMappingInfo** data);

private:
	void SetMarker( CMarkerProperties* marker );

	CMarkerProperties *m_Marker;
	int		 m_iDomain;
	CComBSTR m_cbstrTEStyleName;
	CComBSTR m_cbstrCharEncoding;
	BOOL	 m_bConfirmed;
};

#endif

/////////////////////////////////////////////////////////////////////////////
