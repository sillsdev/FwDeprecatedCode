// Logger.cpp: implementation of the CLogger class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "time.h"		// time functions
#include "Logger.h"



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLogger* CLogger::m_Instance = NULL;

//////////////////////////////////////////////////////////////////////
// Singleton Instance method
//////////////////////////////////////////////////////////////////////
CLogger* CLogger::Instance()
{
	if (m_Instance == NULL)
	{
		m_Instance = new CLogger();
	}
	return m_Instance;
}


//////////////////////////////////////////////////////////////////////
// Static Shutdown method
//////////////////////////////////////////////////////////////////////
bool CLogger::Shutdown()
{
	if (m_Instance == NULL)
		return true;

	SetEvent(m_Instance->m_hShutdown);
	WaitForSingleObject( m_Instance->Done(), 10000000);	// wait upto 10 seconds
	
	delete m_Instance;
	m_Instance = NULL;
	return true;
}


//////////////////////////////////////////////////////////////////////
// Constructor
//
// Initialize the different events, CS and create the actual worker
// thread.
//////////////////////////////////////////////////////////////////////
CLogger::CLogger() : CWorkerThread()
{
	m_hShutdown = CreateEvent(NULL, false, false, NULL);	// shutdown event
	m_NewEntryEvent = CreateEvent(NULL, false, false, NULL);	

	char* fileName = new char[128];
	strcpy(fileName, "C:\\ProcessLogger.txt");

	DWORD dwThreadId, dwThrdParam = 1; 

	m_Thread = CreateThread( 
			NULL,                        // default security attributes 
			0,                           // use default stack size  
			ThreadMethod,                // thread function 
			fileName,                // argument to thread function 
			0,                           // use default creation flags 
			&dwThreadId);                // returns the thread identifier 

	if (m_Thread == NULL) 
	{
		char szMsg[80];
		wsprintf( szMsg, "CreateThread failed." ); 
		MessageBox( NULL, szMsg, "main", MB_OK );
	}
}


//////////////////////////////////////////////////////////////////////
// Destructor
//////////////////////////////////////////////////////////////////////
CLogger::~CLogger()
{
	CloseHandle(m_hShutdown);
	CloseHandle(m_NewEntryEvent);
}


//////////////////////////////////////////////////////////////////////
// GetPendingEntries
//
// Get a count of the number of pending entries to be put to the log.
//////////////////////////////////////////////////////////////////////
int CLogger::GetPendingEntries()
{
	int rval = 0;

	WT_START_BE_SAFE
	rval = m_vecLog.size();
	WT_END_BE_SAFE

	return rval;
}


//////////////////////////////////////////////////////////////////////
// AddLine - Add a line to the log file
//////////////////////////////////////////////////////////////////////
bool CLogger::AddLine(char* msg)
{
	CLogEntry *li = new CLogEntry(msg);

	bool rval = AddEntry(li);	// add the line
	if (!rval)					// didn't add
		delete li;				// release mem when not owned by container

	return rval;
}


//////////////////////////////////////////////////////////////////////
// AddEntry - Private method to create the actual log entry object
//	and add it to the vector, and set the event so that it can be
//	processed.
//////////////////////////////////////////////////////////////////////
bool CLogger::AddEntry(CLogEntry* pCLogEntry)
{
	bool rval = false;

	WT_START_BE_SAFE

	m_vecLog.push_back(pCLogEntry);
	SetEvent(m_NewEntryEvent);		// signal new entry to log
	rval = true;

	WT_END_BE_SAFE

	return rval;
}


//////////////////////////////////////////////////////////////////////
// GetEntry - Get the next entry from the list to put to the log file.
//////////////////////////////////////////////////////////////////////
int	 CLogger::GetEntry(CLogEntry** pCLogEntry)
{
	int rval = -1;

	WT_START_BE_SAFE

	if (m_vecLog.size() > 0 )
	{
		*pCLogEntry = m_vecLog.front();
		m_vecLog.erase( m_vecLog.begin() );	// remove from vec
		rval = m_vecLog.size();				// items remaining
	}
	else	// handle case where no entries in vec
	{
		pCLogEntry = NULL;
		rval = 0;
	}

	WT_END_BE_SAFE

	return rval;
}


//////////////////////////////////////////////////////////////////////
// AddTimeStamp - Put a date_time stamp at start of log line.
//////////////////////////////////////////////////////////////////////
void AddTimeStamp(char* buff)
{
	buff[0] = '<';
	_strdate(&buff[1]);
	buff[9] = '_';
	_strtime(&buff[10]);
	buff[18] = '>';
	buff[19] = ' ';
	buff[20] = '\0';
}


//////////////////////////////////////////////////////////////////////
// FormatLine
//////////////////////////////////////////////////////////////////////
void FormatLine(char* buff, CLogEntry* li)
{
	AddTimeStamp(buff);
	strcat(buff, li->Msg());
	strcat(buff, "\n");
}


//////////////////////////////////////////////////////////////////////
// FormatLine
//////////////////////////////////////////////////////////////////////
void FormatLine(char* buff, char *msg)
{
	AddTimeStamp(buff);
	strcat(buff, msg);
	strcat(buff, "\n");
}


//////////////////////////////////////////////////////////////////////
// FormatFirstLine
//////////////////////////////////////////////////////////////////////
void FormatFirstLine(char* buff)
{
#if 0
	AddTimeStamp(buff);
	strcat(buff, "----> Start: New Log\n");
#else
	AddTimeStamp(buff);
	strcat(buff, "----------------------------------\n");
	char *nLine = &buff[strlen(buff)];
	AddTimeStamp(nLine);
	strcat(buff, "-----      N E W   L O G     -----\n");
	nLine = &buff[strlen(buff)];
	AddTimeStamp(nLine);
	strcat(buff, "----------------------------------\n");
#endif
}


//////////////////////////////////////////////////////////////////////
// FormatLastLine
//////////////////////////////////////////////////////////////////////
void FormatLastLine(char* buff)
{
	AddTimeStamp(buff);
	strcat(buff, "----> End\n");
	char *nLine = &buff[strlen(buff)];
	AddTimeStamp(nLine);
	strcat(buff, "\n");
}


//////////////////////////////////////////////////////////////////////
// Static method that is used by the thread for processing.
//	** Real work done here **
//////////////////////////////////////////////////////////////////////
DWORD WINAPI CLogger::ThreadMethod( LPVOID lpParam ) 
{ 
	CLogger* log = CLogger::Instance();
	char* fileName = (char*)lpParam;

	FILE *fLog = fopen(fileName, "a+");

	char tmpLine[256];

	FormatFirstLine(tmpLine);
	fwrite(tmpLine, strlen(tmpLine), sizeof(char), fLog);

	DWORD dwCount = 2;
	DWORD dwWait;
	HANDLE pEvents[2] = { log->m_NewEntryEvent, log->m_hShutdown  };
	while (true)
	{
		dwWait = WaitForMultipleObjects(dwCount, pEvents, false, 1000);
		if (dwWait == WAIT_TIMEOUT)
		{
			if (fLog)
			{
				fclose(fLog);
				fLog = NULL;
			}
		}
		else if (dwWait == WAIT_OBJECT_0)	// New Entry
		{
			if (log->GetPendingEntries() > 0)
			{
				if (!fLog)
				{
					fLog = fopen(fileName, "a+");
				}

				CLogEntry *entryinfo;
				log->GetEntry(&entryinfo);

				FormatLine(tmpLine, entryinfo);
				delete entryinfo;	// release memory
				fwrite(tmpLine, strlen(tmpLine), sizeof(char), fLog);

				SetEvent(log->m_NewEntryEvent);	// make sure not another one waiting
			}
		}
		else
		{
			break;	// shutting down
		}
	}
	
	if (!fLog)
	{
		fLog = fopen(fileName, "a+");
	}

	if (fLog)
	{
//		FormatLastLine(tmpLine);
//		fwrite(tmpLine, strlen(tmpLine), sizeof(char), fLog);
		fclose(fLog);
	}

	delete[] fileName;

	SetEvent(log->Done());

    return 0; 
} 

/*
	Sample Log Entry:
03/09/04 17:58:24 **** Test ****
03/09/04 17:58:24 Test line of Data
03/09/04 17:58:24 Second test line of data
03/09/04 17:58:24 **** Exiting ****
03/09/04 18:03:24 **** Test ****
03/09/04 18:03:24 WM_PAINT message
03/09/04 18:03:24 Test line of Data
03/09/04 18:03:24 Second test line of data
03/09/04 18:03:29 WM_PAINT message
03/09/04 18:03:33 WM_PAINT message
03/09/04 18:03:34 **** Exiting ****
03/10/04 08:10:46 **** Test ****
03/10/04 08:10:46 WM_PAINT message
03/10/04 08:10:46 Test line of Data
03/10/04 08:10:46 Second test line of data
03/10/04 08:10:51 WM_PAINT message
03/10/04 08:10:53 WM_COMMAND message
03/10/04 08:10:53 WM_DESTROY message
03/10/04 08:10:53 **** Exiting ****


	[02/03/04 08:33:27] ***** ProcessTracker Started *****
	02/03/2004 - 08:33:27 Tracking: asdf, qwerqw, zsdare
	02/03/2004 - 08:33:28 Currently Active: asdf
	02/03/2004 - 10:11:02 Started: qwerqw (1)
	02/03/2004 - 10:45:47 Stopped: qwerqw (1-00:34:45)
	 .... 
	 .... 
	 .... 
	02/03/2004 - 10:45:47 Stopped: qwerqw (6-00:04:12)
	02/03/2004 - 22:12:57 Finial Daily Statistics
	02/03/2004 - 22:12:57  qwerqw (6 instances, TTL Time: 5:32:16, Avg Time: 0:55:23)
	02/03/2004 - 22:12:57  asdf (2 instances, TTL Time: :11:11, Avg Time: 0:5:53)
	02/03/2004 - 22:12:57  zsdare (0 instances)
	02/03/2004 - 22:12:57 ***** ProcessTracker Stopping *****

*/