// AutoIncrement.h: interface for the CAutoIncrement class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUTOINCREMENT_H__539C0A5E_C052_49B6_A1EF_18E96AAEE706__INCLUDED_)
#define AFX_AUTOINCREMENT_H__539C0A5E_C052_49B6_A1EF_18E96AAEE706__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAutoIncrement  
{
public:
	CAutoIncrement();
	virtual ~CAutoIncrement();
	unsigned long GetID() { return m_ID; }

	// Static methods...
	static void Init();
	static unsigned long RestartIDS();
	static unsigned long GetNextID();

private:
	// local class private methods
	unsigned long SetID();

	// local class variables
	unsigned long m_ID;

	// global class variables
	static unsigned long m_BaseID;
	static unsigned long m_ResetCount;
	static CRITICAL_SECTION m_CS;
	static bool m_bInitDone;


};

#endif // !defined(AFX_AUTOINCREMENT_H__539C0A5E_C052_49B6_A1EF_18E96AAEE706__INCLUDED_)
