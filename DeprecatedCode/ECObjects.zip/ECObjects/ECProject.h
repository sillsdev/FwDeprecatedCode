// ECProject.h : Declaration of the CECProject

#ifndef __ECPROJECT_H_
#define __ECPROJECT_H_

#include "resource.h"       // main symbols

#include <vector>
#include <map>
#include <string>

#include "MappingInfo.h"
#include "VectorOfPtrs.h"		// template for std::vector with good cleanup

#include "Persist.h"
#include "InternalMappingData.h"	// data object that contains all mapping information
#include "MappingDataContainer.h"	// container for managing internal mapping data items
#include "InternalProjectFileInfo.h"	// data object that contains all file info for each file

class CCharPtr : public CTraceCreation
{
private:
	CCharPtr();
public:
	CCharPtr( char* in ) : CTraceCreation("CCharPtr") { m_Ptr = new char[strlen(in)+1]; strcpy(m_Ptr, in); }
	~CCharPtr() { delete [] m_Ptr; }
	const char* cptr() { return m_Ptr; }
private:
	char* m_Ptr;
};
/////////////////////////////////////////////////////////////////////////////
// CECProject

typedef std::map<long, CInternalMappingData*> TMapIDMappingPtrs;	// 3/03 new data model
typedef TMapIDMappingPtrs::iterator TMapITIDMappingPtrs;			// 3/03 new data model

typedef struct {
	int count;
	bool bInline;
} TMappingInfo;

typedef CVectorOfPtrs<CCharPtr>		TVectorCharPtrs;
typedef TVectorCharPtrs::iterator	TVectorITCharPtrs;

typedef std::map<std::string/*CCharPtr* */, int>	TMapCharPtrsAndInts;
typedef TMapCharPtrsAndInts::iterator TMapITCharPtrsAndInts;

typedef std::map<std::string, TMappingInfo>	TMapStringAndInfo;
typedef TMapStringAndInfo::iterator TMapITStringAndInfo;

typedef std::vector<boolean>		TVectorBoolean;
typedef TVectorBoolean::iterator	TVectorITBoolean;

typedef std::vector<CComBSTR>		TVectorComBSTR;
typedef TVectorComBSTR::iterator	TVectorITComBSTR;

typedef std::map<CComBSTR, int>		TMapComBSTRtoInt;
typedef TMapComBSTRtoInt::iterator	TMapITComBSTRtoInt;

typedef std::vector<CInternalProjectFileInfo*>	TVectorFileInfo;
typedef TVectorFileInfo::iterator	TVectorITFileInfo;

/////////////////////////////////////////////////////////////////////////////
// CECProject
class ATL_NO_VTABLE CECProject : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CECProject, &CLSID_ECProject>,
	public ISupportErrorInfo,
	public CTraceCreation,
	public IDispatchImpl<IECProject, &IID_IECProject, &LIBID_ECOBJECTSLib>

{
public:
	CECProject();
	virtual ~CECProject();

DECLARE_REGISTRY_RESOURCEID(IDR_ECPROJECT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CECProject)
	COM_INTERFACE_ENTRY(IECProject)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IECProject
public:
	STDMETHOD(GetFileInfo)(/*[in]*/ BSTR fileName, /*[out]*/ IECProjectFileInfo* *data);
	STDMETHOD(get_AutoDeleteTempFiles)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_AutoDeleteTempFiles)(/*[in]*/ BOOL newVal);
	STDMETHOD(DeleteOutputFiles)();
	STDMETHOD(get_MappingInfoSafeArray)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_FilePropertyInfoSafeArray)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(UpdateFileEncoding)(/*[in]*/ BSTR fileName, /*[in]*/ EC_FileEncoding fileEC);
	STDMETHOD(AddFileGetEncoding)(/*[in]*/ BSTR fileName, /*[out]*/ EC_FileEncoding* fileEC, /*[out]*/ long* percentCertian);
	STDMETHOD(get_DefaultAnalWritingSystem)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_DefaultAnalWritingSystem)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_DefaultVernWritingSystem)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_DefaultVernWritingSystem)(/*[in]*/ BSTR newVal);
	STDMETHOD(IsFileAccessible)(/*[in]*/BSTR bstrFileName, /*[out]*/ BOOL *isAccessible);
	STDMETHOD(get_DefaultSTYFileName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_DefaultSTYFileName)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_DefaultSSFFileName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_DefaultSSFFileName)(/*[in]*/ BSTR newVal);
	STDMETHOD(ValidateSafeArray)(/*[in]*/ VARIANT pSafeArrayOfBytes, /*[out]*/ BOOL* isValid );
	STDMETHOD(get_LibraryObject)(/*[out, retval]*/ IECLibrary* *pVal);
	STDMETHOD(BuildSOProjectFiles)();	// BSTR bstrSSFPathName, BSTR bstrSTYPathName);
///	STDMETHOD(ReadTEStyleFile)(/*[in]*/ BSTR styFileName);

	STDMETHOD(ConvertProject)(/*[out]*/ BSTR *bstrDoneEventName);


///	STDMETHOD(get_EncodingNames)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(DeleteMarker)(/*[in]*/ BSTR bstrMarker);
	STDMETHOD(DeleteECMapping)(/*[in]*/ IECMapping* mapping);
	STDMETHOD(get_AsSafeArray)(/*[out, retval]*/ VARIANT *pVal);
	void FinalRelease() {};

///	STDMETHOD(Initialize)(/*[in]*/ BSTR* bstrBlob);
	STDMETHOD(InitializeFromSafeArray)(/*[in]*/ VARIANT pSafeArrayOfBytes );
///	STDMETHOD(Save)(/*[out]*/ BSTR* bstrBlob, /*[out]*/ BSTR* bstrToken);
	STDMETHOD(AddFile)(/*[in]*/ BSTR bstrFileName);
	STDMETHOD(RemoveFile)(/*[in]*/ BSTR bstrFileName);
	STDMETHOD(get_Files)(/*[out,retval]*/ VARIANT* pSafeArray);
///	STDMETHOD(get_StyleNames)(/*[out, retval]*/ VARIANT* pSafeArray);

	STDMETHOD(get_BookMarker)(/*[out,retval]*/ BSTR* bstrBookMarker)
	{
		*bstrBookMarker = m_cbstrBookMarker.Copy();
		return S_OK;
	}
	STDMETHOD(put_BookMarker)(/*[in]*/ BSTR bstrBookMarker)
	{
		m_cbstrBookMarker = bstrBookMarker;
		return S_OK;
	}

	STDMETHOD(get_BinaryDirectory)(/*[out, retval]*/ BSTR *pVal)
	{
		*pVal = m_cbstrBinDir.Copy();
		return S_OK;
	}

	STDMETHOD(put_BinaryDirectory)(/*[in]*/ BSTR newVal)
	{
		m_cbstrBinDir = newVal;
		return S_OK;
	}
	
	STDMETHOD(get_DefaultDataEncoding)(/*[out,retval]*/ BSTR* bstrEncoding )
	{
		*bstrEncoding = m_cbstrDataEncoding.Copy();
		return S_OK;
	}
	STDMETHOD(put_DefaultDataEncoding)(/*[in]*/ BSTR bstrEncoding )
	{
		m_cbstrDataEncoding = bstrEncoding;
		return S_OK;
	}

	STDMETHOD(get_DefaultMarkerEncoding)(/*[out,retval]*/ BSTR* bstrEncoding )
	{
		*bstrEncoding = m_cbstrMarkerEncoding.Copy();
		return S_OK;
	}
	STDMETHOD(put_DefaultMarkerEncoding)(/*[in]*/ BSTR bstrEncoding )
	{
		m_cbstrMarkerEncoding = bstrEncoding;
		return S_OK;
	}


	STDMETHOD(get_NumberOfMappings)(/*[out,retval]*/ int* iCount);
	STDMETHOD(get_NumberOfFiles)(/*[out,retval]*/ int* iCount);

#if 0
	STDMETHOD(NthMapping)(
		/*[in] */ int iIndex, 
		/*[out]*/ BSTR* pbstrMarker,
		/*[out]*/ MarkerDomain* piDomain,
		/*[out]*/ BSTR* pbstrTeStyleName,
		/*[out]*/ BSTR* pbstrEncoding,
		/*[out]*/ BOOL* bConfirmed
		);

	STDMETHOD(SetMapping)(
		/*[in]*/ BSTR pbstrMarker,
		/*[in]*/ MarkerDomain piDomain,
		/*[in]*/ BSTR pbstrTeStyleName,
		/*[in]*/ BSTR pbstrEncoding
		);
#endif

	STDMETHOD(GetBooksForFile)( 
		/*[in]*/ BSTR bstrFileName,				// "fullpath and filename of file"
		/*[out,retval]*/ VARIANT* pSafeArray	// safearray of shorts where 1 == GEN
		);

	STDMETHOD(debugShowObjects)();

	STDMETHOD(NthECMapping)(/*[in]*/ int iIndex, /*[out]*/ IECMapping* *data);
	STDMETHOD(SetECMapping)(/*[in]*/ IECMapping* mapping);


//	short AddFilePathOnly(BSTR bstrFileName);	// zero if added, otherwise error code
	short AddFileInfo( CInternalProjectFileInfo* pfi );

private:
	BSTR* GetTEStyleFromBeginMarker( char * beginMarker);
	bool	Test();
	long	BuildConvertXML( BSTR *bstrOut );
	void	Init();
	
	void	AddMapping( char* marker, char* endMarker="", bool bInline=false );

	bool	IsValidFile( BSTR bstrFileName );
	bool	MarkerAlreadyExists( char *marker );

	void	RemoveTempFiles();
	void	SaveToString( BSTR* archive );
///	HRESULT	RestoreFromString( BSTR archive );

	friend CPersist& operator<<( CPersist& stream, CECProject* data);
	friend CPersist& operator>>( CPersist& stream, CECProject** data);

	CComBSTR	m_cbstrSSFName;					// current value for SSF file name
	CComBSTR	m_cbstrSTYName;					// current value for STY file name

	CComBSTR	m_cbstrUserSSFName;			// user set .ssf file name
	CComBSTR	m_cbstrUserSTYName;			// user set .sty file name
	CComBSTR	m_cbstrTempSSFName;				// generated temp file name
	CComBSTR	m_cbstrTempSTYName;				// generated temp file name

	CComBSTR	m_cbstrDefaultVernWritingSystem;
	CComBSTR	m_cbstrDefaultAnalWritingSystem;

	CComBSTR	m_cbstrBookMarker;				// marker for book '\id'
	CComBSTR	m_cbstrDataEncoding;			// default data encoding
	CComBSTR	m_cbstrMarkerEncoding;			// default marker encoding
	CComBSTR	m_cbstrBinDir;					// m_cbstrRootDir + "\\Python\\"
	CComBSTR	m_cbstrRootDir;					// fieldworks registry setting

	TVectorFileInfo		m_vFileInfo;			// all file information 9/03 NEW

	CRITICAL_SECTION	m_csBusy;
	TMapCharPtrsAndInts m_mapMarkers;


	char*	m_Escape;		// "\\" by default...

	boolean	m_bDirtyFiles;
	boolean m_bDirty;
	BOOL	m_AutoDelete;

	CMappingDataContainer	*m_dataCont;

	HANDLE	m_DoneConvertEvent;

	IECLibrary2* m_ECLibrary;

};

#endif //__ECPROJECT_H_
