//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ECObjects.rc
//
#define IDS_PROJNAME                    100
#define IDR_ECPROJECT                   101
#define IDR_PARATEXTPROJECTPROXY        102
#define IDR_ECMAPPING                   104
//#define IDR_ECMAPPINGRO                 105
#define IDS_ECLIBRARY_DESC              106
#define IDR_ECLibrary                   107
#define IDR_ECFILEINFO                  108
#define IDR_ECPROJECTFILEINFO           110
//#define IDC_CURSOR1                     202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
