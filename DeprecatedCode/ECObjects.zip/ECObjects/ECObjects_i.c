

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Fri Jul 29 16:12:08 2005
 */
/* Compiler settings for ECObjects.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if !defined(_M_IA64) && !defined(_M_AMD64)


#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IECProjectFileInfo,0x90AFA6B6,0xA6E8,0x4173,0xB2,0x03,0x2C,0x50,0xBD,0x70,0x58,0x09);


MIDL_DEFINE_GUID(IID, IID_IECLibrary,0x99A8744D,0xD5A9,0x4CF0,0x90,0x08,0xAE,0xB8,0x7A,0x69,0x27,0xAD);


MIDL_DEFINE_GUID(IID, IID_IECLibrary2,0x380FBC38,0xA844,0x4105,0xAC,0x6F,0x8B,0x28,0x32,0xA1,0x4E,0xEB);


MIDL_DEFINE_GUID(IID, IID_IECMapping,0xE4A8ED4D,0xA50D,0x49CE,0x99,0x57,0xFC,0x4D,0xDF,0x4D,0xB2,0x5D);


MIDL_DEFINE_GUID(IID, IID_IECProject,0xFE4BE80A,0x389F,0x41E7,0x8A,0xCE,0x72,0xA4,0x3B,0xD4,0x03,0xDD);


MIDL_DEFINE_GUID(IID, IID_IParatextProjectProxy,0x223239CA,0x3A0C,0x49AF,0xA0,0xC2,0xFA,0x14,0x01,0x89,0x6A,0x8B);


MIDL_DEFINE_GUID(IID, LIBID_ECOBJECTSLib,0xE2E34538,0x39FF,0x432F,0xB2,0xCA,0x57,0xB9,0x7F,0xBE,0xCE,0x48);


MIDL_DEFINE_GUID(CLSID, CLSID_ECProject,0x301B5DCF,0xE1D9,0x48E7,0xA8,0xB8,0xCB,0x1C,0xD9,0xB1,0x36,0x3E);


MIDL_DEFINE_GUID(CLSID, CLSID_ParatextProjectProxy,0x1D1B84F6,0x6987,0x4220,0x95,0xE7,0x91,0xBE,0x1F,0xD9,0xFC,0x8D);


MIDL_DEFINE_GUID(CLSID, CLSID_ECMapping,0xB2A3DAB6,0xF2BB,0x4C13,0xA7,0xA4,0x01,0xE4,0x70,0x8D,0x1C,0xC0);


MIDL_DEFINE_GUID(CLSID, CLSID_ECLibrary,0x5960765D,0x65E0,0x4223,0x97,0xCD,0x62,0xBE,0x9C,0xFF,0xAF,0xB1);


MIDL_DEFINE_GUID(CLSID, CLSID_ECProjectFileInfo,0xC924DB3B,0x065D,0x4277,0x81,0x58,0x64,0xC0,0x54,0x18,0xDF,0xC5);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



#endif /* !defined(_M_IA64) && !defined(_M_AMD64)*/

