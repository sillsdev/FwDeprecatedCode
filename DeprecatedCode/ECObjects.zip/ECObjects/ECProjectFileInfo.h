// ECProjectFileInfo.h : Declaration of the CECProjectFileInfo

#ifndef __ECPROJECTFILEINFO_H_
#define __ECPROJECTFILEINFO_H_


#include "resource.h"       // main symbols
#include "InternalProjectFileInfo.h"
#include "TraceCreation.h"


/////////////////////////////////////////////////////////////////////////////
// CECProjectFileInfo
class ATL_NO_VTABLE CECProjectFileInfo : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CECProjectFileInfo, &CLSID_ECProjectFileInfo>,
	public ISupportErrorInfo,
	public CTraceCreation,
	public IDispatchImpl<IECProjectFileInfo, &IID_IECProjectFileInfo, &LIBID_ECOBJECTSLib>
{
public:
	CECProjectFileInfo() : CTraceCreation("CECProjectFileInfo") {}
	virtual ~CECProjectFileInfo() {	OutputDebugString("~CECProjectFileInfo()\n"); }


DECLARE_REGISTRY_RESOURCEID(IDR_ECPROJECTFILEINFO)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CECProjectFileInfo)
	COM_INTERFACE_ENTRY(IECProjectFileInfo)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IECProjectFileInfo
public:
	STDMETHOD(get_HasBOM)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(Init)(VARIANT* myData);
	STDMETHOD(get_FileEncodingSource)(/*[out, retval]*/ EC_FileEncodingSource *pVal);
	STDMETHOD(get_SurenessPercent)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_SurenessPercent)(/*[in]*/ short newVal);
	STDMETHOD(get_OutputFileName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_OutputFileName)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_InputFileName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_InputFileName)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_FileEncoding)(/*[out, retval]*/ EC_FileEncoding *pVal);
	STDMETHOD(put_FileEncoding)(/*[in]*/ EC_FileEncoding newVal);

private:
	CInternalProjectFileInfo m_Data;
};

#endif //__ECPROJECTFILEINFO_H_
