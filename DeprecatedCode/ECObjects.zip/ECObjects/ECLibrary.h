// ECLibrary.h: Definition of the ECLibrary class
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ECLIBRARY_H__205090AF_52B9_4A7A_BD31_72DC9A81904F__INCLUDED_)
#define AFX_ECLIBRARY_H__205090AF_52B9_4A7A_BD31_72DC9A81904F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"       // main symbols
#include <map>
#include <string>

#include "TraceCreation.h"

typedef std::map< CComBSTR, CComBSTR > TTEStyleMap;	// begin marker, te style name
typedef TTEStyleMap::iterator TTEStyleMapIT;
typedef TTEStyleMap TSOMarkerInfo;					// begin marker, concatenated SO properties
typedef TSOMarkerInfo::iterator TSOMarkerInfoIT;

/////////////////////////////////////////////////////////////////////////////
// ECLibrary

class ECLibrary : 
	public IDispatchImpl<IECLibrary2, &IID_IECLibrary2, &LIBID_ECOBJECTSLib>, 
	public ISupportErrorInfo,
	public CComObjectRoot,
	public CTraceCreation,
	public CComCoClass<ECLibrary,&CLSID_ECLibrary>
{
public:
	ECLibrary();
	~ECLibrary();

BEGIN_COM_MAP(ECLibrary)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IECLibrary)
	COM_INTERFACE_ENTRY(IECLibrary2)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()
//DECLARE_NOT_AGGREGATABLE(ECLibrary) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation. 

DECLARE_REGISTRY_RESOURCEID(IDR_ECLibrary)
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IECLibrary2
public:
	STDMETHOD(GetScriptureRefBounds2)(
		BSTR fileName, 
		BSTR origFileName, 
		BSTR bookMarker, 
		BSTR chapterMarker,
		BSTR verseMarker, 
		/*[out]*/ BSTR* startRef, 
		/*[out]*/ BSTR* endRef);


// IECLibrary
public:
	STDMETHOD(GuessFileEncoding)(/*[in]*/ BSTR fileName, /*[out]*/ EC_FileEncoding* guess,
		/*[out]*/ EC_FileEncodingSource* src, /*[out]*/ long *percentCertian);
	STDMETHOD(GetScriptureRefBounds)(BSTR fileName, BSTR bookMarker, BSTR chapterMarker,
		BSTR verseMarker, /*[out]*/ BSTR* startRef, /*[out]*/ BSTR* endRef);
	STDMETHOD(ReadInTEStyleNames)(/*[in]*/ BSTR styFile, /*[out]*/ long *numStyles);
	STDMETHOD(get_TEStyleName)(/*[in]*/ BSTR beginMarker, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(MakeSOStyleFile)(/*[in]*/ BSTR fName, /*[in]*/ VARIANT pSafeArray);
	STDMETHOD(TestSO)();
	STDMETHOD(get_MarkerDomainAsBSTR)(/*[in]*/ int domainID, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_MarkerDomainInts)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_MarkerDomainNames)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_EncodingNames)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_StyleNames)(/*[out, retval]*/ VARIANT *pVal);

	STDMETHOD(get_SOMarkerFields)(/*[in]*/ BSTR beginMarker, /*[out, retval]*/ BSTR *pVal);

	STDMETHOD(get_BeginMarkerForStyleName)(/*[in]*/ BSTR teStyleName,
		/*[out, retval]*/ BSTR *pVal);
	
	short ReadSOStyles( char *styFileName );

private:

	// throws exception "HR"
	void ThrowError(HRESULT hr, const std::string &book, const std::string & chapter, const std::string &verse,
		 BSTR fileName, int lineNumber);

	short CleanTEStyleMap();
	short CleanSOMarkersMap();
	TTEStyleMap	m_TEStyles;
	TSOMarkerInfo m_SOMarkers;
};

#endif // !defined(AFX_ECLIBRARY_H__205090AF_52B9_4A7A_BD31_72DC9A81904F__INCLUDED_)
