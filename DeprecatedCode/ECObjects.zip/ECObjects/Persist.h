// Persist.h: interface for the CPersist class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PERSIST_H__BD25DCC0_6815_4F2B_A4CB_14156509C66D__INCLUDED_)
#define AFX_PERSIST_H__BD25DCC0_6815_4F2B_A4CB_14156509C66D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <strstream>

class CBinaryData
{
private:
	CBinaryData();

public:
	CBinaryData( const char* data, bool deepCopy=true );
	CBinaryData( const char* data, long size, bool deepCopy=true );
	~CBinaryData();

	CBinaryData& operator=( const CBinaryData& ref );

	const char*	Data()	{ return m_Data; }
	long		Size()	{ return m_Size; }

private:
	bool  m_DeepCopy;
	char* m_Data;
	long  m_Size;
};

class CPersist  
{
public:
	CPersist();
	CPersist( char* dataIn, long length );

	virtual ~CPersist();

	//	One Byte that gives Type and Value information:
	//	Ex:
	//		Short == to zero	>> 0x21
	//		Short == to 6		>> 0x20 0x00 0x06
	//		Long  == to 16		>> 0x30 0x00 0x00 0x00 0x10
	//		Empty BSTR			>> 0x52
	//

	enum DataType  { DT_BYTE=0x10, DT_SHORT=0x20, DT_LONG=0x30, DT_BINARY=0x40, DT_BSTR=0x50, DT_CHARSTR=0x60 };
	enum DataValue { DV_ZERO=0x01, DV_EMPTY=0x02 };
	enum ErrorType { ET_NONE=0x00, ET_WRONG_TYPE, ET_BAD_INIT, ET_OTHER };

	static long Encode( short dataIn, unsigned char **outBuffer, long outBufferLen );	// returns the #bytes added to outBuffer
	static long Encode( long  dataIn, unsigned char **outBuffer, long outBufferLen );
	static long Encode( BSTR  dataIn, unsigned char **outBuffer, long outBufferLen );

	static long Encode( const unsigned char *dataIn, long dataInLen, unsigned char **outBuffer, long outBufferLen );


	CPersist& operator <<( short dataIn);
	CPersist& operator <<( long dataIn);
	CPersist& operator <<( CBinaryData *binData);
	CPersist& operator <<( BSTR* bstrData);
	CPersist& operator <<( char* cptr);
	CPersist& operator <<( int dataIn)			{ return this->operator<<((long)dataIn); }
	CPersist& operator <<( const char* dataIn)	{ return this->operator<<((char*)dataIn); }


	CPersist& operator >>( short& dataIn);
	CPersist& operator >>( long& dataIn);
	CPersist& operator >>( CBinaryData& binData);
	CPersist& operator >>( BSTR* bstrData);
	CPersist& operator >>( char** cptr);
//	CPersist& operator >>( int& dataIn)			{ return this->operator>>((long&)dataIn); }
//	CPersist& operator >>( const char** dataIn)	{ return this->operator>>((char**)dataIn); }


	const char* ReadOnlyBuffer();
	long		ReadOnlyBufferSize(){ return m_DataLength; }
	
	ErrorType	GetError()			{ return m_Error; }
	bool		HasError()			{ return m_Error != ET_NONE; }

	long		CalcCRC();
	long		Size()		{ return m_DataLength; }
	short		Version()	{ return 0x0102; }

	void		SetError( ErrorType et )	{ m_Error = et; }

	long		GetCurrentReadPosition()				{ return m_ReadPos; }
	void		SetCurrentReadPosition( long inVal )	{ m_ReadPos = inVal; }

private:

	// Helper functions...

	long		GrowBuffer( long minSize );

	CPersist&	DataEqualsZero	 ( DataType dt );
	CPersist&	NoData			 ( DataType dt );
	CPersist&	ProcessBinaryData( DataType dt, CBinaryData *binData);

	CBinaryData*	ReadKnownData( DataType dt );


	ErrorType	m_Error;

	char *	m_Data;					// buffer
	long	m_DataSize;				// size of buffer
	long	m_DataLength;			// length of data in buffer
	long	m_ReadPos;				// position of the read pointer

	const long m_ChunkSize;			// size to bump buffer when needed

	std::strstream	m_strStream;
};

#endif // !defined(AFX_PERSIST_H__BD25DCC0_6815_4F2B_A4CB_14156509C66D__INCLUDED_)
