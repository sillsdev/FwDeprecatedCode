// ParatextProjectProxy.h : Declaration of the CParatextProjectProxy

#ifndef __PARATEXTPROJECTPROXY_H_
#define __PARATEXTPROJECTPROXY_H_

#include "resource.h"       // main symbols

#include "MappingInfo.h"
#include "Persist.h"
#include "MappingDataContainer.h"	// container for managing internal mapping data items


typedef std::map<long, CMappingDataContainer*>	TMapIDMappingContainer;
typedef TMapIDMappingContainer::iterator		TMapIDMappingContainerIT;


/////////////////////////////////////////////////////////////////////////////
// CParatextProjectProxy
class ATL_NO_VTABLE CParatextProjectProxy : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CParatextProjectProxy, &CLSID_ParatextProjectProxy>,
	public ISupportErrorInfo,
	public CTraceCreation,
	public IDispatchImpl<IParatextProjectProxy, &IID_IParatextProjectProxy, &LIBID_ECOBJECTSLib>
{
public:
	CParatextProjectProxy();
	~CParatextProjectProxy();


DECLARE_REGISTRY_RESOURCEID(IDR_PARATEXTPROJECTPROXY)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CParatextProjectProxy)
	COM_INTERFACE_ENTRY(IParatextProjectProxy)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IParatextProjectProxy
public:
	STDMETHOD(RefreshDomainMarkers)(MarkerDomain domain);
	STDMETHOD(GetProjectFilename)(/*[in]*/ MarkerDomain md, /*[in out]*/ BSTR * bstrFilename);
	STDMETHOD(get_IsValidProject)(MarkerDomain projectDomain, /*[out, retval]*/ BOOL *pVal);
	STDMETHOD(get_AreProjectsAccessible)(/*[out, retval]*/ long *pVal);
	STDMETHOD(ReadTEStyleFile)(BSTR styFileName);
	STDMETHOD(get_AsSafeArray)(/*[out, retval]*/ VARIANT *pVal);
///	STDMETHOD(Initialize)(/*[in]*/ BSTR* bstrBlob);
///	STDMETHOD(Save)(/*[out]*/ BSTR* bstrBlob, /*[out]*/ BSTR* bstrToken);

	STDMETHOD(get_VernTransProj)(/*[out, retval]*/ BSTR* pt6Project);
	STDMETHOD(put_VernTransProj)(/*[in]*/ BSTR pt6Project);
	STDMETHOD(get_BackTransProj)(/*[out, retval]*/ BSTR* pt6Project);
	STDMETHOD(put_BackTransProj)(/*[in]*/ BSTR pt6Project);
	STDMETHOD(get_NotesTransProj)(/*[out, retval]*/ BSTR* pt6Project);
	STDMETHOD(put_NotesTransProj)(/*[in]*/ BSTR pt6Project);

	STDMETHOD(get_DefaultAnalWritingSystem)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_DefaultAnalWritingSystem)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_DefaultVernWritingSystem)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_DefaultVernWritingSystem)(/*[in]*/ BSTR newVal);

	STDMETHOD(get_NumberOfMappings)(/*[out,retval]*/ int* iCount);

	// 4/14 added for compatibility with the SFProject interface
	STDMETHOD(NthECMapping)(/*[in]*/ int iIndex, /*[out]*/ IECMapping* *data);
	STDMETHOD(SetECMapping)(/*[in]*/ IECMapping* mapping);
	STDMETHOD(DeleteMarker)(/*[in]*/ BSTR bstrMarker);
	STDMETHOD(DeleteECMapping)(/*[in]*/ IECMapping* mapping);
	STDMETHOD(InitializeFromSafeArray)(/*[in]*/ VARIANT pSafeArrayOfBytes );

	STDMETHOD(get_NumberOfMappingsForDomain)(/*[in]*/ MarkerDomain domain, /*[out,retval]*/ int* iCount);
	STDMETHOD(NthECMappingForDomain)(/*[in]*/ MarkerDomain domain, /*[in]*/ int, /*[out]*/ IECMapping* *data);


private:
	CMappingDataContainer* GetContainerForItemIndex(long index, long *startPos, long *endPos );
	CMappingDataContainer* GetContainerForDomain( MarkerDomain domain);

	friend CPersist& operator<<( CPersist& stream, CParatextProjectProxy* data);
	friend CPersist& operator>>( CPersist& stream, CParatextProjectProxy** data);

	void		Init();
	void		SaveToString( BSTR* archive );
	short		FindMapping( const BSTR* /*char**/ InMarker, MarkerDomain domain );

	long		AddMappingContainer( CMappingDataContainer* dataCont );

	HRESULT		SetDomainProject( BSTR project, MarkerDomain domain, CComBSTR* projString, bool cleanStart=true );
	HRESULT		SetDomainProjectNameOnly( BSTR project, MarkerDomain domain);

	CRITICAL_SECTION	m_csBusy;

	CComBSTR	m_cbstrVernProj;
	CComBSTR	m_cbstrBackProj;
	CComBSTR	m_cbstrNoteProj;

	CComBSTR	m_cbstrDefaultVernWritingSystem;
	CComBSTR	m_cbstrDefaultAnalWritingSystem;

	TMapIDMappingContainer	m_DataCont;
	IECLibrary* m_ECLibrary;

};

#endif //__PARATEXTPROJECTPROXY_H_
