// ECLibrary.cpp : Implementation of CECObjectsApp and DLL registration.

#include "stdafx.h"
#include "ECObjects.h"
#include "ECLibrary.h"
#include "ECUtil.h"

#include "GuessFileEncoding.h"	// CGuessFileEncoding

#include <io.h>				// _filelength

#include <vector>
#include <map>
#include <string>

#include <comutil.h>	// for some of the com objects _variant_t

#define	START_BE_SAFE( X )	bool besafeTrue=true; char besafeName__[] = {"" #X ""}; try {
#define END_BE_SAFE		} catch(...) {besafeTrue=false;ATLTRACE("*** Exception: <%s>\n", besafeName__);}
#define HAD_EXCEPTION	besafeTrue==false

#include "../TESO/TESO.h"	// for midl generated header

//#define __USE_LOGGING 1
#ifdef __USE_LOGGING
#include "logger.h"
#endif

#include "IcuCommon.h"		// ICU header file
// function from UtilXml.h in FieldWorks Generic folder
typedef wchar_t wchar;
typedef unsigned long ulong;
#define AssertArray(v,c)
#define Assert(x)
#include "../Generic/DecodeUtf8_i.c"
namespace StrUtil
{
	extern void InitIcuDataDir();
};


/////////////////////////////////////////////////////////////////////////////
//

ECLibrary::ECLibrary() : CTraceCreation( "ECLibrary" )
{
	StrUtil::InitIcuDataDir();
}


ECLibrary::~ECLibrary()
{
	ATLTRACE("* ~ECLibrary()<%d> called\n", GetTraceID());
	CleanTEStyleMap();
#ifdef __USE_LOGGING
	CLogger::Shutdown();
#endif
}

STDMETHODIMP ECLibrary::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IECLibrary,
	};

	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


STDMETHODIMP ECLibrary::get_EncodingNames(VARIANT *pSafeArray)
{
	HRESULT hr = S_OK;

	START_BE_SAFE( ECLibrary::get_EncodingNames );

	const int numItems = 5;
	CComBSTR val[numItems];
	val[0] = _T("SIL-ANNAPURNA_05-2002");
	val[1] = _T("SIL-EEG_SINDHI");
	val[2] = _T("SIL-GREEK_GALATIA-2001");
	val[3] = _T("ISO-8859-1");
	val[4] = _T("X-SIL-ETHIOPIC-Cushitic");

	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreate(VT_BSTR, 1, rgsabound);

	// Fill the safe array with the styles
	//
	for( LONG lIndex = 0 ; lIndex < numItems ;lIndex++)
	{
		hr  = SafeArrayPutElement(psa, &lIndex, val[lIndex].Copy());
	}

	pSafeArray->vt = VT_BSTR | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;

	END_BE_SAFE

	return hr;
}

STDMETHODIMP ECLibrary::get_StyleNames(VARIANT *pSafeArray)
{
	HRESULT hr = S_OK;
	int numItems = 0;

	START_BE_SAFE( ECLibrary::get_StyleNames );

	numItems = m_TEStyles.size();
	TTEStyleMapIT it = m_TEStyles.begin();
	long lIndex = 0;

	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreate(VT_BSTR, 1, rgsabound);

	for ( ; it != m_TEStyles.end(); it++, lIndex++ )
	{
		CComBSTR styleName = (*it).second;
		hr = SafeArrayPutElement( psa, &lIndex, styleName.Copy() );
	}

	pSafeArray->vt = VT_BSTR | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;

	END_BE_SAFE

	return hr;
}


STDMETHODIMP ECLibrary::get_MarkerDomainNames(VARIANT *pSafeArray)
{
	HRESULT hr = S_OK;

	START_BE_SAFE( ECLibrary::get_MarkerDomainNames );

	std::vector< CComBSTR > names;

	names.push_back( _T("Unknown") );
	names.push_back( _T("Vern") );
	names.push_back( _T("Back") );
	names.push_back( _T("Note") );
	names.push_back( _T("Footnote") );

	int numItems = names.size();
	
	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreate(VT_BSTR, 1, rgsabound);

	// Fill the safe array with the names
	//
	for( LONG lIndex = 0 ; lIndex < numItems ;lIndex++)
	{
		hr  = SafeArrayPutElement(psa, &lIndex, names[lIndex].Copy());
	}

	pSafeArray->vt = VT_BSTR | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;

	END_BE_SAFE

	return hr;
}

STDMETHODIMP ECLibrary::get_MarkerDomainInts(VARIANT *pSafeArray)
{
	HRESULT hr = S_OK;

	START_BE_SAFE( ECLibrary::get_MarkerDomainInts );

	std::vector< int > domainValue;

	domainValue.push_back( MD_Unknown );
	domainValue.push_back( MD_Vern );
	domainValue.push_back( MD_Back );
	domainValue.push_back( MD_Note );

	int numItems = domainValue.size();
	
	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreate(VT_INT, 1, rgsabound);

	// Fill the safe array with the domain values
	//
	for( LONG lIndex = 0 ; lIndex < numItems ;lIndex++)
	{
		hr  = SafeArrayPutElement(psa, &lIndex, &domainValue[lIndex] );
	}

	pSafeArray->vt = VT_INT | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;

	END_BE_SAFE

	return hr;
}

STDMETHODIMP ECLibrary::get_MarkerDomainAsBSTR(int domainID, BSTR *pVal)
{
	switch ( domainID )
	{
	case MD_Vern:
		*pVal = ::SysAllocString( L"Vern" ); break;

	case MD_Back:
		*pVal = ::SysAllocString( L"Back" ); break;

	case MD_Note:
		*pVal = ::SysAllocString( L"Note" ); break;

	case MD_Unknown:
	default:
		*pVal = ::SysAllocString( L"Unknown" ); break;

	}

	return S_OK;
}

STDMETHODIMP ECLibrary::TestSO()
{

//	short numStyles = ReadSOStyles("C:\\Dev\\Projects\\ECObjects\\SOFiles\\StylesProject.ssf");
	short numStyles = ReadSOStyles("C:\\Dev\\Projects\\ECObjects\\SOFiles\\ECSOStyles.sty");

	// style names
	_variant_t vSafeArrayData;
	long LBnd, UBnd;
	BSTR bstrName;
	get_StyleNames( &vSafeArrayData );

	SafeArrayGetLBound(V_ARRAY(&vSafeArrayData), 1, &LBnd);
	SafeArrayGetUBound(V_ARRAY(&vSafeArrayData), 1, &UBnd);

	for ( long li = LBnd; li <= UBnd; li++ )
	{
		SafeArrayGetElement(V_ARRAY(&vSafeArrayData), &li, &bstrName );
		ATLTRACE("Pulling out Style name: %ld : ", li );
		OutputDebugStringW( bstrName );
		ATLTRACE("\n");
		::SysFreeString( bstrName );
	}

	CComBSTR marker = L"v";
	get_TEStyleName( marker.m_str, &bstrName );
	::SysFreeString( bstrName );
	
	marker = L"io1";
	get_TEStyleName( marker.m_str, &bstrName );
	::SysFreeString( bstrName );
	
	marker = L"thisMarkerDoesntExist";
	get_TEStyleName( marker.m_str, &bstrName );
	::SysFreeString( bstrName );
	
	return S_OK;
}


typedef struct {
	int index;
	int count;
} TMapData;

typedef std::map< CComBSTR, TMapData > TStyleMap;
typedef TStyleMap::iterator TStyleMapIT;

STDMETHODIMP ECLibrary::MakeSOStyleFile(BSTR fName, VARIANT pSafeArray)
{
/*******************************************************
	<ScriptureText>
	<AutoKeyboardSwitching>F</AutoKeyboardSwitching>
	<BooksPresent>0</BooksPresent>
	<CallerSequence></CallerSequence>
	<ChapterMarker>c</ChapterMarker>
	<DefaultFont>Arial</DefaultFont>
	<DefaultFontSize>12</DefaultFontSize>
		//<Directory>C:\Apps\Paratext 6\TEV</Directory>
		//<Editable>F</Editable>
	<Encoding>65001</Encoding>											// use 65001 which is utf-8
		//<FileNameChapterNumberForm></FileNameChapterNumberForm>
		//<FileNameForm>41MAT</FileNameForm>
		//<FileNamePostPart>.TEV</FileNamePostPart>
		//<FileNamePrePart></FileNamePrePart>
	<FullName>Today's English Version (FOR PREDISTRIBUTION USE ONLY)</FullName>
	<IndentedParagraph>pi</IndentedParagraph>
	<InnerInnerQuotes>� �</InnerInnerQuotes>
	<InnerQuotes>� �</InnerQuotes>
	<Language>English</Language>
	<LeftToRight>T</LeftToRight>
	<Name>TEV</Name>
	<PoeticMarker>q1</PoeticMarker>
	<Quotes>� �</Quotes>
	<RepeatAtNewParagraph>yes</RepeatAtNewParagraph>
	<RepeatPoetryAtBreak>b c s</RepeatPoetryAtBreak>
	<RepeatPoetryAtPoetryFirstLine>No</RepeatPoetryAtPoetryFirstLine>
	<ResourceText>T</ResourceText>
		//<RunFromCD>F</RunFromCD>
	<StyleSheet>USFM.STY</StyleSheet>
	<VerseMarker>v</VerseMarker>
	<Versification>4</Versification>
		//<Naming PostPart=".TEV" BookNameForm="41MAT"></Naming>
	</ScriptureText>
********************************************************/
	
	
//	SO::ISCScriptureTextPtr qScriptureText;
	CComPtr<ISCScriptureText> qScriptureText;	//HKEY_CLASSES_ROOT\Interface\{12AAD383-2909-4A14-ADA9-C73DC231A18D}
	TStyleMap styleMap;
	TStyleMapIT mapIT;
	CLSID clsid;
	HRESULT hr;

	START_BE_SAFE( ECLibrary::MakeSOStyleFile );

	//
	// Create the main SO object
//	qScriptureText.CreateInstance(__uuidof(SO::SCScriptureText));

	hr = CLSIDFromProgID(L"TESOLib.SCScriptureText", &clsid);
	hr = qScriptureText.CoCreateInstance(L"TESO.SCScriptureText");	// __uuidof(SCScriptureText));
/*
									  ScriptureObjects.SCTextSegment
				if (FAILED(CLSIDFromProgID(L"SIL.CS.ConvertWToA", &clsid)))
					return WriteError(kpszComCreateError, iLine);
				if (FAILED(CoCreateInstance(clsid, NULL, CLSCTX_ALL, IID_ICsConvertWToA,
					(void **)&(peiNew->qunk))))

		CComPtr<LANG::ILgKeymanHandler> keymanPtr;
		keymanPtr.CoCreateInstance(_uuidof(LANG::LgKeymanHandler),NULL,CLSCTX_INPROC_SERVER);

		if (keymanPtr == NULL) 
		{
			printf("Unable to create ILgKeymanHandler interface object.\n");
			return 0;
		}

    IECs    pECs;
    if( pECs.CoCreateInstance(L"SilEncConverters.EncConverters") == S_OK )

*/

	//
	// Read in the default TE - SO properties
	qScriptureText->Load(L"C:\\Dev\\Projects\\ECObjects\\SOFiles\\StylesProject.ssf"); 

	//
	// create a map from the TEStyleName property to the index of the SCTag object
	//	- if there are multiple entries with the same TEStyleName, then just use the first
	//	  one for this map.
	//

////	SO::ISCTagPtr qTag;
	CComPtr<ISCTag> qTag;
//	_bstr_t qtext;
//	int iTagIndex;
	BSTR tmpBSTR;
	TMapData tmpData;
	int numTags = 0;

	for ( int i=0; true; i++ )
	{
//		qTag = qScriptureText->NthTag( i );
		qScriptureText->NthTag( i, &qTag );
		if ( qTag == NULL )
		{
			numTags = i;
			break;
		}

		qTag->get_TeStyleName( &tmpBSTR );
		tmpData.index = i;
		tmpData.count = 1;

		mapIT = styleMap.find( tmpBSTR );
		if ( mapIT == styleMap.end() )
		{
			styleMap[tmpBSTR] = tmpData;
		}
		else
		{
			mapIT->second.count++;
			tmpData = mapIT->second;
		}

///		OutputDebugString("-- Style Name : " );
///		OutputDebugStringW( tmpBSTR );
///		ATLTRACE(" index=%d, count=%d\n", tmpData.index, tmpData.count );
///
		::SysFreeString( tmpBSTR );
	}

	ATLTRACE("%d Tags and %d unique StyleNames\n", numTags, styleMap.size() );
		

	END_BE_SAFE

	styleMap.clear();

	return S_OK;
}

short ECLibrary::ReadSOStyles(char *styFileName)
{
	static const char szMkr[] = "\\Marker ";

	CleanTEStyleMap();
	CleanSOMarkersMap();

	FILE * fp = fopen(styFileName, "rb");
	if (!fp)
	{
		return -1;		// no such file??
	}
	long nFileSize = _filelength(_fileno(fp));
	if (nFileSize == -1L)
	{
		fclose(fp);
		return -9;		// what??  no size info?
	}
	char * prgchBuf = (char*)malloc(nFileSize + 1);
	if (!prgchBuf)
	{
		fclose(fp);
		return -2;		// out of memory???
	}
	if (fread(prgchBuf, nFileSize, 1, fp) != 1)
	{
		fclose(fp);
		free(prgchBuf);
		return -3;		// cannot read file??
	}
	fclose(fp);
	prgchBuf[nFileSize] = 0;		// NUL terminate the buffer

	char * pchLim = prgchBuf + nFileSize;
	char * pchMarker = strstr(prgchBuf, szMkr);
	if (!pchMarker)
	{
		free(prgchBuf);
		return -4;		// invalid file??
	}
	char * pchNext;
	for ( ; pchMarker != pchLim; pchMarker = pchNext)
	{
		pchNext = strstr(pchMarker + 8, szMkr);
		if (!pchNext)
			pchNext = pchLim;
		*pchNext = 0;		// NUL terminate this record: the next record won't
							// miss this first backslash.
		if (pchMarker != prgchBuf && pchMarker[-1] != '\n')
			continue;

		// Now, isolate the information we want for this marker, and store it.
		char * pszMarkerValue = pchMarker + 8;
		char * pszRec = strpbrk(pszMarkerValue, "\r\n");
		if (pszRec)
		{
			*pszRec++ = 0;		// NUL terminate the marker value: point to \n?
			// convert ASCII string to the UTF-16 BSTR value we want
			CComBSTR bstrMarker = L"\\";
			bstrMarker.Append(pszMarkerValue);
			char * pszTeStyle = strstr(pszRec, "\n\\TEStyleName ");
			// Point to the beginning of the next line.  This probably points to the
			// block of lines stored in m_SOMarkers.
			if (*pszRec == '\n')
				++pszRec;			// Point to beginning of next line.
			if (pszTeStyle)
			{
				++pszTeStyle;
				char * pszName = pszTeStyle + 13;
				char * psz = strpbrk(pszName, "\r\n");
				if (psz)
					*psz++ = 0;
				CComBSTR bstrTeStyle = pszName;

#if 0
				ATLTRACE("Adding ");
				OutputDebugStringW( bstrMarker );
				ATLTRACE(" -> ");
				OutputDebugStringW( bstrTeStyle );
				ATLTRACE("\n");
#endif

				m_TEStyles[ bstrMarker ] = bstrTeStyle;	// add this to the map
				// Point to the beginning of the next line.   If anything exists
				// between here and the nd of the record, move it up over the \TEStyleName
				// line, compacting the data stored in the map.
				if (*psz == '\n')
					++psz;
				if (psz < pchNext)
					memmove(pszTeStyle, psz, pchNext - psz + 1);

				// Look for a trailing comment (starts with '#') after final field (starts with '\')
				// First, find the final field.  Too bad that strrstr doesn't exist!
				char * pszField;
				char * pszNextField;
				for (pszField = strstr(pszRec, "\n\\"); pszField; pszField = pszNextField)
				{
					pszNextField = strstr(pszField + 2, "\n\\");
					if (!pszNextField)
						break;
				}
				// This assumes that nothing meaningful can occur after the last field of this
				// record, which we assume occupies only one line (or at least nothing past the
				// comment line).
				if (pszField)
				{
					char * pszComment = strstr(pszField, "\n#");
					if (pszComment)
						*pszComment = 0;
				}
				// Trim trailing whitespace from the block of marker lines.
				psz = pszRec + strlen(pszRec) - 1;
				while (psz > pszRec)
				{
					if (!isascii(*psz) || !isspace(*psz))
						break;
					*psz-- = 0;
				}
				CComBSTR bstrSOMarkers = pszRec;
				m_SOMarkers[ bstrTeStyle ] = bstrSOMarkers;

#if 0
				ATLTRACE("Adding ");
				OutputDebugStringW( bstrTeStyle );
				ATLTRACE(" -> ");
				OutputDebugStringW( bstrSOMarkers );
				ATLTRACE("\n");
#endif
			}
			else
			{
				// no TEStyleName defined, unable to create the association
			}
		}
		else
		{
			// nothing to do if "\n\\Marker name" ends the file.
		}
	}

	int soSize = m_SOMarkers.size();
	int teSize = m_TEStyles.size();

	free(prgchBuf);

	// ===========================================================================

	return this->m_TEStyles.size();
;
}

short ECLibrary::CleanTEStyleMap()
{
	short rval = m_TEStyles.size();

	m_TEStyles.clear();

	return rval;
}

short ECLibrary::CleanSOMarkersMap()
{
	short rval = m_SOMarkers.size();

	m_SOMarkers.clear();

	return rval;
}

STDMETHODIMP ECLibrary::get_BeginMarkerForStyleName(BSTR teStyleName, BSTR *pVal)
{
	return E_FAIL;
}


STDMETHODIMP ECLibrary::get_TEStyleName(BSTR beginMarker, BSTR *pVal)
{

	START_BE_SAFE( ECLibrary::get_TEStyleName );

	TTEStyleMapIT it = m_TEStyles.find( beginMarker );
	int numElements = m_TEStyles.size();

	if ( it != m_TEStyles.end() )
	{
		CComBSTR tmpData = it->second;
		*pVal = tmpData.Copy();
	}
	else
	{
		CComBSTR unknown = L"Unknown";
		it = m_TEStyles.find( unknown );

		if ( it != m_TEStyles.end() )
		{
			CComBSTR tmpData = it->second;
			*pVal = tmpData.Copy();
		}
		else
		{
			CComBSTR unknown = L"UnknownTEStyle";
			*pVal = unknown.Copy();
		}
	}

	END_BE_SAFE

	return S_OK;
}

STDMETHODIMP ECLibrary::get_SOMarkerFields(BSTR teStyleName, BSTR *pVal)
{

	START_BE_SAFE( ECLibrary::get_SOMarkerFields );

	TSOMarkerInfoIT it = m_SOMarkers.find( teStyleName );
	if ( it != m_SOMarkers.end() )
	{
		CComBSTR tmpData = it->second;
		*pVal = tmpData.Copy();
	}
	else
	{
		// this is where a default SO property block would be put out
		CComBSTR unknown = L"# Default data will likely go here...";
		*pVal = unknown.Copy();
	}

	END_BE_SAFE

	return S_OK;
}


STDMETHODIMP ECLibrary::ReadInTEStyleNames( BSTR styFile, long *numStyles)
{
	char asciiFileName[256];

	::WideCharToMultiByte( CP_ACP, 0, styFile, ::SysStringLen(styFile)+1, asciiFileName, 256, "*", 0 );

	short rval = ReadSOStyles( asciiFileName );
	*numStyles = rval;

	return S_OK;
}

/*----------------------------------------------------------------------------------------------
	Check that the string contains only valid numeric digit Unicode characters (encoded as
	UTF8).  Return E_FAIL if invalid number and let caller set proper HRESULT (chapter/verse).
----------------------------------------------------------------------------------------------*/
HRESULT CheckForValidNumber(const char * pch, int cch)
{
	HRESULT rval = S_OK;
	// int32_t u_charDigitValue(UChar32 c) returns -1 if invalid, decimal number value otherwise
	const char * pchEnd = pch + cch;
	for (const char * pchT = pch; pchT && pchT < pchEnd && *pchT; )
	{
		int cchUsed = 0;
		UChar32 ch = DecodeUtf8(pchT, pchEnd - pchT, cchUsed);
		pchT += cchUsed;
		int32_t nDigit = u_charDigitValue(ch);
		if (nDigit < 0 || nDigit > 9)
			rval = E_FAIL;
	}
	return rval;
}

/*----------------------------------------------------------------------------------------------
	Check that the string contains only valid numeric digit Unicode characters or valid
	punctuation characters (encoded as UTF8).  Return E_FAIL if invalid number and let caller 
	set proper HRESULT (chapter/verse).
----------------------------------------------------------------------------------------------*/
HRESULT CheckForValidNumberOrPunct(const char * pch, int cch)
{
	HRESULT rval = S_OK;
	// int32_t u_charDigitValue(UChar32 c) returns -1 if invalid, decimal number value otherwise
	const char * pchEnd = pch + cch;
	for (const char * pchT = pch; pchT && pchT < pchEnd && *pchT; )
	{
		int cchUsed = 0;
		UChar32 ch = DecodeUtf8(pchT, pchEnd - pchT, cchUsed);
		pchT += cchUsed;
		int32_t nDigit = u_charDigitValue(ch);
		if (nDigit >= 0 && nDigit <= 9)
			continue;
		// Check for punctuation.
		if (!u_ispunct(ch))
			rval = E_FAIL;
	}
	return rval;
}

// assume that rgchFirst and rgchLast each are 64 bytes long.  (that should be enough)
HRESULT CheckForValidVerseRange(const char * pchVerseRange, int cch, char * rgchFirst,
	char * rgchSecond, int * pnFirst, int * pnLast)
{
	HRESULT rval = S_OK;
	// int32_t u_charDigitValue(UChar32 c) returns -1 if invalid, decimal number value otherwise
	const char * pchEnd = pchVerseRange + cch;
	int nFirst = -1;
	
	// initialize passed in return pointers
	if (rgchFirst)	*rgchFirst = 0;
	if (rgchSecond)	*rgchSecond = 0;
	if (pnFirst)	*pnFirst = -1;
	if (pnLast)		*pnLast = -1;

	bool fPunctSeen = false;
	bool fLastWasPunct = false;
	const char * pchSecondVerse = NULL;
	int nT = 0;
	int cDigits = 0;
	for (const char * pchT = pchVerseRange; pchT && pchT < pchEnd && *pchT; )
	{
		int cchUsed = 0;
		UChar32 ch = DecodeUtf8(pchT, pchEnd - pchT, cchUsed);
		pchT += cchUsed;
		int32_t nDigit = u_charDigitValue(ch);
		if (nDigit >= 0 && nDigit <= 9)
		{
			if (fPunctSeen && cDigits == 0 && pchSecondVerse == NULL)
				pchSecondVerse = pchT - cchUsed;
			nT = nT * 10 + nDigit;
			++cDigits;
			fLastWasPunct = false;
			continue;
		}
		// Check for punctuation.
		if (u_ispunct(ch))
		{
			if (!fLastWasPunct && cDigits == 0)
				return E_FAIL;
			if (!fPunctSeen)
			{
				fPunctSeen = true;
				nFirst = nT;
				if (pnFirst)
					*pnFirst = nT;
				nT = 0;
				cDigits = 0;
				int cchT = pchT - pchVerseRange - cchUsed;
				if (cchT >= 64)
					cchT = 63;
				memcpy(rgchFirst, pchVerseRange, cchT);
				rgchFirst[cchT] = 0;
			}
			else if (pchSecondVerse != NULL)
			{
				return E_FAIL;
			}
			fLastWasPunct = true;
		}
		else
		{
			return E_FAIL;
		}
	}
	if (pchSecondVerse == NULL)
	{
		if (fPunctSeen || cDigits == 0)
			return E_FAIL;
		if (pnFirst)
			*pnFirst = nT;
		int cchT = cch < 64 ? cch : 64;
		memcpy(rgchFirst, pchVerseRange, cchT);
		rgchFirst[cchT] = 0;
		memset(rgchSecond, 0, 64);
	}
	else
	{
		int cchT = pchT - pchSecondVerse;
		if (cchT >= 64)
			cchT = 63;
		memcpy(rgchSecond, pchSecondVerse, cchT);
		rgchSecond[cchT] = 0;
		if (pnLast)
			*pnLast = nT;
		if (nFirst >= nT)
			return E_FAIL;
	}

	return S_OK;
}

/*---------------------------------------------------------------------------------------------
	Get the length of the verse number clump, which may be a single verse or a range of verses.
	TODO: handle subverses.
---------------------------------------------------------------------------------------------*/
int LengthOfVerseNumbers(const char * pchVerse)
{
	int len = strcspn(pchVerse, " \t\r\n\f\v");	// all non-white space markers
	for (int ich = 0; ich < len; )
	{
		int cchUsed = 0;
		UChar32 ch = DecodeUtf8(pchVerse + ich, len - ich, cchUsed);
		if (u_ispunct(ch))
		{
			if (ch == 0x5c)	// don't allow '\'
				return ich;
		}
		else if (!u_isdigit(ch))
			return ich;

		ich += cchUsed;
	}
	return len;
}


void TestVerseRanges()
{
	HRESULT hr = S_OK;
	const char pchOne[] =	{"1"};
	const char pchTwo[] =	{"1-4"};
	const char pchThree[] = {"4-1"};
	const char pchFour[] =	{"-1-4-"};

	int iFirst, iLast;
	char chFirst[64], chLast[64];

	hr = CheckForValidVerseRange(pchOne, strlen(pchOne), chFirst, chLast, &iFirst, &iLast);
	hr = CheckForValidVerseRange(pchTwo, strlen(pchTwo), chFirst, chLast, &iFirst, &iLast);
	hr = CheckForValidVerseRange(pchThree, strlen(pchThree), chFirst, chLast, &iFirst, &iLast);
	hr = CheckForValidVerseRange(pchFour, strlen(pchFour), chFirst, chLast, &iFirst, &iLast);
}


#if 0
// Read a standard format (Shoebox?) scripture file, and extract the first and last book/chapter/verse
// references found therein.  The output strings look like "GEN 1:1" and "REV 22:25".  No checking is
// done for valid book names, chapter numbers, or verse numbers, apart from requiring 3-character names,
// and ASCII digit numbers.  Verse numbers can have internal punctuation characters.
/*
OBA 1:21
PHM 1:25
2JN 1:13
3JN 1:15
JUD 1:25
LJE 1:73
S3Y 1:68
SUS 1:64
BEL 1:42
MAN 1:15
PS2 1:7
SST 1:64
BLT 1:42
*/

STDMETHODIMP ECLibrary::GetScriptureRefBounds(BSTR bstrFileName, BSTR bookMarker, 
	BSTR chapterMarker, BSTR verseMarker, BSTR *startRef, BSTR *endRef)
{
	char *pszBookMarker = NULL;
	char *pszChapterMarker = NULL;
	char *pszVerseMarker = NULL;
	char * prgchBuf = NULL;
	bool bCheckVerses = true;

	char *singleChapter_BookIDS[] = {"OBA", "PHM", "2JN", "3JN", "JUD", 
		"LJE", "S3Y", "SUS", "BEL", "MAN", "PS2", "SST", "BLT", 0 };
	
	*startRef = NULL;
	*endRef = NULL;

	// open the file and read it into memory.

	FILE * fp = NULL;
	HRESULT retVal = S_OK;

	START_BE_SAFE(ECLibrary::GetScriptureRefBounds)

	fp = _wfopen( bstrFileName, L"rb");
	if (!fp)
	{
		OutputDebugString("** Error ECLibrary::GetScriptureRefBounds : Unable to open file <");
		OutputDebugStringW( bstrFileName );
		OutputDebugString(">\n");
		retVal = ECERROR_VerseNoBook; // found verse with out chapter in non-single chapter book
		throw Error(bstrFileName, IID_IECLibrary, retVal);
//		return ECERROR_FileError;
	}

	long nFileSize = _filelength(_fileno(fp));
	if (nFileSize <= 0L)	// -1 error or empty file
	{
		fclose(fp);
		fp = NULL;
		OutputDebugString("** Error ECLibrary::GetScriptureRefBounds : File size invalid <");
		OutputDebugStringW( bstrOrigFileName );
		OutputDebugString(">\n");
		retVal = ECERROR_FileError;		// could have been the standard E_UNEXPECTED;
		throw Error(bstrOrigFileName, IID_IECLibrary, retVal);
//		throw retVal;
	}
	prgchBuf = (char*)malloc(nFileSize + 1);
	if (!prgchBuf)
	{
		fclose(fp);
		fp = NULL;
		OutputDebugString("** Error ECLibrary::GetScriptureRefBounds : Out of memory <");
		OutputDebugStringW( bstrOrigFileName );
		OutputDebugString(">\n");
		retVal = E_OUTOFMEMORY;
		throw retVal;
	}
	if (fread(prgchBuf, nFileSize, 1, fp) != 1)
	{
		fclose(fp);
		fp = NULL;
		OutputDebugString("** Error ECLibrary::GetScriptureRefBounds : Couldn't read file <");
		OutputDebugStringW( bstrFileName );
		OutputDebugString(">\n");
		free(prgchBuf);
		prgchBuf = NULL;
		retVal = E_UNEXPECTED;
		throw Error(bstrOrigFileName, IID_IECLibrary, retVal);
//		throw retVal;
	}

	fclose(fp);
	fp = NULL;
	prgchBuf[nFileSize] = 0;		// NUL terminate the buffer

	// convert our markers to multibyte data

	pszBookMarker = ECUtil::WideToMultiByte( bookMarker );
	pszChapterMarker = ECUtil::WideToMultiByte( chapterMarker );
	pszVerseMarker = ECUtil::WideToMultiByte( verseMarker );

	// assert(pszBookMarker[0] == pszChapterMarker[0]);
	// assert(pszBookMarker[0] == pszVerseMarker[0]);

	if ( !pszBookMarker || !pszChapterMarker || !pszVerseMarker )
	{
		OutputDebugString("** Error ECLibrary::GetScriptureRefBounds : Out of memory <");
		OutputDebugStringW( bstrFileName );
		OutputDebugString(">\n");
		retVal = E_OUTOFMEMORY;
		throw retVal;
	}

	size_t cchBookMarker = strlen(pszBookMarker);
	size_t cchChapterMarker = strlen(pszChapterMarker);
	size_t cchVerseMarker = strlen(pszVerseMarker);

	char * pchFirstBook = NULL;			// first book found
	char * pchBook = NULL;				// current book
	char * pchFirstChapter = NULL;		// first chapter found
	char * pchLastChapter = NULL;		// used for keeping track of the last chapter found
	char * pchChapter = NULL;			// current chapter
	char * pchFirstVerse = NULL;		// first verse
	char * pchVerse = NULL;				// current verse
	char   pchChapterOne[] = {"1 "};	// default chapter one text

	int iFirst, iLast;
	char rgchFirst[64], rgchLast[64];

	CComPtr<ISCReference2> qRef;		// ISCReference2 for book and verse checking
	CLSID clsid;
	HRESULT hr = CLSIDFromProgID(L"TESOLib.SCReference", &clsid);
	hr = qRef.CoCreateInstance(L"TESO.SCReference");

	char * pchMark;
	size_t cchMarker;
	int chMark = pszBookMarker[0];
	for (pchMark = strchr(prgchBuf, chMark); pchMark; pchMark = strchr(pchMark + cchMarker, chMark))
	{
		cchMarker = 1;
//		if (pchMark != prgchBuf && pchMark[-1] != '\n')		// only the first line doesn't have to have a \n before the '\'
//			continue;
		if (!memcmp(pchMark, pszVerseMarker, cchVerseMarker) && isascii(pchMark[cchVerseMarker]) &&
			isspace(pchMark[cchVerseMarker]))
		{
			cchMarker = cchVerseMarker;
			if (!pchBook)						// still no book found
			{
				pchMark += cchMarker;
				int endposMark = strspn((const char*)pchMark, " \t\r\n\f");
				pchMark += endposMark;
				endposMark = strcspn((const char*)pchMark, " \t\r\n\f");
				pchMark[endposMark] = 0;

				std::string emsg = ",,";
				emsg.append(pchMark);

				retVal = ECERROR_VerseNoBook; // found verse with out chapter in non-single chapter book
				throw Error(emsg.c_str(), IID_IECLibrary, retVal);
			}
			if (!pchChapter)		// if no chapter then check for single chapter books
			{
				bool found = false;
				for (int cchTemp = 0; singleChapter_BookIDS[cchTemp]; cchTemp++)
				{
					if (!strncmp(pchBook, singleChapter_BookIDS[cchTemp], 3))
					{
						found = true;
						pchLastChapter = pchFirstChapter = pchChapter = pchChapterOne;
						break;
					}
				}
				if (!found)
				{
					// build error msg string: Book,,Verse
					int endposBook = strcspn((const char*)pchBook, " \t\r\n\f");
					pchBook[endposBook] = 0;
					pchMark += cchMarker;
					int endposMark = strspn((const char*)pchMark, " \t\r\n\f");
					pchMark += endposMark;
					endposMark = strcspn((const char*)pchMark, " \t\r\n\f");
					pchMark[endposMark] = 0;

					std::string emsg;
					emsg.append(pchBook);		
					emsg += ",,";
					emsg.append(pchMark);

					retVal = ECERROR_VerseNoChapter; // found verse with out chapter in non-single chapter book
					throw Error(emsg.c_str(), IID_IECLibrary, retVal);
				}
			}
			// check for valid verse text
			char *pchVerseText = pchMark + cchMarker;
			int endposMark = strspn((const char*)pchVerseText, " \t\r\n\f");
			pchVerseText += endposMark;
			endposMark = strcspn((const char*)pchVerseText, "\r\n\f");	// go to end of line
			///////// Put data in safe array to send over COM boundry ///////////
			VARIANT safeArray;
			SAFEARRAY FAR* psa;
			SAFEARRAYBOUND rgsabound[1];
			rgsabound[0].lLbound = 0;
			rgsabound[0].cElements = endposMark;
			psa = SafeArrayCreate(VT_UI1, 1, rgsabound);

			for( LONG lIndex = 0 ; lIndex < endposMark ;lIndex++)
			{
				hr  = SafeArrayPutElement(psa, &lIndex, &pchVerseText[lIndex] );
			}

			safeArray.vt = VT_UI1 | VT_ARRAY;
			V_ARRAY(&safeArray) = psa;
			/////////////////////////////////////

			BOOL valid;
			qRef->IsValidVerseNumberText(safeArray, &valid);
			if (!valid)		// invalid book name
			{
				int endpos = strcspn((const char*)pchBook, " \t\r\n\f");
				pchBook[endpos] = 0;
				endpos = strcspn((const char*)pchChapter, " \t\r\n\f");
				pchChapter[endpos] = 0;
///				pchVerse = pchMark + cchVerseMarker;
///				pchVerse += strspn(pchVerse, " \t");
///				pchVerse[len] = 0;	// end of invalid verse number/range
				// build error msg string: Book, Chapter, Verse
				std::string emsg;
				emsg.append(pchBook);
				emsg += ",";
				emsg.append(pchChapter);
				emsg += ",";
///				emsg.append(pchVerse);

				retVal = Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidVerseNumber);
				throw retVal;
			}

			if (!pchFirstVerse && pchChapter == pchFirstChapter)
			{
				pchFirstVerse = pchMark + cchVerseMarker;
				pchFirstVerse += strspn(pchFirstVerse, " \t");
				pchVerse = pchFirstVerse;
			}
			else
			{
				pchVerse = pchMark + cchVerseMarker;
				pchVerse += strspn(pchVerse, " \t");
			}
			
			// Make sure the verse is valid...? (number[puctuation and number])
			int len = LengthOfVerseNumbers(pchVerse);
			if (bCheckVerses && FAILED(CheckForValidVerseRange(pchVerse, len, rgchFirst, rgchLast, &iFirst, &iLast)))
			{
				int endpos = strcspn((const char*)pchBook, " \t\r\n\f");
				pchBook[endpos] = 0;
				endpos = strcspn((const char*)pchChapter, " \t\r\n\f");
				pchChapter[endpos] = 0;
				pchVerse[len] = 0;	// end of invalid verse number/range
				// build error msg string: Book, Chapter, Verse
				std::string emsg;
				emsg.append(pchBook);
				emsg += ",";
				emsg.append(pchChapter);
				emsg += ",";
				emsg.append(pchVerse);

				retVal = Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidVerseNumber);
				throw retVal;
			}
		}
		else if (!memcmp(pchMark, pszChapterMarker, cchChapterMarker) && isascii(pchMark[cchChapterMarker]) &&
			isspace(pchMark[cchChapterMarker]))
		{
			cchMarker = cchChapterMarker;
			if (!pchBook)
			{
				pchMark += cchMarker;
				int endposMark = strspn((const char*)pchMark, " \t\r\n\f");
				pchMark += endposMark;
				endposMark = strcspn((const char*)pchMark, " \t\r\n\f");
				pchMark[endposMark] = 0;

				std::string emsg = ",";		// no book
				emsg.append(pchMark);		
				emsg += ",";				// no verse processed yet in this context

				retVal = ECERROR_ChapterNoBook; // found verse with out chapter in non-single chapter book
				throw Error(emsg.c_str(), IID_IECLibrary, retVal);
			}
			if (!pchFirstChapter)
			{
				pchFirstChapter = pchMark + cchChapterMarker;
				pchFirstChapter += strspn(pchFirstChapter, " \t");
				pchChapter = pchFirstChapter;
			}
			else
			{
				pchChapter = pchMark + cchChapterMarker;
				pchChapter += strspn(pchChapter, " \t");
			}
			pchLastChapter = pchChapter;	// save for next time
			pchVerse = NULL;		// reset for now
		}
		else if (!memcmp(pchMark, pszBookMarker, cchBookMarker) && isascii(pchMark[cchBookMarker]) &&
			isspace(pchMark[cchBookMarker]))
		{
			cchMarker = cchBookMarker;
			pchBook = pchMark + cchBookMarker;	/////
			pchBook += strspn(pchBook, " \t");/////
			int bookLen = strcspn(pchBook, " \t\r\n\f");

			///////// Put data in safe array to send over COM boundry ///////////
			VARIANT safeArray;
			SAFEARRAY FAR* psa;
			SAFEARRAYBOUND rgsabound[1];
			rgsabound[0].lLbound = 0;
			rgsabound[0].cElements = bookLen;
			psa = SafeArrayCreate(VT_UI1, 1, rgsabound);

			for( LONG lIndex = 0 ; lIndex < bookLen ;lIndex++)
			{
				hr  = SafeArrayPutElement(psa, &lIndex, &pchBook[lIndex] );
			}

			safeArray.vt = VT_UI1 | VT_ARRAY;
			V_ARRAY(&safeArray) = psa;
			/////////////////////////////////////

			BOOL valid;
			qRef->IsValidBookName(safeArray, &valid);
			if (!valid)		// invalid book name
			{
				// build error msg string: Book
				std::string emsg;
				pchBook[bookLen] = 0;
				emsg.append(pchBook);
				emsg += ",,";

				retVal = Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidBook);
				throw retVal;
			}

			if (!pchFirstBook)
			{
				pchFirstBook = pchMark + cchBookMarker;
				pchFirstBook += strspn(pchFirstBook, " \t");
				pchBook = pchFirstBook;
			}
			else
			{
				if (!pchChapter)		// if no chapter then check for single chapter books
				{
					char *pchBookTest = pchMark + cchMarker;
					int endposMark = strspn((const char*)pchBookTest, " \t\r\n\f");
					pchBookTest += endposMark;

					bool found = false;
					for (int cchTemp = 0; singleChapter_BookIDS[cchTemp]; cchTemp++)
					{
						if (!strncmp(pchBookTest, singleChapter_BookIDS[cchTemp], 3))
						{
							found = true;
							break;
						}
					}
					if (!found)
					{
						int endposMark = strcspn((const char*)pchBookTest, " \t\r\n\f");
						pchBookTest[endposMark] = 0;

						std::string emsg = pchBookTest;
						emsg += ",,";

						retVal = ECERROR_BooksNoChapters; // found multichapter book without chapter
						throw Error(emsg.c_str(), IID_IECLibrary, retVal);
					}
				}
				pchBook = pchMark + cchBookMarker;
				pchBook += strspn(pchBook, " \t");
			}
			pchChapter = pchVerse = NULL;		// reset for now
		}
	}

	if (!pchBook || !pchChapter)
	{
		retVal = 0;
		std::string emsg;

		if ( !pchBook )
		{
			emsg += ",";
			retVal |= ECERROR_NoBook;
			OutputDebugString("*** GetScriptureRefBounds Error: No book found in file.\n");
		}
		else
		{
			int endposMark = strcspn((const char*)pchBook, " \t\r\n\f");
			pchBook[endposMark] = 0;
			emsg += pchBook;
		}

		if ( !pchChapter )
		{
			emsg += ",,";

			retVal |= ECERROR_NoChapter;
			OutputDebugString("*** GetScriptureRefBounds Error: No chapter found in file.\n");
		}
		else
		{
			emsg += pchChapter;
			emsg += ",";
		}

		throw Error(emsg.c_str(), IID_IECLibrary, retVal);
	}

	// NUL-terminate the book, chapter and verse data.
	char * pchEnd;

	bool fSame = pchBook == pchFirstBook;
	pchFirstBook += strspn(pchFirstBook, " \t");
	pchEnd = strpbrk(pchFirstBook, " \t\r\n\f");
	*pchEnd = 0;
	if (strlen(pchFirstBook) != 3)
	{
		// build error msg string: Book
		std::string emsg;
		emsg.append(pchFirstBook);

		return Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidBook);
	}

	if (fSame)
	{
		pchBook = pchFirstBook;
	}
	else
	{
		pchBook += strspn(pchBook, " \t");
		pchEnd = strpbrk(pchBook, " \t\r\n\f");
		*pchEnd = 0;
		if (strlen(pchBook) != 3)
		{
			// build error msg string: Book
			std::string emsg;
			emsg.append(pchFirstBook);

			retVal = Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidBook);
			throw retVal;
		}
	}
	int cch;
	fSame = pchChapter == pchFirstChapter;
	pchFirstChapter += strspn(pchFirstChapter, " \t");
	pchEnd = strpbrk(pchFirstChapter, " \t\r\n\f");
	*pchEnd = 0;
	cch = pchEnd - pchFirstChapter;
	// Allow vernacular chapter numbers!
	if (FAILED(CheckForValidNumber(pchFirstChapter, cch)))
	{
		// build error msg string: Book, Chapter
		std::string emsg;
		emsg.append(pchBook);
		emsg += ",";
		emsg.append(pchFirstChapter);
		emsg += ",";

		retVal = Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidChapterNumber);
		throw retVal;
	}

	if (fSame)
	{
		pchChapter = pchFirstChapter;
	}
	else
	{
		pchChapter += strspn(pchChapter, " \t");
		pchEnd = strpbrk(pchChapter, " \t\r\n\f");
		*pchEnd = 0;
		cch = pchEnd - pchChapter;
		// Allow vernacular chapter numbers!
		if (FAILED(CheckForValidNumber(pchChapter, cch)))
		{
			// build error msg string: Book, Chapter
			std::string emsg;
			emsg.append(pchBook);
			emsg += ",";
			emsg.append(pchChapter);

			retVal = Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidChapterNumber);
			throw retVal;	// return ECERROR_InvalidChapterNumber;
		}
	}

	fSame = pchVerse == pchFirstVerse;
	if (pchFirstVerse != NULL)
	{
		pchFirstVerse += strspn(pchFirstVerse, " \t");
		pchEnd = strpbrk(pchFirstVerse, " \t\r\n\f\\");
		*pchEnd = 0;
		cch = pchEnd - pchFirstVerse;
		// Allow vernacular verse numbers!
		if (bCheckVerses && FAILED(CheckForValidNumberOrPunct(pchFirstVerse, cch)))
		{
			// build error msg string: Book, Chapter, Verse
			std::string emsg;
			emsg.append(pchBook);
			emsg += ",";
			emsg.append(pchChapter);
			emsg += ",";
			emsg.append(pchFirstVerse);

			retVal = Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidVerseNumber);
			throw retVal;
		}
	}
	if (fSame)
	{
		pchVerse = pchFirstVerse;
	}
	else if (pchVerse)
	{
		// skip over spaces and tabs to find the beginning of the verse.
		pchVerse += strspn(pchVerse, " \t");
		// find another space or tab, or the end of the line, for the end of the verse.
		pchEnd = strpbrk(pchVerse, " \t\r\n\f");
		*pchEnd = 0;
		cch = pchEnd - pchVerse;
		// Allow vernacular verse numbers!
		if (bCheckVerses && FAILED(CheckForValidNumberOrPunct(pchVerse, cch)))
		{
			// build error msg string: Book, Chapter, Verse
			std::string emsg;
			emsg.append(pchBook);
			emsg += ",";
			emsg.append(pchChapter);
			emsg += ",";
			emsg.append(pchVerse);

			retVal = Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidVerseNumber);
			throw retVal;
		}
	}
	// Handle multiple verses numbers within the markup.
	// Allow vernacular verse numbers!
	bool fWasPunct = true;
	for (char * pchT = pchVerse; pchT && pchT < pchEnd && *pchT; )
	{
		int cchUsed = 0;
		UChar32 ch = DecodeUtf8(pchT, pchEnd - pchT, cchUsed);
		if (u_isdigit(ch))
		{
			if (fWasPunct)
				pchVerse = pchT;
			fWasPunct = false;
		}
		else if (u_ispunct(ch))
		{
			fWasPunct = true;
			*pchT = 0;			// terminate any verse number.
		}
		else
		{
			// This should have been taken care of above -- it should never happen!
			// build error msg string: Book, Chapter, Verse
			std::string emsg;
			emsg.append(pchBook);
			emsg += ",";
			emsg.append(pchChapter);
			emsg += ",";
			emsg.append(pchVerse);

			retVal = Error(emsg.c_str(), IID_IECLibrary, ECERROR_InvalidVerseNumber);
			throw retVal;
		}
		pchT += cchUsed;
	}
	if (pchFirstVerse)
	{
		pchEnd = pchFirstVerse + strlen(pchFirstVerse);
		for (char * pchT = pchFirstVerse; pchT && pchT < pchEnd && *pchT; )
		{
			int cchUsed = 0;
			UChar32 ch = DecodeUtf8(pchT, pchEnd - pchT, cchUsed);
			if (!u_isdigit(ch))
			{
				*pchT = 0;
				break;
			}
			pchT += cchUsed;
		}
	}

	//  we now have all the necessary data, nicely isolated.

	CComBSTR bstrFirst;
	bstrFirst = pchFirstBook;	// (NOTE: uses CP_ACP conversion in all likelihood.)
	bstrFirst.Append(L" ");
	int iChapter = Utf8NumberToInt(pchFirstChapter, strlen(pchFirstChapter));
	if (iChapter == 1)
	{
		// TODO: figure out whether we want a vernacular digit character here, and what it would
		// be.
		bstrFirst.Append(L"0");
	}
	else
	{
		// Convert first chapter number from UTF-8 to UTF-16 before appending to the BSTR.
		wchar_t * pszT = ECUtil::MultiByteToWide(pchFirstChapter, strlen(pchFirstChapter));
		bstrFirst.Append(pszT);
		free(pszT);
	}
	
	bstrFirst.Append(L":");

	int iVerse = 1;
	if (pchFirstVerse != NULL)
		iVerse = Utf8NumberToInt(pchFirstVerse, strlen(pchFirstVerse));
	if (iVerse == 1)
	{
		bstrFirst.Append(L"0");
	}
	else
	{
		// Convert first verse number from UTF-8 to UTF-16 before appending to the BSTR.
		wchar_t * pszT = ECUtil::MultiByteToWide(pchFirstVerse, strlen(pchFirstVerse));
		bstrFirst.Append(pchFirstVerse);
		free(pszT);
	}

	*startRef = bstrFirst.Copy();

	CComBSTR bstrLast;
	bstrLast = pchBook;
	bstrLast.Append(L" ");
	// Convert chapter number from UTF-8 to UTF-16 before appending to the BSTR.
	wchar_t * pszT = ECUtil::MultiByteToWide(pchChapter, strlen(pchChapter));
	bstrLast.Append(pszT);
	free(pszT);
	bstrLast.Append(L":");
	// Convert verse number from UTF-8 to UTF-16 before appending to the BSTR.
	if (pchVerse != NULL)
	{
		pszT = ECUtil::MultiByteToWide(pchVerse, strlen(pchVerse));
		bstrLast.Append(pszT);
		free(pszT);
		pszT = NULL;
	}
	else
	{
		bstrLast.Append(L"0");
	}
	*endRef = bstrLast.Copy();


	OutputDebugStringW( bstrFileName );
	OutputDebugString (": FirstRef: " );
	OutputDebugStringW( *startRef );
	OutputDebugString (" LastRef: " );
	OutputDebugStringW( *endRef );
	OutputDebugString ("\n" );

	END_BE_SAFE

	if ( pszBookMarker )
		free( pszBookMarker );
	if ( pszChapterMarker )
		free( pszChapterMarker );
	if ( pszVerseMarker )
		free( pszVerseMarker );

	if ( prgchBuf )
		free( prgchBuf );
	if ( fp )
		fclose(fp);

	return retVal;
}
#endif


STDMETHODIMP ECLibrary::GuessFileEncoding(BSTR fileName, EC_FileEncoding *guess,
	EC_FileEncodingSource* src, long * percentCertain)
{
	*guess = FE_Unknown;	// initialize to unknown
	*src = FES_GUESS;		// assume it's a guess...
	*percentCertain = 0;	// just a guess at this point
	
	START_BE_SAFE(ECLibrary::GuessFileEncoding)

	CGuessFileEncoding guesser( fileName );
	
	*guess = guesser.GetFileEncoding();
	*percentCertain = guesser.GetCertiantyPercent();

	if ( guesser.HasBOM() )		// data was determined through a BOM
		*src = FES_BOM;	
		
	END_BE_SAFE

	return S_OK;
}


// Build a safe array container for the character data to be passed
// over the COM boundry and used as byte data.  To convert to BSTR
// and then back to bytes would be additional overhead with no
// benifit: thus the use of safearrays.
//
void PutCharDataInSafeArray(VARIANT &safeArray, const char *data, int len)
{
	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = len;
	psa = SafeArrayCreate(VT_UI1, 1, rgsabound);
	HRESULT hr;

	for( LONG lIndex = 0 ; lIndex < len; lIndex++)
	{
		hr  = SafeArrayPutElement(psa, &lIndex, (void*)(&data[lIndex]) );
	}

	safeArray.vt = VT_UI1 | VT_ARRAY;
	V_ARRAY(&safeArray) = psa;
}


STDMETHODIMP ECLibrary::GetScriptureRefBounds(BSTR bstrFileName, BSTR bookMarker, 
	BSTR chapterMarker, BSTR verseMarker, BSTR *startRef, BSTR *endRef)
{
	return GetScriptureRefBounds2(bstrFileName, bstrFileName, bookMarker, chapterMarker, verseMarker, startRef, endRef);
}


// Read a standard format (Shoebox?) scripture file, and extract the first and last book/chapter/verse
// references found therein.  The output strings look like "GEN 1:1" and "REV 22:25".  Checking is now
// done with the same code that handles the parsing so that we can detect invalid 'parsing' data before
// the 'actual' parsing takes place.

STDMETHODIMP ECLibrary::GetScriptureRefBounds2(BSTR bstrFileName, BSTR bstrOrigFileName, BSTR bookMarker, 
	BSTR chapterMarker, BSTR verseMarker, BSTR *startRef, BSTR *endRef)
{
	char *pszFileName = NULL;
#ifdef __USE_LOGGING
//	CLogger::Instance()->AddLine("Start of ECLibrary::GetScriptureRefBounds");
//	pszFileName = ECUtil::WideToMultiByte( bstrFileName );
	char cBuff[256];
//	sprintf(cBuff, "Processing file <%s>", pszFileName);
//	CLogger::Instance()->AddLine(cBuff);
#endif

	char *pszBookMarker = NULL;
	char *pszChapterMarker = NULL;
	char *pszVerseMarker = NULL;
	char * prgchBuf = NULL;
	bool bCheckVerses = true;

	char *singleChapter_BookIDS[] = {"OBA", "PHM", "2JN", "3JN", "JUD", 
		"LJE", "S3Y", "SUS", "BEL", "MAN", "PS2", "SST", "BLT", 0 };
	
	*startRef = NULL;
	*endRef = NULL;

	// open the file and read it into memory.
	FILE * fp = NULL;
	HRESULT retVal = E_UNEXPECTED;	// S_OK;

	START_BE_SAFE(ECLibrary::GetScriptureRefBounds)

	fp = _wfopen( bstrFileName, L"rb");
	if (!fp)
	{
#ifdef __USE_LOGGING
		CLogger::Instance()->AddLine("** Error ECLibrary::GetScriptureRefBounds : Unable to open file.");
#endif
		OutputDebugString("** Error ECLibrary::GetScriptureRefBounds : Unable to open file <");
		OutputDebugStringW( bstrOrigFileName );
		OutputDebugString(">\n");
		retVal = ECERROR_FileError;
		throw Error(bstrOrigFileName, IID_IECLibrary, retVal);
	}

	long nFileSize = _filelength(_fileno(fp));
	if (nFileSize <= 0L)	// -1 error or empty file
	{
		fclose(fp);
		fp = NULL;
#ifdef __USE_LOGGING
		CLogger::Instance()->AddLine("** Error ECLibrary::GetScriptureRefBounds : File size invalid .");
#endif
		OutputDebugString("** Error ECLibrary::GetScriptureRefBounds : File size invalid <");
		OutputDebugStringW( bstrOrigFileName );
		OutputDebugString(">\n");
		retVal = ECERROR_FileError;		// could have been the standard E_UNEXPECTED;
		throw Error(bstrOrigFileName, IID_IECLibrary, retVal);
	}
	prgchBuf = (char*)malloc(nFileSize + 1);
	if (!prgchBuf)
	{
		fclose(fp);
		fp = NULL;
		retVal = E_OUTOFMEMORY;
		throw retVal;
	}
	if (fread(prgchBuf, nFileSize, 1, fp) != 1)
	{
		fclose(fp);
		fp = NULL;
#ifdef __USE_LOGGING
		CLogger::Instance()->AddLine("** Error ECLibrary::GetScriptureRefBounds : Couldn't read file .");
#endif
		OutputDebugString("** Error ECLibrary::GetScriptureRefBounds : Couldn't read file <");
		OutputDebugStringW( bstrFileName );
		OutputDebugString(">\n");
		free(prgchBuf);
		prgchBuf = NULL;
		retVal = E_UNEXPECTED;
		throw Error(bstrFileName, IID_IECLibrary, retVal);
	}

	fclose(fp);
	fp = NULL;
	prgchBuf[nFileSize] = 0;		// NUL terminate the buffer

	// convert our markers to multibyte data

	pszBookMarker = ECUtil::WideToMultiByte( bookMarker );
	pszChapterMarker = ECUtil::WideToMultiByte( chapterMarker );
	pszVerseMarker = ECUtil::WideToMultiByte( verseMarker );

	if ( !pszBookMarker || !pszChapterMarker || !pszVerseMarker )
	{
		retVal = E_OUTOFMEMORY;
		throw retVal;
	}

	size_t cchBookMarker = strlen(pszBookMarker);		// size of book marker
	size_t cchChapterMarker = strlen(pszChapterMarker);	// size of chapter marker
	size_t cchVerseMarker = strlen(pszVerseMarker);		// size of verse marker

	char   pchChapterOne[] = {"1 "};	// default chapter one text

	int iFirstVerseNum=0;				// integer verse number of first ref first verse
	int iLastVerseNum=0;				// integer verse number of last ref last verse

	char cTemp[64];						// temporary buffer for book and ch and verse nums

	// contain the current information about the file: book(s), chapters and verses
	std::string strFirstBook = "", strBook = "";
	std::string strFirstChapter = "", strChapter = "";
	std::string strFirstVerse = "", strVerse = "";
	std::string strEMPTY = "";

	CComPtr<ISCReference2> qRef;		// ISCReference2 for book and verse checking
	CLSID clsid;
	HRESULT hr = CLSIDFromProgID(L"TESOLib.SCReference", &clsid);
	hr = qRef.CoCreateInstance(L"TESO.SCReference");

	char * pchMark;
	size_t cchMarker;
	//	int chMark = pszBookMarker[0];
	// don't assume that there is a pszBookMarker anymore, if so use it otherwise default to '\\'
	int chMark = pszBookMarker[0];
	if (!strcmp(pszBookMarker, "_NotUsed_"))
		chMark = '\\';
	int iLineNumber = 1;
	int chEndOfLine = 0x0a;		// just use the line feed char WHAT ABOUT UNICODE DATA UTF8 ENDOFLINE
	char *pchEndOfLine = strchr(prgchBuf, chEndOfLine);
	for (pchMark = strchr(prgchBuf, chMark); pchMark; pchMark = strchr(pchMark + cchMarker, chMark))
	{
		// added 9/2004
		if (!pchEndOfLine)	// end of file / last line
			iLineNumber++;
		else
		{
			while (true)
			{
				if (pchMark < pchEndOfLine)	// on the current line
					break;
				else
					pchEndOfLine = strchr(pchEndOfLine+1, chEndOfLine);
				iLineNumber++;
			}
		}

		cchMarker = 1;
		// =======================================================================
		// ============= Process Verse marker and text ===========================
		// =======================================================================
		if (!memcmp(pchMark, pszVerseMarker, cchVerseMarker) && isascii(pchMark[cchVerseMarker]) &&
			isspace(pchMark[cchVerseMarker]))
		{
			cchMarker = cchVerseMarker;

			// check for valid verse text
			char *pchVerseText = pchMark + cchMarker;
			int endposMark = strspn((const char*)pchVerseText, " \t\r\n\f");
			pchVerseText += endposMark;
			endposMark = strcspn((const char*)pchVerseText, "\r\n\f");	// go to end of line
			///////// Put data in safe array to send over COM boundry ///////////
			VARIANT safeArray;
			PutCharDataInSafeArray(safeArray, pchVerseText, endposMark);

			BOOL valid;
			int verseLen, firstVNum;
			qRef->IsValidVerseNumberText(safeArray, &valid, &verseLen, &firstVNum, &iLastVerseNum);
			// create copy of verse text just found and verified
			if (!valid)		// invalid verse text
			{
				int endpos = strcspn((const char*)pchVerseText, " \t\r\n\f");
				pchVerseText[endpos] = 0;
				strVerse = pchVerseText;
				retVal = ECERROR_InvalidVerseNumber; 
				ThrowError(retVal, strBook, strChapter, strVerse, bstrOrigFileName, iLineNumber);
			}

			strncpy(cTemp,pchVerseText,verseLen);
			cTemp[verseLen] = 0;
			strVerse = cTemp;

			if (strFirstBook.length() == 0)						// still no book found
			{
				retVal = ECERROR_VerseNoBook; // found verse with out chapter in non-single chapter book
				ThrowError(retVal, strBook, strChapter, strVerse, bstrOrigFileName, iLineNumber);
			}
			if (strChapter.length() == 0)	// if no chapter then check for single chapter books
			{
				bool found = false;
				for (int cchTemp = 0; singleChapter_BookIDS[cchTemp]; cchTemp++)
				{
					if (!strncmp(strBook.c_str(), singleChapter_BookIDS[cchTemp], 3))
					{
						found = true;
						strChapter = pchChapterOne;
						strFirstChapter = pchChapterOne;
						break;
					}
				}
				if (!found)
				{
					retVal = ECERROR_VerseNoChapter; // found verse with out chapter in non-single chapter book
					ThrowError(retVal, strBook, strChapter, strVerse, bstrOrigFileName, iLineNumber);
				}
			}
			if (strFirstVerse.length() == 0 && strChapter.compare(strFirstChapter)==0)	// pchChapter == pchFirstChapter)
			{
				strFirstVerse = strVerse;
				iFirstVerseNum = firstVNum;
			}
		}
		// =======================================================================
		// ============= Process Chapter marker and text =========================
		// =======================================================================
		else if (!memcmp(pchMark, pszChapterMarker, cchChapterMarker) && isascii(pchMark[cchChapterMarker]) &&
			isspace(pchMark[cchChapterMarker]))
		{
			cchMarker = cchChapterMarker;

			char *pchChapterText = pchMark + cchMarker;
			pchChapterText += strspn(pchChapterText, " \t");
			int endposMark = strcspn((const char*)pchChapterText, " \t\r\n\f");
			strncpy(cTemp, pchChapterText, endposMark);
			cTemp[endposMark] = 0;
			strChapter = cTemp;

			if (FAILED(CheckForValidNumber(pchChapterText, endposMark)))
			{
				retVal = ECERROR_InvalidChapterNumber;
				ThrowError(retVal, strBook, strChapter, strEMPTY, bstrOrigFileName, iLineNumber);
			}

			if (strBook.length() == 0)
			{
				retVal = ECERROR_ChapterNoBook; // found verse with out chapter in non-single chapter book
				ThrowError(retVal, strEMPTY, strChapter, strEMPTY, bstrOrigFileName, iLineNumber);
			}
			if (strFirstChapter.length() == 0)	// !pchFirstChapter)
			{
				strFirstChapter = strChapter;
			}
			strVerse = strEMPTY;
		}
		else if (!memcmp(pchMark, pszBookMarker, cchBookMarker) && isascii(pchMark[cchBookMarker]) &&
			isspace(pchMark[cchBookMarker]))
		{
			// BOOK Marker Found
			cchMarker = cchBookMarker;

			char *pchBookText = pchMark + cchBookMarker;
			pchBookText += strspn(pchBookText, " \t");
			int bookLen = strcspn(pchBookText, " \t\r\n\f");

			///////// Put data in safe array to send over COM boundry ///////////
			VARIANT safeArray;
			PutCharDataInSafeArray(safeArray, pchBookText, bookLen);

			BOOL valid;
			int bookLength;
			qRef->IsValidBookName(safeArray, &valid, &bookLength);
			strncpy(cTemp,pchBookText,bookLength);
			cTemp[bookLength] = 0;
			strBook = cTemp;

			if (!valid)		// invalid book name
			{
				retVal = ECERROR_InvalidBook; 
				ThrowError(retVal, strBook, strEMPTY, strEMPTY, bstrOrigFileName, iLineNumber);
			}

			if (strFirstBook.length() == 0)
			{
				strFirstBook = strBook;
			}
			else
			{
				if (strChapter.length() == 0)	// if no chapter then check for single chapter books
				{
					const char *pchBookTest = strBook.c_str();	//// pchMark + cchMarker;

					bool found = false;
					for (int cchTemp = 0; singleChapter_BookIDS[cchTemp]; cchTemp++)
					{
						if (!strncmp(pchBookTest, singleChapter_BookIDS[cchTemp], 3))
						{
							found = true;
							break;
						}
					}
					if (!found)
					{
						retVal = ECERROR_BooksNoChapters; // found multichapter book without chapter
						ThrowError(retVal, strBook, strEMPTY, strEMPTY, bstrOrigFileName, iLineNumber);
					}
				}
			}
			strChapter = strEMPTY;
			strVerse = strEMPTY;
		}
	}

	// handle case where book and or chapter aren't in file
	HRESULT hrTest = S_OK;
	if (strBook.length() == 0)
		hrTest |= ECERROR_NoBook;

	if (strChapter.length() == 0)
		hrTest |= ECERROR_NoChapter;

	if (hrTest != S_OK)		// missing a book and/or chapter
	{
		retVal = hrTest;	// set return HRESULT value
		ThrowError(retVal, strBook, strChapter, strEMPTY, bstrOrigFileName, iLineNumber);
	}

	// Now build the BSTR first and last references.  These aren't the literal verse refs, those
	// will come from the data when it's parsed during reading, these are for getting a valid
	// starting and ending int value for book, chapter and verse.  Segments don't show up here
	// as they aren't needed of add any additional information or value.  So an acutal first ref
	// of GEN 1:7a would be "GEN 1:7".  The code for reading would pick up the segments.

	CComBSTR bstrFirst;
	bstrFirst = strFirstBook.c_str();	// (NOTE: uses CP_ACP conversion in all likelihood.)
	bstrFirst.Append(L" ");
	int iChapter = Utf8NumberToInt(strFirstChapter.c_str(), strFirstChapter.length());
	if (iChapter == 1)
	{
		// TODO: figure out whether we want a vernacular digit character here, and what it would
		// be.
		bstrFirst.Append(L"0");
	}
	else
	{
		// Convert first chapter number from UTF-8 to UTF-16 before appending to the BSTR.
		wchar_t * pszT = ECUtil::MultiByteToWide(strFirstChapter.c_str(), strFirstChapter.length());
		bstrFirst.Append(pszT);
		free(pszT);
	}

	bstrFirst.Append(L":");

	int iVerse = 1;
	if (iFirstVerseNum != 0)
		iVerse = iFirstVerseNum;
	if (iVerse == 1)
	{
		bstrFirst.Append(L"0");
	}
	else
	{
		// instead of using the literal verse string, just use the integer portion returned
		itoa(iVerse,cTemp,10);
		wchar_t * pszT = ECUtil::MultiByteToWide(cTemp, strlen(cTemp));
		bstrFirst.Append(pszT);
		free(pszT);
	}

	*startRef = bstrFirst.Copy();

	CComBSTR bstrLast;
	bstrLast = strBook.c_str();	// pchBook;
	bstrLast.Append(L" ");
	// Convert chapter number from UTF-8 to UTF-16 before appending to the BSTR.
	wchar_t * pszT = ECUtil::MultiByteToWide(strChapter.c_str(), strChapter.length());
	bstrLast.Append(pszT);
	free(pszT);
	bstrLast.Append(L":");
	// Convert verse number from UTF-8 to UTF-16 before appending to the BSTR.
	if (iLastVerseNum != 0)
	{
		// instead of using the literal verse string, just use the integer portion returned
		itoa(iLastVerseNum, cTemp, 10);
		pszT = ECUtil::MultiByteToWide(cTemp, strlen(cTemp));
		bstrLast.Append(pszT);
		free(pszT);
		pszT = NULL;
	}
	else
	{
		bstrLast.Append(L"0");
	}
	*endRef = bstrLast.Copy();

	OutputDebugString ("\n" );
	OutputDebugStringW( bstrFileName );
	OutputDebugString (": FirstRef: " );
	OutputDebugStringW( *startRef );
	OutputDebugString (" LastRef: " );
	OutputDebugStringW( *endRef );
	OutputDebugString ("\n" );

#ifdef __USE_LOGGING_VERBOSE
	{
		char *pszRef1 = ECUtil::WideToMultiByte(*startRef);
		char *pszRef2 = ECUtil::WideToMultiByte(*endRef);
		sprintf(cBuff, "FirstRef: %s  LastRef: %s", pszRef1, pszRef2);
		CLogger::Instance()->AddLine(cBuff);
		free(pszRef1);
		free(pszRef2);
	}
#endif
	retVal = S_OK;	// made it through with out unhandled exception - S_OK return value
	END_BE_SAFE

	if (!besafeTrue)
	{
#ifdef __USE_LOGGING
		CLogger::Instance()->AddLine("ECLibrary::GetScriptureRefBounds");
		pszFileName = ECUtil::WideToMultiByte( bstrFileName );
		sprintf(cBuff, "Processing file <%s>", pszFileName);
		CLogger::Instance()->AddLine(cBuff);
		CLogger::Instance()->AddLine("*** Exception caught in method.");
		sprintf(cBuff, "Retval = 0x%0X", retVal);
		CLogger::Instance()->AddLine(cBuff);
//		sprintf(cBuff, "*** last value for CurrentLine = %d", currentLine);
//		CLogger::Instance()->AddLine(cBuff);
#endif
	}

	if ( pszBookMarker )
		free( pszBookMarker );
	if ( pszChapterMarker )
		free( pszChapterMarker );
	if ( pszVerseMarker )
		free( pszVerseMarker );
	if (pszFileName)
		free( pszFileName);

	if ( prgchBuf )
		free( prgchBuf );
	if ( fp )
		fclose(fp);


#ifdef __USE_LOGGING_VERBOSE
	sprintf(cBuff, "Retval = 0x%0X", retVal);
	CLogger::Instance()->AddLine(cBuff);
#endif

	return retVal;
}


// Throw an HRESULT error with the passed in strings.  Create the Error info data via the 'Error' method.
//
void ECLibrary::ThrowError(HRESULT hr, const std::string &book, const std::string & chapter, const std::string &verse,
						   BSTR fileName, int lineNumber)
{
	// convert line number to wstr
	wchar_t wcharLine[8];
	swprintf(wcharLine, L"%d", lineNumber);

	// Convert book, verse, chapter data from UTF-8 to UTF-16 before adding to wstr
	wchar_t * pwszBook  = ECUtil::MultiByteToWide(book.c_str(), book.length());
	wchar_t * pwszChap  = ECUtil::MultiByteToWide(chapter.c_str(), chapter.length());
	wchar_t * pwszVerse = ECUtil::MultiByteToWide(verse.c_str(), verse.length());

	// build the string : file,line,book,chapter,verse
	CComBSTR wmsg = fileName;
	wmsg += L",";
	wmsg += wcharLine;
	wmsg += L",";
	wmsg += pwszBook;	//_T(book.c_str());
	wmsg += L",";
	wmsg += pwszChap;	//_T(chapter.c_str());
	wmsg += L",";
	wmsg += pwszVerse;	//_T(verse.c_str());

	free(pwszBook);
	free(pwszChap);
	free(pwszVerse);

	throw Error(wmsg, IID_IECLibrary, hr);
}
