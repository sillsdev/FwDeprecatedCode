// ECMapping.cpp : Implementation of CECMapping
#include "stdafx.h"
#include "ECObjects.h"
#include "ECMapping.h"

#include <io.h>		// _waccess
/////////////////////////////////////////////////////////////////////////////
// CECMapping

STDMETHODIMP CECMapping::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IECMapping
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

/*
CECMapping()::CECMapping(): CTraceCreation( "CECMapping" )
{
}

CECMapping()::~CECMapping()
{
	OutputDebugString("~CECMapping()\n");
}
*/

STDMETHODIMP CECMapping::get_ID(long *pVal)
{
	*pVal = m_Data.GetID();		// retrieve the value from the AutoIncrement object
	return S_OK;
}

STDMETHODIMP CECMapping::get_BeginMarker(BSTR *pVal)
{
	m_Data.GetBeginMarker( pVal );
	return S_OK;
}

STDMETHODIMP CECMapping::put_BeginMarker(BSTR newVal)
{
	m_Data.SetBeginMarker( newVal );
	return S_OK;
}

STDMETHODIMP CECMapping::get_EndMarker(BSTR *pVal)
{
	m_Data.GetEndMarker( pVal );
	return S_OK;
}

STDMETHODIMP CECMapping::put_EndMarker(BSTR newVal)
{
	m_Data.SetEndMarker( newVal );
	return S_OK;
}

STDMETHODIMP CECMapping::get_DataEncoding(BSTR *pVal)
{
	m_Data.GetDataEncoding( pVal );
	return S_OK;
}

STDMETHODIMP CECMapping::put_DataEncoding(BSTR newVal)
{
///	if( ::SysStringLen(newVal) > 0 && _waccess( newVal, 0 ) != 0 )
///		return E_INVALIDARG;

	m_Data.SetDataEncoding( newVal );
	return S_OK;
}

STDMETHODIMP CECMapping::get_MarkerEncoding(BSTR *pVal)
{
	m_Data.GetMarkerEncoding( pVal );
	return S_OK;
}

STDMETHODIMP CECMapping::put_MarkerEncoding(BSTR newVal)
{
///	if( ::SysStringLen(newVal) > 0 && _waccess( newVal, 0 ) != 0 )
///		return E_INVALIDARG;

	m_Data.SetMarkerEncoding( newVal );
	return S_OK;
}

STDMETHODIMP CECMapping::get_StyleName(BSTR *pVal)
{
	m_Data.GetStyleName( pVal );
	return S_OK;
}

STDMETHODIMP CECMapping::put_StyleName(BSTR newVal)
{
	m_Data.SetStyleName( newVal );
	return S_OK;
}

STDMETHODIMP CECMapping::get_IsInline(BOOL *pVal)
{
	*pVal = m_Data.GetIsInline();
	return S_OK;
}

STDMETHODIMP CECMapping::put_IsInline(BOOL newVal)
{
	m_Data.SetInline( newVal );
	return S_OK;
}

STDMETHODIMP CECMapping::get_Domain(MarkerDomain *pVal)
{
	*pVal = m_Data.GetDomain();
	return S_OK;
}

STDMETHODIMP CECMapping::put_Domain(MarkerDomain newVal)
{
	m_Data.SetDomain( newVal );
	return S_OK;
}

STDMETHODIMP CECMapping::get_IsConfirmed(BOOL *pVal)
{
	*pVal = m_Data.GetIsConfirmed();
	return S_OK;
}

STDMETHODIMP CECMapping::put_IsConfirmed(BOOL newVal)
{
	m_Data.SetConfirmed( newVal );
	return S_OK;
}


STDMETHODIMP CECMapping::get_WritingSystem(BSTR *pVal)
{
	m_Data.GetWritingSystem( pVal );
	return S_OK;
}

STDMETHODIMP CECMapping::put_WritingSystem(BSTR newVal)
{
	m_Data.SetWritingSystem( newVal );
	return S_OK;
}

/*
STDMETHODIMP CECMapping::AsReadOnly(IECMappingRO **readOnly)
{
	return S_OK;
}

STDMETHODIMP CECMapping::get_ReadOnly(IDispatch **pVal)
{
	return S_OK;
}
*/

STDMETHODIMP CECMapping::Init(VARIANT *myData)
{
	if ( myData->vt != VT_USERDEFINED )
		return E_INVALIDARG;

	CInternalMappingData * data = (CInternalMappingData*) myData->byref;
	if ( !data )
	{
		return E_INVALIDARG;
	}

//	m_Data.SetBeginMarker( data->GetBeginMarker() );
	m_Data = *data;	// assignment opperator

	int asdf = 2134;

	return S_OK;
}

CInternalMappingData* CECMapping::InternalDataCopy()
{
	CInternalMappingData* rval = new CInternalMappingData( m_Data );
	return rval;
}



STDMETHODIMP CECMapping::get_DomainAsBSTR(BSTR *pVal)
{
	switch ( m_Data.GetDomain() )
	{
		case MD_Vern:
			*pVal = ::SysAllocString( L"Vern"); 
			break;

		case MD_Back:
			*pVal = ::SysAllocString( L"Back"); 
			break;

		case MD_Note:
			*pVal = ::SysAllocString( L"Note"); 
			break;

		case MD_Unknown:
		default:
			*pVal = ::SysAllocString( L"Unknown"); 
			break;
	}
	return S_OK;
}

STDMETHODIMP CECMapping::get_NewBeginMarker(BSTR *pVal)
{
	m_Data.GetNewBeginMarker( pVal );
	return S_OK;
}

STDMETHODIMP CECMapping::get_NewEndMarker(BSTR *pVal)
{
	m_Data.GetNewEndMarker( pVal );
	return S_OK;
}

