

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Fri Jul 29 16:12:08 2005
 */
/* Compiler settings for ECObjects.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ECObjects_h__
#define __ECObjects_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IECProjectFileInfo_FWD_DEFINED__
#define __IECProjectFileInfo_FWD_DEFINED__
typedef interface IECProjectFileInfo IECProjectFileInfo;
#endif 	/* __IECProjectFileInfo_FWD_DEFINED__ */


#ifndef __IECLibrary_FWD_DEFINED__
#define __IECLibrary_FWD_DEFINED__
typedef interface IECLibrary IECLibrary;
#endif 	/* __IECLibrary_FWD_DEFINED__ */


#ifndef __IECLibrary2_FWD_DEFINED__
#define __IECLibrary2_FWD_DEFINED__
typedef interface IECLibrary2 IECLibrary2;
#endif 	/* __IECLibrary2_FWD_DEFINED__ */


#ifndef __IECMapping_FWD_DEFINED__
#define __IECMapping_FWD_DEFINED__
typedef interface IECMapping IECMapping;
#endif 	/* __IECMapping_FWD_DEFINED__ */


#ifndef __IECProject_FWD_DEFINED__
#define __IECProject_FWD_DEFINED__
typedef interface IECProject IECProject;
#endif 	/* __IECProject_FWD_DEFINED__ */


#ifndef __IParatextProjectProxy_FWD_DEFINED__
#define __IParatextProjectProxy_FWD_DEFINED__
typedef interface IParatextProjectProxy IParatextProjectProxy;
#endif 	/* __IParatextProjectProxy_FWD_DEFINED__ */


#ifndef __ECProject_FWD_DEFINED__
#define __ECProject_FWD_DEFINED__

#ifdef __cplusplus
typedef class ECProject ECProject;
#else
typedef struct ECProject ECProject;
#endif /* __cplusplus */

#endif 	/* __ECProject_FWD_DEFINED__ */


#ifndef __ParatextProjectProxy_FWD_DEFINED__
#define __ParatextProjectProxy_FWD_DEFINED__

#ifdef __cplusplus
typedef class ParatextProjectProxy ParatextProjectProxy;
#else
typedef struct ParatextProjectProxy ParatextProjectProxy;
#endif /* __cplusplus */

#endif 	/* __ParatextProjectProxy_FWD_DEFINED__ */


#ifndef __ECMapping_FWD_DEFINED__
#define __ECMapping_FWD_DEFINED__

#ifdef __cplusplus
typedef class ECMapping ECMapping;
#else
typedef struct ECMapping ECMapping;
#endif /* __cplusplus */

#endif 	/* __ECMapping_FWD_DEFINED__ */


#ifndef __ECLibrary_FWD_DEFINED__
#define __ECLibrary_FWD_DEFINED__

#ifdef __cplusplus
typedef class ECLibrary ECLibrary;
#else
typedef struct ECLibrary ECLibrary;
#endif /* __cplusplus */

#endif 	/* __ECLibrary_FWD_DEFINED__ */


#ifndef __ECProjectFileInfo_FWD_DEFINED__
#define __ECProjectFileInfo_FWD_DEFINED__

#ifdef __cplusplus
typedef class ECProjectFileInfo ECProjectFileInfo;
#else
typedef struct ECProjectFileInfo ECProjectFileInfo;
#endif /* __cplusplus */

#endif 	/* __ECProjectFileInfo_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

/* interface __MIDL_itf_ECObjects_0000 */
/* [local] */ 

typedef /* [public][public][public][public][public][public][public][public][helpstring][uuid] */  DECLSPEC_UUID("61D9D52A-62AC-4f9f-9BC7-1728D66B3DFB") 
enum __MIDL___MIDL_itf_ECObjects_0000_0001
    {	MD_Unknown	= 0,
	MD_Vern	= 0x1,
	MD_Back	= 0x2,
	MD_Note	= 0x4,
	MD_Footnote	= 0x8
    } 	MarkerDomain;

typedef /* [public][public][public][public][public][public][helpstring][uuid] */  DECLSPEC_UUID("1713D5E4-2C47-418c-B332-5FB796E5B5FC") 
enum __MIDL___MIDL_itf_ECObjects_0000_0002
    {	FE_Unknown	= 0x1,
	FE_BYTES	= 0x2,
	FE_UTF8	= 0x4,
	FE_UTF16BE	= 0x10,
	FE_UTF16LE	= 0x20,
	FE_UTF32BE	= 0x40,
	FE_UTF32LE	= 0x80
    } 	EC_FileEncoding;

typedef /* [public][public][public][helpstring][uuid] */  DECLSPEC_UUID("8F63074F-E5CF-4638-A8C9-2E0FDF15DB5C") 
enum __MIDL___MIDL_itf_ECObjects_0000_0003
    {	FES_GUESS	= 0,
	FES_BOM	= FES_GUESS + 1,
	FES_USER	= FES_BOM + 1
    } 	EC_FileEncodingSource;



extern RPC_IF_HANDLE __MIDL_itf_ECObjects_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_ECObjects_0000_v0_0_s_ifspec;

#ifndef __IECProjectFileInfo_INTERFACE_DEFINED__
#define __IECProjectFileInfo_INTERFACE_DEFINED__

/* interface IECProjectFileInfo */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IECProjectFileInfo;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("90AFA6B6-A6E8-4173-B203-2C50BD705809")
    IECProjectFileInfo : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FileEncodingSource( 
            /* [retval][out] */ EC_FileEncodingSource *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FileEncoding( 
            /* [retval][out] */ EC_FileEncoding *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FileEncoding( 
            /* [in] */ EC_FileEncoding newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_InputFileName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_InputFileName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_OutputFileName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_OutputFileName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_SurenessPercent( 
            /* [retval][out] */ short *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_SurenessPercent( 
            /* [in] */ short newVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Init( 
            VARIANT *myData) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_HasBOM( 
            /* [retval][out] */ BOOL *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IECProjectFileInfoVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IECProjectFileInfo * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IECProjectFileInfo * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IECProjectFileInfo * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IECProjectFileInfo * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IECProjectFileInfo * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IECProjectFileInfo * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IECProjectFileInfo * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_FileEncodingSource )( 
            IECProjectFileInfo * This,
            /* [retval][out] */ EC_FileEncodingSource *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_FileEncoding )( 
            IECProjectFileInfo * This,
            /* [retval][out] */ EC_FileEncoding *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_FileEncoding )( 
            IECProjectFileInfo * This,
            /* [in] */ EC_FileEncoding newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_InputFileName )( 
            IECProjectFileInfo * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_InputFileName )( 
            IECProjectFileInfo * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_OutputFileName )( 
            IECProjectFileInfo * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_OutputFileName )( 
            IECProjectFileInfo * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_SurenessPercent )( 
            IECProjectFileInfo * This,
            /* [retval][out] */ short *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_SurenessPercent )( 
            IECProjectFileInfo * This,
            /* [in] */ short newVal);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IECProjectFileInfo * This,
            VARIANT *myData);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasBOM )( 
            IECProjectFileInfo * This,
            /* [retval][out] */ BOOL *pVal);
        
        END_INTERFACE
    } IECProjectFileInfoVtbl;

    interface IECProjectFileInfo
    {
        CONST_VTBL struct IECProjectFileInfoVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IECProjectFileInfo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IECProjectFileInfo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IECProjectFileInfo_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IECProjectFileInfo_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IECProjectFileInfo_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IECProjectFileInfo_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IECProjectFileInfo_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IECProjectFileInfo_get_FileEncodingSource(This,pVal)	\
    (This)->lpVtbl -> get_FileEncodingSource(This,pVal)

#define IECProjectFileInfo_get_FileEncoding(This,pVal)	\
    (This)->lpVtbl -> get_FileEncoding(This,pVal)

#define IECProjectFileInfo_put_FileEncoding(This,newVal)	\
    (This)->lpVtbl -> put_FileEncoding(This,newVal)

#define IECProjectFileInfo_get_InputFileName(This,pVal)	\
    (This)->lpVtbl -> get_InputFileName(This,pVal)

#define IECProjectFileInfo_put_InputFileName(This,newVal)	\
    (This)->lpVtbl -> put_InputFileName(This,newVal)

#define IECProjectFileInfo_get_OutputFileName(This,pVal)	\
    (This)->lpVtbl -> get_OutputFileName(This,pVal)

#define IECProjectFileInfo_put_OutputFileName(This,newVal)	\
    (This)->lpVtbl -> put_OutputFileName(This,newVal)

#define IECProjectFileInfo_get_SurenessPercent(This,pVal)	\
    (This)->lpVtbl -> get_SurenessPercent(This,pVal)

#define IECProjectFileInfo_put_SurenessPercent(This,newVal)	\
    (This)->lpVtbl -> put_SurenessPercent(This,newVal)

#define IECProjectFileInfo_Init(This,myData)	\
    (This)->lpVtbl -> Init(This,myData)

#define IECProjectFileInfo_get_HasBOM(This,pVal)	\
    (This)->lpVtbl -> get_HasBOM(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_get_FileEncodingSource_Proxy( 
    IECProjectFileInfo * This,
    /* [retval][out] */ EC_FileEncodingSource *pVal);


void __RPC_STUB IECProjectFileInfo_get_FileEncodingSource_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_get_FileEncoding_Proxy( 
    IECProjectFileInfo * This,
    /* [retval][out] */ EC_FileEncoding *pVal);


void __RPC_STUB IECProjectFileInfo_get_FileEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_put_FileEncoding_Proxy( 
    IECProjectFileInfo * This,
    /* [in] */ EC_FileEncoding newVal);


void __RPC_STUB IECProjectFileInfo_put_FileEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_get_InputFileName_Proxy( 
    IECProjectFileInfo * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECProjectFileInfo_get_InputFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_put_InputFileName_Proxy( 
    IECProjectFileInfo * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECProjectFileInfo_put_InputFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_get_OutputFileName_Proxy( 
    IECProjectFileInfo * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECProjectFileInfo_get_OutputFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_put_OutputFileName_Proxy( 
    IECProjectFileInfo * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECProjectFileInfo_put_OutputFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_get_SurenessPercent_Proxy( 
    IECProjectFileInfo * This,
    /* [retval][out] */ short *pVal);


void __RPC_STUB IECProjectFileInfo_get_SurenessPercent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_put_SurenessPercent_Proxy( 
    IECProjectFileInfo * This,
    /* [in] */ short newVal);


void __RPC_STUB IECProjectFileInfo_put_SurenessPercent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProjectFileInfo_Init_Proxy( 
    IECProjectFileInfo * This,
    VARIANT *myData);


void __RPC_STUB IECProjectFileInfo_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProjectFileInfo_get_HasBOM_Proxy( 
    IECProjectFileInfo * This,
    /* [retval][out] */ BOOL *pVal);


void __RPC_STUB IECProjectFileInfo_get_HasBOM_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IECProjectFileInfo_INTERFACE_DEFINED__ */


#ifndef __IECLibrary_INTERFACE_DEFINED__
#define __IECLibrary_INTERFACE_DEFINED__

/* interface IECLibrary */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IECLibrary;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("99A8744D-D5A9-4CF0-9008-AEB87A6927AD")
    IECLibrary : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_EncodingNames( 
            /* [retval][out] */ VARIANT *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_StyleNames( 
            /* [retval][out] */ VARIANT *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_MarkerDomainNames( 
            /* [retval][out] */ VARIANT *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_MarkerDomainInts( 
            /* [retval][out] */ VARIANT *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_MarkerDomainAsBSTR( 
            /* [in] */ int domainID,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_TEStyleName( 
            /* [in] */ BSTR BeginMarker,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_SOMarkerFields( 
            /* [in] */ BSTR BeginMarker,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_BeginMarkerForStyleName( 
            /* [in] */ BSTR teStyleName,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TestSO( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MakeSOStyleFile( 
            /* [in] */ BSTR fName,
            /* [in] */ VARIANT pSafeArray) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ReadInTEStyleNames( 
            /* [in] */ BSTR styFile,
            /* [out] */ long *numStyles) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetScriptureRefBounds( 
            BSTR fileName,
            BSTR BookMarker,
            BSTR chapterMarker,
            BSTR verseMarker,
            /* [out] */ BSTR *startRef,
            /* [out] */ BSTR *endRef) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GuessFileEncoding( 
            /* [in] */ BSTR fileName,
            /* [out] */ EC_FileEncoding *guess,
            /* [out] */ EC_FileEncodingSource *src,
            /* [out] */ long *percentCertian) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IECLibraryVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IECLibrary * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IECLibrary * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IECLibrary * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IECLibrary * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IECLibrary * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IECLibrary * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IECLibrary * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_EncodingNames )( 
            IECLibrary * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_StyleNames )( 
            IECLibrary * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_MarkerDomainNames )( 
            IECLibrary * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_MarkerDomainInts )( 
            IECLibrary * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_MarkerDomainAsBSTR )( 
            IECLibrary * This,
            /* [in] */ int domainID,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_TEStyleName )( 
            IECLibrary * This,
            /* [in] */ BSTR BeginMarker,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_SOMarkerFields )( 
            IECLibrary * This,
            /* [in] */ BSTR BeginMarker,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_BeginMarkerForStyleName )( 
            IECLibrary * This,
            /* [in] */ BSTR teStyleName,
            /* [retval][out] */ BSTR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE *TestSO )( 
            IECLibrary * This);
        
        HRESULT ( STDMETHODCALLTYPE *MakeSOStyleFile )( 
            IECLibrary * This,
            /* [in] */ BSTR fName,
            /* [in] */ VARIANT pSafeArray);
        
        HRESULT ( STDMETHODCALLTYPE *ReadInTEStyleNames )( 
            IECLibrary * This,
            /* [in] */ BSTR styFile,
            /* [out] */ long *numStyles);
        
        HRESULT ( STDMETHODCALLTYPE *GetScriptureRefBounds )( 
            IECLibrary * This,
            BSTR fileName,
            BSTR BookMarker,
            BSTR chapterMarker,
            BSTR verseMarker,
            /* [out] */ BSTR *startRef,
            /* [out] */ BSTR *endRef);
        
        HRESULT ( STDMETHODCALLTYPE *GuessFileEncoding )( 
            IECLibrary * This,
            /* [in] */ BSTR fileName,
            /* [out] */ EC_FileEncoding *guess,
            /* [out] */ EC_FileEncodingSource *src,
            /* [out] */ long *percentCertian);
        
        END_INTERFACE
    } IECLibraryVtbl;

    interface IECLibrary
    {
        CONST_VTBL struct IECLibraryVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IECLibrary_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IECLibrary_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IECLibrary_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IECLibrary_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IECLibrary_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IECLibrary_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IECLibrary_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IECLibrary_get_EncodingNames(This,pVal)	\
    (This)->lpVtbl -> get_EncodingNames(This,pVal)

#define IECLibrary_get_StyleNames(This,pVal)	\
    (This)->lpVtbl -> get_StyleNames(This,pVal)

#define IECLibrary_get_MarkerDomainNames(This,pVal)	\
    (This)->lpVtbl -> get_MarkerDomainNames(This,pVal)

#define IECLibrary_get_MarkerDomainInts(This,pVal)	\
    (This)->lpVtbl -> get_MarkerDomainInts(This,pVal)

#define IECLibrary_get_MarkerDomainAsBSTR(This,domainID,pVal)	\
    (This)->lpVtbl -> get_MarkerDomainAsBSTR(This,domainID,pVal)

#define IECLibrary_get_TEStyleName(This,BeginMarker,pVal)	\
    (This)->lpVtbl -> get_TEStyleName(This,BeginMarker,pVal)

#define IECLibrary_get_SOMarkerFields(This,BeginMarker,pVal)	\
    (This)->lpVtbl -> get_SOMarkerFields(This,BeginMarker,pVal)

#define IECLibrary_get_BeginMarkerForStyleName(This,teStyleName,pVal)	\
    (This)->lpVtbl -> get_BeginMarkerForStyleName(This,teStyleName,pVal)

#define IECLibrary_TestSO(This)	\
    (This)->lpVtbl -> TestSO(This)

#define IECLibrary_MakeSOStyleFile(This,fName,pSafeArray)	\
    (This)->lpVtbl -> MakeSOStyleFile(This,fName,pSafeArray)

#define IECLibrary_ReadInTEStyleNames(This,styFile,numStyles)	\
    (This)->lpVtbl -> ReadInTEStyleNames(This,styFile,numStyles)

#define IECLibrary_GetScriptureRefBounds(This,fileName,BookMarker,chapterMarker,verseMarker,startRef,endRef)	\
    (This)->lpVtbl -> GetScriptureRefBounds(This,fileName,BookMarker,chapterMarker,verseMarker,startRef,endRef)

#define IECLibrary_GuessFileEncoding(This,fileName,guess,src,percentCertian)	\
    (This)->lpVtbl -> GuessFileEncoding(This,fileName,guess,src,percentCertian)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE IECLibrary_get_EncodingNames_Proxy( 
    IECLibrary * This,
    /* [retval][out] */ VARIANT *pVal);


void __RPC_STUB IECLibrary_get_EncodingNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECLibrary_get_StyleNames_Proxy( 
    IECLibrary * This,
    /* [retval][out] */ VARIANT *pVal);


void __RPC_STUB IECLibrary_get_StyleNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECLibrary_get_MarkerDomainNames_Proxy( 
    IECLibrary * This,
    /* [retval][out] */ VARIANT *pVal);


void __RPC_STUB IECLibrary_get_MarkerDomainNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECLibrary_get_MarkerDomainInts_Proxy( 
    IECLibrary * This,
    /* [retval][out] */ VARIANT *pVal);


void __RPC_STUB IECLibrary_get_MarkerDomainInts_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECLibrary_get_MarkerDomainAsBSTR_Proxy( 
    IECLibrary * This,
    /* [in] */ int domainID,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECLibrary_get_MarkerDomainAsBSTR_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECLibrary_get_TEStyleName_Proxy( 
    IECLibrary * This,
    /* [in] */ BSTR BeginMarker,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECLibrary_get_TEStyleName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECLibrary_get_SOMarkerFields_Proxy( 
    IECLibrary * This,
    /* [in] */ BSTR BeginMarker,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECLibrary_get_SOMarkerFields_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECLibrary_get_BeginMarkerForStyleName_Proxy( 
    IECLibrary * This,
    /* [in] */ BSTR teStyleName,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECLibrary_get_BeginMarkerForStyleName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECLibrary_TestSO_Proxy( 
    IECLibrary * This);


void __RPC_STUB IECLibrary_TestSO_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECLibrary_MakeSOStyleFile_Proxy( 
    IECLibrary * This,
    /* [in] */ BSTR fName,
    /* [in] */ VARIANT pSafeArray);


void __RPC_STUB IECLibrary_MakeSOStyleFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECLibrary_ReadInTEStyleNames_Proxy( 
    IECLibrary * This,
    /* [in] */ BSTR styFile,
    /* [out] */ long *numStyles);


void __RPC_STUB IECLibrary_ReadInTEStyleNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECLibrary_GetScriptureRefBounds_Proxy( 
    IECLibrary * This,
    BSTR fileName,
    BSTR BookMarker,
    BSTR chapterMarker,
    BSTR verseMarker,
    /* [out] */ BSTR *startRef,
    /* [out] */ BSTR *endRef);


void __RPC_STUB IECLibrary_GetScriptureRefBounds_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECLibrary_GuessFileEncoding_Proxy( 
    IECLibrary * This,
    /* [in] */ BSTR fileName,
    /* [out] */ EC_FileEncoding *guess,
    /* [out] */ EC_FileEncodingSource *src,
    /* [out] */ long *percentCertian);


void __RPC_STUB IECLibrary_GuessFileEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IECLibrary_INTERFACE_DEFINED__ */


#ifndef __IECLibrary2_INTERFACE_DEFINED__
#define __IECLibrary2_INTERFACE_DEFINED__

/* interface IECLibrary2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IECLibrary2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("380FBC38-A844-4105-AC6F-8B2832A14EEB")
    IECLibrary2 : public IECLibrary
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetScriptureRefBounds2( 
            BSTR fileName,
            BSTR origFileName,
            BSTR BookMarker,
            BSTR chapterMarker,
            BSTR verseMarker,
            /* [out] */ BSTR *startRef,
            /* [out] */ BSTR *endRef) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IECLibrary2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IECLibrary2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IECLibrary2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IECLibrary2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IECLibrary2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IECLibrary2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IECLibrary2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IECLibrary2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_EncodingNames )( 
            IECLibrary2 * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_StyleNames )( 
            IECLibrary2 * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_MarkerDomainNames )( 
            IECLibrary2 * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_MarkerDomainInts )( 
            IECLibrary2 * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_MarkerDomainAsBSTR )( 
            IECLibrary2 * This,
            /* [in] */ int domainID,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_TEStyleName )( 
            IECLibrary2 * This,
            /* [in] */ BSTR BeginMarker,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_SOMarkerFields )( 
            IECLibrary2 * This,
            /* [in] */ BSTR BeginMarker,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_BeginMarkerForStyleName )( 
            IECLibrary2 * This,
            /* [in] */ BSTR teStyleName,
            /* [retval][out] */ BSTR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE *TestSO )( 
            IECLibrary2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *MakeSOStyleFile )( 
            IECLibrary2 * This,
            /* [in] */ BSTR fName,
            /* [in] */ VARIANT pSafeArray);
        
        HRESULT ( STDMETHODCALLTYPE *ReadInTEStyleNames )( 
            IECLibrary2 * This,
            /* [in] */ BSTR styFile,
            /* [out] */ long *numStyles);
        
        HRESULT ( STDMETHODCALLTYPE *GetScriptureRefBounds )( 
            IECLibrary2 * This,
            BSTR fileName,
            BSTR BookMarker,
            BSTR chapterMarker,
            BSTR verseMarker,
            /* [out] */ BSTR *startRef,
            /* [out] */ BSTR *endRef);
        
        HRESULT ( STDMETHODCALLTYPE *GuessFileEncoding )( 
            IECLibrary2 * This,
            /* [in] */ BSTR fileName,
            /* [out] */ EC_FileEncoding *guess,
            /* [out] */ EC_FileEncodingSource *src,
            /* [out] */ long *percentCertian);
        
        HRESULT ( STDMETHODCALLTYPE *GetScriptureRefBounds2 )( 
            IECLibrary2 * This,
            BSTR fileName,
            BSTR origFileName,
            BSTR BookMarker,
            BSTR chapterMarker,
            BSTR verseMarker,
            /* [out] */ BSTR *startRef,
            /* [out] */ BSTR *endRef);
        
        END_INTERFACE
    } IECLibrary2Vtbl;

    interface IECLibrary2
    {
        CONST_VTBL struct IECLibrary2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IECLibrary2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IECLibrary2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IECLibrary2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IECLibrary2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IECLibrary2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IECLibrary2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IECLibrary2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IECLibrary2_get_EncodingNames(This,pVal)	\
    (This)->lpVtbl -> get_EncodingNames(This,pVal)

#define IECLibrary2_get_StyleNames(This,pVal)	\
    (This)->lpVtbl -> get_StyleNames(This,pVal)

#define IECLibrary2_get_MarkerDomainNames(This,pVal)	\
    (This)->lpVtbl -> get_MarkerDomainNames(This,pVal)

#define IECLibrary2_get_MarkerDomainInts(This,pVal)	\
    (This)->lpVtbl -> get_MarkerDomainInts(This,pVal)

#define IECLibrary2_get_MarkerDomainAsBSTR(This,domainID,pVal)	\
    (This)->lpVtbl -> get_MarkerDomainAsBSTR(This,domainID,pVal)

#define IECLibrary2_get_TEStyleName(This,BeginMarker,pVal)	\
    (This)->lpVtbl -> get_TEStyleName(This,BeginMarker,pVal)

#define IECLibrary2_get_SOMarkerFields(This,BeginMarker,pVal)	\
    (This)->lpVtbl -> get_SOMarkerFields(This,BeginMarker,pVal)

#define IECLibrary2_get_BeginMarkerForStyleName(This,teStyleName,pVal)	\
    (This)->lpVtbl -> get_BeginMarkerForStyleName(This,teStyleName,pVal)

#define IECLibrary2_TestSO(This)	\
    (This)->lpVtbl -> TestSO(This)

#define IECLibrary2_MakeSOStyleFile(This,fName,pSafeArray)	\
    (This)->lpVtbl -> MakeSOStyleFile(This,fName,pSafeArray)

#define IECLibrary2_ReadInTEStyleNames(This,styFile,numStyles)	\
    (This)->lpVtbl -> ReadInTEStyleNames(This,styFile,numStyles)

#define IECLibrary2_GetScriptureRefBounds(This,fileName,BookMarker,chapterMarker,verseMarker,startRef,endRef)	\
    (This)->lpVtbl -> GetScriptureRefBounds(This,fileName,BookMarker,chapterMarker,verseMarker,startRef,endRef)

#define IECLibrary2_GuessFileEncoding(This,fileName,guess,src,percentCertian)	\
    (This)->lpVtbl -> GuessFileEncoding(This,fileName,guess,src,percentCertian)


#define IECLibrary2_GetScriptureRefBounds2(This,fileName,origFileName,BookMarker,chapterMarker,verseMarker,startRef,endRef)	\
    (This)->lpVtbl -> GetScriptureRefBounds2(This,fileName,origFileName,BookMarker,chapterMarker,verseMarker,startRef,endRef)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IECLibrary2_GetScriptureRefBounds2_Proxy( 
    IECLibrary2 * This,
    BSTR fileName,
    BSTR origFileName,
    BSTR BookMarker,
    BSTR chapterMarker,
    BSTR verseMarker,
    /* [out] */ BSTR *startRef,
    /* [out] */ BSTR *endRef);


void __RPC_STUB IECLibrary2_GetScriptureRefBounds2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IECLibrary2_INTERFACE_DEFINED__ */


#ifndef __IECMapping_INTERFACE_DEFINED__
#define __IECMapping_INTERFACE_DEFINED__

/* interface IECMapping */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IECMapping;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E4A8ED4D-A50D-49CE-9957-FC4DDF4DB25D")
    IECMapping : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_EndMarker( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_EndMarker( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DataEncoding( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DataEncoding( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_MarkerEncoding( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_MarkerEncoding( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_IsInline( 
            /* [retval][out] */ BOOL *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_IsInline( 
            /* [in] */ BOOL newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Domain( 
            /* [retval][out] */ MarkerDomain *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Domain( 
            /* [in] */ MarkerDomain newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_IsConfirmed( 
            /* [retval][out] */ BOOL *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_IsConfirmed( 
            /* [in] */ BOOL newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_StyleName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_StyleName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DomainAsBSTR( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_BeginMarker( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_BeginMarker( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_WritingSystem( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_WritingSystem( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Init( 
            VARIANT *myData) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_NewBeginMarker( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_NewEndMarker( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ long *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IECMappingVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IECMapping * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IECMapping * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IECMapping * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IECMapping * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IECMapping * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IECMapping * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IECMapping * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_EndMarker )( 
            IECMapping * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_EndMarker )( 
            IECMapping * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DataEncoding )( 
            IECMapping * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_DataEncoding )( 
            IECMapping * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_MarkerEncoding )( 
            IECMapping * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_MarkerEncoding )( 
            IECMapping * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_IsInline )( 
            IECMapping * This,
            /* [retval][out] */ BOOL *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_IsInline )( 
            IECMapping * This,
            /* [in] */ BOOL newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Domain )( 
            IECMapping * This,
            /* [retval][out] */ MarkerDomain *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_Domain )( 
            IECMapping * This,
            /* [in] */ MarkerDomain newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_IsConfirmed )( 
            IECMapping * This,
            /* [retval][out] */ BOOL *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_IsConfirmed )( 
            IECMapping * This,
            /* [in] */ BOOL newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_StyleName )( 
            IECMapping * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_StyleName )( 
            IECMapping * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DomainAsBSTR )( 
            IECMapping * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_BeginMarker )( 
            IECMapping * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_BeginMarker )( 
            IECMapping * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_WritingSystem )( 
            IECMapping * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_WritingSystem )( 
            IECMapping * This,
            /* [in] */ BSTR newVal);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IECMapping * This,
            VARIANT *myData);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_NewBeginMarker )( 
            IECMapping * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_NewEndMarker )( 
            IECMapping * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            IECMapping * This,
            /* [retval][out] */ long *pVal);
        
        END_INTERFACE
    } IECMappingVtbl;

    interface IECMapping
    {
        CONST_VTBL struct IECMappingVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IECMapping_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IECMapping_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IECMapping_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IECMapping_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IECMapping_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IECMapping_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IECMapping_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IECMapping_get_EndMarker(This,pVal)	\
    (This)->lpVtbl -> get_EndMarker(This,pVal)

#define IECMapping_put_EndMarker(This,newVal)	\
    (This)->lpVtbl -> put_EndMarker(This,newVal)

#define IECMapping_get_DataEncoding(This,pVal)	\
    (This)->lpVtbl -> get_DataEncoding(This,pVal)

#define IECMapping_put_DataEncoding(This,newVal)	\
    (This)->lpVtbl -> put_DataEncoding(This,newVal)

#define IECMapping_get_MarkerEncoding(This,pVal)	\
    (This)->lpVtbl -> get_MarkerEncoding(This,pVal)

#define IECMapping_put_MarkerEncoding(This,newVal)	\
    (This)->lpVtbl -> put_MarkerEncoding(This,newVal)

#define IECMapping_get_IsInline(This,pVal)	\
    (This)->lpVtbl -> get_IsInline(This,pVal)

#define IECMapping_put_IsInline(This,newVal)	\
    (This)->lpVtbl -> put_IsInline(This,newVal)

#define IECMapping_get_Domain(This,pVal)	\
    (This)->lpVtbl -> get_Domain(This,pVal)

#define IECMapping_put_Domain(This,newVal)	\
    (This)->lpVtbl -> put_Domain(This,newVal)

#define IECMapping_get_IsConfirmed(This,pVal)	\
    (This)->lpVtbl -> get_IsConfirmed(This,pVal)

#define IECMapping_put_IsConfirmed(This,newVal)	\
    (This)->lpVtbl -> put_IsConfirmed(This,newVal)

#define IECMapping_get_StyleName(This,pVal)	\
    (This)->lpVtbl -> get_StyleName(This,pVal)

#define IECMapping_put_StyleName(This,newVal)	\
    (This)->lpVtbl -> put_StyleName(This,newVal)

#define IECMapping_get_DomainAsBSTR(This,pVal)	\
    (This)->lpVtbl -> get_DomainAsBSTR(This,pVal)

#define IECMapping_get_BeginMarker(This,pVal)	\
    (This)->lpVtbl -> get_BeginMarker(This,pVal)

#define IECMapping_put_BeginMarker(This,newVal)	\
    (This)->lpVtbl -> put_BeginMarker(This,newVal)

#define IECMapping_get_WritingSystem(This,pVal)	\
    (This)->lpVtbl -> get_WritingSystem(This,pVal)

#define IECMapping_put_WritingSystem(This,newVal)	\
    (This)->lpVtbl -> put_WritingSystem(This,newVal)

#define IECMapping_Init(This,myData)	\
    (This)->lpVtbl -> Init(This,myData)

#define IECMapping_get_NewBeginMarker(This,pVal)	\
    (This)->lpVtbl -> get_NewBeginMarker(This,pVal)

#define IECMapping_get_NewEndMarker(This,pVal)	\
    (This)->lpVtbl -> get_NewEndMarker(This,pVal)

#define IECMapping_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_EndMarker_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECMapping_get_EndMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECMapping_put_EndMarker_Proxy( 
    IECMapping * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECMapping_put_EndMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_DataEncoding_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECMapping_get_DataEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECMapping_put_DataEncoding_Proxy( 
    IECMapping * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECMapping_put_DataEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_MarkerEncoding_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECMapping_get_MarkerEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECMapping_put_MarkerEncoding_Proxy( 
    IECMapping * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECMapping_put_MarkerEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_IsInline_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BOOL *pVal);


void __RPC_STUB IECMapping_get_IsInline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECMapping_put_IsInline_Proxy( 
    IECMapping * This,
    /* [in] */ BOOL newVal);


void __RPC_STUB IECMapping_put_IsInline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_Domain_Proxy( 
    IECMapping * This,
    /* [retval][out] */ MarkerDomain *pVal);


void __RPC_STUB IECMapping_get_Domain_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECMapping_put_Domain_Proxy( 
    IECMapping * This,
    /* [in] */ MarkerDomain newVal);


void __RPC_STUB IECMapping_put_Domain_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_IsConfirmed_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BOOL *pVal);


void __RPC_STUB IECMapping_get_IsConfirmed_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECMapping_put_IsConfirmed_Proxy( 
    IECMapping * This,
    /* [in] */ BOOL newVal);


void __RPC_STUB IECMapping_put_IsConfirmed_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_StyleName_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECMapping_get_StyleName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECMapping_put_StyleName_Proxy( 
    IECMapping * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECMapping_put_StyleName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_DomainAsBSTR_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECMapping_get_DomainAsBSTR_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_BeginMarker_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECMapping_get_BeginMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECMapping_put_BeginMarker_Proxy( 
    IECMapping * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECMapping_put_BeginMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_WritingSystem_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECMapping_get_WritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECMapping_put_WritingSystem_Proxy( 
    IECMapping * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECMapping_put_WritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECMapping_Init_Proxy( 
    IECMapping * This,
    VARIANT *myData);


void __RPC_STUB IECMapping_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_NewBeginMarker_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECMapping_get_NewBeginMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_NewEndMarker_Proxy( 
    IECMapping * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECMapping_get_NewEndMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECMapping_get_ID_Proxy( 
    IECMapping * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IECMapping_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IECMapping_INTERFACE_DEFINED__ */


#ifndef __IECProject_INTERFACE_DEFINED__
#define __IECProject_INTERFACE_DEFINED__

/* interface IECProject */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IECProject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("FE4BE80A-389F-41E7-8ACE-72A43BD403DD")
    IECProject : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE InitializeFromSafeArray( 
            /* [in] */ VARIANT pSafeArrayOfBytes) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE BuildSOProjectFiles( void) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_LibraryObject( 
            /* [retval][out] */ IECLibrary **pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AddFile( 
            /* [in] */ BSTR bstrFileName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RemoveFile( 
            /* [in] */ BSTR bstrFileName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AddFileGetEncoding( 
            /* [in] */ BSTR fileName,
            /* [out] */ EC_FileEncoding *fileEC,
            /* [out] */ long *percentCertian) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UpdateFileEncoding( 
            /* [in] */ BSTR fileName,
            /* [in] */ EC_FileEncoding fileEC) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFileInfo( 
            /* [in] */ BSTR fileName,
            /* [out] */ IECProjectFileInfo **data) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultDataEncoding( 
            /* [retval][out] */ BSTR *bstrEncoding) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultDataEncoding( 
            /* [in] */ BSTR bstrEncoding) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultMarkerEncoding( 
            /* [retval][out] */ BSTR *bstrEncoding) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultMarkerEncoding( 
            /* [in] */ BSTR bstrEncoding) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_BinaryDirectory( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_BinaryDirectory( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FilePropertyInfoSafeArray( 
            /* [retval][out] */ VARIANT *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_AsSafeArray( 
            /* [retval][out] */ VARIANT *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Files( 
            /* [retval][out] */ VARIANT *pSafeArray) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_NumberOfFiles( 
            /* [retval][out] */ int *iCount) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_NumberOfMappings( 
            /* [retval][out] */ int *iCount) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_BookMarker( 
            /* [retval][out] */ BSTR *bstrBookMarker) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_BookMarker( 
            /* [in] */ BSTR bstrBookMarker) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultSSFFileName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultSSFFileName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultSTYFileName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultSTYFileName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NthECMapping( 
            /* [in] */ int __MIDL_0011,
            /* [out] */ IECMapping **data) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetECMapping( 
            /* [in] */ IECMapping *mapping) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DeleteECMapping( 
            /* [in] */ IECMapping *mapping) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DeleteMarker( 
            /* [in] */ BSTR bstrMarker) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ConvertProject( 
            /* [out] */ BSTR *bstrDoneEventName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBooksForFile( 
            /* [in] */ BSTR bstrFileName,
            /* [retval][out] */ VARIANT *pSafeArray) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE debugShowObjects( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ValidateSafeArray( 
            /* [in] */ VARIANT pSafeArrayOfBytes,
            /* [out] */ BOOL *isValid) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsFileAccessible( 
            /* [in] */ BSTR bstrFileName,
            /* [out] */ BOOL *isAccessible) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultVernWritingSystem( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultVernWritingSystem( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultAnalWritingSystem( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultAnalWritingSystem( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_MappingInfoSafeArray( 
            /* [retval][out] */ VARIANT *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DeleteOutputFiles( void) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_AutoDeleteTempFiles( 
            /* [retval][out] */ BOOL *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_AutoDeleteTempFiles( 
            /* [in] */ BOOL newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IECProjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IECProject * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IECProject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IECProject * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IECProject * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IECProject * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IECProject * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IECProject * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *InitializeFromSafeArray )( 
            IECProject * This,
            /* [in] */ VARIANT pSafeArrayOfBytes);
        
        HRESULT ( STDMETHODCALLTYPE *BuildSOProjectFiles )( 
            IECProject * This);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_LibraryObject )( 
            IECProject * This,
            /* [retval][out] */ IECLibrary **pVal);
        
        HRESULT ( STDMETHODCALLTYPE *AddFile )( 
            IECProject * This,
            /* [in] */ BSTR bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE *RemoveFile )( 
            IECProject * This,
            /* [in] */ BSTR bstrFileName);
        
        HRESULT ( STDMETHODCALLTYPE *AddFileGetEncoding )( 
            IECProject * This,
            /* [in] */ BSTR fileName,
            /* [out] */ EC_FileEncoding *fileEC,
            /* [out] */ long *percentCertian);
        
        HRESULT ( STDMETHODCALLTYPE *UpdateFileEncoding )( 
            IECProject * This,
            /* [in] */ BSTR fileName,
            /* [in] */ EC_FileEncoding fileEC);
        
        HRESULT ( STDMETHODCALLTYPE *GetFileInfo )( 
            IECProject * This,
            /* [in] */ BSTR fileName,
            /* [out] */ IECProjectFileInfo **data);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DefaultDataEncoding )( 
            IECProject * This,
            /* [retval][out] */ BSTR *bstrEncoding);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_DefaultDataEncoding )( 
            IECProject * This,
            /* [in] */ BSTR bstrEncoding);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DefaultMarkerEncoding )( 
            IECProject * This,
            /* [retval][out] */ BSTR *bstrEncoding);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_DefaultMarkerEncoding )( 
            IECProject * This,
            /* [in] */ BSTR bstrEncoding);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_BinaryDirectory )( 
            IECProject * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_BinaryDirectory )( 
            IECProject * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_FilePropertyInfoSafeArray )( 
            IECProject * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_AsSafeArray )( 
            IECProject * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_Files )( 
            IECProject * This,
            /* [retval][out] */ VARIANT *pSafeArray);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfFiles )( 
            IECProject * This,
            /* [retval][out] */ int *iCount);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfMappings )( 
            IECProject * This,
            /* [retval][out] */ int *iCount);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_BookMarker )( 
            IECProject * This,
            /* [retval][out] */ BSTR *bstrBookMarker);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_BookMarker )( 
            IECProject * This,
            /* [in] */ BSTR bstrBookMarker);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DefaultSSFFileName )( 
            IECProject * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_DefaultSSFFileName )( 
            IECProject * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DefaultSTYFileName )( 
            IECProject * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_DefaultSTYFileName )( 
            IECProject * This,
            /* [in] */ BSTR newVal);
        
        HRESULT ( STDMETHODCALLTYPE *NthECMapping )( 
            IECProject * This,
            /* [in] */ int __MIDL_0011,
            /* [out] */ IECMapping **data);
        
        HRESULT ( STDMETHODCALLTYPE *SetECMapping )( 
            IECProject * This,
            /* [in] */ IECMapping *mapping);
        
        HRESULT ( STDMETHODCALLTYPE *DeleteECMapping )( 
            IECProject * This,
            /* [in] */ IECMapping *mapping);
        
        HRESULT ( STDMETHODCALLTYPE *DeleteMarker )( 
            IECProject * This,
            /* [in] */ BSTR bstrMarker);
        
        HRESULT ( STDMETHODCALLTYPE *ConvertProject )( 
            IECProject * This,
            /* [out] */ BSTR *bstrDoneEventName);
        
        HRESULT ( STDMETHODCALLTYPE *GetBooksForFile )( 
            IECProject * This,
            /* [in] */ BSTR bstrFileName,
            /* [retval][out] */ VARIANT *pSafeArray);
        
        HRESULT ( STDMETHODCALLTYPE *debugShowObjects )( 
            IECProject * This);
        
        HRESULT ( STDMETHODCALLTYPE *ValidateSafeArray )( 
            IECProject * This,
            /* [in] */ VARIANT pSafeArrayOfBytes,
            /* [out] */ BOOL *isValid);
        
        HRESULT ( STDMETHODCALLTYPE *IsFileAccessible )( 
            IECProject * This,
            /* [in] */ BSTR bstrFileName,
            /* [out] */ BOOL *isAccessible);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DefaultVernWritingSystem )( 
            IECProject * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_DefaultVernWritingSystem )( 
            IECProject * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DefaultAnalWritingSystem )( 
            IECProject * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_DefaultAnalWritingSystem )( 
            IECProject * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_MappingInfoSafeArray )( 
            IECProject * This,
            /* [retval][out] */ VARIANT *pVal);
        
        HRESULT ( STDMETHODCALLTYPE *DeleteOutputFiles )( 
            IECProject * This);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_AutoDeleteTempFiles )( 
            IECProject * This,
            /* [retval][out] */ BOOL *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_AutoDeleteTempFiles )( 
            IECProject * This,
            /* [in] */ BOOL newVal);
        
        END_INTERFACE
    } IECProjectVtbl;

    interface IECProject
    {
        CONST_VTBL struct IECProjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IECProject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IECProject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IECProject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IECProject_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IECProject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IECProject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IECProject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IECProject_InitializeFromSafeArray(This,pSafeArrayOfBytes)	\
    (This)->lpVtbl -> InitializeFromSafeArray(This,pSafeArrayOfBytes)

#define IECProject_BuildSOProjectFiles(This)	\
    (This)->lpVtbl -> BuildSOProjectFiles(This)

#define IECProject_get_LibraryObject(This,pVal)	\
    (This)->lpVtbl -> get_LibraryObject(This,pVal)

#define IECProject_AddFile(This,bstrFileName)	\
    (This)->lpVtbl -> AddFile(This,bstrFileName)

#define IECProject_RemoveFile(This,bstrFileName)	\
    (This)->lpVtbl -> RemoveFile(This,bstrFileName)

#define IECProject_AddFileGetEncoding(This,fileName,fileEC,percentCertian)	\
    (This)->lpVtbl -> AddFileGetEncoding(This,fileName,fileEC,percentCertian)

#define IECProject_UpdateFileEncoding(This,fileName,fileEC)	\
    (This)->lpVtbl -> UpdateFileEncoding(This,fileName,fileEC)

#define IECProject_GetFileInfo(This,fileName,data)	\
    (This)->lpVtbl -> GetFileInfo(This,fileName,data)

#define IECProject_get_DefaultDataEncoding(This,bstrEncoding)	\
    (This)->lpVtbl -> get_DefaultDataEncoding(This,bstrEncoding)

#define IECProject_put_DefaultDataEncoding(This,bstrEncoding)	\
    (This)->lpVtbl -> put_DefaultDataEncoding(This,bstrEncoding)

#define IECProject_get_DefaultMarkerEncoding(This,bstrEncoding)	\
    (This)->lpVtbl -> get_DefaultMarkerEncoding(This,bstrEncoding)

#define IECProject_put_DefaultMarkerEncoding(This,bstrEncoding)	\
    (This)->lpVtbl -> put_DefaultMarkerEncoding(This,bstrEncoding)

#define IECProject_get_BinaryDirectory(This,pVal)	\
    (This)->lpVtbl -> get_BinaryDirectory(This,pVal)

#define IECProject_put_BinaryDirectory(This,newVal)	\
    (This)->lpVtbl -> put_BinaryDirectory(This,newVal)

#define IECProject_get_FilePropertyInfoSafeArray(This,pVal)	\
    (This)->lpVtbl -> get_FilePropertyInfoSafeArray(This,pVal)

#define IECProject_get_AsSafeArray(This,pVal)	\
    (This)->lpVtbl -> get_AsSafeArray(This,pVal)

#define IECProject_get_Files(This,pSafeArray)	\
    (This)->lpVtbl -> get_Files(This,pSafeArray)

#define IECProject_get_NumberOfFiles(This,iCount)	\
    (This)->lpVtbl -> get_NumberOfFiles(This,iCount)

#define IECProject_get_NumberOfMappings(This,iCount)	\
    (This)->lpVtbl -> get_NumberOfMappings(This,iCount)

#define IECProject_get_BookMarker(This,bstrBookMarker)	\
    (This)->lpVtbl -> get_BookMarker(This,bstrBookMarker)

#define IECProject_put_BookMarker(This,bstrBookMarker)	\
    (This)->lpVtbl -> put_BookMarker(This,bstrBookMarker)

#define IECProject_get_DefaultSSFFileName(This,pVal)	\
    (This)->lpVtbl -> get_DefaultSSFFileName(This,pVal)

#define IECProject_put_DefaultSSFFileName(This,newVal)	\
    (This)->lpVtbl -> put_DefaultSSFFileName(This,newVal)

#define IECProject_get_DefaultSTYFileName(This,pVal)	\
    (This)->lpVtbl -> get_DefaultSTYFileName(This,pVal)

#define IECProject_put_DefaultSTYFileName(This,newVal)	\
    (This)->lpVtbl -> put_DefaultSTYFileName(This,newVal)

#define IECProject_NthECMapping(This,__MIDL_0011,data)	\
    (This)->lpVtbl -> NthECMapping(This,__MIDL_0011,data)

#define IECProject_SetECMapping(This,mapping)	\
    (This)->lpVtbl -> SetECMapping(This,mapping)

#define IECProject_DeleteECMapping(This,mapping)	\
    (This)->lpVtbl -> DeleteECMapping(This,mapping)

#define IECProject_DeleteMarker(This,bstrMarker)	\
    (This)->lpVtbl -> DeleteMarker(This,bstrMarker)

#define IECProject_ConvertProject(This,bstrDoneEventName)	\
    (This)->lpVtbl -> ConvertProject(This,bstrDoneEventName)

#define IECProject_GetBooksForFile(This,bstrFileName,pSafeArray)	\
    (This)->lpVtbl -> GetBooksForFile(This,bstrFileName,pSafeArray)

#define IECProject_debugShowObjects(This)	\
    (This)->lpVtbl -> debugShowObjects(This)

#define IECProject_ValidateSafeArray(This,pSafeArrayOfBytes,isValid)	\
    (This)->lpVtbl -> ValidateSafeArray(This,pSafeArrayOfBytes,isValid)

#define IECProject_IsFileAccessible(This,bstrFileName,isAccessible)	\
    (This)->lpVtbl -> IsFileAccessible(This,bstrFileName,isAccessible)

#define IECProject_get_DefaultVernWritingSystem(This,pVal)	\
    (This)->lpVtbl -> get_DefaultVernWritingSystem(This,pVal)

#define IECProject_put_DefaultVernWritingSystem(This,newVal)	\
    (This)->lpVtbl -> put_DefaultVernWritingSystem(This,newVal)

#define IECProject_get_DefaultAnalWritingSystem(This,pVal)	\
    (This)->lpVtbl -> get_DefaultAnalWritingSystem(This,pVal)

#define IECProject_put_DefaultAnalWritingSystem(This,newVal)	\
    (This)->lpVtbl -> put_DefaultAnalWritingSystem(This,newVal)

#define IECProject_get_MappingInfoSafeArray(This,pVal)	\
    (This)->lpVtbl -> get_MappingInfoSafeArray(This,pVal)

#define IECProject_DeleteOutputFiles(This)	\
    (This)->lpVtbl -> DeleteOutputFiles(This)

#define IECProject_get_AutoDeleteTempFiles(This,pVal)	\
    (This)->lpVtbl -> get_AutoDeleteTempFiles(This,pVal)

#define IECProject_put_AutoDeleteTempFiles(This,newVal)	\
    (This)->lpVtbl -> put_AutoDeleteTempFiles(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IECProject_InitializeFromSafeArray_Proxy( 
    IECProject * This,
    /* [in] */ VARIANT pSafeArrayOfBytes);


void __RPC_STUB IECProject_InitializeFromSafeArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_BuildSOProjectFiles_Proxy( 
    IECProject * This);


void __RPC_STUB IECProject_BuildSOProjectFiles_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_LibraryObject_Proxy( 
    IECProject * This,
    /* [retval][out] */ IECLibrary **pVal);


void __RPC_STUB IECProject_get_LibraryObject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_AddFile_Proxy( 
    IECProject * This,
    /* [in] */ BSTR bstrFileName);


void __RPC_STUB IECProject_AddFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_RemoveFile_Proxy( 
    IECProject * This,
    /* [in] */ BSTR bstrFileName);


void __RPC_STUB IECProject_RemoveFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_AddFileGetEncoding_Proxy( 
    IECProject * This,
    /* [in] */ BSTR fileName,
    /* [out] */ EC_FileEncoding *fileEC,
    /* [out] */ long *percentCertian);


void __RPC_STUB IECProject_AddFileGetEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_UpdateFileEncoding_Proxy( 
    IECProject * This,
    /* [in] */ BSTR fileName,
    /* [in] */ EC_FileEncoding fileEC);


void __RPC_STUB IECProject_UpdateFileEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_GetFileInfo_Proxy( 
    IECProject * This,
    /* [in] */ BSTR fileName,
    /* [out] */ IECProjectFileInfo **data);


void __RPC_STUB IECProject_GetFileInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_DefaultDataEncoding_Proxy( 
    IECProject * This,
    /* [retval][out] */ BSTR *bstrEncoding);


void __RPC_STUB IECProject_get_DefaultDataEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProject_put_DefaultDataEncoding_Proxy( 
    IECProject * This,
    /* [in] */ BSTR bstrEncoding);


void __RPC_STUB IECProject_put_DefaultDataEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_DefaultMarkerEncoding_Proxy( 
    IECProject * This,
    /* [retval][out] */ BSTR *bstrEncoding);


void __RPC_STUB IECProject_get_DefaultMarkerEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProject_put_DefaultMarkerEncoding_Proxy( 
    IECProject * This,
    /* [in] */ BSTR bstrEncoding);


void __RPC_STUB IECProject_put_DefaultMarkerEncoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_BinaryDirectory_Proxy( 
    IECProject * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECProject_get_BinaryDirectory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProject_put_BinaryDirectory_Proxy( 
    IECProject * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECProject_put_BinaryDirectory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_FilePropertyInfoSafeArray_Proxy( 
    IECProject * This,
    /* [retval][out] */ VARIANT *pVal);


void __RPC_STUB IECProject_get_FilePropertyInfoSafeArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_AsSafeArray_Proxy( 
    IECProject * This,
    /* [retval][out] */ VARIANT *pVal);


void __RPC_STUB IECProject_get_AsSafeArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_Files_Proxy( 
    IECProject * This,
    /* [retval][out] */ VARIANT *pSafeArray);


void __RPC_STUB IECProject_get_Files_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_NumberOfFiles_Proxy( 
    IECProject * This,
    /* [retval][out] */ int *iCount);


void __RPC_STUB IECProject_get_NumberOfFiles_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_NumberOfMappings_Proxy( 
    IECProject * This,
    /* [retval][out] */ int *iCount);


void __RPC_STUB IECProject_get_NumberOfMappings_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_BookMarker_Proxy( 
    IECProject * This,
    /* [retval][out] */ BSTR *bstrBookMarker);


void __RPC_STUB IECProject_get_BookMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProject_put_BookMarker_Proxy( 
    IECProject * This,
    /* [in] */ BSTR bstrBookMarker);


void __RPC_STUB IECProject_put_BookMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_DefaultSSFFileName_Proxy( 
    IECProject * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECProject_get_DefaultSSFFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProject_put_DefaultSSFFileName_Proxy( 
    IECProject * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECProject_put_DefaultSSFFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_DefaultSTYFileName_Proxy( 
    IECProject * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECProject_get_DefaultSTYFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProject_put_DefaultSTYFileName_Proxy( 
    IECProject * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECProject_put_DefaultSTYFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_NthECMapping_Proxy( 
    IECProject * This,
    /* [in] */ int __MIDL_0011,
    /* [out] */ IECMapping **data);


void __RPC_STUB IECProject_NthECMapping_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_SetECMapping_Proxy( 
    IECProject * This,
    /* [in] */ IECMapping *mapping);


void __RPC_STUB IECProject_SetECMapping_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_DeleteECMapping_Proxy( 
    IECProject * This,
    /* [in] */ IECMapping *mapping);


void __RPC_STUB IECProject_DeleteECMapping_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_DeleteMarker_Proxy( 
    IECProject * This,
    /* [in] */ BSTR bstrMarker);


void __RPC_STUB IECProject_DeleteMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_ConvertProject_Proxy( 
    IECProject * This,
    /* [out] */ BSTR *bstrDoneEventName);


void __RPC_STUB IECProject_ConvertProject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_GetBooksForFile_Proxy( 
    IECProject * This,
    /* [in] */ BSTR bstrFileName,
    /* [retval][out] */ VARIANT *pSafeArray);


void __RPC_STUB IECProject_GetBooksForFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_debugShowObjects_Proxy( 
    IECProject * This);


void __RPC_STUB IECProject_debugShowObjects_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_ValidateSafeArray_Proxy( 
    IECProject * This,
    /* [in] */ VARIANT pSafeArrayOfBytes,
    /* [out] */ BOOL *isValid);


void __RPC_STUB IECProject_ValidateSafeArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_IsFileAccessible_Proxy( 
    IECProject * This,
    /* [in] */ BSTR bstrFileName,
    /* [out] */ BOOL *isAccessible);


void __RPC_STUB IECProject_IsFileAccessible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_DefaultVernWritingSystem_Proxy( 
    IECProject * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECProject_get_DefaultVernWritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProject_put_DefaultVernWritingSystem_Proxy( 
    IECProject * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECProject_put_DefaultVernWritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_DefaultAnalWritingSystem_Proxy( 
    IECProject * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IECProject_get_DefaultAnalWritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProject_put_DefaultAnalWritingSystem_Proxy( 
    IECProject * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IECProject_put_DefaultAnalWritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_MappingInfoSafeArray_Proxy( 
    IECProject * This,
    /* [retval][out] */ VARIANT *pVal);


void __RPC_STUB IECProject_get_MappingInfoSafeArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IECProject_DeleteOutputFiles_Proxy( 
    IECProject * This);


void __RPC_STUB IECProject_DeleteOutputFiles_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IECProject_get_AutoDeleteTempFiles_Proxy( 
    IECProject * This,
    /* [retval][out] */ BOOL *pVal);


void __RPC_STUB IECProject_get_AutoDeleteTempFiles_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IECProject_put_AutoDeleteTempFiles_Proxy( 
    IECProject * This,
    /* [in] */ BOOL newVal);


void __RPC_STUB IECProject_put_AutoDeleteTempFiles_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IECProject_INTERFACE_DEFINED__ */


#ifndef __IParatextProjectProxy_INTERFACE_DEFINED__
#define __IParatextProjectProxy_INTERFACE_DEFINED__

/* interface IParatextProjectProxy */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IParatextProjectProxy;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("223239CA-3A0C-49AF-A0C2-FA1401896A8B")
    IParatextProjectProxy : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_VernTransProj( 
            /* [retval][out] */ BSTR *pt6Project) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_VernTransProj( 
            /* [in] */ BSTR pt6Project) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_BackTransProj( 
            /* [retval][out] */ BSTR *pt6Project) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_BackTransProj( 
            /* [in] */ BSTR pt6Project) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_NotesTransProj( 
            /* [retval][out] */ BSTR *pt6Project) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_NotesTransProj( 
            /* [in] */ BSTR pt6Project) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_NumberOfMappings( 
            /* [retval][out] */ int *iCount) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_AsSafeArray( 
            /* [retval][out] */ VARIANT *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NthECMapping( 
            /* [in] */ int __MIDL_0012,
            /* [out] */ IECMapping **data) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetECMapping( 
            /* [in] */ IECMapping *mapping) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DeleteECMapping( 
            /* [in] */ IECMapping *mapping) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DeleteMarker( 
            /* [in] */ BSTR bstrMarker) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE InitializeFromSafeArray( 
            /* [in] */ VARIANT pSafeArrayOfBytes) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_NumberOfMappingsForDomain( 
            /* [in] */ MarkerDomain domain,
            /* [retval][out] */ int *iCount) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NthECMappingForDomain( 
            /* [in] */ MarkerDomain domain,
            /* [in] */ int __MIDL_0013,
            /* [out] */ IECMapping **data) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ReadTEStyleFile( 
            BSTR styFileName) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_AreProjectsAccessible( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_IsValidProject( 
            MarkerDomain projectDomain,
            /* [retval][out] */ BOOL *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetProjectFilename( 
            /* [in] */ MarkerDomain md,
            /* [out] */ BSTR *bstrFilename) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RefreshDomainMarkers( 
            MarkerDomain domain) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultVernWritingSystem( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultVernWritingSystem( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_DefaultAnalWritingSystem( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DefaultAnalWritingSystem( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IParatextProjectProxyVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IParatextProjectProxy * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IParatextProjectProxy * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IParatextProjectProxy * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IParatextProjectProxy * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IParatextProjectProxy * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IParatextProjectProxy * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IParatextProjectProxy * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_VernTransProj )( 
            IParatextProjectProxy * This,
            /* [retval][out] */ BSTR *pt6Project);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_VernTransProj )( 
            IParatextProjectProxy * This,
            /* [in] */ BSTR pt6Project);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_BackTransProj )( 
            IParatextProjectProxy * This,
            /* [retval][out] */ BSTR *pt6Project);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_BackTransProj )( 
            IParatextProjectProxy * This,
            /* [in] */ BSTR pt6Project);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_NotesTransProj )( 
            IParatextProjectProxy * This,
            /* [retval][out] */ BSTR *pt6Project);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_NotesTransProj )( 
            IParatextProjectProxy * This,
            /* [in] */ BSTR pt6Project);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfMappings )( 
            IParatextProjectProxy * This,
            /* [retval][out] */ int *iCount);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_AsSafeArray )( 
            IParatextProjectProxy * This,
            /* [retval][out] */ VARIANT *pVal);
        
        HRESULT ( STDMETHODCALLTYPE *NthECMapping )( 
            IParatextProjectProxy * This,
            /* [in] */ int __MIDL_0012,
            /* [out] */ IECMapping **data);
        
        HRESULT ( STDMETHODCALLTYPE *SetECMapping )( 
            IParatextProjectProxy * This,
            /* [in] */ IECMapping *mapping);
        
        HRESULT ( STDMETHODCALLTYPE *DeleteECMapping )( 
            IParatextProjectProxy * This,
            /* [in] */ IECMapping *mapping);
        
        HRESULT ( STDMETHODCALLTYPE *DeleteMarker )( 
            IParatextProjectProxy * This,
            /* [in] */ BSTR bstrMarker);
        
        HRESULT ( STDMETHODCALLTYPE *InitializeFromSafeArray )( 
            IParatextProjectProxy * This,
            /* [in] */ VARIANT pSafeArrayOfBytes);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfMappingsForDomain )( 
            IParatextProjectProxy * This,
            /* [in] */ MarkerDomain domain,
            /* [retval][out] */ int *iCount);
        
        HRESULT ( STDMETHODCALLTYPE *NthECMappingForDomain )( 
            IParatextProjectProxy * This,
            /* [in] */ MarkerDomain domain,
            /* [in] */ int __MIDL_0013,
            /* [out] */ IECMapping **data);
        
        HRESULT ( STDMETHODCALLTYPE *ReadTEStyleFile )( 
            IParatextProjectProxy * This,
            BSTR styFileName);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_AreProjectsAccessible )( 
            IParatextProjectProxy * This,
            /* [retval][out] */ long *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_IsValidProject )( 
            IParatextProjectProxy * This,
            MarkerDomain projectDomain,
            /* [retval][out] */ BOOL *pVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetProjectFilename )( 
            IParatextProjectProxy * This,
            /* [in] */ MarkerDomain md,
            /* [out] */ BSTR *bstrFilename);
        
        HRESULT ( STDMETHODCALLTYPE *RefreshDomainMarkers )( 
            IParatextProjectProxy * This,
            MarkerDomain domain);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DefaultVernWritingSystem )( 
            IParatextProjectProxy * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_DefaultVernWritingSystem )( 
            IParatextProjectProxy * This,
            /* [in] */ BSTR newVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_DefaultAnalWritingSystem )( 
            IParatextProjectProxy * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_DefaultAnalWritingSystem )( 
            IParatextProjectProxy * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IParatextProjectProxyVtbl;

    interface IParatextProjectProxy
    {
        CONST_VTBL struct IParatextProjectProxyVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IParatextProjectProxy_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IParatextProjectProxy_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IParatextProjectProxy_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IParatextProjectProxy_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IParatextProjectProxy_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IParatextProjectProxy_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IParatextProjectProxy_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IParatextProjectProxy_get_VernTransProj(This,pt6Project)	\
    (This)->lpVtbl -> get_VernTransProj(This,pt6Project)

#define IParatextProjectProxy_put_VernTransProj(This,pt6Project)	\
    (This)->lpVtbl -> put_VernTransProj(This,pt6Project)

#define IParatextProjectProxy_get_BackTransProj(This,pt6Project)	\
    (This)->lpVtbl -> get_BackTransProj(This,pt6Project)

#define IParatextProjectProxy_put_BackTransProj(This,pt6Project)	\
    (This)->lpVtbl -> put_BackTransProj(This,pt6Project)

#define IParatextProjectProxy_get_NotesTransProj(This,pt6Project)	\
    (This)->lpVtbl -> get_NotesTransProj(This,pt6Project)

#define IParatextProjectProxy_put_NotesTransProj(This,pt6Project)	\
    (This)->lpVtbl -> put_NotesTransProj(This,pt6Project)

#define IParatextProjectProxy_get_NumberOfMappings(This,iCount)	\
    (This)->lpVtbl -> get_NumberOfMappings(This,iCount)

#define IParatextProjectProxy_get_AsSafeArray(This,pVal)	\
    (This)->lpVtbl -> get_AsSafeArray(This,pVal)

#define IParatextProjectProxy_NthECMapping(This,__MIDL_0012,data)	\
    (This)->lpVtbl -> NthECMapping(This,__MIDL_0012,data)

#define IParatextProjectProxy_SetECMapping(This,mapping)	\
    (This)->lpVtbl -> SetECMapping(This,mapping)

#define IParatextProjectProxy_DeleteECMapping(This,mapping)	\
    (This)->lpVtbl -> DeleteECMapping(This,mapping)

#define IParatextProjectProxy_DeleteMarker(This,bstrMarker)	\
    (This)->lpVtbl -> DeleteMarker(This,bstrMarker)

#define IParatextProjectProxy_InitializeFromSafeArray(This,pSafeArrayOfBytes)	\
    (This)->lpVtbl -> InitializeFromSafeArray(This,pSafeArrayOfBytes)

#define IParatextProjectProxy_get_NumberOfMappingsForDomain(This,domain,iCount)	\
    (This)->lpVtbl -> get_NumberOfMappingsForDomain(This,domain,iCount)

#define IParatextProjectProxy_NthECMappingForDomain(This,domain,__MIDL_0013,data)	\
    (This)->lpVtbl -> NthECMappingForDomain(This,domain,__MIDL_0013,data)

#define IParatextProjectProxy_ReadTEStyleFile(This,styFileName)	\
    (This)->lpVtbl -> ReadTEStyleFile(This,styFileName)

#define IParatextProjectProxy_get_AreProjectsAccessible(This,pVal)	\
    (This)->lpVtbl -> get_AreProjectsAccessible(This,pVal)

#define IParatextProjectProxy_get_IsValidProject(This,projectDomain,pVal)	\
    (This)->lpVtbl -> get_IsValidProject(This,projectDomain,pVal)

#define IParatextProjectProxy_GetProjectFilename(This,md,bstrFilename)	\
    (This)->lpVtbl -> GetProjectFilename(This,md,bstrFilename)

#define IParatextProjectProxy_RefreshDomainMarkers(This,domain)	\
    (This)->lpVtbl -> RefreshDomainMarkers(This,domain)

#define IParatextProjectProxy_get_DefaultVernWritingSystem(This,pVal)	\
    (This)->lpVtbl -> get_DefaultVernWritingSystem(This,pVal)

#define IParatextProjectProxy_put_DefaultVernWritingSystem(This,newVal)	\
    (This)->lpVtbl -> put_DefaultVernWritingSystem(This,newVal)

#define IParatextProjectProxy_get_DefaultAnalWritingSystem(This,pVal)	\
    (This)->lpVtbl -> get_DefaultAnalWritingSystem(This,pVal)

#define IParatextProjectProxy_put_DefaultAnalWritingSystem(This,newVal)	\
    (This)->lpVtbl -> put_DefaultAnalWritingSystem(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_VernTransProj_Proxy( 
    IParatextProjectProxy * This,
    /* [retval][out] */ BSTR *pt6Project);


void __RPC_STUB IParatextProjectProxy_get_VernTransProj_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_put_VernTransProj_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ BSTR pt6Project);


void __RPC_STUB IParatextProjectProxy_put_VernTransProj_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_BackTransProj_Proxy( 
    IParatextProjectProxy * This,
    /* [retval][out] */ BSTR *pt6Project);


void __RPC_STUB IParatextProjectProxy_get_BackTransProj_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_put_BackTransProj_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ BSTR pt6Project);


void __RPC_STUB IParatextProjectProxy_put_BackTransProj_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_NotesTransProj_Proxy( 
    IParatextProjectProxy * This,
    /* [retval][out] */ BSTR *pt6Project);


void __RPC_STUB IParatextProjectProxy_get_NotesTransProj_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_put_NotesTransProj_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ BSTR pt6Project);


void __RPC_STUB IParatextProjectProxy_put_NotesTransProj_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_NumberOfMappings_Proxy( 
    IParatextProjectProxy * This,
    /* [retval][out] */ int *iCount);


void __RPC_STUB IParatextProjectProxy_get_NumberOfMappings_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_AsSafeArray_Proxy( 
    IParatextProjectProxy * This,
    /* [retval][out] */ VARIANT *pVal);


void __RPC_STUB IParatextProjectProxy_get_AsSafeArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IParatextProjectProxy_NthECMapping_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ int __MIDL_0012,
    /* [out] */ IECMapping **data);


void __RPC_STUB IParatextProjectProxy_NthECMapping_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IParatextProjectProxy_SetECMapping_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ IECMapping *mapping);


void __RPC_STUB IParatextProjectProxy_SetECMapping_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IParatextProjectProxy_DeleteECMapping_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ IECMapping *mapping);


void __RPC_STUB IParatextProjectProxy_DeleteECMapping_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IParatextProjectProxy_DeleteMarker_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ BSTR bstrMarker);


void __RPC_STUB IParatextProjectProxy_DeleteMarker_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IParatextProjectProxy_InitializeFromSafeArray_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ VARIANT pSafeArrayOfBytes);


void __RPC_STUB IParatextProjectProxy_InitializeFromSafeArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_NumberOfMappingsForDomain_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ MarkerDomain domain,
    /* [retval][out] */ int *iCount);


void __RPC_STUB IParatextProjectProxy_get_NumberOfMappingsForDomain_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IParatextProjectProxy_NthECMappingForDomain_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ MarkerDomain domain,
    /* [in] */ int __MIDL_0013,
    /* [out] */ IECMapping **data);


void __RPC_STUB IParatextProjectProxy_NthECMappingForDomain_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IParatextProjectProxy_ReadTEStyleFile_Proxy( 
    IParatextProjectProxy * This,
    BSTR styFileName);


void __RPC_STUB IParatextProjectProxy_ReadTEStyleFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_AreProjectsAccessible_Proxy( 
    IParatextProjectProxy * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IParatextProjectProxy_get_AreProjectsAccessible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_IsValidProject_Proxy( 
    IParatextProjectProxy * This,
    MarkerDomain projectDomain,
    /* [retval][out] */ BOOL *pVal);


void __RPC_STUB IParatextProjectProxy_get_IsValidProject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IParatextProjectProxy_GetProjectFilename_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ MarkerDomain md,
    /* [out] */ BSTR *bstrFilename);


void __RPC_STUB IParatextProjectProxy_GetProjectFilename_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IParatextProjectProxy_RefreshDomainMarkers_Proxy( 
    IParatextProjectProxy * This,
    MarkerDomain domain);


void __RPC_STUB IParatextProjectProxy_RefreshDomainMarkers_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_DefaultVernWritingSystem_Proxy( 
    IParatextProjectProxy * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IParatextProjectProxy_get_DefaultVernWritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_put_DefaultVernWritingSystem_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IParatextProjectProxy_put_DefaultVernWritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_get_DefaultAnalWritingSystem_Proxy( 
    IParatextProjectProxy * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IParatextProjectProxy_get_DefaultAnalWritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IParatextProjectProxy_put_DefaultAnalWritingSystem_Proxy( 
    IParatextProjectProxy * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IParatextProjectProxy_put_DefaultAnalWritingSystem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IParatextProjectProxy_INTERFACE_DEFINED__ */



#ifndef __ECOBJECTSLib_LIBRARY_DEFINED__
#define __ECOBJECTSLib_LIBRARY_DEFINED__

/* library ECOBJECTSLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ECOBJECTSLib;

EXTERN_C const CLSID CLSID_ECProject;

#ifdef __cplusplus

class DECLSPEC_UUID("301B5DCF-E1D9-48E7-A8B8-CB1CD9B1363E")
ECProject;
#endif

EXTERN_C const CLSID CLSID_ParatextProjectProxy;

#ifdef __cplusplus

class DECLSPEC_UUID("1D1B84F6-6987-4220-95E7-91BE1FD9FC8D")
ParatextProjectProxy;
#endif

EXTERN_C const CLSID CLSID_ECMapping;

#ifdef __cplusplus

class DECLSPEC_UUID("B2A3DAB6-F2BB-4C13-A7A4-01E4708D1CC0")
ECMapping;
#endif

EXTERN_C const CLSID CLSID_ECLibrary;

#ifdef __cplusplus

class DECLSPEC_UUID("5960765D-65E0-4223-97CD-62BE9CFFAFB1")
ECLibrary;
#endif

EXTERN_C const CLSID CLSID_ECProjectFileInfo;

#ifdef __cplusplus

class DECLSPEC_UUID("C924DB3B-065D-4277-8158-64C05418DFC5")
ECProjectFileInfo;
#endif
#endif /* __ECOBJECTSLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long *, unsigned long            , VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserMarshal(  unsigned long *, unsigned char *, VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserUnmarshal(unsigned long *, unsigned char *, VARIANT * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long *, VARIANT * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


