// MappingInfo.cpp : Implementation of the Mapping related classes

#include "stdafx.h"
#include "MappingInfo.h"
#include "Persist.h"


#define	START_BE_SAFE( X )	char besafeName__[] = {"" #X ""}; try {
#define END_BE_SAFE		} catch(...) {ATLTRACE("*** Exception: <%s>\n", besafeName__);} 

/////////////////////////////////////////////////////////////////////////////
// CMappingInfo

CMappingInfo::CMappingInfo( CMarkerProperties* marker ): CTraceCreation( "CMappingInfo" ), m_Marker(0), m_bConfirmed(false),
		m_iDomain(0) 
{ 
	SetMarker( marker );
}

CMappingInfo::~CMappingInfo()
{ 
	if ( m_Marker ) 
		delete m_Marker; 
}

void CMappingInfo::SetMarker( CMarkerProperties* marker )
{ 
	START_BE_SAFE( CMappingInfo::FromBSTR )

	if ( m_Marker ) 
		delete m_Marker; 
	m_Marker = marker; 

	m_cbstrCharEncoding = marker->GetDataEncoding();

	END_BE_SAFE
}


CMappingInfo* CMappingInfo::FromBSTR( wchar_t *wptr, int *outLength )	// return object
{
	CMappingInfo *mappingInfo = NULL;

	START_BE_SAFE( CMappingInfo::FromBSTR )

	// Format is <markerlen|marker|endmarkerlen|endmarker|domain|charEncodinglen|charEncoding|TEStyleLen|TEStyle>
	//	without the '|' in the data.  The len and domain fields are 4 byte numeric values.
	//
	CComBSTR marker, endmarker, encoding, testyle;
	int domain;
	int len;	//, count, i;

	wchar_t *wptrStart = wptr;

	// --------------------------------------------
	wptr = wcsstr( wptr, L"<" );
	wptr += 1;

	// --------------------------------------------
	// now at start of "marker"
	//
	memcpy( &len, wptr, 4 );		// pull out length
	len = ntohl( len );				// convert from network order back to host order
	wptr += 2;						// move to the start of the data
	
	marker = ::SysAllocStringLen( wptr, len );
	wptr += len;

	// --------------------------------------------
	// now at start of "endmarker"
	//
	memcpy( &len, wptr, 4 );		// pull out length
	len = ntohl( len );				// convert from network order back to host order
	wptr += 2;						// move to the start of the data

	endmarker = ::SysAllocStringLen( wptr, len );
	wptr += len;

	// --------------------------------------------
	// now at start of "domain", read the literal 4 bytes
	//
	memcpy( &domain, wptr, 4 );		// pull out domain from the wide string
	domain = ntohl( domain );		// convert from network order back to host order
	wptr += 2;						// move to the start of the next data

	// --------------------------------------------
	// now at start of "encoding"
	//
	memcpy( &len, wptr, 4 );		// pull out length
	len = ntohl( len );				// convert from network order back to host order
	wptr += 2;						// move to the start of the data

	encoding = ::SysAllocStringLen( wptr, len );
	wptr += len;

	// --------------------------------------------
	// now at start of "TE Style"
	//
	memcpy( &len, wptr, 4 );		// pull out length
	len = ntohl( len );				// convert from network order back to host order
	wptr += 2;						// move to the start of the data

	testyle = ::SysAllocStringLen( wptr, len );

	// --------------------------------------------

	wptr += len+1;
	*outLength = wptr-wptrStart;


	CMarkerProperties *markerProps = new CMarkerProperties( marker, endmarker );
	mappingInfo = new CMappingInfo( markerProps );
	mappingInfo->SetCharEncoding( encoding );
	mappingInfo->SetDomain( domain );
	mappingInfo->SetTEStyleName( testyle );
	mappingInfo->SetConfirmed();

	END_BE_SAFE

	return mappingInfo;
}


void CMappingInfo::AsBSTR( BSTR *out)
{
	{
	CPersist pstream;
	BSTR bstrEncoding, bstrTEStyleName;

////	CBinaryData beginMarker( this->m_Marker->GetMarker(), false );
////	CBinaryData endMarker( this->m_Marker->GetEndMarker(), false );

	this->GetCharEncoding( &bstrEncoding );
	this->GetTEStyleName( &bstrTEStyleName );

//	CComBSTR test = "TestBSTR";
//	bstrEncoding = test.Copy();

//	pstream << &beginMarker << &endMarker << GetDomain();

	// First get all the data, then put it to the stream...
	//
	const char* beginMarker = m_Marker->GetMarker() ;
	const char* endMarker	= m_Marker->GetEndMarker();
	short bInLine = m_Marker->IsInline();
	const char* markerEncoding = m_Marker->GetMarkerEncoding();
	const char* dataEncoding   = m_Marker->GetDataEncoding();
	int domain = GetDomain();


/****************
	pstream << m_Marker;		// put out the marker properties

	CMarkerProperties *mProps;
	pstream >> &mProps;
	delete mProps;

	pstream << this;
	CMappingInfo *mi;
	try
	{
	pstream >> &mi;
	}
	catch(...)
	{
	}
	delete mi;
********************/

	// Marker properties
	pstream << beginMarker << endMarker << bInLine << markerEncoding << dataEncoding;
	
	// Mapping properties
	pstream	<< domain << (BSTR*)&bstrTEStyleName;

	/*
	00BA7D30  60 00 00 00 03 5C 63 00  `....\c.
	00BA7D38  62 31 62 62 31 52 BB FD  b1bb1R��
	*/

	*out = ::SysAllocStringByteLen("", pstream.ReadOnlyBufferSize() );
	memcpy( *out, pstream.ReadOnlyBuffer(), pstream.ReadOnlyBufferSize() );

	::SysFreeString( bstrEncoding );
	::SysFreeString( bstrTEStyleName );

	return;

	}

	// Format is <markerlen|marker|endmarkerlen|endmarker|domain|charEncodinglen|charEncoding|TEStyleLen|TEStyle>
	//	without the '|' in the data.  The len and domain fields are 4 byte numeric values.
	//

	CComBSTR rval;

	START_BE_SAFE( CMappingInfo::AsBSTR )

	char* cdata;
	int dataLen;
	long value;

	rval.Append( L"<" );

	cdata = (char*)this->m_Marker->GetMarker();
	if ( cdata )
		value = strlen( cdata );
	else
		value = 0;
	value = htonl( value );

	dataLen = rval.Length();
	rval.Append( L"12" );						// filler for four bytes
	memcpy( &rval.m_str[dataLen], &value, 4 );	// replace with value
	rval.Append( cdata );						// ===== Put out the Marker

	// ===========================

	cdata = (char*)this->m_Marker->GetEndMarker();
	if ( cdata )
		value = strlen( cdata );
	else
		value = 0;
	value = htonl( value );

	dataLen = rval.Length();
	rval.Append( L"12" );						// filler for four bytes
	memcpy( &rval.m_str[dataLen], &value, 4 );	// replace with value
	rval.Append( cdata );						// ===== Put out the End Marker

	// ===========================

	dataLen = rval.Length();
	value = this->GetDomain();
	value = htonl( value );
	rval.Append( L"12" );						// filler for four bytes
	memcpy( &rval.m_str[dataLen], &value, 4 );	// ===== replace with Domain value

	// ===========================

	BSTR bstrEncoding;
	this->GetCharEncoding( &bstrEncoding );
	value = ::SysStringLen( bstrEncoding );
	value = htonl( value );

	dataLen = rval.Length();
	rval.Append( L"12" );						// filler for four bytes
	memcpy( &rval.m_str[dataLen], &value, 4 );	// replace with value
	rval.AppendBSTR( bstrEncoding );			// ===== Put out the Encoding
	::SysFreeString( bstrEncoding );

	// ===========================

	BSTR bstrTEStyleName;
	this->GetTEStyleName( &bstrTEStyleName );
	value = ::SysStringLen( bstrTEStyleName );
	value = htonl( value );

	dataLen = rval.Length();
	rval.Append( L"12" );						// filler for four bytes
	memcpy( &rval.m_str[dataLen], &value, 4 );	// replace with value
	rval.AppendBSTR( bstrTEStyleName );			// ===== Put out the TE Style Name
	::SysFreeString( bstrTEStyleName );

	// ===========================

	rval.Append( L">" );

	END_BE_SAFE
	
	*out = rval.Copy();
}

void CMappingInfo::SetCharEncoding( BSTR in )
{ 
	m_cbstrCharEncoding = in; 
	this->m_Marker->SetDataEncoding("");
}

/////////////////////////////////////////////////////////////////////////////
// CMarkerProperties

CMarkerProperties::CMarkerProperties( char* marker ) :
	CTraceCreation( "CMarkerProperties" ),
	m_Marker(0), m_EndMarker(0), m_bIsInline(false),
	m_DataEncoding(0), m_MarkerEncoding(0)
{
	copyIfExists( marker, &m_Marker );
}

CMarkerProperties::CMarkerProperties( char* marker, char* endMarker ) :
	CTraceCreation( "CMarkerProperties" ),
	m_Marker(0), m_EndMarker(0), m_bIsInline(false),
	m_DataEncoding(0), m_MarkerEncoding(0)
{
	copyIfExists( marker, &m_Marker );
	copyIfExists( endMarker, &m_EndMarker );
}

CMarkerProperties::CMarkerProperties( BSTR beginMarker ) : 
	CTraceCreation( "CMarkerProperties" ),
	m_Marker(0), m_EndMarker(0), m_bIsInline(false),
	m_DataEncoding(0), m_MarkerEncoding(0)
{
	char asciiMarker[256];
	::WideCharToMultiByte( CP_ACP, 0, beginMarker, ::SysStringLen(beginMarker)+1, asciiMarker, 256, "*", 0 );

	copyIfExists( asciiMarker, &m_Marker );
}

CMarkerProperties::CMarkerProperties( BSTR beginMarker, BSTR endMarker ) :
	CTraceCreation( "CMarkerProperties" ),
	m_Marker(0), m_EndMarker(0), m_bIsInline(false),
	m_DataEncoding(0), m_MarkerEncoding(0)
{
	char asciiMarker[256];

	::WideCharToMultiByte( CP_ACP, 0, beginMarker, ::SysStringLen(beginMarker)+1, asciiMarker, 256, "*", 0 );
	copyIfExists( asciiMarker, &m_Marker );

	::WideCharToMultiByte( CP_ACP, 0, endMarker, ::SysStringLen(endMarker)+1, asciiMarker, 256, "*", 0 );
	copyIfExists( asciiMarker, &m_EndMarker );
	
}

CMarkerProperties::~CMarkerProperties()
{
	ATLTRACE("* ~CMarkerProperties() called\n");

	deleteIfExists( &m_Marker );
	deleteIfExists( &m_EndMarker );
	deleteIfExists( &m_DataEncoding );
	deleteIfExists( &m_MarkerEncoding );
}

void CMarkerProperties::SetDataEncoding	( char* in )
{ 
	deleteIfExists( &m_DataEncoding );
	copyIfExists( in, &m_DataEncoding ); 
}

void CMarkerProperties::SetMarkerEncoding	( char* in )
{ 
	deleteIfExists( &m_MarkerEncoding );
	copyIfExists( in, &m_MarkerEncoding ); 
}


CPersist& operator>>( CPersist& stream, CMarkerProperties** data)
{
	char* beginMarker=0;
	char* endMarker=0;
	char* markerEncoding=0;
	char* dataEncoding=0;
	short bInLine;

	START_BE_SAFE( "operator>>(CPersist&, CMarkerProperties**)" )

	stream >> &beginMarker >> &endMarker >> bInLine >> &markerEncoding >> &dataEncoding;

	*data = new CMarkerProperties( beginMarker, endMarker );
	(*data)->SetInline( bInLine );
	(*data)->SetMarkerEncoding( markerEncoding );
	(*data)->SetDataEncoding( dataEncoding );

	END_BE_SAFE

	deleteIfExists(&beginMarker);
	deleteIfExists(&endMarker);
	deleteIfExists(&markerEncoding);
	deleteIfExists(&dataEncoding);

	return stream;
}

CPersist& operator<<( CPersist& stream, CMarkerProperties* data)
{
	START_BE_SAFE( "operator<<(CPersist&, CMarkerProperties*)" )

	// First get all the data, then put it to the stream...
	//
	const char* beginMarker = data->GetMarker() ;
	const char* endMarker	= data->GetEndMarker();
	const char* markerEncoding = data->GetMarkerEncoding();
	const char* dataEncoding   = data->GetDataEncoding();
	short bInLine = data->IsInline();

	// =====================================================
	// Marker properties
	stream << beginMarker << endMarker << bInLine << markerEncoding << dataEncoding;
	// =====================================================

	END_BE_SAFE

	/*
	*/
	return stream;
}


CPersist& operator<<( CPersist& stream, CMappingInfo* data)
{
	BSTR bstrEncoding=0, bstrTEStyleName=0;

	START_BE_SAFE( "operator<<(CPersist&, CMappingInfo*)" )

	// First get all the data, then put it to the stream...
	//
	short domain = data->GetDomain();
	data->GetCharEncoding( &bstrEncoding );
	data->GetTEStyleName( &bstrTEStyleName );

	// =====================================================
	// Mapping Info
	stream << data->m_Marker << domain << (BSTR*)&bstrEncoding << (BSTR*)&bstrTEStyleName;
	// =====================================================

	END_BE_SAFE

	if ( bstrEncoding )		::SysFreeString( bstrEncoding );
	if ( bstrTEStyleName )	::SysFreeString( bstrTEStyleName );

	return stream;
}

CPersist& operator>>( CPersist& stream, CMappingInfo** data)
{
	CMarkerProperties *markerProps;
	short domain;
	BSTR bstrEncoding=0, bstrTEStyleName=0;

	START_BE_SAFE( "operator>>(CPersist&, CMappingInfo**)" )

	// =====================================================
	// Mapping Info : reading from stream
	stream >> &markerProps >> domain >> (BSTR*)&bstrEncoding >> (BSTR*)&bstrTEStyleName;
	// =====================================================

	*data = new CMappingInfo( markerProps );
	(*data)->SetDomain( domain );
	(*data)->SetTEStyleName( bstrTEStyleName );
	(*data)->SetCharEncoding( bstrEncoding );
	(*data)->SetConfirmed();

	END_BE_SAFE

	if ( bstrEncoding )		::SysFreeString( bstrEncoding );
	if ( bstrTEStyleName )	::SysFreeString( bstrTEStyleName );

	return stream;
}

/////////////////////////////////////////////////////////////////////////////

void copyIfExists( char* in, char** out )
{
	if ( in && strlen(in)>0 )
	{
		if ( *out )
			delete [] (*out);

		*out = new char[strlen(in)+1];
		strcpy(*out, in );
	}
	else
	{
		if ( *out )
			delete [] (*out);
		*out = NULL;
	}
}

void /* inline */ deleteIfExists( char** InOut )
{
	if ( *InOut )	
		delete [] *InOut;
	*InOut = NULL;
}
