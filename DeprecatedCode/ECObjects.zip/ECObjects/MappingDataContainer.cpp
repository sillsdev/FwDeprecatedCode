// MappingDataContainer.cpp: implementation of the CMappingDataContainer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MappingDataContainer.h"

//////////////////////////////////////////////////////////////////////
// Define some preprocessor short cuts
//////////////////////////////////////////////////////////////////////

#define TRY_START	try { EnterCriticalSection( &m_CS );
#define TRY_STOP	} catch (...) { AtlTrace("__**-- Exception in MappingDataContainer**\n"); } LeaveCriticalSection( &m_CS );


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMappingDataContainer::CMappingDataContainer()
{
	InitializeCriticalSection( &m_CS );
}

CMappingDataContainer::~CMappingDataContainer()
{
	EraseAll();

	DeleteCriticalSection( &m_CS );
}

bool CMappingDataContainer::EraseAll()
{
	TRY_START

	CInternalMappingData* data;
	TIDMappingPtrsIT mapIT = m_DataMap.begin();
	while ( mapIT != m_DataMap.end() )
	{
		data = mapIT->second;
		delete data;		// free the mem for the data objects
		mapIT++;
	}

	m_DataMap.clear();
	m_KeyIDMap.clear();

	TRY_STOP

	return true;
}

long CMappingDataContainer::Size()
{
	long rval = 0;
	
	TRY_START
	rval = m_DataMap.size();
	TRY_STOP

	return rval;
}

bool CMappingDataContainer::FindID( long id )
{
	TIDMappingPtrsIT mapIT;
	bool rval = false;
	
	TRY_START

	mapIT = m_DataMap.find( id );
	if ( mapIT != m_DataMap.end() )
	{
		rval = true;
	}

	TRY_STOP

	return rval;
}

bool CMappingDataContainer::FindKey( long key )
{
	TKeyIDIT mapIT;
	bool rval = false;
	
	TRY_START

	mapIT = m_KeyIDMap.find( key );
	if ( mapIT != m_KeyIDMap.end() )
	{
		rval = true;
	}

	TRY_STOP

	return rval;
}

bool CMappingDataContainer::RemoveKeyElement( long key )			// remove the item with this key
{
	bool rval = false;
	
	TRY_START

	TKeyIDIT mapIT;
	TIDMappingPtrsIT idmapIT;

	mapIT = m_KeyIDMap.find( key );

	if ( mapIT == m_KeyIDMap.end() )
		return rval;

	long id = m_KeyIDMap[key];			// retrieve the id
	m_KeyIDMap.erase( mapIT );			// remove this element from key map

	idmapIT = m_DataMap.find( id );
	if ( idmapIT != m_DataMap.end() )
	{
		m_DataMap.erase( idmapIT );		// remove this element from data map
		rval = true;
	}

	TRY_STOP

	return rval;
}

CInternalMappingData* CMappingDataContainer::PopItem( int index )
{
	CInternalMappingData* rval = NULL;

	TRY_START

	rval = at( index );		// get the item
	if ( rval )
	{
		RemoveKeyElement( rval->GetSBKey() );
	}

	TRY_STOP

	return rval;
}

CInternalMappingData* CMappingDataContainer::at( int index )
{
	CInternalMappingData* rval = NULL;
	TIDMappingPtrsIT mapIT;

	TRY_START

	mapIT = m_DataMap.begin();
	if ( index >=0 && index <= (int) (m_DataMap.size()) )
	{
		for ( int i=0; i<index; i++, mapIT++ )
			;

		rval = (CInternalMappingData* )(mapIT->second);
	}


	TRY_STOP

	return rval;
}

bool CMappingDataContainer::Add( CInternalMappingData* data, bool copy/*=false*/ )
{
	// only added if ID and Key are not already in container
	bool rval = false;
	
	TRY_START

	long key = data->GetSBKey();
	long id  = data->GetID();

	if ( !FindKey( key ) && !FindID( id ) )
	{
		m_KeyIDMap[key] = id;		// set ID for Key
		
		if ( copy )
		{
			CInternalMappingData *mappingDataCopy = new CInternalMappingData( *data );
			m_DataMap[id] = mappingDataCopy;
		}
		else
			m_DataMap[id]	= data;		// set Data for ID

		rval = true;
	}

	TRY_STOP

	return rval;
}

bool CMappingDataContainer::AddCopy( CInternalMappingData* data )
{
	return Add(data, true );
}

bool CMappingDataContainer::Update( CInternalMappingData* dataIn )
{
	// update the data with matching Key and different ID, else false
	bool rval = false;
	
	TRY_START

	long key = dataIn->GetSBKey();
	long id  = dataIn->GetID();

	if ( FindKey( key ) && !FindID( id ) )
	{
		CInternalMappingData* data = GetDataFromKey( key );
		*data = *dataIn;
		rval = true;
	}

	TRY_STOP

	return rval;
}

CInternalMappingData* CMappingDataContainer::GetDataFromKey( long key )
{
	TKeyIDIT mapIT;
	CInternalMappingData* rval = NULL;
	
	TRY_START

	mapIT = m_KeyIDMap.find( key );
	if ( mapIT != m_KeyIDMap.end() )
	{
		rval = GetDataFromID( mapIT->second );
	}

	TRY_STOP

	return rval;
}

CInternalMappingData* CMappingDataContainer::GetDataFromID( long id )
{
	CInternalMappingData* rval = NULL;
	
	TRY_START

	TIDMappingPtrsIT mapIT;
	mapIT = m_DataMap.find( id );

	if ( mapIT != m_DataMap.end() )
	{
		rval = mapIT->second;
	}

	TRY_STOP

	return rval;
}


// long Test
/*
void ShowTestResult( long correct, long bTest, short &testNum, short &failCount )
{
	ShowTestResult( (bool)true, (bool)(correct==bTest), testNum, failCount );
}
*/
// bool Test
void ShowTestResult( long correct, long bTest, short &testNum, short &failCount )
{
	testNum++;
	if ( correct != bTest )
	{
		failCount++;	// fail count
		AtlTrace("** **** FAILED Test %d ****\n", testNum );
	}
}


bool CMappingDataContainer::Test()
{
	OutputDebugString("****************************************\n");
	OutputDebugString("** Begin Testing CMappingDataContainer\n");

	bool passed = false;

	CInternalMappingData* verse   = new CInternalMappingData();
	CInternalMappingData* chapter = new CInternalMappingData();
	CInternalMappingData* verseN  = new CInternalMappingData();
	CInternalMappingData* dataPtr;

	verse->SetBeginMarker( _T("\\v") );
	verse->SetDomain( MD_Vern );
	verse->SetDataEncoding(_T("verseEncoding"));

	chapter->SetBeginMarker( _T("\\c") );
	chapter->SetDomain( MD_Vern );
	chapter->SetDataEncoding(_T("chapterEncoding"));

	verseN->SetBeginMarker( _T("\\v") );
	verseN->SetDomain( MD_Vern );

	// now do some tests
	bool bval;
	short testCnt=0;
	short failCnt=0;

	// TEST: try to find an ID that isn't in the container
	//
	bval = this->FindID( verse->GetID() );
	ShowTestResult( false, bval, testCnt, failCnt );

	// TEST: try to find a Key that isn't in the container
	//
	bval = this->FindKey( verse->GetSBKey() );
	ShowTestResult( false, bval, testCnt, failCnt );

	// TEST: add a new mapping object to the container
	//
	bval = this->Add( verse );
	ShowTestResult( true, bval, testCnt, failCnt );

	// TEST: try to add a dup'd key object to the container
	//
	bval = this->Add( verseN );
	ShowTestResult( false, bval, testCnt, failCnt );

	// TEST: update an object using the key
	//
	bval = this->Update( verseN );
	ShowTestResult( true, bval, testCnt, failCnt );

	// TEST: get ID for key that was updated 
	//
	dataPtr = this->GetDataFromKey( verseN->GetSBKey() );
	ShowTestResult( false, dataPtr==NULL, testCnt, failCnt );
	long l1=verse->GetID(), l2=verseN->GetID();
	ShowTestResult( true, l1!=l2, testCnt, failCnt );

	// TEST: try to update an object that doesn't exist in the container
	//
	bval = this->Update( chapter );
	ShowTestResult( false, bval, testCnt, failCnt );

	// TEST: add a new mapping object to the container
	//
	bval = this->Add( chapter );
	ShowTestResult( true, bval, testCnt, failCnt );

	CPersist stream1, stream2;
	stream1 << this;
	CMappingDataContainer *other = new CMappingDataContainer;
	stream1 >> &other;
	stream2 << other;

	long size1, size2;
	size1 = stream1.Size();
	size2 = stream2.Size();

	ShowTestResult( size1, size2, testCnt, failCnt );

	const char* buf1 = stream1.ReadOnlyBuffer();
	const char* buf2 = stream2.ReadOnlyBuffer();

	int cmpValue = ::memcmp(buf1, buf2, size1 );
	ShowTestResult( 0, cmpValue, testCnt, failCnt );

	int asdfqwer = 123;
	delete other;

	AtlTrace("** Results: Tests=%d, Passed=%d\n", testCnt, testCnt-failCnt );
	OutputDebugString("**\n");
	OutputDebugString("** End Testing CMappingDataContainer\n");
	OutputDebugString("****************************************\n");

	delete verseN;	// not added to container so client is responsible for memory!!

	passed = (failCnt==0);
	return passed;
}

// ======================================================================

CPersist& operator<<( CPersist& stream, CMappingDataContainer* data)
{
	long numItems = data->Size();

	stream << numItems;			// put out the number of items in container

	CInternalMappingData* dataItem;
	TIDMappingPtrsIT mapIT = data->m_DataMap.begin();

	// Put out the individual data items
	while ( mapIT != data->m_DataMap.end() )
	{
		dataItem = mapIT->second;
		stream << dataItem;

		mapIT++;
	}

	return stream;
}


CPersist& operator>>( CPersist& stream, CMappingDataContainer** data)
{
	long numItems=0;
	CInternalMappingData* dataItem;

	AtlTrace("*** STATUS: CMappingDataContainer being created from stream.\n");
	
	stream >> numItems;		// pull out the number of items

	AtlTrace("*** STATUS: %d items to add to the container.\n", numItems);

	for ( long i = 0; i<numItems; i++)
	{
		stream >> &dataItem;

		if ( dataItem && !stream.HasError() )
		{
			// 4/17 AddCopy ???
			bool success = (*data)->Add( dataItem );	// container takes over memory management of item
			if ( !success )
			{
				AtlTrace( "***ERR: Unable to add item (%ld) from stream.\n", i );
			}
			dataItem = NULL;		// just to be clean
		}
		else
		{
			AtlTrace("***ERR: Invalid data in the stream, didn't recognize it. Failing to read from stream.\n");
			break;		// stop early for errors
		}
	}

	AtlTrace("*** DONE: CMappingDataContainer DONE being created from stream.\n");
	return stream;
}

