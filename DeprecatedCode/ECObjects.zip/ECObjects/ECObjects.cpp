// ECObjects.cpp : Implementation of DLL Exports.


// Note: Proxy/Stub Information
//      To build a separate proxy/stub DLL, 
//      run nmake -f ECObjectsps.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include "ECObjects.h"

#include "ECObjects_i.c"
#include "ECProject.h"
#include "ParatextProjectProxy.h"
#include "ECMapping.h"
#include "ECLibrary.h"
//#include "ECFileInfo.h"

///#include "ECMappingRO.h"
#include "TraceCreation.h"
#include "crc.h"
#include "ECProjectFileInfo.h"


CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_ECProject, CECProject)
OBJECT_ENTRY(CLSID_ParatextProjectProxy, CParatextProjectProxy)
OBJECT_ENTRY(CLSID_ECMapping, CECMapping)
//OBJECT_ENTRY(CLSID_ECMappingRO, CECMappingRO)
OBJECT_ENTRY(CLSID_ECLibrary, ECLibrary)
//OBJECT_ENTRY(CLSID_ECFileInfo, CECFileInfo)

OBJECT_ENTRY(CLSID_ECProjectFileInfo, CECProjectFileInfo)
END_OBJECT_MAP()

/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        _Module.Init(ObjectMap, hInstance, &LIBID_ECOBJECTSLib);
        DisableThreadLibraryCalls(hInstance);
    }
    else if (dwReason == DLL_PROCESS_DETACH)
	{
		CTraceCreation::ShowObjects();
		CTraceCreation::Done();			// free up any memory
		CRC::Done();					// make sure the object is cleaned up
        _Module.Term();
    }
	return TRUE;    // ok
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
    return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
    return _Module.UnregisterServer(TRUE);
}


