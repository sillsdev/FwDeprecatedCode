// ECSCodes.h
// 
// This file contains all of the HRESULT error codes for ECObjects that are
// non standard or provide additional information.
//

#define	ECERROR_VerseNoBook			MAKE_HRESULT( 1 , FACILITY_ITF , 0x0100 )
#define	ECERROR_VerseNoChapter		MAKE_HRESULT( 1 , FACILITY_ITF , 0x0101 )	
#define	ECERROR_ChapterNoBook		MAKE_HRESULT( 1 , FACILITY_ITF , 0x0102 )	
#define	ECERROR_BooksNoChapters		MAKE_HRESULT( 1 , FACILITY_ITF , 0x0104 )	

#define	ECERROR_NoVerse				MAKE_HRESULT( 1 , FACILITY_ITF , 0x0111 )	
#define	ECERROR_NoChapter			MAKE_HRESULT( 1 , FACILITY_ITF , 0x0112 )	
#define	ECERROR_NoBook				MAKE_HRESULT( 1 , FACILITY_ITF , 0x0114 )	

#define	ECERROR_NoVerseOrChapter		ECERROR_NoVerse	  | ECERROR_NoChapter
#define	ECERROR_NoVerseOrBook			ECERROR_NoVerse	  | ECERROR_NoBook
#define	ECERROR_NoChapterOrBook			ECERROR_NoChapter | ECERROR_NoBook
#define	ECERROR_NoVerseOrChapterOrBook	ECERROR_NoVerse   | ECERROR_NoChapter | ECERROR_NoBook

#define	ECERROR_InvalidBook			MAKE_HRESULT( 1 , FACILITY_ITF , 0x0120 )	
#define	ECERROR_InvalidChapter		MAKE_HRESULT( 1 , FACILITY_ITF , 0x0121 )	
#define	ECERROR_InvalidVerse		MAKE_HRESULT( 1 , FACILITY_ITF , 0x0122 )	

#define	ECERROR_InvalidArchive		MAKE_HRESULT( 1 , FACILITY_ITF , 0x0130 )	
#define	ECOK_InvalidArchive			MAKE_HRESULT( 0 , FACILITY_ITF , 0x0131 )	

// File Errors
// 0x0200 - 
#define	ECERROR_FileError			MAKE_HRESULT( 1 , FACILITY_ITF , 0x0200 )	

// problem with duplicate TEStyle's used in same (set) of input files
#define	ECERROR_DupBookMarker		MAKE_HRESULT( 1 , FACILITY_ITF , 0x0211 )
#define	ECERROR_DupChapterMarker	MAKE_HRESULT( 1 , FACILITY_ITF , 0x0212 )
#define	ECERROR_DupVerseMarker		MAKE_HRESULT( 1 , FACILITY_ITF , 0x0214 )


// Invalide numeric data
#define	ECERROR_InvalidChapterNumber	MAKE_HRESULT( 1 , FACILITY_ITF , 0xF300 )	
#define	ECERROR_InvalidVerseNumber		MAKE_HRESULT( 1 , FACILITY_ITF , 0xF301 )	

/*
 * Error codes not used / implemented
 *
 #define	ECERROR_ChaptersNoVerses	MAKE_HRESULT( 1 , FACILITY_ITF , 0x0103 )	
 *
 */


/*
struct {
	HRESULT hr;
	char* desc;
} ECErrors[] = {	{	ECERROR_VerseNoBook				, "Verse found with out Book." },
					{	ECERROR_VerseNoChapter			, "Verse found with out a Chapter (not single chapter book)." },
					{	ECERROR_ChapterNoBook			, "Chapter with no Book" },
					{	ECERROR_ChaptersNoVerses		, "Chapter with no verses." },
					{	ECERROR_BooksNoChapters			, "Book with no chapters." },
					{	ECERROR_NoVerse					, "No verse." },
					{	ECERROR_NoChapter				, "No chapters." },
					{	ECERROR_NoBook					, "No Book." },
					{	ECERROR_NoVerseOrChapter		, "No verse or chapter." },
					{	ECERROR_NoVerseOrBook			, "No verse or book." },
					{	ECERROR_NoChapterOrBook			, "No Chapter or book." },
					{	ECERROR_NoVerseOrChapterOrBook	, "No verse, chapter or book." },
					{	ECERROR_InvalidBook				, "Invalid book." },
					{	ECERROR_InvalidChapter			, "Invalid chapter." },
					{	ECERROR_InvalidVerse			, "Invalid verse." },
					{	ECERROR_InvalidArchive			, "Invalid Archive data." },
					{	ECOK_InvalidArchive				, "Hmmmm..." },
					{	ECERROR_FileError				, "Unknown file error." },

					{ 0, "Not an ECError code - Description is unknown" }
};


char* GetECErrorDescription( HRESULT hr)
{
	int i;
	for ( i=0; ECErrors[i].hr > 0; i++)
	{
		if (ECErrors[i] == hr )
			return ECErrors[i].desc;
	}

	return ECErrors[i].desc;
}

*/