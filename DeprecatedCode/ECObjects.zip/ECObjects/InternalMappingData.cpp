// InternalMappingData.cpp: implementation of the CInternalMappingData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "InternalMappingData.h"
#include "CRC.h"


/////////////////////////////////////////////////////////////////////////////
// CInternalMappingData
//
//
CInternalMappingData::CInternalMappingData() : CAutoIncrement(), CTraceCreation("IntMapData"),
	m_Domain(MD_Unknown), m_IsInline(FALSE), m_IsConfirmed(FALSE),
	m_SBKey(0), m_DirtySBKey(true), m_CreatorID(0), m_DestructorCount(0)
{
}


//////////////////////////////////////////////////
// Copy Constructor
//////////////////////////////////////////////////
//
CInternalMappingData::CInternalMappingData( const CInternalMappingData& other) : CAutoIncrement(), CTraceCreation("IntMapData")
{
	if ( this == &other )
		return;

///	ATLTRACE("*** CInternalMappingData, Copy \n");	// this->GetID());
	ATLTRACE("*** CInternalMappingData, Copy from<%d> to<%d>\n", ((CAutoIncrement)other).GetID(), this->GetID());

	m_Domain				= other.m_Domain;
	m_cbstrMarkerEncoding	= other.m_cbstrMarkerEncoding;
	m_cbstrDataEncoding		= other.m_cbstrDataEncoding;
	m_cbstrEndMarker		= other.m_cbstrEndMarker;
	m_cbstrBeginMarker		= other.m_cbstrBeginMarker;
	m_cbstrNewEndMarker		= other.m_cbstrNewEndMarker;
	m_cbstrNewBeginMarker	= other.m_cbstrNewBeginMarker;
	m_cbstrStyleName		= other.m_cbstrStyleName;
	m_cbstrWritingSystem	= other.m_cbstrWritingSystem;
	m_IsInline				= other.m_IsInline;
	m_IsConfirmed			= other.m_IsConfirmed;
	m_SBKey					= other.m_SBKey;
	m_DirtySBKey			= other.m_DirtySBKey;

	m_DestructorCount = 0;

	if ( m_CreatorID == 0 )
	{
		m_CreatorID	= other.m_CreatorID;	// same creator as this one
		if ( m_CreatorID == 0 )				// if no creator, than us the ID
			m_CreatorID	= ((CAutoIncrement*)(&other))->GetID();
	}
}

//////////////////////////////////////////////////
// Assignment operator
//////////////////////////////////////////////////
//
CInternalMappingData & CInternalMappingData::operator=( const CInternalMappingData & other)
{
	if ( this == &other )
		return *this;

//	ATLTRACE("*** CInternalMappingData, Assignment\n" );	//  from<%d> to<%d>\n", 100, GetID());
	ATLTRACE("*** CInternalMappingData, Assignment from<%d> to<%d>\n", ((CAutoIncrement)other).GetID(), GetID());

	m_Domain				= other.m_Domain;
	m_cbstrMarkerEncoding	= other.m_cbstrMarkerEncoding;
	m_cbstrDataEncoding		= other.m_cbstrDataEncoding;
	m_cbstrEndMarker		= other.m_cbstrEndMarker;
	m_cbstrBeginMarker		= other.m_cbstrBeginMarker;
	m_cbstrNewEndMarker		= other.m_cbstrNewEndMarker;
	m_cbstrNewBeginMarker	= other.m_cbstrNewBeginMarker;
	m_cbstrStyleName		= other.m_cbstrStyleName;
	m_cbstrWritingSystem	= other.m_cbstrWritingSystem;
	m_IsInline				= other.m_IsInline;
	m_IsConfirmed			= other.m_IsConfirmed;
	m_SBKey					= other.m_SBKey;
	m_DirtySBKey			= other.m_DirtySBKey;

	m_DestructorCount = 0;

	if ( m_CreatorID == 0 )
	{
		m_CreatorID	= other.m_CreatorID;	// same creator as this one
		if ( m_CreatorID == 0 )				// if no creator, than us the ID
			m_CreatorID	= ((CAutoIncrement*)(&other))->GetID();
	}

	return *this;
}


CInternalMappingData::~CInternalMappingData() 
{
	m_DestructorCount++;

	if ( m_DestructorCount > 1 )
		int asdf = 1234;
}

// ----------------------------------------------

void CInternalMappingData::SetMarkerEncoding( char* in )
{
	m_cbstrMarkerEncoding = in;
}

void CInternalMappingData::SetDataEncoding( char* in )
{
	m_cbstrDataEncoding = in;
}

void CInternalMappingData::SetBeginMarker( char* in )
{
	m_DirtySBKey = true;		// just dependant on the begin marker
	m_cbstrBeginMarker = in;
	CalcNewBeginMarker();
}

void CInternalMappingData::SetEndMarker( char* in )
{
	m_cbstrEndMarker = in;
	CalcNewEndMarker();
}

// ----------------------------------------------

void CInternalMappingData::SetMarkerEncoding( BSTR in )
{
	m_cbstrMarkerEncoding = in;
}

void CInternalMappingData::SetDataEncoding( BSTR in )
{
	m_cbstrDataEncoding = in;
}

void CInternalMappingData::SetBeginMarker( BSTR in )
{
	m_DirtySBKey = true;		// just dependant on the begin marker
	m_cbstrBeginMarker = in;
	CalcNewBeginMarker();
}

void CInternalMappingData::SetEndMarker( BSTR in )
{
	m_cbstrEndMarker = in;
	CalcNewEndMarker();
}

void CInternalMappingData::SetNewBeginMarker( BSTR in )
{
	m_cbstrNewBeginMarker = in;
}

void CInternalMappingData::SetNewEndMarker( BSTR in )
{
	m_cbstrNewEndMarker = in;
}

void CInternalMappingData::SetStyleName( BSTR in )		
{ 
	m_cbstrStyleName = in; 
}

void CInternalMappingData::SetWritingSystem( BSTR in )		
{ 
	m_cbstrWritingSystem = in; 
}

void CInternalMappingData::CalcNewBeginMarker()
{
	WCHAR *wcptr = m_cbstrBeginMarker.m_str;
	if ( m_cbstrBeginMarker.Length() > 0 )
	{
		WCHAR wcBackSlash = '\\';
		WCHAR wcNULL = '\0';
		WCHAR wcStar = '*';
		WCHAR wcPlus = '+';

		CComBSTR cbstrTemp = L"";
		if ( *wcptr != wcBackSlash )	// has to start with a backslash character
		{
			cbstrTemp = L"\\";
			cbstrTemp += m_cbstrBeginMarker;
		}
		else
			cbstrTemp = m_cbstrBeginMarker;
		
		// pull out '*' as they are not handled correctly in the SO and replace with '+'
		for ( wcptr = cbstrTemp.m_str; *wcptr != wcNULL; wcptr++ )
		{	// don't replace the last '*' if it's the last character
			if ( *wcptr == wcStar && *(wcptr+1) != wcNULL)
				*wcptr = wcPlus;
		}

		m_cbstrNewBeginMarker = cbstrTemp;
	}
	else
	{
		m_cbstrNewBeginMarker = "";
	}
}

void CInternalMappingData::CalcNewEndMarker()
{
	WCHAR *wcptr = m_cbstrEndMarker.m_str;
	if ( m_cbstrEndMarker.Length() > 0 )
	{
		CComBSTR cbstrTemp = L"";
		if ( *wcptr != '\\' )	// has to start with a backslash character
		{
			cbstrTemp = L"\\";
			cbstrTemp += m_cbstrEndMarker;
		}
		else
			cbstrTemp = m_cbstrEndMarker;

		// pull out '*' as they are not handled correctly in the SO and replace with '+'
		for ( wcptr = cbstrTemp.m_str; *wcptr != '\0'; wcptr++ )
		{	// don't replace the last '*' if it's the last character
			if ( *wcptr == '*' && *(wcptr+1) != '\0')
				*wcptr = '+';
		}

		m_cbstrNewEndMarker = cbstrTemp;
	}
	else
	{
		m_cbstrNewEndMarker = "";
	}
}

// ----------------------------------------------

void CInternalMappingData::SetDomain( MarkerDomain in )
{
	m_Domain = in;
}

void CInternalMappingData::SetInline( BOOL in )
{
	m_IsInline = in;
}

void CInternalMappingData::SetConfirmed( BOOL in )
{
	m_IsConfirmed = in;
}

// ----------------------------------------------

HRESULT CInternalMappingData::GetStyleName( BSTR *out) 
{ 
	*out = m_cbstrStyleName.Copy(); 
	return S_OK; 
}

HRESULT CInternalMappingData::GetMarkerEncoding( BSTR *out)
{
	*out = m_cbstrMarkerEncoding.Copy();
	return S_OK;
}

HRESULT CInternalMappingData::GetDataEncoding( BSTR *out)
{
	*out = m_cbstrDataEncoding.Copy();
	return S_OK;
}

HRESULT CInternalMappingData::GetBeginMarker( BSTR *out)
{
	*out = m_cbstrBeginMarker.Copy();
	return S_OK;
}

HRESULT CInternalMappingData::GetEndMarker( BSTR *out)
{
	*out = m_cbstrEndMarker.Copy();
	return S_OK;
}

HRESULT CInternalMappingData::GetNewBeginMarker( BSTR *out)
{
	if ( m_cbstrNewBeginMarker.Length() > 0 )
		*out = m_cbstrNewBeginMarker.Copy();
	else
		return GetBeginMarker( out );

	return S_OK;
}

HRESULT CInternalMappingData::GetNewEndMarker( BSTR *out)
{
	if ( m_cbstrNewEndMarker.Length() > 0 )
		*out = m_cbstrNewEndMarker.Copy();
	else
		return GetEndMarker( out );

	return S_OK;
}

HRESULT CInternalMappingData::GetWritingSystem( BSTR * out)
{
	*out = m_cbstrWritingSystem.Copy();

	return S_OK;
}


long CInternalMappingData::GetSBKey()
{
	if ( m_DirtySBKey )
	{
		CRC* crc = CRC::Instance();
		m_SBKey = crc->CalculateCRC(m_cbstrBeginMarker.m_str, m_cbstrBeginMarker.Length()*2 );
		m_DirtySBKey = false;
	}

	return m_SBKey;
}

// =====================================================

CPersist& operator<<( CPersist& stream, CInternalMappingData* data)
{
	BSTR beginMarker=0, endMarker=0, markerEncoding=0, dataEncoding=0, styleName=0;
	BSTR writingSystem=0;
	BSTR newBeginMarker=0, newEndMarker=0;
	short domain, bconfirmed, bInLine;

//	START_BE_SAFE( "operator<<(CPersist&, CMarkerProperties*)" )

	data->GetBeginMarker( &beginMarker );
	data->GetEndMarker( &endMarker );
///	data->GetNewBeginMarker( &newBeginMarker );
///	data->GetNewEndMarker( &newEndMarker );
	data->GetDataEncoding( &dataEncoding );
	data->GetMarkerEncoding( &markerEncoding );
	data->GetStyleName( &styleName );
	data->GetWritingSystem( &writingSystem );
	domain = data->GetDomain();
	bconfirmed = data->GetIsConfirmed();
	bconfirmed = true;	// put it out as confirmed so that it is read in confirmed
	bInLine = data->GetIsInline();


	// =====================================================
	stream << (BSTR*)&beginMarker << (BSTR*)&endMarker;
///	stream << (BSTR*)&newBeginMarker << (BSTR*)&newEndMarker;
	stream << bInLine << (BSTR*)&markerEncoding << (BSTR*)&dataEncoding;
	stream << domain << (BSTR*)&styleName;
	stream << (BSTR*)&writingSystem;
	stream << bconfirmed;
	// =====================================================

//	END_BE_SAFE

	if ( beginMarker )		::SysFreeString( beginMarker );
	if ( endMarker )		::SysFreeString( endMarker );
	if ( markerEncoding )	::SysFreeString( markerEncoding );
	if ( dataEncoding )		::SysFreeString( dataEncoding );
	if ( styleName )		::SysFreeString( styleName );
	if ( writingSystem )	::SysFreeString( writingSystem );
	if ( newBeginMarker )	::SysFreeString( newBeginMarker );
	if ( newEndMarker )		::SysFreeString( newEndMarker );

	return stream;
}


CPersist& operator>>( CPersist& stream, CInternalMappingData** data)
{
	BSTR beginMarker=0, endMarker=0, markerEncoding=0, dataEncoding=0, styleName=0;
	BSTR writingSystem=0;
	BSTR newBeginMarker=0, newEndMarker=0;
	short domain, bconfirmed, bInLine;

//	START_BE_SAFE( "operator>>(CPersist&, CMappingInfo**)" )

	// =====================================================
	stream >> (BSTR*)&beginMarker >> (BSTR*)&endMarker;
///	stream >> (BSTR*)&newBeginMarker >> (BSTR*)&newEndMarker;
	stream >> bInLine >> (BSTR*)&markerEncoding >> (BSTR*)&dataEncoding;
	stream >> domain >> (BSTR*)&styleName;
	stream >> (BSTR*)&writingSystem;
	stream >> bconfirmed;
	// =====================================================

	*data = new CInternalMappingData();
	(*data)->SetBeginMarker( beginMarker );
	(*data)->SetEndMarker( endMarker );
///	(*data)->SetNewBeginMarker( newBeginMarker );
///	(*data)->SetNewEndMarker( newEndMarker );
	(*data)->SetDataEncoding( dataEncoding );
	(*data)->SetMarkerEncoding( markerEncoding );
	(*data)->SetDomain( (MarkerDomain)domain );
	(*data)->SetStyleName( styleName );
	(*data)->SetWritingSystem( writingSystem );
	(*data)->SetConfirmed( bconfirmed );
	(*data)->SetInline( bInLine );

//	END_BE_SAFE

	if ( beginMarker )		::SysFreeString( beginMarker );
	if ( endMarker )		::SysFreeString( endMarker );
	if ( markerEncoding )	::SysFreeString( markerEncoding );
	if ( dataEncoding )		::SysFreeString( dataEncoding );
	if ( styleName )		::SysFreeString( styleName );
	if ( writingSystem )	::SysFreeString( writingSystem );
	if ( newBeginMarker )	::SysFreeString( newBeginMarker );
	if ( newEndMarker )		::SysFreeString( newEndMarker );

	return stream;
}

