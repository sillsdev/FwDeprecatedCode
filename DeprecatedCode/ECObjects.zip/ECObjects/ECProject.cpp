// ECProject.cpp : Implementation of CECProject
#include "stdafx.h"
#include "ECObjects.h"
#include "ECProject.h"
#include "ECMapping.h"
#include "ECProjectFileInfo.h"
#include "ECUtil.h"
#include "MappingInfo.h"
#include "CRC.h"
#include "Persist.h"
#include <time.h>
#include <stdio.h>
#include <io.h>		// filelength

#include "MappingDataContainer.h"

#include "ECLibrary.h"		// 4/23

#include "comdef.h"

#include "VectorOfPtrs.h"

#define	START_BE_SAFE( X )	bool besafeTrue=true; char besafeName__[] = {"" #X ""}; EnterCriticalSection( &m_csBusy );	try {
#define END_BE_SAFE		} catch(...) {besafeTrue=false;ATLTRACE("*** Exception: <%s>\n", besafeName__);} LeaveCriticalSection( &m_csBusy );
#define HAD_EXCEPTION	besafeTrue==false


// Some custom HRESULT values
#define E_DATACONVERTER_EXCEPTION		MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x5000)	// asdfasdf
#define E_ECPROJECT_TWO		MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x5001)	// asdfasdf


// Forward declarations for helper routines
/////////////////////////////////////////////////////////////////////////////
short	ScanForBooks( char* pStart, char* pEnd, const char* bookMarker, std::vector<short>& vsiBooks );
int		iLookupBook	( const char* pszBookName );

// Copied from "SrfLib.cpp" , ScriptureReference::iLookupBook
//
static int const NUM_BOOKS=99;
static int const SIZE_BOOK_NAME=3;
//
// Standard book name abbreviations
const char *ppszBookNames[] = {"", 
"GEN","EXO","LEV","NUM","DEU","JOS","JDG","RUT","1SA","2SA",
"1KI","2KI","1CH","2CH","EZR","NEH","EST","JOB","PSA","PRO",
"ECC","SNG","ISA","JER","LAM","EZK","DAN","HOS","JOL","AMO",
"OBA","JON","MIC","NAM","HAB","ZEP","HAG","ZEC","MAL","MAT",
"MRK","LUK","JHN","ACT","ROM","1CO","2CO","GAL","EPH","PHP",
"COL","1TH","2TH","1TI","2TI","TIT","PHM","HEB","JAS","1PE",
"2PE","1JN","2JN","3JN","JUD","REV","TOB","JDT","ESG","WIS",
"SIR","BAR","LJE","S3Y","SUS","BEL","1MA","2MA","3MA","4MA",
"1ES","2ES","MAN","PS2","ODA","PSS","JSA","JDB","TBS","SST",
"DNT","BLT","XXA","XXB","XXC","XXD","XXE","XXF","XXG",
"" };

/////////////////////////////////////////////////////////////////////////////
// Define function template to release a vector of pointers
//
template<class C>
void VectorClean( std::vector<C>& vec)
{
	for ( std::vector<C>::iterator IT = vec.begin(); IT != vec.end(); IT++ )
	{
		delete *IT;
	}
	vec.clear();
}



/////////////////////////////////////////////////////////////////////////////
// CECProject

STDMETHODIMP CECProject::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IECProject
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

CECProject::CECProject() : CTraceCreation( "CECProject" )
{
	InitializeCriticalSection( &m_csBusy );

	m_Escape = NULL;
	m_dataCont = new CMappingDataContainer;
	m_DoneConvertEvent = NULL;
	m_ECLibrary = NULL;
	m_cbstrUserSTYName.Empty();		// default to empty user value
	m_cbstrUserSSFName.Empty();		// default to empty user value

	// set the temp generated unique file names for this project
	{
		char buff[512], tmpName[512];
		if ( GetTempPath( 512, buff ) == 0 )	// failed
		{
			strcpy( buff, "c:\\" );				// default to 'c' drive on failure
		}
		GetTempFileName(buff, "SIF", 0, tmpName);
		m_cbstrTempSSFName = tmpName;
		GetTempFileName(buff, "SIY", 0, tmpName);
		m_cbstrTempSTYName = tmpName;

		m_cbstrSSFName = m_cbstrTempSSFName;	// use the generated values
		m_cbstrSTYName = m_cbstrTempSTYName;
	}

	Init();

//	Test();
	
	CComObject<ECLibrary> *pste;
	HRESULT hResult = CComObject<ECLibrary>::CreateInstance(&pste);
	if (FAILED(hResult))
	{
		ATLTRACE("Unable to create ECLibrary in ECProject constructor. *** ERROR ***\n" );
		return;
	}
	ULONG lval = pste->AddRef();

	m_ECLibrary = pste;


	// pull out the fieldworks directory for the python and default sty file

	char *strSubkey = "SOFTWARE\\SIL\\FieldWorks";	//  HKEY_LOCAL_MACHINE\SOFTWARE\SIL\FieldWorks the RootDir key. 

	char strResult[256];
	DWORD iResultLength = sizeof(strResult);

    HKEY hKey;
    LONG lRet;

    lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE, strSubkey, 0, KEY_QUERY_VALUE, &hKey );
    if( lRet == ERROR_SUCCESS )
	{
	    lRet = RegQueryValueEx( hKey, "RootDir", NULL, NULL, (LPBYTE) strResult, &iResultLength);
		if( (lRet == ERROR_SUCCESS) && (iResultLength < 256) )
		{
			if (strResult[strlen(strResult)-1] != '\\')
				strcat(strResult, "\\");

			m_cbstrRootDir = strResult;
			m_cbstrBinDir = m_cbstrRootDir;
			m_cbstrBinDir += L"Python\\";		// python directory

			// now lets read the default .sty file <ECSOStyles.sty> which is also in the 'RootDir'

			CComBSTR defaultStylesFile = m_cbstrRootDir;
			defaultStylesFile += L"ECSOStyles.sty";

			// replace the ReadTEStyleFile interface method 
			try
			{
				long numStyles;
				if ( m_ECLibrary )
					m_ECLibrary->ReadInTEStyleNames( defaultStylesFile, &numStyles );
			}
			catch(...)
			{
			}
		}
		else
		{
			// not sure what to put here if the value isn't in the registry???  TODO
		}

	    RegCloseKey( hKey );
	}
	else
	{
		// not sure what to put here if the value isn't in the registry???  TODO
	}
}

// ,_ATL_DLL,_ATL_MIN_CRT


void RemoveEmptyFile(CComBSTR &fname)
{
	// delete the output file if the file size is zero
	if (fname.Length() <= 0)
		return;

	FILE * fp = _wfopen(fname.m_str, L"rb");
	if (fp)
	{
		long nFileSize = _filelength(_fileno(fp));
		fclose(fp);
		if (nFileSize <= 0L)
		{
			if ( _wunlink( fname.m_str ) == -1)
			{
				OutputDebugString("Unable to delete output file <");
				OutputDebugStringW(fname);
				OutputDebugString(">\n");
			}
		}
	}
}


CECProject::~CECProject()
{
	ATLTRACE("* ~CEProject()<%d> called\n", GetTraceID());

	RemoveEmptyFile(m_cbstrTempSSFName);
	RemoveEmptyFile(m_cbstrTempSTYName);

	if ( m_AutoDelete )
	{
		DeleteOutputFiles();	// remove temp files
	}

	VectorClean( m_vFileInfo );

	deleteIfExists( &m_Escape );
	ATLTRACE("* Line=%d", __LINE__ );

	delete m_dataCont;

	if ( m_DoneConvertEvent )
	{
		CloseHandle( m_DoneConvertEvent );
	}

	DeleteCriticalSection( &m_csBusy );
	
	m_ECLibrary->Release();

	this->ShowObjects();
}


CPersist& operator<<( CPersist& pstream, CECProject* data)
{
	//	version description
	//	bookMarker, default data encoding, default marker encoding, [Mapping info]*, # of Files, [file info]*
	//////////////////////
	pstream << "ECProject";									//	Description
	pstream << (BSTR*)&(data->m_cbstrBookMarker.m_str);		//	BookMarker
	pstream << (BSTR*)&(data->m_cbstrDataEncoding.m_str);	//	Data Encoding
	pstream << (BSTR*)&(data->m_cbstrMarkerEncoding.m_str);	//	Marker Encoding
	pstream << (BSTR*)&(data->m_cbstrBinDir.m_str);			//	Binary Directory
	pstream << (BSTR*)&(data->m_cbstrSSFName.m_str);		//	SSF file name
	pstream << (BSTR*)&(data->m_cbstrSTYName.m_str);		//	STY file name
	pstream << (data->m_dataCont);							//	Mapping information
	pstream << (long)data->m_vFileInfo.size();				//	Number of Files in project

	for ( TVectorITFileInfo fiIT = data->m_vFileInfo.begin(); fiIT != data->m_vFileInfo.end(); fiIT++ )
	{
		CInternalProjectFileInfo* fi = (*fiIT);	// get a pointer to the object
		pstream << fi;
	}

	return pstream;
}

CPersist& operator>>( CPersist& stream, CECProject** data)
{
	bool dirty = false;
	try
	{
		while ( true )
		{
		ATLTRACE(" --- Restoring from Archive ---\n");

		(*data)->Init();		// reset all the data structures...

		char* desc=0;
		BSTR bstrTemp;
		long lcount;
		
		//	version description
		//	bookMarker, default data encoding, default marker encoding, # of Mappings, [Mapping info]*, # of Files, [file]*
		//////////////////////
		stream >> &desc;							// description
	
		// make sure it's the right type of CPersist data
		if ( desc && strcmp( desc, "ECProject" ) )
		{
			stream.SetError( CPersist::ET_BAD_INIT );
			ATLTRACE(" --- CECProject not created from <%s> stream. ---\n", desc );
			delete [] desc;
			return stream;
		}

		delete [] desc;

		stream >> &bstrTemp;							// book marker
		(*data)->m_cbstrBookMarker = bstrTemp;
		::SysFreeString( bstrTemp );
		
		dirty = true;

		if ( stream.HasError() )	break;

		stream >> &bstrTemp;							// data encoding
		(*data)->m_cbstrDataEncoding = bstrTemp;
		::SysFreeString( bstrTemp );
		if ( stream.HasError() )	break;

		stream >> &bstrTemp;							// marker encoding
		(*data)->m_cbstrMarkerEncoding = bstrTemp;
		::SysFreeString( bstrTemp );
		if ( stream.HasError() )	break;

		stream >> &bstrTemp;							// - bin directory
		(*data)->m_cbstrBinDir = bstrTemp;
		::SysFreeString( bstrTemp );
		if ( stream.HasError() )	break;

		stream >> &bstrTemp;							// - ssf File Name
		(*data)->put_DefaultSSFFileName(bstrTemp);
		::SysFreeString( bstrTemp );
		if ( stream.HasError() )	break;

		stream >> &bstrTemp;							// - sty File Name
		(*data)->put_DefaultSTYFileName(bstrTemp);
		::SysFreeString( bstrTemp );
		if ( stream.HasError() )	break;


		stream >> &((*data)->m_dataCont);				// mapping information
		if ( stream.HasError() )	break;

		stream >> lcount;								// number of files
		if ( stream.HasError() )	break;

		ATLTRACE(" --- Number of Files = %d\n", lcount );

		for ( int i=0; i<lcount; i++ )
		{
			CInternalProjectFileInfo* pfi;
	
			stream >> &pfi;
			if ( stream.HasError() )	break;
			
			if ( (*data)->AddFileInfo( pfi ) != 0 )		// just add the file with out getting mappings (replacement for AddFilePathOnly)
			{
				// wasn't added (dup input file name) so free the object
				delete pfi;
			}

#ifdef _DEBUG
			BSTR bstrFile;
			ATLTRACE(" --- File<%2d> = <", i+1 );
			pfi->GetInputFileName( &bstrFile );
			OutputDebugStringW( bstrFile );
			ATLTRACE( "><" );
			::SysFreeString( bstrFile );
			pfi->GetOutputFileName( &bstrFile );
			OutputDebugStringW( bstrFile );
			ATLTRACE( ">\n" );
			::SysFreeString( bstrFile );
#endif
		}
		if ( stream.HasError() )	break;

		ATLTRACE(" --- CECProject Successfully created from BLOB. ---\n" );
		break;
		}
	}
	catch(...)
	{
		ATLTRACE(" ### ERROR: --- Object NOT Successfully created from BLOB\n" );

		// re initialize the data for the object...
		(*data)->Init();
		dirty = false;
	}
		
	if ( stream.HasError() && dirty )
		(*data)->Init();

	return stream;
}

STDMETHODIMP CECProject::get_LibraryObject(IECLibrary **pVal)
{
	if ( m_ECLibrary )
	{
		m_ECLibrary->AddRef();
		*pVal = m_ECLibrary;
		return S_OK;
	}

	return E_UNEXPECTED;
}

void CECProject::SaveToString( BSTR* archive )
{
	START_BE_SAFE( CECProject::SaveToString )
	
///	int dataLen, numFiles, count;
	CPersist pstream;

	pstream << this;

	*archive = ::SysAllocStringByteLen( pstream.ReadOnlyBuffer(), pstream.ReadOnlyBufferSize() );

	ATLTRACE( "* Created %d byte Archive Blob.\n", ::SysStringByteLen( *archive ) );

	END_BE_SAFE

	if ( HAD_EXCEPTION )
	{
		CComBSTR blob = "";
		*archive = blob.Copy();
	}

	ATLTRACE( "* Created %d byte Archive Blob.\n", ::SysStringByteLen( *archive ) );
}


void CECProject::Init()
{
	START_BE_SAFE( CECProject::Init )

	deleteIfExists( &m_Escape );
	copyIfExists( "\\", &m_Escape ); 

	m_cbstrBookMarker = L"\\id";		// default marker, until the data is processed

	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	m_mapMarkers.clear();
	m_bDirtyFiles = false;
	m_bDirty = false;
	m_dataCont->EraseAll();
	m_AutoDelete = true;

	VectorClean( m_vFileInfo );

	ATLTRACE(" * CECProject<%d> initialized with default values\n", GetTraceID() );

	END_BE_SAFE
}


STDMETHODIMP CECProject::InitializeFromSafeArray(/*[in]*/ VARIANT pSafeArrayOfBytes )
{
	START_BE_SAFE( CECProject::InitializeFromSafeArray )

	long LBnd, UBnd;
	SafeArrayGetLBound(V_ARRAY(&pSafeArrayOfBytes), 1, &LBnd);
	SafeArrayGetUBound(V_ARRAY(&pSafeArrayOfBytes), 1, &UBnd);

	long lsize = UBnd-LBnd+1;
	char *data = new char[lsize];
	unsigned char *pData = (unsigned char*)data;
	for (long li = LBnd; li <= UBnd; li++, pData++ )
	{
		SafeArrayGetElement(V_ARRAY(&pSafeArrayOfBytes), &li, pData );
	}

	CPersist persist(data, lsize );
	delete [] data;

	if ( !persist.HasError() )
	{
		ATLTRACE("**** Good archive, now pull data into object. ***\n");
		CECProject *projPtr = this;
		persist >> &projPtr;
		if ( persist.HasError() )
		{
		}

		return S_OK;
	}
	else
	{
		ATLTRACE("*** Initialize called with invalid data: Default initialization preformed.\n" );
		Init();
		return S_OK;
	}
	
	END_BE_SAFE

	if ( HAD_EXCEPTION )
	{
		ATLTRACE( "### ERROR: Unable to initialize with data.  Default initialization preformed.\n" );
	}

	return S_OK;
}


bool CECProject::IsValidFile( BSTR bstrFileName )
{
	bool rval = false;
	while (1)
	{
		HANDLE hFile;
		BY_HANDLE_FILE_INFORMATION fileData;

		hFile = CreateFileW(bstrFileName,  
						GENERIC_READ,              // open for reading 
						FILE_SHARE_READ,           // share for reading 
						NULL,                      // no security 
						OPEN_EXISTING,             // existing file only 
						FILE_ATTRIBUTE_NORMAL,     // normal file 
						NULL);                     // no attr. template 
 
		// TE-510 - allow unavailable files to be added
		if (hFile == INVALID_HANDLE_VALUE) 
		{
			rval = true;
			break;
		}

#if 0
		DWORD dwLow, dwHigh;
		dwLow = GetFileSize( hFile, &dwHigh);
		int nFileSize = (int)fileData.nFileSizeLow;
#else
		if (! GetFileInformationByHandle(hFile, &fileData)) {
			CloseHandle(hFile);
			break;
		}
		int nFileSize = (int)fileData.nFileSizeLow;
#endif

		// If file is zero size then it clearly contains no markers.
		if (nFileSize == 0) {
			CloseHandle(hFile);
			break;
		}
		
		HANDLE hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
		if (hFileMapping == NULL) {
			CloseHandle(hFile);
			break;
		}

		char* pFile = (char*)MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
		if (pFile == NULL) {
			CloseHandle(hFileMapping);
			CloseHandle(hFile);
			break;
		}

		char* pEnd = pFile + nFileSize - 1;

		// now interrogate the file...
		//
		typedef enum T_DataType { DT_Unknown, DT_Shoebox };
		T_DataType fileType = DT_Unknown;

		char dt_Shoebox[] = {"\\_sh"};
		char shProject[128];

		char *p = pFile;

		if ( strncmp( p, dt_Shoebox, strlen(dt_Shoebox) ) == 0 )	// found match
		{
			p += strlen(dt_Shoebox);
			if ( *p == ' ' )				// space before version
			{
				while (*p == ' '           )	p++;	// eat space
				while (*p != ' ' && p<pEnd )	p++;	// version information
				while (*p == ' '           )	p++;	// eat space
				while (*p != ' ' && p<pEnd )	p++;	// revision information
				while (*p == ' '           )	p++;	// eat space
			
				int pos = 0;
				while (*p != ' ' && *p != 0x0a && *p != 0x0d && p<pEnd )
				{
					shProject[pos++] = *p;	// shoebox project name
					p++;
				}
				shProject[pos] = '\0';

				fileType = DT_Shoebox;
				ATLTRACE(" ---- ShoeBox file: ");
				OutputDebugStringW( bstrFileName );
				ATLTRACE("\n");

				// ---------------------------------------------------------
				// See if a .TYP file is in the current dir for this project
				//

				ATLTRACE(" ---- ShoeBox project name: %s\n", shProject );
			}
		}

		TMappingInfo mappingInfo;
		TMapStringAndInfo mapMarkers;
		TMapITStringAndInfo tmapIT;

		TMapCharPtrsAndInts		/*mapMarkers,*/ mapEndMarkers;
		TMapITCharPtrsAndInts	mapIT;

		char tmpMarker[128];
		char asterisk[] = {"*"};
		int escapeLen = strlen(m_Escape);
		int pos;
		bool bInline = false;

		//	Check for BOM and adjust tests if found
		bool hasBOM = false;
		short lenBOM = 0;
		{
			char utf32be[] = { (char)0x00, (char)0x00, (char)0xfe, (char)0xff };
			char utf32le[] = { (char)0xff, (char)0xfe, (char)0x00, (char)0x00 };
			char utf16be[] = { (char)0xfe, (char)0xff };
			char utf16le[] = { (char)0xff, (char)0xfe };
			char utf8   [] = { (char)0xef, (char)0xbb, (char)0xbf };
			struct {
				char* data;
				int len;
			} encodingData[] = {
				{ utf32be, 4 },	{ utf32le, 4 },	{ utf16be, 2 },	{ utf16le, 2 },
				{ utf8   , 3 },
			};

			short numEncodings = sizeof(encodingData)/sizeof(encodingData[0]);
			for ( int i=0; i<numEncodings; i++ )
			{
				if ( memcmp(pFile, encodingData[i].data, encodingData[i].len ) == 0 )
				{
					hasBOM = true;
					lenBOM = encodingData[i].len;
					break;
				}
			}
		}

		//

		//	Scan the file and pull out all of the markers
		//	Save the markers in an internal temporary list
		//
		for ( p = pFile; p<pEnd; ++p) 
		{
			if ( strncmp(p, m_Escape, escapeLen ) != 0 )	continue;	// have to find escape first

			// if we're at the start of the file (after the BOM if it exists) OR
			// we've just seen the 0x0xa character OR
			if ( (p == (pFile+lenBOM)) || *(p-1) == 0x0a )		
				bInline = false;
			else
				bInline = true;

			// FOR TE SPECIFICALLY !!!! 
			// *****************************************************
			if (bInline)
				continue;
			// *****************************************************
			// Ignore all backslash chars as markers unless they start the line
			// TE SPECIFIC

			strcpy(tmpMarker, m_Escape );	// start with escape char[s]
			pos = escapeLen; 
			p += pos;

			while (*p != ' ' && *p != 0x0a && *p != 0x0d && p<pEnd )
			{
				tmpMarker[pos++] = *p;
				if ( *p == asterisk[0] )	// capture the asterisk and then exit the loop
				{
					p++;
					break;
				}
				p++;						// continue
			}
			tmpMarker[pos] = '\0';


			bool saved = false;
			// see if it's a candidate for an end marker
			if ( tmpMarker[pos-1] == '*' )
			{
				tmpMarker[pos-1] = '\0';			// temporarlily remove the * and see if the marker exists...
				tmapIT = mapMarkers.find(tmpMarker);
				if ( tmapIT != mapMarkers.end() )	// found begin marker with out the '*' in the list
				{
					// add it to the endMarkerMap
					mapIT = mapEndMarkers.find(tmpMarker);
					if ( mapIT == mapEndMarkers.end() )
					{
						mapEndMarkers[tmpMarker] = 1;
						ATLTRACE(" - Found End marker: <%s>\n", tmpMarker );
					}
					else
						(*mapIT).second +=1;

					saved = true;
				}
				else
				{
					tmpMarker[pos-1] = '*';
					tmpMarker[pos] = '\0';
				}
			}

			if ( !saved )
			{
				// put marker into the map or bump the count
				tmapIT = mapMarkers.find(tmpMarker);
				if ( tmapIT == mapMarkers.end() )
				{
					mappingInfo.count = 1;
					mappingInfo.bInline = bInline;
					mapMarkers[tmpMarker] = mappingInfo;	// 1;
					ATLTRACE(" - Found marker: <%s>\n", tmpMarker );
				}
				else
				{
					(*tmapIT).second.count++;
				}
			}
		}

		//	Add the temporary list of markers to the 'project' markers
		//
		for ( tmapIT = mapMarkers.begin(); tmapIT != mapMarkers.end(); tmapIT++ )
		{
///			ATLTRACE(" Marker : <%s>  Count = %d\n", (*mapIT).first.c_str(), (*mapIT).second );

			mappingInfo = (*tmapIT).second;

			// first see if the is an equivalent entry in the end marker map, if so add as an inline marker
			TMapITCharPtrsAndInts	endMapIT;

			strcpy( tmpMarker, (char*)((*tmapIT).first.c_str()) );
			endMapIT = mapEndMarkers.find( tmpMarker );		// (char*)((*mapIT).first.c_str()) );



			if ( endMapIT != mapEndMarkers.end() )				// found end marker entry
			{
				strcat(tmpMarker, asterisk );
				this->AddMapping( (char*)((*tmapIT).first.c_str()), tmpMarker, mappingInfo.bInline );
			}
			else
				this->AddMapping( (char*)((*tmapIT).first.c_str()), NULL, mappingInfo.bInline );
		}

		UnmapViewOfFile(pFile);
		CloseHandle(hFileMapping);
		CloseHandle(hFile);

		rval = true;
		break;
	}
	return rval;
}


STDMETHODIMP CECProject::AddFile(/*[in]*/ BSTR bstrFileName)
{
	HRESULT hr = S_OK;
	EC_FileEncoding fileEC;
	long percentCertian;

	START_BE_SAFE( CECProject::AddFile )

	hr = AddFileGetEncoding(bstrFileName, &fileEC, &percentCertian);

	END_BE_SAFE

	return hr;
}


STDMETHODIMP CECProject::AddFileGetEncoding(BSTR bstrFileName, EC_FileEncoding *fileEC, long *percentCertian)
{
	CComBSTR tmp;
	tmp = bstrFileName;		// will be put in a map or vector
	HRESULT hr = S_OK;		// return error code if unable to add file

	START_BE_SAFE( CECProject::AddFileGetEncoding )

	// first check to see if the file is already in the project,
	// if so - then remove the fileinfo and add it fresh.
	for ( TVectorITFileInfo fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++ )
	{
		if ( (*fiIT)->SameInputFileName( bstrFileName ) )
		{
			ATLTRACE("Adding File again: FRESHEN...\n" );
			int count = m_vFileInfo.size();
			delete *fiIT;		// have to delete the object, erase doesn't free the memory...
			m_vFileInfo.erase( fiIT );
			count = m_vFileInfo.size();
			break;
		}
	}

	for ( fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++ )
	{
		int asdf = 1234;
	}

	EC_FileEncodingSource fes;
	m_ECLibrary->GuessFileEncoding(bstrFileName, fileEC, &fes, percentCertian);

	// make sure the file can be read
	// search the file for markers
	// add the markers to the project
	//
	//	All performed in "IsValidFile"

	bool validFile = IsValidFile( bstrFileName );

	if ( validFile )
	{
		// build the default output file name and save it as well
		CComBSTR outFileName = bstrFileName;

		// pull off the file name
		WCHAR bs = '\\';
		WCHAR *nameStart = wcsrchr( bstrFileName, bs );
		CComBSTR justName;
		if ( nameStart )
		{
			nameStart++;
			justName = nameStart;
		}
		else
			justName = bstrFileName;

		char buff[512], tmpName[512];
		GetTempPath( 512, buff );
		GetTempFileName( buff, "ECP", 0, tmpName);
		outFileName = tmpName;

		CInternalProjectFileInfo* fi = new CInternalProjectFileInfo();
		fi->SetInputFileName( bstrFileName );
		fi->SetOutputFileName( outFileName );
		fi->SetFileEncoding( *fileEC, static_cast<short>(*percentCertian) );
		fi->SetFileEncodingSource( fes );
		if ( fes == FES_BOM )
		{
			fi->SetHasBOM();
		}

		m_vFileInfo.push_back( fi );	// vector takes over ownership of fi object
		int count = m_vFileInfo.size();
		for ( fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++ )
		{
			int asdf = 1234;
		}
	}
	else
	{
//		hr = E_INVALIDARG;
		hr = ECERROR_FileError;		// could have been the standard E_INVALIDARG;
	}

	m_bDirtyFiles = true;

	END_BE_SAFE

	return hr;
}


short CECProject::AddFileInfo( CInternalProjectFileInfo* pfi )	// replacement for AddFilePathOnly
{
	short rval = 0;
	bool found = false;
	BSTR inFileName=0;

	START_BE_SAFE( CECProject::AddFileInfo );

	pfi->GetInputFileName( &inFileName );	// get the input file name

	for ( TVectorITFileInfo fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++ )
	{
		CInternalProjectFileInfo* fi = (*fiIT);	// get the object
		if ( fi->SameInputFileName( inFileName ) )
		{
			found = true;
			rval = -1;		// already exists
			break;
		}
	}

	if ( !found )
	{
		m_vFileInfo.push_back( pfi );	// vector takes over ownership of pfi object
	}

	END_BE_SAFE

	return rval;
}


STDMETHODIMP CECProject::RemoveFile(/*[in]*/ BSTR bstrFileName)
{
	CComBSTR tmp;
	tmp = bstrFileName;		// will be put removed from internal map or vector
	boolean bFound = false;

	START_BE_SAFE( CECProject::RemoveFile );

	for ( TVectorITFileInfo fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++ )
	{
		CInternalProjectFileInfo* fi = (*fiIT);	// get the object
		if ( fi->SameInputFileName( bstrFileName ) )
		{
			ATLTRACE("Removing File : %s\n", tmp.m_str );
			m_vFileInfo.erase( fiIT );
			delete fi;		// have to delete the object, erase doesn't free the memory...

			m_bDirtyFiles = true;
			bFound = true;
			break;
		}
	}

	END_BE_SAFE

	if ( !bFound )
	{
		ATLTRACE("Removing File **FAILED**, File not Found.\n" );
	}

	return S_OK;
}

STDMETHODIMP CECProject::get_Files(/*[out,retval]*/ VARIANT* pSafeArray)	// safe array of bstrs
{
	HRESULT hr = S_OK;

	START_BE_SAFE( CECProject::get_Files );

	const int numItems = m_vFileInfo.size();

	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreate(VT_BSTR, 1, rgsabound);

	CComBSTR val;
	BSTR bstrVal;
	LONG lIndex = 0;

	// Fill the safe array with the input file names
	//
	for ( TVectorITFileInfo fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++, lIndex++ )
	{
		CInternalProjectFileInfo* fi = (*fiIT);	// get the object
		fi->GetInputFileName( &bstrVal );
		hr  = SafeArrayPutElement(psa, &lIndex, bstrVal);	// val.Copy());
		::SysFreeString( bstrVal );
	}

	pSafeArray->vt = VT_BSTR | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;

	END_BE_SAFE

	return hr;
}

STDMETHODIMP CECProject::get_NumberOfMappings(/*[out,retval]*/ int* iCount)
{
	*iCount = (int)m_dataCont->Size();
	return S_OK;
}

STDMETHODIMP CECProject::get_NumberOfFiles(/*[out,retval]*/ int* iCount)
{
	*iCount = m_vFileInfo.size();	// vInFiles.size();
	return S_OK;
}



bool CECProject::MarkerAlreadyExists( char *marker )
{
	bool rval = false;

	START_BE_SAFE( CECProject::MarkerAlreadyExists );

	CInternalMappingData tstData;
	tstData.SetBeginMarker( marker );
	long key = tstData.GetSBKey();
	rval = m_dataCont->FindKey( key );

	END_BE_SAFE

	return rval;
}

void CECProject::AddMapping( char* marker, char* endMarker/*=""*/, bool bInline/*=false*/ )
{
	START_BE_SAFE( CECProject::AddMapping );

	BSTR teStyleName;
	CComBSTR markerBSTR = marker;
	this->m_ECLibrary->get_TEStyleName( markerBSTR, &teStyleName );

	CInternalMappingData *tstData = new CInternalMappingData();

	tstData->SetBeginMarker( marker );
	tstData->SetStyleName( teStyleName );

	// handle the inline marker if endMarker has data

	if ( endMarker && *endMarker )
	{
		tstData->SetEndMarker( endMarker );
		tstData->SetInline( true );
	}

	tstData->SetInline( bInline );

	bool added = m_dataCont->Add( tstData );
	bool updated = false;

	if ( !added )	// if there is a TEStyleName different from 'Unknown'
	{
		CInternalMappingData *oldRec = m_dataCont->GetDataFromKey( tstData->GetSBKey() );
		if ( oldRec )
		{
			BSTR bstrOldStyleName, bstrUnknownStyleName;
			CComBSTR cbstrUnknown =  L"ThisMarkerShouldNeverExist";

			this->m_ECLibrary->get_TEStyleName( cbstrUnknown.m_str, &bstrUnknownStyleName );
			oldRec->GetStyleName( &bstrOldStyleName );

			cbstrUnknown = bstrUnknownStyleName;
			if ( cbstrUnknown == bstrOldStyleName && cbstrUnknown != teStyleName)
			{
				oldRec->SetStyleName( teStyleName );
				updated = true;
			}
			
			::SysFreeString( bstrOldStyleName );
			::SysFreeString( bstrUnknownStyleName );
		}
		delete tstData;
	}
	
	::SysFreeString( teStyleName );

	if ( !added && !updated )
	{
		ATLTRACE("*** Marker Not Added OR Updated: <%s>\n", marker);
	}

	END_BE_SAFE
}



STDMETHODIMP CECProject::debugShowObjects()
{
	CTraceCreation::ShowObjects();
	return S_OK;
}


STDMETHODIMP CECProject::GetBooksForFile( 
			/*[in]*/ BSTR bstrFileName,			// "fullpath and filename of file"
			/*[out,retval]*/ VARIANT* pSafeArray
			)
{
	std::vector<short> vsiBooks;
	HRESULT hr = 0;

		ATLTRACE("\n===============\n*** GetBooksForFile: ");
		OutputDebugStringW(bstrFileName);
		ATLTRACE("********\n\n");

	while (1)
	{
		HANDLE hFile;
		BY_HANDLE_FILE_INFORMATION fileData;

		USES_CONVERSION;

		char bookMarker[128];
		if (m_cbstrBookMarker.Length() > 0 )
			strcpy(bookMarker, OLE2A(m_cbstrBookMarker) );
		else
			strcpy(bookMarker, "\\id");				// TODO: add method to set the Book Marker

		hFile = CreateFile(OLE2A(bstrFileName),  
						GENERIC_READ,              // open for reading 
						FILE_SHARE_READ,           // share for reading 
						NULL,                      // no security 
						OPEN_EXISTING,             // existing file only 
						FILE_ATTRIBUTE_NORMAL,     // normal file 
						NULL);                     // no attr. template 
 
		if (hFile == INVALID_HANDLE_VALUE) 
			break;

		if (! GetFileInformationByHandle(hFile, &fileData)) {
			CloseHandle(hFile);
			break;
		}

		int nFileSize = (int)fileData.nFileSizeLow;

		// If file is zero size then it clearly contains no markers.
		if (nFileSize == 0) {
			CloseHandle(hFile);
			break;
		}
		
		HANDLE hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
		if (hFileMapping == NULL) {
			CloseHandle(hFile);
			break;
		}

		char* pFile = (char*)MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
		if (pFile == NULL) {
			CloseHandle(hFileMapping);
			CloseHandle(hFile);
			break;
		}

		char* pEnd = pFile + nFileSize - 1;
		short numbooks = ScanForBooks( pFile, pEnd, bookMarker, vsiBooks );

		UnmapViewOfFile(pFile);
		CloseHandle(hFileMapping);
		CloseHandle(hFile);

		break;
	}

	try
	{
		const int numItems = vsiBooks.size();

		SAFEARRAY FAR* psa;
		SAFEARRAYBOUND rgsabound[1];
		rgsabound[0].lLbound = 0;
		rgsabound[0].cElements = numItems;
		psa = SafeArrayCreate(VT_I2, 1, rgsabound);

		short sVal;
		LONG lIndex = 0;

		// Fill the safe array with the short value for the book
		//
		for( lIndex = 0 ; lIndex < numItems ;lIndex++)
		{
			sVal = (short) vsiBooks.at(lIndex);
			hr  = SafeArrayPutElement(psa, &lIndex, &sVal);
		}

		pSafeArray->vt = VT_I2 | VT_ARRAY;
		V_ARRAY(pSafeArray) = psa;

	}
	catch(_com_error &e)
	{
		e;
		// DumpError(e);
	}

	return hr;
}


/////////////////////////////////////////////////////////////////////////////
//
// Helper routines
//
/////////////////////////////////////////////////////////////////////////////
short ScanForBooks( char* pStart, char* pEnd, const char* bookMarker, std::vector<short>& vsiBooks )
{
	short rval = 0;
	char *p;
	char bookName[4];	// three char code plus null

	vsiBooks.clear();

	int bookMarkerLen = strlen(bookMarker);
	
	for (p = pStart; p<pEnd; ++p) {
		if (strncmp(p, bookMarker, bookMarkerLen) != 0) continue;	// look for complete marker

		p += bookMarkerLen;									// update pointer
		if (*p != ' ' && *p != '\t ') continue;				// look for white space
		for (p++; *p == ' ' || *p == '\t'; ++p) {}			// eat any additional white space

		if ( *(p+3) != ' '  && *(p+3) != '\t' &&			// need ws after found book name
			 *(p+3) != 0x0d && *(p+3) != 0x0a ) continue;	//  OR possibly and end of line

		strncpy( bookName, p, bookMarkerLen);
		bookName[3] = '\0';

		int id = iLookupBook( bookName );
		
		ATLTRACE("Book Offset %s:%d\n", bookName, id);

		if ( id )
		{
			rval++;
			vsiBooks.push_back( id );
		}
	}

	return rval;
}


int iLookupBook(const char* pszBookName)
{    // GEN indexed at book 1
	int j=0;
	
	// put book name in buffer to ensure upper case
	char *pszTemp=new char[strlen(pszBookName)+1];
	_tcscpy(pszTemp, pszBookName);
	_tcsupr(pszTemp);

	for(int i=1; i<=NUM_BOOKS; i++)
		if(strcmp(ppszBookNames[i], pszTemp)==0) 
		{
			free(pszTemp);
			return i;
		}

	free(pszTemp);
	return 0;
}


typedef struct {
	TCHAR *	desc;
	BSTR *	data;
} TMarkerItem;

long CECProject::BuildConvertXML(BSTR *bstrOut)
{
	CComBSTR cbstrOut;
	BSTR bstrEncoding;

	

	cbstrOut =	_T("<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>\r\n");	// UTF-8
	cbstrOut.Append( _T("<character_conv xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n" ));
	cbstrOut.Append( _T("xsi:noNamespaceSchemaLocation=\"character_conversion.xsd\"\r\n" ));

	// ===============================
	// add the default marker map
	//
	this->get_DefaultMarkerEncoding( &bstrEncoding );
	cbstrOut.Append( _T("marker_map=\"") );
	cbstrOut.AppendBSTR( bstrEncoding );
	cbstrOut.Append( _T("\" ") );
	::SysFreeString( bstrEncoding);

	// ===============================
	// add the default data map
	//
	this->get_DefaultDataEncoding( &bstrEncoding );
	cbstrOut.Append( _T("data_map=\"") );
	cbstrOut.AppendBSTR( bstrEncoding );
	cbstrOut.Append( _T("\" ") );
	::SysFreeString( bstrEncoding);

	cbstrOut.Append( _T("inline_nesting_allowed=\"true\">\r\n\r\n") );

	// ===============================
	// add the markers
	//
	int count = this->m_dataCont->Size();
	CInternalMappingData* mappingInfo;
	char numBuf[32];

	BSTR bstrBegin, bstrEnd, bstrDataEncoding;
	BSTR bstrMarkerEncoding, bstrBefore, bstrAfter, bstrInline;
	BSTR bstrNBegin, bstrNEnd;
	
	WCHAR wcReplaceCharsOld[] = L"*";
	WCHAR wcReplaceCharsIn [] = L"+";

	TMarkerItem	markerItems[] = {	{ _T("begin")		, &bstrBegin },			// begin marker
									{ _T("end")			, &bstrEnd },			// end marker
									{ _T("data_map")	, &bstrDataEncoding },	// data teckit file
									{ _T("marker_map")	, &bstrMarkerEncoding },// marker teckit file
									{ _T("before")		, &bstrBefore },		// markers start on new line
									{ _T("after")		, &bstrAfter },			// markers require white space after
									{ _T("inline")		, &bstrInline },		// inline marker
									{ _T("new_begin")	, &bstrNBegin },		// new begin marker
									{ _T("new_end")		, &bstrNEnd },			// new end marker
	};

	int nMarkerItems = sizeof(markerItems)/sizeof(markerItems[0]);
	CComBSTR markerLine;

	for ( int i=0; i<count; i++ )
	{
		sprintf( numBuf, "%d of %d", i+1, count );

		mappingInfo = m_dataCont->at(i);
	
		// add marker number comment
		markerLine.Append( _T("<!-- marker ") );
		markerLine.Append( numBuf );
		markerLine.Append( _T(" -->\r\n") );
		markerLine.Append( _T("<marker ") );

		cbstrOut += markerLine;
		OutputDebugStringW( markerLine );
		
		markerLine = "";

		// -----------------------------
		// get the data
		bstrBegin = bstrEnd = bstrDataEncoding = bstrMarkerEncoding = 0;
		bstrBefore = bstrAfter = bstrInline = bstrNBegin = bstrNEnd = 0;	/// WAS ,

//		Error_On_Above_Line = 2;

		mappingInfo->GetBeginMarker( &bstrBegin );
		mappingInfo->GetEndMarker( &bstrEnd );
		
		mappingInfo->GetNewBeginMarker( &bstrNBegin );
		mappingInfo->GetNewEndMarker( &bstrNEnd );

		mappingInfo->GetDataEncoding( &bstrDataEncoding );
		mappingInfo->GetMarkerEncoding( &bstrMarkerEncoding );

		if ( mappingInfo->GetIsInline() )
		{
			bstrInline = ::SysAllocString( L"true" );
			bstrBefore = ::SysAllocString( L"false" );
			bstrAfter  = ::SysAllocString( L"false" );
		}
		else
		{
			bstrInline = ::SysAllocString( L"false" );
			bstrBefore = ::SysAllocString( L"true" );
			bstrAfter  = ::SysAllocString( L"true" );
		}

////		bstrBefore = ::SysAllocString( L"true" );
////		bstrAfter  = ::SysAllocString( L"true" );
		// -----------------------------


		for ( int j=0; j<nMarkerItems; j++ )
		{
			if ( ::SysStringLen( *(markerItems[j].data) ) > 0 )
			{
				markerLine.Append( markerItems[j].desc  );
				markerLine.Append( _T("=\"") );
				markerLine.Append( *(markerItems[j].data) );
				markerLine.Append( _T("\" ") );
			}
			::SysFreeString( *(markerItems[j].data) );
		}
		markerLine.Append( _T(" />\r\n\r\n") );
		OutputDebugStringW( markerLine );

		cbstrOut += markerLine;
		markerLine = "";
	}

	// Add the files
	//
	count = m_vFileInfo.size();	// InFiles.size();

	CComBSTR val;
	LONG lIndex = 0;

	for( i = 0 ; i < count; i++)
	{
		BSTR in=0, out=0;
		CInternalProjectFileInfo *idata = m_vFileInfo.at( i );

		idata->GetInputFileName( &in );
		idata->GetOutputFileName( &out );

		sprintf( numBuf, "%d of %d", i+1, count );
		markerLine.Append( _T("<!-- file ") );
		markerLine.Append( numBuf );
		markerLine.Append( _T(" -->\r\n") );

		markerLine.Append( _T("<file_set>\r\n") );
		markerLine.Append( _T("\t<input_file>") );
		markerLine.Append( in );
		markerLine.Append( _T("</input_file>\r\n") );
		markerLine.Append( _T("\t<output_file>") );
		markerLine.Append( out );
		markerLine.Append( _T("</output_file>\r\n") );
		markerLine.Append( _T("</file_set>\r\n\r\n") );

		OutputDebugStringW( markerLine );

		cbstrOut += markerLine;
		markerLine = "";
		
		::SysFreeString( in );
		::SysFreeString( out );

	}


	cbstrOut.Append( _T("</character_conv>") );
	*bstrOut = cbstrOut.Copy();

	return 0;
}

STDMETHODIMP CECProject::NthECMapping(int iIndex, IECMapping* *data)
{
	// first check to see if the index is good
	//
	int count = m_dataCont->Size();
	if ( iIndex < 0 || iIndex >= count )
		return E_INVALIDARG;

	
	// Create CECMapping object
	//
	CComObject<CECMapping> *pste;
	HRESULT hResult = CComObject<CECMapping>::CreateInstance(&pste);
	if (FAILED(hResult))
		return hResult;

	// retrieve the iIndex mapping item
	//
	CInternalMappingData *idata = m_dataCont->at( iIndex );

	// pull out the data from the item and populate the COM object
	//
	VARIANT vData;
	memset(&vData, 0, sizeof(vData) );
	vData.vt = VT_USERDEFINED;
	vData.byref = idata;

	pste->Init( &vData );
	pste->AddRef();

	*data = pste;
	
	////////////
	return S_OK;
}


STDMETHODIMP CECProject::get_AsSafeArray(/*[out,retval]*/ VARIANT* pSafeArray)	// safe array of BYTES
{
	// BEGIN
	// 3/6 test code - not related to this function
	//
	if ( 0 )
	{
		// Create CECMapping object
		CComObject<CECMapping> *pste;
		HRESULT hResult = CComObject<CECMapping>::CreateInstance(&pste);
		if (FAILED(hResult))
			return hResult;

	//	pste->AddRef();

		CInternalMappingData *idata = new CInternalMappingData();
		idata->SetBeginMarker( _T("abc") );
		idata->SetEndMarker( _T("xyz") );
		idata->SetDomain( MD_Vern );

		VARIANT vData;
		memset(&vData, 0, sizeof(vData) );
		vData.vt = VT_USERDEFINED;
		vData.byref = idata;
		
		MarkerDomain mdValue;
		pste->put_Domain( MD_Note );
		pste->Init( &vData );
		pste->get_Domain( &mdValue );

		delete idata;
	}
	//
	// END

	HRESULT hr = S_OK;

	START_BE_SAFE( CECProject::get_AsSafeArray );

	// logic to create the New Begin and New End markers [if needed]
	CPersist pstream;

	START_BE_SAFE( CECProject::get_AsSafeArray::BuildingStream  )
	
	pstream << this;

	END_BE_SAFE

	if ( HAD_EXCEPTION )
	{
		int asdf = 1234;
///		CComBSTR blob = "";
///		*archive = blob.Copy();
	}

	const int numItems = pstream.ReadOnlyBufferSize();

	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreate(VT_UI1, 1, rgsabound);

	const char *pSrc = pstream.ReadOnlyBuffer();	// CComBSTR val;
	unsigned char *pData = (unsigned char*)pSrc;
	long index = 0;

#if 0
	for( index = 0 ; index < numItems; index++, pData++)
	{
		hr  = SafeArrayPutElement(psa, &index, pData );
	}
#else
	char HUGEP *arrayData;
	hr = SafeArrayAccessData( psa, (void HUGEP* FAR*) &arrayData );
	if ( FAILED(hr) )
		return hr;

	memcpy( arrayData, pSrc, numItems );
	SafeArrayUnaccessData(psa);

#endif

	pSafeArray->vt = VT_UI1 | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;

	END_BE_SAFE

	return hr;
}

STDMETHODIMP CECProject::DeleteECMapping(IECMapping *mapping)
{
	bool removed = false;
	CInternalMappingData *idata = NULL;

	START_BE_SAFE( CECProject::DeleteECMapping )
	
	idata = ((CECMapping*)mapping)->InternalDataCopy();
	long key = idata->GetSBKey();
	removed = m_dataCont->RemoveKeyElement( key );

	END_BE_SAFE

	if ( idata )
		delete idata;

	if ( !removed )
		return E_INVALIDARG;

	return S_OK;
}

STDMETHODIMP CECProject::DeleteMarker(BSTR bstrMarker)
{
	bool removed = false;
	CInternalMappingData idata;

	START_BE_SAFE( CECProject::DeleteMarker )
	
	idata.SetBeginMarker( bstrMarker );
	long key = idata.GetSBKey();
	removed = m_dataCont->RemoveKeyElement( key );

	END_BE_SAFE

	if ( !removed )
		return E_INVALIDARG;

	return S_OK;
}

STDMETHODIMP CECProject::SetECMapping(IECMapping *mapping)
{
	CInternalMappingData *idata = NULL;
	bool success = false;
	bool okToDel = true;

	START_BE_SAFE( CECProject::SetECMapping )

	idata = ((CECMapping*)mapping)->InternalDataCopy();

	bool existingID  = m_dataCont->FindID ( idata->GetCreatorID() );
	bool existingKey = m_dataCont->FindKey( idata->GetSBKey() );

	if ( existingKey )		// Update the mapping
	{
		success = m_dataCont->Update( idata );
	}
	else					// Add the mapping
	{
		success = m_dataCont->Add( idata );		// take over ownership of the idata ptr
		okToDel = !success;						// don't allow it to be removed
	}


	END_BE_SAFE

	if ( idata && okToDel )
		delete idata;

	if ( !success )
	{
		ATLTRACE("*** ERR: Mapping Not Added\n");
	}

	return S_OK;
}

extern void ShowTestResult( long correct, long bTest, short &testNum, short &failCount );

//#import "Debug\ECObjects.dll" no_namespace 

bool CECProject::Test()
{
	return false;
	/*
	OutputDebugString("****************************************\n");
	OutputDebugString("** Begin Testing CECProject\n");

	bool passed = false;

	CInternalMappingData* chapter = new CInternalMappingData();
	CInternalMappingData* dataPtr;

	chapter->SetBeginMarker( _T("\\c") );
	chapter->SetDomain( MD_Vern );
	chapter->SetDataEncoding(_T("chapterEncoding"));

	// now do some tests
	bool bval;
	short testCnt=0;
	short failCnt=0;

///	// TEST: try to find an ID that isn't in the container
///	//
///	bval = this->FindID( verse->GetID() );
///	ShowTestResult( false, bval, testCnt, failCnt );

	this->AddMarker( "\\test1" );
	this->AddMarker( "\\test2" );

	CComObject<CECMapping> *mapObj;
	HRESULT hResult = CComObject<CECMapping>::CreateInstance(&mapObj);
//	hResult = mapObj->CreateInstance(__uuidof( ECMapping ));

	IECMappingPtr mapObj; 
	this->NthECMapping( 0, (IECMapping**)&mapObj);

	mapObj->put_IsConfirmed( 1 );
	SetECMapping( mapObj);



	AtlTrace("** Results: Tests=%d, Passed=%d\n", testCnt, testCnt-failCnt );
	OutputDebugString("**\n");
	OutputDebugString("** End Testing CECProject\n");
	OutputDebugString("****************************************\n");


	passed = (failCnt==0);
	return passed;
*/
}

#import "DataConverter.tlb" raw_interfaces_only rename_namespace("TE")	// for clarity use TE namespace

STDMETHODIMP CECProject::ConvertProject(BSTR *bstrDoneEventName)
{
	if ( m_DoneConvertEvent )
	{
		*bstrDoneEventName = ::SysAllocString( L"Conversion in progress..." );
		return E_INVALIDARG;
	}

	bool done = false;
	short count = 0;
	TCHAR ename[32];

	while ( !done )
	{
		count++;
		_stprintf( ename, _T("ECProcess_%02d"), count );
		m_DoneConvertEvent = CreateEvent( NULL, FALSE, FALSE, ename );
		
		if ( m_DoneConvertEvent )
			done = true;
	}

	BSTR defDataEnc=0, defMarkerEnc=0;
	try 
	{
		OutputDebugString("******************************************\n");

		TE::IDataConverterPtr teConverter("SIL.FieldWorks.DataConverter");

//		long nine;

		get_DefaultDataEncoding( &defDataEnc );
		get_DefaultMarkerEncoding( &defMarkerEnc );

//		teConverter->SetDefaultDataMap( "" );		// change GUI to use repository strings
//		teConverter->SetDefaultMarkerMap( "" );

		_variant_t vFileInfo, vMappingInfo;
		memset(&vFileInfo,    0, sizeof(vFileInfo) );
		memset(&vMappingInfo, 0, sizeof(vMappingInfo) );

		get_FilePropertyInfoSafeArray(&vFileInfo);
		get_MappingInfoSafeArray(&vMappingInfo);

		SAFEARRAY *psaMapping, *psaFileInfo;
		psaMapping = V_ARRAY( &vMappingInfo );
		psaFileInfo = V_ARRAY( &vFileInfo );

		// Get the safe array of Mapping objects
#if 0
		if (false)
		{
			long LBnd, UBnd;
			VARIANT vData;
			memset(&vData, 0, sizeof(vData) );
			vData.vt = VT_UNKNOWN;
			SafeArrayGetLBound(V_ARRAY(&vMappingInfo), 1, &LBnd);
			SafeArrayGetUBound(V_ARRAY(&vMappingInfo), 1, &UBnd);

			for (long li = LBnd; li <= UBnd; li++ )
			{
				SafeArrayGetElement(V_ARRAY(&vMappingInfo), &li, &vData );

				IECMapping * pste2;
				vData.punkVal->QueryInterface(__uuidof(IECMapping), (void**) &pste2 );

				BSTR beginMarker;
				pste2->get_BeginMarker(&beginMarker);
				
				::SysFreeString( beginMarker );

				ULONG refCnt = pste2->Release();		// release QuerryInterface bump
//				refCnt = vData.punkVal->Release();		// release origional ref count
			}
		}

		// Quick test of just built array
		if (false)
		{
			CComObject<CECProjectFileInfo> *pste=0;
			VARIANT vData;
			memset(&vData, 0, sizeof(vData) );
			vData.vt = VT_UNKNOWN;	// DISPATCH;	// UNKNOWN;

			long LBnd, UBnd;

			SafeArrayGetLBound(psaFileInfo, 1, &LBnd);
			SafeArrayGetUBound(psaFileInfo, 1, &UBnd);

			for (long li = LBnd; li <= UBnd; li++ )
			{
				SafeArrayGetElement(V_ARRAY( &vFileInfo ), &li, &vData );

				IECProjectFileInfo * pste2;
				vData.punkVal->QueryInterface(IID_IECProjectFileInfo, (void**) &pste2 );

				EC_FileEncoding fe;
				EC_FileEncodingSource fes;
				short percent;
				BSTR inName, outName;

				pste2->get_FileEncoding( &fe );
				pste2->get_FileEncodingSource( &fes );
				pste2->get_SurenessPercent( &percent );
				pste2->get_InputFileName( &inName );
				pste2->get_OutputFileName( &outName );
				
				::SysFreeString( inName );
				::SysFreeString( outName );

				ULONG refCnt = pste2->Release();		// release QuerryInterface bump
			}
		}
#endif

		OutputDebugString("*** Before call to TE::IDataConverterPtr::Convert\n");

		HRESULT hr = teConverter->ConvertNew( psaMapping, psaFileInfo );
		if ( hr != S_OK )
		{
			char strErrorNumber[64];
			sprintf(strErrorNumber, "HRESULT = 0x%08X", hr );
			OutputDebugString("*** Error in IDataConverterPtr\n" );
			OutputDebugString(strErrorNumber);
			return hr;
		}

		OutputDebugString("*** Done calling TE::IDataConverterPtr\n" );
		OutputDebugString("******************************************\n");


		// free up the vFileInfo safe array
		if (false)
		{
			long LBnd, UBnd;
			VARIANT vData;
			memset(&vData, 0, sizeof(vData) );
			vData.vt = VT_UNKNOWN;

			SafeArrayGetLBound(psaFileInfo, 1, &LBnd);
			SafeArrayGetUBound(psaFileInfo, 1, &UBnd);

//			CECProjectFileInfo * fi;
			for (long li = LBnd; li <= UBnd; li++ )
			{
				SafeArrayGetElement(psaFileInfo, &li, &vData );

				CECProjectFileInfo * pste2;
				vData.punkVal->QueryInterface(__uuidof(IECProjectFileInfo), (void**) &pste2 );

				EC_FileEncoding fe;
				pste2->get_FileEncoding(&fe);
				EC_FileEncodingSource fes;
				pste2->get_FileEncodingSource(&fes);
//				short percent = pste2->GetSurenessPercent();
//				BSTR inName = pste2->GetInputFileName();
//				BSTR outName = pste2->GetOutputFileName();
//				
//				::SysFreeString( inName );
//				::SysFreeString( outName );

				ULONG refCnt = pste2->Release();		// release QuerryInterface bump
				refCnt = vData.punkVal->Release();		// release origional ref count
			}
		}


		
		//		SafeArrayDestroy(psaFileInfo);
//		SafeArrayDestroy(psaMapping);
	}
	catch(...)
	{
		OutputDebugString("*$*$*$*$*$*$*$*$*$$*$*\n*\n");
		OutputDebugString("*$  Exception raised in DataConverter.\n*\n" );
		OutputDebugString("*$*$*$*$*$*$*$*$*$$*$*\n");
		throw;
	}

	if ( defDataEnc )	::SysFreeString( defDataEnc );
	if ( defMarkerEnc )	::SysFreeString( defMarkerEnc );


	CComBSTR cbstrName = ename;
	*bstrDoneEventName = cbstrName.Copy();

#if 0
	BSTR bstrConvCtrlFile = 0;
	this->BuildConvertXML( &bstrConvCtrlFile );

	int len = ::SysStringLen(bstrConvCtrlFile)*2;
	char *asciiFileContents = new char[len];
	::WideCharToMultiByte( CP_ACP, 0, bstrConvCtrlFile, ::SysStringLen(bstrConvCtrlFile)+1, asciiFileContents, len, "*", 0 );
	::SysFreeString( bstrConvCtrlFile );

	// make sure that the binary path ends with a directory marker '\'
	//
	WCHAR end[] = {L"\\"};
	CComBSTR binPath = m_cbstrBinDir;
	len = binPath.Length();
	if ( binPath[len-1] != end[0] )
		binPath.Append(end);

	// put the control file in the binary directory for now - for completnes
	//
	CComBSTR controlFileName;
	controlFileName = binPath;
	controlFileName.Append( L"ECGenerated_ControlFile001" );

	OutputDebugString("*** Temporary control file: <");
	OutputDebugStringW( controlFileName );
	OutputDebugString(">\n");

	bool success = false;

///	if ( tmpName )
	if ( controlFileName )
	{
		HANDLE hFile; 

		hFile = CreateFileW( controlFileName.m_str,	// tmpName,
							GENERIC_WRITE,                // open for writing 
							0,                            // do not share 
							NULL,                         // no security 
							CREATE_ALWAYS,                // overwrite existing 
							FILE_ATTRIBUTE_NORMAL |       // normal file 
							0, 
							NULL);                        // no attr. template 

		if (hFile != INVALID_HANDLE_VALUE) 
		{
			DWORD numBytesWritten;
			WriteFile( hFile, asciiFileContents, strlen(asciiFileContents), &numBytesWritten, NULL );
			CloseHandle( hFile );
			if ( asciiFileContents )
			{
				delete [] asciiFileContents;
				asciiFileContents = 0;
			}

			{
				STARTUPINFO si;
				PROCESS_INFORMATION pi;

				ZeroMemory( &si, sizeof(si) );
				ZeroMemory( &pi, sizeof(pi) );
				si.cb = sizeof(si);

				CComBSTR commandLine;
				commandLine = binPath;
				commandLine += L"python.exe -d ";		// debug ?? <L"python.exe -d ";>
				
				if ( false )		// force the console window to stay up until user closes it
					commandLine += L" -i ";
				
				commandLine += m_cbstrRootDir;	// binPath;
				commandLine += L"conversion.py -c ";	// for debugging <L"conversion.py -c ">
				commandLine += controlFileName;

				OutputDebugString("*** Command Line: <");
				OutputDebugStringW(commandLine);
				OutputDebugString(">\n");

// data file giving problems
// 	<input_file>C:\Documents and Settings\hinton\My Documents\field Data ERASE\Djimini\ji-exo.sfc</input_file>


				len = ::SysStringLen(commandLine)*2;
				char *cptrCmdLine = new char[len];
				::WideCharToMultiByte( CP_ACP, 0, commandLine, ::SysStringLen(commandLine)+1, cptrCmdLine, len, "*", 0 );

				// python.exe conversion.py -c character_conversion.xml
				BOOL pCreated;
				pCreated = CreateProcess(	NULL,		// No module name (use command line). 
											cptrCmdLine,		// Command line. 
//											cmdLine,		// Command line. 
											NULL,		// Process handle not inheritable. 
											NULL,		// Thread handle not inheritable. 
											FALSE,		// Set handle inheritance to FALSE. 
											0,			// No creation flags. 
											NULL,		// Use parent's environment block. 
											NULL,		// Use parent's starting directory. 
											&si,		// Pointer to STARTUPINFO structure.
											&pi );		// Pointer to PROCESS_INFORMATION structure.

				delete [] cptrCmdLine;

				if ( pCreated )
				{
					OutputDebugString("*** Process was created.\n");
					
					// wait for the python process to finish
					WaitForSingleObject( pi.hProcess, INFINITE );
	
					// close process and thread handles. 
					CloseHandle( pi.hProcess );
					CloseHandle( pi.hThread );
				}
				else
					OutputDebugString("*** Unable to create Process.\n");
			}

///			DeleteFile( tmpName );
		}
	
	}

///	if ( tmpName )
///		free( tmpName );


#endif

	SetEvent( m_DoneConvertEvent );
	CloseHandle( m_DoneConvertEvent );
	m_DoneConvertEvent = 0;

	return S_OK;
}


#if 0
void main( VOID )
{
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    ZeroMemory( &si, sizeof(si) );
    si.cb = sizeof(si);
    ZeroMemory( &pi, sizeof(pi) );

    // Start the child process. 
    if( !CreateProcess( NULL, // No module name (use command line). 
        "MyChildProcess", // Command line. 
        NULL,             // Process handle not inheritable. 
        NULL,             // Thread handle not inheritable. 
        FALSE,            // Set handle inheritance to FALSE. 
        0,                // No creation flags. 
        NULL,             // Use parent's environment block. 
        NULL,             // Use parent's starting directory. 
        &si,              // Pointer to STARTUPINFO structure.
        &pi )             // Pointer to PROCESS_INFORMATION structure.
    ) 
    {
        ErrorExit( "CreateProcess failed." );
    }

    // Wait until child process exits.
    WaitForSingleObject( pi.hProcess, INFINITE );

    // Close process and thread handles. 
    CloseHandle( pi.hProcess );
    CloseHandle( pi.hThread );
}
#endif


BSTR* CECProject::GetTEStyleFromBeginMarker(char *beginMarker)
{
	return NULL;
}


/*
STDMETHODIMP CECProject::ReadTEStyleFile(BSTR styFileName)
{
	long numStyles;

	if ( m_ECLibrary )
		m_ECLibrary->ReadInTEStyleNames( styFileName, &numStyles );

	return S_OK;
}
*/


STDMETHODIMP CECProject::BuildSOProjectFiles()	// BSTR bstrSSFPathName, BSTR bstrSTYPathName)
{
	// create the .STY file
	// iterate over the mappingdatacontainer
	//	for each begin marker retrieve the so properties
	//		put out the beging marker
	//		put out the testyle marker
	//		put out the so data with end line
	//
	// This method requires that the output files have been created/exist.  This is done
	// by calling the convert method(s)
	//

	if ( !m_ECLibrary )
		return E_UNEXPECTED;		// if the lib object doesn't exist there are other problems...

	CComBSTR cbstrBookMarker=L"", cbstrChapterMarker=L"", cbstrVerseMarker=L"";
	CComBSTR cbstrTEChapterStyle = L"Chapter Number";
	CComBSTR cbstrTEVerseStyle = L"Verse Number";

	FILE * fp = NULL;

	time_t tim = time(0);
	char * pszTime = ctime(&tim);
	char * psz = strchr(pszTime, '\n');
	*psz = 0;

	HRESULT hrRet = S_OK;	// success
	{
	START_BE_SAFE( CECProject::BuildSOProjectFiles )

	fp = _wfopen( m_cbstrSTYName, L"wb");
	if (!fp)
	{
		ATLTRACE("**** Error: Unable to open .sty File\n");
		return E_INVALIDARG;
	}

	fprintf(fp, "# Generated Stylesheet by ECProject, %s\r\n\r\n", pszTime );

	WCHAR *wcptr;
	WCHAR wcTextProperties[] = {L"\\TextProperties "};
	WCHAR wcBook[]    = {L"book"};
	WCHAR wcChapter[] = {L"chapter"};
	WCHAR wcVerse[]   = {L"verse"};

	long numItems = m_dataCont->Size();
	HRESULT hrDupsFound = 0;	// none to start with
	for ( long index = 0; index < numItems; index++ )
	{
		CInternalMappingData* mappingData;
		mappingData = m_dataCont->at( index );

		BSTR bstrBeginMarker, bstrTEStyleName;
		mappingData->GetBeginMarker( &bstrBeginMarker );
		mappingData->GetStyleName( &bstrTEStyleName );

		// Get the properties for the TEStyle.
		// *** NOTE: if the TEStyle is duplicated with other markers, only a single 
		// copy of those properties is mapted to the TEStyle.  So, it's possible in
		// the .sty file to have different properties defined for the same TEStyle,
		// but that won't actually be the case when the data is used.  *** NOTE end
		BSTR bstrSOFields;
		m_ECLibrary->get_SOMarkerFields( bstrTEStyleName, &bstrSOFields );

		// find theTextProperties line
		wcptr = wcsstr(bstrSOFields, wcTextProperties);
		if (wcptr)
		{
			wcptr += wcslen(wcTextProperties);
			// tokenize the line and look for the key fields: book, chapter, verse
			WCHAR *token = wcstok(wcptr, L" ");
			while( token != NULL )
			{
				if (wcsstr(token, wcBook))
				{
					if (cbstrBookMarker.Length() == 0)		// not assigned a value yet
						cbstrBookMarker = bstrBeginMarker;
					else
					{	// build a list of offending markers
						cbstrBookMarker.Append(L" ");
						cbstrBookMarker.AppendBSTR(bstrBeginMarker);
						hrDupsFound |= ECERROR_DupBookMarker;
					}
				}
				else if (wcsstr(token, wcChapter))
				{
					if (cbstrChapterMarker.Length() == 0)		// not assigned a value yet
						cbstrChapterMarker = bstrBeginMarker;
					else
					{	// build a list of offending markers
						cbstrChapterMarker.Append(L" ");
						cbstrChapterMarker.AppendBSTR(bstrBeginMarker);
						hrDupsFound |= ECERROR_DupChapterMarker;
					}
				}
				else if (wcsstr(token, wcVerse))
				{
					if (cbstrVerseMarker.Length() == 0)		// not assigned a value yet
						cbstrVerseMarker = bstrBeginMarker;
					else
					{	// build a list of offending markers
						cbstrVerseMarker.Append(L" ");
						cbstrVerseMarker.AppendBSTR(bstrBeginMarker);
						hrDupsFound |= ECERROR_DupVerseMarker;
					}
				}
				// go to the next one, just incase dup key ones on same line
				WCHAR *nextToken = wcstok(NULL, L" ");
//				token = wcstok(NULL, L" ");
				if (nextToken)
				{
					token += wcslen(token);		// replace inserted NULL character
					*token = ' ';
				}
				token = nextToken;
			}
		}

		// final data to be put out in the created .sty file
		CComBSTR finalData;

		wcptr = bstrBeginMarker;
		if ( wcptr[0] == '\\' )
			wcptr++;

		finalData.Append( L"\\Marker " );
		finalData.Append( wcptr );

		::SysFreeString( bstrBeginMarker );
		
		// if inline, add the end marker
		if ( mappingData->GetIsInline() )
		{
			BSTR bstrEndMarker;
			mappingData->GetEndMarker( &bstrEndMarker );
			wcptr = bstrEndMarker;
			if ( wcptr[0] == '\\' )
				wcptr++;

			finalData.Append( L"\r\n\\EndMarker ");
			finalData.Append( wcptr );

			::SysFreeString( bstrEndMarker );
		}

		finalData.Append( L"\r\n\\TEStyleName ");
		finalData.AppendBSTR( bstrTEStyleName );
		::SysFreeString( bstrTEStyleName ); //tccp 2 July 2003
		finalData.Append( L"\r\n");
		finalData.AppendBSTR( bstrSOFields );
		::SysFreeString( bstrSOFields ); //tccp 2 July 2003
		finalData.Append( L"\r\n\r\n");

		unsigned int bufferSize = ::WideCharToMultiByte( CP_UTF8, 0,
			finalData.m_str, finalData.Length(), NULL, 0, 0, 0 ) + 1;
		char * pszFinalData = (char*)malloc( bufferSize );
		if (!pszFinalData)
		{
			fclose(fp);
			return E_OUTOFMEMORY;
		}
		::WideCharToMultiByte( CP_UTF8, 0,
			finalData.m_str, finalData.Length(), pszFinalData, bufferSize, 0, 0 );

		pszFinalData[bufferSize-1] = 0;

		// write it to the file.. and continue
		fputs(pszFinalData, fp);

		free( pszFinalData );
		pszFinalData = 0;
	}

	if (hrDupsFound != 0)	// error in processing key markers
	{
		hrRet = hrDupsFound;	// save hresult value
		CComBSTR cbstrErrorMsg = L"Duplicate key Markers: ";
		if ((hrDupsFound & ECERROR_DupBookMarker) == ECERROR_DupBookMarker)
		{
			cbstrErrorMsg.Append(L"Book<");
			cbstrErrorMsg += cbstrBookMarker;
			cbstrErrorMsg.Append(L">");
		}
		if ((hrDupsFound & ECERROR_DupChapterMarker) == ECERROR_DupChapterMarker)
		{
			cbstrErrorMsg.Append(L"Chapter<");
			cbstrErrorMsg += cbstrChapterMarker;
			cbstrErrorMsg.Append(L">");
		}
		if ((hrDupsFound & ECERROR_DupVerseMarker) == ECERROR_DupVerseMarker)
		{
			cbstrErrorMsg.Append(L"Verse<");
			cbstrErrorMsg += cbstrVerseMarker;
			cbstrErrorMsg.Append(L">");
		}
		throw Error((BSTR)(cbstrErrorMsg), IID_IECProject, hrRet);
	}

	END_BE_SAFE
	}

	if (fp)
	{
		fclose(fp);
		fp = NULL;
	}

	if (hrRet != S_OK)
		return hrRet;	// don't continue if already had an error

	if ( cbstrBookMarker.Length() == 0)
	{
		cbstrBookMarker = L"_NotUsed_";	// default to this.
	}
	else
	{
		// reset the book marker member to be the 'actual' marker being used
		// up until this point, the BookMarker member has just been a guess.
		m_cbstrBookMarker = cbstrBookMarker;
	}

	if ( cbstrChapterMarker.Length() == 0)
		cbstrChapterMarker = L"_NotUsed_";		// default to this.

	if ( cbstrVerseMarker.Length() == 0)
		cbstrVerseMarker = L"_NotUsed_";		// default to this.

	if ( cbstrBookMarker.Length() == 0 ||
		cbstrChapterMarker.Length() == 0 ||
		cbstrVerseMarker.Length() == 0)
	{
		ATLTRACE("**** Error: Undefined book, chapter and/or verse marker(s).\n" );
		return E_UNEXPECTED;
	}

	START_BE_SAFE( CECProject::BuildSOProjectFiles2 )

	fp = _wfopen( m_cbstrSSFName, L"wb");

	if (!fp)
		return E_INVALIDARG;

	fprintf(fp, "<!-- Generated SSF by ECProject, %s -->\r\n", pszTime );
	fprintf(fp, "<ScriptureText>\r\n"
				"<BooksPresent>0</BooksPresent>\r\n"
				"<Encoding>%d</Encoding>\r\n"
				"<ExtDataSource>Unknown, or a future Task</ExtDataSource>\r\n"
				"<Versification>4</Versification><!-- ? -->\r\n"
				, CP_UTF8
				);

	fprintf(fp, "<EatEscapeBackslashes>T</EatEscapeBackslashes>\r\n");	// for TE processing

	// Write out the defined markers, minus the leading \ (or whatever).

	char* pszMarker = ECUtil::WideToMultiByte( cbstrBookMarker.m_str );
	if ( pszMarker )
	{
		fprintf(fp, "<BookMarker>%s</BookMarker>\r\n", pszMarker + 1);
		free( pszMarker );
	}

	pszMarker = ECUtil::WideToMultiByte( cbstrChapterMarker.m_str );
	if ( pszMarker )
	{
		fprintf(fp, "<ChapterMarker>%s</ChapterMarker>\r\n", pszMarker + 1);
		free( pszMarker );
	}

	pszMarker = ECUtil::WideToMultiByte( cbstrVerseMarker.m_str );
	if ( pszMarker )
	{
		fprintf(fp, "<VerseMarker>%s</VerseMarker>\r\n", pszMarker + 1 );
		free( pszMarker );
	}

	char *pszSTYFileName = ECUtil::WideToMultiByte( m_cbstrSTYName );
	if ( pszSTYFileName )
	{
		fprintf(fp, "<StyleSheet>%s</StyleSheet>\r\n", pszSTYFileName );
		free(pszSTYFileName); 
	}

	// now put out the ExtFileInfo element(s)
	for ( TVectorITFileInfo fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++ )
	{
		CInternalProjectFileInfo* fi = (*fiIT);	// get a pointer to the object
		BSTR outName=0, bstrRealName=0;
		fi->GetOutputFileName( &outName );
		fi->GetInputFileName( &bstrRealName );

		BSTR bstrStartRef, bstrEndRef;
		HRESULT hr = m_ECLibrary->GetScriptureRefBounds2( outName, bstrRealName, cbstrBookMarker, 
				cbstrChapterMarker, cbstrVerseMarker, &bstrStartRef, &bstrEndRef);

		if ( hr != S_OK )
		{
			HRESULT hrTemp;
			ISupportErrorInfoPtr qsei;
			IErrorInfoPtr qei;

			hrTemp = m_ECLibrary->QueryInterface(IID_ISupportErrorInfo, (void **)&qsei);
			if (SUCCEEDED(hrTemp) && qsei->InterfaceSupportsErrorInfo(IID_IECLibrary) == S_OK)
			{
				hrTemp = GetErrorInfo(0, &qei);
				if (hrTemp != S_FALSE)
				{
					BSTR bstr;
					hrTemp = qei->GetDescription(&bstr);
					Error(bstr, IID_IECProject, hr);
					::SysFreeString(bstr);
					::SysFreeString(outName);
					::SysFreeString(bstrRealName);

					SetErrorInfo(0, qei);
//					ThrowHr(hr, NULL, -1);
				}
			}

			char strErrorNumber[64];
			sprintf(strErrorNumber, "ERROR(0x%0X)", hr );
			OutputDebugString(strErrorNumber);
			OutputDebugString(": unable to get ref info from input file <");
			OutputDebugStringW(outName);
			OutputDebugString(">\n");

			::SysFreeString( outName );
			::SysFreeString( bstrRealName );

			if (fp)
			{
				fclose(fp);
				fp = NULL;
			}

			return hr;
		}
		char * pszStart = ECUtil::WideToMultiByte( bstrStartRef );
		char * pszEnd = ECUtil::WideToMultiByte( bstrEndRef  );
		char * pszFile = ECUtil::WideToMultiByte( outName );

		if (pszStart && pszEnd && pszFile)
			fprintf(fp, "<ExtFileInfo FirstRef=\"%s\" LastRef=\"%s\" File=\"%s\"></ExtFileInfo>\r\n",
			pszStart, pszEnd, pszFile);

		::SysFreeString(outName);
		::SysFreeString(bstrStartRef);
		::SysFreeString(bstrEndRef);
		if (pszStart)
			free(pszStart);
		if (pszEnd)
			free(pszEnd);
		if (pszFile)
			free(pszFile);
	}

	fprintf(fp, "</ScriptureText>\r\n");

	END_BE_SAFE

	if (fp)
	{
		fclose(fp);
		fp = NULL;
	}

///	if ( pszTime ) 
///	{
///		free( pszTime );
///		pszTime = 0;
///	}

	if ( HAD_EXCEPTION )
	{
		int asdf = 1234;
		OutputDebugString("*** Error int CECProject::BuildSOProjectFiles()\n");
		return E_FAIL;
	}


	return hrRet;
}



STDMETHODIMP CECProject::ValidateSafeArray(VARIANT pSafeArrayOfBytes, BOOL *isValid)
{
	*isValid = false;

	START_BE_SAFE( CECProject::ValidateSafeArray )

	long LBnd, UBnd;
	SafeArrayGetLBound(V_ARRAY(&pSafeArrayOfBytes), 1, &LBnd);
	SafeArrayGetUBound(V_ARRAY(&pSafeArrayOfBytes), 1, &UBnd);

	long lsize = UBnd-LBnd+1;
	char *data = new char[lsize];
	unsigned char *pData = (unsigned char*)data;
	for (long li = LBnd; li <= UBnd; li++, pData++ )
	{
		SafeArrayGetElement(V_ARRAY(&pSafeArrayOfBytes), &li, pData );
	}

	CPersist persist(data, lsize );
	delete [] data;

	if ( !persist.HasError() )
	{
		ATLTRACE("**** Good archive, now make sure it's an ECProject. ***\n");

		char* desc=0;
		
		persist >> &desc;		// pull out the object description
	
		if ( desc && !strcmp( desc, "ECProject" ) )
		{
			*isValid = true;
			ATLTRACE(" --- CECProject blob *IS* Valid. ---\n");
		}
		else
		{
			ATLTRACE(" --- CECProject blob not Valid. ---\n");
		}

		if ( desc )
			delete [] desc;

	}
	
	END_BE_SAFE

	return S_OK;
}


/******************************************************************
 * get_DefaultSSFFileName
 * 
 * This method returns the value to use for the SSF file name.
 ******************************************************************/
STDMETHODIMP CECProject::get_DefaultSSFFileName(BSTR *pVal)
{
	*pVal = m_cbstrSSFName.Copy();
	return S_OK;
}


/******************************************************************
 * put_DefaultSSFFileName
 * 
 * This method is used to set the SSF file name to a user specified
 * value.  If this is not done, then the name will be a generated
 * file name.
 ******************************************************************/
STDMETHODIMP CECProject::put_DefaultSSFFileName(BSTR newVal)
{
	m_cbstrUserSSFName = newVal;

	if (::SysStringLen(newVal) <= 0 )	// no data
		m_cbstrSSFName = m_cbstrTempSSFName;	// use the generated value
	else
		m_cbstrSSFName = m_cbstrUserSSFName;

	return S_OK;
}


/******************************************************************
 * get_DefaultSTYFileName
 * 
 * This method returns the value to use for the STY file name.
 ******************************************************************/
STDMETHODIMP CECProject::get_DefaultSTYFileName(BSTR *pVal)
{
	*pVal = m_cbstrSTYName.Copy();
	return S_OK;
}


/******************************************************************
 * put_DefaultSTYFileName
 * 
 * This method is used to set the STY file name to a user specified
 * value.  If this is not done, then the name will be a generated
 * file name.
 ******************************************************************/
STDMETHODIMP CECProject::put_DefaultSTYFileName(BSTR newVal)
{
	m_cbstrUserSTYName = newVal;

	if (::SysStringLen(newVal) <= 0 )	// no data
		m_cbstrSTYName = m_cbstrTempSTYName;	// use the generated value
	else
		m_cbstrSTYName = m_cbstrUserSTYName;

	return S_OK;
}


/******************************************************************
 ******************************************************************/

/******************************************************************
 * IsFileAccessible
 * 
 * Return true if the passed in file name exists and is writeable.
 ******************************************************************/
STDMETHODIMP CECProject::IsFileAccessible(BSTR bstrFileName, BOOL *isAccessible)
{
	*isAccessible = false;
	try
	{
		if (( ::_waccess( bstrFileName, 0 ) != -1 ) &&
			( ::_waccess( bstrFileName, 4 ) != -1 ))
		{
			*isAccessible = true;
		}
	}
	catch(...)
	{
	}
	return S_OK;
}

STDMETHODIMP CECProject::get_DefaultVernWritingSystem(BSTR *pVal)
{
	*pVal = m_cbstrDefaultVernWritingSystem.Copy();
	return S_OK;
}

STDMETHODIMP CECProject::put_DefaultVernWritingSystem(BSTR newVal)
{
	m_cbstrDefaultVernWritingSystem = newVal;
	return S_OK;
}

STDMETHODIMP CECProject::get_DefaultAnalWritingSystem(BSTR *pVal)
{
	*pVal = m_cbstrDefaultAnalWritingSystem.Copy();
	return S_OK;
}

STDMETHODIMP CECProject::put_DefaultAnalWritingSystem(BSTR newVal)
{
	m_cbstrDefaultAnalWritingSystem = newVal;
	return S_OK;
}


STDMETHODIMP CECProject::UpdateFileEncoding(BSTR fileName, EC_FileEncoding fileEC)
{
	bool found = false;

	START_BE_SAFE( CECProject::UpdateFileEncoding );

	for ( TVectorITFileInfo fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++ )
	{
		CInternalProjectFileInfo* fi = (*fiIT);		// get the object
		if ( fi->SameInputFileName( fileName ) )
		{
			found = true;
			fi->SetFileEncoding( fileEC, 77 );		// user set
			break;
		}
	}

	END_BE_SAFE

	if ( found )
		return S_OK;

	return E_INVALIDARG;
}


#if 0
STDMETHODIMP CECProject::get_FilePropertyInfoSafeArray(VARIANT *pSafeArray)
{
	HRESULT hr = S_OK;

	START_BE_SAFE( CECProject::get_FilePropertyInfoSafeArray );

	const int numItems = m_vFileInfo.size();

	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreate(VT_VARIANT, 1, rgsabound);

	CComBSTR val;
	LONG lIndex = 0;

	// Fill the safe array with the file info objects
	//
	for( lIndex = 0 ; lIndex < numItems ;lIndex++)
	{
		CComObject<CECProjectFileInfo> *pste;
		HRESULT hResult = CComObject<CECProjectFileInfo>::CreateInstance(&pste);
		if (FAILED(hResult))
			return hResult;

		// retrieve the iIndex File Info data item
		//
		CInternalProjectFileInfo *idata = m_vFileInfo.at( lIndex );

		// pull out the data from the item and populate the COM object
		//
		VARIANT vMyData;
		memset(&vMyData, 0, sizeof(vMyData) );
		vMyData.vt = VT_USERDEFINED;
		vMyData.byref = idata;
		pste->Init( &vMyData );

		// now build the variant type and put in the safe array
		//
		VARIANT vData;
		memset(&vData, 0, sizeof(vData) );
		vData.vt = VT_UNKNOWN;
		pste->QueryInterface(IID_IUnknown, (void **) &(vData.punkVal));

		hr  = SafeArrayPutElement(psa, &lIndex, &vData);

		pste->Release();	// decrement the bump from the QueryInterface
	}

	pSafeArray->vt = VT_VARIANT | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;


/*
	// Quick test of just built array
	{
		CComObject<CECProjectFileInfo> *pste=0;
		VARIANT vData;
		memset(&vData, 0, sizeof(vData) );
		vData.vt = VT_UNKNOWN;	// DISPATCH;	// UNKNOWN;

		long LBnd, UBnd;

		SafeArrayGetLBound(psa, 1, &LBnd);
		SafeArrayGetUBound(psa, 1, &UBnd);

		for (long li = LBnd; li <= UBnd; li++ )
		{
			SafeArrayGetElement(psa, &li, &vData );

			IECProjectFileInfo * pste2;
			vData.punkVal->QueryInterface(IID_IECProjectFileInfo, (void**) &pste2 );

			EC_FileEncoding fe;
			EC_FileEncodingSource fes;
			short percent;
			BSTR inName, outName;

			pste2->get_FileEncoding( &fe );
			pste2->get_FileEncodingSource( &fes );
			pste2->get_SurenessPercent( &percent );
			pste2->get_InputFileName( &inName );
			pste2->get_OutputFileName( &outName );
			
			::SysFreeString( inName );
			::SysFreeString( outName );
		}

	}


*/

	END_BE_SAFE

	return hr;
}
#endif

/*
STDMETHODIMP CECProject::get_MappingInfoSafeArray(VARIANT *pSafeArray)
{
	HRESULT hr = S_OK;

	START_BE_SAFE( CECProject::get_MappingInfoSafeArray );

	const int numItems = m_dataCont->Size();

	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreate(VT_VARIANT, 1, rgsabound);

	// Fill the safe array with the file info objects
	//
	for( long lIndex = 0 ; lIndex < numItems; lIndex++ )
	{
		CComObject<CECMapping> *pste;
		HRESULT hResult = CComObject<CECMapping>::CreateInstance(&pste);
		if (FAILED(hResult))
			return hResult;

		CInternalMappingData *idata = m_dataCont->at( lIndex );

		// pull out the data from the item and populate the COM object
		//
		VARIANT vMyData;
		memset(&vMyData, 0, sizeof(vMyData) );
		vMyData.vt = VT_USERDEFINED;
		vMyData.byref = idata;
		pste->Init( &vMyData );

		// now build the variant type and put in the safe array
		//
		VARIANT vData;
		memset(&vData, 0, sizeof(vData) );
		vData.vt = VT_UNKNOWN;
		pste->QueryInterface(IID_IUnknown, (void **) &(vData.punkVal));

		hr  = SafeArrayPutElement(psa, &lIndex, &vData);

		pste->Release();	// decrement the bump from the QueryInterface
	}

	pSafeArray->vt = VT_VARIANT | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;

	END_BE_SAFE

	return hr;
}
*/

STDMETHODIMP CECProject::get_MappingInfoSafeArray(VARIANT *pSafeArray)
{
	HRESULT hr = S_OK;

	START_BE_SAFE( CECProject::get_MappingInfoSafeArray );

	const int numItems = m_dataCont->Size();

	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreateEx(VT_UNKNOWN, 1, rgsabound, (void*)&__uuidof(TE::IDCMapping));

	// Fill the safe array with the mapping objects
	//
	for( long lIndex = 0 ; lIndex < numItems; lIndex++ )
	{
//		CComObject<CECMapping> *pste;
//		HRESULT hResult = CComObject<CECMapping>::CreateInstance(&pste);
//		if (FAILED(hResult))
//			return hResult;
		TE::IDCMappingPtr pste("DCMapping");

		CInternalMappingData * idata = m_dataCont->at( lIndex );

		// pull out the data from the item and populate the COM object
		//
//		VARIANT vMyData;
//		memset(&vMyData, 0, sizeof(vMyData) );
//		vMyData.vt = VT_USERDEFINED;
//		vMyData.byref = idata;
//		pste->Init( &vMyData );

		CComBSTR sbstrBegin;
		idata->GetBeginMarker(&sbstrBegin);
		CComBSTR sbstrEnd;
		idata->GetEndMarker(&sbstrEnd);
		CComBSTR sbstrNewBegin;
		idata->GetNewBeginMarker(&sbstrNewBegin);
		CComBSTR sbstrNewEnd;
		idata->GetNewEndMarker(&sbstrNewEnd);
		CComBSTR sbstrMarkerEnc;
		idata->GetMarkerEncoding(&sbstrMarkerEnc);
		CComBSTR sbstrDataEnc;
		idata->GetDataEncoding(&sbstrDataEnc);
		MarkerDomain md = idata->GetDomain();

		VARIANT_BOOL fIsInline = idata->GetIsInline();

		hr = pste->put_BeginMarker(sbstrBegin);
		hr = pste->put_EndMarker(sbstrEnd);
		hr = pste->put_NewBeginMarker(sbstrNewBegin);
		hr = pste->put_NewEndMarker(sbstrNewEnd);
		hr = pste->put_MarkerEncoding(sbstrMarkerEnc);
		hr = pste->put_DataEncoding(sbstrDataEnc);
		hr = pste->put_Domain(md);
		hr = pste->put_IsInline(fIsInline);

		// now build the variant type and put in the safe array
		//
//		hr  = SafeArrayPutElement(psa, &lIndex, static_cast<IECMapping *>(pste));
		hr  = SafeArrayPutElement(psa, &lIndex, pste);
	}

	pSafeArray->vt = VT_UNKNOWN | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;

	END_BE_SAFE

	return hr;
}


STDMETHODIMP CECProject::get_FilePropertyInfoSafeArray(VARIANT *pSafeArray)
{
	HRESULT hr = S_OK;

	START_BE_SAFE( CECProject::get_FilePropertyInfoSafeArray );

	const int numItems = m_vFileInfo.size();

	SAFEARRAY FAR* psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = numItems;
	psa = SafeArrayCreateEx(VT_UNKNOWN, 1, rgsabound, (void*)&__uuidof(TE::IDCFileInfo));

	CComBSTR val;
	LONG lIndex = 0;

	// Fill the safe array with the file info objects
	//
	for( lIndex = 0 ; lIndex < numItems ;lIndex++)
	{
//		CComObject<CECProjectFileInfo> *pste;
//		HRESULT hResult = CComObject<CECProjectFileInfo>::CreateInstance(&pste);
//		if (FAILED(hResult))
//			return hResult;
		TE::IDCFileInfoPtr pste("DCFileInfo");

		// retrieve the iIndex File Info data item
		//
		CInternalProjectFileInfo * idata = m_vFileInfo.at( lIndex );

#ifdef _DEBUG
		ATLTRACE(" --- FileInfo<%2d>: In<", lIndex );
		BSTR bstrFile;
		idata->GetInputFileName(&bstrFile);
		OutputDebugStringW(bstrFile);
		::SysFreeString( bstrFile );
        ATLTRACE( "> Out<" );
		idata->GetOutputFileName(&bstrFile);
		OutputDebugStringW(bstrFile);
		::SysFreeString( bstrFile );
		ATLTRACE( ">\n" );
#endif

		// pull out the data from the item and populate the COM object
		//
//		VARIANT vMyData;
//		memset(&vMyData, 0, sizeof(vMyData) );
//		vMyData.vt = VT_USERDEFINED;
//		vMyData.byref = idata;
//		pste->Init( &vMyData );

		TE::DCFileEncoding dfe;
		switch (idata->GetFileEncoding())
		{
		case FE_BYTES:		dfe = TE::DCFileEncoding_DC_FE_BYTES;		break;
		case FE_UTF8:		dfe = TE::DCFileEncoding_DC_FE_UTF8;		break;
		case FE_UTF16BE:	dfe = TE::DCFileEncoding_DC_FE_UTF16BE;		break;
		case FE_UTF16LE:	dfe = TE::DCFileEncoding_DC_FE_UTF16LE;		break;
		case FE_UTF32BE:	dfe = TE::DCFileEncoding_DC_FE_UTF32BE;		break;
		case FE_UTF32LE:	dfe = TE::DCFileEncoding_DC_FE_UTF32LE;		break;
		default:			dfe = TE::DCFileEncoding_DC_FE_Unknown;		break;
		}
		CComBSTR sbstrInput;
		idata->GetInputFileName(&sbstrInput);
		CComBSTR sbstrOutput;
		idata->GetOutputFileName(&sbstrOutput);
		VARIANT_BOOL fHasBOM = idata->HasBOM() ? TRUE : FALSE;

		hr = pste->put_InputFileName(sbstrInput.m_str);
		hr = pste->put_OutputFileName(sbstrOutput.m_str);
		hr = pste->put_HasBOM(fHasBOM);
		hr = pste->put_FileEncoding(dfe);

		// now build the variant type and put in the safe array
		//
//		VARIANT vData;
//		memset(&vData, 0, sizeof(vData) );
//		vData.vt = VT_UNKNOWN;
//		pste->QueryInterface(IID_IUnknown, (void **) &(vData.punkVal));

//		hr  = SafeArrayPutElement(psa, &lIndex, static_cast<IECProjectFileInfo *>(pste));
		hr  = SafeArrayPutElement(psa, &lIndex, pste);

//		pste->Release();	// decrement the bump from the QueryInterface
	}

	pSafeArray->vt = VT_UNKNOWN | VT_ARRAY;
	V_ARRAY(pSafeArray) = psa;


#if 0
	// Quick test of just built array
	{
		CComObject<CECProjectFileInfo> *pste=0;
		VARIANT vData;
		memset(&vData, 0, sizeof(vData) );
		vData.vt = VT_UNKNOWN;	// DISPATCH;	// UNKNOWN;

		long LBnd, UBnd;
		HRESULT hResult;
		SafeArrayGetLBound(psa, 1, &LBnd);
		SafeArrayGetUBound(psa, 1, &UBnd);

		for (long li = LBnd; li <= UBnd; li++ )
		{
			hResult = SafeArrayGetElement(psa, &li, &vData );

			IECProjectFileInfo * pste2;
			vData.punkVal->QueryInterface(IID_IECProjectFileInfo, (void**) &pste2 );

			EC_FileEncoding fe;
			EC_FileEncodingSource fes;
			short percent;
			BSTR inName, outName;

			pste2->get_FileEncoding( &fe );
			pste2->get_FileEncodingSource( &fes );
			pste2->get_SurenessPercent( &percent );
			pste2->get_InputFileName( &inName );
			pste2->get_OutputFileName( &outName );
			
			::SysFreeString( inName );
			::SysFreeString( outName );

			ULONG refCnt = pste2->Release();		// release QuerryInterface bump
		}

	}

#endif


	END_BE_SAFE

	return hr;
}

STDMETHODIMP CECProject::DeleteOutputFiles()
{
	START_BE_SAFE( CECProject::DeleteOutputFiles );


	if( (_waccess( m_cbstrSSFName.m_str, 0 )) != -1 )	// file exists
		if ( _wunlink( m_cbstrSSFName.m_str ) == -1)
		{
			ATLTRACE("======= Unable to delete: ");
			OutputDebugStringW( m_cbstrSSFName.m_str );
			OutputDebugString( "\n" );
		}

	if( (_waccess( m_cbstrSTYName.m_str, 0 )) != -1 )	// file exists
		if ( _wunlink( m_cbstrSTYName.m_str ) == -1)
		{
			ATLTRACE("======= Unable to delete: ");
			OutputDebugStringW( m_cbstrSTYName.m_str );
			OutputDebugString( "\n" );
		}

	BSTR bstrOut;
	for ( TVectorITFileInfo fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++ )
	{
		CInternalProjectFileInfo* fi = (*fiIT);	// get a pointer to the object

		fi->GetOutputFileName( &bstrOut );

		if ( _wunlink( bstrOut ) == -1 )
		{
			ATLTRACE("======= Unable to delete: ");
			OutputDebugStringW( bstrOut );
			OutputDebugString( "\n" );
		}

		::SysFreeString( bstrOut );
	}

	END_BE_SAFE

	return S_OK;
}

STDMETHODIMP CECProject::get_AutoDeleteTempFiles(BOOL *pVal)
{
	*pVal = m_AutoDelete;
	return S_OK;
}

STDMETHODIMP CECProject::put_AutoDeleteTempFiles(BOOL newVal)
{
	m_AutoDelete = newVal;
	return S_OK;
}

STDMETHODIMP CECProject::GetFileInfo(BSTR inFileName, IECProjectFileInfo **data)
{
	bool found = false;
	CInternalProjectFileInfo* fi = NULL;

	START_BE_SAFE( CECProject::GetFileInfo );

	for ( TVectorITFileInfo fiIT = m_vFileInfo.begin(); fiIT != m_vFileInfo.end(); fiIT++ )
	{
		fi = (*fiIT);	// get the object
		if ( fi->SameInputFileName( inFileName ) )
		{
			found = true;
			break;
		}
	}

	if ( !found )
	{
		return E_INVALIDARG;	// not a valid file name
	}

	// now build a copy of the object
	CComObject<CECProjectFileInfo> *pste;
	HRESULT hResult = CComObject<CECProjectFileInfo>::CreateInstance(&pste);
	if (FAILED(hResult))
		return hResult;

	// pull out the data from the item and populate the COM object
	VARIANT vMyData;
	memset(&vMyData, 0, sizeof(vMyData) );
	vMyData.vt = VT_USERDEFINED;
	vMyData.byref = fi;

	pste->Init( &vMyData );
	pste->AddRef();	

	*data = pste;

	END_BE_SAFE

	return S_OK;
}
