// GuessFileEncoding.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"

#include "stdio.h"				// fread
#include "GuessFileEncoding.h"


bool IsUTF8Text(const char* utf8, int len);
bool IsUTF8String(const char* utf8);


CGuessFileEncoding::CGuessFileEncoding( BSTR fileName):		// char *fileName ) :
	m_FileEncoding(FE_Unknown), m_buf(0), m_bufLength(0), m_HasBOM(false), m_BOMEncoding(FE_Unknown)
{
	m_FileName = fileName;	// new char[strlen(fileName)+1];
//	strcpy( m_FileName, fileName );

	// Read BOM if it exists...
	m_BOMEncoding = ReadBOM( m_FileName );
	
	if ( m_BOMEncoding != FE_Unknown )	// found BOM
	{
		m_HasBOM = true;
		m_FileEncoding = m_BOMEncoding;
	}
	else
	{
		GetFileData();		// read the file (or portion there of) into buffer
		ParseTheBuffer();	// scan buffer to determine encoding
	}
}


CGuessFileEncoding::~CGuessFileEncoding()
{
	if ( m_buf ) 
		free(m_buf);

//	if ( m_FileName )
//		delete [] m_FileName;
}


EC_FileEncoding CGuessFileEncoding::ReadBOM( BSTR fname )	// char* fname )
{
	EC_FileEncoding rval = FE_Unknown;

	FILE * fp = NULL;
	char * prgchBuf = 0;

	while ( 1 )
	{
		fp = _wfopen( fname, L"rb");
		if (!fp)
			break;

		long nFileSize = 4;	// _filelength(_fileno(fp));
		if (nFileSize == -1L)
			break;

		prgchBuf = (char*)malloc(nFileSize + 1);
		if (!prgchBuf)
			break;

		if (fread(prgchBuf, nFileSize, 1, fp) != 1)
			break;

		// now do the work on the BOM if it exists

		char utf32be[] = { (char)0x00, (char)0x00, (char)0xfe, (char)0xff };
		char utf32le[] = { (char)0xff, (char)0xfe, (char)0x00, (char)0x00 };
		char utf16be[] = { (char)0xfe, (char)0xff };
		char utf16le[] = { (char)0xff, (char)0xfe };
		char utf8   [] = { (char)0xef, (char)0xbb, (char)0xbf };
		struct {
			char* data;
			int len;
			EC_FileEncoding encoding;
		} encodingData[] = {
			{ utf32be, 4, FE_UTF32BE },
			{ utf32le, 4, FE_UTF32LE },
			{ utf16be, 2, FE_UTF16BE },
			{ utf16le, 2, FE_UTF16LE },
			{ utf8   , 3, FE_UTF8    },
		};

		short numEncodings = sizeof(encodingData)/sizeof(encodingData[0]);
		for ( int i=0; i<numEncodings; i++ )
		{
			if ( memcmp(prgchBuf, encodingData[i].data, encodingData[i].len ) == 0 )
			{
				rval = encodingData[i].encoding;
				break;
			}
		}
		break;
	}

	if ( fp )
		fclose(fp);

	if ( prgchBuf )
		free(prgchBuf);

	return rval;
}


void CGuessFileEncoding::GetFileData()			// open, and read 'n' bytes into the 'buffer'
{
	EC_FileEncoding rval = FE_Unknown;

	FILE * fp = NULL;
	if ( m_buf )
		free(m_buf);

	m_buf = 0;
	m_bufLength = 0;

	while ( 1 )
	{
		fp = _wfopen( m_FileName, L"rb");
		if (!fp)
			break;

		long nFileSize = _filelength(_fileno(fp));
		if (nFileSize == -1L)
			break;

		if ( nFileSize > 0x4000 )	// 16k
			nFileSize = 0x4000;		// limit to 16k for now

		m_bufLength = nFileSize;
		m_buf = (char*)malloc(nFileSize + 1);
		if (!m_buf)
		{
			m_bufLength = 0;
			break;
		}

		if (fread(m_buf, nFileSize, 1, fp) != 1)
		{
			m_bufLength = 0;
			break;
		}

		m_buf[nFileSize] = '\0';

		break;
	}

	if ( fp )
		fclose(fp);
}
	
void CGuessFileEncoding::ParseTheBuffer()		// walk through the buffer and process the data
{
	bool isUTF8 = IsUTF8String(m_buf);

	if ( isUTF8 )
	{
		m_FileEncoding = FE_UTF8;
	}
	else
		m_FileEncoding = GuessEncoding();
}

//bool CheckBuf( char *buf, 

EC_FileEncoding	CGuessFileEncoding::GuessEncoding()
{
	EC_FileEncoding rval = FE_Unknown;
	
	long utf32le = 0, utf32be = 0;
	long utf16le = 0, utf16be = 0;
	long bytes   = 0;

	for (long pos = 0; pos < m_bufLength; pos++ )
	{
		if ( m_buf[pos] == '\\' )
		{
			//
			// first check for utf32
			//
			long inc = pos%4;
			if ( inc == 0 )
			{
				if ( pos+3 <= m_bufLength )	// within bounds
				{
					if ( m_buf[pos+1] == 0x00 && m_buf[pos+2] == 0x00 && m_buf[pos+3] == 0x00 )
						utf32le++;
				}
			}
			else if ( inc == 3 )
			{
				if ( pos-3 >= 0 )	// within bounds
				{
					if ( m_buf[pos-1] == 0x00 && m_buf[pos-2] == 0x00 && m_buf[pos-3] == 0x00 )
						utf32be++;
				}
			}
			//
			// check for utf16
			//
			inc = pos%2;
			if ( inc == 0 )
			{
				if ( pos+1 <= m_bufLength )	// within bounds
				{
					if ( m_buf[pos+1] == 0x00 )
						utf16le++;
				}
			}
			else if ( inc == 1 )
			{
				if ( pos-1 >= 0 )	// within bounds
				{
					if ( m_buf[pos-1] == 0x00 )
						utf16be++;
				}
			}

			bytes++;	// bump byte counter
		}		
	}

	long ttl32 = utf32be + utf32le;
	long ttl16 = utf16be + utf16le;

	if ( ttl32 > ttl16/2 )	// looks like more valid 32 hits
	{
		if ( utf32be > utf32le )
			rval = FE_UTF32BE;
		else
			rval = FE_UTF32LE;
	}
	else if ( ttl16 > bytes/2 )
	{
		if ( utf16be > utf16le )
			rval = FE_UTF16BE;
		else
			rval = FE_UTF16LE;
	}
	else if ( bytes )
		rval = FE_BYTES;

/*
	if ( utf32be > 0 && utf32be > utf32le )
		rval = FE_UTF32BE;
	else if ( utf32le )
		rval = FE_UTF32LE;
	else if ( utf16be )
		rval = FE_UTF16BE;
	else if ( utf16le )
		rval = FE_UTF16LE;
	else if ( bytes )
		rval = FE_BYTES;
*/

	if ( rval == FE_Unknown )
		rval = FE_BYTES;		// don't return unknown - make a guess

	return rval;
}


void CGuessFileEncoding::UnicodeValueToSurrogatePair( long scalar, short *high, short *low )
{
	*high = (short)((scalar - 0x10000) / 0x400 + 0xd800);
	*low  = (short)((scalar - 0x10000) % 0x400 + 0xdc00);
}

long CGuessFileEncoding::SurrogatePairToUnicodeValue( unsigned short high, unsigned short low )
{
	long rval = 0;
	
	rval  = (high - 0xd800) * 0x400;
	rval += (low  - 0xdc00);
	rval += 0x10000;

	return rval;
}



#define kLeft1BitMask  0x80
#define kLeft2BitsMask 0xC0
#define kLeft3BitsMask 0xE0
#define kLeft4BitsMask 0xF0
#define kLeft5BitsMask 0xF8
#define kLeft6BitsMask 0xFC
#define kLeft7BitsMask 0xFE

#define k2BytesLeadByte kLeft2BitsMask
#define k3BytesLeadByte kLeft3BitsMask
#define k4BytesLeadByte kLeft4BitsMask
#define k5BytesLeadByte kLeft5BitsMask
#define k6BytesLeadByte kLeft6BitsMask
#define kTrialByte      kLeft1BitMask

#define UTF8_1Byte(c) ( 0 == ((c) & kLeft1BitMask))
#define UTF8_2Bytes(c) ( k2BytesLeadByte == ((c) & kLeft3BitsMask))
#define UTF8_3Bytes(c) ( k3BytesLeadByte == ((c) & kLeft4BitsMask))
#define UTF8_4Bytes(c) ( k4BytesLeadByte == ((c) & kLeft5BitsMask))
#define UTF8_5Bytes(c) ( k5BytesLeadByte == ((c) & kLeft6BitsMask))
#define UTF8_6Bytes(c) ( k6BytesLeadByte == ((c) & kLeft7BitsMask))
#define UTF8_ValidTrialByte(c) ( kTrialByte == ((c) & kLeft2BitsMask))


bool IsUTF8String(const char* utf8)
{
    if(NULL == utf8)
        return false;	// true;
    return IsUTF8Text(utf8, strlen(utf8));
}

bool IsUTF8Text(const char* utf8, int len)
{
	int bytePairCounts[7];
	memset(bytePairCounts, 0, sizeof(bytePairCounts));
	int searchLen = len - 10;	// make sure we cant fail with our trail bytes test

	int i, j, clen, maxclen=0;
	for(i =0; i < searchLen; i += clen)
	{
		clen = 0;
		if(UTF8_1Byte(utf8[i]))
		{
			clen = 1;
		} 
		else if(UTF8_2Bytes(utf8[i])) 
		{
			clen = 2;
			/* No enough trail bytes */
			if( (i + clen) > len) 
				return false;
			/* 0000 0000 - 0000 007F : should encode in less bytes */
			if(0 ==  (utf8[i] & 0x1E )) 
				return false;
		} 
		else if(UTF8_3Bytes(utf8[i])) 
		{
			clen = 3;
			/* No enough trail bytes */
			if( (i + clen) > len) 
				return false;
			/* a single Surrogate should not show in 3 bytes UTF8, instead, the pair should be intepreted
			as one single UCS4 char and encoded UTF8 in 4 bytes */
			if((0xED == utf8[i] ) && (0xA0 ==  (utf8[i+1] & 0xA0 ) )) 
				return false;
			/* 0000 0000 - 0000 07FF : should encode in less bytes */
			if((0 ==  (utf8[i] & 0x0F )) && (0 ==  (utf8[i+1] & 0x20 ) )) 
				return false;
		} 
		else if(UTF8_4Bytes(utf8[i])) 
		{
			clen = 4;
			/* No enough trail bytes */
			if( (i + clen) > len) 
				return false;
			/* 0000 0000 - 0000 FFFF : should encode in less bytes */
			if((0 ==  (utf8[i] & 0x07 )) && (0 ==  (utf8[i+1] & 0x30 )) ) 
				return false;
			
		} 
		else if(UTF8_5Bytes(utf8[i])) 
		{
			clen = 5;
			/* No enough trail bytes */
			if( (i + clen) > len) 
				return false;
			/* 0000 0000 - 001F FFFF : should encode in less bytes */
			if((0 ==  (utf8[i] & 0x03 )) && (0 ==  (utf8[i+1] & 0x38 )) ) 
				return false;
		} 
		else if(UTF8_6Bytes(utf8[i])) 
		{
			clen = 6;
			/* No enough trail bytes */
			if( (i + clen) > len) 
				return false;
			/* 0000 0000 - 03FF FFFF : should encode in less bytes */
			if((0 ==  (utf8[i] & 0x01 )) && (0 ==  (utf8[i+1] & 0x3E )) ) 
				return false;
		} 
		else 
		{
			return false;
		}
		for(j = 1; j<clen ;j++)
		{
			if(! UTF8_ValidTrialByte(utf8[i+j])) /* Trail bytes invalid */
				return false;
		}
		bytePairCounts[clen]++;
		if ( maxclen < clen )
			maxclen = clen;
	}
	return (maxclen>1);
}
 

/*
int main(int argc, char* argv[])
{
	if ( argc <= 1 ) 
	{
		Usage( argv[0] );
		return 2;
	}

//	char buff[33] = { L"*.*" };

	for ( int i=1; i<argc; i++)
	{
		struct _finddata_t files;
		long hFile;

		if( (hFile = _findfirst( argv[i], &files )) == -1L )
		{
			printf( "%s not in current directory.\n", argv[1] );
			continue;
		}


		do
		{
			CGuessFileEncoding guess( files.name );	
			char buf[32];
			guess.GetEncodingAsString( buf );
			printf(" %20s --> BOM(%c) - %s\n", files.name, guess.HasBOM()?'T':'F', buf );

		} while ( _findnext( hFile, &files ) == 0 );

		_findclose( hFile );
	}

	return 0;

}
*/


void CGuessFileEncoding::GetEncodingAsString( char *buf )
{
	switch (m_FileEncoding)
	{
		case FE_Unknown: strcpy( buf, "Unknown"); break;
		case FE_BYTES:	 strcpy( buf, "Bytes");   break;
		case FE_UTF8:	 strcpy( buf, "UTF8");	  break;
		case FE_UTF16BE: strcpy( buf, "UTF16BE"); break;
		case FE_UTF16LE: strcpy( buf, "UTF16LE"); break;
		case FE_UTF32BE: strcpy( buf, "UTF32BE"); break;
		case FE_UTF32LE: strcpy( buf, "UTF32LE"); break;
	}
}

