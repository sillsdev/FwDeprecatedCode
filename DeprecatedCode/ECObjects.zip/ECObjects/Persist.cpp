// Persist.cpp: implementation of the CPersist class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Persist.h"
#include "CRC.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPersist::CPersist() :
	m_Data(0), m_DataSize(0), m_DataLength(0), m_ChunkSize(256), m_ReadPos(0), m_Error(ET_NONE)
{
	m_Data = new char[m_ChunkSize];
	memset( m_Data, 0xbb, m_ChunkSize );
	m_DataSize = m_ChunkSize;

	long tmpCRC = 0x12345678, tmpSize=0x12345678;
	this->operator<<(tmpCRC) << tmpSize << Version();

	m_ReadPos = m_DataLength;		// start reading after the crc, size and version
}

CPersist::~CPersist()
{
	if ( m_Data )
	{
		delete [] m_Data;
		m_Data = NULL;
	}
}

CPersist::CPersist( char* dataIn, long length ) : 
	m_DataSize(length), m_DataLength(length), m_ChunkSize(256), m_ReadPos(0), m_Error(ET_NONE)
{
	m_Data = new char[m_DataSize];
	memcpy( m_Data, dataIn, m_DataSize );

	// check the CRC
	long inCRC, inLength, checkCRC;
	short inVer;

	CPersist* pptr = this;
	*pptr >> inCRC;
	*pptr >> inLength;
	*pptr >> inVer;

	if ( m_DataLength == inLength )
		int asdf = 1234;

	checkCRC = CalcCRC();

	if ( inCRC != checkCRC )
		m_Error = ET_BAD_INIT;

	m_ReadPos = 13;
}


long CPersist::CalcCRC()
{
	long dataOffset = 5;
	long crcSize = 5;

	// The crc is based on the data after the crc [ after the first 5 bytes]
	//
	CRC* crc = CRC::Instance();
	long rval = crc->CalculateCRC( &m_Data[dataOffset], m_DataLength-crcSize );

	return rval;
}

const char* CPersist::ReadOnlyBuffer()
{ 
	// add the current crc and size to the buffer

	DataType dt;
	long lval;

	// put out the Size ID and Value
	//
	dt = DT_LONG;
	lval = m_DataLength;					// put out the whole length of the stream
	char * pos = &m_Data[5];
	*pos = dt;								// put out the id
	pos++;									// move the pointer
	lval = htonl( lval );					// convert from host order to network order
	memcpy(pos, &lval, sizeof(lval) );		// copy over the data

	// put out the CRC ID and Value
	//
	lval = CalcCRC();
	pos = m_Data;
	*pos = dt;								// put out the id
	pos++;									// move the pointer
	lval = htonl( lval );					// convert from host order to network order
	memcpy(pos, &lval, sizeof(lval) );		// copy over the data
	
	return m_Data; 
}



// ----------------------------------------------------------------

// ==================================================
// Add a short value to the stream
// ==================================================
CPersist& CPersist::operator <<( short dataIn)
{
	DataType dt = DT_SHORT;
	long sizeNeeded = 3;

	{
		m_strStream << dt << dataIn;
	}

	if ( dataIn == 0 )
		sizeNeeded = 1;

	if ( m_DataSize-m_DataLength < sizeNeeded )		// have to increase size
		GrowBuffer( m_DataLength+sizeNeeded );
	
	if ( dataIn == 0 )						// zero value, 
		return DataEqualsZero( dt );		//  put out id and DV_ZERO

	char * pos = &m_Data[m_DataLength];
	*pos = dt;								// put out the id
	pos++;									// move the pointer
	dataIn = htons( dataIn );				// convert from host order to network order
	memcpy(pos, &dataIn, sizeof(dataIn) );	// copy over the data
	m_DataLength += sizeNeeded;				// increase buffer length

	return *this;
}
// ==================================================
// Read a short value from the stream
// ==================================================
CPersist& CPersist::operator >>( short& dataIn)
{
	char* pos = &m_Data[m_ReadPos];

	if ( ((*pos) & DT_SHORT) != DT_SHORT )
	{
		ATLTRACE("CPersist: expecting 0x%X, found 0x%X.\n", DT_SHORT, *pos );
		SetError( ET_WRONG_TYPE );
		return *this;
	}

	if ( (*pos) & DV_ZERO )
	{
		dataIn = 0;
		m_ReadPos++;
	}
	else
	{
		long size = 3;
		pos++;
		memcpy(&dataIn, pos, sizeof(dataIn) );
		dataIn = ntohs( dataIn );
		m_ReadPos += size;
	}
	return *this;
}

// ----------------------------------------------------------------

// ==================================================
// Add a long value to the stream
// ==================================================
CPersist& CPersist::operator <<( long dataIn)
{
	DataType dt = DT_LONG;
	long sizeNeeded = 5;

	{
		m_strStream << dt << _T(" ") << dataIn << _T(" ");
		char* streamData = m_strStream.rdbuf()->str();
		m_strStream.rdbuf()->freeze(false);
	}

	if ( dataIn == 0 )
		sizeNeeded = 1;

	if ( m_DataSize-m_DataLength < sizeNeeded )		// have to increase size
		GrowBuffer( m_DataLength+sizeNeeded );
	
	if ( dataIn == 0 )						// zero value, 
		return DataEqualsZero( dt );		//  put out id and DV_ZERO

	// put out the ID and Data value
	//
	char * pos = &m_Data[m_DataLength];
	*pos = dt;								// put out the id
	pos++;									// move the pointer
	dataIn = htonl( dataIn );				// convert from host order to network order
	memcpy(pos, &dataIn, sizeof(dataIn) );	// copy over the data
	m_DataLength += sizeNeeded;				// increase buffer length

	return *this;
}
// ==================================================
// Read a Long value from the stream
// ==================================================
CPersist& CPersist::operator >>( long& dataIn)
{
	char* pos = &m_Data[m_ReadPos];

	if ( ((*pos) & DT_LONG) != DT_LONG )
	{
		ATLTRACE("CPersist: expecting 0x%X, found 0x%X.\n", DT_LONG, *pos );
		SetError( ET_WRONG_TYPE );
		return *this;
	}

	if ( *pos & DV_ZERO )
	{
		dataIn = 0;
		m_ReadPos++;
	}
	else
	{
		long size = 5;
		pos++;
		memcpy(&dataIn, pos, sizeof(dataIn) );
		dataIn = ntohl( dataIn );
		m_ReadPos += size;
	}

	return *this;
}

// ----------------------------------------------------------------

// ==================================================
// Process DT_BINARY, DT_CHARSTR, and DT_BSTR
// ==================================================
CPersist& CPersist::ProcessBinaryData( DataType dt, CBinaryData *binData)
{
	long sizeNeeded = 1+4+binData->Size();			// id+size+data

	if ( binData->Size() == 0 )						// Binary data is empty
		sizeNeeded = 1;								// only need 1 byte

	if ( m_DataSize-m_DataLength < sizeNeeded )		// have to increase size
		GrowBuffer( m_DataLength+sizeNeeded );
	
	if ( sizeNeeded == 1 )							// no actual data
		return NoData( dt );						// put out id and DV_EMPTY

	char * pos = &m_Data[m_DataLength];
	*pos = dt;										// put out the id
	pos++;											// move the pointer
	long lsize = binData->Size();
	lsize = htonl( lsize );							// convert from host order to network order
	memcpy(pos, &lsize, sizeof(lsize) );			// copy over the size of the data
	pos += sizeof(lsize);							// move the pointer
	memcpy(pos, binData->Data(), binData->Size() );	// copy over the data
	m_DataLength += sizeNeeded;						// increase buffer length

	return *this;
}

// ----------------------------------------------------------------
// ==================================================
// Read DT_BINARY, DT_CHARSTR, and DT_BSTR
// ==================================================
CBinaryData* CPersist::ReadKnownData( DataType dt )
{
	char* pos = &m_Data[m_ReadPos];

	if ( ((*pos) & dt) != dt )
	{
		ATLTRACE("CPersist: expecting 0x%X, found 0x%X.\n", dt, *pos );
		SetError( ET_WRONG_TYPE );
		return NULL;
	}

	if ( (*pos) & DV_EMPTY )
	{
		m_ReadPos++;
		return NULL;
		CBinaryData* rval;
		rval = new CBinaryData( "" );
		return rval;
	}

	long lsize;								// storage for the data size
	pos++;									// move past ID to size field
	memcpy( &lsize, pos, sizeof(lsize) );	// read the data size 
	lsize = ntohl( lsize );					// convert back to host order
	pos += sizeof(lsize);					// move past the size field to the data

	CBinaryData* rval;
	rval = new CBinaryData( pos, lsize, false );
	m_ReadPos += 5+lsize;

	return rval;
}

// ----------------------------------------------------------------

// ==================================================
// Add a binary data object to the stream
// ==================================================
CPersist& CPersist::operator <<( CBinaryData *binData)
{
	return ProcessBinaryData( DT_BINARY, binData );
}

// ==================================================
// Read a binary data object from the stream
// ==================================================
CPersist& CPersist::operator >>( CBinaryData& binData)
{
	CBinaryData *data = ReadKnownData( DT_BINARY );

	if ( data == NULL )
		return *this;

	binData = *data;
	delete data;

	return *this;
}

// ----------------------------------------------------------------

// ==================================================
// Add a char string (null terminated) to the stream
// ==================================================
CPersist& CPersist::operator <<( char* cptr)
{
	int len = 0;
	if ( cptr && *cptr )
		len = strlen( cptr )+1;

	CBinaryData binData( cptr, len, false );
	return ProcessBinaryData( DT_CHARSTR, &binData );
}

// ----------------------------------------------------------------

CPersist& CPersist::operator >>( char** cptr)
{
	CBinaryData *data = ReadKnownData( DT_CHARSTR );

	if ( data == NULL )
	{
		*cptr = new char[1];
		*cptr = '\0';
//		*cptr = NULL;
		return *this;
	}

	*cptr = new char[data->Size()];
	memcpy( *cptr, data->Data(), data->Size() );
	delete data;
	
	return *this;
}

// ==================================================
// Add a BSTR (double null terminated) value to the stream
// ==================================================
CPersist& CPersist::operator <<( BSTR *bstrData)
{
	int len = ::SysStringByteLen( *bstrData );
	if ( len > 0 )
		len += 2;		// include the two byte zero chars

	CBinaryData binData( (const char*) (*bstrData), len, false );
	return ProcessBinaryData( DT_BSTR, &binData );
}

CPersist& CPersist::operator >>( BSTR* bstrData)
{
	CBinaryData *data = ReadKnownData( DT_BSTR );

	if ( data == NULL )
	{
		*bstrData = ::SysAllocString( L"" );
		return *this;
	}
	*bstrData = ::SysAllocStringByteLen( data->Data(), data->Size()-2 );
	delete data;
	
	return *this;
}
// ----------------------------------------------------------------









long CPersist::Encode( short dataIn, unsigned char ** dataOut, long dataOutLen )
{
	long rval = -1;
	const long sizeNeeded = 3;

	if ( dataOutLen >= sizeNeeded )		// room for id and data
	{
		unsigned char * pos = *dataOut;
		*pos = CPersist::DT_SHORT;		// put out the id
		pos++;							// move the pointer
		memcpy(pos, &dataIn, 2 );		// copy over the data
		rval = sizeNeeded;				// return the size used
	}

	return rval;
}

long CPersist::Encode( long  dataIn, unsigned char ** dataOut, long dataOutLen )
{
	long rval = -1;
	const long sizeNeeded = 5;

	if ( dataOutLen >= sizeNeeded )		// room for id and data
	{
		unsigned char * pos = *dataOut;
		*pos = CPersist::DT_LONG;		// put out the id
		pos++;							// move the pointer
		memcpy(pos, &dataIn, 4 );		// copy over the data
		rval = sizeNeeded;				// return the size used
	}

	return rval;
}

long CPersist::Encode( BSTR  dataIn, unsigned char ** dataOut, long dataOutLen )
{
	long rval = -1;

	return rval;
}

long CPersist::Encode( const unsigned char *dataIn, long dataInLen, unsigned char ** dataOut, long dataOutLen )
{
	long rval = -1;
	const long sizeNeeded = dataInLen+1+4;

	if ( dataOutLen >= sizeNeeded )		// room for id and data
	{
		unsigned char * pos = *dataOut;
		*pos = CPersist::DT_BINARY;		// put out the id
		pos++;							// move the pointer
		memcpy(pos, &dataInLen, 4 );	// put out the length
		pos += 4;
		memcpy(pos, dataIn, dataInLen);	// copy over the data
		rval = sizeNeeded;				// return the size used
	}

	return rval;
}


//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

long CPersist::GrowBuffer( long minSize )
{
	char* temp = m_Data;
	do
	{
		m_DataSize += m_ChunkSize;
	} while ( m_DataSize < minSize );

	m_Data = new char[m_DataSize];
	memset( m_Data, 0xbb, m_DataSize );
	memcpy( m_Data, temp, m_DataLength );

	delete [] temp;
	return m_DataSize;
}

CPersist& CPersist::DataEqualsZero( CPersist::DataType dt )
{
	m_Data[m_DataLength] = dt | DV_ZERO;	// zero
	m_DataLength++;							// increase buffer length by 1
	return *this;
}

CPersist& CPersist::NoData( CPersist::DataType dt )
{
	m_Data[m_DataLength] = dt | DV_EMPTY;	// empty / null
	m_DataLength++;							// increase buffer length by 1
	return *this;
}

// ----------------------------------------------------------------
// ============ CBinaryData class methods ========================

CBinaryData& CBinaryData::operator=( const CBinaryData& ref )
{
	if ( m_DeepCopy && m_Data )
		delete [] m_Data;
	
	m_DeepCopy = true;
	if ( ref.m_Data )
	{
		m_Size = ref.m_Size;
		m_Data = new char[m_Size];
		memcpy( m_Data, ref.m_Data, m_Size );
	}
	else
	{
		m_Data = NULL;
		m_Size = 0;
	}

	return *this;
}

CBinaryData::CBinaryData( const char* data, bool deepCopy/*=true*/ ) : m_DeepCopy(deepCopy)
{
	if ( m_DeepCopy )
	{
		if ( data )
		{
			m_Size = strlen(data);
			m_Data = new char[m_Size];
			memcpy( m_Data, data, m_Size );
		}
		else
		{
			m_Data = NULL;
			m_Size = 0;
		}
	}
	else
	{
		m_Data = (char*)data;
		if ( data )
			m_Size = strlen( data );
		else
			m_Size = 0;
	}
}

CBinaryData::CBinaryData( const char* data, long size, bool deepCopy/*=true*/ ) : m_DeepCopy(deepCopy)
{
	if ( m_DeepCopy )
	{
		if ( size > 0 )
		{
			m_Data = new char[size];
			memcpy( m_Data, data, size );
		}
		else
			m_Data = NULL;
	}
	else
	{
		m_Data = (char*)data;
	}
	m_Size = size;
}

CBinaryData::~CBinaryData()
{
	if ( m_DeepCopy && m_Data )
		delete [] m_Data;
}
// ----------------------------------------------------------------
