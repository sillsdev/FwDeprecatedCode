// ECProjectFileInfo.cpp : Implementation of CECProjectFileInfo
#include "stdafx.h"
#include "ECObjects.h"
#include "ECProjectFileInfo.h"

/////////////////////////////////////////////////////////////////////////////
// CECProjectFileInfo

STDMETHODIMP CECProjectFileInfo::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IECProjectFileInfo
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CECProjectFileInfo::get_FileEncoding(EC_FileEncoding *pVal)
{
	*pVal = m_Data.GetFileEncoding();
	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::put_FileEncoding(EC_FileEncoding newVal)
{
	m_Data.SetFileEncoding( newVal );
	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::get_InputFileName(BSTR *pVal)
{
	m_Data.GetInputFileName( pVal );
	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::put_InputFileName(BSTR newVal)
{
	m_Data.SetInputFileName( newVal );
	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::get_OutputFileName(BSTR *pVal)
{
	m_Data.GetOutputFileName( pVal );
	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::put_OutputFileName(BSTR newVal)
{
	m_Data.SetOutputFileName( newVal );
	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::get_SurenessPercent(short *pVal)
{
	*pVal = m_Data.GetSurenessPercent();
	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::put_SurenessPercent(short newVal)
{
	m_Data.SetSurenessPercent( newVal );
	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::get_FileEncodingSource(EC_FileEncodingSource *pVal)
{
	*pVal = m_Data.GetFileEncodingSource();
	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::Init(VARIANT *myData)
{
	if ( myData->vt != VT_USERDEFINED )	// UNKNOWN )
		return E_INVALIDARG;

	CInternalProjectFileInfo * data = (CInternalProjectFileInfo*) myData->byref;
	if ( !data )
	{
		return E_INVALIDARG;
	}

	m_Data = *data;	// assignment opperator

	return S_OK;
}

STDMETHODIMP CECProjectFileInfo::get_HasBOM(BOOL *pVal)
{
	*pVal = m_Data.HasBOM();
	return S_OK;
}
