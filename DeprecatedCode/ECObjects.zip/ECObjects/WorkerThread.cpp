// WorkerThread.cpp: implementation of the CWorkerThread class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WorkerThread.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWorkerThread::CWorkerThread()
{

//	InitializeCriticalSectionAndSpinCount(&m_cs, 0x4000);
	InitializeCriticalSection(&m_cs);	// create the critical section
	m_hShutdown = NULL;
	m_Thread = NULL;
	m_DoneEvent = CreateEvent(NULL, false, false, NULL);
}

CWorkerThread::~CWorkerThread()
{
	CloseHandle(m_DoneEvent);
	DeleteCriticalSection(&m_cs);
}

HANDLE CWorkerThread::Done()
{
	return m_DoneEvent;
}