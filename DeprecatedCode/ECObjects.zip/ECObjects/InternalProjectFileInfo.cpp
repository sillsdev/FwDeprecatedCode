// InternalProjectFileInfo.cpp: implementation of the CInternalProjectFileInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "InternalProjectFileInfo.h"
#include "io.h"		// file methods
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInternalProjectFileInfo::CInternalProjectFileInfo() : CTraceCreation("CInternalProjectFileInfo"),
	m_surenessPercent(0), m_FE(FE_Unknown), m_FESource(FES_GUESS), m_hasBOM(false)
{
	SetNewOutputName();		// create output file name
}


CInternalProjectFileInfo::~CInternalProjectFileInfo()
{
	// delete the output file if the file size is zero
	RemoveTempOutputFile();
}

//////////////////////////////////////////////////
// Assignment operator
//////////////////////////////////////////////////
//
CInternalProjectFileInfo & CInternalProjectFileInfo::operator=( const CInternalProjectFileInfo & other)
{
	if ( this == &other )
		return *this;

	m_FE					= other.m_FE;
	m_FESource				= other.m_FESource;
	m_surenessPercent		= other.m_surenessPercent;
	m_cbstrInName			= other.m_cbstrInName;
	m_cbstrInNameLowerCase	= other.m_cbstrInNameLowerCase;	// use internally for comparisons
	m_cbstrOutName			= other.m_cbstrOutName;
	m_hasBOM				= other.m_hasBOM;

	
	return *this;
}

void CInternalProjectFileInfo::SetNewOutputName()
{
	char buff[512], tmpName[512];
	if ( GetTempPath( 512, buff ) == 0 )	// failed
	{
		strcpy( buff, "c:\\" );				// default to 'c' drive on failure
	}
	
	GetTempFileName(buff, "ECO", 0, tmpName);
	m_cbstrOutName = tmpName;
}

void CInternalProjectFileInfo::RemoveTempOutputFile()
{
	// delete the output file if the file size is zero
	if (m_cbstrOutName.Length() <= 0)
		return;

	FILE * fp = _wfopen(m_cbstrOutName.m_str, L"rb");
	if (fp)
	{
		long nFileSize = _filelength(_fileno(fp));
		fclose(fp);
		if (nFileSize <= 0L)
		{
			if ( _wunlink( m_cbstrOutName.m_str ) == -1)
			{
				OutputDebugString("Unable to delete output file <");
				OutputDebugStringW(m_cbstrOutName);
				OutputDebugString(">\n");
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////
// Set Methods
//////////////////////////////////////////////////////////////////////

void CInternalProjectFileInfo::SetInputFileName( BSTR in )
{
	m_cbstrInName = in;
	m_cbstrInNameLowerCase = in;
	m_cbstrInNameLowerCase.ToLower();	// lower case version for comparisions
}


void CInternalProjectFileInfo::SetOutputFileName( BSTR in )
{
	RemoveTempOutputFile();		// remove temp file

	m_cbstrOutName = in;

	if (m_cbstrOutName.Length() <= 0)
		SetNewOutputName();
}


void CInternalProjectFileInfo::SetFileEncoding( EC_FileEncoding fe, short surnessPercent/*=100*/ )
{
	m_FE = fe;
	m_surenessPercent = surnessPercent;
	m_FESource = FES_USER;				// user is calling this method
}


//////////////////////////////////////////////////////////////////////
// Get Methods
//////////////////////////////////////////////////////////////////////

HRESULT CInternalProjectFileInfo::GetInputFileName( BSTR *out)
{
	*out = m_cbstrInName.Copy(); 
	return S_OK; 
}


HRESULT CInternalProjectFileInfo::GetOutputFileName( BSTR *out)
{
	*out = m_cbstrOutName.Copy(); 
	return S_OK; 
}


HRESULT CInternalProjectFileInfo::GetFileEncoding( EC_FileEncoding* fe, EC_FileEncodingSource* fes, short* surnessPercent )
{
	*fe = m_FE;
	*fes = m_FESource;
	*surnessPercent = m_surenessPercent;
	return S_OK;
}


//////////////////////////////////////////////////////////////////////
// Comparison Methods
//////////////////////////////////////////////////////////////////////

bool CInternalProjectFileInfo::SameInputFileName( const BSTR& in )
{
	CComBSTR tmpstr = in;
	tmpstr.ToLower();

	if ( m_cbstrInNameLowerCase == tmpstr )
		return true;
	return false;
}


//////////////////////////////////////////////////////////////////////
// Friend Methods
//////////////////////////////////////////////////////////////////////

CPersist& operator<<( CPersist& stream, CInternalProjectFileInfo* data)
{
	BSTR inName=0;	// , outName=0;
	EC_FileEncodingSource fes;
	EC_FileEncoding fe;
	short s_fe, s_fes, percent;

	data->GetInputFileName( &inName );
//	data->GetOutputFileName( &outName );
	data->GetFileEncoding( &fe, &fes, &percent );

	s_fe  = fe;		// convert to short
	s_fes = fes;	// convert to short

	// =====================================================
	stream << (BSTR*)&inName;	//  << (BSTR*)&outName;
	stream << (short)fe << (short)fes << (short)percent;
	// =====================================================

	if ( inName )		::SysFreeString( inName );
//	if ( outName )		::SysFreeString( outName );

	return stream;
}

CPersist& operator>>( CPersist& stream, CInternalProjectFileInfo** data)
{
	BSTR inName=0;	// , outName=0;
	short s_fe, s_fes, percent;

	// =====================================================
	stream >> (BSTR*)&inName;	//  >> (BSTR*)&outName;
	stream >> s_fe >> s_fes >> percent;
	// =====================================================

	EC_FileEncodingSource fes = (EC_FileEncodingSource)s_fes;
	EC_FileEncoding fe = (EC_FileEncoding)s_fe;

	*data = new CInternalProjectFileInfo();
	(*data)->SetInputFileName( inName );
//	(*data)->SetOutputFileName( L"" );	// outName );
	(*data)->SetFileEncoding( fe, percent );
	(*data)->m_FESource = fes;		// make sure it's the same

	if ( inName )		::SysFreeString( inName );
//	if ( outName )		::SysFreeString( outName );

	return stream;
}

