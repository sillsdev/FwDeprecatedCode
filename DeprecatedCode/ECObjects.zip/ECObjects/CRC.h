// CRC.h: interface for the CRC class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CRC_H__E2A1CCAD_D8E8_48A1_B7E2_9D9854D6EC2B__INCLUDED_)
#define AFX_CRC_H__E2A1CCAD_D8E8_48A1_B7E2_9D9854D6EC2B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRC
{
private:
	CRC(){};

public:
	static CRC* Instance();
	static void Done();

	unsigned long CalculateCRC( void *buffer, unsigned int count );

private:
	void BuildCRCTable();

	static CRC* m_Instance;
	static unsigned long m_CRC32_POLYNOMIAL;
	static unsigned long m_CRC32_STARTVALUE;
	static unsigned long m_CRCTable[ 256 ];
};


#endif // !defined(AFX_CRC_H__E2A1CCAD_D8E8_48A1_B7E2_9D9854D6EC2B__INCLUDED_)
