// InternalMappingData.h: interface for the CInternalMappingData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTERNALMAPPINGDATA_H__499DBCC6_0A4E_4BE8_83FD_7BBA75E78AF4__INCLUDED_)
#define AFX_INTERNALMAPPINGDATA_H__499DBCC6_0A4E_4BE8_83FD_7BBA75E78AF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ECObjects.h"			// MarkerDomain
#include "Persist.h"
#include "AutoIncrement.h"
#include "TraceCreation.h"


class CInternalMappingData : public CAutoIncrement, public CTraceCreation
{
public:
	CInternalMappingData();
	CInternalMappingData( const CInternalMappingData& other);
	CInternalMappingData & operator=( const CInternalMappingData& other);

	virtual ~CInternalMappingData();

	// char* interface
	void SetMarkerEncoding( char* in );
	void SetDataEncoding( char* in );
	void SetBeginMarker( char* in );
	void SetEndMarker( char* in );

	// BSTR interface
	void SetMarkerEncoding( BSTR in );  
	void SetDataEncoding( BSTR in );
	void SetBeginMarker( BSTR in );
	void SetEndMarker( BSTR in );
	void SetStyleName( BSTR in );
	void SetWritingSystem( BSTR in );

	// remaining "set" interfaces
	void SetDomain( MarkerDomain in );
	void SetInline( BOOL in );
	void SetConfirmed( BOOL in );

	void SetMarker		( BSTR begin )			{ SetBeginMarker( begin ); SetEndMarker( _T("")); SetInline( FALSE ); }
	void SetMarker		( BSTR begin, BSTR end ){ SetBeginMarker( begin ); SetEndMarker( end   ); SetInline( FALSE ); }
	void SetInlineMarker( BSTR begin, BSTR end ){ SetBeginMarker( begin ); SetEndMarker( end   ); SetInline( TRUE  ); }


	// Get Methods
	HRESULT GetMarkerEncoding( BSTR *out);
	HRESULT GetDataEncoding( BSTR *out);
	HRESULT GetBeginMarker( BSTR *out);
	HRESULT GetEndMarker( BSTR *out);
	HRESULT GetNewBeginMarker( BSTR *out);
	HRESULT GetNewEndMarker( BSTR *out);
	HRESULT GetStyleName( BSTR *out);

	HRESULT GetWritingSystem( BSTR *out);
	
	BOOL			GetIsInline()	{ return m_IsInline; }
	BOOL			GetIsConfirmed(){ return m_IsConfirmed; }
	MarkerDomain	GetDomain()		{ return m_Domain; }
	unsigned long	GetCreatorID()	{ return m_CreatorID; }
	bool			GetWasCopied()	{ return m_CreatorID != 0; }


	friend CPersist& operator<<( CPersist& stream, CInternalMappingData* data);
	friend CPersist& operator>>( CPersist& stream, CInternalMappingData** data);

	long GetSBKey();		// calc &| return the long key for SB data


private:
	void SetNewBeginMarker( BSTR in );
	void SetNewEndMarker( BSTR in );
	void CalcNewBeginMarker();			// build the new begin marker if needed
	void CalcNewEndMarker();			// build the new end marker if needed

	MarkerDomain m_Domain;
	CComBSTR m_cbstrMarkerEncoding;
	CComBSTR m_cbstrDataEncoding;
	CComBSTR m_cbstrEndMarker;
	CComBSTR m_cbstrBeginMarker;
	CComBSTR m_cbstrStyleName;
	CComBSTR m_cbstrNewBeginMarker;
	CComBSTR m_cbstrNewEndMarker;
	CComBSTR m_cbstrWritingSystem;

	BOOL m_IsInline;
	BOOL m_IsConfirmed;

	unsigned long m_CreatorID;		// id of other object if created by copy or assignment
	long m_SBKey;
	bool m_DirtySBKey;

	short m_DestructorCount;
};

#endif // !defined(AFX_INTERNALMAPPINGDATA_H__499DBCC6_0A4E_4BE8_83FD_7BBA75E78AF4__INCLUDED_)
