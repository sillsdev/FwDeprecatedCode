#include "stdafx.h"
#include "TraceCreation.h"


//////////////////////////////////////////////////
// Initialize static members
//////////////////////////////////////////////////
//
TraceCreationMap CTraceCreation::mObjects;
TraceCreationActiveMap CTraceCreation::mActiveObjects;
CRITICAL_SECTION CTraceCreation::mCS;
bool CTraceCreation::mbInitDone = false;
int  CTraceCreation::mMaxLen = 0;

//////////////////////////////////////////////////
// Define some preprocessor short cuts
//////////////////////////////////////////////////
//
#define TRY_START	try { EnterCriticalSection( &mCS );
#define TRY_STOP	} catch (...) { AtlTrace("__**-- Exception in CTraceCreation **\n"); } LeaveCriticalSection( &mCS );

#ifdef _TURN_ON_OUTPUT_TRACING_		// _DEBUG
#define	SKIP_IF_RELEASE ;
#define	SKIP_IF_RELEASE_RETURN( X ) ;
#else
#define	SKIP_IF_RELEASE return;
#define	SKIP_IF_RELEASE_RETURN( X ) return X ;
#endif


#if 0
//////////////////////////////////////////////////
// Test "Leaky" class for memory leaks...
//////////////////////////////////////////////////
//
class CLeaky : public CTraceCreation
{
public:
	CLeaky() : CTraceCreation( "CLeaky" ) { memset( &mLeaky, 0x77, sizeof( mLeaky )); }
	char	mLeaky[10];
};
#endif
//////////////////////////////////////////////////
// Static Init Method
//////////////////////////////////////////////////
//
void CTraceCreation::Init()
{
////8/19	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	if ( !mbInitDone )
	{
		InitializeCriticalSection( &mCS );
		mbInitDone = true;
		
////		CLeaky *leak = new CLeaky();	// create a leak!!!
////		_CrtDumpMemoryLeaks();
	}
}

//////////////////////////////////////////////////
// Static Done method (free up memory for class)
//////////////////////////////////////////////////
//
void CTraceCreation::Done()
{
////8/19	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	Reset();
	DeleteCriticalSection( &mCS );
	mbInitDone = false;
}

//////////////////////////////////////////////////
// Static Reset method (free up memory for class)
//////////////////////////////////////////////////
//
void CTraceCreation::Reset()
{
////8/19	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	Init();

	TRY_START

	// just need to free up the vector pointers, all else handled automatically
	TraceCreationActiveMap::iterator it = mActiveObjects.begin();
	while ( it != mActiveObjects.end() )
	{
		bVec *active = (*it).second;
		delete active;
		it++;
	}

	mActiveObjects.clear();
	mObjects.clear();

	TRY_STOP
}

//////////////////////////////////////////////////
// Default Constructor
//////////////////////////////////////////////////
//
CTraceCreation::CTraceCreation()
{
////8/19	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	Init();

	TRY_START

	mCreationType = CT_UNKNOWN;
	Init( "Unknown - defCons" );
///	ShowObjects();
	
	TRY_STOP
}

//////////////////////////////////////////////////
// Prefered Constructor with super class name
//////////////////////////////////////////////////
//
CTraceCreation::CTraceCreation( char* name )
{
////8/19	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	Init();

	TRY_START

	mCreationType = CT_CONS;
	Init( name );
///	ShowObjects();
	
	TRY_STOP
}

//////////////////////////////////////////////////
// Copy Constructor
//////////////////////////////////////////////////
//
CTraceCreation::CTraceCreation( const CTraceCreation& other)
{
////8/19	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	if ( this == &other )
		return;

////8/19	ATLTRACE("*** Copy of ID<%d-%d>\n", other.mID, other.mCreationType );	// .GetCreationString() );
	mCreationType = CT_COPY;
	Init( (char*)other.mName.c_str() );

}

//////////////////////////////////////////////////
// Assignment operator
//////////////////////////////////////////////////
//
CTraceCreation & CTraceCreation::operator=( const CTraceCreation & other)
{
////8/19	SKIP_IF_RELEASE_RETURN( *this )		// run faster if in release mode & skip the output tracking

	if ( this == &other )
		return *this;

////8/19	ATLTRACE("*** Assignment of ID<%d-%s>\n", other.mID, other.mCreationType );	// .GetCreationString() );
	mCreationType = CT_ASSIGN;
	Init( (char*)other.mName.c_str() );

	return *this;
}

//////////////////////////////////////////////////
// Destructor
//////////////////////////////////////////////////
//
CTraceCreation::~CTraceCreation()
{
////8/19	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	TRY_START


	TraceCreationData data;
	TraceCreationMap::iterator it = mObjects.find( mName );
	if ( it == mObjects.end() )
	{
		// shouldn't ever happen
		std::string name = (std::string)((*it).first);
		AtlTrace("~~~ Error in destructor <%*s>\n", mMaxLen, name.c_str() );
	}
	else
	{
		std::string strObjName = /*(std::string)*/(*it).first;
		const char* name = strObjName.c_str();
		data = (TraceCreationData)((*it).second);

		bool active = IsObjectActive();

		if ( !active )
		{
			AtlTrace("~~~ ERR %*s : deleting object again %d\n", mMaxLen, name, mID );
///			assert(true);
		}
		else
		{
////8/19			AtlTrace("~~~ %*s ID<%d> being Destroyed.\n", mMaxLen, name, mID);
///			mID *= -1;
			data.active--;
////8/19			AtlTrace("~~~ %*s %d active out of %d\n", mMaxLen, name, data.active, data.max );
		}
		mObjects[mName] = data;

		TraceCreationActiveMap::iterator ita = mActiveObjects.find( name );	// begin();
		bVec *activeList = (bVec*)((*ita).second);
		activeList->at( mID ) = false;

//		ShowCount( name );
	}

///	ShowObjects();
	
	TRY_STOP
}

//////////////////////////////////////////////////
// Initialize routine
//////////////////////////////////////////////////
//
void CTraceCreation::Init( char * name )
{
////8/19	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	TRY_START

	mName = name;
	if ( mName.length() > (size_t)mMaxLen )
		mMaxLen = mName.length();

	TraceCreationData data;
	bVec *activeList = NULL;
	TraceCreationMap::iterator it = mObjects.find( name );
	if ( it == mObjects.end() )
	{
		data.active = 1;
		data.max = 1;

		// add entry to the active map as well
		activeList = new bVec;
		activeList->push_back( false );			// zero index is place holder
		mActiveObjects[ name ] = activeList;
	}
	else
	{
		TraceCreationActiveMap::iterator ita = mActiveObjects.find( name );	// begin();
		activeList = (*ita).second;	// mActiveObjects.find( name );
		data = (TraceCreationData)((*it).second);
		data.active++;
		data.max++;
	}
	activeList->push_back( true  );			// this id is active
	
	mID = data.max;
	mObjects[name] = data;	// mID;
////8/19	AtlTrace("+++ %*s %d being Created, %d active\n", mMaxLen, name, mID, data.active );
	
	TRY_STOP
}

//////////////////////////////////////////////////
// Static routine to show all objects and counts
//////////////////////////////////////////////////
//
void CTraceCreation::ShowObjects()
{
	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	Init();

	TRY_START
	
///	AtlTrace("*** %-*s ********  *****\n", mMaxLen, "*******" );
	AtlTrace("*** %-*s **********  **********\n", mMaxLen, "**********" );

	TraceCreationMap::iterator it = mObjects.begin();
	if ( it == mObjects.end() )
	{
		AtlTrace("*** No Objects currently exist\n" );
	}

	TraceCreationData data;
	std::string name;
	while ( it != mObjects.end() )
	{
		name = (std::string)((*it).first);
		data = (TraceCreationData)((*it).second);
///		AtlTrace("*** %-*s %d active %d max\n", mMaxLen, name.c_str(), data.active, data.max );
		AtlTrace("*** %-*s (%3d of %3d) ", mMaxLen, name.c_str(), data.active, data.max );

		// now show the individual active status
		TraceCreationActiveMap::iterator ita = mActiveObjects.find( name );	// begin();
		bVec *activeStatus = (*ita).second;	// mActiveObjects.find( name );

///		AtlTrace("***  %s ", "Active IDs [" );
		AtlTrace("[ " );
		for ( int i=1; i<(int)activeStatus->size(); i++)
		{
			if ( activeStatus->at(i) )
			{
				AtlTrace("%d", i);
				if ( i+1 < (int)activeStatus->size() )
					AtlTrace(", ");
			}
		}
		AtlTrace(" ]\n");

		it++;
	}
//	AtlTrace("*** End\n" );
	AtlTrace("*** %-*s ********  *****\n", mMaxLen, "*******" );
	

	TRY_STOP
}

//////////////////////////////////////////////////
// Show the count for the passed in class name
//////////////////////////////////////////////////
//
void CTraceCreation::ShowCount( char* name )
{
	SKIP_IF_RELEASE		// run faster if in release mode & skip the output tracking

	Init();

	TRY_START

	TraceCreationMap::iterator it = mObjects.find( name );
	if ( it == mObjects.end() )
	{
		AtlTrace("*** No Objects of this type have been created\n" );
	}
	else
	{
		std::string name = (std::string)((*it).first);
		TraceCreationData data = (TraceCreationData)((*it).second);
		AtlTrace("*** %*s has %d active, %d max\n", mMaxLen, name.c_str(), data.active, data.max );
	}
	
	TRY_STOP
}

//////////////////////////////////////////////////
// See if the current object is in an active state
//////////////////////////////////////////////////
//
bool CTraceCreation::IsObjectActive()
{
////8/19	SKIP_IF_RELEASE_RETURN(false)		// run faster if in release mode & skip the output tracking

	bool rval = false;

	TRY_START

	TraceCreationActiveMap::iterator it = mActiveObjects.find( mName );
	if ( it == mActiveObjects.end() )
	{
		AtlTrace("~~~ Error in IsObjectActive<%*s>\n", mMaxLen, mName.c_str() );
	}
	else
	{
		bVec *activeList = (bVec*)((*it).second);
		rval = activeList->at( mID );
	}
	

	TRY_STOP

	return rval;
}

//////////////////////////////////////////////////
// Get the creation string for the type
//////////////////////////////////////////////////
//
char* CTraceCreation::GetCreationString() 
{ 
	switch (mCreationType) 
	{ 
	case CT_COPY: return "copy";
		break;
	case CT_ASSIGN: return "assignment";
		break;
	case CT_CONS: return "constructor";
		break;
	case CT_UNKNOWN: return "unknown";
		break;
	}
	return "unknown";
}

