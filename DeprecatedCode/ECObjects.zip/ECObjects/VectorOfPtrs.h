// VectorOfPtrs.h: interface for the CVectorOfPtrs class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VECTOROFPTRS_H__DDDC2C5A_6854_4A24_BBDE_C4B59BCC0636__INCLUDED_)
#define AFX_VECTOROFPTRS_H__DDDC2C5A_6854_4A24_BBDE_C4B59BCC0636__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TraceCreation.h"
#include <vector>

#include "Persist.h"

template <typename classX>
class CVectorOfPtrs : public std::vector<classX*>, public CTraceCreation
{
public:
	CVectorOfPtrs() : std::vector<classX*>(), CTraceCreation( "CVectorOfPtrs" ) {}
	~CVectorOfPtrs();
	void RemoveAllPtrs();

///	friend CPersist& operator<<( CPersist& pstream, CVectorOfPtrs<classX>* dataVec);

};

template <typename classX> CVectorOfPtrs<classX>::~CVectorOfPtrs()
{
	RemoveAllPtrs();
};


template <typename classX> void CVectorOfPtrs<classX>::RemoveAllPtrs()
{
	std::vector<classX*>::iterator it;
	
	for ( it = begin(); it != end(); it++ )
	{
		delete *it;
	}
	clear();	// call base class
}

/*
template <typename classX> CPersist& CVectorOfPtrs<classX>::operator<<( CPersist& pstream, CVectorOfPtrs<classX>* dataVec)
{
	pstream << (long)dataVec->size();				//	Number of Mappings

	TVectorITInternalMappingData iitm = dataVec->.begin();
	while ( iitm != dataVec->.end() )
	{
		pstream << (*iitm);								//	[Mapping information]*
		iitm++;
	}
	
	return pstream;
}
*/

#endif // !defined(AFX_VECTOROFPTRS_H__DDDC2C5A_6854_4A24_BBDE_C4B59BCC0636__INCLUDED_)
