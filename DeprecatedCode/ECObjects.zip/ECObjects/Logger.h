// Logger.h: interface for the CLogger class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOGGER_H__340B10B1_9717_42F3_9A91_2D1A81707ACE__INCLUDED_)
#define AFX_LOGGER_H__340B10B1_9717_42F3_9A91_2D1A81707ACE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "WorkerThread.h"
#include <vector>
#include <map>


class CLogEntry
{
public:
	CLogEntry():msg(NULL) {}
	CLogEntry(char* data) { msg = new char[strlen(data)+1]; strcpy(msg, data); }
	~CLogEntry() { if (msg) delete[] msg; msg = NULL; }

	char*	Msg()		{ return msg; }

private:
	char* msg;
};


class CLogger : public CWorkerThread
{
public:
	static CLogger* Instance();
	static bool Shutdown();

private:
	CLogger();
	virtual ~CLogger();
	bool AddEntry(CLogEntry* pCLogEntry);

public:
	// log related methods
	//
	bool AddLine(char* msg);
	int	 GetEntry(CLogEntry** pCLogEntry);
	int	 GetPendingEntries();

private:
	static CLogger* m_Instance;
	
	HANDLE	m_NewEntryEvent;
	LONG	m_waitTime;
	std::vector<CLogEntry*> m_vecLog;

	static DWORD WINAPI ThreadMethod( LPVOID lpParam );
};

#endif // !defined(AFX_LOGGER_H__340B10B1_9717_42F3_9A91_2D1A81707ACE__INCLUDED_)
