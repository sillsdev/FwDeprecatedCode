// InternalProjectFileInfo.h: interface for the CInternalProjectFileInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTERNALPROJECTFILEINFO_H__70675FA2_C7F0_4C73_9BD3_9475B7215425__INCLUDED_)
#define AFX_INTERNALPROJECTFILEINFO_H__70675FA2_C7F0_4C73_9BD3_9475B7215425__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ECObjects.h"			// EC_FileEncodingSource, EC_FileEncoding
#include "Persist.h"			// CPersist object
#include "TraceCreation.h"


class CInternalProjectFileInfo  : public CTraceCreation
{
public:
	CInternalProjectFileInfo();
	CInternalProjectFileInfo & operator=( const CInternalProjectFileInfo& other);

	virtual ~CInternalProjectFileInfo();


	// Set Methods
	void SetInputFileName( BSTR in );
	void SetOutputFileName( BSTR in );
	void SetFileEncoding( EC_FileEncoding fe, short surnessPercent=100 );	

//	void SetFileEncoding( EC_FileEncoding in )				{ m_FE = in; }
	void SetFileEncodingSource( EC_FileEncodingSource in )	{ m_FESource = in; }
	void SetSurenessPercent( short in )						{ m_surenessPercent = in; }
	void SetHasBOM( bool in = TRUE )						{ m_hasBOM = in; }


	// Get Methods
	HRESULT GetInputFileName( BSTR *out);
	HRESULT GetOutputFileName( BSTR *out);
	HRESULT GetFileEncoding( EC_FileEncoding* fe, EC_FileEncodingSource* fes, short* surnessPercent );	

	EC_FileEncoding	GetFileEncoding()				{ return m_FE; }
	EC_FileEncodingSource GetFileEncodingSource()	{ return m_FESource; }
	short GetSurenessPercent()						{ return m_surenessPercent; }
	bool HasBOM()									{ return m_hasBOM; }

	// Comparison Methods
	bool SameInputFileName( const BSTR& in );

	// Persistant methods
	friend CPersist& operator<<( CPersist& stream, CInternalProjectFileInfo* data);
	friend CPersist& operator>>( CPersist& stream, CInternalProjectFileInfo** data);

private:

	void SetNewOutputName();	// set the output name to a generated unique name
	void RemoveTempOutputFile();

	CComBSTR m_cbstrInName;				// input file name
	CComBSTR m_cbstrInNameLowerCase;	// lower case input file name
	CComBSTR m_cbstrOutName;			// output file name

	EC_FileEncodingSource	m_FESource;	// who set the encoding
	EC_FileEncoding			m_FE;		// what is the encoding

	short	m_surenessPercent;			// how sure are you
	bool	m_hasBOM;					// true if BOM is in input file
};

#endif // !defined(AFX_INTERNALPROJECTFILEINFO_H__70675FA2_C7F0_4C73_9BD3_9475B7215425__INCLUDED_)
