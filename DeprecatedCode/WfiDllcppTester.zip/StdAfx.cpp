/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: stdafx.cpp
Responsibility: Randy Regnier
Last reviewed: not yet.

	WfiDllcppTester.pch will be the pre-compiled header
	stdafx.obj will contain the pre-compiled type information
-------------------------------------------------------------------------------*//*:End Ignore*/

#include "stdafx.h"