/*-----------------------------------------------------------------------------------*//*:Ignore
Copyright 2001, SIL International. All rights reserved.

File: WfiDllcppTester.cpp
Responsibility: Randy Regnier
Last reviewed: not yet.

	Provides for a way to test WfiUtil.dll from a command line.
	Various command line options are supported.
-------------------------------------------------------------------------------*//*:End Ignore*/

#include "stdafx.h"
#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <iostream.h>
#include <stdlib.h>
#include <stdio.h>

const char * const err = "ERROR: ";
char buffer[100000];

void test()
{
	HRESULT hr;
	IWFI * pwfi = NULL;
		// Initialize COM.
	hr = CoInitialize(NULL);
	if (FAILED(hr))
	{
		cout << err << "Could not initialize COM." << endl;
//		iRet = 1;
//		goto LExit;
	}

	// Create an IWFI object.
	hr = CoCreateInstance(CLSID_WFI, NULL, CLSCTX_INPROC_SERVER,
		IID_IWFI, (void **)&pwfi);
	if (FAILED(hr))
	{
		cout << err << "Could not create IWFI." << endl;
//		iRet = 2;
//		goto LExit;
	}

}

///////////////////////////////////////////////////////////////////////////////
//
//  FUNCTION: DisplayUsage()
//
//      Display usage information
//
//  PARAMETERS:
//
//  RETURNS: 0
//
//  COMMENTS:
//
///////////////////////////////////////////////////////////////////////////////

int DisplayUsage (void)
{
    cout << endl;
    cout << "Tests WfiUtil.dll" << endl;
    cout << endl;
    cout << "WfiDllcppTester [/S [sqlserver]] [/U [login]] [/P [password]]" << endl;
    cout << "                [/D [database]] [/L language project] [/I file] [/?]" << endl;
    cout << endl;
    cout << "  /S sqlserver   The SQL Server to connect to." << endl;
 	cout << "                     Default='<machine name>\\SILFW or .\\SILFW'." << endl;
    cout << "  /U login       The login to connect with." << endl;
	cout << "                     Default='FWDeveloper'." << endl;
    cout << "  /P password    The password for 'login'." << endl;
	cout << "                     Default='Careful' password." << endl;
    cout << "  /D database    The database to use." << endl;
	cout << "                     Default='ZPU'." << endl;
    cout << "  /L lang proj   The language project to use." << endl;
	cout << "                     Default='ZPU-Yal�lag Zapotec'." << endl;
    cout << "  /I input file  The XML data file name." << endl;
	cout << "                     Default='SampleM3ParserOutput.xml'." << endl;
    cout << "  /?             Display this usage information and exit." << endl;
    cout << endl;

    return (0);
}

///////////////////////////////////////////////////////////////////////////////
//
//  FUNCTION: GetOption()
//
//      Get next command line option and parameter
//
//  PARAMETERS:
//
//      argc - count of command line arguments
//      argv - array of command line argument strings
//      pszValidOpts - string of valid, case-sensitive option characters,
//                     a colon ':' following a given character means that
//                     option can take a parameter
//      ppszParam - pointer to a pointer to a string for output
//
//  RETURNS:
//
//      If valid option is found, the character value of that option
//          is returned, and *ppszParam points to the parameter if given,
//          or is NULL if no param
//      If standalone parameter (with no option) is found, 1 is returned,
//          and *ppszParam points to the standalone parameter
//      If option is found, but it is not in the list of valid options,
//          -1 is returned, and *ppszParam points to the invalid argument
//      When end of argument list is reached, 0 is returned, and
//          *ppszParam is NULL
//
//  COMMENTS:
//
///////////////////////////////////////////////////////////////////////////////
int GetOption(
    int argc,
    char** argv,
    char* pszValidOpts,
    char** ppszParam)
{
    static int iArg = 1;
    char chOpt;
    char* psz = NULL;
    char* pszParam = NULL;

    if (iArg < argc)
    {
        psz = &(argv[iArg][0]);
        if (*psz == '-' || *psz == '/')
        {
            // we have an option specifier
            chOpt = argv[iArg][1];
            if (isalnum(chOpt) || ispunct(chOpt))
            {
                // we have an option character
                psz = strchr(pszValidOpts, chOpt);
                if (psz != NULL)
                {
                    // option is valid, we want to return chOpt
                    if (psz[1] == ':')
                    {
                        // option can have a parameter
                        psz = &(argv[iArg][2]);
                        if (*psz == '\0')
                        {
                            // must look at next argv for param
                            if (iArg+1 < argc)
                            {
                                psz = &(argv[iArg+1][0]);
                                if (*psz == '-' || *psz == '/')
                                {
                                    // next argv is a new option, so param
                                    // not given for current option
                                }
                                else
                                {
                                    // next argv is the param
                                    iArg++;
                                    pszParam = psz;
                                }
                            }
                            else
                            {
                                // reached end of args looking for param
                            }

                        }
                        else
                        {
                            // param is attached to option
                            pszParam = psz;
                        }
                    }
                    else
                    {
                        // option is alone, has no parameter
                    }
                }
                else
                {
                    // option specified is not in list of valid options
                    chOpt = -1;
                    pszParam = &(argv[iArg][0]);
                }
            }
            else
            {
                // though option specifier was given, option character
                // is not alpha or was was not specified
                chOpt = -1;
                pszParam = &(argv[iArg][0]);
            }
        }
        else
        {
            // standalone arg given with no option specifier
            chOpt = 1;
            pszParam = &(argv[iArg][0]);
        }
    }
    else
    {
        // end of argument list
        chOpt = 0;
    }

    iArg++;
    *ppszParam = pszParam;
    return (chOpt);
}

/*----------------------------------------------------------------------------------------------
	Entry point for program.
	@return values:
		0 - Successful
		1 - Could not initialize COM
		2 - Could not create IWFI object.
		3 - Could not initialize IWFI
		4 - Could not open XML data file
		5 - Could not process the data file
----------------------------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
	int iRet = 0;	// Return value.
	HRESULT hr;
	IWFI * pwfi = NULL;
	FILE * pFile = NULL;
	size_t iFSize;
	char chOpt;				// Option character
	char * pszParam;		// Parameter
	_bstr_t bstrServer(L".\\SILFW"); // Server name
	_bstr_t bstrDatabase(L"ZPU");	// Database name
	_bstr_t bstrUser(L"FWDeveloper");		// User name
	_bstr_t bstrPassword(L"careful");	// Password
	_bstr_t bstrLangProj(L"ZPU-Yal�lag Zapotec");	// Language project name
	_bstr_t bstrInput;		// Input file data.
	_bstr_t bstrFormat(L"FWParse");		// Data format.
	char szInputFile[MAX_PATH];		// Input file

ZeroMemory(szInputFile, MAX_PATH);

	::GetEnvironmentVariable("FWROOT", szInputFile,MAX_PATH);
	strcat(szInputFile, "\\Src\\WW-WFIUtil\\");
	strcat(szInputFile, (LPCTSTR)bstrDatabase);
	strcat(szInputFile, "\\XFP For WfiUtil Testing.xml");
    
    // Get command-line options and parameters
    while (true)
    {
        // The following command-line options are valid, they
        // are neither case sensitive nor white-space sensitive, and
        // both '/' and '-' are valid switch characters
        //
        //  OPTION  PARAMETER           DESCRIPTION
        //
        //  /S      [sqlserver]         SQL Server
        //  /D      [database]          Database
        //  /U      [login]             Login
        //  /P      [password]          Password
        //  /L      project             Language project
        //  /I      file                XML data file
        //  /?                          Usage information

        chOpt = GetOption(argc, argv, "s:S:d:D:u:U:p:P:l:L:i:I:?", &pszParam);
        if (chOpt > 1)
        {
            // chOpt is valid argument
            switch (chOpt)
            {
            case 's':   // SQL Server
            case 'S':
                bstrServer = pszParam;
                break;
            case 'd':   // database
            case 'D':
                bstrDatabase = pszParam;
                break;
            case 'u':   // login
            case 'U':
                bstrUser = pszParam;
                break;
            case 'p':   // password
            case 'P':
                bstrPassword = pszParam;
                break;
            case 'l':   // Language project
            case 'L':
                bstrLangProj = pszParam;
                break;
            case 'i':   // Input file
            case 'I':
				ZeroMemory(szInputFile, MAX_PATH);
				strcpy(szInputFile, pszParam);
                break;
            case '?':   // usage info
                DisplayUsage();
                goto LExit;
                break;
            }
        }
        if (chOpt == 0)
        {
            // end of argument list
            break;
        }
        if ((chOpt == 1) || (chOpt == -1))
        {
            // Standalone param or error
            cout << err << "Argument '" << pszParam << "' not recognized" << endl;
            iRet = 2;
			goto LExit;
        }
    }

	// Initialize COM.
	hr = CoInitialize(NULL);
	if (FAILED(hr))
	{
		cout << err << "Could not initialize COM." << endl;
		iRet = 1;
		goto LExit;
	}

	// Create an IWFI object.
	hr = CoCreateInstance(CLSID_WFI, NULL, CLSCTX_INPROC_SERVER,
		IID_IWFI, (void **)&pwfi);
	if (FAILED(hr))
	{
		cout << err << "Could not create IWFI." << endl;
		iRet = 2;
		goto LExit;
	}

	// Initialize IWFI.
	hr = pwfi->Init(bstrServer, bstrDatabase, bstrLangProj, bstrUser, bstrPassword);
	if (FAILED(hr))
	{
		cout << err << "Could not initialize database." << endl;
		iRet = 3;
		goto LExit;
	}

	// Read input file.
	if((pFile = _wfopen(szInputFile, "r")) == NULL)
	{
		cout << err << "Could not open: '" << szInputFile << "'." << endl;
		iRet = 4;
		goto LExit;
	}
	iFSize = _wfread(&buffer, sizeof(char), 100000, pFile);
	
	//for some reason buffer isn't terminated properly
	buffer[iFSize] = 0;

	bstrInput = buffer;

	
	// Process data.
	hr = pwfi->ProcessParse(bstrFormat, bstrInput);
	if (FAILED(hr))
	{
		cout << err << "Could not process the data file: '" << szInputFile << "'." << endl;
		iRet = 5;
		goto LExit;
	}
	cout << "Worked fine." << endl;

LExit:
	if (pFile)
		fclose(pFile);
	if (pwfi)
		pwfi->Release();
	CoUninitialize();
	return iRet;
}
